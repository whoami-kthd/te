#if !defined(AFX_CMV_EDITJUMP_H__512570F8_95D2_4B94_8E8B_DF51E5CFDB13__INCLUDED_)
#define AFX_CMV_EDITJUMP_H__512570F8_95D2_4B94_8E8B_DF51E5CFDB13__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_EditJump.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMV_EditJump dialog

class CMV_EditJump : public CDialog
{
// Construction
public:
	CMV_EditJump(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMV_EditJump)
	enum { IDD = IDD_EDIT_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_EditJump)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMV_EditJump)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_EDITJUMP_H__512570F8_95D2_4B94_8E8B_DF51E5CFDB13__INCLUDED_)

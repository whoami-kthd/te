// CMV_MapJump.cpp : implementation file
//

#include "stdafx.h"
#include "cmv.h"
#include "CMV_MapJump.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump

IMPLEMENT_DYNCREATE(CMV_MapJump, CEditView)

CMV_MapJump::CMV_MapJump()
{
}

CMV_MapJump::~CMV_MapJump()
{
}


BEGIN_MESSAGE_MAP(CMV_MapJump, CView)
	//{{AFX_MSG_MAP(CMV_MapJump)
		ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump drawing

void CMV_MapJump::OnDraw(CDC* pDC)
{
	DrawJumpTable(pDC);
}

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump diagnostics

#ifdef _DEBUG
void CMV_MapJump::AssertValid() const
{
	CView::AssertValid();
}

void CMV_MapJump::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump message handlers
void CMV_MapJump::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}


void CMV_MapJump::DrawJumpTable(CDC* pDC)
{
	CRect rc;
	GetClientRect(&rc);

	pDC->FillSolidRect(rc, (::GetSysColor(COLOR_BTNFACE)));

	CPen pen(PS_SOLID, 1, RGB(80, 80, 80) );
	CPen* pOldPen = pDC->SelectObject(&pen);

	CFont myFontTool;
	myFontTool.CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));
	pDC->SelectObject(&myFontTool);

	// size unit
	int xSizeUnit = (rc.right - rc.left)/3;
	int ySizeUnit = (rc.bottom - rc.top)/2;

	// Draw edge of table
	pDC->MoveTo(rc.left, rc.bottom);
	pDC->LineTo(rc.right, rc.bottom);
	pDC->MoveTo(rc.left, rc.top);
	pDC->LineTo(rc.right, rc.top);
	pDC->MoveTo(rc.left, rc.top);
	pDC->LineTo(rc.left, rc.bottom);
	pDC->MoveTo(rc.right, rc.top);
	pDC->LineTo(rc.right, rc.bottom);
	
	pDC->MoveTo(rc.left + xSizeUnit, rc.top);
	pDC->LineTo(rc.left + xSizeUnit, rc.bottom);

	pDC->MoveTo(rc.left + 2*xSizeUnit, rc.top);
	pDC->LineTo(rc.left + 2*xSizeUnit, rc.bottom);

	pDC->MoveTo(rc.left + xSizeUnit, rc.top+ySizeUnit);
	pDC->LineTo(rc.right, rc.top+ySizeUnit);

	CRect WorkRect = rc;
	WorkRect.right = rc.left + xSizeUnit;
	pDC->DrawText(_T("Index"), &WorkRect, m_pDoc->m_nFormat);

	WorkRect.left = rc.left + xSizeUnit;
	WorkRect.right = rc.left + 2*xSizeUnit;
	WorkRect.bottom = rc.top + ySizeUnit;
	pDC->DrawText(_T("X"), &WorkRect, m_pDoc->m_nFormat);

	WorkRect.left = rc.left + xSizeUnit;
	WorkRect.right = rc.left + 2*xSizeUnit;
	WorkRect.bottom = rc.bottom;
	WorkRect.top = rc.top + ySizeUnit;
	pDC->DrawText(_T("Y"), &WorkRect, m_pDoc->m_nFormat);

	if(m_pDoc->m_IsDiplayJump == TRUE)
	{
		CString xClickJump = " ", yClickJump = " ";

		if ((m_pDoc->m_JumpX > 0) && (m_pDoc->m_JumpY > 0)) {
			xClickJump.Format("%d", m_pDoc->m_JumpX);
			yClickJump.Format("%d", m_pDoc->m_JumpY);
		}

		CEdit* edit1=(CEdit*) m_pDoc->m_pEdit1.GetDlgItem(IDC_EDIT_JUMP);
		edit1->SetWindowText((LPCTSTR)(xClickJump));

		CEdit* edit2=(CEdit*) m_pDoc->m_pEdit2.GetDlgItem(IDC_EDIT_JUMP);
		edit2->SetWindowText((LPCTSTR)(yClickJump));
	}
}


int CMV_MapJump::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if(CView::OnCreate(lpCreateStruct) == -1) return -1;
	
	CRect rc, EditRect1, EditRect2;
	GetWindowRect(rc);

	int xSizeUnit = (rc.right - rc.left)/3;
	int ySizeUnit = (rc.bottom - rc.top)/2;

	// Display editbox
	EditRect1.left = rc.left + 2*xSizeUnit;
	EditRect1.right = rc.right;
	EditRect1.top   = rc.top;
	EditRect1.bottom = rc.top + ySizeUnit;
	
	// Create m_pEdit1 
	ScreenToClient(&EditRect1);
	m_pDoc->m_pEdit1.Create(IDD_EDIT_DLG, this);
	m_pDoc->m_pEdit1.SetWindowPos(&CWnd::wndTop,
			EditRect1.left, EditRect1.top, EditRect1.Width(), EditRect1.Height(), SWP_DRAWFRAME);
	m_pDoc->m_pEdit1.ShowWindow(SW_SHOW);
	m_pDoc->m_pEdit1.SetDlgCtrlID(IDC_EDIT_1);

	
	// Display editbox
	EditRect2.left = rc.left + 2*xSizeUnit;
	EditRect2.right = rc.right;
	EditRect2.bottom = rc.bottom;
	EditRect2.top = rc.top + ySizeUnit;
	
	// Create m_pEdit1 
	ScreenToClient(&EditRect2);
	m_pDoc->m_pEdit2.Create(IDD_EDIT_DLG, this);
	m_pDoc->m_pEdit2.SetWindowPos(&CWnd::wndTop,
			EditRect2.left, EditRect2.top, EditRect2.Width(), EditRect2.Height(), SWP_DRAWFRAME);
	m_pDoc->m_pEdit2.ShowWindow(SW_SHOW);
	m_pDoc->m_pEdit1.SetDlgCtrlID(IDC_EDIT_2);

	return 0;
}

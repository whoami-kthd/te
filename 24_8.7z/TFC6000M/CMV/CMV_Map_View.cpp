// CMV_Map_View.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMV_Map_View.h"
#include "CMV_Util.h"
#include "MemDC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View

IMPLEMENT_DYNAMIC(CMV_Map_View, CScrollView)

CMV_Map_View::CMV_Map_View()
{
	SetBackSolidBrush(::GetSysColor(COLOR_BTNFACE));
}

CMV_Map_View::~CMV_Map_View()
{
}


BEGIN_MESSAGE_MAP(CMV_Map_View, CScrollView)
	//{{AFX_MSG_MAP(CMV_Map_View)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONUP()
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View drawing
BOOL CMV_Map_View::SetBackSolidBrush(COLORREF crColor)
{
	if(NULL != m_brushBack.GetSafeHandle())
	  m_brushBack.DeleteObject();

	BOOL bRet = m_brushBack.CreateSolidBrush(crColor);

	if(NULL != m_hWnd)
	  Invalidate();

	return bRet;
}



void CMV_Map_View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	m_pDoc ->m_Zoom = 1;
	
	_SetScrollSizes();
}


void CMV_Map_View::OnDraw(CDC* pDC)
{
	ASSERT(MM_TEXT == pDC->GetMapMode());
	ASSERT(CPoint(0, 0) == pDC->GetViewportOrg());

	if (m_pDoc->m_IsLoadedMap == true)
	{
		CRect rcClient(0, 0, 0, 0);
		GetClientRect(rcClient);
		const int cx = rcClient.right;  // view client area width
		const int cy = rcClient.bottom; // view client area height	
		CMemDC dcDraw(pDC, cx, cy);

		DrawLEDs(&dcDraw, pDC);

		CRect rcClip(0, 0, 0, 0);
		pDC->GetClipBox(rcClip);
		pDC->BitBlt(rcClip.left, rcClip.top, rcClip.Width(), rcClip.Height(), 
					&dcDraw, rcClip.left, rcClip.top, SRCCOPY);

		/* Set scroll for view pickup index alway in center(S) */
		if ( (GetStyle() & WS_HSCROLL) || (GetStyle() & WS_VSCROLL) ) {
			int xlimit = GetScrollLimit(SB_HORZ);
			int ylimit = GetScrollLimit(SB_VERT);

			if ((m_pDoc->m_IsDipsIndex == TRUE) && (m_pDoc->m_IndexSelect >= 1) ) {	
				int x1stLEDIndex = m_pDoc->LEDArrayInfo[m_pDoc->m_indexFirstY[m_pDoc->m_IndexSelect]][m_pDoc->m_indexFirstX[m_pDoc->m_IndexSelect]].left;
				int y1stLEDIndex = m_pDoc->LEDArrayInfo[m_pDoc->m_indexFirstY[m_pDoc->m_IndexSelect]][m_pDoc->m_indexFirstX[m_pDoc->m_IndexSelect]].top;

				int xEndLEDIndex = m_pDoc->LEDArrayInfo[m_pDoc->m_indexFirstY[m_pDoc->m_IndexSelect]+m_pDoc->m_ratioToolLEDX][m_pDoc->m_indexFirstX[m_pDoc->m_IndexSelect]+m_pDoc->m_ratioToolLEDY].right;
				int yEndLEDIndex = m_pDoc->LEDArrayInfo[m_pDoc->m_indexFirstY[m_pDoc->m_IndexSelect]+m_pDoc->m_ratioToolLEDX][m_pDoc->m_indexFirstX[m_pDoc->m_IndexSelect]+m_pDoc->m_ratioToolLEDY].bottom;
				
				int xCenter = (x1stLEDIndex + xEndLEDIndex)/2;
				int yCenter = (y1stLEDIndex + yEndLEDIndex)/2;

				SetScrollPos(SB_HORZ, (xCenter-rcClient.Width()/2 < xlimit) ? xCenter-rcClient.Width()/2 : xlimit);
				SetScrollPos(SB_VERT, (yCenter-rcClient.Height()/2 < ylimit) ? yCenter-rcClient.Height()/2 : ylimit);

				Invalidate();
				m_pDoc->m_IsDipsIndex = FALSE;
			}

			if (m_pDoc->m_IsDrawJumpInMap == TRUE) {	
				int xCenterLEDJump = (m_pDoc->LEDArrayInfo[m_pDoc->m_JumpY][m_pDoc->m_JumpX].right + m_pDoc->LEDArrayInfo[m_pDoc->m_JumpY][m_pDoc->m_JumpX].left)/2;
				int yCenterLEDJump = (m_pDoc->LEDArrayInfo[m_pDoc->m_JumpY][m_pDoc->m_JumpX].bottom + m_pDoc->LEDArrayInfo[m_pDoc->m_JumpY][m_pDoc->m_JumpX].top)/2;

				SetScrollPos(SB_HORZ, (xCenterLEDJump-rcClient.Width()/2 < xlimit) ? xCenterLEDJump-rcClient.Width()/2 : xlimit);
				SetScrollPos(SB_VERT, (yCenterLEDJump-rcClient.Height()/2 < ylimit) ? yCenterLEDJump-rcClient.Height()/2 : ylimit);

				Invalidate();
//				m_pDoc->m_IsDrawJumpInMap = FALSE;
			}
		}
		/* Set scroll for view pickup index alway in center(E) */

	}
}

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View diagnostics

#ifdef _DEBUG
void CMV_Map_View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMV_Map_View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View message handlers

void CMV_Map_View::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}


void CMV_Map_View::InitMapView()
{
	int i, j;

	m_pDoc->m_MiniSizeX = 3;
	m_pDoc->m_MiniSizeY = 3;

	m_pDoc->m_MiniPitchLEDX = 1;
	m_pDoc->m_MiniPitchLEDY = 1;

	m_pDoc->m_toolSizeX  = 2;
	m_pDoc->m_toolSizeY  = 2;

	m_pDoc->m_MiniPitchToolX = m_pDoc->m_toolSizeX * (m_pDoc->m_MiniSizeX + m_pDoc->m_MiniPitchLEDX);
	m_pDoc->m_MiniPitchToolY = m_pDoc->m_toolSizeY * (m_pDoc->m_MiniSizeY + m_pDoc->m_MiniPitchLEDY);;

	m_pDoc->MapSize = 6;
	m_pDoc->m_Zoom  = 1;

	m_pDoc->MapSize *= m_pDoc->m_Zoom;

	m_pDoc->m_SizeX = m_pDoc->m_MiniSizeX * m_pDoc->MapSize;
	m_pDoc->m_SizeY = m_pDoc->m_MiniSizeY * m_pDoc->MapSize;

	m_pDoc->m_LEDPitchX = m_pDoc->m_MiniPitchLEDX * m_pDoc->MapSize;
	m_pDoc->m_LEDPitchY = m_pDoc->m_MiniPitchLEDY * m_pDoc->MapSize;

	m_pDoc->m_toolPitchX = m_pDoc->m_toolSizeX * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX); //  suppose that value of m_toolPitchX
	m_pDoc->m_toolPitchY = m_pDoc->m_toolSizeY * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY); //  suppose that value of m_toolPitchY
	
	m_pDoc->m_ratioToolLEDX = m_pDoc->m_toolPitchX / (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX);
	m_pDoc->m_ratioToolLEDY = m_pDoc->m_toolPitchY / (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY);

	/* Get rect of LEDArrayInfo (S) */
	CRect Rect, Rect2;

	CSize size = GetTotalSize();
	// Get region
	CRect rc(CPoint(0, 0), GetTotalSize());

	Rect2.top    = rc.top + TYOUSEI_TOP;
	Rect2.left   = rc.left + TYOUSEI_LEFT;
	Rect2.bottom = rc.top + m_pDoc->m_SizeY - 1;
	Rect2.right  = rc.left + m_pDoc->m_SizeX - 1;

	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax ; i++){
		Rect.top    = Rect2.top + ((i - m_pDoc->m_CurY) * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY)) + m_pDoc->m_LEDPitchY;

		for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax ; j++){
			Rect.left   = Rect2.left + ((j - m_pDoc->m_CurX) * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX)) + m_pDoc->m_LEDPitchX;

			Rect.bottom = Rect.top  + m_pDoc->m_SizeY - 1;
			Rect.right  = Rect.left + m_pDoc->m_SizeX - 1;

			m_pDoc->LEDArrayInfo[i][j].top    = Rect.top;
			m_pDoc->LEDArrayInfo[i][j].left   = Rect.left;
			m_pDoc->LEDArrayInfo[i][j].right  = Rect.right;
			m_pDoc->LEDArrayInfo[i][j].bottom = Rect.bottom;

			m_pDoc->s2 = m_pDoc->str.Mid( ((m_pDoc->m_CoulmMax + 1) * i) + j, 1 );
			strcpy(m_pDoc->ch, (LPCTSTR)(m_pDoc->s2));
			m_pDoc->LEDArrayInfo[i][j].ch = m_pDoc->ch[0];

			if(m_pDoc->MapD.BCEQU.Find(CString(m_pDoc->ch[0])) != -1) {
				m_pDoc->LEDArrayInfo[i][j].isGoodBin = true;
			}else {
				m_pDoc->LEDArrayInfo[i][j].isGoodBin = false;
			}

			m_pDoc->LEDArrayInfo[i][j].isInGroup = false;
			m_pDoc->LEDArrayInfo[i][j].index	 = NULL;
		}
	}
	/* Get rect of LEDArrayInfo (E) */

	for(i = 0; i < m_pDoc->m_CoulmMax; i++) {
		m_pDoc->xAxisRectArray[i].left = m_pDoc->LEDArrayInfo[0][i].left;
		m_pDoc->xAxisRectArray[i].right = m_pDoc->LEDArrayInfo[0][i].right;
		m_pDoc->xAxisRectArray[i].bottom = m_pDoc->LEDArrayInfo[0][i].top;
		m_pDoc->xAxisRectArray[i].top = m_pDoc->LEDArrayInfo[0][i].top - TYOUSEI_TOP;
	}

	for(i = 0; i < m_pDoc->m_LineMax; i++) {		
		m_pDoc->yAxisRectArray[i].right = m_pDoc->LEDArrayInfo[i][0].left;
		m_pDoc->yAxisRectArray[i].left  = m_pDoc->LEDArrayInfo[i][0].left - TYOUSEI_LEFT;
		m_pDoc->yAxisRectArray[i].top = m_pDoc->LEDArrayInfo[i][0].top;
		m_pDoc->yAxisRectArray[i].bottom  = m_pDoc->LEDArrayInfo[i][0].bottom;
	}	
	/* Create axisRects for display axis (E) */

	m_mapDispSize.cx = m_pDoc->xAxisRectArray[m_pDoc->m_CoulmMax-1].right;
	m_mapDispSize.cy = m_pDoc->yAxisRectArray[m_pDoc->m_LineMax-1].bottom;

/* If size of LEDs bitmap is smaller than size of client rect - Scroll,
   assign LEDs bitmap size equal to client rect size (S) */
	GetClientRect(&rc);	
	if (m_mapDispSize.cx <= rc.right) {
		m_mapDispSize.cx = rc.right;
	}

	if (m_mapDispSize.cy <= rc.bottom) {
		m_mapDispSize.cy = rc.bottom;
	}
// (E)

	_SetScrollSizes();
}


void CMV_Map_View::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	CScrollView::OnPrepareDC(pDC, pInfo);

	pDC->SetMapMode(MM_TEXT);          // force map mode to MM_TEXT
	pDC->SetViewportOrg(CPoint(0, 0)); // force viewport origin to zero
}


BOOL CMV_Map_View::OnScrollBy(CSize sizeScroll, BOOL bDoScroll) 
{
	int xOrig, x;
	int yOrig, y;

	// don't scroll if there is no valid scroll range (ie. no scroll bar)
	CScrollBar* pBar;
	DWORD dwStyle = GetStyle();
	pBar = GetScrollBarCtrl(SB_VERT);
	if ((pBar != NULL && !pBar->IsWindowEnabled()) ||
		(pBar == NULL && !(dwStyle & WS_VSCROLL)))
	{
		// vertical scroll bar not enabled
		sizeScroll.cy = 0;
	}
	pBar = GetScrollBarCtrl(SB_HORZ);
	if ((pBar != NULL && !pBar->IsWindowEnabled()) ||
		(pBar == NULL && !(dwStyle & WS_HSCROLL)))
	{
		// horizontal scroll bar not enabled
		sizeScroll.cx = 0;
	}

	// adjust current x position
	xOrig = x = GetScrollPos(SB_HORZ);
	int xMax = GetScrollLimit(SB_HORZ);
	x += sizeScroll.cx;
	if (x < 0)
		x = 0;
	else if (x > xMax)
		x = xMax;

	// adjust current y position
	yOrig = y = GetScrollPos(SB_VERT);
	int yMax = GetScrollLimit(SB_VERT);
	y += sizeScroll.cy;
	if (y < 0)
		y = 0;
	else if (y > yMax)
		y = yMax;

	// did anything change?
	if (x == xOrig && y == yOrig)
		return FALSE;

	if (bDoScroll)
	{
	    Invalidate();
		if (x != xOrig)
			SetScrollPos(SB_HORZ, x);
		if (y != yOrig)
			SetScrollPos(SB_VERT, y);
	}
	return TRUE;
}


void CMV_Map_View::_SetScrollSizes()
{
	CSize sizeView(100, 100);
	if(m_pDoc->m_IsLoadedMap == true)
	{
	  CSize size = GetMapDispSize();
	  sizeView.cx = (int)(size.cx);
	  sizeView.cy = (int)(size.cy);
	}

   SetScrollSizes(MM_TEXT, sizeView);
}


CSize CMV_Map_View::GetMapDispSize(void)
{
	return m_mapDispSize;
}


int CMV_Map_View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	CSize sizeView(100, 100);
	SetScrollSizes(MM_TEXT, sizeView);
	return 0;
}


void CMV_Map_View::DrawLEDs(CMemDC* pDCDraw, CDC *pDC)
{
	CPoint point = GetScrollPosition();

	CRect rcClient;
    GetClientRect(&rcClient);

	const int cx = rcClient.right;				// view client area width
	const int cy = rcClient.bottom;				// view client area height
	const int bx = GetMapDispSize().cx;			// source bitmap width
	const int by = GetMapDispSize().cy;			// source bitmap height
	const int xPos = point.x;					// horizontal scroll position
	const int yPos = point.y;					// vertical scroll position

	// source and destination cordinates and sizes
	int xSrc = xPos, ySrc = yPos, nSrcWidth, nSrcHeight, xDst = 0, yDst = 0, nDstWidth, nDstHeight;

	if(bx > cx) {
	  nSrcWidth = bx - xSrc;
	  nDstWidth = bx - xSrc;
	}
	else {
	  nSrcWidth = bx;
	  nDstWidth = bx;
	}

	if(by > cy) {
	  nSrcHeight = by - ySrc;
	  nDstHeight = by - ySrc;
	}
	else {
	  nSrcHeight = by;
	  nDstHeight = by;
	}

	CMemDC pDCTemp(pDC, bx, by);
	/* Draw background color */
	pDCTemp.SelectObject(&m_brushBack);
	pDCTemp.PatBlt(0, 0, bx, by, PATCOPY);

	pDCTemp.SelectObject(&m_pDoc->myFont);

	CRect WorkRect;
	int i, j;
	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax ; i++){
		for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax ; j++){
			
			WorkRect.left	= m_pDoc->LEDArrayInfo[i][j].left;
			WorkRect.top	= m_pDoc->LEDArrayInfo[i][j].top;
			WorkRect.bottom = m_pDoc->LEDArrayInfo[i][j].bottom;
			WorkRect.right  = m_pDoc->LEDArrayInfo[i][j].right;

			CBrush brush(m_pDoc->m_gCategoryColor[(int)(m_pDoc->LEDArrayInfo[i][j].ch)]);
			pDCTemp.FillRect( WorkRect, &brush );
			pDCTemp.SetBkMode(TRANSPARENT);

			pDCTemp.DrawText(m_pDoc->LEDArrayInfo[i][j].ch, &WorkRect, m_pDoc->m_nFormat);
		}
	}

	/* Create axisRects for display axis (S) */
	CString text;	
	for(i = 0; i < m_pDoc->m_CoulmMax; i++) {
		text.Format(_T("%d"), i);
		pDCTemp.DrawText( text, m_pDoc->xAxisRectArray[i], m_pDoc->m_nFormat);
	}
	
	for(i = 0; i < m_pDoc->m_LineMax; i++) {
		text.Format(_T("%d"), i);
		pDCTemp.DrawText( text, m_pDoc->yAxisRectArray[i], m_pDoc->m_nFormat);
	}
	/* Create axisRects for display axis (E) */
	if( m_pDoc->m_IndexSelect >= 1){
		DrawIndexPickup(&pDCTemp, m_pDoc->m_IndexSelect);
	}

	if( m_pDoc->m_IsDrawJumpInMap == TRUE){
		DrawIndexJump(&pDCTemp, m_pDoc->m_JumpX, m_pDoc->m_JumpY);
	}
		
	pDCDraw->SetStretchBltMode(HALFTONE);
	pDCDraw->StretchBlt(xDst, yDst, nDstWidth, nDstHeight, &pDCTemp, xSrc, ySrc, nSrcWidth, nSrcHeight, SRCCOPY);
}


void CMV_Map_View::OnUpdateMapView(void)
{
	m_pDoc->MapSize = 6;
	m_pDoc->MapSize *= m_pDoc->m_Zoom;

	m_pDoc->m_SizeX = m_pDoc->m_MiniSizeX * m_pDoc->MapSize;
	m_pDoc->m_SizeY = m_pDoc->m_MiniSizeY * m_pDoc->MapSize;

	m_pDoc->m_LEDPitchX = m_pDoc->m_MiniPitchLEDX * m_pDoc->MapSize;
	m_pDoc->m_LEDPitchY = m_pDoc->m_MiniPitchLEDY * m_pDoc->MapSize;

	m_pDoc->m_toolPitchX = 2 * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX);	//  suppose that value of m_toolPitchX
	m_pDoc->m_toolPitchY = 2 * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY); //  suppose that value of m_toolPitchY

	m_mapDispSize.cx = m_pDoc->m_CoulmMax * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX) + 50;
	m_mapDispSize.cy = m_pDoc->m_LineMax * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY) + 50;

/* If size of LEDs bitmap is smaller than size of client rect - Scroll,
   assign LEDs bitmap size equal to client rect size (S) */
	CRect rect1;
	GetClientRect(&rect1);
	if (m_mapDispSize.cx <= rect1.right - 17) {
		m_mapDispSize.cx = rect1.right + 17;
	}

	if (m_mapDispSize.cy <= rect1.bottom - 17) {
		m_mapDispSize.cy = rect1.bottom + 17;
	}
// (E)

	/* Get rect of LEDArrayInfo (S) */
	CRect Rect, Rect2;
	int i, j;

	CSize size = GetTotalSize();
	// Get region
	CRect rc(CPoint(0, 0), GetTotalSize());

	Rect2.top    = rc.top + TYOUSEI_TOP;
	Rect2.left   = rc.left + TYOUSEI_LEFT;
	Rect2.bottom = rc.top + m_pDoc->m_SizeY - 1;
	Rect2.right  = rc.left + m_pDoc->m_SizeX - 1;

	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax ; i++){
		Rect.top    = Rect2.top + ((i - m_pDoc->m_CurY) * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY)) + m_pDoc->m_LEDPitchY;

		for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax ; j++){
			Rect.left   = Rect2.left + ((j - m_pDoc->m_CurX) * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX)) + m_pDoc->m_LEDPitchX;

			Rect.bottom = Rect.top  + m_pDoc->m_SizeY - 1;
			Rect.right  = Rect.left + m_pDoc->m_SizeX - 1;

			m_pDoc->LEDArrayInfo[i][j].top    = Rect.top;
			m_pDoc->LEDArrayInfo[i][j].left   = Rect.left;
			m_pDoc->LEDArrayInfo[i][j].right  = Rect.right;
			m_pDoc->LEDArrayInfo[i][j].bottom = Rect.bottom;
		}
	}
	/* Get rect of LEDArrayInfo (E) */

	for(i = 0; i < m_pDoc->m_CoulmMax; i++) {
		m_pDoc->xAxisRectArray[i].left = m_pDoc->LEDArrayInfo[0][i].left;
		m_pDoc->xAxisRectArray[i].right = m_pDoc->LEDArrayInfo[0][i].right;
		m_pDoc->xAxisRectArray[i].bottom = m_pDoc->LEDArrayInfo[0][i].top;
		m_pDoc->xAxisRectArray[i].top = m_pDoc->LEDArrayInfo[0][i].top - TYOUSEI_TOP;
	}

	for(i = 0; i < m_pDoc->m_LineMax; i++) {		
		m_pDoc->yAxisRectArray[i].right = m_pDoc->LEDArrayInfo[i][0].left;
		m_pDoc->yAxisRectArray[i].left  = m_pDoc->LEDArrayInfo[i][0].left - TYOUSEI_LEFT;
		m_pDoc->yAxisRectArray[i].top = m_pDoc->LEDArrayInfo[i][0].top;
		m_pDoc->yAxisRectArray[i].bottom  = m_pDoc->LEDArrayInfo[i][0].bottom;
	}	
	/* Create axisRects for display axis (E) */

	_SetScrollSizes();
	Invalidate(TRUE);
	UpdateWindow();
}


BOOL CMV_Map_View::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}


void CMV_Map_View::DrawIndexPickup(CMemDC *pDCDraw, int index)
{
	CRect WorkRect;

	CPen pen(PS_SOLID, 2, RGB(255, 0, 0) );
	CPen* pOldPen = pDCDraw->SelectObject(&pen);

	int i, j;
	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax ; i++){
		for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax ; j++){

			if (m_pDoc->LEDArrayInfo[i][j].index == index) {		
				WorkRect.top	= m_pDoc->LEDArrayInfo[i][j].top - 4;
				WorkRect.left	= m_pDoc->LEDArrayInfo[i][j].left - 4;
				WorkRect.bottom = m_pDoc->LEDArrayInfo[i][j].bottom + 4;
				WorkRect.right  = m_pDoc->LEDArrayInfo[i][j].right + 4;
			
				/* Draw rectange (S) */
				pDCDraw->MoveTo(WorkRect.left, WorkRect.top);
				pDCDraw->LineTo(WorkRect.right, WorkRect.top);

				pDCDraw->MoveTo(WorkRect.left, WorkRect.top);
				pDCDraw->LineTo(WorkRect.left, WorkRect.bottom);

				pDCDraw->MoveTo(WorkRect.left, WorkRect.bottom);
				pDCDraw->LineTo(WorkRect.right, WorkRect.bottom);

				pDCDraw->MoveTo(WorkRect.right, WorkRect.top);
				pDCDraw->LineTo(WorkRect.right, WorkRect.bottom);
				/* Draw rectange (E) */
			}
		}
	}
}

void CMV_Map_View::DrawIndexJump(CMemDC *pDCDraw, int indexX, int indexY)
{
	CRect WorkRect;

	CPen pen(PS_SOLID, 2, RGB(0, 0, 0) );
	CPen* pOldPen = pDCDraw->SelectObject(&pen);
	
	WorkRect.top	= m_pDoc->LEDArrayInfo[indexY][indexX].top - 4;
	WorkRect.left	= m_pDoc->LEDArrayInfo[indexY][indexX].left - 4;
	WorkRect.bottom = m_pDoc->LEDArrayInfo[indexY][indexX].bottom + 4;
	WorkRect.right  = m_pDoc->LEDArrayInfo[indexY][indexX].right + 4;
	
	/* Draw rectange (S) */
	pDCDraw->MoveTo(WorkRect.left, WorkRect.top);
	pDCDraw->LineTo(WorkRect.right, WorkRect.top);

	pDCDraw->MoveTo(WorkRect.left, WorkRect.top);
	pDCDraw->LineTo(WorkRect.left, WorkRect.bottom);

	pDCDraw->MoveTo(WorkRect.left, WorkRect.bottom);
	pDCDraw->LineTo(WorkRect.right, WorkRect.bottom);

	pDCDraw->MoveTo(WorkRect.right, WorkRect.top);
	pDCDraw->LineTo(WorkRect.right, WorkRect.bottom);
	/* Draw rectange (E) */
}


void CMV_Map_View::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CScrollView::OnLButtonUp(nFlags, point);
	int i = 0, j = 0;
	for(i = 0; i < m_pDoc->m_LineMax; i++) {	
		for(j = 0; j < m_pDoc->m_CoulmMax; j++) {
			if ((point.x >= m_pDoc->LEDArrayInfo[i][j].left && point.x <= m_pDoc->LEDArrayInfo[i][j].right) &&
				(point.y <= m_pDoc->LEDArrayInfo[i][j].bottom && point.y >= m_pDoc->LEDArrayInfo[i][j].top) ) {
				m_pDoc->m_JumpX = j;
				m_pDoc->m_JumpY = i;
			}
		}
	}

	m_pDoc->m_IsDiplayJump = TRUE;
	AfxGetApp()->m_pMainWnd->Invalidate();
	UpdateWindow();
}


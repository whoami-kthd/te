// BLE.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "BLE.h"

#include "CBLE_FrameWnd.h"
#include "CBLE_Doc.h"
#include "CBLE_View.h"
#include "CBLE_Util.h"
#include "windows.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Position of subinfo parametter in command lines
#define SUBINFO_POS						2
#define RIGHTSIDE_POS					11
#define LEFTSIDE_POS					14

// Define message for log file
#define DBLE_MULTIINSTANCE_ERROR		_T("Trying to run third instance!")

/////////////////////////////////////////////////////////////////////////////
// CBLEApp

HANDLE g_hFirstMutexAppRunning = NULL;
HANDLE g_hSecondMutexAppRunning = NULL;

// Use this to translate button in message box
HHOOK hhk;
int appLanguage;

BEGIN_MESSAGE_MAP(CBLEApp, CWinApp)
	//{{AFX_MSG_MAP(CBLEApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	//ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLEApp construction

CBLEApp::CBLEApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	p_Logger = NULL;
	m_Speed = 0;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CBLEApp object

CBLEApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CBLEApp initialization

BOOL CBLEApp::InitInstance()
{
	//Get instance checking result: 0 is no instance, 1 is 1 instance, 2 is 2 instances
	int instance = AppInstanceExists(); 
	if (instance != 0) {
		// Find first and second window
		HWND hWndFirstInstance, hWndSecondInstance;
		hWndSecondInstance = FindWindow(NULL, DBLE_FRAMENAME_EDITMODE);
		hWndFirstInstance = FindWindow(NULL, DBLE_FRAMENAME_SUBINFOMODE);
		UINT id = GetID(); //get command lines parametters

		// If subinfo window is found
		if ( hWndFirstInstance != (HWND)NULL ) {
			if (IsIconic(hWndFirstInstance)) {
				ShowWindow(hWndFirstInstance, SW_RESTORE); //bring to front
			}
			SetForegroundWindow(hWndFirstInstance);
			// CWnd* pWnd = CWnd::FromHandle(hWndFirstInstance);
			if (id == ID_MENU_SUBINFO_R || id == ID_MENU_SUBINFO_L || id == ID_MENU_SUBINFO) {
				SendMessage(hWndFirstInstance, WM_START_INSTANCE, (WPARAM)id, 0); // start L, R or both
				return false;
			}
		} 

		// If Edit window is found
		if (hWndSecondInstance != (HWND)NULL ){
			if (IsIconic(hWndSecondInstance)) {
				ShowWindow(hWndSecondInstance, SW_RESTORE); //bring to front
			}
			SetForegroundWindow(hWndSecondInstance);
			// CWnd* pWnd = CWnd::FromHandle(hWndSecondInstance);
			if (id == ID_MENU_LOCATEEDIT) {
				SendMessage(hWndSecondInstance, WM_START_INSTANCE, (WPARAM)id, 0);
				return false;
			}
		}
		// Do not allow third instance start. Check at the end to allow start
		// subinfo left or right if both of them haven't run
		if (instance == 2) {
			// Write log file: Input error
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, DBLE_MULTIINSTANCE_ERROR, "", "");
			return false;
		}

	}

	// Create logger
	p_Logger = CBLE_Logger::GetInstance();

	// Get system information
	int numberProc = 0;
	SYSTEM_INFO systemInfo;
	GetSystemInfo(&systemInfo);
	numberProc = systemInfo.dwNumberOfProcessors;

	// Get computer speed
	m_Speed = atof(ProcSpeedRead()) * numberProc;

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("LocateEdit"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CBLE_Doc),
		RUNTIME_CLASS(CBLE_FrameWnd),       // main SDI frame window
		RUNTIME_CLASS(CBLE_View));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	
	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// Get command line arguments to call corresponding window
	int id = GetID();
	CBLE_FrameWnd *frame = (CBLE_FrameWnd*)m_pMainWnd;
	if (id == ID_MENU_SUBINFO_L || id == ID_MENU_SUBINFO_R || id == ID_MENU_SUBINFO) {
		// Get Subinfo position
		if (!CBLE_Util::GetWindowPlace(frame, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_SUBINFO)) {
			// Set initial subinfo position
			// int width = GetSystemMetrics(SM_CXFULLSCREEN);
			int height = GetSystemMetrics(SM_CYFULLSCREEN);	
			frame->SetWindowPos(&CWnd::wndTop, 0, height - DBLE_MAINWND_SIZEY_SUBINFO, DBLE_MAINWND_SIZEX_SUBINFO * 2 , DBLE_MAINWND_SIZEY_SUBINFO, SWP_SHOWWINDOW);
		}
	} else {
		// Get Editmode position
		if (!CBLE_Util::GetWindowPlace(frame, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_EDIT)) {
			// Set initial edit mode position
			frame->SetWindowPos(&CWnd::wndTop,	0, 0, DBLE_MAINWND_SIZEX, DBLE_MAINWND_SIZEY, SWP_SHOWWINDOW);
		}
	}
	if (id == ID_MENU_SUBINFO) { //start both subinfo left and right
		frame->OnStartSubWnd(ID_MENU_SUBINFO_L);
		frame->OnStartSubWnd(ID_MENU_SUBINFO_R);
	} else {
		frame->OnStartSubWnd(id);
	}
	// The one and only window has been initialized, so show and update it.
	//m_pMainWnd->ShowWindow(SW_MAXIMIZE);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}

CBLEApp::~CBLEApp()
{
	delete p_Logger;
}

int CBLEApp::AppInstanceExists()
{
	int result = 0;
	// Create a global mutex. Use a unique name, for example 
	//incorporating your company and application name.
	g_hFirstMutexAppRunning = CreateMutex( NULL, FALSE, "First BLE.EXE");
	// Check if the mutex object already exists, indicating an
	// existing application instance
	if (( g_hFirstMutexAppRunning != NULL ) && ( GetLastError() == ERROR_ALREADY_EXISTS))
	{
		// Close the mutex for this application instance. This assumes
		// the application will inform the user that it is about to terminate
		result = 1;
		g_hSecondMutexAppRunning = CreateMutex( NULL, FALSE, "Second BLE.EXE");
		if (( g_hSecondMutexAppRunning != NULL ) && ( GetLastError() == ERROR_ALREADY_EXISTS))
		{
			CloseHandle(g_hSecondMutexAppRunning);
			g_hSecondMutexAppRunning = NULL;
			result = 2;
			//result = true;
		}
      CloseHandle(g_hFirstMutexAppRunning);
      g_hFirstMutexAppRunning = NULL;
   }

   // Return False if a new mutex was created, as this means it's the first app instance
   return result;
}

int CBLEApp::CBTMessageBox(HWND hwnd, CString lpText, UINT uType, int language)
{
	appLanguage = language;
	hhk = SetWindowsHookEx(WH_CBT, &CBTProc, 0, GetCurrentThreadId());
	return AfxMessageBox(/*hwnd, */lpText, /*_T("�x��!"), */uType); // Fig bugs: Must close message box before do anything else
}

LRESULT CALLBACK CBLEApp::CBTProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	HWND  hParentWnd, hChildWnd;    // msgbox is "child"
	CRect  rParent, rChild, rDesktop;
	CPoint pCenter, pStart;
	int   nWidth, nHeight;
 
	// notification that a window is about to be activated
	// window handle is wParam
	if (nCode == HCBT_ACTIVATE)
	{
		// set window handles
		hParentWnd = GetForegroundWindow();
		hChildWnd  = (HWND)wParam;
 
		if((hParentWnd != 0) && (hChildWnd != 0) && (GetWindowRect(GetDesktopWindow(), &rDesktop) != 0) &&
			(GetWindowRect(hParentWnd, &rParent) != 0) && (GetWindowRect(hChildWnd, &rChild) != 0)) {
			// calculate message box dimensions
			nWidth  = (rChild.right - rChild.left);
			nHeight = (rChild.bottom - rChild.top);
 
			// calculate parent window center point
			pCenter.x = rParent.left+((rParent.right - rParent.left)/2);
			pCenter.y = rParent.top+((rParent.bottom - rParent.top)/2);
 
			// calculate message box starting point
			pStart.x = (pCenter.x - (nWidth/2));
			pStart.y = (pCenter.y - (nHeight/2));
    
			// adjust if message box is off desktop
			if(pStart.x < 0) {
				pStart.x = 0;
			}
			if(pStart.y < 0) {
				pStart.y = 0;
			}
			if(pStart.x + nWidth > rDesktop.right) {
				pStart.x = rDesktop.right - nWidth;
			}
			if(pStart.y + nHeight > rDesktop.bottom) {
				pStart.y = rDesktop.bottom - nHeight;
			}

			UINT result; // result of set dialog item, used to debug
			// Change language
			if (GetDlgItem(hChildWnd,IDYES)!=NULL) {
				if (appLanguage == 0) {
					result= SetDlgItemText(hChildWnd, IDYES, "�͂�");
				} else {
					result= SetDlgItemText(hChildWnd, IDYES, "Yes");
				}
			}
			if (GetDlgItem(hChildWnd,IDNO)!=NULL) {
				if (appLanguage == 0) {
					result= SetDlgItemText(hChildWnd, IDNO, "������");
				} else {
					result= SetDlgItemText(hChildWnd, IDNO, "No");
				}
			}
			if (GetDlgItem(hChildWnd,IDOK)!=NULL) {
				result= SetDlgItemText(hChildWnd, IDOK, "OK");
			}
			if (GetDlgItem(hChildWnd,IDCANCEL)!=NULL) {
				if (appLanguage == 0) {
					result= SetDlgItemText(hChildWnd, IDCANCEL, "�L�����Z��");
				} else {
					result= SetDlgItemText(hChildWnd, IDCANCEL, "Cancel");
				}
			}
			
			// move message box
			MoveWindow(hChildWnd, pStart.x, pStart.y, nWidth, nHeight, FALSE);
		}
		// exit CBT hook
		UnhookWindowsHookEx(hhk);
	}
	// otherwise, continue with any possible chained hooks
	else CallNextHookEx(hhk, nCode, wParam, lParam);

	return 0;
}

// This function will be used to read speed of PC
CString CBLEApp::ProcSpeedRead()
{
	CString sMHz;
	char Buffer[_MAX_PATH];
	DWORD BufSize = _MAX_PATH;
	DWORD dwMHz = _MAX_PATH;
	HKEY hKey;

	// open the key where the proc speed is hidden:
	long lError = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
							"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
							0,
							KEY_READ,
							&hKey);
    
	if(lError != ERROR_SUCCESS) {// if the key is not found, tell the user why:
		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, lError, 0, Buffer, _MAX_PATH, 0);
		return "N/A";
	}

	// query the key:
	RegQueryValueEx(hKey, "~MHz", NULL, NULL, (LPBYTE) &dwMHz, &BufSize);

	// convert the DWORD to a CString:
	sMHz.Format("%i", dwMHz);

	return sMHz;
}

UINT CBLEApp::GetID()
{
	//Get position of SubInfo in arguments
	char* pSubInfo = strstr(m_lpCmdLine, "SubInfo"); 
	int subInfoIndex = pSubInfo - m_lpCmdLine + 1;

	if (subInfoIndex == SUBINFO_POS) {
		//Get position of 
		char* pRightSide = strstr(m_lpCmdLine, "R");
		char* pLeftSide = strstr(m_lpCmdLine, "L");
		char* pBothSide = strstr(m_lpCmdLine, "LR");
		int rightSideIndex = pRightSide - m_lpCmdLine + 1;
		int leftSideIndex = pLeftSide - m_lpCmdLine + 1;
		int bothSideIndex = pBothSide - m_lpCmdLine + 1;

		// Check parameter
		if (bothSideIndex == RIGHTSIDE_POS) { //because righ index = both left and right index
			return ID_MENU_SUBINFO;
		} else if (rightSideIndex == RIGHTSIDE_POS || leftSideIndex == RIGHTSIDE_POS) { // check second parameters
			if (rightSideIndex == LEFTSIDE_POS || leftSideIndex == LEFTSIDE_POS) {
				return ID_MENU_SUBINFO; // allow -L -R or -R -L
			} else if (rightSideIndex == RIGHTSIDE_POS){
				return ID_MENU_SUBINFO_R;
			} else {
				return ID_MENU_SUBINFO_L;
			}
		} else { // default is start left
			return ID_MENU_SUBINFO_L;
		}
	}
	return ID_MENU_LOCATEEDIT;
}
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CBLEApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}
/////////////////////////////////////////////////////////////////////////////
// CBLEApp message handlers


// BLE.h : main header file for the BLE application
//

#if !defined(AFX_BLE_H__9C0DCD9E_CF68_472C_801C_9C02EBD68144__INCLUDED_)
#define AFX_BLE_H__9C0DCD9E_CF68_472C_801C_9C02EBD68144__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "CBLE_Logger.h"

/////////////////////////////////////////////////////////////////////////////
// CBLEApp:
// See BLE.cpp for the implementation of this class
//

class CBLEApp : public CWinApp
{
public:
	CBLEApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBLEApp)
	public:
	virtual BOOL InitInstance();
	virtual ~CBLEApp();
	//}}AFX_VIRTUAL
public:
		CBLE_Logger* p_Logger;
		double m_Speed;
		CString ProcSpeedRead();
		int AppInstanceExists();
		int CBTMessageBox(HWND hwnd, CString lpText, UINT uType, int language);
		static LRESULT CALLBACK CBTProc(int code, WPARAM wParam, LPARAM lParam);

		UINT GetID();
// Implementation
	//{{AFX_MSG(CBLEApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CBLEApp theApp;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BLE_H__9C0DCD9E_CF68_472C_801C_9C02EBD68144__INCLUDED_)

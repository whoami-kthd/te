///////////////////////////////////////////////////////////
//  CBLE_CareTaker.cpp
//  Header of the Class CBLE_CareTaker
//  Created on: 2013-11-01
//  Original author: DucDT
///////////////////////////////////////////////////////////
#pragma once
#include "stdafx.h"
#include "..\\BLE.h"
#include "swatch.h"
#include "CBLE_Memento.h"

class CBLE_CareTaker
{
private:
	static CBLE_CareTaker *m_CareTaker;
	vector<CBLE_Memento> m_vMemento;
public:
	//static int m_DialogID;
public:
	~CBLE_CareTaker();
	static CBLE_CareTaker* CreateInstance();
	CBLE_Memento GetMemento();
	void SetMemento(CBLE_Memento);
	void ResetStore(int kind = 0);
	bool Restoreable();
	int GetLastKind();
	void DeleteLastItem();
private:
	CBLE_CareTaker();
	void DeleteItem(int index);
};
#if !defined(AFX_CBLE_COMMONWND_H__D4A7B381_A3B5_4FC5_B689_2B4DCD511DD3__INCLUDED_)
#define AFX_CBLE_COMMONWND_H__D4A7B381_A3B5_4FC5_B689_2B4DCD511DD3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_GridCtrl.h"
#include "CBLE_ProgressBar.h"

// CBLE_CommonWnd.h : header file
//


/////////////////////////////////////////////////////////////////////////////
// CBLE_CommonWnd dialog

class CBLE_CommonWnd : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CBLE_GridCtrl* m_GridCtrl;
	int m_nShape;
	int m_lastShape;										// to check if shape be changed (check when press Check&Reflect)
	int m_autoToolChange;
	int m_colletteNo;
	int m_ejectorNo;

// Construction
public:
	CBLE_CommonWnd(CWnd* pParent = NULL);					// standard constructor
	CWnd* GetEditWnd();

	enum { IDD = IDD_COM_SETTING_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);		// DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();

	// For undo function
	virtual BOOL PreTranslateMessage(MSG* pMsg);

// Implementation
public:
	void SetDocument(CBLE_Doc* pDoc);
	virtual ~CBLE_CommonWnd();
	void UpdateView();
	void ChangeLanguage();

	// For undo function
	void RestoreState();

	void UpdateGrid(int row, int col, CString val, CString oldVal);
	void UpdateCommonSetting();

	afx_msg void OnChangeShape();
	afx_msg void OnCheckBtn();
	afx_msg LRESULT OnUpdateGrid(WPARAM wParam, LPARAM lParam); // Response when press a key
	afx_msg virtual void OnLButtonDown(UINT nFlags, CPoint point); // using mouse click event to determine if info or common window is active
	DECLARE_MESSAGE_MAP()	

private:
	void InitGridCtrl();
	void AddGridData();
	void ResetGridCtrl(bool hasToResetHeaderStatus);
	bool CheckInputValue(int row, int col);					 // Check if input value is out of range
	void AutoFillICSize(int rol, int col);
};

#endif // !defined(AFX_CBLE_COMMONWND_H__D4A7B381_A3B5_4FC5_B689_2B4DCD511DD3__INCLUDED_)

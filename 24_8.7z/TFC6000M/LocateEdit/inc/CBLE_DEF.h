///////////////////////////////////////////////////////////
//  CBLE_DEF.h
//  Created on:      16-Thg7-2013 9:45:24 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_E551C81A_F440_4505_9678_EEB99AD6DF05__INCLUDED_)
#define EA_E551C81A_F440_4505_9678_EEB99AD6DF05__INCLUDED_

#pragma once

#include "stdafx.h"
#include "pos.h"

//#include <list>
//#include <set>
//#include <map>
#include <vector>
using namespace std;

// Define PI constant
#define PI 3.141592653589793

#define ARRAY_LENGTH(_array) (sizeof(_array)/sizeof(_array[0]))

#define DEG_TO_RAD(_deg) (_deg * PI / 180)

#define RAD_TO_DEG(_rad) (_rad * 180 / PI)

#define NUMBER_ZOOM_MAX 20
#define NUMBER_SHAPE_MAX 20

#define EDIT_INI_NAME					"EditMode.ini"
#define SUBINFO_INI_NAME				"SubInfo.ini"
#define	FCB_INIT_FILE_PATH				"C:\\fcb-tfc6000\\DATA\\FCB.INI"
#define	FCB_PD300_FILE_PATH				"C:\\fcb-tfc6000\\DATA\\pd_���Y�Ǘ��ް�.300"
#define BUF_SIZE						(450000 + 1) * 4 
#define LOAD_SIZE						(450000 + 1) * 4 * 4 
#define MANUAL_LOAD_SIZE				(450000 + 1) * 4 * 2 
#define LOADMAP_SIZE					(450000 + 1) * 4 *2
// Global name for shared memory
#define GLOBAL_NAME_L					"Global\\MyFileMappingObjectL"
#define GLOBAL_NAME_R					"Global\\MyFileMappingObjectR"
#define GLOBAL_NAME_LOAD_L				"Global\\MyLoadObjectL"
#define GLOBAL_NAME_LOAD_R				"Global\\MyLoadObjectR"
#define GLOBAL_NAME_MANUAL_LOADBOND_L	"Global\\MyManualLoadBondObjectL"
#define GLOBAL_NAME_MANUAL_LOADBOND_R	"Global\\MyManualLoadbondObjectR"
#define GLOBAL_NAME_MANUAL_LOADDETECT_L	"Global\\MyManualLoadDetectObjectL"
#define GLOBAL_NAME_MANUAL_LOADDETECT_R	"Global\\MyManualLoadDetectObjectR"

#define GLOBAL_NAME_LOADMAP_L			"Global\\MyLoadMapDataL"
#define GLOBAL_NAME_LOADMAP_R			"Global\\MyLoadMapDataR"

// SubInfo 
#define DBLE_SUBINFO_ASK					10000
#define DBLE_SUBINFO_BOND_MODE				10001
#define DBLE_SUBINFO_DETECT_MODE			10002

// Frame name
#define DBLE_FRAMENAME_EDITMODE			_T("Locate Edit - Edit Mode")
#define DBLE_FRAMENAME_SUBINFOMODE		_T("Locate Edit - SubInfo Mode")
#define TFC_FRAMENAME					_T("TFC")
// SubInfo:Status Memory
#define INFO_STATUS_EXTENTION			".dat"
// Dialog name
#define DBLE_DIALOGNAME_APPNAME			_T("Locate Edit")
#define DBLE_DIALOGNAME_EDIT			_T("Edit Mode")
#define DBLE_DIALOGNAME_SUBINFO			_T("SubInfo Mode")
#define DBLE_DIALOGNAME_EDITDLG			_T("SubstrEdit")
#define DBLE_DIALOGNAME_ADJDLG			_T("Adjust")
#define DBLE_DIALOGNAME_SUBINFO_DLGL	_T("SubInfo Left")
#define DBLE_DIALOGNAME_SUBINFO_DLGR	_T("SubInfo Right")
// Define constant
#define DBLE_SPEED_IC_RATIO				1.2 // Determine whether display progress bar or not
#define DBLE_LANGUAGE_ITEMS				40 // number of item need to changes language
#define DBLE_LANGUAGE_MENU				6  // number of menu items

// Define message for log file
#define DBLE_LOGFILE_OPERATION			_T("Operation")
#define DBLE_LOGFILE_CHECKREFELCT		_T("Check&Reflect")
#define DBLE_LOGFILE_CURRENTLOAD		_T("CurrentLoad")
#define DBLE_LOGFILE_LOAD				_T("Load")
#define DBLE_LOGFILE_SAVE				_T("Save")
#define DBLE_LOGFILE_COMMON				_T("CommonSetting")
#define DBLE_LOGFILE_LEDIT				_T("LocateEdit")
#define DBLE_LOGFILE_OFFSET				_T("OffsetData")
#define DBLE_LOGFILE_ALLOFFSET			_T("AllOffset")
#define DBLE_LOGFILE_EXPAND				_T("ExpandData")
#define DBLE_LOGFILE_MAPPING			_T("SubstMapping")
#define DBLE_LOGFILE_FORCEOK			_T("ForceOK")
#define DBLE_LOGFILE_SUBINFO			_T("SubstInfo")
#define DBLE_LOGFILE_SUBINFO_DETECT		_T("Detect")
#define DBLE_LOGFILE_SUBINFO_BOND		_T("Bond")
#define DBLE_LOGFILE_SUBINFO_SETSTATUS	_T("SetStatus")
#define DBLE_LOGFILE_COMM_ICTYPE		_T("ICType")
#define DBLE_LOGFILE_COMM_ICSIZE		_T("ICSize")
#define DBLE_LOGFILE_COMM_ICPITCH		_T("ICPitch")
#define DBLE_LOGFILE_COMM_STARTPOS		_T("StartPos")
#define DBLE_LOGFILE_COMM_ICNUMBER		_T("Number")
#define DBLE_LOGFILE_COMM_ANGLE			_T("Angle")
#define DBLE_LOGFILE_COMM_TOOL			_T("Tool")
#define DBLE_LOGFILE_COMM_COLLETTE		_T("Collette")
#define DBLE_LOGFILE_COMM_EJECTER		_T("Ejecter")
#define DBLE_LOGFILE_COMM_SHAPE			_T("Shape")
#define DBLE_LOGFILE_ERROR				_T("Error")
#define DBLE_LOGFILE_CHANGEVALUE		_T("ChangeValue")

///////////////////////////////////////////////////////////////
/////Define key
// Edit mode setting key
#define DBLE_KEY_EDIT_LANGUAGE				"Language(0:Jap 1:Eng)"
#define DBLE_KEY_EDIT_PASSWORD				"��%d�����߽ܰ��"
#define DBLE_KEY_EDIT_REGNOMAX				"RegNoMax"
#define DBLE_KEY_EDIT_ICTYPEMAX				"IcTypeMax"
#define DBLE_KEY_EDIT_ICSIZEMIN				"IcSizeMin"
#define DBLE_KEY_EDIT_ICSIZEMAX				"IcSizeMax"
#define DBLE_KEY_EDIT_BGHEADTOOLMAX			"BgHeadToolMax"
#define DBLE_KEY_EDIT_COLLETTEMAX			"PickupColletteMax"
#define DBLE_KEY_EDIT_EJECTMAX				"WaferEjectMax"
#define DBLE_KEY_EDIT_MAXNUMBERX			"ArrayNumberMaxX"
#define DBLE_KEY_EDIT_MAXNUMBERY			"ArrayNumberMaxY"
#define DBLE_KEY_EDIT_TOTALMAX				"ArrayTotalMax"
#define DBLE_KEY_EDIT_OFFSETMAX				"OffsetValueMax"
#define DBLE_KEY_EDIT_OFFSETMIN				"OffsetValueMin"
#define DBLE_KEY_EDIT_EXPANDMAX				"ExpandValueMax"
#define DBLE_KEY_EDIT_EXPANDMIN				"ExpandValueMin"
#define DBLE_KEY_EDIT_EXPANDTABMAX			"ExpandTableMax"
#define DBLE_KEY_EDIT_ZOOMRATIO				"ZoomRatio"
#define DBLE_KEY_EDIT_SHAPENAME				"ShapeName"
#define DBLE_KEY_EDIT_TIMEOUT				"TimeOut(second)"
#define DBLE_KEY_EDIT_CURRENTOPEN			"CurrentOpenFile"
#define DBLE_KEY_EDIT_CHKREF				"CheckAndReflect(0:Reflect 1:CheckReflect)"
#define DBLE_KEY_EDIT_NEIGHBORLMT			"LimitFindICNeaghBor"

// #DDT140116: For setting color
#define DBLE_KEY_EDIT_COLOR_CURSOR				"Color_Cursor"
#define DBLE_KEY_EDIT_COLOR_FOCUS				"Color_Focus"
#define DBLE_KEY_EDIT_COLOR_VALID				"Color_ValidDisplay"
#define DBLE_KEY_EDIT_COLOR_OVERLAP				"Color_OverlapDisplay"
#define DBLE_KEY_EDIT_COLOR_REGNO				"Color_RegNoUnselectable"
#define DBLE_KEY_EDIT_COLOR_CENTERLINE			"Color_CenterLine"
#define DBLE_KEY_EDIT_COLOR_INDEX				"Color_IndexDisplay"
#define DBLE_KEY_EDIT_COLOR_SHAPE				"Color_Shape"

// SubInfo setting key
#define DBLE_KEY_INFO_LANGUAGE				"Language(0:Jap 1:Eng)"
#define DBLE_KEY_INFO_CLRUNKNOW				"Color_Unknown"
#define DBLE_KEY_INFO_CLRBAD				"Color_Bad"
#define DBLE_KEY_INFO_CLRGOOD				"Color_Good"
#define DBLE_KEY_INFO_CLRNOTDONE			"Color_NotDone"
#define DBLE_KEY_INFO_CLRFAIL				"Color_Fail"
#define DBLE_KEY_INFO_CLRDONE				"Color_Done"
#define DBLE_KEY_INFO_CLRSTACK				"Color_Stack"
#define DBLE_KEY_INFO_CLRDONTNEED			"Color_DontNeed"
#define DBLE_KEY_INFO_DISLEFT				"DisplayModeLeft(0:Detect 1:Bond 2:Stack)"
#define DBLE_KEY_INFO_DISRIGHT				"DisplayModeRight(0:Detect 1:Bond 2:Stack)"
#define DBLE_KEY_INFO_TIMEOUT				"TimeOut(second)"
#define DBLE_KEY_INFO_DESTPATH				"DestPath"

// dv_.190 file's keys

#define DBLE_KEY_BGSITE_TOOL				"IC���ߖ��c�[���ԍ�"
#define DBLE_KEY_BGSITE_NAME				"BgSite��(%d)"	
#define DBLE_KEY_BGSITE_NUMBERX				"�o�^No(%d) ArrayNumberX"
#define DBLE_KEY_BGSITE_NUMBERY				"�o�^No(%d) ArrayNumberY"
#define DBLE_KEY_BGSITE_ICSIZE				"�o�^No(%d) IcSize"
#define DBLE_KEY_BGSITE_PITCH				"�o�^No(%d) Pitch"
#define DBLE_KEY_BGSITE_STARTPOS			"�o�^No(%d) StartPos"
#define DBLE_KEY_BGSITE_ICTYPE				"�e�o�^No.��IC�i��"
#define DBLE_KEY_SUBTSHAPE					"SubstrateShape"
#define DBLE_KEY_OFFSET_XY					"BgLocateOffsetXY Reg%d_row%03d_col%03d-%d"
#define DBLE_KEY_OFFSET_T					"BgLocateOffsetT Reg%d_row%03d_col%03d-%d"
#define DBLE_KEY_VALID						"BgLocateValid Reg%d_row%03d_col%03d-%d"

// dv_.290 file's keys

#define DBLE_KEY_MAPP_BCREAD				"BCRead"
#define DBLE_KEY_MAPP_REFND					"REFND"
#define DBLE_KEY_MAPP_FNLOC					"FNLOC"
#define DBLE_KEY_MAPP_RPSEL					"RPSEL"
#define DBLE_KEY_MAPP_REFPX					"REFPX"
#define DBLE_KEY_MAPP_REFPY					"REFPY"
#define DBLE_KEY_MAPP_PRDCT					"PRDCT"
#define DBLE_KEY_MAPP_MLCL					"MLCL"
#define DBLE_KEY_MAPP_FID					"FID"
#define DBLE_KEY_MAPP_DUTMS					"DUTMS"
#define DBLE_KEY_MAPP_BCEQU					"BCEQU"
#define DBLE_KEY_MAPP_NULBC					"NULBC"
#define DBLE_KEY_MAPP_BCPAS					"BCPAS"
#define DBLE_KEY_MAPP_BCBND					"BCBND"

// dv_.390 file's keys

#define DBLE_KEY_ICANGLE					"�o�^No(%d) IC��ڰ����� ��ڰ����ߊp�x"					
#define DBLE_KEY_ICEJECTOR					"IC�i��(%d) IC��ڰ����� IcType to Ejector No"
#define DBLE_KEY_ICCOLLETTE					"IC�i��(%d) IC��ڰ����� IcType to Collette No"

// Status read/write key

#define DBLE_KEY_STATUSRW_BOND				"BondStatus Reg%d_row%03d_col%03d-%d"
#define DBLE_KEY_STATUSRW_DETECT			"DetectStatus Reg%d_row%03d_col%03d-%d"

// Section's keys

// EditMode.ini file's sections

#define DBLE_SECTION_EDIT_CONFIG			"ConfigurationData"
#define DBLE_SECTION_EDIT_PRODUCT			"ProductData"
#define DBLE_SECTION_EDIT_COLOR				"SettingColor"

// SubInfo.ini file's sections
#define DBLE_SECTION_INFO_CONFIG			"ConfigurationData"
#define DBLE_SECTION_INFO_DESTPATH			"SubstMapData"

// dv_.190 file's sections

#define DBLE_SECTION_EDIT_REGNO				"BgLocateICLocation"
#define DBLE_SECTION_EDIT_OFFSET_XY			"BgLocateOffsetXY"
#define DBLE_SECTION_EDIT_OFFSET_T			"BgLocateOffsetT"
#define DBLE_SECTION_EDIT_ICVALID			"BgLocateValid"	
#define DBLE_SECTION_EDIT_TOOL_L			"FC����� �i���ް�(����ިݸ��Ư�):°ٌ����ް�_L"
#define DBLE_SECTION_EDIT_TOOL_R			"FC����� �i���ް�(����ިݸ��Ư�):°ٌ����ް�_R"

// dv_.290 file's sections

#define DBLE_SECTION_EDIT_MAPP				"MappingData"

// dv_.390 file's sections

#define DBLE_SECTION_EDIT_ACE_L				"FC����� �i���ް�(IC�����Ư�):�߯������Ư��ް�_L"
#define DBLE_SECTION_EDIT_ACE_R				"FC����� �i���ް�(IC�����Ư�):�߯������Ư��ް�_R"

// StatusRW's sections
#define DBLE_SECTION_STATUSRW_BOND			"BondStatus"	
#define DBLE_SECTION_STATUSRW_DETECT		"DetectStatus"

// #DDT(20140624) Add LoadMap function
#define DBLE_LOADMAP_BARCODE_FILEPATH		"C:\\fcb-tfc6000\\DATA\\pd_���Y�Ǘ��ް�.100"
#define DBLE_LOADMAP_BARCODE_SECTION_L		"FC����� ���Y�Ǘ��ް�(����ިݸ��Ư�)_L:�}�b�s���O�f�[�^"
#define DBLE_LOADMAP_BARCODE_SECTION_R		"FC����� ���Y�Ǘ��ް�(����ިݸ��Ư�)_R:�}�b�s���O�f�[�^"
#define DBLE_LOADMAP_DATAPATH				"D:\\MapData\\SmMap\\SmSubstMap\\"
#define DBLE_LOADMAP_SECTION				"Map Data Type 2"
/////////////////////////////////////////////////////////////////////////////

// Define max size for dialog items
#define DBLE_MAX_DLGITEM_SIZE				100

// Message
#define STR_BLE_CTRL					"BLE_CTRL"
#define STR_TFC_CTRL					"TFC_CTRL"

static UINT BLE_CTRL		= RegisterWindowMessage(STR_BLE_CTRL);
//#define WM_AUTORUN_MES				"WM_AUTORUN"
//#define WM_AUTORUN_ANS_MES			"WM_AUTORUN_ANS"
// Enum for message ID to communicate with TFC
enum {														// wParam
	BLE_INIT	= 0,	// Initialize
	BLE_DISP	= 1,	// Display							0: erase  1: display
	BLE_FILE	= 2,	// Load file
	BLE_MOVE	= 3,	// notify current position
	BLE_BOND	= 4,	// Notify bond status
	BLE_OK_L	= 5,	// Not in autorun for left side
	BLE_NG_L	= 6,	// In autorun for left side
	BLE_OK_R	= 7,	// Not in autorun for right side
	BLE_NG_R	= 8,	// In autorun for right side

	// Status for left side		(10~30)
	BOND_NDONE_L	= 10,
	BOND_FAIL_L,
	BOND_DONE_L,
	BOND_STACK_L,
	BOND_SKIP_L,
	BOND_REVERSE_L,
	DET_UNKN_L,
	DET_BAD_L,
	DET_GOOD_L,

	// Status for right side	(30~50)
	BOND_NDONE_R	= 30,
	BOND_FAIL_R,
	BOND_DONE_R,
	BOND_STACK_R,
	BOND_SKIP_R,
	BOND_REVERSE_R,
	DET_UNKN_R,
	DET_BAD_R,
	DET_GOOD_R,
	
	// All status				(50~70)		
	SET_SUBST_L		= 50,
	SET_SUBST_R,
	DETECT_ALL_BAD_L,
	DETECT_ALL_BAD_R,
	DETECT_ALL_GOOD_L,
	DETECT_ALL_GOOD_R,
	BOND_ALL_DONE_L,
	BOND_ALL_DONE_R,
	BOND_ALL_DONTNEED_L,
	BOND_ALL_DONTNEED_R,
	BOND_ALL_REVERSE_L,
	BOND_ALL_REVERSE_R,
	BOND_ALL_LEFTDONE_L,
	BOND_ALL_LEFTDONE_R,
	BOND_ALL_RIGHTDONE_L,
	BOND_ALL_RIGHTDONE_R,
	LOADMAP_L,
	LOADMAP_R,

	// Status for stack count	(70~130) 
	// Now maximum stack count is 20
	STACK_COUNT_L	= 70,
	STACK_COUNT_R	= 100,

	// wParam Message with EditMode
	BLE_CAN_SAVE_FILE = 150,// Request message from BLE to TFC
	BLE_SAVE_FILE_DONE,		// Report save done from BLE to TFC

	BLE_SAVE_FILE_OK,		// Reply message from TFC to BLE
	BLE_SAVE_FILE_NG,		// Reply message from TFC to BLE

	BLE_SUBINFO_INIT,		// Request message from BLE-SubInfo to BLE-Edit

	BLE_INIT_SUBINFO_OK,	// Reply message from BLE-Edit to BLE-SubInfo
	BLE_INIT_SUBINFO_NG,	// Reply message from BLE-Edit to BLE-SubInfo

	BLE_SUBINFO_CUROPEN,	// Request message from BLE-SubInfo to BLE-Edit

	BLE_CUROPEN_SUBINFO_OK,	// Reply message from BLE-Edit to BLE-SubInfo
	BLE_CUROPEN_SUBINFO_NG,	// Reply message from BLE-Edit to BLE-SubInfo


	// Reset substrate
	BLE_RESET_L = 160,
	BLE_RESET_R,


	// Load status
	STARTUP_LOAD_L = 170,
	STARTUP_LOAD_R,

	// Notify TFC load status
	USER_LOAD_L = 180,
	USER_LOAD_R,
	OK_LOAD_L,
	OK_LOAD_R,
	NG_LOAD_L,
	NG_LOAD_R,
	OK_LOADMAP_L,
	OK_LOADMAP_R,
	NG_LOADMAP_L,
	NG_LOADMAP_R,

	// Move position
	BLE_MOVED_L = 190,
	BLE_MOVED_R,
	// Frame direction
	BLE_DIR_L = 200	,
	BLE_DIR_R,
	// Index send
	BLE_INDEX_L = 210	,
	BLE_INDEX_R,

	BLE_ERR		= 10000,// for error
};

enum DBLE_ProgressBarType {
	DBLE_PROGRESSBAR_CHCK = 0,
	DBLE_PROGRESSBAR_CHCK_SELECT_ONLY,
	DBLE_PROGRESSBAR_SAVE_DATA,
	DBLE_PROGRESSBAR_OPEN_DATA,
};
enum DBLE_LocateEditMode
{
	DBLE_EDIT_MODE = 0,
	DBLE_SUBINFO_MODE
};

enum DBLE_SUBINFO_TYPE
{
	DBLE_SUBINFO_TYPE_L = 2,
	DBLE_SUBINFO_TYPE_R
};

enum DBLE_USER
{
	DBLE_USER_LEVEL1 = 0,
	DBLE_USER_LEVEL2,
	DBLE_USER_LEVEL3
};

enum DBLE_MODE
{
	DBLE_MODE_LOCATE_EDIT_HIDE_INVALID = 0,
	DBLE_MODE_LOCATE_EDIT_SHOW_INVALID,
	DBLE_MODE_SUB_INFO_DETECT,
	DBLE_MODE_SUB_INFO_BOND,
	DBLE_MODE_SUB_INFO_STACK,
	DBLE_MODE_SUB_INFO_LOAD_MAP,
	DBLE_MODE_LED_STATUS_DISP
};

enum DBLE_SUBSTRATE_SHAPE
{
	DBLE_SHAPE_SQUARE = 0,
	DBLE_SHAPE_ROUND
};

enum DBLE_LANGUAGE
{
	DBLE_LANGUAGE_JAPANESE = 0,
	DBLE_LANGUAGE_ENGLISH
};

/*// This enum will be used to determine which
// type IC is
enum DBLE_IC_TYPE
{
	DBLE_IC_TYPE_1 = 0, // x < 0 and y > 0
	DBLE_IC_TYPE_2,		// x >= 0 and y >= 0
	DBLE_IC_TYPE_3,		// x > 0 and y < 0
	DBLE_IC_TYPE_4		// x < 0 and y < 0
};*/

enum DBLE_BondState
{
	DBLE_BOND_NOTDONE = 200,
	DBLE_BOND_FAIL,
	DBLE_BOND_DONE,
	DBLE_BOND_STACK,
	DBLE_BOND_NONEED
};

enum DBLE_DetectState
{
	DBLE_DETECT_UNKNOWN = 250,
	DBLE_DETECT_BAD,
	DBLE_DETECT_GOOD
};

enum DBLE_AllSetState
{
	DBLE_ALLSET_SUBST = 300,
	DBLE_ALLSET_BAD,
	DBLE_ALLSET_GOOD,
	DBLE_ALLSET_DONE,
	DBLE_ALLSET_DONTNEED,
	// For reverse all bond status
	DBLE_ALLSET_REVERSE,
	// For reverse bond status
	DBLE_BOND_REVERSE,
	// All left done
	DBLE_ALLSET_LEFTDONE,
	// All right done
	DBLE_ALLSET_RIGHTDONE,
};

enum COMMSETTING_COLUMN_NAME
{
	IC_TYPE	= 1,
	IC_SIZE_X,
	IC_SIZE_Y,
	IC_PITCH_X,
	IC_PITCH_Y,
	START_POS_X,
	START_POS_Y,
	NUMBER_X,
	NUMBER_Y,
	ANGLE,
	TOOL_L,
//	TOOL_R,			//#DMV170622 Disable Tool Change
	COLLETTE_L,
//	COLLETTE_R,		//#DMV170622 Disable Tool Change
	EJECTER_L,
//	EJECTER_R,		//#DMV170622 Disable Tool Change
};


struct TBLE_RegIC
{
	int m_RegNo;
	int m_Type;
	double m_SizeX;
	double m_SizeY;
	double m_PitchX;
	double m_PitchY;
	double m_StartPosX;
	double m_StartPosY;
	int m_NumberX;
	int m_NumberY;
	double m_Angle;
	int m_ToolL;
	int m_ToolR;
	int m_ColletteL;
	int m_ColletteR;
	int m_EjectL;
	int m_EjectR;

	bool m_Changed;		// This member is for checking if substrate shape or array number is changed on Common setting table

public:
	TBLE_RegIC()
	{
		m_RegNo = 0;
		m_Type = 0;
		m_SizeX = 0.0;
		m_SizeY = 0.0;
		m_PitchX = 0.0;
		m_PitchY = 0.0;
		m_StartPosX = 0.0;
		m_StartPosY = 0.0;
		m_NumberX = 0;
		m_NumberY = 0;
		m_Angle = 0.0;
		m_ToolL = 1;
		m_ToolR = 1;
		m_ColletteL = 1;
		m_ColletteR = 1;
		m_EjectL = 1;
		m_EjectR = 1;
		m_Changed = true;
	}
};


struct TBLE_StatusColor
{
	COLORREF m_UnknownClr;
	COLORREF m_BadClr;
	COLORREF m_GoodClr;
	COLORREF m_NotDoneClr;
	COLORREF m_FailClr;
	COLORREF m_DoneClr;
	COLORREF m_StackClr;
	COLORREF m_NoNeedClr;
	COLORREF m_Cursor;
	COLORREF m_Focus;
	COLORREF m_ValidDisp;
	COLORREF m_OverlapDisp;
	COLORREF m_Regno;
	COLORREF m_CenterLine;
	COLORREF m_IndexDisp;
	COLORREF m_Shape;

public:
	TBLE_StatusColor()
	{
		m_UnknownClr	=	RGB(255, 0, 255);
		m_BadClr		=	RGB(255, 0, 0);
		m_GoodClr		=	RGB(255, 255, 0);
		m_NotDoneClr	=	RGB(255, 255, 255);
		m_FailClr		=	RGB(255, 255, 255);
		m_DoneClr		=	RGB(50, 205, 50);
		m_StackClr		=	RGB(143, 188, 143);
		m_NoNeedClr		=	RGB(0, 0, 255);
		m_Cursor		=	RGB(10, 255, 10);
		m_ValidDisp		=	RGB(10, 10, 10);
		m_OverlapDisp	=	RGB(255, 0, 10);
		m_Regno			=	RGB(192, 190, 190);
		m_CenterLine	=	RGB(192, 190, 190);
		m_IndexDisp		=	RGB(43, 43, 227);
		m_Shape			=	RGB(180, 10, 10);
		m_Focus			=	RGB(85, 220, 204);
	}
};

struct TBLE_Language
{
	int m_ID;
	CString m_IDName;
	CString m_Name;

public: 
	TBLE_Language() {}
	TBLE_Language (int id, CString idName, CString name) {
		m_ID = id;
		m_IDName = idName;
		m_Name = name;
	}
};

struct TBLE_Init
{
	int m_CheckReflect;
	int m_ArrayNumberMaxX;
	int m_ArrayNumberMaxY;
	int m_ArrayTotalMax;
	int m_BgHeadToolMax;
	int m_PickupColletteMax;
	int m_WaferEjectMax;
	int m_ExpandTableMax;
	R2Pos m_ExpandValueMax;
	R2Pos m_ExpandValueMin;
	R2Pos m_IcSizeMax;
	R2Pos m_IcSizeMin;
	int m_IcTypeMax;
	int m_Language;
	R2Pos m_OffsetValueMax;
	R2Pos m_OffsetValueMin;
	CString m_PassLevel1;
	CString m_PassLevel2;
	CString m_PassLevel3;
	int m_RegNoMax;
	int m_numberOfShape;
	int m_TimeOutEdit;
	int m_TimeOutSubInfo;
	int m_NeighborLimit;
	CString m_ShapeName[NUMBER_SHAPE_MAX];
	int m_numberOfZoom;
	int m_ZoomRatio[NUMBER_ZOOM_MAX];
	CString m_CurrentOpen;
	CString m_DestPath;

public: 
	TBLE_Init() 
	{
		m_CheckReflect = 1;
		m_ArrayNumberMaxX = 0;
		m_ArrayNumberMaxY = 0;
		m_ArrayTotalMax = 0;
		m_BgHeadToolMax = 1;
		m_PickupColletteMax = 0;
		m_WaferEjectMax = 0;
		m_ExpandTableMax = 0;
		m_ExpandValueMax = R2Pos(0.0, 0.0);
		m_ExpandValueMin = R2Pos(0.0, 0.0);
		m_IcSizeMax = R2Pos(0.0, 0.0);
		m_IcSizeMin = R2Pos(0.0, 0.0);
		m_IcTypeMax = 0;
		m_Language = DBLE_LANGUAGE_ENGLISH;
		m_OffsetValueMax = R2Pos(0.0, 0.0);
		m_OffsetValueMin = R2Pos(0.0, 0.0);
		m_PassLevel1 = "";
		m_PassLevel2 = "";
		m_PassLevel3 = "";
		m_RegNoMax = 0;
		m_numberOfShape = 0;
		m_numberOfZoom = 0;
		m_TimeOutEdit = 0;
		m_TimeOutSubInfo = 0;
		m_NeighborLimit = 0;
		int i;
		for (i = 0; i < NUMBER_SHAPE_MAX; i++) {
			m_ShapeName[i] = "";
		}
		for (i = 0; i < NUMBER_ZOOM_MAX; i++) {
			m_ZoomRatio[i] = 0;
		}
		m_CurrentOpen = "";
		m_DestPath = "";
	}

};

struct TBLE_Subs_Shape
{
	DBLE_SUBSTRATE_SHAPE shape;
	int sizeX;
	int sizeY;
};

struct TBLE_Mapping
{
	int m_BCRead;
	int m_RefND;
	int m_OriFlat;
	int m_RefDie;
	int m_RefDieX;
	int m_RefDieY;
	int m_ProcessDie;
	int m_MessLength;
	CString m_FID;
	CString	m_DiePoint;
	CString m_GoodBin;
	CString m_NullBin;
	CString m_PassBin;
	CString m_BondedBin;
	
	
public:
	TBLE_Mapping()
	{
		m_BCRead = 0;
		m_RefND = 0;
		m_OriFlat = 0;
		m_RefDie = 1;
		m_RefDieX = 0;
		m_RefDieY = 0;
		m_ProcessDie = 0;
		m_MessLength = 0;
		m_FID = CString("");
		m_DiePoint = CString("");
		m_GoodBin = CString("");
		m_NullBin = CString("");
		m_BondedBin = CString("");
		m_PassBin = CString("");

	}
};

// SubInfo button index
enum DBLE_SUBINFO_BTN
{
	DBLE_DETECT_UNKNOWN_BTN = 0,
	DBLE_DETECT_BAD_BTN,
	DBLE_DETECT_GOOD_BTN,
	DBLE_BOND_NOTDONE_BTN,
	DBLE_BOND_FAIL_BTN,
	DBLE_BOND_DONE_BTN,
	DBLE_BOND_STACK_BTN,
	DBLE_BOND_DONTNEED_BTN,
	DBLE_BOND_REVERSE_BTN,
	DBLE_ALLSET_SUBST_BTN,
	DBLE_ALLSET_BAD_BTN,
	DBLE_ALLSET_GOOD_BTN,
	DBLE_ALLSET_DONE_BTN,
	DBLE_ALLSET_DONTNEED_BTN,
	DBLE_ALLSET_REVERSE_BTN,
	DBLE_ALLSET_LEFTDONE_BTN,
	DBLE_ALLSET_RIGHTDONE_BTN,
	DBLE_LOADMAP_BTN,
};

// Determine NG message
enum {
	BLE_NG_AUTORUN = 0,
	BLE_NG_STEPRUN,
	BLE_NG_FRAME,
	BLE_NG_SCREEN,
	BLE_NG_NOUSEMAP,
};


enum {
	eLeftMode	= 0,	// left side only mode
	eRightMode	= 1,	// right side only mode
	eLRMode		= 2,	// both left and right side mode
};
#endif // !defined(EA_E551C81A_F440_4505_9678_EEB99AD6DF05__INCLUDED_)



///////////////////////////////////////////////////////////
//  CBLE_ExpandDlg.h
//  Implementation of the Class CBLE_ExpandDlg
//  Created on:      16-Thg7-2013 1:41:03 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_1E7ED0AC_49C8_4b57_813D_31FB7183F060__INCLUDED_)
#define EA_1E7ED0AC_49C8_4b57_813D_31FB7183F060__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_GridCtrl.h"
#include "CBLE_NumKeyWnd.h"
#include "CBLE_ExpandView.h"

struct TBLE_Expand
{
	int Nstart;
	int Nend;
	double dX;
	double dY;
};

// CBLE_ExpandDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_ExpandDlg dialog

class CBLE_ExpandDlg : public CDialog
{

private:
	CBLE_Doc* m_pDoc;
	CBLE_GridCtrl* m_GridCtrl;
	CBLE_NumKeyWnd m_KeyWnd;
	CBLE_ExpandView* m_View;

// Construction
public:
	CBLE_ExpandDlg(CWnd* pParent = NULL);   // standard constructor
	enum { IDD = IDD_EXPAND_DLG };

	virtual ~CBLE_ExpandDlg();
	void SetDocument(CBLE_Doc* pDoc);

	// For undo function
	void OnRestoreState();

// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnClose();
	virtual void OnOK();
	

// Implementation
protected:
	afx_msg LRESULT OnUpdateGrid(WPARAM wParam, LPARAM lParam); // Response when press a key
	afx_msg void OnOffsetExpand();
	DECLARE_MESSAGE_MAP()
	virtual BOOL PreTranslateMessage(MSG* pMsg);
private:
	void InitGridCtrl();
	void AddGridData();
	void GetExpandVector(vector<TBLE_Expand>& vExpand);
	void ValidateData(long row);
	void DrawFrame();
};
#endif // !defined(EA_1E7ED0AC_49C8_4b57_813D_31FB7183F060__INCLUDED_)


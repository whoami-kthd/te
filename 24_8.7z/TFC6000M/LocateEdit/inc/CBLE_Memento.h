///////////////////////////////////////////////////////////
//  CBLE_Memento.h
//  Header of the Class CBLE_Memento and childs
//  Created on: 2013-11-01
//  Original author: DucDT
///////////////////////////////////////////////////////////

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_IC.h"
#define DATA_TYPE 1
#define MAPP_TYPE 2
#define GRID_TYPE 3

/**
* Store: Use to save previous data to restore
*/
class CBLE_Memento : public CObject
{
private:
	// Type of store
	int m_Kind;
	// Internal state
	void *m_pState;
	// Date type
	int m_Type;
public:
	CBLE_Memento();
	CBLE_Memento(int kind, int type);
	~CBLE_Memento();
	CBLE_Memento(const CBLE_Memento& mem);

	void SetState(void *state);
	void* GetState();
	int GetStoreKind();
	int GetType();
	void Clean();
	inline CBLE_Memento operator=(const CBLE_Memento& mem) {
		m_pState = const_cast<CBLE_Memento&>(mem).GetState();
		m_Kind = const_cast<CBLE_Memento&>(mem).GetStoreKind();
		m_Type = const_cast<CBLE_Memento&>(mem).GetType();
		return *this;
	}
	//virtual void FreeMem();

};

/////////////////////////////////////////////////////////////////////////////////////////////
/**
* Inherit class to store data state
*/
class CBLE_DataStore : public CBLE_Memento
{
private:
	//vector<CBLE_IC> *m_vIC;
public:
	CBLE_DataStore();
	~CBLE_DataStore();
	CBLE_DataStore(vector<CBLE_IC*> vIC, int kind, int type, bool all = false, int regNo = 0);

};

/////////////////////////////////////////////////////////////////////////////////////////////
/**
* Inherit class to store grid data state
*/

struct TBLE_GridData
{
	int row;
	int col;
	CString val;
public:
	TBLE_GridData(int r, int c, CString v) 
	{
		row = r;
		col = c;
		val = v;
	}
};

class CBLE_GridStore : public CBLE_Memento
{
private:
	//TBLE_GridData *m_pGrid;
	//vector<TBLE_GridData> *m_vpGrid;
public:
	CBLE_GridStore();
	~CBLE_GridStore();
	CBLE_GridStore(int row, int col, CString val, int kind, int type);
	CBLE_GridStore(vector<TBLE_GridData> *v_Grid, int kind, int type);

};

/////////////////////////////////////////////////////////////////////////////////////////////
/**
* Inherit class to store mapping data state
*/

class CBLE_MapStore : public CBLE_Memento
{
private:
	//TBLE_Mapping m_Mapping;
public:
	CBLE_MapStore();
	~CBLE_MapStore();
	CBLE_MapStore(TBLE_Mapping *mapping, int kind, int type);

};
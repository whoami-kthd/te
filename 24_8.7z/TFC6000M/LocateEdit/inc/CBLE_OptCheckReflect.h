///////////////////////////////////////////////////////////
//  CBLE_OptCheckReflect.h
//  Implementation of the Class CBLE_OptCheckReflect
///////////////////////////////////////////////////////////

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_FullKeyWnd.h"
#include "CBLE_SubInfoDispDlg.h"
#include "CBLE_EditCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CBLE_OptCheckReflect dialog

class CBLE_OptCheckReflect : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CBLE_FullKeyWnd m_KeyWnd;
	// Edit box
	CBLE_EditCtrl m_Edit;

	TBLE_StatusColor m_DispColor; // Option change color

	int m_Check; // 1 is check and reflect, 0 is reflect only

// Construction
public:
	//CBLE_Doc* m_pDoc;
	CBLE_OptCheckReflect(CWnd* pParent = NULL);   // standard constructor
	enum { IDD = IDD_OPTION_CHECKREFLECT };
	
// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();

// Implementation
public:
	void InitView();
	void SetDocument(CBLE_Doc* pDoc);
	virtual ~CBLE_OptCheckReflect();

	afx_msg virtual void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnCheckReflect(); // Select check and reflect
	afx_msg void OnReflectOnly(); // Select reflect only
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
};


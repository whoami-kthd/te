#if !defined(AFX_CBLE_PASSWORDWND_H__FB24119A_D300_4BF3_9F38_EC914907CFB1__INCLUDED_)
#define AFX_CBLE_PASSWORDWND_H__FB24119A_D300_4BF3_9F38_EC914907CFB1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CBLE_PassWordWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_PassWordWnd dialog

#include "CBLE_Doc.h"
#include "CBLE_NumKeyWnd.h"

// CBLE_PassWordWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_PassWordWnd dialog

class CBLE_PassWordWnd : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CBLE_NumKeyWnd m_KeyWnd;

// Construction
public:
	CBLE_PassWordWnd(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_PassWordWnd();
	enum { IDD = IDD_PASSWORD_DLG };

	virtual BOOL OnInitDialog();

	void SetDocument(CBLE_Doc* pDoc);
	void InitView();
	void DisplayPasswordLevel();
	void DisplayWarningMessage();
	void PressNumKey(CString& text, UINT key, bool isInteger);
	void ChangeLanguage();


// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support


// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBLE_PassWordWnd)
	afx_msg void OnPasswordCancel();
	afx_msg void OnPasswordChangepassword();
	afx_msg void OnPasswordLeveldown();
	afx_msg LRESULT OnPressKey(WPARAM wParam, LPARAM lParam); // Response when press a key
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CBLE_PASSWORDWND_H__FB24119A_D300_4BF3_9F38_EC914907CFB1__INCLUDED_)

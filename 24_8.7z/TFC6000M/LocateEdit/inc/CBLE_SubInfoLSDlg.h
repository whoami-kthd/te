///////////////////////////////////////////////////////////
//  CBLE_SubInfoLSDlg.h
//  Implementation of the Class CBLE_SubInfoLSDlg
//  Created on:      15-8-2013 14:11:08
//  Original author: tiennv
///////////////////////////////////////////////////////////
#pragma once

#include "CBLE_DEF.h"
#include "CDialog.h"
#include "CBLE_Doc.h"
#include "CBLE_IC.h"

class CBLE_SubInfoLSDlg : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	int m_BondDetectMode;									// 0: Bond, 1: Detect
	DBLE_SUBINFO_TYPE m_nMode;								// Left right mode
	CWnd *m_pParentWnd;
	HANDLE m_ManualLoadBondHandle[2];
	HANDLE m_ManualLoadDetectHandle[2];
	CWinThread*		m_pLoadStatusThread;

	HANDLE m_hMapFileBond, m_hMapFileDetect;								// Handle for share memory load status
	int* m_pBufBond, *m_pBufDetect;											// Buffer to write to share memory

public:
	enum { IDD = IDD_SUBINFO_TABDLG };
public:
	CBLE_SubInfoLSDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_SubInfoLSDlg();
	void InitView();
	void SetDocument(CBLE_Doc* pDoc);
	CBLE_Doc* GetDocument();
	void SetStatusMode(int mode);
	void SetLRMode(DBLE_SUBINFO_TYPE mode);
	virtual void OnCancel();
	void SetParentWindow(CWnd *parent);
	void LoadStatus();
	void ProcessAns(int wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnLoadStatus();
	afx_msg void OnSaveStatus();
	
private:
	void SetLabel(CString label);
};

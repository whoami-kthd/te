///////////////////////////////////////////////////////////
//  CBLE_SubInfoWnd.h
//  Implementation of the Class CBLE_SubInfoWnd
//  Created on:      15-8-2013 14:11:08
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_2F1A404C_5863_43c7_9C9C_4EC3424D274A__INCLUDED_)
#define EA_2F1A404C_5863_43c7_9C9C_4EC3424D274A__INCLUDED_
#pragma once

#include "CBLE_LayoutWnd.h"
#include "CBLE_DEF.h"
#include "CDialog.h"
#include "CBLE_Doc.h"
#include "CBLE_InfoWnd.h"
#include "CBLE_SubInfoDispDlg.h"
#include "CBLE_SubInfoLSDlg.h"

#define DBLE_SUBINFO_BTN_NO 18

static UINT WM_TFC_CTRL  = RegisterWindowMessage(STR_TFC_CTRL);


class CBLE_SubInfoWnd : public CDialog
{
private:
	CBLE_LayoutWnd* m_LayoutWnd;
	CBLE_Doc* m_pDoc;
	CBLE_InfoWnd m_InfoWnd;
	int m_nZoom;
	int m_nRegNo;
	DBLE_SUBINFO_TYPE m_nMode;							// Left right mode
	int m_StatusToSet;
	HANDLE m_hMapFile;									// Handle for share memory
	int* m_pBuf;										// Buffer to write to share memory

	HANDLE m_hMapLoadFile;								// Handle for share memory
	int *m_pBufLoad;									// Buffer to write to share memory

	int m_MovedIndex;									// Index of Moved IC

	HANDLE m_Handle[2];									// handle for set status
	HANDLE m_StartLoadHandle;							// handle for load status 
	
	CWinThread*		m_pSetStatusThread;
	CWinThread*		m_pLoadStatusThread;
	CWinThread*		m_pLoadMapThread;
	int m_ButtonID;
	int m_Count[DBLE_SUBINFO_BTN_NO];
	int m_DisplayMode;									// Display mode

	bool m_bInit;
	vector<CBLE_IC> m_vIC;								// For map data loading
	CString m_Barcode;
	HANDLE m_hLoadMapData;
	int *m_pBufLoadMapData;
	HANDLE m_LoadMapHandle[2];	
	CStatic m_FrmDirLR[2];

public:
	CBLE_SubInfoWnd(CWnd* pParent = NULL);				// standard constructor
	virtual ~CBLE_SubInfoWnd();
	void InitView();
	void SetDocument(CBLE_Doc* pDoc);
	CBLE_Doc* GetDocument();
	void SetMode(DBLE_SUBINFO_TYPE mode);
	void SetStatusThread(UINT nID);
	void LoadStatusThread();
	void SetStatus(int wParam, LPARAM lParam);
	void LoadStatus(int wParam, LPARAM lParam);
	void UpdateSubInfo();
	int GetButtonID();
	DBLE_MODE GetDisplayMode();
	void OnChangeColor(UINT nID, COLORREF color);
	void SetFrameDirection(int dir);

	void SetMapDataThread();
	CString GetInfoTopLeftSelIC(); //#TIENBV20151125 
	// Combobox
	afx_msg void OnChangeRegNo();
	afx_msg void OnChangeZoom();
	// Button
	afx_msg void OnZoomButton(UINT nID);
	afx_msg void OnRegNoButton(UINT nID);
	afx_msg void OnSetStatus(UINT nID);
	afx_msg void OnChangeDisplayMode(UINT nID);
	// Load map file
	afx_msg void OnLoadMap();
	
	//afx_msg void OnPaint();
	//afx_msg virtual void OnLButtonDown(UINT nFlags, CPoint point); // using mouse click event to change color
	afx_msg LRESULT OnChangeSelectIC(WPARAM wParam,LPARAM lParam);	// Update the selected ICs
	afx_msg LRESULT OnDisplayFocusIC(WPARAM wParam,LPARAM lParam); // Display focus IC in real-time display mode
	afx_msg LRESULT OnUpdateZoom(WPARAM wParam, LPARAM lParam);		// Update zoom
	afx_msg LRESULT OnUpdateView(WPARAM wParam, LPARAM lParam); // Update view when a child window is changed
	afx_msg void OnTcnSelchangeTabcontrol(NMHDR *pNMHDR, LRESULT *pResult);	// change select on tabctrl
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) ;
	DECLARE_MESSAGE_MAP()

// Construction
public:
	enum { IDD = IDD_SUBINFO_DLG };

	CTabCtrl m_TabCtrl;
	CBLE_SubInfoDispDlg m_DisplayDlg;
	CBLE_SubInfoLSDlg m_BondLS;
	CBLE_SubInfoLSDlg m_DetectLS;

	
// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	
	virtual void OnCancel();
	virtual void OnOK();
	
private:
	//int CalIndex(CBLE_IC *ic);
	void CheckBtnState();

	static UINT OnSetStatusThread(LPVOID pParam);
	static UINT OnLoadStatusThread(LPVOID pParam);
	static UINT	OnSetMapDataStatusThread(LPVOID pParam);

};

#endif
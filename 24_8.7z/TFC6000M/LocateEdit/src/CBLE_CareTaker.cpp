///////////////////////////////////////////////////////////
//  CBLE_CareTaker.cpp
//  Implementation of the Class CBLE_CareTaker
//  Created on: 2013-11-01
//  Original author: DucDT
///////////////////////////////////////////////////////////

#include "CBLE_CareTaker.h"
#define NUMBER_RESTORE_MAX 3

CBLE_CareTaker* CBLE_CareTaker::m_CareTaker;
//int CBLE_CareTaker::m_DialogID;

/**
* Constructor
*/
CBLE_CareTaker::CBLE_CareTaker()
{
	// Default constructor
}

/**
* Destructor
*/
CBLE_CareTaker::~CBLE_CareTaker()
{
	ResetStore();
}

/**
* Get instance of store manage class
*/
CBLE_CareTaker* CBLE_CareTaker::CreateInstance()
{
	if (m_CareTaker == NULL) {
		m_CareTaker = new CBLE_CareTaker();
	}
	return m_CareTaker;
}

/**
* Put new store to buffer
*/
void CBLE_CareTaker::SetMemento(CBLE_Memento memento)
{
	if (m_vMemento.size() >= NUMBER_RESTORE_MAX)
	{
		DeleteItem(0);
	}
	m_vMemento.push_back(memento);
}

/**
* Get last store
*/
CBLE_Memento CBLE_CareTaker::GetMemento()
{	
	CBLE_Memento mem = m_vMemento[m_vMemento.size() - 1];
	m_vMemento.pop_back();
	return mem;
}

/** 
* Check have any store in buffer
*/
bool CBLE_CareTaker::Restoreable()
{
	return (m_vMemento.size() == 0) ? false : true;
}

/**
* Reset buffer: Delete all store
*/
void CBLE_CareTaker::ResetStore(int kind)
{
	int length = m_vMemento.size();

	if (kind == 0) {
		for (int idx = length - 1; idx >= 0; idx--) {
			DeleteItem(idx);
		}
		//m_vMemento.clear();
	} else {
		for (int idx = length - 1; idx >= 0; idx--) {
			if (m_vMemento[idx].GetStoreKind() != kind) {
				break;
			}
			DeleteItem(idx);
		}
	}
	return;
}

/**
* Type of last store in buffer
*/
int CBLE_CareTaker::GetLastKind()
{
	return m_vMemento[m_vMemento.size() - 1].GetStoreKind();
}

/**
* Delete last data store in buffer
*/
void CBLE_CareTaker::DeleteLastItem()
{
	DeleteItem(m_vMemento.size() - 1);
	return;
}

/**
* Delete store in buffer
*/
void CBLE_CareTaker::DeleteItem(int index)
{
	CBLE_Memento mem = m_vMemento[index];
	m_vMemento.erase(m_vMemento.begin() + index);
	mem.Clean();
	return;
}
// CBLE_FileOpenDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CBLE_FileOpenDlg.h"
#include "dlgs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


////////////////////////////////////////////////////
CString OpenTitle[]	=	{
							_T("�t�@�C�����J��"),
							_T("Open file"),
						};

CString Open[]		=	{
							_T("�J��"),
							_T("Open"),
						};

CString Cancel[]		=	{
							_T("�L�����Z��"),
							_T("Cancel"),
						};

CString FileName[]	=	{
							_T("�t�@�C����"),
							_T("File Name"),
						};

CString FileType[]	=	{
							_T("�t�@�C���̎��"),
							_T("File Type"),
						};

CString LookIn[]	=	{
							_T("�t�H���_"),
							_T("Look In"),
						};


/////////////////////////////////////////////////////
//

IMPLEMENT_DYNAMIC(CBLE_FileOpenDlg, CFileDialog)

CBLE_FileOpenDlg:: CBLE_FileOpenDlg (BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
	m_Language = 0;
}

CBLE_FileOpenDlg::~CBLE_FileOpenDlg()
{
	
}

BOOL CBLE_FileOpenDlg::OnInitDialog()
{
	// Get a pointer to the original dialog box.
    CWnd *wndDlg = GetParent();
	wndDlg->SetWindowText(OpenTitle[m_Language]);

	// Number of controls in the File Dialog
    const UINT nControls = 8;  

	// Control ID's - defined in <dlgs.h>
    UINT Controls[nControls] = {stc4, stc3, stc2,
                                edt1, cmb1, // The eidt control and the drop-down box
                                IDOK, IDCANCEL, 
                                lst1};
	for (int i=0 ; i<nControls ; i++) {
        CWnd *wndCtrl = wndDlg->GetDlgItem(Controls[i]);
        if (Controls[i] == stc3) {
			wndCtrl->SetWindowText(FileName[m_Language]);
		}
		if (Controls[i] == stc2) {
			wndCtrl->SetWindowText(FileType[m_Language]);
		}
		if (Controls[i] == IDOK) {
			wndCtrl->SetWindowText(Open[m_Language]);
		}
		if (Controls[i] == IDCANCEL) {
			wndCtrl->SetWindowText(Cancel[m_Language]);
		}
		if (Controls[i] == stc4) {
			wndCtrl->SetWindowText(LookIn[m_Language]);
		}
    }

	return CFileDialog::OnInitDialog();
}

///////////////////////////////////////////////////////////
//  CBLE_GridCell.cpp
//  Implementation of the Class CBLE_IC
//  Created on:      12-Thg7-2013 1:52:09 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "CBLE_GridCell.h"

#define DBLE_CELL_BK_CLR			RGB(255, 255, 255)
#define DBLE_CELL_HEADER_BK_CLR		(::GetSysColor(COLOR_BTNFACE))
#define DBLE_CELL_TEXT_CLR			RGB(0, 0, 0)
#define DBLE_CELL_LINE_CLR			RGB(80, 80, 80)
#define DBLE_CELL_MARK_CLR			RGB(0, 0, 0)
#define DBLE_CELL_TEXT_BORDER		2
#define TEXT_LENGTH_MAX				8								// "xxx.xxxx"



CBLE_GridCell::CBLE_GridCell(int row, int col)
{
	m_Type = DBLE_CELL_STRING;
	m_Text = _T("");
	m_OldText = _T("");
	m_Row = row;
	m_Col = col;
	m_Header = false;
	m_Merged = false;
	m_Visible = true;
	//m_BkClr = DBLE_CELL_BK_CLR;
	m_TextClr = DBLE_CELL_TEXT_CLR;
	m_Region.SetRectEmpty();
	m_IsMark = false;
}


CBLE_GridCell::~CBLE_GridCell()
{

}


void CBLE_GridCell::Draw(CDC* pDC)
{
	if(m_Merged || !m_Visible) return;
	// Background color
	CBrush brush(m_Header ? DBLE_CELL_HEADER_BK_CLR : (/*!m_IsMark ? */DBLE_CELL_BK_CLR /*: DBLE_CELL_MARK_CLR*/));
	CBrush* pOldBrush = pDC->SelectObject(&brush);
	// Set pen
	CPen pen(PS_SOLID, !m_IsMark ? 1 : 2, !m_IsMark ? DBLE_CELL_LINE_CLR : DBLE_CELL_MARK_CLR);
	CPen* pOldPen = pDC->SelectObject(&pen);
	// Set text color
	//SetColor(m_TextClr);
	COLORREF textClr = pDC->SetTextColor(m_TextClr);

	// Draw
	pDC->Rectangle(m_Region);
	CRect textRect = m_Region;
	textRect.DeflateRect(DBLE_CELL_TEXT_BORDER, DBLE_CELL_TEXT_BORDER);

	if (!m_Header && (m_Text.GetLength() > TEXT_LENGTH_MAX)) {	
		// If this cell is for inputting value, need to left align (high priority for the most meaning digit)
		pDC->DrawText(m_Text, textRect, DT_WORDBREAK | DT_LEFT);
	} else {
		// If this cell is for display a label or a short-length number, should align the text to center
		pDC->DrawText(m_Text, textRect, DT_WORDBREAK | DT_CENTER);
	}
	
	// Restore brush and pen
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);
	pDC->SetTextColor(textClr);
}


bool CBLE_GridCell::Merge(CBLE_GridCell* pCell)
{
	if(pCell == NULL) return false;
	if((pCell->m_Row != m_Row) && (pCell->m_Col != m_Col)) return false;
	pCell->m_Merged = true;
	m_Region.BottomRight() = pCell->m_Region.BottomRight();
	return true;
}

void CBLE_GridCell::SetRegion(CRect rect)
{
	m_Region = rect;
}


CRect CBLE_GridCell::GetRegion()
{
	return m_Region;
}

void CBLE_GridCell::SetHeader(bool header)
{
	m_Header = header;
}


void CBLE_GridCell::SetText(CString text, bool restore)
{
	CString tmp = text;
	if((m_Type == DBLE_CELL_INT) && !m_Header && (text != _T(""))){
		tmp.Format(_T("%d"), atoi(text));
	}else if((m_Type == DBLE_CELL_DOUBLE) && !m_Header && (text != _T(""))){
		tmp.Format(_T("%.4f"), atof(text));
	} else {
		// do nothing
	}
	
	m_Text = tmp;
	if(restore) m_OldText = tmp;
}


void CBLE_GridCell::RestoreText()
{
	m_Text = m_OldText;
}

void CBLE_GridCell::SetColor(COLORREF color)
{
	m_TextClr = color;
}

CString CBLE_GridCell::GetText()
{
	return m_Text;
}

CString CBLE_GridCell::GetOldText()
{
	return m_OldText;
}

int CBLE_GridCell::GetRow()

{
	return m_Row;
}

int CBLE_GridCell::GetCol()
{
	return m_Col;
}

void CBLE_GridCell::SetVisible(bool visible)
{
	m_Visible = visible;
}


bool CBLE_GridCell::IsEnable()
{
	return (m_Visible && !m_Header && !m_Merged);
}

void CBLE_GridCell::SetType(DBLE_CellType type)
{
	m_Type = type;
}

void CBLE_GridCell::SetMarkCell(bool mark)
{
	m_IsMark = mark;
}

bool CBLE_GridCell::GetMarkCell()
{
	return m_IsMark;
}
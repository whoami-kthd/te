///////////////////////////////////////////////////////////
//  CBLE_IC.cpp
//  Implementation of the Class CBLE_IC
//  Created on:      12-Thg7-2013 1:52:09 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "CBLE_IC.h"
#include "CBLE_Util.h"

#define DBLE_IC_LINE_CLR			RGB(10, 10, 10)
#define DBLE_IC_SELECT_CLR			RGB(10, 255, 10)
#define DBLE_IC_MOVED_CLR			RGB(10, 255, 10)
#define DBLE_IC_OVERLAP_CLR			RGB(255, 0, 10)
#define DBLE_IC_GRAY_CLR			RGB(192, 190, 190)
#define DBLE_IC_STACKCOUNT_CLR		RGB(255, 255, 255)
#define DBLE_IC_TEXT_COLOR_WHITE	RGB(255, 255, 255)
#define DBLE_IC_INDEX_COLOR			RGB(43, 43, 227)
#define DBLE_IC_SIZE_MIN			1
#define DBLE_IC_SIZE_MEDIUM			10
#define DBLE_IC_VIEW_FONT_SIZE		100
#define DBLE_IC_VIEW_FONT_NAME		_T("Arial")

// Define colors which in them, text color is white
static COLORREF m_ColorArr[] = {
	RGB(0, 0, 0),									// black
	RGB(255, 0, 0),									// red
	RGB(0, 0, 255),									// blue
};

// Implement serialize
IMPLEMENT_SERIAL(CBLE_IC,CObject,1)

CBLE_IC::CBLE_IC(TBLE_RegIC* pRegIC, int idxX, int idxY)
{
	m_pRegIC = pRegIC;
	m_indexX = idxX;
	m_indexY = idxY;
	m_OffsetX = 0;
	m_OffsetY = 0;
	m_OffsetT = 0;
	
	// Substrate info statuses
	
	m_DetectL = DBLE_DETECT_UNKNOWN;
	m_BondingL = DBLE_BOND_NOTDONE;
	m_DetectR = DBLE_DETECT_UNKNOWN;
	m_BondingR = DBLE_BOND_NOTDONE;

	// Initialize stack count
	m_StackCountL = 0;
	m_StackCountR = 0;

	// Editing statuses
	m_Deleted = false;
	m_Selected = false;
	m_Overlapped = false;
	m_Clickable = true;
	m_OutsideSubStrate = false;
	m_BeingFocus = false;

	// Is Moved IC
	m_IsMovedL = false;
	m_IsMovedR = false;

	// #DDT(20140624): Add selected attribute for left&right
	m_SelectedL = false;
	m_SelectedR = false;

	// Set the targer position
	m_BgPosX = (pRegIC != NULL) ? (pRegIC->m_StartPosX + pRegIC->m_PitchX*m_indexX) : 0;
	//m_BgPosY = (pRegIC != NULL) ? (pRegIC->m_StartPosY + pRegIC->m_PitchY*m_indexY) : 0;
	// Change the coordinate
	m_BgPosY = (pRegIC != NULL) ? (pRegIC->m_StartPosY - pRegIC->m_PitchY*m_indexY) : 0;
	m_TargetBgPosX = m_BgPosX + m_OffsetX;
	m_TargetBgPosY = m_BgPosY + m_OffsetY;
	m_TargetTheta = m_OffsetT + (pRegIC != NULL) ? pRegIC->m_Angle : 0;
}

CBLE_IC::CBLE_IC(const CBLE_IC& ic)
{
	m_pRegIC = ic.m_pRegIC;
	m_indexX = ic.m_indexX;
	m_indexY = ic.m_indexY;
	m_OffsetX = ic.m_OffsetX;
	m_OffsetY = ic.m_OffsetY;
	m_OffsetT = ic.m_OffsetT;
	
	// Substrate info statuses
	
	m_DetectL = ic.m_DetectL;
	m_BondingL = ic.m_BondingL;
	m_DetectR = ic.m_DetectR;
	m_BondingR = ic.m_BondingR;

	// Initialize stack count
	m_StackCountL = ic.m_StackCountL;
	m_StackCountR = ic.m_StackCountR;

	// Editing statuses
	m_Deleted = ic.m_Deleted;
	m_Selected = false;
	m_Overlapped = ic.m_Overlapped;
	m_Clickable = ic.m_Clickable;
	m_OutsideSubStrate = ic.m_OutsideSubStrate;
	m_BeingFocus = ic.m_BeingFocus;

	// Is Moved IC
	m_IsMovedL = ic.m_IsMovedL;
	m_IsMovedR = ic.m_IsMovedR;

	m_SelectedL = false;
	m_SelectedR = false;

	// Set the targer position
	m_BgPosX = ic.m_BgPosX;
	m_BgPosY = ic.m_BgPosY;
	m_TargetBgPosX = ic.m_TargetBgPosX;
	m_TargetBgPosY = ic.m_TargetBgPosY;
	m_TargetTheta = ic.m_TargetTheta;
	m_textIC.Format(_T("-"));
	
}


CBLE_IC::~CBLE_IC()
{

}

/**
* If properties of m_pRegIC be changed, need to change properties of IC
*/
void CBLE_IC::SetIcProperties(TBLE_RegIC* pRegIC, int idxX, int idxY)
{
	if ((m_indexX != idxX) || (m_indexY != idxY)) {
		return;
	}
	m_pRegIC = pRegIC;
	
	// Set the target position
	m_BgPosX = (pRegIC != NULL) ? (pRegIC->m_StartPosX + pRegIC->m_PitchX*m_indexX) : 0;
	//m_BgPosY = (pRegIC != NULL) ? (pRegIC->m_StartPosY + pRegIC->m_PitchY*m_indexY) : 0;
	// Change the coordinate
	m_BgPosY = (pRegIC != NULL) ? (pRegIC->m_StartPosY - pRegIC->m_PitchY*m_indexY) : 0;
	m_TargetBgPosX = m_BgPosX + m_OffsetX;
	m_TargetBgPosY = m_BgPosY + m_OffsetY;
	m_TargetTheta = pRegIC->m_Angle + m_OffsetT;
}

void CBLE_IC::Draw(CDC* pDC, double scale, DBLE_MODE mode, TBLE_StatusColor* stColor, bool drawRegNo, bool selectable, int dir, CString Text, COLORREF colorIC)
{
	// Don't draw deleted ICs in edit mode if hide invalid
	if((mode == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID) && m_Deleted) return;
	// Don't draw deleted ICs in subinfo mode
	if ((mode == DBLE_MODE_SUB_INFO_DETECT || mode == DBLE_MODE_SUB_INFO_BOND || mode == DBLE_MODE_SUB_INFO_STACK) && m_Deleted) {
		return;
	}
	vector<R2Pos> vR2Pnt;
	GetICPoint(vR2Pnt, scale, true);
	CBLE_Util::ChangeCoordinate(vR2Pnt);
	vector<CPoint> vPoint;
	// Convert to CPoint
	CBLE_Util::R2PosToCPoint(vR2Pnt, vPoint);
	
	bool moved = false;
	int selected = m_Selected;
	if (dir == DBLE_SUBINFO_TYPE_L) {
		moved = m_IsMovedL;
		selected = m_SelectedL;
	}else if(dir == DBLE_SUBINFO_TYPE_R) {
		moved = m_IsMovedR;
		selected = m_SelectedR;
	}
	// Create pen
	CPen pen;
	// IC is moved
	if (moved) {
		// Draw frame around with moved IC
		pen.CreatePen(PS_SOLID, 1, DBLE_IC_MOVED_CLR);
	} else {
		if (!selectable) {
			pen.CreatePen(m_Deleted ? PS_DOT : PS_SOLID, 1, stColor->m_Regno);
		} else {
			if(!m_Overlapped){
				if (m_BeingFocus) {
					pen.CreatePen(m_Deleted ? PS_DOT : PS_SOLID, 1, m_BeingFocus ? stColor->m_Focus/*DBLE_IC_SELECT_CLR*/ : stColor->m_ValidDisp/*DBLE_IC_LINE_CLR*/);
				} else {
					pen.CreatePen(m_Deleted ? PS_DOT : PS_SOLID, 1, selected ? stColor->m_Cursor/*DBLE_IC_SELECT_CLR*/ : stColor->m_ValidDisp/*DBLE_IC_LINE_CLR*/);
				}
			} else {
				if (m_BeingFocus) {
					pen.CreatePen(PS_SOLID, 1, m_BeingFocus ? stColor->m_Focus/*DBLE_IC_SELECT_CLR*/ : stColor->m_OverlapDisp/*DBLE_IC_OVERLAP_CLR*/);
				} else {
					pen.CreatePen(PS_SOLID, 1, selected ? stColor->m_Cursor/*DBLE_IC_SELECT_CLR*/ : stColor->m_OverlapDisp/*DBLE_IC_OVERLAP_CLR*/);
				}
			}
		}
	}	
	CPen* pOldPen = pDC->SelectObject(&pen);

	// Store brush
	CBrush* pOlBrush = pDC->GetCurrentBrush();

	// Get IC region
	int posX = CBLE_Util::Round(GetPosX()*scale);
	int posY = CBLE_Util::Round(GetPosY()*scale);
	int sizeX = CBLE_Util::Round(m_pRegIC->m_SizeX*scale);
	int sizeY = CBLE_Util::Round(m_pRegIC->m_SizeY*scale);
	// Create font
	CFont font;
	font.CreatePointFont(DBLE_IC_VIEW_FONT_SIZE, DBLE_IC_VIEW_FONT_NAME);
	CFont* pOldFont = pDC->SelectObject(&font);
	//CRect rect(CPoint(posX, posY), CSize(sizeX, sizeY));
	// Change the coordinate
	CRect rect(CPoint(posX, -posY), CSize(sizeX, sizeY));
	rect.OffsetRect(-sizeX/2, -sizeY/2);

	if((mode == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID) || (mode == DBLE_MODE_LOCATE_EDIT_SHOW_INVALID)){ // Draw in edit mode
		pDC->SelectObject(GetStockObject(NULL_BRUSH));
		pDC->Polygon(&vPoint[0], 4);
		if(drawRegNo){
			CString text;
			text.Format(_T("%d"), m_pRegIC->m_RegNo);

			CSize textSize = pDC->GetTextExtent(text);
			if((textSize.cx < rect.Width()) && (textSize.cy < rect.Height())){
				pDC->DrawText(text, rect, DT_VCENTER | DT_CENTER | DT_SINGLELINE);
			}

			pDC->SelectObject(pOldFont);
		}
	} else {	// subinfo mode
		CString text;
		COLORREF color = DBLE_IC_STACKCOUNT_CLR;
		if (mode == DBLE_MODE_SUB_INFO_DETECT) { // Draw in subinfo mode: Dectect
			// Check draw status in L or R
			DBLE_DetectState detect = (dir == DBLE_SUBINFO_TYPE_L) ? m_DetectL : m_DetectR;
			if(drawRegNo){
				switch(detect) {
					case DBLE_DETECT_UNKNOWN:
						color = stColor->m_UnknownClr;
						text.Format(_T("-"));
						break;
					case DBLE_DETECT_BAD:
						text.Format(_T("B"));	
						color = stColor->m_BadClr;
						break;
					case DBLE_DETECT_GOOD:
						text.Format(_T("G"));	
						color = stColor->m_GoodClr;
						break;
					default:
						text.Format(_T("-"));
						color = stColor->m_UnknownClr;
						break;

				}
			}
		}
		if (mode == DBLE_MODE_SUB_INFO_BOND) { // Draw in subinfo mode : bond
			DBLE_BondState bond = (dir == DBLE_SUBINFO_TYPE_L) ? m_BondingL : m_BondingR;
			switch(bond) {
				case DBLE_BOND_NOTDONE:
					text.Format(_T("-"));
					color = stColor->m_NotDoneClr;
					break;
				case DBLE_BOND_FAIL:
					text.Format(_T("N"));
					color = stColor->m_FailClr;
					break;
				case DBLE_BOND_DONE:
					text.Format(_T("O"));
					color = stColor->m_DoneClr;
					break;
				case DBLE_BOND_STACK:
					text.Format(_T("C"));
					color = stColor->m_StackClr;
					break;
				case DBLE_BOND_NONEED:
					text.Format(_T("S"));
					color = stColor->m_NoNeedClr;
					break;
				default:
					// default color & text
					text.Format(_T("-"));
					color = stColor->m_NotDoneClr;
					break;
			}
		} 
		if(mode == DBLE_MODE_SUB_INFO_LOAD_MAP){   //#THAIHV170807 Add mode Load Subtrate Map
			text = Text;
			color = colorIC;
		}
		if (mode == DBLE_MODE_SUB_INFO_STACK) { // Draw in subinfo mode : stack
			int stack = (dir == DBLE_SUBINFO_TYPE_L) ? m_StackCountL : m_StackCountR;
			text.Format("%2d", stack);
		}
		
		CBrush brushRed(color);
		pDC->SelectObject(&brushRed);
		if(text != "."){
			pDC->Polygon(&vPoint[0], 4);
		}
		if (moved) {
			
			// Draw if IC is moved
			// 4 middle points of 4 edges of ICs
			vector<CPoint> vMidPoint;
			vMidPoint.push_back(CPoint((vPoint[0].x + vPoint[1].x)/2, (vPoint[0].y + vPoint[1].y)/2));
			vMidPoint.push_back(CPoint((vPoint[1].x + vPoint[2].x)/2, (vPoint[1].y + vPoint[2].y)/2));
			vMidPoint.push_back(CPoint((vPoint[2].x + vPoint[3].x)/2, (vPoint[2].y + vPoint[3].y)/2));
			vMidPoint.push_back(CPoint((vPoint[3].x + vPoint[0].x)/2, (vPoint[3].y + vPoint[0].y)/2));

			// 4 end-points corresponding to 4 middle points
			vector<CPoint> vMidEndPoint;
			vMidEndPoint.push_back(CPoint((5 * vMidPoint[0].x - vMidPoint[2].x) / 4, (5 * vMidPoint[0].y - vMidPoint[2].y) / 4));
			vMidEndPoint.push_back(CPoint((5 * vMidPoint[1].x - vMidPoint[3].x) / 4, (5 * vMidPoint[1].y - vMidPoint[3].y) / 4));
			vMidEndPoint.push_back(CPoint((5 * vMidPoint[2].x - vMidPoint[0].x) / 4, (5 * vMidPoint[2].y - vMidPoint[0].y) / 4));
			vMidEndPoint.push_back(CPoint((5 * vMidPoint[3].x - vMidPoint[1].x) / 4, (5 * vMidPoint[3].y - vMidPoint[1].y) / 4));
			for (int mv = 0; mv < 4; mv++) {
				pDC->MoveTo(vMidPoint[mv]);
				pDC->LineTo(vMidEndPoint[mv]);
			}
		}
		
		CSize textSize = pDC->GetTextExtent(text);
		COLORREF textColor = pDC->GetTextColor();
		if (CheckColor(color)) {
			pDC->SetTextColor(DBLE_IC_TEXT_COLOR_WHITE);
		}
		if((textSize.cx < rect.Width()) && (textSize.cy < rect.Height())){
			pDC->DrawText(text, rect, DT_VCENTER | DT_CENTER | DT_SINGLELINE);
		}
		pDC->SetTextColor(textColor);
		pDC->SelectObject(pOldFont);
	}

	// Restore pen & brush
	pDC->SelectObject(pOldPen);
	pDC->SelectObject(pOlBrush);
	
}

/**
 * Check a point is in region of this IC or not
 */
BOOL CBLE_IC::Click(R2Pos point, DBLE_MODE mode, bool selectDeleted)
{
	if((mode == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID || mode == DBLE_MODE_SUB_INFO_DETECT || mode == DBLE_MODE_SUB_INFO_BOND || mode == DBLE_MODE_SUB_INFO_STACK) && m_Deleted && !selectDeleted) {
		return false;
	}

	if (!m_Clickable /*|| m_OutsideSubStrate*/) {
		return false;
	}
	vector <R2Pos> vPoint;
	GetICPoint(vPoint);
	// Change the coordinate of IC
	point.y = point.y * (-1);

	// Check to see of clicked point is inside IC circle
	double distance = CBLE_Util::SegmentLength(R2Pos(GetPosX(), GetPosY()), point);
	// Calculate radius of IC1's circle
	double sizeXIC = m_pRegIC->m_SizeX;
	double sizeYIC = m_pRegIC->m_SizeY;
	double r = sqrt(sizeXIC * sizeXIC + sizeYIC* sizeYIC) / 2;

	// Distance from clicked point to center of IC is larger than radius of IC then skip
	if (distance > r) { 
		return false;
	}

	if (m_OffsetT + m_pRegIC->m_Angle == 0) {
		return (point.x >= vPoint[0].x && point.x <= vPoint[1].x && point.y <= vPoint[3].y && point.y >= vPoint[1].y );
	} else {
		return (CBLE_Util::PointInPolygon(point, vPoint));
	}
}

/**
 * Check a rectangle is intersect with this IC or not
 */
BOOL CBLE_IC::IntersectRect(R2Pos p1, R2Pos p2, DBLE_MODE mode, bool selectDeleted)
{
	if((mode == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID || mode == DBLE_MODE_SUB_INFO_DETECT || mode == DBLE_MODE_SUB_INFO_BOND || mode == DBLE_MODE_SUB_INFO_STACK) && m_Deleted && !selectDeleted) {
		return false;
	}
	//return CBLE_Util::PointInPolygonS(R2Pos(GetPosX(), GetPosY()), rectPoint);
	// Get the center point
	double posX = GetPosX();
	//double posY = GetPosY();
	// Change the coordinate
	double posY = -GetPosY();
	if(posX < p1.x) return false;
	if(posX > p2.x) return false;
	if(posY < p1.y) return false;
	if(posY > p2.y) return false;
	return true;
}


/**
 * Delete this IC in substrate
 */
void CBLE_IC::Delete()
{
	m_Deleted = true;
}


/**
 * Restore this IC in substrate
 */
void CBLE_IC::Restore()
{
	m_Deleted = false;
}


/**
 * Check this IC and a another IC is overlapped or not
 */
bool CBLE_IC::CheckOverlap(CBLE_IC* pIC)
{
	// Get 4 points of this IC
	vector<R2Pos> vR2Pnt1;
	GetICPoint(vR2Pnt1);

	// Get 4 points of another IC
	vector<R2Pos> vR2Pnt2;
	pIC->GetICPoint(vR2Pnt2);

	return CBLE_Util::CheckOverlap(vR2Pnt1, vR2Pnt2);
}

void CBLE_IC::GetICPoint(vector<R2Pos> &vPoint, double scale, bool checkSize)
{
	vPoint.clear();
	double posX = GetPosX(), posY = GetPosY();

	double sizeX = m_pRegIC->m_SizeX;
	double sizeY = m_pRegIC->m_SizeY;

	if(checkSize){
		if(sizeX*scale < DBLE_IC_SIZE_MIN) {
			sizeX = DBLE_IC_SIZE_MIN/scale;
		}
		if(sizeY*scale < DBLE_IC_SIZE_MIN) {
			sizeY = DBLE_IC_SIZE_MIN/scale;
		}
	}

	// 1st point
	R2Pos point;
	point.x = posX - sizeX/2;
	point.y = posY - sizeY/2;
	CBLE_Util::RotatePoint(point.x, point.y, posX, posY, m_OffsetT + m_pRegIC->m_Angle);
	if(scale != 0){
		point.x *= scale;
		point.y *= scale;
	}
	vPoint.push_back(point);
	// 2nd point
	point.x = posX + sizeX/2;
	point.y = posY - sizeY/2;
	CBLE_Util::RotatePoint(point.x, point.y, posX, posY, m_OffsetT + m_pRegIC->m_Angle);
	if(scale != 0){
		point.x *= scale;
		point.y *= scale;
	}
	vPoint.push_back(point);
	// 3rd point
	point.x = posX + sizeX/2;
	point.y = posY + sizeY/2;
	CBLE_Util::RotatePoint(point.x, point.y, posX, posY, m_OffsetT + m_pRegIC->m_Angle);
	if(scale != 0){
		point.x *= scale;
		point.y *= scale;
	}
	vPoint.push_back(point);
	// 4th point
	point.x = posX - sizeX/2;
	point.y = posY + sizeY/2;
	CBLE_Util::RotatePoint(point.x, point.y, posX, posY, m_OffsetT + m_pRegIC->m_Angle);
	if(scale != 0){
		point.x *= scale;
		point.y *= scale;
	}
	vPoint.push_back(point);
}

double CBLE_IC::GetPosX()
{
	return m_BgPosX + m_OffsetX;
}

double CBLE_IC::GetPosY()
{
	//return m_BgPosY + m_OffsetY;
	return m_BgPosY + m_OffsetY;
}

bool CBLE_IC::CheckColor(COLORREF color)
{
	bool r = false;
	int length = ARRAY_LENGTH(m_ColorArr);
	for (int i = 0; i < length; i++) {
		if (color == m_ColorArr[i]) {
			r = true;
			break;
		}
	}
	return r;
}

void CBLE_IC::DrawIndex(CDC* pDC, double scale, bool xAxis)
{
	// Get IC pos
	int posX = CBLE_Util::Round(m_BgPosX*scale);
	int posY = CBLE_Util::Round(m_BgPosY*scale);
	int sizeX = CBLE_Util::Round(m_pRegIC->m_SizeX*scale);
	int sizeY = CBLE_Util::Round(m_pRegIC->m_SizeY*scale);
	CRect rect(CPoint(posX, -posY), CSize(sizeX, sizeY));
	
	// Create font
	CFont font;
	font.CreatePointFont(DBLE_IC_VIEW_FONT_SIZE, DBLE_IC_VIEW_FONT_NAME);
	CFont* pOldFont = pDC->SelectObject(&font);
	CString text;
	COLORREF oldColor = pDC->GetTextColor();
	pDC->SetTextColor(DBLE_IC_INDEX_COLOR);

	if (xAxis) {
		text.Format(_T("%d"), m_indexY + 1);
		//pDC->TextOut(posX + 20 * scale, posY, text);
		rect.OffsetRect(sizeX/2, -sizeY/2);
		pDC->DrawText(text, rect, DT_VCENTER | DT_CENTER | DT_SINGLELINE);
	} else {
		text.Format(_T("%d"), m_indexX + 1);
		//pDC->TextOut(posX, -posY, text);
		rect.OffsetRect(-sizeX/2, 0);
		pDC->DrawText(text, rect, DT_VCENTER | DT_CENTER | DT_SINGLELINE);
	}
	
	pDC->SetTextColor(oldColor);
	pDC->SelectObject(pOldFont);
}

/*
* Set Moved status
*/
void CBLE_IC::SetMoved(bool isMoved, int dir)
{
	if (dir == DBLE_SUBINFO_TYPE_L) {
		m_IsMovedL = isMoved;
	} else {
		m_IsMovedR = isMoved;
	}
}

/*
* Serialize function
*/

void CBLE_IC::Serialize(CArchive &archive)
{
	CObject::Serialize(archive);
	//DWORD changed = m_pRegIC->m_Changed;
	int deleted;
	int overlap;
	int outside = m_OutsideSubStrate;

	if (m_Deleted) {
		deleted = 1;
	} else {
		deleted = 0;
	}

	if (m_Overlapped) {
		overlap = 1;
	} else {
		overlap = 0;
	}
	
	if (m_OutsideSubStrate) {
		outside = 1;
	} else {
		outside = 0;
	}

	if (archive.IsStoring()) {
		archive << m_indexX << m_indexY << m_OffsetT << m_OffsetX << m_OffsetY << m_BgPosX 
				<< m_BgPosY << m_TargetBgPosX << m_TargetBgPosY << m_TargetTheta
				<< deleted << overlap << outside;
	} else {
		archive >> m_indexX >> m_indexY >> m_OffsetT >> m_OffsetX >> m_OffsetY >> m_BgPosX 
				>> m_BgPosY >> m_TargetBgPosX >> m_TargetBgPosY >> m_TargetTheta
				>> deleted >> overlap >> outside;
		//m_pRegIC->m_Changed = changed;
		if (deleted == 1) {
			m_Deleted = true;
		} else {
			m_Deleted = false;
		}

		if (overlap == 1) {
			m_Overlapped = true;
		} else {
			m_Overlapped =  false;
		}
		
		if (outside == 1) {
			m_OutsideSubStrate = true;
		} else {
			m_OutsideSubStrate = false;
		}
		//SetIcProperties(m_pRegIC, m_indexX, m_indexY);
	}
}
// For undo function
/**
* Copy data of IC
*/
void CBLE_IC::CopyData(CBLE_IC ic)
{
	m_pRegIC = ic.m_pRegIC;
	m_indexX = ic.m_indexX;
	m_indexY = ic.m_indexY;
	m_OffsetX = ic.m_OffsetX;
	m_OffsetY = ic.m_OffsetY;
	m_OffsetT = ic.m_OffsetT;
	
	// Substrate info statuses
	
	m_DetectL = ic.m_DetectL;
	m_BondingL = ic.m_BondingL;
	m_DetectR = ic.m_DetectR;
	m_BondingR = ic.m_BondingR;

	// Initialize stack count
	m_StackCountL = ic.m_StackCountL;
	m_StackCountR = ic.m_StackCountR;
	// Is Moved IC
	m_IsMovedL = ic.m_IsMovedL;
	m_IsMovedR = ic.m_IsMovedR;

	// Editing statuses
	m_Deleted = ic.m_Deleted;
	m_Selected = true;
	m_Overlapped = ic.m_Overlapped;
	m_Clickable = ic.m_Clickable;
	m_OutsideSubStrate = ic.m_OutsideSubStrate;
	m_BeingFocus = ic.m_BeingFocus;

	// Set the targer position
	m_BgPosX = ic.m_BgPosX;
	m_BgPosY = ic.m_BgPosY;
	m_TargetBgPosX = ic.m_TargetBgPosX;
	m_TargetBgPosY = ic.m_TargetBgPosY;
	m_TargetTheta = ic.m_TargetTheta;

	// Selected LR
	m_SelectedL = false;
	m_SelectedR = false;
}

/**
* Compare two ICs
*/
bool CBLE_IC::CompareIC(CBLE_IC ic)
{
	if ((ic.m_pRegIC->m_RegNo == m_pRegIC->m_RegNo) && (ic.m_indexX == m_indexX) && (ic.m_indexY == m_indexY)) {
		return true;
	} 
	return false;
}

double CBLE_IC::GetDistanceToICBorder(R2Pos point)
{
	double nearest;
	point.y = point.y * (-1);
	// Vector to store 4 points of IC
	vector<R2Pos> vR2Pnt;
	this->GetICPoint(vR2Pnt);
	nearest = CBLE_Util::SegmentLength(point, vR2Pnt[0]);
	for (int i = 1; i <= 3; i++) {
		if (nearest > CBLE_Util::SegmentLength(point, vR2Pnt[i])) {
			nearest = CBLE_Util::SegmentLength(point, vR2Pnt[i]);
		}
	}
	return nearest;
}
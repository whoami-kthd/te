///////////////////////////////////////////////////////////
//  CBLE_LocateEditWnd.cpp
//  Implementation of the Class CBLE_LocateEditWnd
//  Created on:      16-Thg7-2013 10:25:24 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_LocateEditWnd.h"
#include "CBLE_ProgressBar.h"
#include "CBLE_FrameWnd.h"
#include "CBLE_Util.h"
#include "CBLE_Memento.h"
#include "CBLE_CareTaker.h"

#define DBLE_EDITWND_SIZEX				600		// Edit Window�̉����w��
#define DBLE_EDITWND_SIZEY				500		// Edit Window�̍����w��
#define DBLE_EDITWND_MINSCALE			1.0

#define DBLE_EDITWND_OPERATION_SIZEX	300		// Layout��LocaeEdit�g�E�[����̋���.�l�������������Layout�傫���Ȃ�.
#define DBLE_EDITWND_OPERATION_SIZEY	200
#define DBLE_EDITWND_MARGIN_SIZEX		140

#define DBLE_EDITWND_10KEY_WIDTH		170		// 10KEY��Width,Height
#define DBLE_EDITWND_10KEY_HEIGHT		140

#define DBLE_EDITWND_INFO_WIDTH			400		// Information��Width,Height
#define DBLE_EDITWND_INFO_HEIGHT		60

// Define message to warning when restore all IC
//#define WARNING_MESSAGE_ALLRESTORE		_T("Are you sure want to restore all IC?")
/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString AllRestore[] =		{
								_T("���ׂ�IC�𕜌����܂����H"),
								_T("Are you sure want to restore all IC?"),
							};

/////////////////////////////////////////////////////////////////////////////
// CBLE_LocateEditWnd dialogy


CBLE_LocateEditWnd::CBLE_LocateEditWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_LocateEditWnd::IDD, pParent)
{
	m_pDoc = NULL;
	m_nZoom = 0;
	m_nRegNo = 0;
	m_LayoutWnd = NULL;
	m_bInit = false;
}

CBLE_LocateEditWnd::~CBLE_LocateEditWnd()
{

}


void CBLE_LocateEditWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_CBIndex(pDX, IDC_LEDIT_ZOOM_CBB, m_nZoom);
	DDX_CBIndex(pDX, IDC_LEDIT_REGNO_CBB, m_nRegNo);
}


BEGIN_MESSAGE_MAP(CBLE_LocateEditWnd, CDialog)
	// Messages
	ON_MESSAGE(WM_UPDATE_VIEW, OnUpdateView)
	ON_MESSAGE(WM_UPDATE_ZOOM, OnUpdateZoom)
	ON_MESSAGE(WM_UPDATE_SELECTED, OnChangeSelectIC)
	ON_MESSAGE(WM_DISPLAY_FOCUSIC, OnDisplayFocusIC)
	ON_MESSAGE(WM_UPDATE_REGNO, OnUpdateRegNo)
	ON_MESSAGE(WM_UPDATE_REVWND, OnChangeRevKeyWnd)
	// Combobox event
	ON_CBN_SELCHANGE(IDC_LEDIT_ZOOM_CBB, OnZoom)
	ON_CBN_SELCHANGE(IDC_LEDIT_REGNO_CBB, OnChangeRegNo)
	// Button event
	ON_COMMAND_RANGE(IDC_LEDIT_ZOOM_IN, IDC_LEDIT_ZOOM_OUT, OnChangeZoom)
	ON_BN_CLICKED(IDC_LEDIT_DEL_BTN, OnDelete)
	ON_BN_CLICKED(IDC_LEDIT_REST_BTN, OnRestore)
	ON_BN_CLICKED(IDC_LEDIT_DISP_BTN, OnChangeDisplayMode)
	ON_BN_CLICKED(IDC_LEDIT_CHECK_BTN, OnCheckReflect)
	ON_BN_CLICKED(IDC_LEDIT_ALLRESTORE, OnAllRestore)
	ON_BN_CLICKED(IDC_LEDIT_INDEX_DISPLAY_BTN, OnIndexDisplay)
	ON_COMMAND_RANGE(IDC_LEDIT_REGNO_UP, IDC_LEDIT_REGNO_DOWN, OnRegNoButton)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_WM_DESTROY()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_LocateEditWnd message handlers

void CBLE_LocateEditWnd::OnCancel()
{
	CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_EDITDLG);
	CDialog::OnCancel();
	
	// Reset buffer restore
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore();

}

void CBLE_LocateEditWnd::OnOK()
{
	// do nothing
}
//THAIHV 20151124 (C)
//Close windows  
void CBLE_LocateEditWnd::CloseWnd()
{
	OnCancel();
}

void CBLE_LocateEditWnd::OnDestroy()
{
	CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_EDITDLG);
	CDialog::OnDestroy();
}

BOOL CBLE_LocateEditWnd::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;

	CRect rect;
	// --------------------
	// Creat common window
	GetDlgItem(IDC_LEDIT_COMMON)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_CommWnd.SetDocument(m_pDoc);
	m_CommWnd.Create(IDD_COM_SETTING_DLG, this);
	m_CommWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	//m_CommWnd.UpdateView();
	//Change language
	m_CommWnd.ChangeLanguage();
	m_CommWnd.ShowWindow(SW_SHOW);

	// --------------------
	// Create layout window
	GetDlgItem(IDC_LEDIT_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_LayoutWnd = new CBLE_LayoutWnd();
	m_LayoutWnd->SetDocument(m_pDoc);
	m_LayoutWnd->Create(NULL, NULL,
		WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_LEDIT_LAYOUT, pContext);
	//m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],true);

	// --------------------
	// Create information window
	GetDlgItem(IDC_LEDIT_INFO)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_InfoWnd.SetDocument(m_pDoc);
	m_InfoWnd.Create(IDD_INFORMATION_DLG, this);
	m_InfoWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	// Change language
	m_InfoWnd.ChangeLanguage();
	m_InfoWnd.ShowWindow(SW_SHOW);

	// --------------------
	// Create key window
	GetDlgItem(IDC_LEDIT_NUM_KEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(m_InfoWnd.GetEditWnd(), IDD_NKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);
	//#THAIHV170815 Hide button for RegNo
	GetDlgItem(IDC_LEDIT_REGNO_CBB)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_LEDIT_REGNO_DOWN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_LEDIT_REGNO_UP)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_LEDIT_STATICREGNO)->ShowWindow(SW_HIDE);
	// --------------------
	// Add content for zoom combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_LEDIT_ZOOM_CBB));
	int zoom = m_pDoc->m_vZoom.size();
	for(UINT idx = 0; idx < zoom; idx ++){
		CString str;
		str.Format(_T("x%2d"), m_pDoc->m_vZoom[idx]);
		pCbb->AddString(str);
	}
//#THAIHV170818 Move Items in Edit mode (S)
	//	IDC_LEDIT_DISP_BTN
	GetDlgItem(IDC_LEDIT_DISP_BTN)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -20);
	GetDlgItem(IDC_LEDIT_DISP_BTN)->MoveWindow(rect,true);
	//	IDC_LEDIT_LBL_DISP
	GetDlgItem(IDC_LEDIT_LBL_DISP)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -20);
	GetDlgItem(IDC_LEDIT_LBL_DISP)->MoveWindow(rect,true);

	//IDC_LEDIT_INDEX_DISPLAY_BTN
	GetDlgItem(IDC_LEDIT_INDEX_DISPLAY_BTN)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -15);
	GetDlgItem(IDC_LEDIT_INDEX_DISPLAY_BTN)->MoveWindow(rect,true);

	//IDC_LEDIT_REST_BTN    
	GetDlgItem(IDC_LEDIT_REST_BTN)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -10);
	GetDlgItem(IDC_LEDIT_REST_BTN)->MoveWindow(rect,true);
	//IDC_LEDIT_ALLRESTORE    
	GetDlgItem(IDC_LEDIT_ALLRESTORE)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -10);
	GetDlgItem(IDC_LEDIT_ALLRESTORE)->MoveWindow(rect,true);
	//IDC_LEDIT_DEL_BTN    
	GetDlgItem(IDC_LEDIT_DEL_BTN)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -5);
	GetDlgItem(IDC_LEDIT_DEL_BTN)->MoveWindow(rect,true);
//#THAIHV170818 Move Items in Edit mode (E)
	// Init view
	InitView();
	// Delete pointer
	delete pContext;

	m_bInit = true;
	// Resize windown
	CBLE_Util::GetWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_EDITDLG);

	return TRUE;
}

void CBLE_LocateEditWnd::InitView()
{
	OnUpdateRegNo(0, 0);
	// Update information window
	m_InfoWnd.UpdateGridData();
	m_CommWnd.UpdateView();
	// Show this window
	ShowWindow(SW_SHOW);
}

void CBLE_LocateEditWnd::UpdateComboBox()
{
	// Update combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_LEDIT_ZOOM_CBB));
	pCbb->ResetContent();
	int zoom = m_pDoc->m_vZoom.size();
	for(UINT idx = 0; idx < zoom; idx ++){
		CString str;
		str.Format(_T("x%2d"), m_pDoc->m_vZoom[idx]);
		pCbb->AddString(str);
	}
	m_nZoom = 0;
	pCbb->SetCurSel(m_nZoom);
	UpdateData(FALSE);

}

void CBLE_LocateEditWnd::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

CBLE_Doc* CBLE_LocateEditWnd::GetDocument()
{
	return m_pDoc;
}

LRESULT CBLE_LocateEditWnd::OnUpdateZoom(WPARAM wParam, LPARAM lParam)
{
	if((wParam == DBLE_ZOOM_IN) && (m_nZoom != (m_pDoc->m_vZoom.size() - 1))){
		OnChangeZoom(IDC_LEDIT_ZOOM_IN);
	}else if((wParam == DBLE_ZOOM_OUT) && (m_nZoom != 0)){
		OnChangeZoom(IDC_LEDIT_ZOOM_OUT);
	}
	return 0;
}


LRESULT CBLE_LocateEditWnd::OnUpdateView(WPARAM wParam, LPARAM lParam)
{
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],true);
	m_LayoutWnd->Invalidate();
	CheckBtnState();
	return 0;
}


void CBLE_LocateEditWnd::OnZoom()
{
	UpdateData();
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],true);
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	CheckBtnState();
}

void CBLE_LocateEditWnd::OnChangeZoom(UINT nID)
{
	switch(nID){
	case IDC_LEDIT_ZOOM_IN:
		m_nZoom ++;
		break;
	case IDC_LEDIT_ZOOM_OUT:
		m_nZoom --;
		break;
	default:
		return;
	}
	// Set Scale
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom], true);
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	UpdateData(FALSE);
	CheckBtnState();
}


void CBLE_LocateEditWnd::OnChangeRegNo()
{
	UpdateData();
	// Set RegNo to Layout
	CString strRegNo;
	GetDlgItem(IDC_LEDIT_REGNO_CBB)->GetWindowText(strRegNo);
	m_LayoutWnd->SetRegNo(atoi(strRegNo));

	// Display index for new regno
	CButton* checkBox = (CButton*) GetDlgItem(IDC_LEDIT_INDEX_DISPLAY_BTN);
	m_LayoutWnd->SetIndexDisplay(checkBox->GetCheck());

	// Redraw Layout
	m_LayoutWnd->Invalidate();
}

void CBLE_LocateEditWnd::CheckBtnState()
{
	// Zoom out button
	GetDlgItem(IDC_LEDIT_ZOOM_OUT)->EnableWindow(m_nZoom != 0);
	
	// Zoom in button
	GetDlgItem(IDC_LEDIT_ZOOM_IN)->EnableWindow(m_nZoom != (m_pDoc->m_vZoom.size() - 1));
	
	// RegNo Up button
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_LEDIT_REGNO_CBB));
	GetDlgItem(IDC_LEDIT_REGNO_UP)->EnableWindow(m_nRegNo != pCbb->GetCount() - 1);
	
	// RegNo Down button
	CString strRegNo;
	GetDlgItem(IDC_LEDIT_REGNO_CBB)->GetWindowText(strRegNo);
	GetDlgItem(IDC_LEDIT_REGNO_DOWN)->EnableWindow(atoi(strRegNo) != 0);

	// Delete button
	BOOL bEnable = FALSE;
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	int icSize = vIC.size();
	for(UINT idx = 0; idx < icSize; idx ++){
		if(vIC[idx]->m_Deleted) continue;
		bEnable = TRUE;
		break;
	}
	GetDlgItem(IDC_LEDIT_DEL_BTN)->EnableWindow(bEnable);
	
	// Restore button
	bEnable = FALSE;
	for(idx = 0; idx < icSize; idx ++){
		if(!vIC[idx]->m_Deleted) continue;
		bEnable = TRUE;
		break;
	}
	GetDlgItem(IDC_LEDIT_REST_BTN)->EnableWindow(bEnable);

	// Display button
	CString strDisp = (m_LayoutWnd->GetMode() == DBLE_MODE_LOCATE_EDIT_SHOW_INVALID) ? _T("Show") : _T("Hide");
	GetDlgItem(IDC_LEDIT_LBL_DISP)->SetWindowText(strDisp);

	// Display index button
	GetDlgItem(IDC_LEDIT_INDEX_DISPLAY_BTN)->EnableWindow(m_nRegNo != 0);
}


void CBLE_LocateEditWnd::OnDelete()
{
	DeleteSelectedIC();
}


void CBLE_LocateEditWnd::OnRestore()
{
	// For undo function
	// Store state
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	CBLE_Memento mem = m_pDoc->GetData()->CreateMemento(IDD_LOCATE_EDIT_DLG);
	pCareTaker->SetMemento(mem);


	TRACE("[Edit][Restore]CBLE_ LocateEditWnd::On Restore()\n");
	// Update modified flag
	m_pDoc->SetModifiedFlag(1);
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	int icSize = vIC.size();
	for(UINT idx = 0; idx < icSize; idx ++){
		vIC[idx]->Restore();
	}
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	// Update state for button
	CheckBtnState();
	// Update information window
	m_InfoWnd.UpdateGridData();
	
}

void CBLE_LocateEditWnd::OnChangeDisplayMode()
{
	if(m_LayoutWnd->GetMode() == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID){
		m_LayoutWnd->SetMode(DBLE_MODE_LOCATE_EDIT_SHOW_INVALID);
		m_InfoWnd.SetDisplayMode(DBLE_MODE_LOCATE_EDIT_SHOW_INVALID);
	}else{
		m_LayoutWnd->SetMode(DBLE_MODE_LOCATE_EDIT_HIDE_INVALID);
		m_InfoWnd.SetDisplayMode(DBLE_MODE_LOCATE_EDIT_HIDE_INVALID);
	}
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	CheckBtnState();
}

LRESULT CBLE_LocateEditWnd::OnChangeSelectIC(WPARAM wParam,LPARAM lParam)
{
	// Check disable/enable Delete and Restore button
	CheckBtnState();
	// Update information window
	m_InfoWnd.UpdateGridData();
	return 0;
}

// Display focus IC
LRESULT CBLE_LocateEditWnd::OnDisplayFocusIC(WPARAM wParam, LPARAM lParam)
{
	m_InfoWnd.DisplayFocusIC();
	return 0;
}

void CBLE_LocateEditWnd::OnCheckReflect()
{
	// Refresh buffer restore
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore();

	// Write log
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_CHECKREFELCT, DBLE_LOGFILE_LEDIT, "");

	TRACE("[Edit][C&R]CBLE_LocateEditWnd::On CheckReflect()Check,Refrect-Start\n");
	// Check setting
	if (m_pDoc->GetSetting() == 0) {
		return;
	}
	// Update modified flag
	m_pDoc->SetModifiedFlag(1);
	// Check in substrate
	CBLE_ProgressBar progressDlg;
	progressDlg.SetDocument(m_pDoc);
	progressDlg.m_Type = DBLE_PROGRESSBAR_CHCK;
	progressDlg.m_bDisplay = progressDlg.m_bDisplay = m_pDoc->GetData()->GetSubstrate()->PerformanceChecking();

	progressDlg.DoModal();

	if (m_pDoc->m_vZoom[m_nZoom] >= DBLE_EDITWND_MINSCALE) {
		m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],false);
	}

	// Redraw Layout
	m_LayoutWnd->Invalidate();
}

LRESULT CBLE_LocateEditWnd::OnUpdateRegNo(WPARAM wParam, LPARAM lParam)
{
	// Get the pointer of RegNo combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_LEDIT_REGNO_CBB));
	// Get current RegNo
	CString strReg;
	pCbb->GetWindowText(strReg);
	int RegNo = atoi(strReg);
	// Update RegNo
	m_nRegNo = 0;
	// Update content for RegNo combobox
	pCbb->ResetContent();
	pCbb->AddString(_T("0"));
	vector<TBLE_RegIC> vReg = m_pDoc->GetData()->m_vRegIC;
	CString strTmp;
	int regSize = vReg.size();
	for(UINT idx = 0; idx < regSize; idx ++){
		strTmp.Format(_T("%d"), vReg[idx].m_RegNo);
		pCbb->AddString(strTmp);
		if(RegNo != vReg[idx].m_RegNo) continue;
		m_nRegNo = idx + 1;
	}

	// Update view
	UpdateData(FALSE);
	OnChangeRegNo();
	// Check state of all buttons
	CheckBtnState();

	return 0;
}

void CBLE_LocateEditWnd::OnRegNoButton(UINT nID)
{
	UpdateData();
	CString strRegNo;
	GetDlgItem(IDC_LEDIT_REGNO_CBB)->GetWindowText(strRegNo);
	m_nRegNo = atoi(strRegNo);

	switch(nID){
	case IDC_LEDIT_REGNO_UP:
		m_nRegNo ++;
		break;
	case IDC_LEDIT_REGNO_DOWN:
		m_nRegNo --;
		break;
	default:
		return;
	}
	m_LayoutWnd->SetRegNo(m_nRegNo);
	// Add content for regno combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_LEDIT_REGNO_CBB));
	pCbb->SetCurSel(m_nRegNo);

	// Change regno event
	OnChangeRegNo();

	// Redraw Layout
	//m_LayoutWnd->Invalidate();
}

CBLE_CommonWnd* CBLE_LocateEditWnd::GetCommdWnd()
{
	return &m_CommWnd;
}

CBLE_InfoWnd* CBLE_LocateEditWnd::GetInfoWnd()
{
	return &m_InfoWnd;
}

CBLE_LayoutWnd* CBLE_LocateEditWnd::GetLayoutWnd()
{
	return m_LayoutWnd;
}

void CBLE_LocateEditWnd::OnSize(UINT nType, int cx, int cy)
{
	if (!m_bInit) {
		return;
	}

	// Initialize a rect
	CRect rect;

	// Expand layout window
	m_LayoutWnd->GetWindowRect(rect);
	ScreenToClient(&rect);
	int oldWidth = rect.Width(); // store original width of layout window
	//int oldHeight = rect.Height(); // store original height of layout window
	//int size = min(cx - DBLE_EDITWND_OPERATION_SIZEX, cy - DBLE_EDITWND_OPERATION_SIZEY);
	//CRect layourRect(rect.TopLeft(), CSize(size, size));
	CRect layoutRect(rect.TopLeft(), CSize(cx - DBLE_EDITWND_OPERATION_SIZEX, cy - DBLE_EDITWND_OPERATION_SIZEY));
	m_LayoutWnd->MoveWindow(layoutRect);

	// Expand locate edit frame
	GetDlgItem(IDC_LEDIT_LOCATEDIT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	CRect leditRect(rect.TopLeft(), CSize(cx - DBLE_EDITWND_MARGIN_SIZEX, cy - DBLE_EDITWND_OPERATION_SIZEY));
	GetDlgItem(IDC_LEDIT_LOCATEDIT)->MoveWindow(leditRect,true);

	// Expand layout frame
	GetDlgItem(IDC_LEDIT_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	GetDlgItem(IDC_LEDIT_LAYOUT)->MoveWindow(layoutRect,true);

	// Expand infor window
	m_InfoWnd.GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.SetRect(0, cy - DBLE_EDITWND_INFO_HEIGHT, 0 + DBLE_EDITWND_INFO_WIDTH, cy);
	m_InfoWnd.MoveWindow(rect, true);

	// Expand 10-key window
	m_KeyWnd.GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.SetRect( cx - DBLE_EDITWND_10KEY_WIDTH, cy - DBLE_EDITWND_10KEY_HEIGHT /*- DBLE_EDITWND_INFO_HEIGHT*/, cx, cy /*- DBLE_EDITWND_INFO_HEIGHT*/);
	m_KeyWnd.MoveWindow(rect, true);

	// Expand buttons and text
	for (UINT idx = IDC_LEDIT_ZOOM_CBB; idx <= IDC_LEDIT_STATICOPERATION; idx++) {
		GetDlgItem(idx)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(idx)->MoveWindow(rect,true);
	}
	// Redraw
	Invalidate();
	CDialog::OnSize(nType, cx, cy);
}

// Display index of IC
void CBLE_LocateEditWnd::OnIndexDisplay()
{
	// Get status of button
	CButton* checkBox = (CButton*) GetDlgItem(IDC_LEDIT_INDEX_DISPLAY_BTN);
	m_LayoutWnd->SetIndexDisplay(checkBox->GetCheck());

	m_LayoutWnd->Invalidate();
	return;
}


// Get min and max size of dialog
void CBLE_LocateEditWnd::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	lpMMI->ptMinTrackSize.x = DBLE_EDITWND_SIZEX;
	lpMMI->ptMinTrackSize.y = DBLE_EDITWND_SIZEY;
}

int CBLE_LocateEditWnd::GetZoomScale()
{
	return m_nZoom;
}

void CBLE_LocateEditWnd::SetRegNo(int regNo)
{
	if (regNo > m_pDoc->GetData()->m_vRegIC.size() || regNo < 0) {
		return;
	}
	m_nRegNo = regNo;

	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_LEDIT_REGNO_CBB));
	pCbb->SetCurSel(m_nRegNo);

	int dispMode = m_LayoutWnd->GetMode();
	// Change regno event
	OnChangeRegNo();
	m_LayoutWnd->SetMode((DBLE_MODE)dispMode);
}

CBLE_NumKeyWnd* CBLE_LocateEditWnd::GetNumKeyWnd()
{
	return &m_KeyWnd;
}

//THAIHV 20151124 (A)
void CBLE_LocateEditWnd::DeleteSelectedIC()
{
	BOOL bEnable = FALSE;
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	int size = vIC.size();
	for(UINT idx = 0; idx < size; idx ++){
		if(vIC[idx]->m_Deleted) continue;
		bEnable = TRUE;
		break;
	}
	if(!bEnable){
		return;
	}
	// For undo function
	// Store state
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	CBLE_Memento mem = m_pDoc->GetData()->CreateMemento(IDD_LOCATE_EDIT_DLG);
	pCareTaker->SetMemento(mem);

	TRACE("[Edit][Delete]CBLE_ LocateEditWnd::On Delete()\n");
	// Update modified flag
	m_pDoc->SetModifiedFlag(1);
	for(idx = 0; idx < size; idx ++){
		vIC[idx]->Delete();
	}
	if(m_LayoutWnd->GetMode() == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID){
		// Deselect all deleted ICs
		m_pDoc->GetData()->GetSubstrate()->DeselectAll();
	}
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	// Update state for button
	CheckBtnState();
	// Update information window
	m_InfoWnd.UpdateGridData();
}

LRESULT CBLE_LocateEditWnd::OnChangeRevKeyWnd(WPARAM wParam,LPARAM lParam)
{
	if(wParam == (WPARAM)m_InfoWnd.m_hWnd) {
		m_KeyWnd.SetReceiveKeyWindow(m_InfoWnd.GetEditWnd());
	} else if (wParam == (WPARAM)m_CommWnd.m_hWnd) {
		m_KeyWnd.SetReceiveKeyWindow(m_CommWnd.GetEditWnd());
	}
	return 0;
}

void CBLE_LocateEditWnd::OnAllRestore()
{
	//int nType = AfxMessageBox(WARNING_MESSAGE_ALLRESTORE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
	int nType = theApp.CBTMessageBox(this->m_hWnd, AllRestore[m_pDoc->GetData()->m_Init.m_Language], MB_YESNO, m_pDoc->GetData()->m_Init.m_Language);
	if (nType == IDYES) {								// Re-input
		
		// For undo function
		// Store state
		CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
		CBLE_Memento mem = m_pDoc->GetData()->CreateMemento(IDD_LOCATE_EDIT_DLG, true, m_nRegNo);
		pCareTaker->SetMemento(mem);
		
		m_pDoc->GetData()->GetSubstrate()->RestoreAll(m_nRegNo);
		m_LayoutWnd->Invalidate();
	} else {
		return;
	}	
}

/*
* Change language
*/
void CBLE_LocateEditWnd::ChangeLanguage()
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	for (UINT id = IDC_LEDIT_LAYOUT; id <= IDC_LEDIT_LBL_LOCATEEDIT; id ++) {
		for (int idx = 0; idx < DBLE_LANGUAGE_ITEMS; idx ++) {
			if ((id == m_pDoc->m_DialogItems[idx].m_ID) && (m_pDoc->m_DialogItems[idx].m_Name.Compare("") != 0)) {
				GetDlgItem(id)->SetWindowText(m_pDoc->m_DialogItems[idx].m_Name);
				break;
			}
		}
	}
}

/**
* Do not allow select deleted ICs
*/
void CBLE_LocateEditWnd::AllowSelectDeletedIC()
{
	m_pDoc->GetData()->GetSubstrate()->m_bSelectDeleted = false;
}


/**
* Catch Ctrl + Z to restore
*/
BOOL CBLE_LocateEditWnd::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN /*&& pMsg->wParam == VK_CONTROL*/){
		if ((GetKeyState(0x5A) & 0x8000) && (GetKeyState(VK_CONTROL) & 0x8000)) {
			CBLE_FrameWnd *frame = (CBLE_FrameWnd*)GetParentFrame();
			frame->OnRestoreState();
		} else if ((GetKeyState(VK_DELETE) & 0x8000) ) {
			DeleteSelectedIC();
		}
    }	
    return CDialog::PreTranslateMessage(pMsg);
}

///////////////////////////////////////////////////////////
//  CBLE_Memento.cpp
//  Implementation of the Class CBLE_Memento and childs
//  Created on: 2013-11-01
//  Original author: DucDT
///////////////////////////////////////////////////////////
#pragma once
#include "stdafx.h"
#include "..\\BLE.h"
#include "swatch.h"
#include "CBLE_Memento.h"


CBLE_Memento::CBLE_Memento()
{
	// Default constructor
}

/**
* Destructor
*/
CBLE_Memento::~CBLE_Memento()
{
	// Default destructor
}

/**
* Constructor
*/
CBLE_Memento::CBLE_Memento(int kind, int type)
{
	m_Kind = kind;
	m_Type = type;

}

/**
* Get store kind (depend on window ID)
*/
int CBLE_Memento::GetStoreKind()
{
	return m_Kind;
}

/**
* Get type of data 
*/
int CBLE_Memento::GetType()
{
	return m_Type;
}

/** 
* Set data state
*/
void CBLE_Memento::SetState(void *state)
{
	m_pState = state;
}

/**
* Get data state
*/
void* CBLE_Memento::GetState()
{
	return m_pState;
}


CBLE_Memento::CBLE_Memento(const CBLE_Memento& mem)
{
	m_pState = const_cast<CBLE_Memento&>(mem).GetState();
	m_Kind = const_cast<CBLE_Memento&>(mem).GetStoreKind();
	m_Type = const_cast<CBLE_Memento&>(mem).GetType();
}

void CBLE_Memento::Clean()
{
	if (m_Type == DATA_TYPE) {
		vector<CBLE_IC> *vIC = static_cast<vector<CBLE_IC> *> (m_pState);
		delete vIC;
	} else if (m_Type == GRID_TYPE) {
		vector<TBLE_GridData> *v_Grid = static_cast<vector<TBLE_GridData> *>(m_pState);
		delete v_Grid;
	} else if (m_Type == MAPP_TYPE) {
		TBLE_Mapping *mapp = static_cast<TBLE_Mapping *> (m_pState);
		delete mapp;
	} else {
		// Nothing
	}
	return;
}


///////////////////////////////////////////////////////////////////////////////////////////
//
// Data store 
//
///////////////////////////////////////////////////////////////////////////////////////////

/**
* Default Constructor
*/
CBLE_DataStore::CBLE_DataStore()
{

}

/**
* Default destructor
*/
CBLE_DataStore::~CBLE_DataStore()
{

}

/**
* Create data store
*/
CBLE_DataStore::CBLE_DataStore(vector<CBLE_IC*> vIC, int kind, int type, bool all, int regNo) : CBLE_Memento(kind, type)
{
	//vector<CBLE_IC> *vCopyIC = new vector<CBLE_IC>;
	vector<CBLE_IC> *vpIC = new vector<CBLE_IC>;
	vector<CBLE_IC*>::iterator it;
	for (it = vIC.begin(); it != vIC.end(); it++) {
		if (all && regNo != 0 && regNo != (*it)->m_pRegIC->m_RegNo) {
			continue;
		}
		CBLE_IC ic(**it);
		vpIC->push_back(ic);
	}
	SetState(vpIC);
}


///////////////////////////////////////////////////////////////////////////////////////////
//
// Mapping store
//
///////////////////////////////////////////////////////////////////////////////////////////

/**
* Default Constructor
*/
CBLE_MapStore::CBLE_MapStore()
{

}

/**
* Default destructor
*/
CBLE_MapStore::~CBLE_MapStore()
{

}

/**
* Create MapStore
*/
CBLE_MapStore::CBLE_MapStore(TBLE_Mapping *mapping, int kind, int type) : CBLE_Memento(kind, type)
{
	SetState(mapping);
}

///////////////////////////////////////////////////////////////////////////////////////////
//
// Grid data store
//
///////////////////////////////////////////////////////////////////////////////////////////

/**
* Default Constructor
*/
CBLE_GridStore::CBLE_GridStore()
{

}

/**
* Default destructor
*/
CBLE_GridStore::~CBLE_GridStore()
{

}

/**
* Create GridStore with one item (specific by row, col)
*/
CBLE_GridStore::CBLE_GridStore(int row, int col, CString val, int kind, int type) : CBLE_Memento(kind, type)
{
	vector<TBLE_GridData> *vGrid = new vector<TBLE_GridData>;
	TBLE_GridData grid(row, col, val);
	vGrid->push_back(grid);
	SetState(vGrid);
}

/**
* Create GridStore with vector of GridData
*/
CBLE_GridStore::CBLE_GridStore(vector<TBLE_GridData> *v_Grid, int kind, int type) : CBLE_Memento(kind, type)
{
	SetState(v_Grid);
}

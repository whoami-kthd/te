///////////////////////////////////////////////////////////
//  CBLE_NumKeyWnd.cpp
//  Implementation of the Class CBLE_NumKeyWnd
//  Created on:      16-Thg7-2013 11:51:16 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_NumKeyWnd.h"
#include "CBLE_Doc.h"


/////////////////////////////////////////////////////////////////////////////
// CBLE_NumKeyWnd dialog


CBLE_NumKeyWnd::CBLE_NumKeyWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_NumKeyWnd::IDD, pParent)
{
	m_pRevWnd = NULL;
}

CBLE_NumKeyWnd::~CBLE_NumKeyWnd()
{

}


void CBLE_NumKeyWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBLE_NumKeyWnd, CDialog)
	ON_COMMAND_RANGE(IDC_NKEY_0, IDC_NKEY_ENT, OnKey)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_NumKeyWnd message handlers

void CBLE_NumKeyWnd::OnKey(UINT nID)
{
	if(m_pRevWnd == NULL) return;
	// Post message to the parent window
	::PostMessage(m_pRevWnd->m_hWnd, WM_UPDATE_KEY, (WPARAM)nID, 0);
}

BOOL CBLE_NumKeyWnd::Create(CWnd* pRevWnd, UINT nIDTemplate, CWnd* pParentWnd)
{
	m_pRevWnd = pRevWnd;
	return CDialog::Create(nIDTemplate, pParentWnd);
}

void CBLE_NumKeyWnd::OnCancel()
{
	// do nothing
}

void CBLE_NumKeyWnd::OnOK()
{
	// do nothing
}

// Set receive key window
void CBLE_NumKeyWnd::SetReceiveKeyWindow(CWnd* pRevWnd)
{
	m_pRevWnd = pRevWnd;
}

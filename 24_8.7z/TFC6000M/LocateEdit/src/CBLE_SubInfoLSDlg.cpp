///////////////////////////////////////////////////////////
//  CBLE_SubInfoLSDlg.cpp
//  Implementation of the Class CBLE_SubInfoLSDlg
//  Created on:      15-8-2013 14:11:08
//  Original author: DucDT
///////////////////////////////////////////////////////////
#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_SubInfoLSDlg.h"
#include "CBLE_Util.h"
#include "CBLE_SubInfoSaveDlg.h"
#include "CBLE_SubInfoWnd.h"
#include "CBLE_FileOpenDlg.h"

CString ShareMemoryLS[] =		{
								_T("�}�b�s���O�t�@�C�����J���܂���A�G���[(%d)"),
								_T("Could not open file mapping object, error (%d)"),
							};

CString MapViewLS[] =			{
								_T("�t�@�C���̃r���[���}�b�v�ł��܂���A�G���[(%d)"),
								_T("Could not map view of file, error (%d)"),
							};

CString TimeOutLS[] =		{
								_T("�^�C���A�E�g!"),
								_T("Time out!"),
							};

CString NGAnswerLS[] =		{
								_T("�X�e�[�^�X�f�[�^�����[�h�ł��܂���!"),
								_T("Cannot load status!"),
							};


CBLE_SubInfoLSDlg::CBLE_SubInfoLSDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_SubInfoLSDlg::IDD, pParent)
{
	m_pDoc = NULL;
	m_BondDetectMode = 0;
	m_nMode = DBLE_SUBINFO_TYPE_L;
	m_pParentWnd = NULL;
	m_pLoadStatusThread = NULL;
	m_ManualLoadBondHandle[0] = CreateEvent(NULL, false, false, "OK_BOND");
	m_ManualLoadBondHandle[1] = CreateEvent(NULL, false, false, "NG_BOND");
	m_ManualLoadDetectHandle[0] = CreateEvent(NULL, false, false, "OK_DETECT");
	m_ManualLoadDetectHandle[1] = CreateEvent(NULL, false, false, "NG_DETECT");
}

CBLE_SubInfoLSDlg::~CBLE_SubInfoLSDlg()
{
	::CloseHandle(m_ManualLoadBondHandle[0]);
	::CloseHandle(m_ManualLoadBondHandle[1]);
	::CloseHandle(m_ManualLoadDetectHandle[0]);
	::CloseHandle(m_ManualLoadDetectHandle[1]);
	if (m_pLoadStatusThread) {
		delete m_pLoadStatusThread;
	}
}

void CBLE_SubInfoLSDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CBLE_SubInfoLSDlg, CDialog)

	ON_COMMAND(IDC_SUBINFO_TABDLG_SAVE, OnSaveStatus)
	ON_COMMAND(IDC_SUBINFO_TABDLG_LOAD, OnLoadStatus)

END_MESSAGE_MAP()

// Load button thread
static UINT OnManualLoadStatusThread(LPVOID pParam);

/**
* Init dialog
*/

BOOL CBLE_SubInfoLSDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;

	// Init view
	InitView();
	// Delete pointer
	delete pContext;

	return TRUE;
}

/**
* Init dialog view
*/
void CBLE_SubInfoLSDlg::InitView()
{
	ShowWindow(SW_SHOW);
}

/**
* Set document
*/
void CBLE_SubInfoLSDlg::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

/**
* Get document
*/
CBLE_Doc* CBLE_SubInfoLSDlg::GetDocument()
{
	return m_pDoc;
}

/**
* Set parent window
*/
void CBLE_SubInfoLSDlg::SetParentWindow(CWnd *parent)
{
	m_pParentWnd = parent;
}

/**
* Set mode to load/save
*/
void CBLE_SubInfoLSDlg::SetStatusMode(int mode) 
{
	m_BondDetectMode = mode;
	// Label for button
	CString label;
	if (m_BondDetectMode == DBLE_SUBINFO_BOND_MODE) {
		label = _T("Bond");
	} else if (m_BondDetectMode == DBLE_SUBINFO_DETECT_MODE) {
		label = _T("Detect");
	}
	SetLabel(label);
	return;
}

/**
* Set LR mode
*/
void CBLE_SubInfoLSDlg::SetLRMode(DBLE_SUBINFO_TYPE mode) 
{
	m_nMode = mode;
	return;
}

void CBLE_SubInfoLSDlg::OnOK()
{
	// do nothing
}

void CBLE_SubInfoLSDlg::OnCancel()
{
	// do nothing
	CDialog::OnCancel();
}

/**
* Set label of button
*/
void CBLE_SubInfoLSDlg::SetLabel(CString label)
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		GetDlgItem(IDC_SUBINFO_TABDLG_LOAD)->SetWindowText("Load " + label);
		GetDlgItem(IDC_SUBINFO_TABDLG_SAVE)->SetWindowText("Save " + label);
	} else {
		GetDlgItem(IDC_SUBINFO_TABDLG_LOAD)->SetWindowText(label + "���[�h");
		GetDlgItem(IDC_SUBINFO_TABDLG_SAVE)->SetWindowText(label + "�Z�[�u");
	}
	return;
}

/** 
* Load status from file
*/
void CBLE_SubInfoLSDlg::OnLoadStatus()
{
	if (m_pLoadStatusThread) {
		delete m_pLoadStatusThread;
	}
	// Create thread to load status
	m_pLoadStatusThread = AfxBeginThread( 
			OnManualLoadStatusThread,		// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
	if (m_pLoadStatusThread) {
		// Don't auto delete after thread terminated
		m_pLoadStatusThread->m_bAutoDelete = FALSE;
		// Start thread
		m_pLoadStatusThread->ResumeThread();
	}
	return;
}

/**
* Save status
*/
void CBLE_SubInfoLSDlg::OnSaveStatus()
{
	CBLE_SubInfoSaveDlg saveDlg;
	saveDlg.SetDocument(m_pDoc);
	saveDlg.SetModeLR(m_nMode);
	saveDlg.SetStatusMode(m_BondDetectMode);
	if (saveDlg.DoModal() == IDC_SUBINFO_SAVE_OK_BTN) {

		// Save status data
		m_pDoc->GetData()->StatusRW(false, saveDlg.GetFileName(), m_nMode, m_BondDetectMode);
	}
	return;
}

/**
* Create load status thread
*/
UINT OnManualLoadStatusThread(LPVOID pParam)
{
	CBLE_SubInfoLSDlg *sub = (CBLE_SubInfoLSDlg *)pParam;
	sub->LoadStatus();
	return 0;
}

/**
* Load status
*/
void CBLE_SubInfoLSDlg::LoadStatus()
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	// Check TFC is running or not
	// If TFC is running, don't allow operator to load status

	// Find TFC
	bool r = true;
	CWnd * tfc = FindWindow(NULL, TFC_FRAMENAME);

	if (tfc != NULL) {
		// Send message for TFC to check it running or not
		if (m_nMode == DBLE_SUBINFO_TYPE_L) {
			tfc->PostMessage(WM_TFC_CTRL, USER_LOAD_L, DBLE_SUBINFO_ASK + m_BondDetectMode);
		} else {
			tfc->PostMessage(WM_TFC_CTRL, USER_LOAD_R, DBLE_SUBINFO_ASK + m_BondDetectMode);
		}
		// Reset events
		//ResetEvent(m_ManualLoadHandle[0]);
		//ResetEvent(m_ManualLoadHandle[1]);

		// Wait for response from TFC
		DWORD result;
		if (m_BondDetectMode == DBLE_SUBINFO_BOND_MODE) {
			result = WaitForMultipleObjects(2, &m_ManualLoadBondHandle[0], false, m_pDoc->GetData()->m_Init.m_TimeOutSubInfo * 1000);
		} else {
			result = WaitForMultipleObjects(2, &m_ManualLoadDetectHandle[0], false, m_pDoc->GetData()->m_Init.m_TimeOutSubInfo * 1000);
		}
		if (result == WAIT_TIMEOUT) {

			// Warning time out
			theApp.CBTMessageBox(this->m_hWnd, TimeOutLS[language], MB_OK, language);

			r = false;
		} else if (result == WAIT_OBJECT_0 + 1) {

			// Warning to operator
			theApp.CBTMessageBox(this->m_hWnd, NGAnswerLS[language], MB_OK, language);

			r = false;
		}
	}
	
	// Load status
	if (r) {
		CString fileName;

		// INFO_STATUS_EXTENTION
		CString         filter;
		filter.Format("Status Files (*%s)|*%s|All Files (*.*)|*.*||",INFO_STATUS_EXTENTION,INFO_STATUS_EXTENTION);
		// Create dialog to open file
		//CFileDialog dlg(TRUE, NULL, NULL, OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR | OFN_FILEMUSTEXIST | OFN_EXPLORER | OFN_ENABLEHOOK ,filter);
		
		CBLE_FileOpenDlg dlg(TRUE, NULL, NULL, OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR | OFN_FILEMUSTEXIST | OFN_EXPLORER | OFN_ENABLEHOOK ,filter);

		dlg.m_ofn.lpstrInitialDir = m_pDoc->GetData()->GetDataFilePath();
		dlg.m_Language = language;
		if(dlg.DoModal() == IDOK)
		{
			fileName = dlg.GetFileName();

			// Load status data
			m_pDoc->GetData()->StatusRW(true, fileName, m_nMode, m_BondDetectMode);
			
			// If TFC exist
			if (tfc != NULL) {
				// Create share memory for send status of ICs
				CString tmp;
				if (m_BondDetectMode == DBLE_SUBINFO_BOND_MODE) {
					if (m_nMode == DBLE_SUBINFO_TYPE_L) {
						tmp = GLOBAL_NAME_MANUAL_LOADBOND_L;
					} else {
						tmp = GLOBAL_NAME_MANUAL_LOADBOND_R;
					}
					m_hMapFileBond = CreateFileMapping(
						INVALID_HANDLE_VALUE,    // use paging file
						NULL,                    // default security
						PAGE_READWRITE,          // read/write access
						0,                       // maximum object size (high-order DWORD)
						MANUAL_LOAD_SIZE,        // maximum object size (low-order DWORD)
						tmp);					 // name of mapping object
					
					// If cannot create mapping file, show warning message and return
					if (m_hMapFileBond == NULL)
					{
						CString tmp;
						tmp.Format(ShareMemoryLS[language], GetLastError());
						//AfxMessageBox(tmp);
						theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
						// Write log file: pass in use
// #DDT140306: Fix write log file with share memory error
						theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, tmp/*ShareMemoryLS[language]*/, "", "");
						return;
					}
					m_pBufBond = (int*) MapViewOfFile(m_hMapFileBond,   // handle to map object
						FILE_MAP_ALL_ACCESS, // read/write permission
						0,
						0,
						MANUAL_LOAD_SIZE);
					if (m_pBufBond == NULL)
					{
						CString tmp;
						tmp.Format(MapViewLS[language], GetLastError());
						//AfxMessageBox(tmp);
						theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
						// Write log file: pass in use
						theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, MapViewLS[language], "", "");
						
						CloseHandle(m_hMapFileBond);
						return;
					}
				} else if (m_BondDetectMode == DBLE_SUBINFO_DETECT_MODE) {
					if (m_nMode == DBLE_SUBINFO_TYPE_L) {
						tmp = GLOBAL_NAME_MANUAL_LOADDETECT_L;
					} else {
						tmp = GLOBAL_NAME_MANUAL_LOADDETECT_R;
					}
					m_hMapFileDetect = CreateFileMapping(
						INVALID_HANDLE_VALUE,    // use paging file
						NULL,                    // default security
						PAGE_READWRITE,          // read/write access
						0,                       // maximum object size (high-order DWORD)
						MANUAL_LOAD_SIZE,        // maximum object size (low-order DWORD)
						tmp);					 // name of mapping object
					
					// If cannot create mapping file, show warning message and return
					if (m_hMapFileDetect == NULL)
					{
						CString tmp;
						tmp.Format(ShareMemoryLS[language], GetLastError());
						//AfxMessageBox(tmp);
						theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
						// Write log file: pass in use
// #DDT140306: Fix write log file with share memory error
						theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, tmp/*ShareMemoryLS[language]*/, "", "");
						return;
					}
					m_pBufDetect = (int*) MapViewOfFile(m_hMapFileDetect,   // handle to map object
						FILE_MAP_ALL_ACCESS, // read/write permission
						0,
						0,
						MANUAL_LOAD_SIZE);
					if (m_pBufDetect == NULL)
					{
						CString tmp;
						tmp.Format(MapViewLS[language], GetLastError());
						//AfxMessageBox(tmp);
						theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
						// Write log file: pass in use
						theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, MapViewLS[language], "", "");
						
						CloseHandle(m_hMapFileBond);
						return;
					}
					
				}
				
				// Write data to share memory
				vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vIC;
				int numberOfRegNo = m_pDoc->GetData()->m_vRegIC.size();
				int totalICs = vIC.size();
				int length = 0;
				int idx = 0;
				if (m_BondDetectMode == DBLE_SUBINFO_BOND_MODE) {
					for (idx = 0; idx < totalICs; idx++) {
						if (vIC[idx]->m_Deleted) {
							continue;
						} else {
							
							if (m_nMode == DBLE_SUBINFO_TYPE_L) {
								if (vIC[idx]->m_BondingL != BOND_NDONE_L) {
									m_pBufBond[length * 2 + 1] = idx;
									m_pBufBond[length * 2 + 2] = vIC[idx]->m_BondingL;
									length++;
								}
							} else {
								if (vIC[idx]->m_BondingR != BOND_NDONE_R) {
									m_pBufBond[length * 2 + 1] = idx;
									m_pBufBond[length * 2 + 2] = vIC[idx]->m_BondingR;
									length++;
								}
							}
							
						}
					}
					m_pBufBond[0] = length;
					// Close map file view
					UnmapViewOfFile(m_pBufBond);
					
				} else if (m_BondDetectMode == DBLE_SUBINFO_DETECT_MODE){
					for (idx = 0; idx < totalICs; idx++) {
						if (vIC[idx]->m_Deleted) {
							continue;
						} else {
							
							if (m_nMode == DBLE_SUBINFO_TYPE_L) {
								if (vIC[idx]->m_DetectL != DET_UNKN_L) {
									m_pBufDetect[length * 2 + 1] = idx;
									m_pBufDetect[length * 2 + 2] = vIC[idx]->m_DetectL;
									length++;
								}
							} else {
								if (vIC[idx]->m_DetectR != DET_UNKN_R) {
									m_pBufDetect[length * 2 + 1] = idx;
									m_pBufDetect[length * 2 + 2] = vIC[idx]->m_DetectR;
									length++;
								}
							}
							
						}
					}
					m_pBufDetect[0] = length;
					// Close map file view
					UnmapViewOfFile(m_pBufDetect);
				}
				
				//TODO: send to TFC ask to load new status of ICs
				if (m_nMode == DBLE_SUBINFO_TYPE_L) {
					tfc->PostMessage(WM_TFC_CTRL, USER_LOAD_L, m_BondDetectMode);
				} else {
					tfc->PostMessage(WM_TFC_CTRL, USER_LOAD_R, m_BondDetectMode);
				}
			}
			// Update layout
			((CBLE_SubInfoWnd *)m_pParentWnd)->OnUpdateView(0, 0);
		}	
	}
	return;
}

/**
* Process response from TFC
*/
void CBLE_SubInfoLSDlg::ProcessAns(int wParam, LPARAM lParam)
{
	if (wParam == OK_LOAD_L || wParam == OK_LOAD_R) {
		// OK event
		if (lParam == DBLE_SUBINFO_ASK + DBLE_SUBINFO_BOND_MODE) {
			SetEvent(m_ManualLoadBondHandle[0]);
		} else {
			SetEvent(m_ManualLoadDetectHandle[0]);
		}
	} else if (wParam == NG_LOAD_L || wParam == NG_LOAD_R) {

		// NG event
		if (lParam == DBLE_SUBINFO_ASK + DBLE_SUBINFO_BOND_MODE) {
			SetEvent(m_ManualLoadBondHandle[1]);
		} else {
			SetEvent(m_ManualLoadDetectHandle[1]);
		}
	}
}
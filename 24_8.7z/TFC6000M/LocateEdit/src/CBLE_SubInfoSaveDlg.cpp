///////////////////////////////////////////////////////////
//  CBLE_SubInfoSaveDlg.cpp
//  Implementation of the Class CBLE_SubInfoSaveDlg
//  Created on:      2013-09-19
//  Original author: DucDT
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_SubInfoSaveDlg.h"

#define DBLE_SUBINFO_FONT_SIZE	80
#define DBLE_SUBINFO_FONT_NAME	_T("MS Sans Serif")
/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString FileNameEmpty[] =	{							
								_T("�t�@�C��������ł��B�ē��͂��Ă��������I"),
								_T("File name is empty. Please input again!"),
							};

/////////////////////////////////////////////////////////////////////////////
// CBLE_SubInfoSaveDlg dialog

CBLE_SubInfoSaveDlg::CBLE_SubInfoSaveDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_SubInfoSaveDlg::IDD, pParent)
{
	m_pDoc = NULL;
	m_FileName = CString("");
	m_SubInfoMode = DBLE_SUBINFO_TYPE_L;
	m_BondDetectMode = DBLE_SUBINFO_BOND_MODE;
}

CBLE_SubInfoSaveDlg::~CBLE_SubInfoSaveDlg()
{

}


void CBLE_SubInfoSaveDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//DDX_Text(pDX, IDC_SUBINFO_SAVE_EDIT, m_FileName);
}


BEGIN_MESSAGE_MAP(CBLE_SubInfoSaveDlg, CDialog)
	ON_WM_LBUTTONDOWN()
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateValue)
	ON_BN_CLICKED(IDC_SUBINFO_SAVE_CANCEL_BTN, OnSaveCancel)
	ON_BN_CLICKED(IDC_SUBINFO_SAVE_OK_BTN, OnSaveOK)
	ON_WM_CLOSE()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_SubInfoSaveDlg message handlers

BOOL CBLE_SubInfoSaveDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	// Create key window
	CRect rect;
	GetDlgItem(IDC_SUBINFO_FULLKEY_DLG)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(m_Edit.GetEditWnd(), IDD_FKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);

	// Create the edit box
	m_Edit.Create(IDD_EDIT_BOX_DLG, this);
	m_Edit.SetWindowPos(&CWnd::wndBottom, 0, 0, 0, 0, SWP_DRAWFRAME);
	m_Edit.SetEditFont(DBLE_SUBINFO_FONT_SIZE, DBLE_SUBINFO_FONT_NAME);
	m_Edit.SetRevWnd(this);
	// Not integer field
	m_Edit.SetIntegerMode(false);
	// Use full key board
	m_Edit.SetMode(1);

	// Initialize view and update data
	InitView();
	UpdateData(FALSE);

	return TRUE;
}

void CBLE_SubInfoSaveDlg::OnCancel()
{
	// Do nothing
	CDialog::OnCancel();
}

void CBLE_SubInfoSaveDlg::OnOK()
{
	// Do nothing
	CDialog::OnOK();
}

void CBLE_SubInfoSaveDlg::OnClose()
{
	CDialog::OnClose();
}

void CBLE_SubInfoSaveDlg::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

void CBLE_SubInfoSaveDlg::InitView()
{
	//m_Edit.ShowWindow(SW_SHOW);
	CString label = "";
	if (m_BondDetectMode == DBLE_SUBINFO_BOND_MODE) {
		if (m_SubInfoMode == DBLE_SUBINFO_TYPE_L) {
			label = "BOND_L";
		} else {
			label = "BOND_R";
		}
	} else {
		if (m_SubInfoMode == DBLE_SUBINFO_TYPE_L) {
			label = "DETECT_L";
		} else {
			label = "DETECT_R";
		}
	}
	m_Edit.SetText(label);
	m_FileName = label;
	GetDlgItem(IDC_SUBINFO_SAVE_EDIT)->SetWindowText(label);
	ShowWindow(SW_SHOW);
}

void CBLE_SubInfoSaveDlg::UpdateView()
{
	UpdateData(FALSE);
}

void CBLE_SubInfoSaveDlg::OnSaveCancel()
{
	EndDialog(IDC_SUBINFO_SAVE_CANCEL_BTN);
	//CDialog::OnCancel();
	//this->DestroyWindow();
}

void CBLE_SubInfoSaveDlg::OnSaveOK()
{
	if (m_FileName == "") {
		// Warning
		//AfxMessageBox("File name is empty. Please input again!", IDOK);
		theApp.CBTMessageBox(this->m_hWnd, FileNameEmpty[m_pDoc->GetData()->m_Init.m_Language], MB_OK, m_pDoc->GetData()->m_Init.m_Language);
	} else {
		m_FileName += INFO_STATUS_EXTENTION;
		EndDialog(IDC_SUBINFO_SAVE_OK_BTN);
	}
	return;
}


LRESULT CBLE_SubInfoSaveDlg::OnUpdateValue(WPARAM wParam, LPARAM lParam)
{
	m_FileName = m_Edit.GetText();
	GetDlgItem(IDC_SUBINFO_SAVE_EDIT)->SetWindowText(m_FileName);
	m_Edit.MoveWindow(CRect(0, 0, 0, 0));
	m_Edit.ShowWindow(SW_HIDE);
	return 0;
}

// Handle when left mouse down
void CBLE_SubInfoSaveDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	CRect rect;
	GetDlgItem(IDC_SUBINFO_SAVE_EDIT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	if (rect.PtInRect(point)) {
		ClientToScreen(&rect);
		m_Edit.MoveWindow(rect);
		CString text;
		GetDlgItem(IDC_SUBINFO_SAVE_EDIT)->GetWindowText(text);
		m_Edit.SetText(text);
		m_Edit.GetEditWnd()->SetFocus();
		m_Edit.ShowWindow(SW_SHOW);
	} else {
		m_Edit.MoveWindow(CRect(0, 0, 0, 0));
		m_Edit.ShowWindow(SW_HIDE);
	}
	return;
}

CString CBLE_SubInfoSaveDlg::GetFileName()
{
	return m_FileName;
}

void CBLE_SubInfoSaveDlg::SetModeLR(DBLE_SUBINFO_TYPE lr)
{
	m_SubInfoMode = lr;
}

void CBLE_SubInfoSaveDlg::SetStatusMode(int mode)
{
	m_BondDetectMode = mode;
}
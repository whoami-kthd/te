///////////////////////////////////////////////////////////
//  CBLE_SubInfoWnd.cpp
//  Implementation of the Class CBLE_SubInfoWnd
//  Created on:      15-8-2013 14:11:08
//  Original author: DucDT
///////////////////////////////////////////////////////////
#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_SubInfoWnd.h"
#include "CBLE_Util.h"
#include "CBLE_FrameWnd.h"

#define DBLE_SUBINFOWND_MINSCALE					1.0

#define DBLE_SUBINFOWND_OPERATION_SIZEX				260//350		//#DMV170720-Display issue
#define DBLE_SUBINFOWND_INFO_SIZEY					90
#define DBLE_SUBINFOWND_INFO_MARGIN					1

/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString NotRun[] =			{							
								_T("TFC�����s���Ă��܂���B"),
								_T("TFC is not running now"),
							};

CString NGAnswerAutoRun[] =	{
								_T("���uPC���������[�h�Ŏ��s���Ă��܂��B"),
								_T("Equipment PC is running in autorun mode. Stop it before set status."),
							};

CString NGAnswerStepRun[] =	{
								_T("���uPC���X�e�b�v���[�h�Ŏ��s���Ă��܂��B"),
								_T("Equipment PC is running in step mode. Stop it before set status."),
							};

CString NGAnswerFrame[] =	{
								_T("���u�̓t���[��������܂���B"),
								_T("Equipment PC has not a frame!"),
							};

CString NGAnswerScreen[] =	{
								_T("���uPC�̎��s���Ă����ʂ͎�����ʂƃX�e�b�v��ʂł͂���܂���B"),
								_T("Equipment PC is not in AutoRun screen or StepMode screen!"),
							};

CString NGAnswerNotLoad[] =	{
								_T("ϯ��ݸ�Ӱ�ގ��͎d�l�ł��܂���.\n�i��ݒ��[SubMapDataLoading]�����s���Ă�������."),
								_T("No use Mapping Mode.\nExecute [SubMapDataLoading] on Manual."),
							};

CString ShareMemory[] =		{
								_T("�}�b�s���O�t�@�C�����J���܂���A�G���[(%d)"),
								_T("Could not open file mapping object, error (%d)"),
							};

CString MapView[] =			{
								_T("�t�@�C���̃r���[���}�b�v�ł��܂���A�G���[(%d)"),
								_T("Could not map view of file, error (%d)"),
							};

CString SubInfoTitleL[] =	{
							//	_T("��SubInfo"),
							//	_T("SubInfo Left"),
								_T("SubInfo"),
								_T("SubInfo"),
							};

CString SubInfoTitleR[] =	{
								_T("�ESubInfo"),
								_T("SubInfo Right"),
							};

CString ComplexMode[] =		{
								_T("TFC�ł�Complex���[�h�ł���܂���B"),
								_T("TFC is not in complex mode!"),
							};

CString IndexInvalid[] =	{
								_T("TFC�����IC�C���f�b�N�X�������ł��B"),
								_T("IC index from TFC is not valid"),
							};

CString TimeOutTFC[] =		{
								_T("�^�C���A�E�g�I\nTFC�̕Ԏ����҂��܂����H"),
								_T("Time out!\nDo you want to wait response from TFC?"),
							};
CString LoadDataFromTFC[] = {
								_T("TFC�̃f�[�^�����f�B���O�ł��܂���B"),
								_T("Can not load data from TFC."),
							};

CString LoadMap[] =			{
								_T("�}�b�v�f�[�^��ǂݎ��ł��܂���B"),
								_T("Can not load map data."),
							};

CString BarCode[] =			{
								_T("TFC�̐��Y�f�[�^�̓o�[�R�[�h������܂���B"),
								_T("TFC Product data has no barcode."),
							};

// Define string arrays for log file
static CString m_logDetectString[] = { 
	// Click on unknown button				Click on bad button					Click on Good button
	_T("Operation,SubInfo,Detect,Unknown,"), _T("Operation,SubInfo,Detect,Bad,"), _T("Operation,SubInfo,Detect,Good,")
};

static CString m_logBondString[] = {
	// Click on not done button			  Click on Fail button				Click on done button
	_T("Operation,SubInfo,Bond,NotDone,"),_T("Operation,SubInfo,Bond,Fail,"),_T("Operation,SubInfo,Bond,Done,"),
	// Click on stack button			Click on don't need button
	_T("Operation,SubInfo,Bond,Stack,"),_T("Operation,SubInfo,Bond,DontNeed,"), 
	// Click on reverse button
	_T("Operation, SubInfo, Bond, Reverse")
};

static CString m_logSetStatusString[] = {
	// Click on set substrate button			Click on set bad button
	_T("Operation,SubInfo,SetStatus,Substrate,"),_T("Operation,SubInfo,SetStatus,Bad,"),
	// Click on set good button				Click on set done button				Click on set not need button
	_T("Operation,SubInfo,SetStatus,Good,"),_T("Operation,SubInfo,SetStatus,Done,"),_T("Operation,SubInfo,SetStatus,NotNeed,"),
	// Click on reverse all button
	_T("Operation, SubInfo, SetStatus, Reverse,")
	// Click on all right done button
	_T("Operation, SubInfo, SetStatus, LeftBond,")
	// Click on all left done button
	_T("Operation, SubInfo, SetStatus, RightBond,")
};

static CString m_logLoadMapData = _T("Operation, SubInfo, LoadMapData, ,");
//static UINT NEAR WM_TFC_SUBINFO = RegisterWindowMessage("TFC_CTRL");

CBLE_SubInfoWnd::CBLE_SubInfoWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_SubInfoWnd::IDD, pParent)
{
	m_pDoc = NULL;
	m_nZoom = 0;
	m_nRegNo = 1;
	m_nMode = DBLE_SUBINFO_TYPE_L;
	m_LayoutWnd = NULL;
	m_StatusToSet = 0;
	m_ButtonID = 0;
	m_DisplayMode = 0;
	m_pBuf = NULL;
	m_MovedIndex = -1;
	m_pSetStatusThread = NULL;
	m_pLoadMapThread = NULL;
	m_pLoadStatusThread = NULL;
	// Initialize event
	m_Handle[0] = NULL;
	m_Handle[1] = NULL;
	m_StartLoadHandle = NULL;
	m_LoadMapHandle[0] = NULL;
	m_LoadMapHandle[1] = NULL;

	for (int i = 0; i < DBLE_SUBINFO_BTN_NO; i++) {
		m_Count[i] = 0;
	}
	m_bInit = false;
}

CBLE_SubInfoWnd::~CBLE_SubInfoWnd()
{
	::CloseHandle(m_Handle[0]);
	::CloseHandle(m_Handle[1]);
	::CloseHandle(m_LoadMapHandle[0]);
	::CloseHandle(m_LoadMapHandle[1]);
	::CloseHandle(m_StartLoadHandle);
	if (m_pSetStatusThread) {
		delete m_pSetStatusThread;
	}
	if (m_pLoadMapThread) {
		delete m_pLoadMapThread;
	}
	if (m_pLoadStatusThread) {
		delete m_pLoadStatusThread;
	}
}

void CBLE_SubInfoWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_CBIndex(pDX, IDC_SUBINFO_ZOOM_CBB, m_nZoom);
	DDX_CBIndex(pDX, IDC_SUBINFO_REGNO_CBB, m_nRegNo);
	DDX_Control(pDX, IDC_SUBINFO_TABCTRL, m_TabCtrl);
}

BEGIN_MESSAGE_MAP(CBLE_SubInfoWnd, CDialog)
	// Combobox event
	ON_CBN_SELCHANGE(IDC_SUBINFO_ZOOM_CBB, OnChangeZoom)
	ON_CBN_SELCHANGE(IDC_SUBINFO_REGNO_CBB, OnChangeRegNo)
	// Button event
	ON_COMMAND_RANGE(IDC_SUBINFO_ZOOM_IN, IDC_SUBINFO_ZOOM_OUT,	OnZoomButton)
	ON_COMMAND_RANGE(IDC_SUBINFO_REGNO_UP, IDC_SUBINFO_REGNO_DOWN, OnRegNoButton)
	ON_COMMAND_RANGE(IDC_SUBINFO_DISPLAY_DETECT_BTN, IDC_SUBINFO_DISPLAY_STACK_BTN, OnChangeDisplayMode)
	ON_COMMAND_RANGE(IDC_SUBINFO_DETECT_UNKNOW_BTN, IDC_SUBINFO_BOND_REVERSE_BTN, OnSetStatus)
	ON_COMMAND_RANGE(IDC_SUBINFO_SETSTATUS_SUBST_BTN, IDC_SUBINFO_SETSTATUS_RIGHTDONE_BTN, OnSetStatus)
	ON_COMMAND(IDC_SUBINFO_LOADMAP_BTN, OnLoadMap)
	// Select IC
	ON_MESSAGE(WM_UPDATE_SELECTED, OnChangeSelectIC)
	ON_MESSAGE(WM_DISPLAY_FOCUSIC, OnDisplayFocusIC)
	ON_MESSAGE(WM_UPDATE_VIEW, OnUpdateView)
	// Update zoom
	ON_MESSAGE(WM_UPDATE_ZOOM, OnUpdateZoom)
	// Load Substrate Map
	ON_COMMAND(IDC_SUBINFO_LOAD_SUB_MAP_BTN,OnLoadMap /*OnLoadSubstrateMap*/)
	
	// Tab control
	ON_NOTIFY(TCN_SELCHANGE, IDC_SUBINFO_TABCTRL, OnTcnSelchangeTabcontrol)

	ON_WM_DESTROY()

	ON_WM_PAINT()

	ON_WM_SIZE()

	ON_WM_GETMINMAXINFO()

END_MESSAGE_MAP()

BOOL CBLE_SubInfoWnd::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	
	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;
	
	CRect rect;
	
	// Create layout window
	GetDlgItem(IDC_SUBINFO_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_LayoutWnd = new CBLE_LayoutWnd();
	m_LayoutWnd->SetDocument(m_pDoc);
	m_LayoutWnd->SetSubInfoDir(m_nMode);
	m_LayoutWnd->Create(NULL, NULL,
		WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_SUBINFO_LAYOUT, pContext);
	
	// Create information window
	GetDlgItem(IDC_SUBINFO_INFO)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_InfoWnd.SetDocument(m_pDoc);
	m_InfoWnd.SetSubInfoDir(m_nMode);
	m_InfoWnd.Create(IDD_INFORMATION_DLG, this);
	m_InfoWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	
	// Change language
	m_InfoWnd.ChangeLanguage();
	m_InfoWnd.ShowWindow(SW_SHOW);
	
	// Add content for zoom combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_SUBINFO_ZOOM_CBB));
	for(UINT idx = 0; idx < m_pDoc->m_vZoom.size(); idx ++){
		CString str;
		str.Format(_T("x%2d"), m_pDoc->m_vZoom[idx]);
		pCbb->AddString(str);
	}
	// Initial zoom
	m_nZoom = 0;
	pCbb->SetCurSel(m_nZoom);
	// Add content for regno combobox
	// Get the pointer of RegNo combobox
	CComboBox* pCbbReg = ((CComboBox*)GetDlgItem(IDC_SUBINFO_REGNO_CBB));
	pCbbReg->AddString(_T("0"));
	vector<TBLE_RegIC> vReg = m_pDoc->GetData()->m_vRegIC;
	CString strTmp;
	for(idx = 0; idx < vReg.size(); idx ++){
		strTmp.Format(_T("%d"), vReg[idx].m_RegNo);
		pCbbReg->AddString(strTmp);
	}
	// Initial regno
	m_nRegNo = 0;
	pCbbReg->SetCurSel(m_nRegNo);
	
	// Tab control
	//m_DisplayDlg = new CBLE_SubInfoDispDlg(this);
	m_DisplayDlg.SetDocument(m_pDoc);
	m_DisplayDlg.SetParentWindow(this);
	m_DisplayDlg.Create(CBLE_SubInfoDispDlg::IDD, this);
	
	m_BondLS.SetDocument(m_pDoc);
	m_BondLS.Create(CBLE_SubInfoLSDlg::IDD, this);
	m_BondLS.SetLRMode(m_nMode);
	m_BondLS.SetStatusMode(DBLE_SUBINFO_BOND_MODE);
	m_BondLS.SetParentWindow(this);
	
	
	m_DetectLS.SetDocument(m_pDoc);
	m_DetectLS.Create(CBLE_SubInfoLSDlg::IDD, this);
	m_DetectLS.SetLRMode(m_nMode);
	m_DetectLS.SetStatusMode(DBLE_SUBINFO_DETECT_MODE);
	m_DetectLS.SetParentWindow(this);
	
	
	m_TabCtrl.InsertItem(0, _T("Display"), -1);
	//	m_TabCtrl.InsertItem(1, _T("Detect Status"), -1);    
	//	m_TabCtrl.InsertItem(2, _T("Bond Status"), -1);		 
	
	// Adjust tab position
	CRect tabRect;
	//m_TabCtrl.GetClientRect(&tabRect);
	GetDlgItem(IDC_SUBINFO_DISPLAY_PIC)->GetWindowRect(tabRect);
	ScreenToClient(&tabRect);
	//m_TabCtrl.AdjustRect(FALSE, &tabRect);
	
	m_DisplayDlg.MoveWindow(tabRect);
	m_DetectLS.MoveWindow(tabRect);
	m_BondLS.MoveWindow(tabRect);
	
	// Get subinfo display mode
	m_pDoc->GetData()->DisplayModeRW(true, m_nMode, m_DisplayMode);
	
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		m_LoadMapHandle[0] = CreateEvent(NULL, false, false, "OK-Map-L");
		m_LoadMapHandle[1] = CreateEvent(NULL, false, false, "NG-Map-L");
		m_StartLoadHandle = CreateEvent(NULL, false, false, "StartUpLoad-L");
		m_Handle[0] = CreateEvent(NULL, false, false, "OK-Set-L");
		m_Handle[1] = CreateEvent(NULL, false, false, "NG-Set-L");
	} else {
		m_LoadMapHandle[0] = CreateEvent(NULL, false, false, "OK-Map-R");
		m_LoadMapHandle[1] = CreateEvent(NULL, false, false, "NG-Map-R");
		m_StartLoadHandle = CreateEvent(NULL, false, false, "StartUpLoad-R");
		m_Handle[0] = CreateEvent(NULL, false, false, "OK-Set-R");
		m_Handle[1] = CreateEvent(NULL, false, false, "NG-Set-R");
	}
	
	// Set icon for left/right direction
	GetDlgItem(IDC_SUBINFO_FRMDIR_L)->GetWindowRect(rect);
	ScreenToClient(rect);
	m_FrmDirLR[0].Create("",WS_CHILD|WS_VISIBLE|WS_BORDER|SS_BITMAP|SS_CENTERIMAGE,rect,this);
	
	GetDlgItem(IDC_SUBINFO_FRMDIR_R)->GetWindowRect(rect);
	ScreenToClient(rect);
	m_FrmDirLR[1].Create("",WS_CHILD|WS_VISIBLE|WS_BORDER|SS_BITMAP|SS_CENTERIMAGE,rect,this);
	
	// Init view
	InitView();
	
	// Delete pointer
	delete pContext;
	
	m_bInit = true;
	
	// Resize windown
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		// Set dialog title for left side
		SetWindowText(SubInfoTitleL[m_pDoc->GetData()->m_Init.m_Language]);
		// Get window position
		if (!CBLE_Util::GetWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_SUBINFO_DLGL)) {
			// Set default position
			//SetWindowPos(NULL, 0, 0, DBLE_SUBINFOWND_SIZEX, DBLE_SUBINFOWND_SIZEY, SWP_NOSIZE | SWP_NOZORDER);
		}
	} else {
		// Set dialog title for right side
		SetWindowText(SubInfoTitleR[m_pDoc->GetData()->m_Init.m_Language]);
		// Get window position
		if (!CBLE_Util::GetWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_SUBINFO_DLGR)) {
			// Set default position
			//SetWindowPos(NULL, DBLE_SUBINFOWND_SIZEX + 10, 0, DBLE_SUBINFOWND_SIZEX, DBLE_SUBINFOWND_SIZEY, SWP_NOSIZE | SWP_NOZORDER);
		}
	}
	//#THAIHV170815 Hide button not need in subinfo
	GetDlgItem(IDC_SUBINFO_BOND_DONTNEED_BTN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_SUBINFO_BOND_REVERSE_BTN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_ALLDONTNEED_BTN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_REVERSE_BTN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_SUBINFO_DONTNEED)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_SUBST_BTN)->ShowWindow(SW_HIDE);
	//#THAIHV170815 Hide RegNo and IC type
	GetDlgItem(IDC_SUBINFO_REGNO_UP)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_SUBINFO_REGNO_DOWN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_SUBINFO_REGNO_CBB)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_SUBINFO_STATICREGNO)->ShowWindow(SW_HIDE);
	//#THAIHV170818 Move Items in SubInfo mode (S)
	{
		UINT idx =0;
		for (idx = IDC_SUBINFO_DETECT_UNKNOW_BTN; idx <= IDC_SUBINFO_DETECT_GOOD_BTN; idx++) {
			if (GetDlgItem(idx) != NULL) {
				GetDlgItem(idx)->GetWindowRect(rect);
				ScreenToClient(&rect);
				rect.OffsetRect(0, -20);
				GetDlgItem(idx)->MoveWindow(rect,true);
			}
		}
		for (idx = IDC_SUBINFO_UNKNOWN; idx <= IDC_SUBINFO_DETECT; idx++) {
			if (GetDlgItem(idx) != NULL) {
				GetDlgItem(idx)->GetWindowRect(rect);
				ScreenToClient(&rect);
				rect.OffsetRect(0, -20);
				GetDlgItem(idx)->MoveWindow(rect,true);
			}
		}
		for (idx = IDC_SUBINFO_DETECTBOX; idx <= IDC_SUBINFO_ALLSETBOX; idx++) {
			if (GetDlgItem(idx) != NULL) {
				GetDlgItem(idx)->GetWindowRect(rect);
				ScreenToClient(&rect);
				rect.OffsetRect(0, -20);
				GetDlgItem(idx)->MoveWindow(rect,true);
			}
		}
		for (idx = IDC_SUBINFO_BOND_NOTDONE_BTN; idx <= IDC_SUBINFO_BOND_DONE_BTN; idx++) {
			if (GetDlgItem(idx) != NULL) {
				GetDlgItem(idx)->GetWindowRect(rect);
				ScreenToClient(&rect);
				rect.OffsetRect(0, -20);
				GetDlgItem(idx)->MoveWindow(rect,true);
			}
		}
		for (idx = IDC_SUBINFO_NOTDONE; idx <= IDC_SUBINFO_SETSTATUS; idx++) {
			if (GetDlgItem(idx) != NULL) {
				GetDlgItem(idx)->GetWindowRect(rect);
				ScreenToClient(&rect);
				rect.OffsetRect(0, -20);
				GetDlgItem(idx)->MoveWindow(rect,true);
			}
		}
		for (idx = IDC_SUBINFO_SETSTATUS_ALLBAD_BTN; idx <= IDC_SUBINFO_SETSTATUS_ALLDONE_BTN; idx++) {
			if (GetDlgItem(idx) != NULL) {
				GetDlgItem(idx)->GetWindowRect(rect);
				ScreenToClient(&rect);
				rect.OffsetRect(0, -15);
				GetDlgItem(idx)->MoveWindow(rect,true);
			}
		}
		for (idx = IDC_SUBINFO_SETSTATUS_LEFTDONE_BTN; idx <= IDC_SUBINFO_SETSTATUS_RIGHTDONE_BTN; idx++) {
			if (GetDlgItem(idx) != NULL) {
				GetDlgItem(idx)->GetWindowRect(rect);
				ScreenToClient(&rect);
				rect.OffsetRect(0, -50);
				GetDlgItem(idx)->MoveWindow(rect,true);
			}
		}
		for (idx = IDC_LED_DISP_BTN; idx <= IDC_LED_LBL_DISP; idx++) {
			if (GetDlgItem(idx) != NULL) {
				GetDlgItem(idx)->GetWindowRect(rect);
				ScreenToClient(&rect);
				rect.OffsetRect(0, -15);
		//		GetDlgItem(idx)->MoveWindow(rect,true);
			}
		}
	}
	//	GetDlgItem(IDC_SUBINFO_LOAD_SUB_MAP_BTN)->GetWindowRect(rect);
	//	ScreenToClient(&rect);
	//	rect.OffsetRect(0, -150);
	//	GetDlgItem(IDC_SUBINFO_LOAD_SUB_MAP_BTN)->MoveWindow(rect,true);
	//IDC_SUBINFO_LOAD_SUB_MAP_BTN
	return TRUE;
}

/**
* Initialize view
*/
void CBLE_SubInfoWnd::InitView()
{
	// Set default display mode
	m_TabCtrl.SetCurSel(0);
	m_DisplayDlg.ShowWindow(SW_SHOW);
	m_DisplayDlg.CheckBtnState();
	m_DetectLS.ShowWindow(SW_HIDE);
	m_BondLS.ShowWindow(SW_HIDE);
	m_LayoutWnd->SetMode(DBLE_MODE(m_DisplayMode + 2));
	CheckBtnState();
	m_InfoWnd.UpdateGridData();
	SetFrameDirection(m_pDoc->GetData()->GetFrmDir((m_nMode == DBLE_SUBINFO_TYPE_L) ? eLeftMode : eRightMode));
	Invalidate();
	//m_LayoutWnd->ShowWindow(SW_HIDE);
	ShowWindow(SW_SHOW);
}

/**
* Update combo box
*/
void CBLE_SubInfoWnd::UpdateSubInfo()
{
	// Update title
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		// Set dialog title for left side
		SetWindowText(SubInfoTitleL[m_pDoc->GetData()->m_Init.m_Language]);
	} else {
		// Set dialog title for right side
		SetWindowText(SubInfoTitleR[m_pDoc->GetData()->m_Init.m_Language]);
	}
	m_InfoWnd.ChangeLanguage();
	// Update zoom
	// Add content for zoom combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_SUBINFO_ZOOM_CBB));
	pCbb->ResetContent();
	for(UINT idx = 0; idx < m_pDoc->m_vZoom.size(); idx ++){
		CString str;
		str.Format(_T("x%2d"), m_pDoc->m_vZoom[idx]);
		pCbb->AddString(str);
	}
	// Initial zoom
	// #DDT(150814): Keep zoom ratio
	if ((0 > m_nZoom) || (m_nZoom >= m_pDoc->m_vZoom.size())) {
		m_nZoom = 0;
	}
	pCbb->SetCurSel(m_nZoom);
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom], true);
	// Update RegNo
	// Add content for regno combobox
	// Get the pointer of RegNo combobox
	CComboBox* pCbbReg = ((CComboBox*)GetDlgItem(IDC_SUBINFO_REGNO_CBB));
	pCbbReg->ResetContent();
	pCbbReg->AddString(_T("0"));
	vector<TBLE_RegIC> vReg = m_pDoc->GetData()->m_vRegIC;
	CString strTmp;
	for(idx = 0; idx < vReg.size(); idx ++){
		strTmp.Format(_T("%d"), vReg[idx].m_RegNo);
		pCbbReg->AddString(strTmp);
	}
	// Initial regno
	m_nRegNo = 0;
	pCbbReg->SetCurSel(m_nRegNo);
	m_LayoutWnd->SetRegNo(m_nRegNo);
	if (m_pLoadStatusThread) {
		delete m_pLoadStatusThread;
	}
	// Start thread to ask TFC for current status of ICs
	m_pLoadStatusThread = AfxBeginThread( 
			OnLoadStatusThread,				// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
	if (m_pLoadStatusThread) {
		// Don't auto delete after thread terminated
		m_pLoadStatusThread->m_bAutoDelete = FALSE;
		// Start thread
		m_pLoadStatusThread->ResumeThread();
	}
	UpdateData(false);
	CheckBtnState();
}

/**
* Set document for window
*/
void CBLE_SubInfoWnd::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

/**
* Get document
*/
CBLE_Doc* CBLE_SubInfoWnd::GetDocument()
{
	return m_pDoc;
}

/**
* Set mode (Left/Right) for SubInfo window
*/
void CBLE_SubInfoWnd::SetMode(DBLE_SUBINFO_TYPE mode) 
{
	m_nMode = mode;
}

/**
* OnOK
*/
void CBLE_SubInfoWnd::OnOK()
{
	// Do nothing
}

/**
* Cancel window
*/
void CBLE_SubInfoWnd::OnCancel()
{
	// Save window position
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_SUBINFO_DLGL);
	} else {
		CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_SUBINFO_DLGR);
	}
	// Save color
	m_pDoc->GetData()->SaveColor();
	// Save display mode
	m_pDoc->GetData()->DisplayModeRW(false, m_nMode, m_DisplayMode);

	// Cancel tabs window
	m_DisplayDlg.OnCancel();
	m_BondLS.OnCancel();
	m_DetectLS.OnCancel();
	// Cancel window
	CDialog::OnCancel();
}

/**
* Destroy window
*/
void CBLE_SubInfoWnd::OnDestroy()
{
	// Save window position
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_SUBINFO_DLGL);
	} else {
		CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_SUBINFO_DLGR);
	}
	// Save color
	m_pDoc->GetData()->SaveColor();
	// Save display mode
	m_pDoc->GetData()->DisplayModeRW(false, m_nMode, m_DisplayMode);
	// Delete bitmap
	HBITMAP bitmap = m_FrmDirLR[0].GetBitmap();
	if (bitmap) {
		DeleteObject(bitmap);
	}
	bitmap = m_FrmDirLR[1].GetBitmap();
	if (bitmap) {
		DeleteObject(bitmap);
	}
	// Destroy window
	CDialog::OnDestroy();
}

/**
* Change color
*/
void CBLE_SubInfoWnd::OnChangeColor(UINT nID, COLORREF color)
{
	switch(nID) {
		case IDC_SUBINFO_DISPLAY_UNKNOW_COLOR:
			m_pDoc->GetData()->m_StatusColor.m_UnknownClr = color;
			break;
		case IDC_SUBINFO_DISPLAY_BAD_COLOR:
			m_pDoc->GetData()->m_StatusColor.m_BadClr = color;
			break;
		case IDC_SUBINFO_DISPLAY_GOOD_COLOR:
			m_pDoc->GetData()->m_StatusColor.m_GoodClr = color;
			break;
		case IDC_SUBINFO_DISPLAY_FAIL_COLOR:
			m_pDoc->GetData()->m_StatusColor.m_FailClr = color;
			break;
		case IDC_SUBINFO_DISPLAY_DONE_COLOR:
			m_pDoc->GetData()->m_StatusColor.m_DoneClr = color;
			break;
		case IDC_SUBINFO_DISPLAY_NOTDONE_COLOR:
			m_pDoc->GetData()->m_StatusColor.m_NotDoneClr = color;
			break;
		case IDC_SUBINFO_DISPLAY_DONTNEED_COLOR:
			m_pDoc->GetData()->m_StatusColor.m_NoNeedClr = color;
			break;
		case IDC_SUBINFO_DISPLAY_STACK_COLOR:
			m_pDoc->GetData()->m_StatusColor.m_StackClr = color;
			break;
		default:
			break;
	}
	//OnPaint();
	// Redraw layout
	m_LayoutWnd->Invalidate();

	// Send message to frame to ask other side change color
	CBLE_FrameWnd *frame = (CBLE_FrameWnd*)GetParentFrame();
	frame->PostMessage(WM_COLOR_CHANGE, 1, 0);
}

/**
* Change display mode (0:Detect 1:Bond 2:Stack)
*/
void CBLE_SubInfoWnd::OnChangeDisplayMode(UINT nID)
{
	// Set mode display for layout
	switch(nID){
		case IDC_SUBINFO_DISPLAY_DETECT_BTN:
			m_DisplayMode = 0;
			break;
		case IDC_SUBINFO_DISPLAY_BOND_BTN:
			m_DisplayMode = 1;
			break;
		case IDC_SUBINFO_DISPLAY_STACK_BTN:
			m_DisplayMode = 2;
			break;
		default:
			return;
	}
	
	m_LayoutWnd->SetMode(DBLE_MODE(m_DisplayMode + 2));
	// Redraw Layout
	m_LayoutWnd->Invalidate();

}

/**
* Handle RegNo button
*/
void CBLE_SubInfoWnd::OnRegNoButton(UINT nID)
{
	UpdateData();
	CString strRegNo;

	// Get current RegNo
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_SUBINFO_REGNO_CBB));
	pCbb->GetWindowText(strRegNo);
	m_nRegNo = atoi(strRegNo);
	
	//  Update RegNo
	switch(nID){
		case IDC_SUBINFO_REGNO_UP:
			m_nRegNo++;
			break;
		case IDC_SUBINFO_REGNO_DOWN:
			m_nRegNo--;
			break;
		default:
			return;
	}

	// Set RegNo for layout
	m_LayoutWnd->SetRegNo(m_nRegNo);
	pCbb->SetCurSel(m_nRegNo);

	// Redraw Layout
	m_LayoutWnd->Invalidate();

	// Update button state
	CheckBtnState();
}

/**
* Zoom button
*/
void CBLE_SubInfoWnd::OnZoomButton(UINT nID)
{
	switch(nID){
		case IDC_SUBINFO_ZOOM_IN:
			m_nZoom++;
			break;
		case IDC_SUBINFO_ZOOM_OUT:
			m_nZoom--;
			break;
		default:
			return;
	}
	// Set Scale
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom], true);
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	UpdateData(FALSE);
	CheckBtnState();
}

/**
* Change RegNo (combo box)
*/
void CBLE_SubInfoWnd::OnChangeRegNo()
{
	UpdateData();
	// Set RegNo to Layout
	m_LayoutWnd->SetRegNo(m_nRegNo);
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	CheckBtnState();
}

/**
* Change zoom (combo box)
*/
void CBLE_SubInfoWnd::OnChangeZoom()
{
	UpdateData();
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],true);
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	CheckBtnState();
}

/**
* #TIENBV20151125 Get information of IC selected.
*/
CString CBLE_SubInfoWnd::GetInfoTopLeftSelIC()
{
	//Get information of top left IC selected
	UINT nSelICSize = 0;
	//UINT nICTopLeftIdx = 0;	
	CString strText = "";
	
	vector<CBLE_IC*> vSelIC; 
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		vSelIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICL;
	} else if (m_nMode == DBLE_SUBINFO_TYPE_R) {
		vSelIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICR;
	}

	nSelICSize = vSelIC.size();
	if (nSelICSize != 0) {
		int nICIdx       = vSelIC.at(0)->m_indexX;
		int nICIdy       = vSelIC.at(0)->m_indexY;
		int nICRegNo     = vSelIC.at(0)->m_pRegIC->m_RegNo;
		
		int nICIdxTemp   = 0;
		int nICIdyTemp   = 0;
		int nICRegNoTemp = 0;
		
		
		for ( UINT idx = 0; idx < nSelICSize; idx++) {
			nICIdxTemp   = vSelIC.at(idx)->m_indexX;
			nICIdyTemp   = vSelIC.at(idx)->m_indexY;
			nICRegNoTemp = vSelIC.at(idx)->m_pRegIC->m_RegNo;
			if ((nICRegNo >= nICRegNoTemp) && ( nICIdx >= nICIdxTemp ) && (nICIdy >= nICIdyTemp)) {
				nICIdx   = nICIdxTemp;
				nICIdy   = nICIdyTemp;
				nICRegNo = nICRegNoTemp;
				//nICTopLeftIdx = idx;
			}
		}
		//Make strText to write to log file
		strText.Format("%d,%d,%d,%d,\n", nICRegNo, nICIdx + 1, nICIdy + 1, nSelICSize);
	}
	return strText;
}



/**
* Set status to TFC
*/
void CBLE_SubInfoWnd::OnSetStatus(UINT nID)
{
	// Set button ID
	m_ButtonID = nID;
	if (m_pSetStatusThread) {
		delete m_pSetStatusThread;
	}
	m_pSetStatusThread = AfxBeginThread(
			OnSetStatusThread,				// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
	if (m_pSetStatusThread) {
		// Don't auto delete after thread terminated
		m_pSetStatusThread->m_bAutoDelete = FALSE;
		// Start thread
		m_pSetStatusThread->ResumeThread();
	}
	// Write log for detect button
	for (UINT id = IDC_SUBINFO_DETECT_UNKNOW_BTN; id <= IDC_SUBINFO_DETECT_GOOD_BTN; id ++) {
		if (nID == id) {
			//#TIENBV20151125 1.1_CD:: Get info of the top left IC selected and write to the log file
			CString strText = GetInfoTopLeftSelIC();
			// Write log
			theApp.p_Logger->SetLogFormat(m_logDetectString[id - IDC_SUBINFO_DETECT_UNKNOW_BTN] + strText);
		}
	}

	// Write log for bond button
	for (id = IDC_SUBINFO_BOND_NOTDONE_BTN; id <= IDC_SUBINFO_BOND_REVERSE_BTN; id ++) {
		if (nID == id) {
			//#TIENBV20151125 1.1_CD:: Get info of the top left IC selected and write to the log file
			CString strText = GetInfoTopLeftSelIC();
			// Write log
			theApp.p_Logger->SetLogFormat(m_logBondString[id - IDC_SUBINFO_BOND_NOTDONE_BTN] + strText);
		}
	}

	// Write log for set status button
	for (id = IDC_SUBINFO_SETSTATUS_SUBST_BTN; id <= IDC_SUBINFO_SETSTATUS_RIGHTDONE_BTN; id ++) {
		if (nID == id) {
            //#TIENBV20151125 1.1_CD:: Get info of the top left IC selected and write to the log file
			CString strText = GetInfoTopLeftSelIC();
			// Write log
			theApp.p_Logger->SetLogFormat(m_logSetStatusString[id - IDC_SUBINFO_SETSTATUS_SUBST_BTN] + strText);
		}
	}

	return;
}

/**
* Thread to set status
*/
UINT CBLE_SubInfoWnd::OnSetStatusThread(LPVOID pParam)
{
	CBLE_SubInfoWnd *sub = (CBLE_SubInfoWnd *)pParam;
	sub->SetStatusThread(sub->GetButtonID());
	return 0;
}

/** 
* Thread to load status when start from TFC
*/
UINT CBLE_SubInfoWnd::OnLoadStatusThread(LPVOID pParam)
{
	CBLE_SubInfoWnd *sub = (CBLE_SubInfoWnd *)pParam;
	sub->LoadStatusThread();
	return 0;
}

/**
* Get button ID
*/
int CBLE_SubInfoWnd::GetButtonID()
{
	return m_ButtonID;
}

/** 
* Get display mode
*/
DBLE_MODE CBLE_SubInfoWnd::GetDisplayMode()
{
	return DBLE_MODE(m_DisplayMode + 2);
}

/**
* Thread load status from TFC: wait for response from TFC
*/
void CBLE_SubInfoWnd::LoadStatusThread()
{
	// Find TFC window
	CWnd * tfc = FindWindow(NULL, TFC_FRAMENAME);

	if (tfc != NULL) {
		// Send message for TFC to load status
		if (m_nMode == DBLE_SUBINFO_TYPE_L) {
			tfc->PostMessage(WM_TFC_CTRL, STARTUP_LOAD_L, 0);
		} else {
			tfc->PostMessage(WM_TFC_CTRL, STARTUP_LOAD_R, 0);
		}
		// Wait for response from TFC
		DWORD result = WaitForSingleObject(m_StartLoadHandle, m_pDoc->GetData()->m_Init.m_TimeOutSubInfo * 1000);
		if (result == WAIT_TIMEOUT) {
			int language = m_pDoc->GetData()->m_Init.m_Language;
			theApp.CBTMessageBox(this->m_hWnd, LoadDataFromTFC[language], MB_OK, language);
		}
	}
	return;
}

/**
* Set status
*/
void CBLE_SubInfoWnd::SetStatusThread(UINT nID)
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	// Find TFC window
	CWnd * tfc = FindWindow(NULL, TFC_FRAMENAME);
	// Not found tfc, show message to user
	if (tfc == NULL) {
		//AfxMessageBox(DBLE_SUBINFOWND_NOTRUN_MESS, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, NotRun[language], MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, NotRun[language], "", "");
		return;
	} 

	// Check isSubComplex mode or not
	int complex = m_pDoc->GetData()->GetSubComplexMode();
	if (!complex) {
		//AfxMessageBox(DBLE_SUBINFOWND_COMPLEX_MESS, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, ComplexMode[language], MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ComplexMode[language], "", "");
		return;
	}

	// TODO: Write data to shared memory
	// Create mapping file
	CString tmp;
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		tmp = GLOBAL_NAME_L;
	} else {
		tmp = GLOBAL_NAME_R;
	}
	m_hMapFile = CreateFileMapping(
                 INVALID_HANDLE_VALUE,    // use paging file
                 NULL,                    // default security
                 PAGE_READWRITE,          // read/write access
                 0,                       // maximum object size (high-order DWORD)
                 BUF_SIZE,                // maximum object size (low-order DWORD)
                 tmp);					  // name of mapping object

	// If cannot create mapping file, show warning message and return
	if (m_hMapFile == NULL)
	{
		CString tmp;
		tmp.Format(ShareMemory[language], GetLastError());
		//AfxMessageBox(tmp);
		theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
		// Write log file: pass in use
// #DDT140306: Fix write log file with share memory error
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, tmp/*ShareMemory[language]*/, "", "");
		return;
	}
	m_pBuf = (int*) MapViewOfFile(m_hMapFile,   // handle to map object
                        FILE_MAP_ALL_ACCESS, // read/write permission
                        0,
                        0,
                        BUF_SIZE);
	if (m_pBuf == NULL)
	{
		CString tmp;
		tmp.Format(MapView[language], GetLastError());
		//AfxMessageBox(tmp);
		theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, MapView[language], "", "");

		CloseHandle(m_hMapFile);
		return;
	}
	vector<CBLE_IC*> vIC;
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICL;
	} else if (m_nMode == DBLE_SUBINFO_TYPE_R) {
		vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICR;;
	}
	int length = vIC.size();
	// Set RegNo need to change 
	if (length == 0) {
		m_pBuf[0] = m_nRegNo;
	} else {
		// Set ICs need to change
		m_pBuf[0] = length;
		for (int idx = 0; idx < length; idx++) {
			// TODO: write index of ICs
// #DDT131021: NOTICE update reverse function here
			m_pBuf[idx + 1] = m_pDoc->GetData()->CalIndex(*(vIC[idx]));
			//m_pBuf[idx + 1] = CalIndex(vIC[idx]);
		}
	}
	// Reset event before send message
	ResetEvent(m_Handle[0]);
	ResetEvent(m_Handle[1]);
	switch(nID) {
		// Unknown button
		case IDC_SUBINFO_DETECT_UNKNOW_BTN:
			m_StatusToSet = DBLE_DETECT_UNKNOWN;
			m_Count[DBLE_DETECT_UNKNOWN_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, DET_UNKN_L, m_Count[DBLE_DETECT_UNKNOWN_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, DET_UNKN_R, m_Count[DBLE_DETECT_UNKNOWN_BTN]);
			}
			break;
		// Bad button
		case IDC_SUBINFO_DETECT_BAD_BTN:
			m_StatusToSet = DBLE_DETECT_BAD;
			m_Count[DBLE_DETECT_BAD_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, DET_BAD_L, m_Count[DBLE_DETECT_BAD_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, DET_BAD_R, m_Count[DBLE_DETECT_BAD_BTN]);
			}
			break;
		// Good button
		case IDC_SUBINFO_DETECT_GOOD_BTN:
			m_StatusToSet = DBLE_DETECT_GOOD;
			m_Count[DBLE_DETECT_GOOD_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, DET_GOOD_L, m_Count[DBLE_DETECT_GOOD_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, DET_GOOD_R, m_Count[DBLE_DETECT_GOOD_BTN]);
			}
			break;
		// Not done button
		case IDC_SUBINFO_BOND_NOTDONE_BTN:
			m_StatusToSet = DBLE_BOND_NOTDONE;
			m_Count[DBLE_BOND_NOTDONE_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_NDONE_L, m_Count[DBLE_BOND_NOTDONE_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_NDONE_R, m_Count[DBLE_BOND_NOTDONE_BTN]);
			}
			break;
		// Fail button
		case IDC_SUBINFO_BOND_FAIL_BTN:
			m_StatusToSet = DBLE_BOND_FAIL;
			m_Count[DBLE_BOND_FAIL_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_FAIL_L, m_Count[DBLE_BOND_FAIL_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_FAIL_R, m_Count[DBLE_BOND_FAIL_BTN]);
			}
			break;
		// Done button
		case IDC_SUBINFO_BOND_DONE_BTN:
			m_StatusToSet = DBLE_BOND_DONE;
			m_Count[DBLE_BOND_DONE_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_DONE_L, m_Count[DBLE_BOND_DONE_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_DONE_R, m_Count[DBLE_BOND_DONE_BTN]);
			}
			break;
		// Stack button
		case IDC_SUBINFO_BOND_STACK_BTN:
			m_StatusToSet = DBLE_BOND_STACK;
			m_Count[DBLE_BOND_STACK_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_STACK_L, m_Count[DBLE_BOND_STACK_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_STACK_R, m_Count[DBLE_BOND_STACK_BTN]);
			}
			break;
		// Don't need button
		case IDC_SUBINFO_BOND_DONTNEED_BTN:
			m_StatusToSet = DBLE_BOND_NONEED;
			m_Count[DBLE_BOND_DONTNEED_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_SKIP_L, m_Count[DBLE_BOND_DONTNEED_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_SKIP_R, m_Count[DBLE_BOND_DONTNEED_BTN]);
			}
			break;
		// Reverse button
		case IDC_SUBINFO_BOND_REVERSE_BTN:
			m_StatusToSet = DBLE_BOND_REVERSE;
			m_Count[DBLE_BOND_REVERSE_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_REVERSE_L, m_Count[DBLE_BOND_REVERSE_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_REVERSE_R, m_Count[DBLE_BOND_REVERSE_BTN]);
			}
			break;
		// Set Subst button
		case IDC_SUBINFO_SETSTATUS_SUBST_BTN:
			m_StatusToSet = DBLE_ALLSET_SUBST;
			m_Count[DBLE_ALLSET_SUBST_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, SET_SUBST_L, m_Count[DBLE_ALLSET_SUBST_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, SET_SUBST_R, m_Count[DBLE_ALLSET_SUBST_BTN]);
			}
			break;
		// Set all bad button
		case IDC_SUBINFO_SETSTATUS_ALLBAD_BTN:
			m_StatusToSet = DBLE_ALLSET_BAD;
			m_Count[DBLE_ALLSET_BAD_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, DETECT_ALL_BAD_L, m_Count[DBLE_ALLSET_BAD_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, DETECT_ALL_BAD_R, m_Count[DBLE_ALLSET_BAD_BTN]);
			}
			break;
		// Set all good button
		case IDC_SUBINFO_SETSTATUS_ALLGOOD_BTN:
			m_StatusToSet = DBLE_ALLSET_GOOD;
			m_Count[DBLE_ALLSET_GOOD_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, DETECT_ALL_GOOD_L, m_Count[DBLE_ALLSET_GOOD_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, DETECT_ALL_GOOD_R, m_Count[DBLE_ALLSET_GOOD_BTN]);
			}
			break;
		// Set all done button
		case IDC_SUBINFO_SETSTATUS_ALLDONE_BTN:
			m_StatusToSet = DBLE_ALLSET_DONE;
			m_Count[DBLE_ALLSET_DONE_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_DONE_L, m_Count[DBLE_ALLSET_DONE_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_DONE_R, m_Count[DBLE_ALLSET_DONE_BTN]);
			}
			break;
		// Set all don't need button
		case IDC_SUBINFO_SETSTATUS_ALLDONTNEED_BTN:
			m_StatusToSet = DBLE_ALLSET_DONTNEED;
			m_Count[DBLE_ALLSET_DONTNEED_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_DONTNEED_L, m_Count[DBLE_ALLSET_DONTNEED_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_DONTNEED_R, m_Count[DBLE_ALLSET_DONTNEED_BTN]);
			}
			break;
		// Reverse all button
		case IDC_SUBINFO_SETSTATUS_REVERSE_BTN:
			m_StatusToSet = DBLE_ALLSET_REVERSE;
			m_Count[DBLE_ALLSET_REVERSE_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_REVERSE_L, m_Count[DBLE_ALLSET_REVERSE_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_REVERSE_R, m_Count[DBLE_ALLSET_REVERSE_BTN]);
			}
			break;
		// All left done button
		case IDC_SUBINFO_SETSTATUS_LEFTDONE_BTN:
			m_StatusToSet = DBLE_ALLSET_LEFTDONE;
			m_Count[DBLE_ALLSET_LEFTDONE_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_LEFTDONE_L, m_Count[DBLE_ALLSET_LEFTDONE_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_RIGHTDONE_L, m_Count[DBLE_ALLSET_LEFTDONE_BTN]);
			}
			break;
		// All right done button
		case IDC_SUBINFO_SETSTATUS_RIGHTDONE_BTN:
			m_StatusToSet = DBLE_ALLSET_RIGHTDONE;
			m_Count[DBLE_ALLSET_RIGHTDONE_BTN]++;
			if (m_nMode == DBLE_SUBINFO_TYPE_L) {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_LEFTDONE_R, m_Count[DBLE_ALLSET_RIGHTDONE_BTN]);
			} else {
				tfc->PostMessage(WM_TFC_CTRL, BOND_ALL_RIGHTDONE_R, m_Count[DBLE_ALLSET_RIGHTDONE_BTN]);
			}
			break;
		default: 
			break;
	}
	CheckBtnState();
	DWORD result = WaitForMultipleObjects(2, &m_Handle[0], false, m_pDoc->GetData()->m_Init.m_TimeOutSubInfo * 1000);
	while (result == WAIT_TIMEOUT) {
		//if (AfxMessageBox(DBLE_SUBINFO_TIMEOUT_MESS, MB_YESNO) == IDYES) {
		if (theApp.CBTMessageBox(this->m_hWnd, TimeOutTFC[language], MB_YESNO, language) == IDYES) {
			result = WaitForMultipleObjects(2, &m_Handle[0], false, m_pDoc->GetData()->m_Init.m_TimeOutSubInfo * 1000);
		} else {
			// Update button state
			CheckBtnState();

			// Reset status
			m_StatusToSet = 0;
			
			break;
		}
	}
	CheckBtnState();
}

/**
* Load status when start from TFC
*/
void CBLE_SubInfoWnd::LoadStatus(int wParam, LPARAM lParam)
{
	// If error 
	if (lParam == FALSE) {
		return;
	}
	int language = m_pDoc->GetData()->m_Init.m_Language;
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vIC;
	int length = vIC.size();
	// Create mapping file
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		m_hMapLoadFile = OpenFileMapping(
			FILE_MAP_ALL_ACCESS,	  // Access right to file mapping
			FALSE,					  // No inherit
			GLOBAL_NAME_LOAD_L);	  // name of mapping object
	} else {
		m_hMapLoadFile = OpenFileMapping(
			FILE_MAP_ALL_ACCESS,	  // Access right to file mapping
			FALSE,					  // No inherit
			GLOBAL_NAME_LOAD_R);	  // name of mapping object
	}
	// If cannot create mapping file, show warning message and return
	if (m_hMapLoadFile == NULL)
	{
		CString tmp;
		tmp.Format(ShareMemory[language], GetLastError());
		//AfxMessageBox(tmp);
		theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, tmp/*ShareMemory[language]*/, "", "");
		return;
	}
	m_pBufLoad = (int*) MapViewOfFile(m_hMapLoadFile,   // handle to map object
		FILE_MAP_ALL_ACCESS,			// read/write permission
		0,
		0,
		LOAD_SIZE);
	if (m_pBufLoad == NULL)
	{
		CString tmp;
		tmp.Format(MapView[language], GetLastError());
		//AfxMessageBox(tmp);
		theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, MapView[language], "", "");
		
		CloseHandle(m_hMapLoadFile);
		return;
	}
	int total = m_pBufLoad[0];
	if (total > 0) {
		if (m_nMode == DBLE_SUBINFO_TYPE_L) {
			for (int idx = 1; idx <= total * 4; idx += 4) {
				if (m_pBufLoad[idx] < length) {
					vIC[m_pBufLoad[idx]]->m_DetectL = (DBLE_DetectState)m_pBufLoad[idx + 1];
					vIC[m_pBufLoad[idx]]->m_BondingL = (DBLE_BondState)m_pBufLoad[idx + 2];
					vIC[m_pBufLoad[idx]]->m_StackCountL = m_pBufLoad[idx + 3];
				}
			}
		} else {
			for (int idx = 1; idx <= total * 4; idx += 4) {
				if (m_pBufLoad[idx] < length) {
					vIC[m_pBufLoad[idx]]->m_DetectR = (DBLE_DetectState)m_pBufLoad[idx + 1];
					vIC[m_pBufLoad[idx]]->m_BondingR = (DBLE_BondState)m_pBufLoad[idx + 2];
					vIC[m_pBufLoad[idx]]->m_StackCountR = m_pBufLoad[idx + 3];
				}
			}
		}
	}
	
	// Finish load, close mapping file
	UnmapViewOfFile(m_pBufLoad);
	CloseHandle(m_hMapLoadFile);
	
	// Set event load
	SetEvent(m_StartLoadHandle);
	// Re-draw layout
	m_LayoutWnd->Invalidate();
	return;
}

/**
* Set status
*/
void CBLE_SubInfoWnd::SetStatus(int wParam, LPARAM lParam)
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vIC;
	int length = 0;
	int idx = 0;
	if (wParam == OK_LOAD_L || wParam == OK_LOAD_R || wParam == NG_LOAD_L || wParam == NG_LOAD_R) {			// Message OK/NG from TFC to load status
		if (lParam == DBLE_SUBINFO_ASK + DBLE_SUBINFO_BOND_MODE) {
			m_BondLS.ProcessAns(wParam, lParam);
		} else if (lParam == DBLE_SUBINFO_ASK + DBLE_SUBINFO_DETECT_MODE) {
			m_DetectLS.ProcessAns(wParam, lParam);
		} else {
			// Do nothing
		}

	} else if (wParam == OK_LOADMAP_L || wParam == OK_LOADMAP_R){
		if (lParam == m_Count[DBLE_LOADMAP_BTN]) {
			// Set OK event
			SetEvent(m_LoadMapHandle[0]);
			// Copy data
			int pos;
			for (int idx = 0; idx < m_vIC.size(); idx++) {
				pos = m_pDoc->GetData()->CalIndex(m_vIC[idx]);
				m_pDoc->GetData()->GetSubstrate()->m_vIC[pos]->CopyData(m_vIC[idx]);
			}
			// Clear data
			m_vIC.clear();
			// Refresh layout
			m_LayoutWnd->Invalidate();
		}

	} else if (wParam == NG_LOADMAP_L || wParam == NG_LOADMAP_R) {
		if (lParam == m_Count[DBLE_LOADMAP_BTN]) {
			// Set NG event
			SetEvent(m_LoadMapHandle[1]);
			// Clear data
			m_vIC.clear();

			theApp.CBTMessageBox(this->m_hWnd, LoadMap[language], MB_OK, language);
		}
	} else if (wParam == BLE_OK_L || wParam == BLE_OK_R) {													// Message to answer OK from TFC
		// Set status to each ICs in left 
		
		bool r = true;
		switch (m_StatusToSet) {
			case DBLE_DETECT_UNKNOWN:
			case DBLE_DETECT_BAD:
			case DBLE_DETECT_GOOD:
				if (lParam != m_Count[m_StatusToSet - DBLE_DETECT_UNKNOWN + DBLE_DETECT_UNKNOWN_BTN]) {
					r = false;
					break;
				}
				length = m_pBuf[0];
				if (wParam == BLE_OK_L) {
					for (idx = 0; idx < length; idx++) {
						vIC[m_pBuf[idx + 1]]->m_DetectL = (DBLE_DetectState)m_StatusToSet;
					}
				} else if (wParam == BLE_OK_R) {
					for (idx = 0; idx < length; idx++) {
						vIC[m_pBuf[idx + 1]]->m_DetectR = (DBLE_DetectState)m_StatusToSet;
					}
				} else {
					// Nothing to do
				}
				break;
			case DBLE_BOND_NOTDONE:
			case DBLE_BOND_FAIL:
			case DBLE_BOND_DONE:
			case DBLE_BOND_STACK:
			case DBLE_BOND_NONEED:
				if (lParam != m_Count[m_StatusToSet - DBLE_BOND_NOTDONE + DBLE_BOND_NOTDONE_BTN]) {
					r = false;
					break;
				}
				length = m_pBuf[0];
				if (wParam == BLE_OK_L) {
					for (idx = 0; idx < length; idx++) {
						vIC[m_pBuf[idx + 1]]->m_BondingL = (DBLE_BondState)m_StatusToSet;
					}
				} else if (wParam == BLE_OK_R) {
					for (idx = 0; idx < length; idx++) {
						vIC[m_pBuf[idx + 1]]->m_BondingR = (DBLE_BondState)m_StatusToSet;
					}
				} else {
					// Nothing to do
				}
				break;
			case DBLE_BOND_REVERSE:
				if (lParam != m_Count[DBLE_BOND_REVERSE_BTN]) {
					r = false;
					break;
				}
				length = m_pBuf[0];
				if (wParam == BLE_OK_L) {
					for (idx = 0; idx < length; idx++) {
						if (vIC[m_pBuf[idx + 1]]->m_BondingL == DBLE_BOND_NOTDONE) {
							vIC[m_pBuf[idx + 1]]->m_BondingL = DBLE_BOND_DONE;
						} else if (vIC[m_pBuf[idx + 1]]->m_BondingL == DBLE_BOND_DONE) {
							vIC[m_pBuf[idx + 1]]->m_BondingL = DBLE_BOND_NOTDONE;
						} else {
							// Nothing to do
						}
					}
				} else if (wParam == BLE_OK_R) {
					for (idx = 0; idx < length; idx++) {
						if (vIC[m_pBuf[idx + 1]]->m_BondingR == DBLE_BOND_NOTDONE) {
							vIC[m_pBuf[idx + 1]]->m_BondingR = DBLE_BOND_DONE;
						} else if (vIC[m_pBuf[idx + 1]]->m_BondingR == DBLE_BOND_DONE) {
							vIC[m_pBuf[idx + 1]]->m_BondingR = DBLE_BOND_NOTDONE;
						} else {
							// Nothing to do
						}
					}
				} else {
					// Nothing to do
				}
				break;
			case DBLE_ALLSET_SUBST:
				if (lParam != m_Count[DBLE_ALLSET_SUBST_BTN]) {
					r  = false;
				} else {
					length = vIC.size();
					if (wParam == BLE_OK_L) {
						for (idx = 0; idx < length; idx ++) {
							vIC[idx]->m_BondingL = DBLE_BOND_NOTDONE;
							vIC[idx]->m_DetectL = DBLE_DETECT_UNKNOWN;
							vIC[idx]->m_StackCountL = 0;
						}
					}
					else if (wParam == BLE_OK_R) {
						for (idx = 0; idx < length; idx ++) {
							vIC[idx]->m_BondingR = DBLE_BOND_NOTDONE;
							vIC[idx]->m_DetectR = DBLE_DETECT_UNKNOWN;
							vIC[idx]->m_StackCountR = 0;
						}
					} else {
						// Nothing to do
					}
					// Reset moved index
					if (m_MovedIndex >=0 && m_MovedIndex < length) {
						vIC[m_MovedIndex]->SetMoved(false, m_nMode);
						m_MovedIndex = -1;
					}
				}
				break;
			case DBLE_ALLSET_BAD:
				if (lParam != m_Count[DBLE_ALLSET_BAD_BTN]) {
					r = false;
					break;
				}
				length = vIC.size();
				if (wParam == BLE_OK_L) {
					for (idx = 0; idx < length; idx++) {
						if (m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) {
							vIC[idx]->m_DetectL = DBLE_DETECT_BAD;
						}
					}
				} else if (wParam == BLE_OK_R) {
					for (idx = 0; idx < length; idx++) {
						if (m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) {
							vIC[idx]->m_DetectR = DBLE_DETECT_BAD;
						}
					}
				} else {
					// Nothing to do
				}
				break;
			case DBLE_ALLSET_GOOD:
				if (lParam != m_Count[DBLE_ALLSET_GOOD_BTN]) {
					r = false;
					break;
				}
				length = vIC.size();
				if (wParam == BLE_OK_L) {
					for (idx = 0; idx < length; idx++) {
						if (m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) {
							vIC[idx]->m_DetectL = DBLE_DETECT_GOOD;
						}
					}
				} else if (wParam == BLE_OK_R) {
					for (idx = 0; idx < length; idx++) {
						if (m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) {
							vIC[idx]->m_DetectR = DBLE_DETECT_GOOD;
						}
					}
				} else {
					// Nothing to do
				}
				break;
			case DBLE_ALLSET_DONE:
				if (lParam != m_Count[DBLE_ALLSET_DONE_BTN]) {
					r = false;
					break;
				}
				length = vIC.size();
				if (wParam == BLE_OK_L) {
					for (idx = 0; idx < length; idx++) {
						if (m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) {
							vIC[idx]->m_BondingL = DBLE_BOND_DONE;
						}
					}
				} else if (wParam == BLE_OK_R) {
					for (idx = 0; idx < length; idx++) {
						if (m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) {
							vIC[idx]->m_BondingR = DBLE_BOND_DONE;
						}
					}
				} else {
					// Nothing to do
				}
				break;
			case DBLE_ALLSET_DONTNEED:
				if (lParam != m_Count[DBLE_ALLSET_DONTNEED_BTN]) {
					r = false;
					break;
				}
				length = vIC.size();
				if (wParam == BLE_OK_L) {
					for (idx = 0; idx < length; idx++) {
						if (m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) {
							vIC[idx]->m_BondingL = DBLE_BOND_NONEED;
						}
					}
				} else if (wParam == BLE_OK_R) {
					for (idx = 0; idx < length; idx++) {
						if (m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) {
							vIC[idx]->m_BondingR = DBLE_BOND_NONEED;
						}
					}
				} else {
					// Nothing to do
				}
				break;
			case DBLE_ALLSET_REVERSE:
				if (lParam != m_Count[DBLE_ALLSET_REVERSE_BTN]) {
					r = false;
					break;
				}
				length = vIC.size();
				if (wParam == BLE_OK_L) {
					for (idx = 0; idx < length; idx++) {
						if ((m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) && (vIC[idx]->m_BondingL == DBLE_BOND_NOTDONE)) {
							vIC[idx]->m_BondingL = DBLE_BOND_DONE;
						} else if ((m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) && (vIC[idx]->m_BondingL == DBLE_BOND_DONE)) {
							vIC[idx]->m_BondingL = DBLE_BOND_NOTDONE;
						} else {
							// Nothing to do
						}
					}
				} else if (wParam == BLE_OK_R) {
					for (idx = 0; idx < length; idx++) {
						if ((m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) && (vIC[idx]->m_BondingR == DBLE_BOND_NOTDONE)) {
							vIC[idx]->m_BondingR = DBLE_BOND_DONE;
						} else if ((m_pBuf[0] == 0 || vIC[idx]->m_pRegIC->m_RegNo == m_pBuf[0]) && (vIC[idx]->m_BondingR == DBLE_BOND_DONE)) {
							vIC[idx]->m_BondingR = DBLE_BOND_NOTDONE;
						} else {
							// Nothing to do
						}
					}
				} else {
					// Nothing to do
				}
				break;
			case DBLE_ALLSET_LEFTDONE:
				{
					if (lParam != m_Count[DBLE_ALLSET_LEFTDONE_BTN]) {
						r = false;
						break;
					}
					int regNo = vIC[m_pBuf[1]]->m_pRegIC->m_RegNo;
					int idxX = vIC[m_pBuf[1]]->m_indexX + 1;
					int idxY = vIC[m_pBuf[1]]->m_indexY + 1;
					int currentIndex = m_pDoc->GetData()->CalIndex(*vIC[m_pBuf[1]]);
					int numberOfICs = (idxY - 1) * vIC[m_pBuf[1]]->m_pRegIC->m_NumberX + idxX;
					CBLE_IC *pIC = NULL;
					if (wParam == BLE_OK_L) {
						// For all ICs before selected IC
						for (idx = 0; idx < numberOfICs; idx++) {
							pIC = vIC[currentIndex - idx];
							if (!pIC->m_Deleted) {
								pIC->m_BondingL = DBLE_BOND_DONE;
							}
						}
					} else if (wParam == BLE_OK_R) {
						// For all ICs before selected IC
						for (idx = 0; idx < numberOfICs; idx++) {
							pIC = vIC[currentIndex - idx];
							if (!pIC->m_Deleted) {
								pIC->m_BondingR = DBLE_BOND_DONE;
							}
						}
					} else {
						// Do nothing
					}
					break;
				}
			case DBLE_ALLSET_RIGHTDONE:
				{
					if (lParam != m_Count[DBLE_ALLSET_RIGHTDONE_BTN]) {
						r = false;
						break;
					}
					int regNo = vIC[m_pBuf[1]]->m_pRegIC->m_RegNo;
					int idxX = vIC[m_pBuf[1]]->m_indexX + 1;
					int idxY = vIC[m_pBuf[1]]->m_indexY + 1;
					int currentIndex = m_pDoc->GetData()->CalIndex(*vIC[m_pBuf[1]]);
					int numberOfICs = (idxY - 1) * vIC[m_pBuf[1]]->m_pRegIC->m_NumberX;
					CBLE_IC *pIC = NULL;
					if (wParam == BLE_OK_L) {
						// For all ICs on lines before selected IC
						for (idx = 0; idx < numberOfICs; idx++) {
							pIC = vIC[currentIndex - idxX - idx];
							if (!pIC->m_Deleted) {
								pIC->m_BondingL = DBLE_BOND_DONE;
							}
						}
						// For all ICs after seletec IC on the same line
						for (idx = idxX; idx <= vIC[m_pBuf[1]]->m_pRegIC->m_NumberX; idx++) {
							pIC = vIC[currentIndex + (idx - idxX)];
							if (!pIC->m_Deleted) {
								pIC->m_BondingL = DBLE_BOND_DONE;
							}
						}
					} else if (wParam == BLE_OK_R) {
						// For all ICs on lines before selected IC
						for (idx = 0; idx < numberOfICs; idx++) {
							pIC = vIC[currentIndex - idxX - idx];
							if (!pIC->m_Deleted) {
								pIC->m_BondingR = DBLE_BOND_DONE;
							}
						}
						// For all ICs after seletec IC on the same line
						for (idx = idxX; idx <= vIC[m_pBuf[1]]->m_pRegIC->m_NumberX; idx++) {
							pIC = vIC[currentIndex + (idx - idxX)];
							if (!pIC->m_Deleted) {
								pIC->m_BondingR = DBLE_BOND_DONE;
							}
						}
					} else {
						// Do nothing
					}
					break;
				}
			default:
				r = false;
				break;
		}
		if (r) {
			UnmapViewOfFile(m_pBuf);
			CloseHandle(m_hMapFile);
			
			// Reset statusTochange
			m_StatusToSet = 0;

			// Set Event
			SetEvent(m_Handle[0]);
		} else {
			// Nothing to do
		}
	} else if (wParam == BLE_NG_L || wParam == BLE_NG_R) {
		
		// Reset statusTochange
		m_StatusToSet = 0;

		// Set event
		SetEvent(m_Handle[1]);

		// Message warning don't change status
		switch (lParam) {
			case BLE_NG_AUTORUN:
				//AfxMessageBox(DBLE_SUBINFOWND_NG_ANSWER_AUTORUN_MESS, MB_OK);
				theApp.CBTMessageBox(this->m_hWnd, NGAnswerAutoRun[language], MB_OK, language);
				break;
			case BLE_NG_STEPRUN:
				//AfxMessageBox(DBLE_SUBINFOWND_NG_ANSWER_STEPRUN_MESS, MB_OK);
				theApp.CBTMessageBox(this->m_hWnd, NGAnswerStepRun[language], MB_OK, language);
				break;
			case BLE_NG_FRAME:
				//AfxMessageBox(DBLE_SUBINFOWND_NG_ANSWER_FRAME_MESS, MB_OK);
				theApp.CBTMessageBox(this->m_hWnd, NGAnswerFrame[language], MB_OK, language);
				break;
			case BLE_NG_SCREEN:
				//AfxMessageBox(DBLE_SUBINFOWND_NG_ANSWER_SCREEN_MESS, MB_OK);
				theApp.CBTMessageBox(this->m_hWnd, NGAnswerScreen[language], MB_OK, language);
				break;
			case BLE_NG_NOUSEMAP:
				//AfxMessageBox(DBLE_SUBINFOWND_NG_ANSWER_NOTLOADMAP_MESS, MB_OK);
				theApp.CBTMessageBox(this->m_hWnd, NGAnswerNotLoad[language], MB_OK, language);
				break;
		}
		UnmapViewOfFile(m_pBuf);
		CloseHandle(m_hMapFile);

	} else {	// message change status from TFC
		bool r = true;
		CString strText = ""; //#TIENBV20151127
		// Check index of IC from TFC
		// Check range of index
		if (wParam == BLE_RESET_L || wParam == BLE_RESET_R) {
			// Do nothing
			strText = "0,0,0,0,"; //#TIENBV20151127
		} else {
			if (lParam <0 || lParam >= vIC.size()) {
				// TODO
				r = false;
			} else {
				// Check deleted status of IC at index from TFC
				//#TIENBV20151127
				strText.Format("%d,%d,%d,,",vIC[lParam]->m_pRegIC->m_RegNo, vIC[lParam]->m_indexX + 1, vIC[lParam]->m_indexY + 1);
				if (vIC[lParam]->m_Deleted) {
					r = false;
				}
			}
		}

		if (r) {
			if (lParam == m_MovedIndex) {
					// Reset moved index
					m_MovedIndex = -1;
					vIC[lParam]->SetMoved(false, m_nMode);
			}
			// Set status for IC
			switch(wParam) {
				case DBLE_BOND_NOTDONE:
				case DBLE_BOND_FAIL:
				case DBLE_BOND_DONE:
				case DBLE_BOND_STACK:
				case DBLE_BOND_NONEED:
					if (m_nMode == DBLE_SUBINFO_TYPE_L) {
						vIC[lParam]->m_BondingL = (DBLE_BondState)wParam;
					} else if(m_nMode == DBLE_SUBINFO_TYPE_R) {
						vIC[lParam]->m_BondingR = (DBLE_BondState)wParam;
					}
					m_LayoutWnd->SetScroll(vIC[lParam]);
					break;
				case DBLE_DETECT_UNKNOWN:
				case DBLE_DETECT_BAD:
				case DBLE_DETECT_GOOD:
					if (m_nMode == DBLE_SUBINFO_TYPE_L) {
						vIC[lParam]->m_DetectL = (DBLE_DetectState)wParam;
					} else if(m_nMode == DBLE_SUBINFO_TYPE_R) {
						vIC[lParam]->m_DetectR = (DBLE_DetectState)wParam;
					}
					m_LayoutWnd->SetScroll(vIC[lParam]);
					break;
				case BLE_RESET_L:
					length = vIC.size();
					for (idx = 0; idx < length; idx ++) {
						vIC[idx]->m_BondingL = DBLE_BOND_NOTDONE;
						vIC[idx]->m_DetectL = DBLE_DETECT_UNKNOWN;
						vIC[idx]->m_StackCountL = 0;
					}
					// Reset moved index
					if (m_MovedIndex >=0 && m_MovedIndex < length) {
						vIC[m_MovedIndex]->SetMoved(false, m_nMode);
						m_MovedIndex = -1;
					}
					break;
				case BLE_RESET_R:
					length = vIC.size();
					for (idx = 0; idx < length; idx ++) {
						vIC[idx]->m_BondingR = DBLE_BOND_NOTDONE;
						vIC[idx]->m_DetectR = DBLE_DETECT_UNKNOWN;
						vIC[idx]->m_StackCountR = 0;
					}
					// Reset moved index
					if (m_MovedIndex >=0 && m_MovedIndex < length) {
						vIC[m_MovedIndex]->SetMoved(false, m_nMode);
						m_MovedIndex = -1;
					}
				case BLE_MOVED_L:
				case BLE_MOVED_R:
					if (m_MovedIndex >= 0 && m_MovedIndex < vIC.size()) {
						// Clear Moved attribute
						vIC[m_MovedIndex]->SetMoved(false, m_nMode);
					}
					m_MovedIndex = lParam;
					vIC[lParam]->SetMoved(true, m_nMode);
					// Deselect all ICs
					m_pDoc->GetData()->GetSubstrate()->DeselectAll(m_nMode);
					// Set current IC is selected
					m_pDoc->GetData()->GetSubstrate()->SelectIC(vIC[lParam], m_nMode);
					// Update info window
					m_InfoWnd.UpdateGridData();
					m_LayoutWnd->SetScroll(vIC[lParam]);
					break;
				default:
					break;
			}
			if (wParam >= STACK_COUNT_L && wParam < STACK_COUNT_R) {
				vIC[lParam]->m_StackCountL = wParam - STACK_COUNT_L;
			}
			if (wParam >= STACK_COUNT_R && wParam < STACK_COUNT_R + 30) {
				vIC[lParam]->m_StackCountR = wParam - STACK_COUNT_R;
			}
		} else {
			// TODO: warning for user
			//AfxMessageBox(DBLE_SUBINFOWND_INDEX_INVALID_MESS, MB_OK);
			//theApp.CBTMessageBox(this->m_hWnd, IndexInvalid[language], MB_OK, language);
			// Write log file:

			//#TIENBV20151125 1.1_CD:: Get info of the top left IC selected and write to the log file
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, IndexInvalid[language] + "," + "," + "," + strText, "", "");
		}	
	}
	// Redraw layout
	m_LayoutWnd->Invalidate();
	return;
}

void CBLE_SubInfoWnd::CheckBtnState()
{
	vector<CBLE_IC*> vIC;
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICL;
	} else if (m_nMode == DBLE_SUBINFO_TYPE_R) {
		vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICR;;
	}
	// Zoom out button
	GetDlgItem(IDC_SUBINFO_ZOOM_OUT)->EnableWindow(m_nZoom != 0);
	// Zoom in button
	GetDlgItem(IDC_SUBINFO_ZOOM_IN)->EnableWindow(m_nZoom != (m_pDoc->m_vZoom.size() - 1));
	// Regno Up button
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_SUBINFO_REGNO_CBB));
	GetDlgItem(IDC_SUBINFO_REGNO_UP)->EnableWindow(m_nRegNo != pCbb->GetCount() - 1);
	// Regno Down button
	GetDlgItem(IDC_SUBINFO_REGNO_DOWN)->EnableWindow(m_nRegNo != 0);
	// Check set status button
	bool btnState = ((m_StatusToSet == 0) && (vIC.size() != 0)) ? true : false;
	GetDlgItem(IDC_SUBINFO_DETECT_UNKNOW_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_DETECT_BAD_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_DETECT_GOOD_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_BOND_NOTDONE_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_BOND_FAIL_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_BOND_DONE_BTN)->EnableWindow(btnState);
//	GetDlgItem(IDC_SUBINFO_BOND_STACK_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_BOND_DONTNEED_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_BOND_REVERSE_BTN)->EnableWindow(btnState);
	// Check set all status button
	btnState = ((m_StatusToSet == 0) && (vIC.size() == 0)) ? true : false;
	GetDlgItem(IDC_SUBINFO_SETSTATUS_SUBST_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_ALLBAD_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_ALLGOOD_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_ALLDONE_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_ALLDONTNEED_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_REVERSE_BTN)->EnableWindow(btnState);
	// Check set all left done status button
	btnState = ((m_StatusToSet == 0) && (vIC.size() == 1)) ? true : false;
	GetDlgItem(IDC_SUBINFO_SETSTATUS_LEFTDONE_BTN)->EnableWindow(btnState);
	GetDlgItem(IDC_SUBINFO_SETSTATUS_RIGHTDONE_BTN)->EnableWindow(btnState);
	return;
}

// Select IC
LRESULT CBLE_SubInfoWnd::OnChangeSelectIC(WPARAM wParam,LPARAM lParam)
{
	// Check disable/enable Delete and Restore button
	CheckBtnState();
	// Update information window
	m_InfoWnd.UpdateGridData();
	return 0;
}

// Update zoom
LRESULT CBLE_SubInfoWnd::OnUpdateZoom(WPARAM wParam, LPARAM lParam)
{
	if((wParam == DBLE_ZOOM_IN) && (m_nZoom != (m_pDoc->m_vZoom.size() - 1))){
		OnZoomButton(IDC_SUBINFO_ZOOM_IN);
	}else if((wParam == DBLE_ZOOM_OUT) && (m_nZoom != 0)){
		OnZoomButton(IDC_SUBINFO_ZOOM_OUT);
	}
	return 0;
}

// Update view when child window post a message
LRESULT CBLE_SubInfoWnd::OnUpdateView(WPARAM wParam, LPARAM lParam)
{
	// Update zoom
	if (wParam == 0) {
		m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],true);
	} else {
		// Update color label
		m_DisplayDlg.OnPaint();
	}
	m_LayoutWnd->Invalidate();
	return 0;
}

void CBLE_SubInfoWnd::OnTcnSelchangeTabcontrol(NMHDR *pNMHDR, LRESULT *pResult)
{
	m_DisplayDlg.ShowWindow(SW_HIDE);
	m_BondLS.ShowWindow(SW_HIDE);
	m_DetectLS.ShowWindow(SW_HIDE);
	switch(m_TabCtrl.GetCurSel()) {
		case 0:
			m_DisplayDlg.ShowWindow(SW_SHOW);
			break;
		case 1:
			m_DetectLS.ShowWindow(SW_SHOW);
			break;
		case 2:
			m_BondLS.ShowWindow(SW_SHOW);
			break;
	}
	*pResult = 0;
	return;
}

// Display focus IC
LRESULT CBLE_SubInfoWnd::OnDisplayFocusIC(WPARAM wParam, LPARAM lParam)
{
	m_InfoWnd.DisplayFocusIC();
	return 0;
}

void CBLE_SubInfoWnd::OnSize(UINT nType, int cx, int cy)
{
	if (!m_bInit) {
		return;
	}
	// Initialize a rect
	CRect rect;
	// Expand layout window
	m_LayoutWnd->GetWindowRect(rect);
	ScreenToClient(&rect);
	int oldWidth = rect.Width(); // store original width of layout window
	CRect layoutRect(rect.TopLeft(), CSize(cx - DBLE_SUBINFOWND_OPERATION_SIZEX, cy - DBLE_SUBINFOWND_INFO_SIZEY));
	m_LayoutWnd->MoveWindow(layoutRect);

	// Expand layout frame
	GetDlgItem(IDC_SUBINFO_LAYOUT)->MoveWindow(layoutRect,true);

	// Expand buttons and text
	for (UINT idx = IDC_SUBINFO_LOADMAP_BTN/*IDC_SUBINFO_DETECT_UNKNOW_BTN*/; idx <= IDC_SUBINFO_STATICREGNO; idx++) {
		if (GetDlgItem(idx) != NULL) {
			GetDlgItem(idx)->GetWindowRect(rect);
			ScreenToClient(&rect);
			rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
			GetDlgItem(idx)->MoveWindow(rect,true);
			if (idx == IDC_SUBINFO_FRMDIR_L) {
				m_FrmDirLR[0].MoveWindow(rect,true);
			} else if (idx == IDC_SUBINFO_FRMDIR_R) {
				m_FrmDirLR[1].MoveWindow(rect,true);
			}
		}
	}
	for (idx = IDC_SUBINFO_TABCTRL; idx <= IDC_SUBINFO_ALLSETBOX; idx++) {
		if (GetDlgItem(idx) != NULL) {
			GetDlgItem(idx)->GetWindowRect(rect);
			ScreenToClient(&rect);
			rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
			GetDlgItem(idx)->MoveWindow(rect,true);
		}
	}
	// Expand display dialog
	if (m_DisplayDlg) {
		m_DisplayDlg.GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		m_DisplayDlg.MoveWindow(rect,true);
	}

	// Expand Bond Load/Save dialog
	if (m_BondLS) {
		m_BondLS.GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		m_BondLS.MoveWindow(rect,true);
	}

	// Expand Detect Load/Save dialog
	if (m_DetectLS) {
		m_DetectLS.GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		m_DetectLS.MoveWindow(rect,true);
	}

	// Expand infor window
	m_InfoWnd.GetWindowRect(rect);
	int oldInfoWidth = rect.Width();
	int oldInfoHeight = rect.Height();
	ScreenToClient(&rect);
	CRect rect1;
	GetDlgItem(IDC_SUBINFO_DISPLAY_PIC)->GetWindowRect(rect1);
	ScreenToClient(&rect1);
	int bottom = (layoutRect.bottom > rect1.bottom) ? layoutRect.bottom : rect1.bottom;
	rect.SetRect(0, bottom + DBLE_SUBINFOWND_INFO_MARGIN, oldInfoWidth, bottom + oldInfoHeight + DBLE_SUBINFOWND_INFO_MARGIN);
	m_InfoWnd.MoveWindow(rect, true);

	//Expand Load Substrate Map
	if (GetDlgItem(IDC_SUBINFO_LOAD_SUB_MAP_BTN) != NULL) {
		GetDlgItem(IDC_SUBINFO_LOAD_SUB_MAP_BTN)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_SUBINFO_LOAD_SUB_MAP_BTN)->MoveWindow(rect,true);
	}
	if (GetDlgItem(IDC_SUBINFO_STATIC_SUBMAP) != NULL) {
		GetDlgItem(IDC_SUBINFO_STATIC_SUBMAP)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_SUBINFO_STATIC_SUBMAP)->MoveWindow(rect,true);
	}
	//Expand LED Display button
	for (idx = IDC_LED_DISP_BTN; idx <= IDC_STATIC_BCEQU; idx++) {
		if (GetDlgItem(idx) != NULL) {
			GetDlgItem(idx)->GetWindowRect(rect);
			ScreenToClient(&rect);
			rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
			GetDlgItem(idx)->MoveWindow(rect,true);
		}
	}
	// Redraw
	Invalidate();
	CDialog::OnSize(nType, cx, cy);
	
}

// Get min and max size of dialog
void CBLE_SubInfoWnd::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	lpMMI->ptMinTrackSize.x = DBLE_SUBINFOWND_SIZEX;
	lpMMI->ptMinTrackSize.y = DBLE_SUBINFOWND_SIZEY;
}

// #DDT(20140624) Load map file
void CBLE_SubInfoWnd::OnLoadMap()
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	// Data file for loading Barcode
	BOOL Read = TRUE;
	m_Barcode = m_pDoc->GetData()->GetBarcode(m_nMode);
	if (m_Barcode == "") {
		theApp.CBTMessageBox(this->m_hWnd, BarCode[language], MB_OK, language);
		return;
	}
    //#TIENBV20151125 1.1_CD:: Get info of the top left IC selected and write to the log file
	CString strText = GetInfoTopLeftSelIC();

	theApp.p_Logger->SetLogFormat(m_logLoadMapData + strText);

	if (m_pLoadMapThread) {
		delete m_pLoadMapThread;
	}
	m_pLoadMapThread = AfxBeginThread(
			OnSetMapDataStatusThread,				// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
	if (m_pLoadMapThread) {
		// Don't auto delete after thread terminated
		m_pLoadMapThread->m_bAutoDelete = FALSE;
		// Start thread
		m_pLoadMapThread->ResumeThread();
	}
	this->m_LayoutWnd->SetMode(DBLE_MODE_SUB_INFO_LOAD_MAP);
	Sleep(5000);
	GetDlgItem(IDC_EDIT_BCEQU)->SetWindowText(m_pDoc->GetData()->m_BCEQU);
	GetDlgItem(IDC_EDIT_MAP)->SetWindowText(m_Barcode);
	Invalidate();
	return;
}

UINT CBLE_SubInfoWnd::OnSetMapDataStatusThread(LPVOID pParam)
{
	CBLE_SubInfoWnd *sub = (CBLE_SubInfoWnd *)pParam;
	sub->SetMapDataThread();
	return 0;
}

void CBLE_SubInfoWnd::SetMapDataThread()
{

	int language = m_pDoc->GetData()->m_Init.m_Language;
	// Find TFC window
	CWnd * tfc = FindWindow(NULL, TFC_FRAMENAME);
	// Not found tfc, show message to user
	if (tfc == NULL) {
		//AfxMessageBox(DBLE_SUBINFOWND_NOTRUN_MESS, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, NotRun[language], MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, NotRun[language], "", "");
		return;
	} 

	// Check isSubComplex mode or not
	int complex = m_pDoc->GetData()->GetSubComplexMode();
	if (!complex) {
		//AfxMessageBox(DBLE_SUBINFOWND_COMPLEX_MESS, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, ComplexMode[language], MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ComplexMode[language], "", "");
		return;
	}

	// Load map data 
	BOOL r = m_pDoc->GetData()->LoadMapData(m_Barcode, m_nMode, m_vIC);

	if (!r) {
		theApp.CBTMessageBox(this->m_hWnd, LoadMap[language], MB_OK, language);
		return;
	}
	// TODO: Write data to shared memory
	// Create mapping file
	CString tmp;
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		tmp = GLOBAL_NAME_LOADMAP_L;
	} else {
		tmp = GLOBAL_NAME_LOADMAP_R;
	}
	// Create handle for share memory
	m_hLoadMapData = CreateFileMapping(
                 INVALID_HANDLE_VALUE,    // use paging file
                 NULL,                    // default security
                 PAGE_READWRITE,          // read/write access
                 0,                       // maximum object size (high-order DWORD)
                 LOADMAP_SIZE,            // maximum object size (low-order DWORD)
                 tmp);					  // name of mapping object

	// If cannot create mapping file, show warning message and return
	if (m_hLoadMapData == NULL)
	{
		CString tmp;
		tmp.Format(ShareMemory[language], GetLastError());
		//AfxMessageBox(tmp);
		theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, tmp/*ShareMemory[language]*/, "", "");
		return;
	}
	m_pBufLoadMapData = (int*) MapViewOfFile(m_hLoadMapData,   // handle to map object
                        FILE_MAP_ALL_ACCESS, // read/write permission
                        0,
                        0,
                        LOADMAP_SIZE);
	if (m_pBufLoadMapData == NULL)
	{
		CString tmp;
		tmp.Format(MapView[language], GetLastError());
		//AfxMessageBox(tmp);
		theApp.CBTMessageBox(this->m_hWnd, tmp, MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, MapView[language], "", "");

		CloseHandle(m_hLoadMapData);
		return;
	}
	// Set ICs need to change
	int length = m_vIC.size();
	m_pBufLoadMapData[0] = length;
	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		for (int idx = 0; idx < length; idx++) {
			m_pBufLoadMapData[2 * idx + 1] = m_pDoc->GetData()->CalIndex(m_vIC[idx]);
			m_pBufLoadMapData[2 * idx + 2]	= m_vIC[idx].m_BondingL;
		}
	} else {
		for (int idx = 0; idx < length; idx++) {
			m_pBufLoadMapData[2 * idx + 1] = m_pDoc->GetData()->CalIndex(m_vIC[idx]);
			m_pBufLoadMapData[2 * idx + 2]	= m_vIC[idx].m_BondingR;
		}
	}

	// Reset event before send message
	ResetEvent(m_LoadMapHandle[0]);
	ResetEvent(m_LoadMapHandle[1]);

	m_Count[DBLE_LOADMAP_BTN]++;

	if (m_nMode == DBLE_SUBINFO_TYPE_L) {
		tfc->PostMessage(WM_TFC_CTRL, LOADMAP_L, m_Count[DBLE_LOADMAP_BTN]);
	} else {
		tfc->PostMessage(WM_TFC_CTRL, LOADMAP_R, m_Count[DBLE_LOADMAP_BTN]);
	}

	DWORD result = WaitForMultipleObjects(2, &m_LoadMapHandle[0], false, m_pDoc->GetData()->m_Init.m_TimeOutSubInfo * 1000);
	while (result == WAIT_TIMEOUT) {
		if (theApp.CBTMessageBox(this->m_hWnd, TimeOutTFC[language], MB_YESNO, language) == IDYES) {
			result = WaitForMultipleObjects(2, &m_LoadMapHandle[0], false, m_pDoc->GetData()->m_Init.m_TimeOutSubInfo * 1000);
		} else {
			// Clear data
			m_vIC.clear();
			// Warning
			theApp.CBTMessageBox(this->m_hWnd, LoadMap[language], MB_OK, language);
			break;
		}
	}
	UnmapViewOfFile(m_pBufLoadMapData);
	CloseHandle(m_hLoadMapData);
}

void CBLE_SubInfoWnd::SetFrameDirection(int dir)
{
	m_pDoc->GetData()->SetFrmDir((m_nMode == DBLE_SUBINFO_TYPE_L) ? eLeftMode : eRightMode, dir);
	// Frame direction
	HBITMAP bitmap;
	bitmap = m_FrmDirLR[0].GetBitmap();
	if (bitmap) {
		DeleteObject(bitmap);
	}
	bitmap = (HBITMAP)LoadImage(AfxGetApp()->m_hInstance, MAKEINTRESOURCE((dir == DBLE_SUBINFO_FRMDIR_LEFT) ? IDB_BITMAP1 : IDB_BITMAP2), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR);
	m_FrmDirLR[0].SetBitmap(bitmap);
	bitmap = m_FrmDirLR[1].GetBitmap();
	if (bitmap) {
		DeleteObject(bitmap);
	}
	bitmap = (HBITMAP)LoadImage(AfxGetApp()->m_hInstance, MAKEINTRESOURCE((dir == DBLE_SUBINFO_FRMDIR_RIGHT) ? IDB_BITMAP3 : IDB_BITMAP4), IMAGE_BITMAP, 0, 0, LR_DEFAULTCOLOR);
	m_FrmDirLR[1].SetBitmap(bitmap);
}
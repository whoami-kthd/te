/*---------------------------------------------------------------------
	 ShibauraLoader
								2013 HangNT / TSDV
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
////////////////////////////////////////////////////////////////////////

#ifndef	_CSMLDCtrl_H
#define	_CSMLDCtrl_H

#include	<mcstd.h>
#include	<CommonDef.h>
#include	<SingleMtCtrl.h>
#include	"PauseAndWait.h"
#include	"LoaderUnloader.h"
#include	"CommonDef.h"

enum {
	CmdWaitAndExecute,
	CmdMoveToExchg,
};


class	MCCtrl;
class	CSMLDCtrl;
class	CSMUDCtrl;
///////////////////////////////////////////////
//
// This class only control the movement of magazine
//(1): Get next slot
//(2): Move to load position
//(3): Move to magazine exchange position
//

class CSMLDCtrl : public StdSbstLDUDCtrl
{
	public:
		CSMLDCtrl();
		virtual ~CSMLDCtrl();
		CSMLDCtrl (
					CString name,
					int class_id,					// Class ID
					CEventX* pEvRequestLoad,		// Load request event
					CEventX* pEvLoadOK,				// Load OK report event
					CEventX* pEvLoadNG,				// Load NG report event
					CEventX* pEvLoadStop,			// Load stop event
					CEventX* pEvFinish,				// Finish event
					OrdinarySnsTBL* pSnsMgzExist,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsMgzExist2,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsCoverClose,	// Cover close detect sensor
					OrdinarySnsTBL* pSnsSubstExist,	// Subst exist sensor
					int idx_mtMgz,					// Transfer motor X index
					int myErrStart					// Error start
					);

	//====================================================
	// Attribute declaration
	//====================================================
	private:
		CEventX*			pEvRequestLoad;			// Request load event
		CEventX*			pEvLoadOK;				// Load OK report event
		CEventX*			pEvLoadNG;				// Load NG report event
		CEventX*			pEvLoadStop;			// Loader stop event
		CEventX*			pEvFinish;				// Finish event

		int		mgzFeedType;						// Loader feed type

		bool	isAging;

	//===================================================
	// Motor index
	//===================================================
	protected:
		MTCtrl			ActionMTC;

	// Public attribute
	public:
		MCCtrl			*pMCC;	// pMCC pointer to MCCtrl
		
		OrdinarySensor	m_snsBackPushOL;
		OrdinarySensor	m_snsBackPushOri;
		OrdinarySensor	m_snsSubInRail;
		AirCylinderStd	m_CyBackPush;
	//====================================================
	// Method declaration
	//====================================================
	private:	
		// Get next slot number
		BOOL	GetNextSlot(int& mgzNo, int& slot, bool& canGet);

	protected:
		// Action function
		static	UINT ActionFunc(MTCtrl *pParam);

	public:
// #IK20130508-02 [�C��] ۰�ޗ�O����ב΍�
		// Set stop flag
		virtual void SetStopFlag(int flag);
		// Move magazine to exchange position
		BOOL	MoveToExchPos();
		// Move magazine to wait position
		BOOL	MoveToWaitPos();
		// Move to load position
		BOOL	MoveToLoadPos(int mgzNo, int slot);
		// Move magazine
		BOOL	MgzMoveAbs(double pos, bool wait);
		// Get current magazine slot
		BOOL	isGetMgzSide(int& mgzNo, int& slotNo, bool& canGet);		// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
		BOOL	MgEndSub();
		BOOL	WaitAndExecute();	
		BOOL	InitInstance();
		void	ErrorInit(int myErrorStart);

		BOOL	MakeSlotMap();
		BOOL	MgRingCheckPosMove(int mgzNo, int No);
		bool	isMgzAtSlotPos();
		BOOL	isAbleToMoveMgz();
		BOOL	IsEnableBackPush();

	// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
		void SetAging(bool isValid){	//#MI130906SMEMA_I/F�C��
			this->isAging = isValid;
		}

		// MC data read/ write method
		enum{
			eSubstUnknown	= 0,			// Unknown
			eSubstNone		= 1,			// Subst not exist
			eSubstExist		= 3,			// Subst exist
		};
		//enum {
		//	eSubstNumberMax = 25,
	//	};

		BOOL	MCDataRW(BOOL Read,	LPCTSTR FNam, CString MSec);
		BOOL	DVDataRW(BOOL Read, LPCTSTR FNam, CString MSec);
		BOOL	PDDataRW(BOOL Read, LPCTSTR FNam, CString MSec);

		// Error enum list
		enum {
			Err_CoverOpenL = 1,		// Magazine cover open error
			Err_MgzNotExistL,		// Magazine not exist error
			Err_SubstNotExistL,		// Substrate not exist error
			Err_MtrBusy,			// Motor busy error
			Err_ELVLimitLMgz,		// Elevator limit error
			Err_EVLMtrAlarmLMgz,	// Elevator motor alarm error
			Err_EVLMtrPosLMgz,		// Elevator position error
			Err_EVLTime,			// Elevator time out setting error
			Err_MazPusherIL,		// Magazine and feed pusher IL
			Err_MgRunOutSubst,		// Magazine run out of substrate error
			Err_BackPushNotOri,		// Backpush not in origin position
			Err_SubstrateInRail,	// Substrate exist in rail
			Err_MgzPosIllegal,		// Magazine is in illegal postion
			Err_FeedChuckNotOpen,	// Feed chuck not open
		};
	
};

///////////////////////////////////////////////
//
//
// 
//
class CSMUDCtrl : public StdSbstLDUDCtrl//,public MCCStd		// yk130503
{
	public:
		CSMUDCtrl();
		virtual ~CSMUDCtrl();
		CSMUDCtrl (
					CString name,
					int class_id,					// Class ID
					CEventX* pEvRequestUnLoad,		// Load request event
					CEventX* pEvUnLoadOK,			// Load OK report event
					CEventX* pEvUnLoadNG,			// Load NG report event
					CEventX* pEvUnLoadStop,			// Load stop event
					CEventX* pEvFinish,				// Finish event
					OrdinarySnsTBL* pSnsMgzExist,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsMgzExist2,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsCoverClose,	// Cover close detect sensor
					OrdinarySnsTBL* pSnsSubstExist,	// Subst exist sensor
					int idx_mtMgz,					// Transfer motor X index
					int myErrStart					// Error start				// Error start
					);

	//=================================================
	// Attribute declaration
	//=================================================
	private:
		CEventX*			pEvRequestUnLoad;		// Request load event
		CEventX*			pEvUnLoadOK;				// Load OK report event
		CEventX*			pEvUnLoadNG;				// Load NG report event
		CEventX*			pEvUnLoadStop;				// Loader stop event
		CEventX*			pEvFinish;				// Finish event

		int		mgzFeedType;						// Loader feed type

		bool	isAging;

	//===================================================
	// Motor index
	//===================================================
	protected:
		MTCtrl			ActionMTC;

	// Public attribute
	public:
		MCCtrl			*pMCC;	// pMCC pointer to MCCtrl

	//====================================================
	// Method declaration
	//====================================================
	private:	
		// Get next slot number
		BOOL	GetNextSlot(int& mgzNo, int& slot, bool& canGet);

	protected:
		// Action function
		static	UINT ActionFunc(MTCtrl *pParam);

	public:
// #IK20130508-02 [�C��] ۰�ޗ�O����ב΍�
		// Set stop flag
		virtual void SetStopFlag(int flag);
		// Move magazine to exchange position
		BOOL	MoveToExchPos();
		// Move magazine to wait position
		BOOL	MoveToWaitPos();
		// Move to load position
		BOOL	MoveToLoadPos(int mgzNo, int slot);
		// Move magazine
		BOOL	MgzMoveAbs(double pos, bool wait);
		// Get current magazine slot
		BOOL	isGetMgzSide(int& mgzNo, int& slotNo, bool& canGet);		// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
		BOOL	MgEndSub();
		BOOL	WaitAndExecute();
		BOOL	MakeSlotMap();
	// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
		void SetAging(bool isValid){	//#MI130906SMEMA_I/F�C��
			this->isAging = isValid;
		}

		enum{
			eSubstUnknown	= 0,			// Unknown
			eSubstNone		= 1,			// Subst not exist
			eSubstExist		= 3,			// Subst exist
		};
//		enum {
//			eSubstNumberMax = 13,
//		};

		BOOL	MgRingCheckPosMove(int mgzNo, int No);
		bool	isMgzAtSlotPos();
		BOOL	isAbleToMoveMgz();
		BOOL	InitInstance();
		void	ErrorInit(int myErrorStart);
		
		BOOL	MCDataRW(BOOL Read,	LPCTSTR FNam, CString MSec);
		BOOL	DVDataRW(BOOL Read, LPCTSTR FNam, CString MSec);
		BOOL	PDDataRW(BOOL Read, LPCTSTR FNam, CString MSec);

		// Error list
		enum {
			Err_CoverOpenU = 1,		// Magazine cover open error
			Err_MgzNotExistU,		// Magazine not exist error
			Err_SubstNotExistU,		// Substrate not exist error
			Err_MtrBusy,			// Motor busy error
			Err_ELVLimitUMgz,		// Elevator limit error
			Err_EVLMtrAlarmUMgz,	// Elevator motor alarm error
			Err_EVLMtrPosUMgz,		// Elevator position error
			Err_EVLTime,			// Elevator time out setting error
			Err_MazPusherIL,		// Magazine and pusher IL
			Err_MgFullSubst,		// Magazine full of subst
		};
};

#endif

// SecsGem300.h: SecsGem300 �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SECSGEM300_H__9C04F43B_B284_4BAE_B946_7013259C01FF__INCLUDED_)
#define AFX_SECSGEM300_H__9C04F43B_B284_4BAE_B946_7013259C01FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include	"afxmt.h"

class SecsGem300  
{
public:
	SecsGem300();
	virtual ~SecsGem300();
public:
	/////////////////////////////////////
	//
	// Public Event
	//
	CEvent* pEvFinInfoComState;
	CEvent* pEvFailInfoComState;
public:
	/////////////////////////////////////
	//
	// Public Method
	//
	BOOL ChangeCR();
	BOOL OpenProject();

protected:
	/////////////////////////////////////
	//
	// protected ��MMethod
	//
void OnInfoComStateXcomsecsctrl1(short com_state, short hst_sts, short eq_sts);
};

#endif // !defined(AFX_SECSGEM300_H__9C04F43B_B284_4BAE_B946_7013259C01FF__INCLUDED_)

// ColletteGDTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GarbageDetectTest.h"
#include "GDTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern int ColletteGDTest(int, CString, CString, CWnd*);
extern int ToolStgGDTest(int, CString, CString, CWnd*,CWnd*);

#define FILE_BUFFER_SIZE 200
/////////////////////////////////////////////////////////////////////////////
// CGDTestDlg dialog


CGDTestDlg::CGDTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGDTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGDTestDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_type = 0;
}


void CGDTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGDTestDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGDTestDlg, CDialog)
	//{{AFX_MSG_MAP(CGDTestDlg)
	ON_BN_CLICKED(ID_COLLETTE_START, OnColletteStart)
	ON_BN_CLICKED(IDC_BUTTON_BRTEACH, OnButtonBrteach)
	ON_BN_CLICKED(IDC_BUTTON_BRTTEST, OnButtonBrttest)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGDTestDlg message handlers

void CGDTestDlg::OnColletteStart() 
{
	// TODO: Add your control notification handler code here
	CString text;	// Get text from controller
	int threshold = 0;

	GetDlgItem(IDC_EDIT_THRESHOLD)->GetWindowText(text);
	if (!text.IsEmpty()) {
		text.TrimLeft();
		text.TrimRight();
		threshold = atoi(text);
	} else {
		AfxMessageBox("Threshold value is empty!");
		return;
	}

	CFileStatus status;
	if (m_filePathTeach.IsEmpty() || !CFile::GetStatus(m_filePathTeach, status)) {
		AfxMessageBox("Teach file path is invalid!");
		return;
	}

	if (m_filePathTeach.IsEmpty() || !CFile::GetStatus(m_filePathTest, status)) {
		AfxMessageBox("Test file path is invalid!");
		return;
	}
	
	if (this->m_type == COLLETTE_GD) {
		ColletteGDTest(threshold, m_filePathTeach, m_filePathTest, GetDlgItem(IDC_STATIC_DISPLAY));
	} else {
		ToolStgGDTest(threshold, m_filePathTeach, m_filePathTest, GetDlgItem(IDC_STATIC_TEACH), GetDlgItem(IDC_STATIC_TEST));
	}
}

void CGDTestDlg::OnButtonBrteach() 
{
	// TODO: Add your control notification handler code here
	CString fileName;
	char* p = fileName.GetBuffer( FILE_BUFFER_SIZE );
	CFileDialog dlgFile(TRUE);
	int ret = dlgFile.DoModal();
	fileName.ReleaseBuffer();
	if (ret == IDOK) {
		m_filePathTeach = dlgFile.GetPathName();
		GetDlgItem(IDC_EDIT_TEACH_FILEPATH)->SetWindowText(m_filePathTeach);
	}
	return;
}

void CGDTestDlg::OnButtonBrttest() 
{
	// TODO: Add your control notification handler code here
	CString fileName;
	char* p = fileName.GetBuffer( FILE_BUFFER_SIZE );
	CFileDialog dlgFile(TRUE);
	int ret = dlgFile.DoModal();
	fileName.ReleaseBuffer();
	if (ret == IDOK) {
		m_filePathTest = dlgFile.GetPathName();
		GetDlgItem(IDC_EDIT_TEST_FILEPATH)->SetWindowText(m_filePathTest);
	}
	return;
}

BOOL CGDTestDlg::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	return CDialog::Create(IDD, pParentWnd);
}

void CGDTestDlg::SetGDType(int type)
{
	this->m_type = type;
}

BOOL CGDTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	if (m_type == COLLETTE_GD) {
		this->SetWindowText("Tool Stage Garbage Detection Test");
		GetDlgItem(IDC_STATIC_TEST)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_STATIC_TEACH)->ShowWindow(SW_HIDE);
	} else {
		this->SetWindowText("Collette Garbage Detection Test");
		GetDlgItem(IDC_STATIC_DISPLAY)->ShowWindow(SW_HIDE);
	}

	return TRUE;
}
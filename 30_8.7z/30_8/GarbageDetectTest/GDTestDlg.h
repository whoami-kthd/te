#if !defined(AFX_COLLETTEGDTESTDLG_H__04ED6DE5_7BA8_46F1_8C74_533C8A1FD889__INCLUDED_)
#define AFX_COLLETTEGDTESTDLG_H__04ED6DE5_7BA8_46F1_8C74_533C8A1FD889__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColletteGDTestDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGDTestDlg dialog
enum {
	COLLETTE_GD = 0,
	TOOLSTG_GD,
};
class CGDTestDlg : public CDialog
{
// Construction
public:
	CGDTestDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGDTestDlg)
	enum { IDD = IDD_DIALOG_GD};
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	void SetGDType(int type);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGDTestDlg)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	BOOL OnInitDialog();
	// Generated message map functions
	//{{AFX_MSG(CGDTestDlg)
	afx_msg void OnColletteStart();
	afx_msg void OnButtonBrteach();
	afx_msg void OnButtonBrttest();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CString m_filePathTeach;
	CString m_filePathTest;
	int		m_type;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLLETTEGDTESTDLG_H__04ED6DE5_7BA8_46F1_8C74_533C8A1FD889__INCLUDED_)

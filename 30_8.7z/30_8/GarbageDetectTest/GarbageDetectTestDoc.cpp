// GarbageDetectTestDoc.cpp : implementation of the CGarbageDetectTestDoc class
//

#include "stdafx.h"
#include "GarbageDetectTest.h"

#include "GarbageDetectTestDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestDoc

IMPLEMENT_DYNCREATE(CGarbageDetectTestDoc, CDocument)

BEGIN_MESSAGE_MAP(CGarbageDetectTestDoc, CDocument)
	//{{AFX_MSG_MAP(CGarbageDetectTestDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestDoc construction/destruction

CGarbageDetectTestDoc::CGarbageDetectTestDoc()
{
	// TODO: add one-time construction code here

}

CGarbageDetectTestDoc::~CGarbageDetectTestDoc()
{
}

BOOL CGarbageDetectTestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestDoc serialization

void CGarbageDetectTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestDoc diagnostics

#ifdef _DEBUG
void CGarbageDetectTestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGarbageDetectTestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestDoc commands

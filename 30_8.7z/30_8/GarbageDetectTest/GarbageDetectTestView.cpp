// GarbageDetectTestView.cpp : implementation of the CGarbageDetectTestView class
//

#include "stdafx.h"
#include "GarbageDetectTest.h"

#include "GarbageDetectTestDoc.h"
#include "GarbageDetectTestView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestView

IMPLEMENT_DYNCREATE(CGarbageDetectTestView, CView)

BEGIN_MESSAGE_MAP(CGarbageDetectTestView, CView)
	//{{AFX_MSG_MAP(CGarbageDetectTestView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestView construction/destruction

CGarbageDetectTestView::CGarbageDetectTestView()
{
	// TODO: add construction code here

}

CGarbageDetectTestView::~CGarbageDetectTestView()
{
}

BOOL CGarbageDetectTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestView drawing

void CGarbageDetectTestView::OnDraw(CDC* pDC)
{
	CGarbageDetectTestDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestView diagnostics

#ifdef _DEBUG
void CGarbageDetectTestView::AssertValid() const
{
	CView::AssertValid();
}

void CGarbageDetectTestView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGarbageDetectTestDoc* CGarbageDetectTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGarbageDetectTestDoc)));
	return (CGarbageDetectTestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGarbageDetectTestView message handlers

// GarbageDetectTestView.h : interface of the CGarbageDetectTestView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GARBAGEDETECTTESTVIEW_H__74F3D385_B7B2_4345_AF12_9F414FB783E1__INCLUDED_)
#define AFX_GARBAGEDETECTTESTVIEW_H__74F3D385_B7B2_4345_AF12_9F414FB783E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CGarbageDetectTestView : public CView
{
protected: // create from serialization only
	CGarbageDetectTestView();
	DECLARE_DYNCREATE(CGarbageDetectTestView)

// Attributes
public:
	CGarbageDetectTestDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGarbageDetectTestView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGarbageDetectTestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGarbageDetectTestView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in GarbageDetectTestView.cpp
inline CGarbageDetectTestDoc* CGarbageDetectTestView::GetDocument()
   { return (CGarbageDetectTestDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GARBAGEDETECTTESTVIEW_H__74F3D385_B7B2_4345_AF12_9F414FB783E1__INCLUDED_)

/*
* Copyright (c) 2004 by Cognex Corporation, Natick, MA USA
* All rights reserved. This material contains unpublished,
* copyrighted work, which includes confidential and proprietary
* information of Cognex.
*/

#include <ch_cvl/pminspct.h>
#include <ch_cvl/constrea.h>

///////
#include <ch_cvl/acusymbl.h>
#include <ch_cvl/pelfunc.h>
#include <ch_cvl/constrea.h>
#include <ch_cvl/dib.h>
#include <ch_cvl/windisp.h>
#include <ch_cvl/uishapes.h>
//#include <ch_cvl/gmorph.h>
#include <afxdlgs.h>

/////////////////
//Histgrram
////////////////
#include <ch_cvl/histo.h>
#include <ch_cvl/histstat.h>
#include <ch_cvl/pelfunc.h>
#include <ch_cvl/defs.h>
#include <ch_cvl/constrea.h>
#include <assert.h>
////////////////

////////////////
// Blob
#include <ch_cvl/blobdesc.h>
#include <ch_cvl/blobtool.h>
#include <ch_cvl/pelfunc.h>
#include <ch_cvl/constrea.h>
#include <iomanip>
#include <ch_cvl/pelmap.h>
////////////////

////////////////
// Cnl
#include <ch_cvl/cnlsrch.h>

////////////////
// �}���`����
// �������x�𑁂����邽�߂̎���
//#include <ch_cvl/workmgr.h>

#ifndef cmNoGUI
#include <ch_cvl/windisp.h>
#endif

// This sample code demonstrates Beta functionality.

// This file is a sample code for using the defect extraction
// functionality of the intensity difference mode of PatInspect(R)
// (see <ch_cvl/pminspct.h>).
//
// This sample code:
//   - creates synthetic images for both training and run-time inspection
//   - sets up only one inspection region
//   - enables image preprocessing to improve training quality
//   - uses statistical training on multiple defect-free images
//   - runs the trained tool on a run-time image with defects, and shows
//     the found defects
// It is straightforward to extend this sample code to work on multiple
// inspection regions.


// The following functions are simple utilities used in this sample code
// to create test data and show found defects.
// They are not necessary on a production system.
static void createTrainingImages(cmStd vector<ccPelBuffer</*c_UInt8*/c_UInt32> >& images);
static void createRuntimeImages(cmStd vector<ccPelBuffer</*c_UInt8*/c_UInt32> >& images);
static ccCvlString polarityString(ccPMInspectDefs::DefectPolarity p);


//////////////////////
// Main
int cfSampleMain(int argc, TCHAR** const argv)
{
	//ccWorkerThreadManagerParams params;
	//params.desiredWorkerThreads(ccWorkerThreadManagerDefs::eWorkerThreadsSpecified);
	//params.workerThreadCount(3);
	//ccWorkerThreadManager::configure(params);
	
	
	cmStd vector<ccPelBuffer</*c_UInt8*/c_UInt32> > trainImages, runImages;
	createTrainingImages(trainImages);
	createRuntimeImages(runImages);
	
	const c_Int32 numTrainImages = static_cast<c_Int32>(trainImages.size());
	const c_Int32 numRunImages = static_cast<c_Int32>(runImages.size());
	
#ifndef cmNoGUI
	// Display some images on the host system, where cmNoGUI is not defined.
	//  ccDisplayConsole console(cmT("PatInspect(R) Intensity Difference Mode ")
	//                          cmT("Defect Extraction"),
	//                           ccIPair(0,0), trainImages[0].window().size());
	////////////////////
	// window�\��
	ccDisplayConsole console(ccIPair(640, 480));
	//  ccDisplayConsole console(ccIPair(320, 240));
	ccDIB dib;
	ccDIB dib2;
#endif
	
	////////////////////
	// �摜���t�@�C������I���ł���悤(�e�B�[�`���O�摜�g���C���Ώ�)
	CFileDialog fileDlg(true, NULL, _T("")
		, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT
		, _T("Bitmap Files (*.bmp)|*.bmp|All Files (*.*)|*.*||") );
	if ( IDOK!=fileDlg.DoModal() ) return 0;
	
	
	dib.init( (LPCTSTR)fileDlg.GetPathName() );
	ccPelBuffer<c_UInt8> pb = dib.pelBuffer();
	////////////////////
	console.image(pb);  // �I�������摜�f�[�^���擾
	console.fit();
	MessageBox(NULL, _T("load image(Teaching)"), _T("stop"), MB_OK);
	////////////////////
	
	////////////////////
	// �摜���t�@�C������I���ł���悤(���ۂ̔F���摜)
	CFileDialog fileDlg2(true, NULL, _T("")
		, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT
		, _T("Bitmap Files (*.bmp)|*.bmp|All Files (*.*)|*.*||") );
	if ( IDOK!=fileDlg2.DoModal() ) return 0;
	
	
	dib2.init( (LPCTSTR)fileDlg2.GetPathName() );
	ccPelBuffer<c_UInt8> pb2 = dib2.pelBuffer();
	////////////////////
	console.image(pb2);  // �I�������摜�f�[�^���擾
	console.fit();
	MessageBox(NULL, _T("load image(Align)"), _T("stop"), MB_OK);
	////////////////////
	
	
	
	///////////////////////////////
	// PatInspect paramater �ʒu�o�^�ݒ�
	ccPMInspectPattern pat;
	//
	const ccPMInspectDefs::InspectMode inspectMode =
		ccPMInspectDefs::eIntensityDifference;	// VisionPRo�ɂ͂��ꂵ���Ȃ�
	// (P1292) pb�摜�\����5�k������̊��������ΏۂƂ���
	// �����ł���̂�5pix�ȏ�Ȃ̂ł����Ń`�F�b�N����
	const ccPelRect inspectRegion(pb.window().trim(/*X*/5,/*Y*/ 5,/*w*/ 5,/*h*/ 5));
	
	pat.addInspectRegion(inspectRegion, inspectMode);		// starttrain�O�ɌĂяo���K�v����
	
	// Set properties for the inspection region.
	// - enable defect extraction
	// - use the ccPMInspectDefs::eLocalCorrectionEnhanced preprocessing method
	//   to improve the tool's tolerance of lighting variations.
	// - set neighborhood size for image preprocessing
	const c_Int32 regionIndex = 0;
	ccPMInspectRegion& region = pat.inspectRegion(regionIndex);
	region.extractIntensityDefects(true);
	region.preprocessing(ccPMInspectDefs::eLocalCorrectionEnhanced);
	// The default neighborhoodSize value 101x101 may be okay for many images.
	// Uncomment the following line if you want to change it.
	// region.neighborhoodSize(ccIPair(50, 50));
	
	///////////////////////
	// sobel
	// ccDPair coeffs_s(0.4,35);	// 
	ccDPair coeffs_s(0.4,35);	// 
	pat.sobelCoeffs(coeffs_s);
	
	///////////////////////
	// �������������l
	ccDPair coeffs_t(0.4,0);	// 
	pat.thresholdCoeffs(coeffs_t);
	
	/////////////////////////
	// Statistically train the tool, using the internal alignment model.
	ccPMInspectStatTrainParams trainParams;
	
	
	
	
	pat.startTrain(pb);		//�@�摜�̓o�^���s���B(�e�B�[�`���O�����摜)
	
	/////////////////
    // Train���s��(�TPix�`�F�b�N���s���B)
	pat.statisticTrain(pb, trainParams, inspectMode);	// �F���������摜
														/*
														#ifndef cmNoGUI
														console.image(pb);
														if (MessageBox(NULL, cmT("PB2 Continue?"), cmT("Training image"), MB_OKCANCEL)
														== IDCANCEL)
														return 0;
														#endif
	*/
	pat.endTrain(false, inspectMode);
	
	/////////////////////////
	
	
#ifndef cmNoGUI
	// Show statistical training results.
	// console.image(pat.templateImage(regionIndex));
	// if (MessageBox(NULL, cmT("Continue?"), cmT("Template image"), MB_OKCANCEL)
	//    == IDCANCEL)
	// return 0;
	
	// Show statistical training results.
	//  console.image(pat.thresholdImage(regionIndex));
	//  if (MessageBox(NULL, cmT("Continue?"), cmT("Threshold image"), MB_OKCANCEL)
	//      == IDCANCEL)
	//    return 0;
	
	
	
#endif
	
	
    ///////////////////////
    // �����摜
    ///////////////////////
    // Run the tool on the run-time image.
    ccPMInspectRunParams runParams;
	
    ccPMInspectResultSet resultSet;
	
    ///////////////////////
    // ���������̎��s
    pat.run(pb2, runParams, resultSet);
    if (resultSet.results().empty()){
		;
	}
    ccPMInspectIntensityParams intParams;
    ccPMInspectIntensityData intData;
    const ccPMInspectResult& result = resultSet.results()[0];
    result.getIntensityDiff(intData, regionIndex, intParams);
	
    
	
	// Show statistical training results.
	console.image(result.diffImage(regionIndex));
	if (MessageBox(NULL, cmT("Continue?"), cmT("�����C���[�W"), MB_OKCANCEL)
		== IDCANCEL)
		return 0;
	// ��v�����摜��\��
	// console.image(result.matchImage(regionIndex));
	// if (MessageBox(NULL, cmT("Continue?"), cmT("��v�C���[�W"), MB_OKCANCEL)
	//     == IDCANCEL)
	//  return 0;
	
	
	
	////////////////////
	// 臒l�摜���擾
	ccPelBuffer_const<c_UInt8> PatIsp = result.diffImage(regionIndex);
	
	
	
	//////////////////////////////////////////////////////////////////
	// Histogram Tool 
	
	// �@�����摜�̍ō��P�x
	
	// run histogram
	cmStd vector<c_UInt32> histogram(256);
	for(int i=0; i<256; i++){
		histogram[i] = 0;
	}
	////////////////////
	// �q�X�g�O�����̃p�����[�^
	cfPelHistogram(PatIsp, histogram);
	// compute some histogram statistics
	ccHistoStats stats(histogram);
	
	stats.max();	// �ő�l
	cogOut << cmT("PatIsp Th Max_Hist = ") << stats.max() << cmStd endl;
	
	
	// �A�o�^�摜�̕��ϋP�x�l�A�Œ�P�x�l
	for(int j=0; j<256; j++){
		histogram[j] = 0;
	}
	////////////////////
	// �q�X�g�O�����̃p�����[�^
	cfPelHistogram(pb2, histogram);
	// compute some histogram statistics
	ccHistoStats stats_align(histogram);
	
	cogOut << cmT("Align min_Hist = ") << stats_align.min() << cmStd endl;
	cogOut << cmT("Align mean_Hist = ") << stats_align.mean() << cmStd endl;
	
	
	
	
	
	//////////////////////////////////////////////////////////////////
	// Blob Tool 
	
	// Do simple greyscale analysis, so the default parameters work fine
	ccBlobParams blobParams; // �ݒ�p�����[�^�@
	
	// 臒l�@
	//  int threshold = 30;
	int threshold = (int )stats_align.mean();
	
	
	// �������@�ݒ�
	blobParams.setSegmentationHardThresh(abs(threshold), (0 < threshold) ? true : false);
	
	// ���t�H���W���� 
	// �c��X�񁨎��kY��
	int blodM_X = 4;
	int blodM_Y = 4;
	int blob_num = blodM_X + blodM_Y;
	
	cmStd vector<ceBlobParamsMorphOp> blobMorphs(blob_num);
	///////////////
	// �c��
	for(int k = 0; k < blodM_X; k++){
		blobMorphs[k] = (ceBlobParamsMorphOp)eMinS;
	}
	///////////////
	// ���k
	for(int l = blodM_X; l < blob_num; l++){
		blobMorphs[l] = (ceBlobParamsMorphOp)eMaxS;
	}
	blobParams.morph(blobMorphs);
	blobParams.keepMorphed(true);	// �t�B���^������̉摜��ێ�����
	
	// �A�������^�C�v�@
	//blobParams.connectivityCleanup(ccBlobSceneDescription::ePrune); //
	blobParams.connectivityCleanup(ccBlobSceneDescription::eFill);  // �h��Ԃ��^�C�v
	// �A�������^�C�v�A
	blobParams.connectivityType(ccBlobSceneDescription::eGreyScale);     // Grayscall
	
	// �ŏ��v�̃T�C�Y
	int judgecount = 3;
	blobParams.connectivityMinPels(judgecount);
	
	///////////////
	// compute
	// blobParams.preCompute(ccBlobSceneDescription::eInertiaX);
	
	
	
	ccBlobResults blobResults;	// ����
	
	
	///////////////
	// ���s
	cfBlobAnalysis(PatIsp, blobParams, blobResults);
	
	ccBlobSceneDescription* bsd = blobResults.connectedBlobs();
	// #DDT161021-01
	bsd->setFilter(ccBlob::eArea, 0, 100, true);
	
	///////////////
	// compute
	//  bsd->preCompute(ccBlobSceneDescription::eDescending);
	
	
	///////////////
	// �傫�����Ƀ\�[�g
	bsd->setSort(ccBlob::eArea, ccBlobSceneDescription::eDescending);
	//  cmStd vector<const ccBlob*> blobs = bsd->firstTop();
	const ccBlob *blobs = bsd->firstTop();
	
	
	
	///////////////
	// ��̂������l
	//  int jx = 100, jy = 100;	// ������������
	int jx = 30, jy = 30;	// ������������
	double AllArea = 0;
	if(blobs){ // �򂠂�
		//	if (jx < blobs->boundingBox().size().x()
		//		|| jy < blobs->boundingBox().size().y()) {
		//		// ��̃T�C�Y���傫��
		//	}
		//	AllArea += blobs->area();
		//	for (blobs = blobs->firstChild(); blobs; blobs = blobs->nextSibling()) {
		//		AllArea += blobs->area();
		//	}
		//	if (judgecount > AllArea) {
		//		;	// �ʐς�������
		//	}
		
	}else{	// ��Ȃ�
		// �I��
		return 0;
	}
	
	
	///////////////
	// �摜�\��
	if(blobParams.keepMorphed()){
		ccPelBuffer<c_UInt8> pbx(blobResults.morphed().image());
		std::vector<c_UInt8> map(2);
		map[0] = 255;
		map[1] = 0;
		ccPelBuffer<c_UInt8> mappedImage = cfPelMap(pbx, map);
		console.image(mappedImage);
		if (MessageBox(NULL, cmT("Continue?"), cmT("Blob image"), MB_OKCANCEL)
			== IDCANCEL)
			return 0;
	}
	
	
	/*
	for (unsigned int i = 0 ; i < blobs.size() ; i++)
	{
    cc2Vect com(blobs[i]->centerOfMass());
    cogOut << cmT("Feature: ") << cmStd setw(3) << i+1 <<
	cmT(" Label: ") << cmStd setw(3) << (int)blobs[i]->label() <<
	cmT(" Area: ") << cmStd setw(3) << blobs[i]->area() <<
	cmT(" Center of mass: (") << com.x() << cmT(",") << com.y() << cmT(")") << cmStd endl;
	}
	*/
	
	
	return 0;
}

void ChangeColor(ccGraphicList glist){
 // �O���t�B�b�N���X�g�̔z��擾
    std::vector<ccGraphicPtrh>&    cItems = glist.items();

    // �O���t�B�b�N�v�f�����[�v
    for( std::vector<ccGraphicPtrh>::iterator cIter = cItems.begin() ; cIter != cItems.end() ; ++cIter )
    {
        // ���E�g���[�X
        if( dynamic_cast<ccGraphicPolyline*>( cIter->rep() ) )
        {
            ccGraphicPolyline* pPoly = dynamic_cast<ccGraphicPolyline*>( cIter->rep() );
            ccGraphicProps cProps;
            cProps.penColor( ccColor::greenColor() );
            cProps.fill( true );
            pPoly->props( cProps );
        }
    }
}

int ToolStgGDTest(int threshold, CString teachFilePath, CString testFilePath, CWnd *pWnd, CWnd* pWnd2)
{
	//ccWorkerThreadManagerParams params;
	//params.desiredWorkerThreads(ccWorkerThreadManagerDefs::eWorkerThreadsSpecified);
	//params.workerThreadCount(3);
	//ccWorkerThreadManager::configure(params);
	
	cmStd vector<ccPelBuffer</*c_UInt8*/c_UInt32> > trainImages, runImages;
	createTrainingImages(trainImages);
	createRuntimeImages(runImages);
	
	const c_Int32 numTrainImages = static_cast<c_Int32>(trainImages.size());
	const c_Int32 numRunImages = static_cast<c_Int32>(runImages.size());
	
	// Display image window
	ccWin32Display display(pWnd->m_hWnd);
	ccWin32Display display2(pWnd2->m_hWnd);
	ccDIB dib;
	ccDIB dib2;

	// Get image file (teach pattern)
	////////////////////
	// �摜���t�@�C������I���ł���悤(�e�B�[�`���O�摜�g���C���Ώ�)
	dib.init((LPCTSTR)teachFilePath);
	ccPelBuffer<c_UInt8> pb = dib.pelBuffer();
	// Display teaching pattern
	display.image(pb);  // �I�������摜�f�[�^���擾
	display.fit();
	Sleep(1000);
	// Get image file (recognition pattern)
	////////////////////
	// �摜���t�@�C������I���ł���悤(���ۂ̔F���摜)
	dib2.init((LPCTSTR)testFilePath);
	ccPelBuffer<c_UInt8> pb2 = dib2.pelBuffer();
	// Display recognition pattern
	display2.image(pb2);  // �I�������摜�f�[�^���擾
	display2.fit();
	Sleep(1000);


	ccCnlSearchTrainParams
		trainParams(ccCnlSearchDefs::eNormalizedCnlpas);
	ccCnlSearchModel model;
	cc2Vect modelCenter (
		pb.offset().x() + pb.width()/2.0,
		pb.offset().y() + pb.height()/2.0);
	// Adjust origin for client coordinates
	//
	modelCenter = pb.clientFromImageXform()* modelCenter;
	model.origin(modelCenter);

	model.train (pb, trainParams);

	ccCnlSearchResultSet results;
	
	ccCnlSearchRunParams runParams(
		ccCnlSearchDefs::eNormalizedCnlpas);
	runParams.accept (0.9);
	runParams.confusion (0.95);
	runParams.maxNumResults (10);

	model.run (pb2, runParams, results);

	// Print the position and score for each result.
	//
	for (int i = 0; i < results.results().size(); i++)
	{
		cogOut << "Result " << i+1 << ": ";
		if (results.results()[i].found())
		{
			cogOut << "Score = " << results.results()[i].score()<< cmStd endl;
		}
		else
			cogOut << "Not Found" << cmStd endl;
	}
	ccGraphicList graphList;
	
	results.draw(graphList);
	display2.drawSketch(graphList.sketch(), ccDisplayConsole::eClientCoords);


#if 0
	//////////////////////////////////////////////////////////////////
	// Histogram Tool 
	cmStd vector<c_UInt32> histogram(256);
	for(int i=0; i<256; i++){
		histogram[i] = 0;
	}
	////////////////////
	// �q�X�g�O�����̃p�����[�^
	// Calculate histogram from trained pattern
	cfPelHistogram(pb, histogram);
	// Compute some histogram statistics
	ccHistoStats stats(histogram);
	
	// Log histogram result
	cogOut << cmT("Teaching Th Max_Hist = ") << stats.max() << cmStd endl;
	cogOut << cmT("Teaching Th Min_Hist = ") << stats.min() << cmStd endl;
	cogOut << cmT("Teaching Th Mean_Hist = ") << stats.mean() << cmStd endl;

	// �A�o�^�摜�̕��ϋP�x�l�A�Œ�P�x�l
	for(int j=0; j<256; j++){
		histogram[j] = 0;
	}
	////////////////////
	// �q�X�g�O�����̃p�����[�^
	cfPelHistogram(pb2, histogram);
	// compute some histogram statistics
	ccHistoStats stats_align(histogram);
	
	// Log histogram result
	cogOut << cmT("Recog max_Hist = ") << stats_align.max() << cmStd endl;
	cogOut << cmT("Recog min_Hist = ") << stats_align.min() << cmStd endl;
	cogOut << cmT("Recog mean_Hist = ") << stats_align.mean() << cmStd endl;
	
	//////////////////////////////////////////////////////////////////
	// Blob Tool 
	
	// Do simple greyscale analysis, so the default parameters work fine
	ccBlobParams blobParams; // �ݒ�p�����[�^�@
	
	// �������@�ݒ�
	// Set threshold params
	blobParams.setSegmentationHardThresh(abs(threshold), (0 < threshold) ? true : false);
	
	// ���t�H���W���� 
	// �c��X�񁨎��kY��
	// Set morphology params
	int blodM_X = 2;			// Morphology constraction 2 times
	int blodM_Y = 2;			// Morphology expansion 2 times
	int blob_num = blodM_X + blodM_Y;
	
	cmStd vector<ceBlobParamsMorphOp> blobMorphs(blob_num);
	///////////////
	// �c��
	for(int k = 0; k < blodM_X; k++){
		blobMorphs[k] = (ceBlobParamsMorphOp)eMinS;
	}
	///////////////
	// ���k
	for(int l = blodM_X; l < blob_num; l++){
		blobMorphs[l] = (ceBlobParamsMorphOp)eMaxS;
	}
	blobParams.morph(blobMorphs);
	blobParams.keepMorphed(true);	// �t�B���^������̉摜��ێ�����
	// TODO: block filter params?

	// �A�������^�C�v�@
	//blobParams.connectivityCleanup(ccBlobSceneDescription::ePrune); //
	blobParams.connectivityCleanup(ccBlobSceneDescription::eFill);  // �h��Ԃ��^�C�v
	// �A�������^�C�v�A
	blobParams.connectivityType(ccBlobSceneDescription::eGreyScale);     // Grayscall
	
	// �ŏ��v�̃T�C�Y
	// Set connectivity smallest area param
	int judgecount = 1;		// smallest area is 1
	blobParams.connectivityMinPels(judgecount);
	
	///////////////
	// compute
	// blobParams.preCompute(ccBlobSceneDescription::eInertiaX);
	
	ccBlobResults blobResults[2];	// ����
	
	///////////////
	// ���s
	// Run blob tool for teaching pattern
	cfBlobAnalysis(pb, blobParams, blobResults[0]);
	ccGraphicList glist;
	ccBlobSceneDescription* bsd = blobResults[0].connectedBlobs();
	// #DDT161021-01
	bsd->setFilter(ccBlob::eArea, 0, 100, true);	
	///////////////
	// �傫�����Ƀ\�[�g
	bsd->setSort(ccBlob::eArea, ccBlobSceneDescription::eDescending);
	//  cmStd vector<const ccBlob*> blobs = bsd->firstTop();
	const ccBlob *blobs = bsd->firstTop();

	// Log out number of blobs found
	cogOut << cmT("Teaching Number of Blobs = ") << bsd->numBlobs() << cmStd endl;
	
	///////////////
	// ���s
	// Run blob tool for recognition pattern
	cfBlobAnalysis(pb2, blobParams, blobResults[1]);
	
	ccBlobSceneDescription* bsd2 = blobResults[1].connectedBlobs();
	bsd2->setFilter(ccBlob::eArea, 0, 100, true);
	///////////////
	// �傫�����Ƀ\�[�g
	bsd2->setSort(ccBlob::eArea, ccBlobSceneDescription::eDescending);
	//  cmStd vector<const ccBlob*> blobs = bsd->firstTop();
	const ccBlob *blobs2 = bsd2->firstTop();

	// Log out number of blobs found
	cogOut << cmT("Recog Number of Blobs = ") << bsd2->numBlobs() << cmStd endl;

	///////////////
	// �摜�\��
	if(blobParams.keepMorphed()){
		ccPelBuffer<c_UInt8> pbx(blobResults[0].morphed().image());
		std::vector<c_UInt8> map(2);
		map[0] = 255;
		map[1] = 0;
		ccPelBuffer<c_UInt8> mappedImage = cfPelMap(pbx, map);
		
		display.image(mappedImage);	
		bsd->draw(glist, ccBlobDefs::eDrawBoundingTrace);
		// �O���t�B�b�N���X�g�̔z��擾
		std::vector<ccGraphicPtrh>&    cItems = glist.items();
		
		// �O���t�B�b�N�v�f�����[�v
		for( std::vector<ccGraphicPtrh>::iterator cIter = cItems.begin() ; cIter != cItems.end() ; ++cIter )
		{
			// ���E�g���[�X
			if( dynamic_cast<ccGraphicPolyline*>( cIter->rep() ) )
			{
				ccGraphicPolyline* pPoly = dynamic_cast<ccGraphicPolyline*>( cIter->rep() );
				ccGraphicProps cProps;
				cProps.penColor( ccColor::greenColor() );
				cProps.fill( true );
				pPoly->props( cProps );
			}
		}
		
		display.drawSketch(glist.sketch(), ccDisplayConsole::eClientCoords);

		ccPelBuffer<c_UInt8> pbx2(blobResults[1].morphed().image());
		std::vector<c_UInt8> map2(2);
		map2[0] = 255;
		map2[1] = 0;
		ccPelBuffer<c_UInt8> mappedImage2 = cfPelMap(pbx2, map2);
		display2.image(mappedImage2);
		bsd2->draw(glist, ccBlobDefs::eDrawBoundingTrace);
		cItems = glist.items();
		
		// �O���t�B�b�N�v�f�����[�v
		for( cIter = cItems.begin() ; cIter != cItems.end() ; ++cIter )
		{
			// ���E�g���[�X
			if( dynamic_cast<ccGraphicPolyline*>( cIter->rep() ) )
			{
				ccGraphicPolyline* pPoly = dynamic_cast<ccGraphicPolyline*>( cIter->rep() );
				ccGraphicProps cProps;
				cProps.penColor( ccColor::greenColor() );
				cProps.fill( true );
				pPoly->props( cProps );
			}
		}		
		display2.drawSketch(glist.sketch(), ccDisplayConsole::eClientCoords);
	}
#endif
	return 0;
}
//////////////////////
// Collette garbage detection test
int ColletteGDTest(int threshold, CString teachFilePath, CString testFilePath, CWnd *pWnd)
{
	//ccWorkerThreadManagerParams params;
	//params.desiredWorkerThreads(ccWorkerThreadManagerDefs::eWorkerThreadsSpecified);
	//params.workerThreadCount(3);
	//ccWorkerThreadManager::configure(params);
	
	cmStd vector<ccPelBuffer</*c_UInt8*/c_UInt32> > trainImages, runImages;
	createTrainingImages(trainImages);
	createRuntimeImages(runImages);
	
	const c_Int32 numTrainImages = static_cast<c_Int32>(trainImages.size());
	const c_Int32 numRunImages = static_cast<c_Int32>(runImages.size());
	
	ccWin32Display display(pWnd->m_hWnd);
	ccDIB dib;
	ccDIB dib2;
	
	////////////////////
	// �摜���t�@�C������I���ł���悤(�e�B�[�`���O�摜�g���C���Ώ�)
	dib.init((LPCTSTR)teachFilePath);
	ccPelBuffer<c_UInt8> pb = dib.pelBuffer();
	////////////////////
	display.image(pb);  // �I�������摜�f�[�^���擾
	display.fit();
	Sleep(1000);
	
	////////////////////
	// �摜���t�@�C������I���ł���悤(���ۂ̔F���摜)
	dib2.init((LPCTSTR)testFilePath);
	ccPelBuffer<c_UInt8> pb2 = dib2.pelBuffer();
	////////////////////
	display.image(pb2);  // �I�������摜�f�[�^���擾
	display.fit();
	Sleep(1000);
	
	//////////////////////////////////////////////////////////////////
	// Histogram Tool 
	
	// �@�����摜�̍ō��P�x
	
	// run histogram
	cmStd vector<c_UInt32> histogram(256);
	for(int i=0; i<256; i++){
		histogram[i] = 0;
	}
	////////////////////
	// �q�X�g�O�����̃p�����[�^
	cfPelHistogram(pb, histogram);
	// compute some histogram statistics
	ccHistoStats stats(histogram);

	cogOut << cmT("Teach Th Max_Hist = ") << stats.max() << cmStd endl;
	cogOut << cmT("Teach Th Min_Hist = ") << stats.min() << cmStd endl;
	cogOut << cmT("Teach Th Mean_Hist = ") << stats.mean() << cmStd endl;
	
	// �A�o�^�摜�̕��ϋP�x�l�A�Œ�P�x�l
	for(int j=0; j<256; j++){
		histogram[j] = 0;
	}
	////////////////////
	// �q�X�g�O�����̃p�����[�^
	cfPelHistogram(pb2, histogram);
	// compute some histogram statistics
	ccHistoStats stats_align(histogram);
	
	cogOut << cmT("Align max_Hist = ") << stats_align.max() << cmStd endl;
	cogOut << cmT("Align min_Hist = ") << stats_align.min() << cmStd endl;
	cogOut << cmT("Align mean_Hist = ") << stats_align.mean() << cmStd endl;

	///////////////////////////////
	// PatInspect paramater �ʒu�o�^�ݒ�
	ccPMInspectPattern pat;
	//
	const ccPMInspectDefs::InspectMode inspectMode =
		ccPMInspectDefs::eIntensityDifference;	// VisionPRo�ɂ͂��ꂵ���Ȃ�
	// (P1292) pb�摜�\����5�k������̊��������ΏۂƂ���
	// �����ł���̂�5pix�ȏ�Ȃ̂ł����Ń`�F�b�N����
	const ccPelRect inspectRegion(pb.window().trim(/*X*/5,/*Y*/ 5,/*w*/ 5,/*h*/ 5));
	
	pat.addInspectRegion(inspectRegion, inspectMode);		// starttrain�O�ɌĂяo���K�v����
	
	// Set properties for the inspection region.
	// - enable defect extraction
	// - use the ccPMInspectDefs::eLocalCorrectionEnhanced preprocessing method
	//   to improve the tool's tolerance of lighting variations.
	// - set neighborhood size for image preprocessing
	const c_Int32 regionIndex = 0;
	ccPMInspectRegion& region = pat.inspectRegion(regionIndex);
	region.extractIntensityDefects(true);
	region.preprocessing(ccPMInspectDefs::eLocalCorrectionEnhanced);
	// The default neighborhoodSize value 101x101 may be okay for many images.
	// Uncomment the following line if you want to change it.
	// region.neighborhoodSize(ccIPair(50, 50));
	
	///////////////////////
	// Setting sobel params
	// scale 2, offset 10
	ccDPair coeffs_s(2,10);	// 
	pat.sobelCoeffs(coeffs_s);
	
	///////////////////////
	// �������������l
	// Setting threshold params #DDT161012-TODO (param scale:1, offset:1)
	ccDPair coeffs_t(1,1);	// 
	pat.thresholdCoeffs(coeffs_t);
	
	/////////////////////////
	// Statistically train the tool, using the internal alignment model.
	ccPMInspectStatTrainParams trainParams;

	pat.startTrain(pb);		//�@�摜�̓o�^���s���B(�e�B�[�`���O�����摜)
	
	/////////////////
	// Train���s��(�TPix�`�F�b�N���s���B)
	pat.statisticTrain(pb, trainParams, inspectMode);	// �F���������摜
	pat.endTrain(false, inspectMode);
	
	/////////////////////////
	
	
    ///////////////////////
    // �����摜
    ///////////////////////
    // Run the tool on the run-time image.
    ccPMInspectRunParams runParams;
	
    ccPMInspectResultSet resultSet;
	
    ///////////////////////
    // ���������̎��s
    pat.run(pb2, runParams, resultSet);
    if (resultSet.results().empty()){
		;
	}
    ccPMInspectIntensityParams intParams;
    ccPMInspectIntensityData intData;
    const ccPMInspectResult& result = resultSet.results()[0];
    result.getIntensityDiff(intData, regionIndex, intParams);
	
	// Show statistical training results.
	display.image(result.diffImage(regionIndex));
	if (MessageBox(NULL, cmT("Continue?"), cmT("�����C���[�W"), MB_OKCANCEL)
		== IDCANCEL)
		return 0;	
	
	////////////////////
	// 臒l�摜���擾
	ccPelBuffer_const<c_UInt8> PatIsp = result.diffImage(regionIndex);
	
	//////////////////////////////////////////////////////////////////
	// Blob Tool 
	
	// Do simple greyscale analysis, so the default parameters work fine
	ccBlobParams blobParams; // �ݒ�p�����[�^�@	
	
	// �������@�ݒ�
	blobParams.setSegmentationHardThresh(abs(threshold), (0 < threshold) ? true : false);
	
	// ���t�H���W���� 
	// �c��X�񁨎��kY��
	// Setting morphology params
	int blodM_X = 2;		// constraction 2 times
	int blodM_Y = 2;		// expansion 2 times
	int blob_num = blodM_X + blodM_Y;
	
	cmStd vector<ceBlobParamsMorphOp> blobMorphs(blob_num);
	///////////////
	// �c��
	for(int k = 0; k < blodM_X; k++){
		blobMorphs[k] = (ceBlobParamsMorphOp)eMinS;
	}
	///////////////
	// ���k
	for(int l = blodM_X; l < blob_num; l++){
		blobMorphs[l] = (ceBlobParamsMorphOp)eMaxS;
	}
	blobParams.morph(blobMorphs);
	blobParams.keepMorphed(true);	// �t�B���^������̉摜��ێ�����
	
	// �A�������^�C�v�@
	//blobParams.connectivityCleanup(ccBlobSceneDescription::ePrune); //
	blobParams.connectivityCleanup(ccBlobSceneDescription::eFill);  // �h��Ԃ��^�C�v
	// �A�������^�C�v�A
	blobParams.connectivityType(ccBlobSceneDescription::eGreyScale);     // Grayscall
	
	// �ŏ��v�̃T�C�Y
	// Setting connnectivity smallest area param
	int judgecount = 1;
	blobParams.connectivityMinPels(judgecount);
	
	ccBlobResults blobResults;	// ����
	
	///////////////
	// ���s
	cfBlobAnalysis(PatIsp, blobParams, blobResults);
	ccGraphicList glist;
	ccBlobSceneDescription* bsd = blobResults.connectedBlobs();
	// #DDT161021-01
	bsd->setFilter(ccBlob::eArea, 0, 100, true);	
	///////////////
	// �傫�����Ƀ\�[�g
	bsd->setSort(ccBlob::eArea, ccBlobSceneDescription::eDescending);
	//bsd->setFilter(ccBlob::eArea, 0, 500, true);
	//  cmStd vector<const ccBlob*> blobs = bsd->firstTop();
	const ccBlob *blobs = bsd->firstTop();
	
	// Log out number of blobs found
	cogOut << cmT("DiffImage Number of Blobs = ") << bsd->numBlobs() << cmStd endl;
	
	
	///////////////
	// �摜�\��
	if(blobParams.keepMorphed()){
		ccPelBuffer<c_UInt8> pbx(blobResults.morphed().image());
		std::vector<c_UInt8> map(2);
		map[0] = 255;
		map[1] = 0;
		ccPelBuffer<c_UInt8> mappedImage = cfPelMap(pbx, map);
		display.image(mappedImage);
		bsd->draw(glist, ccBlobDefs::eDrawBoundingTrace);
		
		// �O���t�B�b�N���X�g�̔z��擾
		std::vector<ccGraphicPtrh>&    cItems = glist.items();
		
		// �O���t�B�b�N�v�f�����[�v
		for( std::vector<ccGraphicPtrh>::iterator cIter = cItems.begin() ; cIter != cItems.end() ; ++cIter )
		{
			// ���E�g���[�X
			if( dynamic_cast<ccGraphicPolyline*>( cIter->rep() ) )
			{
				ccGraphicPolyline* pPoly = dynamic_cast<ccGraphicPolyline*>( cIter->rep() );
				ccGraphicProps cProps;
				cProps.penColor( ccColor::greenColor() );
				cProps.fill( true );
				pPoly->props( cProps );
			}
		}

		display.drawSketch(glist.sketch(), ccDisplayConsole::eClientCoords);
						
		CRect rect;
		pWnd->GetClientRect(&rect);

				  		ccUIFormat txtFormat(0, ccUIFormat::eTopLeft);
						ccUITablet tablet;
						CString	msg;
						msg.Format("%d%%", bsd->numBlobs());
						tablet.draw((char*)LPCSTR(msg), cc2Vect(rect.right-50,rect.bottom-30),
							ccColor::green,ccColor::pass,txtFormat);
						display.drawSketch(tablet.sketch(), ccDisplay::eDisplayCoords);

		if (MessageBox(NULL, cmT("Continue?"), cmT("Blob image"), MB_OKCANCEL)
			== IDCANCEL)
			return 0;
	}
	
	return 0;
}
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////


// The following functions are simple utilities used in this sample code
// to create test data. They are not necessary on a production system.
#include <ch_cvl/pelfunc.h>

static ccPelBuffer</*c_UInt8*/c_UInt32> makeLImage(c_Int32 width, c_Int32 height,
                                       ccPelRect lWindow, c_Int32 lThickness,
                                       /*c_UInt8*/c_UInt32 fg, /*c_UInt8*/c_UInt32 bg)
{
	ccPelBuffer</*c_UInt8*/c_UInt32> image(width, height);
	ccPelBuffer</*c_UInt8*/c_UInt32> tmpWin(image);
	
	cfPelSet(image, bg);
	tmpWin.window(lWindow);
	cfPelSet(tmpWin, fg);
	const c_Int32 lWidth = lWindow.width(), lHeight = lWindow.height();
	tmpWin.subWindow(lThickness, 0, lWidth - lThickness, lHeight - lThickness);
	cfPelSet(tmpWin, bg);
	
	return image;
}

static void createTrainingImages(cmStd vector<ccPelBuffer</*c_UInt8*/c_UInt32> >& images)
{
	
	// �摜�쐬
	images.clear();
	const c_Int32 width = 256, height = 256, thickness = 48;
	const ccPelRect window(32, 32, 192, 192);
	const /*c_UInt8*/c_UInt32 fg = 200, bg = 100;
	images.push_back(makeLImage(width, height, window, thickness, fg, bg));
	//  images.push_back(makeLImage(width, height, window, thickness+1, fg+4, bg-2));
	images.push_back(makeLImage(width, height, window, thickness+10, fg+4, bg-2));
	images.push_back(makeLImage(width, height, window, thickness-1, fg-3, bg+2));
}

static void createRuntimeImages(cmStd vector<ccPelBuffer</*c_UInt8*/c_UInt32> >& images)
{
	createTrainingImages(images);
	images.resize(1);
	ccPelBuffer</*c_UInt8*/c_UInt32> win(images[0]);
	win.window(40, 100, 10, 10);
	cfPelSet(win, 255);
	cfPelSet(win, 1);	// ��
	win.window(50, 200, 10, 20);
	cfPelSet(win, 250);
	win.window(120, 150, 20, 10);
	cfPelSet(win, 50);
	//  win.window(200, 64, 20, 20);
	win.window(47, 57, 2, 2);
	cfPelSet(win, 150);
}

static ccCvlString polarityString(ccPMInspectDefs::DefectPolarity p)
{
	if (p == ccPMInspectDefs::eDarkOnLight)
		return cmT("eDarkOnLight");
	else if (p == ccPMInspectDefs::eLightOnDark)
		return cmT("eLightOnDark");
	return cmT("InvalidEnumValue");
}

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GarbageDetectTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GARBAGTYPE                  129
#define IDD_DIALOG_GD                   130
#define IDC_EDIT_THRESHOLD              1000
#define ID_COLLETTE_START               1001
#define IDC_EDIT_TEACH_FILEPATH         1002
#define IDC_STATIC_FILE_TEACH           1003
#define IDC_STATIC_FILE_TEACH2          1004
#define IDC_EDIT_TEST_FILEPATH          1005
#define IDC_BUTTON_BRTEACH              1006
#define IDC_BUTTON_BRTTEST              1007
#define IDC_STATIC_DISPLAY              1008
#define IDC_STATIC_TEACH                1009
#define IDC_STATIC_TEST                 1010
#define ID_FILE_COLLETTE                32772
#define ID_FILE_TOOL                    32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

/*==========================================*/
/*  HPCI-CPD530 series						*/
/*	Library lebel1a function for Visual C	*/
/*											*/
/*	    file name:cp530l1a.h				*/
/*      date     :2003/06/16				*/
/*      version  :2.0.0.0					*/
/*						 					*/
/*	Copyright(C) 2001-2003  Hivertec Inc.	*/
/*	All Rights Reserved.					*/
/*==========================================*/
#include	"hicpd530.h"

/* �萔��` */
#define CP53_ELS_PORT	0x80	/* ELS�ɐ��I���|�[�g */
#define CP53_DLS_PORT	0x82	/* DLS/PCS�ؑփ|�[�g */
#define CP53_CP4_PORT	0x84	/* �R���p���[�^�S�o�͐ؑփ|�[�g */
#define CP53_CP5_PORT	0x86	/* �R���p���[�^�T�o�͐ؑփ|�[�g */
#define CP53_OLS_PORT	0x88	/* CPD508 BOLS/PCS�ؑփ|�[�g */
#define CP53_ALM_PORT	0x8a	/* CPD508 SVALM/DI/EMG�ؑփ|�[�g */
#define CP57_J3CO_PRT	0x8a	/* CPD578A J3�o�̓}�X�N�|�[�g */
#define CP57_XUCO_PRT	0x8c	/* CPD578A X-U��CMP�o�͐ؑփ|�[�g */
#define CP57_VBCO_PRT	0x8e	/* CPD578A X-U��CMP�o�͐ؑփ|�[�g */
#define CP53_INT_PORT	0x90	/* �����o�̓}�X�N�|�[�g */
// #KS080804-01 AB���Ή�
#define CP53_CRECT_PORT	0xa0	/* �G���R�[�_�␳ */

// #IK050507-01(S) �������֌W�C��
#if 0
/* ���C�u�����֐��v���g�^�C�v�錾 */
#ifdef __cplusplus
extern "C"
{
#endif

DWORD hcp530_GetDevInfo(DWORD*, HPCDEVICEINFO*);
DWORD hcp530_DevOpen(DWORD*, HPCDEVICEINFO*);
DWORD hcp530_DevClose(DWORD);

DWORD hcp530_SetOrgMode(DWORD, WORD, WORD);
DWORD hcp530_SetEls(DWORD, WORD, WORD, WORD);
DWORD hcp530_SetOls(DWORD, WORD, WORD);
DWORD hcp530_SetSvAlm(DWORD, WORD, WORD, WORD);
DWORD hcp530_SetEz(DWORD, WORD, WORD, WORD);
DWORD hcp530_SetDlsSel(DWORD, WORD, WORD, WORD, WORD, WORD);
DWORD hcp530_SetInpos(DWORD, WORD, WORD, WORD);
DWORD hcp530_SetSvCtrCl(DWORD, WORD, WORD);
DWORD hcp530_SetSls(DWORD, WORD, long, long, WORD, WORD);
DWORD hcp530_SetCmdPulse(DWORD, WORD, WORD);
DWORD hcp530_SetAccProfile(DWORD, WORD, WORD);
DWORD hcp530_SetAutoDec(DWORD, WORD, WORD);

DWORD hcp530_ReadMainSts(DWORD, WORD, WORD*);
DWORD hcp530_ReadErrorSts(DWORD, WORD, DWORD*);
DWORD hcp530_ReadEventSts(DWORD, WORD, DWORD*);
DWORD hcp530_ReadSubSts(DWORD, WORD, WORD*);
DWORD hcp530_ReadExSts(DWORD, WORD, DWORD*);
DWORD hcp530_ReadIpSts(DWORD, DWORD*);
DWORD hcp530_ReadSpd(DWORD, WORD, WORD*);
DWORD hcp530_ReadCtr(DWORD, WORD, WORD, long*);

DWORD hcp530_SetFLSpd(DWORD, WORD, DWORD);
DWORD hcp530_SetAuxSpd(DWORD, WORD, DWORD);
DWORD hcp530_SetAccRate(DWORD, WORD, DWORD);
DWORD hcp530_SetDecRate(DWORD, WORD, DWORD);
DWORD hcp530_SetMult(DWORD, WORD, DWORD);
DWORD hcp530_SetEventMask(DWORD, WORD, DWORD);
DWORD hcp530_SetDecPoint(DWORD, WORD, long);

DWORD hcp530_WritOpeMode(DWORD, WORD, WORD);
DWORD hcp530_WritFHSpd(DWORD, WORD, DWORD);
DWORD hcp530_WritPos(DWORD, WORD, long);
DWORD hcp530_WritLine(DWORD, WORD, long);
DWORD hcp530_WritCircl(DWORD, WORD, long, long, long, long);
DWORD hcp530_WritCtr(DWORD, WORD, long, WORD);

DWORD hcp530_DecStop(DWORD, WORD);
DWORD hcp530_QuickStop(DWORD, WORD);
DWORD hcp530_EmgStop(DWORD, WORD);
DWORD hcp530_AccStart(DWORD, WORD);
DWORD hcp530_CnstStartFH(DWORD, WORD);
DWORD hcp530_CnstStartFL(DWORD, WORD);
DWORD hcp530_ConstStartByDec(DWORD hDevID, WORD axis)
DWORD hcp530_CnstStartByDec(DWORD, WORD);
DWORD hcp530_SvOn(DWORD, WORD);
DWORD hcp530_SvOff(DWORD, WORD);
DWORD hcp530_SvResetOn(DWORD, WORD);
DWORD hcp530_SvResetOff(DWORD, WORD);
DWORD hcp530_PMOn(DWORD, WORD);
DWORD hcp530_PMOff(DWORD, WORD);

/* 2001/05/21�֐��ǉ� */
DWORD hcp530_CalAccRate(DWORD*, DWORD, DWORD, DWORD, WORD, WORD);

/* 2001/11/01�֐��ǉ� */
DWORD hcp530_SyDecStop(DWORD, WORD);
DWORD hcp530_SyQuickStop(DWORD, WORD);

#ifdef __cplusplus
}
#endif

#endif
// #IK050507-01(E)
/*---------------------------------------------------------------------
	������ى�ʊ֐��i�i���ް�:�c�[�����j

	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_ToolInfo(int step,int page)
{
	int OptIdx = 0;
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r=OK_END;
	for(;;){
		if(step == 0){		// �ް��ݒ�
			if(page ==1)		r = DVd_ToolInfo1();
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}


////////////////////////////////////////////////////////////////////////////////-
// �c�[�����i�f�[�^�ݒ�j
int TPCtrl::DVd_ToolInfo1()
{
	enum {
		// ��ʔԍ�
		SNo					= 1100,		// ���No.
		// �\���f�[�^�C���f�b�N�X
		SupAng				= 304,		// �����p�x
		RngHold				= 314,		// �ݸ����ޓ��a
		// �{�^���C���f�b�N�X
		KeyWfrSize12		= 64,		// ��ʻ���12���
		KeyWfrSize6			= 65,		// ��ʻ���6���
		// ��ԕێ��C���f�b�N�X
		AttWfrSize6			= 200,		// ��ʻ���6���
		AttWfrSize8			= 201,		// ��ʻ���8���
		// ���ʃ{�^���C���f�b�N�X
		KeyHome				= '0',
		KeyPrev				= '1',

		// KTV#170828: Add variables for Tool information(S)
		KeyToolIndex		= 83,
		KeyToolPitch		= 84,
		KeyHoleRadius		= 85,

		ToolIndexX			= 334,
		ToolIndexY			= 336,
		ToolPitchX			= 338,
		ToolPitchY			= 340,
		HoleRadius			= 342,
		// KTV#170828: Add variables for Tool information(E)

	};
	int	r;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

	DataPut(ToolIndexX, pMCC->BND.MD.ToolD.toolIndex.X(), 1);
	DataPut(ToolIndexY, pMCC->BND.MD.ToolD.toolIndex.Y(), 1);
	DataPut(ToolPitchX, pMCC->BND.MD.ToolD.toolPitch.X(), 1);
	DataPut(ToolPitchY, pMCC->BND.MD.ToolD.toolPitch.Y(), 1);
	DataPut(HoleRadius, pMCC->BND.MD.ToolD.holeRadius, 1);

	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;

		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
	for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			switch(key){
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyToolIndex:
					{	
						const char *msg[] = {
							"Tool Index X",
							"Tool Index X",
						};

						const char *msg1[] = {
							"Tool Index Y",
							"Tool Index Y",
						};

						double toolIndexX = pMCC->BND.MD.ToolD.toolIndex.X();
						if (DataEdit(msg[Lang], "", toolIndexX, 0, 255, 1)) {
							pMCC->BND.MD.ToolD.toolIndex.x = toolIndexX;
							DataPut(ToolIndexX, pMCC->BND.MD.ToolD.toolIndex.X(), 1);
							DataUpdate = true;
						}
						
						double toolIndexY = pMCC->BND.MD.ToolD.toolIndex.Y();
						if (DataEdit(msg1[Lang], "", toolIndexY, 0, 255, 1)) {
							pMCC->BND.MD.ToolD.toolIndex.y = toolIndexY;
							DataPut(ToolIndexY, pMCC->BND.MD.ToolD.toolIndex.Y(), 1);
							DataUpdate = true;
						}
					}
					break;
				case KeyToolPitch:
					{
						const char *msg[] = {
							"Tool PitchX",
							"Tool PitchX",
						};
						const char *msg1[] = {
							"Tool PitchY",
							"Tool PitchY",
						};

						double toolPitchX = pMCC->BND.MD.ToolD.toolPitch.X();
						double toolPitchY = pMCC->BND.MD.ToolD.toolPitch.Y();

						if (DataEdit(msg[Lang], "mm", toolPitchX, 0, 255, 1)) {
							pMCC->BND.MD.ToolD.toolPitch.x = toolPitchX;
							DataPut(ToolPitchX, pMCC->BND.MD.ToolD.toolPitch.X(), 1);
							DataUpdate = true;
						}

						if (DataEdit(msg1[Lang], "mm", toolPitchY, 0, 255, 1)) {
							pMCC->BND.MD.ToolD.toolPitch.y = toolPitchY;
							DataPut(ToolPitchY, pMCC->BND.MD.ToolD.toolPitch.Y(), 1);
							DataUpdate = true;
						}
					}
					break;
				case KeyHoleRadius:
					{
						const char *msg[] = {
							"Hole Radius",
							"Hole Radius",
						};
						double holeRadius = pMCC->BND.MD.ToolD.holeRadius;
						if (DataEdit(msg[Lang], "mm", holeRadius, 0, 255, 1)) {
							pMCC->BND.MD.ToolD.holeRadius = holeRadius;
							DataPut(HoleRadius, pMCC->BND.MD.ToolD.holeRadius, 1);
							DataUpdate = true;
						}
					}
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	return	r;
}
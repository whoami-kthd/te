/*---------------------------------------------------------------------
	�į�߳����@ײ����
								1996 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------
 #0001 97/02/04	ٰ�ߌv���֘A�̏������߲قɂ�镪��
 #0002 97/02/04	�į�߳����̓����Ԃ̎擾�֐��ǉ�
---------------------------------------------------------------------*/
#include	<conio.h>
#include	<stdio.h>
#include	<time.h>
#include	<stdlib.h>
#include	<search.h>
#include	<sys\types.h>
#include	<sys\timeb.h>
#include	<windows.h>
#include	"swatch.h"
/////////////////////////////////////////////////////////////////////
//	�ÓI�ް����� �����ݒ�
#ifdef TimmerCount_USE		// #0001
long StopWatch::CycleTime=0;
long StopWatch::CycleLoopCount=0;
double StopWatch::LoopTime=0;
#endif
/////////////////////////////////////////////////////////////////////
//	�ݽ�׸�
StopWatch::StopWatch(long time)
{
	StopWatch::Reset(time);
}

/////////////////////////////////////////////////////////////////////
//	ؾ��
void StopWatch::Reset(long time)
{
	s_time = 0;			// �v����~�� 
	if(time < 0)	time = 0;
	initd 	= time;			// �����l
	sw 		= time;			// �į�߳��� �o��or�c�莞��
}

/////////////////////////////////////////////////////////////////////
//	����
void StopWatch::Start()
{
	timeb	tb;
	if(s_time == 0){	// �v����~�� 
		ftime(&tb);	// ���݂̎��������o�� 
		s_time 	= tb.time;
		s_mtime = tb.millitm;
	}
}
/////////////////////////////////////////////////////////////////////
//	�į��
long StopWatch::Stop()
{
	long	r;
	long	t;
	timeb	tb;
	
	if(s_time == 0){	// �v����~�� 
		r = sw;	
	}
	else{
		ftime(&tb);	// ���݂̎��������o��
					// �o�ߎ��ԎZ�o 
		t = tb.time - s_time;	// �b�P��
		t = t * 1000;
		t += tb.millitm;		// �ؕb�P��
		t = t - s_mtime;
		if(t < 0)		r = -1L;
		else{
			if(initd == 0){	// �ݸ����Ӱ��
				sw += t;
			}
			else{			// �޸����Ӱ��
				sw -= t;
				if(sw < 0)	sw = 0;
			}
			r = sw;
		}
		s_time = 0;	// �v����~ 
	}
	return(r);
}
/////////////////////////////////////////////////////////////////////
//	�ǂݏo��
long StopWatch::Read()
{
	long	r,t;
	timeb	tb;
	
	if(s_time == 0){	// �v����~�� 
		r = sw;
	}
	else{
		ftime(&tb);
		t = tb.time - s_time;	// �b�P��
		t = t * 1000;
		t += tb.millitm;		// �ؕb�P��
		t = t - s_mtime;
		if(t < 0)		r = -1L;
		else{
			if(initd == 0){
				r = sw + t;
			}
			else{
				r = sw - t;
				if(r < 0)	r = 0;
			}
		}
	}
	return(r);
}

/////////////////////////////////////////////////////////////////////
//	������		// #0002
int StopWatch::Status()
{
	if(s_time == 0)	return	0;	// �v����~�� 
	else			return	1;
}




#ifdef TimmerCount_USE		// #0001

/////////////////////////////////////////////////////////////////////
//	��ϰ���ď����ݒ�
static int	CountCompare(const void *e1,const void *e2)
{

	
	long	a,b;
	a = *(const long *)e1;
	b = *(const long *)e2;
	a = a - b;
	if(a < 0)		a = -1;
	else if(a > 0)	a = 1;
	return	a;
}
#define	CYCMAX	48	//	24*2
void StopWatch::TimmerInit(int M)
{
	StopWatch	SW;
	if(M == FALSE){
		if(CycleLoopCount	> 0)	return;
	}
	
	static long	i,j,max,time,timew;
	static int	k;
	long	Time[CYCMAX+1];
	long	Count[CYCMAX+1];
	long	CountBuff[CYCMAX];
	timew=0;
	max = 0x7fffffff;
	SW.Reset();	  
	SW.Start();	  
	for(i=0;i<CYCMAX+1;i++){
		for(j=0;j<max;j++){
	 		time = SW.Read();
			if(time > timew){
				timew = time;
				Time[i] = time;
				Count[i] = j;
				break;
			}
		}
	}
	for(i=0;i<(CYCMAX/2);i++){
		CountBuff[i] = Count[i*2+1] + Count[i*2+2];
	}
	qsort(CountBuff,(CYCMAX/2),sizeof(long),CountCompare);
	CycleTime 		= Time[2] - Time[0];
	CycleLoopCount 	= CountBuff[(CYCMAX/4)-1];
	LoopTime 		= (double)CycleTime / CycleLoopCount;


/*
	CStdioFile	File;
	if(File.Open("swatch.txt",
			CFile::typeText		| 
			CFile::modeWrite	|
			CFile::modeCreate 	)){
		CString	Str;

		for(i=0;i<49;i++){
			if(i == 0){
				Str.Format("(%2d) Time=%4ld	Count=%ld\n",
					i,Time[i],Count[i]);
			}
 			else if(i & 0x01){
				Str.Format("(%2d) Time=%4ld(%4ld)	Count=%ld	%ld\n",
					i,Time[i],Time[i]-Time[i-1],
					Count[i],Count[i]+Count[i+1]);
			}
			else{
				Str.Format("(%2d) Time=%4ld(%4ld)	Count=%ld\n",
					i,Time[i],Time[i]-Time[i-1],
					Count[i]);
			}
			File.WriteString(LPCTSTR(Str)); 
		}
		for(i=0;i<24;i++){
			Str.Format("(%2d) Count=%ld\n",
					i,CountBuff[i]);
			File.WriteString(LPCTSTR(Str)); 
		}
		Str.Format("CycleTime=%ld\n",CycleTime);
		File.WriteString(LPCTSTR(Str)); 
		Str.Format("CycleLoopCount=%ld\n",CycleLoopCount);
		File.WriteString(LPCTSTR(Str)); 
		Str.Format("LoopTime=%lf\n",LoopTime);
		File.WriteString(LPCTSTR(Str)); 

	}
 */
 }
/////////////////////////////////////////////////////////////////////
//	��ϰ����
void StopWatch::TimmerCount(long T)
{
	static long	N0,N1,N2,N02,T02;
	StopWatch	SW;
	N1 = (T / CycleTime) - 1;
	if(N1 < 0) 	N1 = 0;
	T02 = T - (CycleTime * N1);
	N02 = (long)(T02 / LoopTime);
		// ��ϰٰ��0 ��ϰ����orN02 �܂�ٰ��
	static long	i,j,time,timew;
	static int	k;
	timew=0;
	SW.Reset();	  
	SW.Start();	  
	for(i=0;i<N02;i++){
 		time = SW.Read();
		if(time > timew){
			break;
		}
	}
	N0 = i;
	N2 = N02 - N0;
	if(N2 < 0)	N2 = 0;
	else if(N2 > CycleLoopCount){
		N2 = N2 - CycleLoopCount;
		N1 = N1 + 1;
	}
		// ��ϰٰ��1 
	timew = time;
	for(i=0;N1 > 0;){
 		time = SW.Read();
		if(time > timew){
			timew = time;
			i++;
			if(i > 1){
				i = 0;
				N1 --;
			}
		}
	}
		// ��ϰٰ��2 ��ϰ���ތ�
	for(i=0;i<N2;i++){
 		time = SW.Read();
		if(time > timew){
		}
	}
}
#endif
/*---------------------------------------------------------------------
	Cognex MVS-8200 ���� �N���X���C�u����
	
	Vison Processor �u�[�g�v���O����
	
								1999 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------
 #0000 99/06/-- ����
  --------------------------------------------------------------------*/
//#include <ch_cog/rpc.h>
//#include <ch_cvl/vp8200.h>
#include <ch_cvl/vp8504.h>

#include <ch_cvl/constrea.h>
#include <ch_cvl/except.h>
#include <string>

void CreateVPObject();
void DeleteVPObject();

void cfRemoteAcqFifoHandler(void *);
extern c_UInt8 linkForce_userfunc_cpp;
c_UInt8 linkForce[] = { linkForce_userfunc_cpp
                      };
int cfSampleMain(int argc, char *argv[])
{  
  // We are both an RPC client (VP needs host file I/O) and an RPC
  // server (the various user-defined functions).
  ccThreadID acqThread = cfCreateThread(cfRemoteAcqFifoHandler, 0);
  ccRPC::init(ccHost::gOnly());

  CreateVPObject();

  /* We want to enter an efficient sleep state.
   *    for (;;) ;
   * actually eats up a measurable amount of processor time.
   * Do a bogus wait on a thread that will never terminate instead.
   */
  cfWaitForThreadTermination(acqThread);
  DeleteVPObject();

  return 0; // happy compiler
}


extern "C" int cfMain(int argc, char* argv[]);

int cfMain(int argc, char* argv[])
{
  // Wrapper for sample functions so that Cognex specific exceptions
  // are caught and a message is printed.
  try {
    cfSampleMain(argc, argv);
//    cogOut << "Sample code complete " << cmStd endl;
  }
  catch (ccException& exc) {
    cogOut << exc.message() << cmStd endl;
  }
  return 0;
}

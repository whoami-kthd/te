// DlgSG300.cpp : �C���v�������e�[�V���� �t�@�C��
//
// #KS20130510-01 [���P]S5F2���s�v�ȃA���[���Ή�
#include <mcc.h>
#include "stdafx.h"
#include "fcb.h"
#include "DlgSG300.h"
// #KS20130417-01 [�ǉ�]GEM�Q�|�[�g��
//#include	<io.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CString TRStateMsg[] = {
	"StateOutOfService",
	"StateTransferBlocked",
	"StateReadyToLoad",
	"StateReadyToUnload",
};

/////////////////////////////////////////////////////////////////////////////
// DlgSG300 �_�C�A���O


DlgSG300::DlgSG300(CWnd* pParent /*=NULL*/)
	: CDialog(DlgSG300::IDD, pParent)
// #KS20130417-01 [�ǉ�]GEM�Q�|�[�g��
//	,ID(0)
//	,pSecsTDS(NULL)
// #KS20130510-01 [���P]S5F2���s�v�ȃA���[���Ή�
	,AlarmMsgName("_GS05F01S")
{
	//{{AFX_DATA_INIT(DlgSG300)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_DATA_INIT

	this->pEvFinInfoComState		= NULL;
	this->pEvFailInfoComState		= NULL;

	this->pEvPPRecipeSendReq		= NULL;

	this->pEvPPSelectReq			= NULL;
	this->pEvPPStartReq_B			= NULL;
	this->pEvPPStartReq_T			= NULL;
	this->pEvTopWaferUnloadReq		= NULL;
	this->pEvBottomWaferUnloadReq	= NULL;
	this->pEvStopWaitingSecsT	= &this->EvStopWaitingDummy;	// ���Ƀ_�~�[�����Ă����B
	this->pEvStopWaitingSecsB	= &this->EvStopWaitingDummy;	// ���Ƀ_�~�[�����Ă����B
	this->EvStopWaitingDummy.ResetEvent();
	//
	this->pEvFinInfoBottomCarrierIdRead		= NULL;
	this->pEvFailInfoBottomCarrierIdRead	= NULL;
	this->pEvFinInfoTopCarrierIdNotified	= NULL;
	this->pEvFailInfoTopCarrierIdNotified	= NULL;
	this->pEvFinInfoBottomSlotMap			= NULL;
	this->pEvFailInfoBottomSlotMap			= NULL;
	this->pEvFinInfoTopSlotMap				= NULL;
	this->pEvFailInfoTopSlotMap				= NULL;
	count_S1F13 = 0;
	this->goRemote	= false;
	this->goLocal	= false;
	this->goOffline	= false;
//	this->goOnlineRemote_flg = FALSE;
	this->initCarrierObj_flg = FALSE;

	this->ppID = "";
	this->fileNameCount		= 0;
	this->comState			= 0;
	this->HostCommandStatus	= eNotReceived;
//	this->carrierIsCreated	= false;
//	this->carrierIsPlaced	= false;
	//
	this->CntD.PickCountG			= 0;
	this->CntD.PickCountB			= 0;
	this->CntD.PlaceCountG			= 0;
	this->CntD.PlaceCountB			= 0;
	this->CntD.UnBondCountG			= 0;
	this->CntD.UnBondCountB			= 0;
	this->CntD.PickRemainCountG		= 0;
	this->CntD.PickRemainCountB		= 0;
	this->CntD.PlaceRemainCountG	= 0;
	this->CntD.PlaceRemainCountB	= 0;
	this->SetCWnd(this);
	for(int i=0; i<2000; i++){
		this->almIsAlreadySend[i] = false;
	}
	for(i=0;i<ePortNoMax;i++){
		this->loadedByHost[i]			= false;
		this->carrierId[i]				= "";
	}
// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O
	this->MapCtrl.bReqMap = false;
	this->MapCtrl.pMapData = NULL;
// #KS20130415-01(E)	
}

DlgSG300::~DlgSG300(){
	m_hXComSecs.CloseProject();
	this->comState = 0;
}

void DlgSG300::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgSG300)
	DDX_Control(pDX, IDC_XCOMSECSCTRL1, m_hXComSecs);
	DDX_Control(pDX, IDC_SG300CMSCTRL1, m_hCsg300cms);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgSG300, CDialog)
	//{{AFX_MSG_MAP(DlgSG300)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgSG300 ���b�Z�[�W �n���h��

BEGIN_EVENTSINK_MAP(DlgSG300, CDialog)
    //{{AFX_EVENTSINK_MAP(DlgSG300)
	ON_EVENT(DlgSG300, IDC_XCOMSECSCTRL1, 14 /* InfoComState */, OnInfoComStateXcomsecsctrl1, VTS_I2 VTS_I2 VTS_I2)
	ON_EVENT(DlgSG300, IDC_XCOMSECSCTRL1, 15 /* InfoControlStateEvent */, OnInfoControlStateEventXcomsecsctrl1, VTS_I2)
	ON_EVENT(DlgSG300, IDC_XCOMSECSCTRL1, 2 /* GetSecsEvent */, OnGetSecsEventXcomsecsctrl1, VTS_BSTR)
	ON_EVENT(DlgSG300, IDC_SG300CMSCTRL1, 9 /* InfoCarrierIdStateEvent */, OnInfoCarrierIdStateEventSg300cmsctrl1, VTS_I2 VTS_VARIANT VTS_I2)
	ON_EVENT(DlgSG300, IDC_SG300CMSCTRL1, 10 /* InfoSlotMapStateEvent */, OnInfoSlotMapStateEventSg300cmsctrl1, VTS_I2 VTS_VARIANT VTS_VARIANT VTS_I2 VTS_I2)
	ON_EVENT(DlgSG300, IDC_SG300CMSCTRL1, 2 /* GetServiceEvent */, OnGetServiceEventSg300cmsctrl1, VTS_BSTR)
	ON_EVENT(DlgSG300, IDC_XCOMSECSCTRL1, 18 /* LinkXComChanged */, OnLinkXComChangedXcomsecsctrl1, VTS_I2 VTS_I2)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()


///////////////////////////////////////////////////
//
//
//
//
//	�� �� �� / O p e n P r o j ec t �֌W
//
//
//
BOOL DlgSG300::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	SystemParametersInfo( SPI_GETWORKAREA, 0, &m_WorkRect, sizeof(m_WorkRect) );
	this->DlgStatus.Create( IDD_STATUS, this );
	SetTimer( 1, 1000, NULL );
	
	return TRUE;  // �R���g���[���Ƀt�H�[�J�X��ݒ肵�Ȃ��Ƃ��A�߂�l�� TRUE �ƂȂ�܂�
	              // ��O: OCX �v���p�e�B �y�[�W�̖߂�l�� FALSE �ƂȂ�܂�
}

void DlgSG300::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID && pSecsTDS) {
//		int sts = pSecsTDS->GetStatus();
//		sts = (2 == sts) ? 4 : 0;
//		if (this->DlgStatus.nowCtrlState != sts) {
//			this->DlgStatus.nowCtrlState = sts;
//			this->DlgStatus.CheckTheCtrlState();
//		}
//	}
// #KS20130417-01(E)
}

int	DlgSG300::SetSecsSystemItem(CString item_name, long item_data)
{
	int		isErr;
	VARIANT	vtData;
	VariantInit( &vtData );
	vtData.vt	= VT_I4;				// LONG�^
	vtData.lVal	= item_data;			// 
	isErr = m_hXComSecs.PutSecsItem(item_name, vtData, 0, 0, 0, 0);		// ���[�U�ϐ��ɑ��M������e���Z�b�g
	VariantClear( &vtData );
	return isErr;
}
void DlgSG300::Init(int class_id, int myErrorStart){
	// �G���[�̏�����
	this->err.Initinstance(class_id, myErrorStart);
	CString waferId;
	for(int i=0;i<eWaferNumberMax;i++){
		waferId.Format("BottomWafer%02d",i+1);
		waferIdOfContentMap[i]	= waferId;
		waferIdOfManual[i]		= waferId;
	}
}
void DlgSG300::ErrorLogOut(int line,int Error){
	CString buf;
	buf.Format("SoftComGem300 Error(%d) 0x%08X", line, Error);
	// �G���[�̏�����
	this->err.LogSaveNFL(buf);
}


// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//BOOL DlgSG300::OpenProject(){
BOOL DlgSG300::OpenProject(int iMode){
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (!pSecsTDS) {
//			pSecsTDS = new SecsTDS;
//		}
//		if (pSecsTDS) {
//			if (0 == pSecsTDS->Initialize()) {
//				r = TRUE;
//			}
//		}
//		if (r) {
//			this->DlgStatus.ShowWindow( SW_SHOWNA );
//			this->DlgStatus.SetWindowPos( &wndTopMost, m_WorkRect.left+m_WorkRect.right-ST_W * ID, m_WorkRect.top+m_WorkRect.bottom-ST_H, ST_W, ST_H, 0 );
//			this->DlgStatus.ShowWindow( SW_SHOWNOACTIVATE );
//			SetTimer(1, 1000, NULL);
//		}
//		return(r);
//	}
// #KS20130417-01(E)
// #KS20130510-01 [���P]S5F2���s�v�ȃA���[���Ή�
	GWPPfileData(SECS_INIT_FILE_PATH, "OPTION", "AlarmMsgName", TRUE, AlarmMsgName, AlarmMsgName);
	BOOL r = TRUE;
	long lRet;
	// ���O�ɃG�O�[���E���B
	this->KillTheExeFiles();
	m_hXComSecs.SetOpenMode(1);
	if((lRet = m_hXComSecs.OpenProject(this->pathName,this->projectName)) != 0){
		r = FALSE;
		this->err.PutError(Err_ProjectNotOpened1);
		this->ErrorLogOut(__LINE__,lRet);
		return r;
	}
	m_hXComSecs.SetOpenMode(2);
	if((lRet = m_hXComSecs.OpenProject(this->pathName,this->projectName)) != 0){
		m_hXComSecs.CloseProject();	//���s������v���W�F�N�g���N���[�Y
		r = FALSE;
		this->err.PutError(Err_ProjectNotOpened2);
		this->ErrorLogOut(__LINE__,lRet);
		return r;
	}
// #MO20131101 [�ǉ�] SoftComGem300�@�\���g�p���Ă��邩�Z�b�g
	if(this->useSoftComGem300){
		this->initCarrierObj_flg = TRUE;	//�c���Ă���S�L�����A�̏�����(�r�o)
		m_hCsg300cms.SetOpenMode(0);
		if((lRet = m_hCsg300cms.OpenProject(this->pathName,this->projectName)) != 0){
			m_hXComSecs.CloseProject();	//���s������v���W�F�N�g���N���[�Y
			r = FALSE;
			//#MO20131105[�ǉ�]Gem300NG�p�̃G���[�쐬�E�\��
			this->err.PutError(Err_Gem300ProjectNotOpened);
			this->ErrorLogOut(__LINE__,lRet);
			return r;
		}
	}
	BOOL r2 = TRUE;
	// �ʐM�m����Ԃ̐ݒ�B
// #KS20130511-01 [�s�]OFFLINE�ɂȂ�Ȃ�
	this->DlgStatus.nowCtrlState = 0;
	this->DlgStatus.ShowWindow( SW_SHOWNA );
// #KS20130417-01 [�ǉ�]GEM�Q�|�[�g��
	if(false){
//		this->DlgStatus.SetWindowPos( &wndTopMost, m_WorkRect.left+m_WorkRect.right-ST_W * (ID + 1), m_WorkRect.top+m_WorkRect.bottom-ST_H, ST_W, ST_H, 0 );
	}else{
		this->DlgStatus.SetWindowPos( &wndTopMost, m_WorkRect.left+m_WorkRect.right-ST_W, m_WorkRect.top+m_WorkRect.bottom-ST_H, ST_W, ST_H, 0 );
	}
	this->DlgStatus.ShowWindow( SW_SHOWNOACTIVATE );
	// S1F13�p�̐ݒ�B
	this->PutSecsVidSingleASCII("_MDLN"		, "FC6000");
	this->PutSecsVidSingleASCII("_SOFTREV"	, this->softRevision);
	if(r2 != 0){
	}
	this->goRemote = false;
	for(int i=0;i<ePortNoMax;i++){
		this->loadedByHost[i]			= false;
	}
	return r;
}

void DlgSG300::KillTheExeFiles()
{
	CString comLogExe = "COMLOG  [" + this->projectName + "]";
	this->KillTheExe(comLogExe);								// ComLog.exe	�I��
	this->KillTheExe(this->pathName + "\\Hsms.exe");			// Hsms.exe		�I��
	this->KillTheExe(this->pathName + "\\Spool.exe");			// Spool.exe	�I��
}
void DlgSG300::KillTheExe(CString fileName)
{
	CString strWndName;
	CWnd	*cwnd;
	strWndName.Format(fileName);
	cwnd = pCwnd->FindWindow(NULL, strWndName);
	if(cwnd != NULL){
		cwnd->PostMessage(WM_CLOSE);
	}
}
BOOL DlgSG300::CloseProject(){
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (pSecsTDS) {
//			if (0 == pSecsTDS->Terminate()) {
//				r = TRUE;
//			}
//		}
//		this->DlgStatus.CloseTheDialog();
//		KillTimer(1);
//		return(r);
//	}
// #KS20130417-01(E)
	BOOL r = TRUE;
	// Unload�͒ʏ�̕��@�Ɏ~�߂�
//	int r2 = this->UnloadALLCarrierObj();
	this->CarrierForceTakeOut(eBottomPortNo,	this->carrierId[eBottomPortNo]);
	this->CarrierForceTakeOut(eTopPortNo,		this->carrierId[eTopPortNo]);
	if(this->useSoftComGem300){
		this->m_hCsg300cms.SetCloseMode(0);
		this->m_hCsg300cms.CloseProject();
	}
	this->m_hXComSecs.SetCloseMode(0);
	this->m_hXComSecs.CloseProject();
	this->comState = 0;
	this->DlgStatus.CloseTheDialog();
	return r;
}
///////////////////////////////////////////////////
//
//
//
//
//	O n l i n e  / O f f l i n e �֌W
//
//
//

BOOL DlgSG300::ChangeCR(){

	CString	sStr;
	BOOL r = TRUE;
	//
	this->pEvFinInfoSeleStat	= &EvFinSeleStat;
	this->pEvFailInfoSeleStat	= &EvFailSeleStat;
	//
	m_hXComSecs.ChangeCR();
	return r;
}

BOOL DlgSG300::ChangeOffLine(){
	BOOL r = TRUE;
	long lRet;
	if(getCtrlState() > eHostOffline){	//�X�e�[�^�X��OnLine��������
//		this->goOffline	= true;
		this->goLocal	= false;
		this->goRemote	= false;
		if((lRet = m_hXComSecs.ChangeOnline(0)) != 0){
			r = FALSE;
		}
	}
	return r;
}


BOOL DlgSG300::ChangeOnLineLocal(){

	BOOL r = TRUE;
	long lRet;

//	this->goLocal	= true;
//	this->goRemote	= false;
	if(getCtrlState() <= eHostOffline){	//OffLine��������
		if((lRet = m_hXComSecs.ChangeOnline(1)) != 0){
			r = FALSE;
		}
	}else if(getCtrlState() == eOnlineRemote){	//OnLineRemote��������
		if((lRet = m_hXComSecs.ChangeOnlineSubState(0)) != 0){
			r = FALSE;
		}
	}
	return r;
}


BOOL DlgSG300::ChangeOnLineRemote(){
	BOOL r = TRUE;
	long lRet;
	// 
	if(getCtrlState() == eOnlineLocal){	//OnLineLocal��������
		if((lRet = m_hXComSecs.ChangeOnlineSubState(1)) != 0){
			r = FALSE;
			return r;
		}
	}else if(getCtrlState() <= eHostOffline){	//OffLine��������
		if((lRet = m_hXComSecs.ChangeOnline(1)) != 0){
			r = FALSE;
			return r;
		}
		this->goRemote = true;
	}

	return r;
}


/////////////////////////////////////////////////////////
//
//
//
//	I t e m  and  V I D �֌W
//
//
//
//

short DlgSG300::getVIDValSingleUNIT1(LPCSTR vid_name)
{
	//�v�f��1 UNIT1 ��VID�̒l���擾����(��ɃX�e�[�^�X���)
	short status, i_type;
	long elm;
	VARIANT	v;
	VariantInit(&v);
	m_hXComSecs.GetVIDVal(vid_name, &v, &i_type, &elm, 0,0,0,0);
	status = v.bVal;
	VariantClear(&v);
	return status;
}


BOOL DlgSG300::setAttDataSingleUINT1(CString ObjType, CString ObjId, LPCSTR attr_name, unsigned char data_v){

	BOOL r = TRUE;
	long	ret;
	VARIANT	vObjType, vObjId, v;
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&v);
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = ObjType.AllocSysString();
	vObjId.vt = VT_BSTR;
	vObjId.bstrVal = ObjId.AllocSysString();
	v.vt = VT_UI1;
	v.bVal = data_v;
	if((ret = m_hXComSecs.PutAttrData(vObjType, vObjId, attr_name, v, 0x00A4, 1, 0, 0, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&vObjType);
	VariantClear(&vObjId);
	VariantClear(&v);
	return r;
}

short DlgSG300::getAttDataSingleUINT1(CString ObjType, CString ObjId, LPCSTR attr_name){
	VARIANT	vObjType, vObjId, v;
	short val, item_type;
	long	element;
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&v);
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = ObjType.AllocSysString();
	vObjId.vt = VT_BSTR;
	vObjId.bstrVal = ObjId.AllocSysString();
	item_type = 0x00A4;
	element = 1;
	m_hXComSecs.GetAttrData(vObjType, vObjId, attr_name, &v, &item_type, &element, 0, 0, 0, 0);
	val = v.bVal;
	VariantClear(&vObjType);
	VariantClear(&vObjId);
	VariantClear(&v);
	return val;
}

CString DlgSG300::getCarrierID(){
	CString sCarrierID;
	short i_type;
	long elm;
	VARIANT	v;
	VariantInit(&v);
	m_hXComSecs.GetVIDVal("_CARRIERID", &v, &i_type, &elm, 0,0,0,0);
	sCarrierID = v.bstrVal;
	VariantClear(&v);
	return sCarrierID;
}

// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O

BOOL DlgSG300::PutSecsItemSingleUnsignInt(CString item_name, unsigned int data_ui, CString data_format)
{
	//data_format : "U1"or"U2"or"U4"
	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;

	VariantInit(&v_data);

	if(data_format == "U1"){
		v_data.vt = VT_UI1;
		v_data.bVal = data_ui;
	}else if(data_format =="U2"){
		v_data.vt = VT_I4;
		v_data.lVal = data_ui;
	}else if(data_format == "U4"){
		v_data.vt = VT_R8;
		v_data.dblVal = data_ui;
	}else{
		r = FALSE;
		VariantClear(&v_data);
		return r;
	}

	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, 0, 0, 0, 0)) != 0){
		r = FALSE;
///		WriteLog( ERRMSGID7, "PutSecsItemSingleUnsignInt() Error: 0x%08X,  ItemName=%s", ret, item_name, data_format);
	}

	VariantClear(&v_data);
	return r;
}

// #KS20130415-01(E)

BOOL DlgSG300::PutSecsItemSingleASCII(CString item_name, CString item_data){
	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_BSTR;
	v_data.bstrVal = item_data.AllocSysString();
	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, 0, 0, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}

BOOL DlgSG300::PutSecsVidSingleASCII(CString item_name, CString item_data)
{
	BOOL isErr = FALSE;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_BSTR;
	v_data.bstrVal = item_data.AllocSysString();
	isErr = m_hXComSecs.PutSecsItem(item_name, v_data, item_data.GetLength(), 0, 0, 0);
	VariantClear(&v_data);
	return isErr;
}


BOOL DlgSG300::PutSecsItemSingleBIN(CString item_name, unsigned char item_data){

	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_UI1;
	v_data.bVal = item_data;
	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, 0, 0, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}
BOOL DlgSG300::PutExtendItemSingleASCII(CString item_name, CString item_data, int element1, int element2)
{
	BOOL r = TRUE;
	long isErr	= FALSE;
	VARIANT v_data;
	VariantInit( &v_data );
	v_data.vt = VT_BSTR;
	v_data.bstrVal	= item_data.AllocSysString();
	if((isErr = m_hXComSecs.PutExtendItem(item_name, v_data, 0x0040, item_data.GetLength(), element1, element2, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}


BOOL DlgSG300::PutExtendItem4ByteInteger(CString item_name, int item_data, int element1, int element2)
{
	BOOL r = TRUE;
	long isErr	= FALSE;
	VARIANT v_data;
	VariantInit( &v_data );
	v_data.vt	= VT_I4;										// LONG�^
	v_data.lVal = item_data;
	if((isErr = m_hXComSecs.PutExtendItem(item_name, v_data, 0x0070, 1, element1, element2, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}

BOOL DlgSG300::PutSecsItem4ByteInteger(CString item_name, int item_data, int element1, int element2)
{
	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_I4;
	v_data.lVal = item_data;
//	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, 0, 0, 0, 0)) != 0){
	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, element1, element2, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}
// #MO20131129 [�ǉ�]SECS�E�F�n�}�b�s���O
BOOL DlgSG300::PutSecsItem8ByteFloating(CString item_name, int item_data, int element1, int element2)
{
	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_R8;
	v_data.lVal = item_data;
	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, element1, element2, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}

// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O
unsigned int DlgSG300::GetItemDataSingleUnsignInt(CString item_name, CString data_format)
{
	//data_format : "U1"or"U2"or"U4"
	BOOL r = TRUE;
	VARIANT v_data;
	SHORT	i_type;
	LONG	i_elm;
	unsigned int val;

	VariantInit(&v_data);
	m_hXComSecs.GetItemData(item_name, &v_data, &i_type, &i_elm, 0, 0, 0, 0);

	if(data_format == "U1"){
		val = v_data.bVal;
	}else if(data_format == "U2"){
		val = v_data.lVal;
	}else if(data_format == "U4"){
		val = v_data.ulVal;
	}else if(data_format == "I2"){
		val = v_data.iVal;
	}

	VariantClear(&v_data);
	return val;
}
// #KS20130415-01(E)

CString DlgSG300::GetItemDataSingleASCII(CString item_name){
	VARIANT v_data;
	short i_type;
	long elm;
	CString item_data;
	VariantInit(&v_data);
	m_hXComSecs.GetItemData(item_name, &v_data, &i_type, &elm, 0, 0, 0, 0);
	item_data = v_data.bstrVal;
	VariantClear(&v_data);
	return item_data;
}

// #MO20131130 [�ǉ�]SECSϯ��ݸ�
int DlgSG300::GetItemDataSingleInt(CString item_name)
{
	VARIANT v_data;
	SHORT	i_type;
	LONG	i_elm;
	int		val;
	VariantInit(&v_data);
	m_hXComSecs.GetItemData(item_name, &v_data, &i_type, &i_elm, 0, 0, 0, 0);
    val = v_data.iVal;
	VariantClear(&v_data);
	return val;
}

///////////////////////////////////////////////////
//
//
//
//
//	��@�M�@E�@v�@e�@n�@t�@�ց@�W
//
//
//
//
BOOL DlgSG300::WaitingMessageCancel(){
	//HOST�񓚑҂���Ԃ���̊J��

	BOOL r = TRUE;
	CString sCarrierId;
	sCarrierId = this->getCarrierID();
	//  _CARRIERIDSTATUS:1  ID Read  (HOST�񓚑҂�) 
	if(getAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS") == 1){
		if(this->pEvFinInfoBottomCarrierIdRead){	//�҂���ԊJ��
			this->pEvFinInfoBottomCarrierIdRead->SetEvent();
		}
		//����_CARRIERIDSTATUS:2   ID Verification OK 
		this->setAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS", 2);
	//  _SLOTMAPSTATUS:1  SLOTMAP Read  (HOST�񓚑҂�) 
	}else if(getAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS") == 1){
		if(this->pEvFinInfoBottomSlotMap){	//�҂���ԊJ��
			this->pEvFinInfoBottomSlotMap->SetEvent();
		}
		if(this->pEvFinInfoTopSlotMap){	//�҂���ԊJ��
			this->pEvFinInfoTopSlotMap->SetEvent();
		}
		//����_SLOTMAPSTATUS:2   Slotmap Verification OK 
		this->setAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS", 2);
	}
	return r;
}

void DlgSG300::OnInfoComStateXcomsecsctrl1(short com_state, short hst_sts, short eq_sts) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������

	CString	sStr;
	this->comState = com_state;
	switch(com_state){
		case 0:		//�ʐM����
			if(this->pEvFailInfoComState){
				this->pEvFailInfoComState->SetEvent();
			}
#if !Release
				TRACE("comstatus = 0 �ʐM�L�� �ʐM���s\n");
#endif
			break;
		case 1:		//�ʐM�L���@�ʐM���f
			if(eq_sts!= 0){	//wait��Ԃ̂Ƃ�0 ����ȊO�̂Ƃ�0�ȊO(���M)
				this->count_S1F13 ++;
//				sStr.Format("%s%x%s%d", "COM_STATAS:", com_state, " ��:", this->count_S1F13);
//				sStr.Format("%s%x%s%x%s%x", "COM_STATAS:", com_state, " hst_sts:", hst_sts, " eq_sts:", eq_sts);
//				AfxMessageBox(sStr, MB_OK, 0);
			}
#if !Release
				TRACE("comstatus = 1 �ʐM�L�� �ʐM���f\n");
#endif
			if(this->count_S1F13 > 10){
				if(this->pEvFailInfoComState){
					this->pEvFailInfoComState->SetEvent();
				}
			}

			break;
		case 2:		//�ʐM�L��	�ʐM���s
			if(this->pEvFinInfoComState){
				this->pEvFinInfoComState->SetEvent();
			}
#if !Release
				TRACE("comstatus = 2 �ʐM�L�� �ʐM���s\n");
#endif
			break;
	}
}

void DlgSG300::OnInfoControlStateEventXcomsecsctrl1(short state) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������

	switch(state)
	{
		case 0: //Equip OFFLINE
#if !Release
	TRACE("OnInfoControlState = 0(Equip OFFLINE)\n");
#endif
			if(this->goRemote || this->goLocal){
				this->goLocal = false;
				m_hXComSecs.ChangeOnline(1);
#if !Release
	TRACE("m_hXComSecs.ChangeOnline(1)\n");
#endif
			}else if(getVIDValSingleUNIT1("_PRECTRLSTATE") == 5){	//�O��Ԃ��R���g���[�������[�g��������
				this->WaitingMessageCancel();	//HOST�҂���Ԃ���̊J��
			}
			break;
		case 1:	//Host OFFLINE
#if !Release
	TRACE("OnInfoControlState = 1(Host OFFLINE)\n");
#endif
			if(getVIDValSingleUNIT1("_PRECTRLSTATE") == 5){	//�O��Ԃ��R���g���[�������[�g��������
				this->WaitingMessageCancel();	//HOST�҂���Ԃ���̊J��
			}
			break;

		case 2: //Attempt ONLINE
#if !Release
	TRACE("OnInfoControlState = 2(Attempt OFFLINE)\n");
#endif
			if(getVIDValSingleUNIT1("_PRECTRLSTATE") == 5){	//�O��Ԃ��R���g���[�������[�g��������
				this->WaitingMessageCancel();	//HOST�҂���Ԃ���̊J��
			}
			break;

		case 3: //CONTROL_STAT_ONLINE_LOCAL:
#if !Release
	TRACE("OnInfoControlState = 3(ONLINE LOCAL)\n");
#endif
			if(this->goRemote){
				m_hXComSecs.ChangeOnlineSubState(1);	//REQ_ONLINE_SUBSTATE_REMOTE
				this->goRemote = false;
			}else if(getVIDValSingleUNIT1("_PRECTRLSTATE") == 5){	//�O��Ԃ��R���g���[�������[�g��������
				this->WaitingMessageCancel();	//HOST�҂���Ԃ���̊J��
			}
			break;

		case 4: //CONTROL_STAT_ONLINE_REMOTE:
#if !Release
	TRACE("OnInfoControlState = 4(ONLINE REMOTE)\n");
#endif
			break;
	}
	// �ʐM�m����Ԃ̕\���ύX
	this->DlgStatus.nowCtrlState = this->getCtrlState();	// ���ʃN���X�փZ�b�g
	this->DlgStatus.CheckTheCtrlState();
}

void DlgSG300::OnGetSecsEventXcomsecsctrl1(LPCTSTR event_name) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	if(strcmp(event_name, "_GS02F41R") == 0){
		this->RecvS02F41();
	}
	else if(strcmp(event_name, "_GS03F17R") == 0){
		// ContentMap�̎擾�͂����ł͂��Ȃ�(���ۂɗ~�������O�ɍs��)
	}
	else if(strcmp(event_name, "_GS07F19R") == 0){
		this->RecvS07F19();
	}
	else if(strcmp(event_name, "_GS07F25R") == 0){
		this->RecvS07F25();
	}
// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O	
	else if(strcmp(event_name, "_GS12F02R") == 0){
		if (this->RecvS12F2()) {
			SendS12F5();
		}
	}
	else if(strcmp(event_name, "_GS12F04R") == 0){
		if (this->RecvS12F4()) {
			this->SendS12F15();
		}
	}
	else if(strcmp(event_name, "_GS12F16R") == 0){											//130206_Misato
		this->RecvS12F16();
	}
	else if(strcmp(event_name, "_GS12F06R") == 0){											//13020_Misato
		if (this->RecvS12F6()) {
			SendS12F9();
		}
	}
	else if(strcmp(event_name, "_GS12F10R") == 0){											//13020_Misato
		this->RecvS12F10();
	}
// #KS20130415-01(E)
	else if(strcmp(event_name, "_GS12F74R") == 0){
		if(this->pEvFinInfoFileMapName)	//�҂���ԊJ��
			this->pEvFinInfoFileMapName->SetEvent();
	}
//#Ducmv 20150821 SECS (S)
	else if(strcmp(event_name, "_GS12F76R") == 0){
		if(this->pEvFinCSVFileName)	//�҂���ԊJ��
			this->pEvFinCSVFileName->SetEvent();
	}
//#Ducmv 20150821 SECS (E)
	else if(strcmp(event_name, "_InternalErr") == 0){
		long errcode = m_hXComSecs.GetErrorStatus();
		if(errcode == 0xC600B105 || errcode == 0xC600B205){
#if 0
			if(this->pEvFinInfoSeleStat){	//�҂���ԊJ��
				this->pEvFinInfoSeleStat->SetEvent();
			}
#else
	m_hXComSecs.ChangeCR();
#endif
		}
	}
// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O	
	else if (0 == strcmp(event_name, "_Illegal_SF")
		|| 0 == strcmp(event_name, "_TransactionTimeout")
		|| 0 == strcmp(event_name, "_AbortTransaction")) {
		VARIANT vtMHead;
		VariantInit(&vtMHead);
		vtMHead = m_hXComSecs.GetMhead();
		SAFEARRAY FAR *pArray = vtMHead.parray;
		char DispStr[80], DataStr[16];
		unsigned char cData;
		long i;
		int s, f;
		wsprintf((LPSTR) DispStr, "MHEAD = ");
		for(i = 0; i < 10; i++) {
			if (SafeArrayGetElement(pArray, (long FAR*)&i, &cData) != S_OK) {
				break;
			}
			if (2 == i) {
				s = cData;
			} else if (3 == i) {
				f = cData;
			}
			wsprintf((LPSTR)DataStr, "%02x ", cData);
			strcat(DispStr, DataStr);
		}
		if (10 == i) {
			if (12 == (~0x80 & s)) {	// ���s
				if (MapCtrl.bReqMap) {
					MapCtrl.bReqMap = FALSE;
					MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_FailRecv;
					MapCtrl.EvReqMapOK.SetEvent();
					MapCtrl.EvReqMapEnd.SetEvent();
				}
			}
		}
		if(i == 10) {
// #KS20130415-01 [�C���K�v]SECS�E�F�n�}�b�s���O	
// #KS20130510-01 [���P]S5F2���s�v�ȃA���[���Ή�
//			AfxMessageBox(DispStr, MB_OK | MB_ICONINFORMATION, 0);
		}
		VariantClear(&vtMHead);
	}
// #KS20130415-01(E)
	else if(strcmp(event_name, "__GS03F17R_CR") == 0){
		// �ʏ��S3F17�͂����ł͎󂯎��Ȃ����߁ACarrierRelease��p��__GS03F17R_CR���쐬����
		// �󂯎�邱�ƂƂ���B
		short	item_type;
		long	ret,element;
		VARIANT	vtData;
		short	port_no;
		VariantInit( &vtData );
		ret = m_hXComSecs.GetItemData("Itm_PORT_NO",&vtData, &item_type,&element,0,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
//			return;
		}
		port_no = vtData.bVal;
		this->RecvCarrierRelease(port_no);
	}
	else if(strcmp(event_name, "__GS03F17R_CN") == 0){		//�ǉ�120524
		// �ʏ��S3F17�͂����ł͎󂯎��Ȃ����߁ACarrierNotification��p��__GS03F17R_CN���쐬����
		// �󂯎�邱�ƂƂ���B
		short	item_type;
		long	ret,element;
		VARIANT	vtData;
		short	port_no;
		CString carrierId;
		VariantInit( &vtData );
		ret = m_hXComSecs.GetItemData("Itm_PORT_NO",&vtData, &item_type,&element,0,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
			return;
		}
		port_no = vtData.bVal;
		VariantInit( &vtData );
		ret = m_hXComSecs.GetItemData("Itm_CARRIERID",&vtData, &item_type,&element,0,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
			return;
		}
		carrierId = vtData.bstrVal;
		VariantClear(&vtData);
		this->RecvCarrierNotification(port_no, carrierId);
	}
	// TCP/IP�ؒf�ʒm
	else if(strcmp(event_name, "_Disconnect") == 0){
		// �v���W�F�N�g�t�@�C������U�ۑ�����
		this->m_hXComSecs.WriteCurrentData();
		// �v���W�F�N�g�̃N���[�Y
		this->m_hXComSecs.SetCloseMode(2);
		this->m_hXComSecs.CloseProject();
		// �f�B���C
		::Sleep(500);
		m_hXComSecs.SetOpenMode(2);
		m_hXComSecs.OpenProject(this->pathName,this->projectName);
	}
}
void DlgSG300::OnInfoCarrierIdStateEventSg300cmsctrl1(short ptn, const VARIANT FAR& carrierid, short state) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
#if !Release
	TRACE("OnInfoCarrierIdState = port(%d),Status(%d)\n", ptn, state);
#endif
	CString msg;
	switch(state)
	{
	case 0:	//Not Read
		break;
	case 1:	//Waitting For Host
		break;
	case 2: //VERIFICATION_OK
#if !Release
	TRACE("(Verification OK)\n");
#endif
		if((ptn == eBottomPortNo)&&(this->pEvFinInfoBottomCarrierIdRead)){
			this->pEvFinInfoBottomCarrierIdRead->SetEvent();
		}
		break;
	case 3: //VERIFICATION_NG
#if !Release
	TRACE("(Verification NG)\n");
#endif
		{
			CString msg;
			msg.Format("CancelCarrierIDRead None\n");
			if((ptn == eBottomPortNo)&&(this->pEvFailInfoBottomCarrierIdRead)){
				this->pEvFailInfoBottomCarrierIdRead->SetEvent();
				msg.Format("EvFailInfoBottomCarrierIdRead.SetEvent()\n");
			}
			if((ptn == eTopPortNo)&&(this->pEvFailInfoTopCarrierIdNotified)){
				this->pEvFailInfoTopCarrierIdNotified->SetEvent();
				msg.Format("pEvFailInfoTopCarrierIdNotified.SetEvent()\n");
			}
			this->err.LogSaveNFL(msg);
#if !Release
			TRACE(msg);
#endif
			if(this->getCtrlState() != eOnlineRemote){		//Online Remote�ȊO��NG�𖳎����Đ�ɐi�߂�悤�ɂ���
				this->setAttDataSingleUINT1("Carrier", this->getCarrierID(), "_CARRIERIDSTATUS", 2);
			}
		}
		break;
	}
}

void DlgSG300::OnInfoSlotMapStateEventSg300cmsctrl1(short ptn, const VARIANT FAR& carrierid, const VARIANT FAR& slotmap, short slotcount, short state) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
#if !Release
	TRACE("OnInfoSlotMapState = port(%d),Status(%d)\n", ptn, state);
#endif
	switch(state)
	{
	case 0:	//Not Read
		break;
	case 1:	//Waitting For Host
		break;
	case 2: //VERIFICATION OK
#if !Release
	TRACE("(Verification OK)\n");
#endif
		if((ptn == eBottomPortNo)&&(this->pEvFinInfoBottomSlotMap)){
			this->pEvFinInfoBottomSlotMap->SetEvent();
		}
		if((ptn == eTopPortNo) && (this->pEvFinInfoTopSlotMap)){
			this->pEvFinInfoTopSlotMap->SetEvent();
		}
		break;
	case 3: //VERIFICATION NG
#if !Release
	TRACE("(Verification NG)\n");
#endif
		{
			CString msg;
			msg.Format("CancelSlotMapRead None\n");
			if((ptn == eBottomPortNo)&&(this->pEvFailInfoBottomSlotMap)){
				this->pEvFailInfoBottomSlotMap->SetEvent();
				msg.Format("EvFailInfoBottomSlotMap.SetEvent()\n");
			}
			if((ptn == eTopPortNo)&&(this->pEvFailInfoTopSlotMap)){
				this->pEvFailInfoTopSlotMap->SetEvent();
				msg.Format("EvFailInfoTopSlotMap.SetEvent()\n");
			}
			this->err.LogSaveNFL(msg);
#if !Release
			TRACE(msg);
#endif
			if(this->getCtrlState() != eOnlineRemote){		//Online Remote�ȊO��NG�𖳎����Đ�ɐi�߂�悤�ɂ���
				this->setAttDataSingleUINT1("Carrier", this->getCarrierID(), "_SLOTMAPSTATUS", 2);
			}
		}
		break;
	}
}

void DlgSG300::OnGetServiceEventSg300cmsctrl1(LPCTSTR service_name) 
{
	//S3F17�̃��b�Z�[�W���e���擾����(CarrierAction)
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	short status	= 0;
	int	port_no		= 0;
	//
	if(strcmp(service_name, "CancelCarrier") == 0){
//		::Sleep(1500);
		// CancelCarrier�Ƃ����T�[�r�X�̓f�t�H���g�ő��݂���̂ŁA��������̗p����B
		status = getVIDValSingleUNIT1("_CARRIERACCESSSTATUS");
		port_no = getVIDValSingleUNIT1("_PORTID");
		{
			CString msg;
			msg.Format("%s(%d) CancelCarrierReceived status(%d), port_no(%d)\n",
											__FILE__, __LINE__,status,port_no);
			this->err.LogSaveNFL(msg);
#if !Release
			TRACE(msg);
#endif
		}
		if(status == 0){	//CARRIERACCESSSTATUS��not accessed�̂Ƃ��̂݉\����ȍ~�͋���
			CString msg;
			//�҂���ԉ���
			if((port_no==eBottomPortNo)&&(this->pEvFailInfoBottomCarrierIdRead)){
				this->pEvFailInfoBottomCarrierIdRead->SetEvent();
				msg.Format("EvFailInfoBottomCarrierIdRead.SetEvent()\n");
			}else if((port_no==eTopPortNo)&&(this->pEvFailInfoTopCarrierIdNotified)){
				this->pEvFailInfoTopCarrierIdNotified->SetEvent();
				msg.Format("EvFailInfoTopCarrierIdNotified.SetEvent()\n");
			}else if((port_no==eBottomPortNo)&&(this->pEvFailInfoBottomSlotMap)){
				this->pEvFailInfoBottomSlotMap->SetEvent();
				msg.Format("EvFailInfoBottomSlotMap.SetEvent()\n");
			}else if((port_no==eTopPortNo)&&(this->pEvFailInfoTopSlotMap)){
				this->pEvFailInfoTopSlotMap->SetEvent();
				msg.Format("EvFailInfoBottomSlotMap.SetEvent()\n");
			}else{
				msg.Format("EventNone\n");
			}
			this->err.LogSaveNFL(msg);
#if !Release
			TRACE(msg);
#endif
		}
	}else if(strcmp(service_name, "CarrierRelease") == 0){
		// CarrierRelease�Ƃ����T�[�r�X���f�t�H���g�ł͑��݂��Ȃ��̂ŁAOnGetSecsEventXcomsecsctrl1�Ŏ󂯎�邱�Ƃɂ���B
	}
}
void DlgSG300::OnLinkXComChangedXcomsecsctrl1(short ocx_type, short status) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	if(ocx_type == 4){	//1:SG300PJM  4:SG300CMS  5:SG300STS  6:SG300CJM
		if(status == 0){	//0:�����NOK�@1,2,3:�����N���s 10:�����N�����҂�
			if(this->initCarrierObj_flg == TRUE){
				::Sleep(1000);
				this->UnloadALLCarrierObj();
				this->DelALLCarrierObj();
				this->initCarrierObj_flg = FALSE;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////
//
//
//
//
//	C M S(C a r r i e r   M a n a g e m e n t)�֌W
//	Carrier Management�֌W
//
//
//
// �L�����A���u���ꂽ
BOOL DlgSG300::CarrierPlaced(short PortNo, bool placed, CString sCarrierId)
{
	BOOL r = TRUE;
	// 
//	this->carrierIsPlaced	= true;
	// �ʐM�m�����Ă���OnlineRemote�ł���΁A
	if((this->comState == eCommunicating)
		/*&&(this->getCtrlState() == eOnlineRemote)*/){
		if(placed){	// �u���ꂽ
			// ReadyToUnload �����s����B
			r = this->CarrierTakeIn(PortNo);
		}else{		// ��������ꂽ
			// ReadyToLoad �����s����B
			r = this->CarrierTakeOut(PortNo);
		}
	}
	return r;
}
//////////////////////////////////////////////
//
// CarrierLoad
//
BOOL DlgSG300::CarrierLoad(short port_no, CString sCarrierId)
{
	// �r����return�֎~
	// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("CarrierLoad(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	short transferState;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	// TransferState���擾����B
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
			// �擾�ł��Ȃ����OutOfService�ƌ��Ȃ��B
			transferState	= eStateOutOfService;
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	if(r){
		// Bottom Wafer �� ReadyToUnload��Ԃł���΁A��U�A�����[�h���Ă��炤
		if((port_no == eBottomPortNo)&&(transferState == /*3*/eStateReadyToUnload)){
			this->err.PutError(Err_CarrierIsNotUnload);
			r = FALSE;
		}
	}
	if(r){
		// ReadyToLoad�łȂ����ReadyToLoad�ɂ���(���̍ہA��xTransferBlocked���o�R����B
		if(transferState != /*2*/eStateReadyToLoad){
			// ��UTransferBlocked�ɂ������Ƃ�ReadyToLoad
			if(transferState != /*1*/eStateTransferBlocked){	//not transfer blocked
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*2*/eCmdTransferBlocked)) != 0){	//transfer blocked
					r = FALSE;
					this->err.PutError(Err_Dlg300_03);
					this->ErrorLogOut(__LINE__,ret);
				}
			}
			////////////////////
			//
			// ReadyToLoad�ɕύX
			//
			if(r){
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*3*/eCmdReadyToLoad)) != 0){	//
					r = FALSE;
					this->err.PutError(Err_Dlg300_04);
					this->ErrorLogOut(__LINE__,ret);
				}
			}
		}
	}
	if(r){
		VariantInit(&vCarrierId);
		vCarrierId.vt = VT_BSTR;
		vCarrierId.bstrVal = sCarrierId.AllocSysString();
		/////////////////
		//
		// �L�����A�̃Z�[�u
		//
		this->carrierId[port_no]	= sCarrierId;
		//
		if(port_no == eBottomPortNo){
			this->TraceBotD.bottomWaferCarrierID	= sCarrierId;
		}else{
		}
		/////////////////////////
		//
		// �L�����A���[�h�J�n
		//
		if((ret = m_hCsg300cms.CarrierLoad(port_no, vCarrierId, /*1*/eCarrierStart)) != 0){		//���[�h�J�n
			VariantClear(&vCarrierId);
			r = FALSE;
			this->err.PutError(Err_CarrierLoadFailed);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	// 
	if(r){
		if((ret = m_hCsg300cms.CarrierLoad(port_no, vCarrierId, /*2*/eCarrierFinished)) != 0){
			r = FALSE;
			this->err.PutError(Err_CarrierLoadFailed);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("CarrierLoad(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	VariantClear(&vCarrierId);
	return r;
}
//////////////////////////////////////////////
//
// CarrierUnload
//
BOOL DlgSG300::CarrierUnLoad(short port_no)
{
	// �r����return�֎~
	// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("CarrierUnLoad(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[port_no].AllocSysString();
	short transferState/* = getLPTransferState()*/;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	/////////////////////////
	//
	// TransferState���擾����B
	// ��{�I��LPTransferState���擾�ł��Ȃ����Ƃ͂��肦�Ȃ����c
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
			r = FALSE;
			this->err.PutError(Err_CarrierNotRecognizedB+port_no-1);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	if(r){
		// �X�e�[�^�X��ReadyToUnload�ɂ���(���̍ہATransferBlocked���o�R����)
		if(transferState != /*3*/eStateReadyToUnload){
			if(transferState != /*1*/eStateTransferBlocked){
				// TransferBlocked�ɂ���B
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*2*/eCmdTransferBlocked)) != 0){
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
			/////////////////////////
			//
			// ReadyToUnload�ɕύX����B
			//
			if(r){
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*4*/eCmdReadyToUnload)) != 0){	//ready to unload
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
		}
	}
	if(r){
		this->loadedByHost[port_no]	= false;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("CarrierUnLoad(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}

//////////////////////////////////////////////
//
// CarrierTakeIn
//
BOOL DlgSG300::CarrierTakeIn(short port_no)
{
	BOOL r = TRUE;
	// ���ɂȂ�
	return r;
}

//////////////////////////////////////////////
//
// CarrierTakeOut
//
BOOL DlgSG300::CarrierTakeOut(short port_no/*, bool errOut*/)
{
	// �r����return�֎~
	// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("CarrierTakeOut(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[port_no].AllocSysString();
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	short transferState/* = getLPTransferState()*/;
	//////////////////////////////
	//
	// TransferState���擾����B
	//
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
			r = FALSE;
			this->err.PutError(Err_CarrierNotRecognizedB+port_no-1);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	///////////////////////////
	//
	// ���ł�ReadyToLoad��Ԃł���΁A(���łɃA�����[�h���ꂽ�Ƃ݂Ȃ�)�������Ȃ�
	//
	if(r&&(transferState != /*2*/eStateReadyToLoad)){
		/////////////////////////
		//
		// ���݂�ReadyToUnload�łȂ���΁A�X�e�[�^�X��ReadyToUnload�ɂ���(���̍ہATransferBlocked���o�R����)
		//
		if(transferState != /*3*/eStateReadyToUnload){
			if(transferState != /*1*/eStateTransferBlocked){
				// TransferBlocked�ɂ���B
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*2*/eCmdTransferBlocked)) != 0){
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
			//////////////////////////
			//
			// ReadyToUnload�ɕύX����B
			//
			if(r){
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*4*/eCmdReadyToUnload)) != 0){	//ready to unload
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
		}
		if(r){
			VariantInit(&vCarrierId);
			vCarrierId.vt = VT_BSTR;
			vCarrierId.bstrVal = this->carrierId[port_no].AllocSysString();
		}
		////////////////////////////////
		//
		// CarrierUnload����(�X�e�[�^�X�͎�����ReadyToLoad�ɂȂ�)
		//
		if(r){
			if((ret = m_hCsg300cms.CarrierUnLoad(port_no, vCarrierId, /*1*/eCarrierStart)) != 0){		//���o�J�n
				VariantClear(&vCarrierId);
				this->err.PutError(Err_Dlg300_10);
				this->ErrorLogOut(__LINE__,ret);
				r = FALSE;
			}
		}
		if(r){
			if((ret = m_hCsg300cms.CarrierUnLoad(port_no, vCarrierId, /*2*/eCarrierFinished)) != 0){	//���o����
				this->err.PutError(Err_Dlg300_10);
				this->ErrorLogOut(__LINE__,ret);
				r = FALSE;
			}
		}
	}// end of if(r)
	if(r){
		this->loadedByHost[port_no]	= false;
	}
	VariantClear(&vCarrierId);
	::Sleep(1000);
	{
		CString msg;
		msg.Format("CarrierTakeOut(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}
////////////////////////////
//
// �����I�ɃL�����A���A�����[�h����
//
//
BOOL DlgSG300::CarrierForceTakeOut(short port_no, CString sCarrierId)
{
	// �r����return�֎~
	// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("CarrierForceTakeOut(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	short transferState/* = getLPTransferState()*/;
	// TransferState���擾����B
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
			r = FALSE;
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	/////////////////////////////////
	//
	// �X�e�[�^�X��ReadyToUnload�ɂ���(���̍ہATransferBlocked���o�R����)
	//
	if(r){
		if(transferState != /*3*/eStateReadyToUnload){
			if(transferState != /*1*/eStateTransferBlocked){
				// TransferBlocked�ɂ���B
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*2*/eCmdTransferBlocked)) != 0){
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
			////////////////////////
			//
			// ReadyToUnload�ɕύX����B
			//
			if(r){
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*4*/eCmdReadyToUnload)) != 0){	//ready to unload
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
		}
		VariantInit(&vCarrierId);
		vCarrierId.vt = VT_BSTR;
		vCarrierId.bstrVal = sCarrierId.AllocSysString();
	}
	///////////////////////////////
	//
	// CarrierUnload����(������ReadyToLoad�ɂȂ�)
	//
	if(r){
		if((ret = m_hCsg300cms.CarrierUnLoad(port_no, vCarrierId, /*1*/eCarrierStart)) != 0){		//���o�J�n
			VariantClear(&vCarrierId);
			this->ErrorLogOut(__LINE__,ret);
			r = FALSE;
		}
	}
	if(r){
		if((ret = m_hCsg300cms.CarrierUnLoad(port_no, vCarrierId, /*2*/eCarrierFinished)) != 0){	//���o����
			this->ErrorLogOut(__LINE__,ret);
			r = FALSE;
		}
		this->loadedByHost[port_no]	= false;
		::Sleep(1000);
	}
	{
		CString msg;
		msg.Format("CarrierForceTakeOut(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	VariantClear(&vCarrierId);
	return r;
}


short DlgSG300::getCtrlState()
{
	//���݂̃R���g���[����Ԃ��擾
	//1:Equipment Offline  2:Attempt Offline 3:Host Offline  4:Online Local  5:Online Remote
	short status, i_type;
	long elm;
	VARIANT	v;
	VariantInit(&v);
	m_hXComSecs.GetVIDVal("_CTRLSTATE",&v, &i_type, &elm, 0,0,0,0);
	status = v.bVal;
	VariantClear(&v);
	return status;
}

short DlgSG300::getLPTransferState()
{
	//���݂̃��[�h�|�[�g������Ԃ��擾
	//1:TRANSFER BLOCKED  2:READY TO LOAD 3:READY TO UNLOAD
	short status, i_type;
	long elm;
	VARIANT	v;
	VariantInit(&v);
	m_hXComSecs.GetVIDVal("_PORTTRANSFERSTATE",&v, &i_type, &elm, 0,0,0,0);
	status = v.bVal;
	VariantClear(&v);
	return status;
}

short DlgSG300::getLPTransferState(int port_no, CString sCarrierId)
{
	//���݂̃��[�h�|�[�g������Ԃ��擾
	//1:TRANSFER BLOCKED  2:READY TO LOAD 3:READY TO UNLOAD
//	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	short transferState/* = getLPTransferState()*/;
	// TransferState���擾����B
	if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
		transferState = 0;
	}
	return(transferState);
}
///////////////////////////////////////
//
// �L�����A�h�c�̌���
//
BOOL DlgSG300::ReadBottomCarrierID(CString sCarrierId)
{
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("ReadBottomCarrierID Start");
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	// CarrierIDReadEvent
	CEvent EvFinReadCarrierID;
	CEvent EvFailReadCarrierID;
	// �C�x���g�����Z�b�g����B
	EvFinReadCarrierID.ResetEvent();
	EvFailReadCarrierID.ResetEvent();
	// �C�x���g�̎��̐ݒ�
	this->pEvFinInfoBottomCarrierIdRead		= &EvFinReadCarrierID;
	this->pEvFailInfoBottomCarrierIdRead	= &EvFailReadCarrierID;
	this->PutPortNo((unsigned int)1);	// ���ꂩ��o������Ă�PortID����������
	///////////////////////////////////
	//
	// HOST��CarrierID�̌��ؗv�����s���B
	//
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.ReadCarrierId(/*port_no*/1, vCarrierId, 1)) != 0){
			r = FALSE;
			this->err.PutError(Err_Dlg300_06);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("ReadBottomCarrierID Waiting Host");
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();		// �ȍ~�͑��҂�PortNo��ύX���Ă��悢�B
	if(r){
		VariantClear(&vCarrierId);
		enum{
			WaitCnt		= 3,
		};
		//
		CSyncObject *ppObjects[WaitCnt] = {0};
		ppObjects[0]	= pEvFinInfoBottomCarrierIdRead;	// VERIFICATION_OK
		ppObjects[1]	= pEvFailInfoBottomCarrierIdRead;	// VERIFICATION_NG
		ppObjects[2]	= pEvStopWaitingSecsB;		// ���f
		CMultiLock	M(ppObjects,WaitCnt);
		//
		if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
			// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
			int i = M.Lock(INFINITE, FALSE);
			M.Unlock();
			i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == i) {
				// ����
				r = TRUE;
			} else if (1 == i) {
				// ���s
				r = FALSE;
				this->err.PutError(Err_BottomReadIdCanceled);
			} else if (2 == i) {
				//�r����~(���f)
				r = FALSE;
				this->StoppedBEvent();
			}
			{
				CString msg;
				msg.Format("ReadBottomCarrierID finished = %d\n", r);
				if(!r){
					this->err.LogSaveNFL(msg);
				}
#if !Release
				TRACE(msg);
#endif
			}
		
		}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
				//����_CARRIERIDSTATUS:2   ID Verification OK 
			this->setAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS", 2);
		}
		{
			CString msg;
			msg.Format("ReadBottomCarrierID End r = %d",r);
			this->err.LogSaveNFL(msg);
		}
		{
			long	ret;
			VARIANT vCarrierIdList;
			long	Count;
			VariantInit(&vCarrierIdList);
			if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
				VariantClear(&vCarrierIdList);
			}
#if !Release
			if(Count > 0){
				TRACE("ReadBottomCarrierID��Carrier is %d\n", Count);
			}
#endif
		}
	}
	this->pEvFinInfoBottomCarrierIdRead		= NULL;
	this->pEvFailInfoBottomCarrierIdRead	= NULL;
	return r;
}
//////////////////////////////
//
//	���u��RFID���[�_�������Ă��Ȃ��ꍇ�̏���
//	HOST����CarrierID���擾���āACarrierLoad����B
//
BOOL DlgSG300::NotifyTopCarrierID()
{
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	// CarrierIDReadEvent
	CEvent EvFinNotifyCarrier;
	CEvent EvFailNotifyCarrier;
	// �C�x���g�����Z�b�g����B
	EvFinNotifyCarrier.ResetEvent();
	EvFailNotifyCarrier.ResetEvent();
	// �C�x���g�̎��̐ݒ�
	this->pEvFinInfoTopCarrierIdNotified	= &EvFinNotifyCarrier;
	this->pEvFailInfoTopCarrierIdNotified	= &EvFailNotifyCarrier;
//	this->PutPortNo((unsigned int)2);	// ���ꂩ��o������Ă�PortID����������
	{
		CString msg;
		msg.Format("NotifyTopCarrierID Start");
		this->err.LogSaveNFL(msg);
	}
	///////////////////////////////////////////
	//
	// �N�����v�C�x���g�̏o��(HOST��RFID��ǂ�ł������Ɠ`����)
	//
	BOOL r = TRUE;
	if(r){
		// �N�����v�C�x���g�̒��ŃZ�}�t�H���b�N���Ă���̂Œ��ӁB
		r = this->ClampEvent(eTopPortNo);
	}
	enum{
		WaitCnt		= 3,
	};
	{
		CString msg;
		msg.Format("NotifyTopCarrierID Waiting Host");
		this->err.LogSaveNFL(msg);
	}
	///////////////////////////////////////////
	//
	// Notify�C�x���g�҂�
	//
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinInfoTopCarrierIdNotified;	// VERIFICATION_OK
	ppObjects[1]	= pEvFailInfoTopCarrierIdNotified;	// VERIFICATION_NG
	ppObjects[2]	= pEvStopWaitingSecsT;		// ���f
	CMultiLock	M(ppObjects,WaitCnt);
	//
	if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
		// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
		int i = M.Lock(INFINITE, FALSE);
		M.Unlock();
		i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
		if (0 == i) {
			// ����
			r = TRUE;
		} else if (1 == i) {
			// ���s
			r = FALSE;
			this->err.PutError(Err_TopNotifiyCanceled);
		} else if (2 == i) {
			//�r����~(���f)
			r = FALSE;
			this->StoppedTEvent();
		}
		{
			CString msg;
			msg.Format("NotifyTopCarrierID finished = %d\n", r);
			if(!r){
				this->err.LogSaveNFL(msg);
			}
#if !Release
			TRACE(msg);
#endif
		}
	}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
			//����_CARRIERIDSTATUS:2   ID Verification OK 
//		this->setAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS", 2);
	}
#if !Release
	TRACE("CarrierLoad = %s\n", this->carrierId[eTopPortNo]);
#endif
	if(r){
		////////////////////////////
		//
		// ������CarrierLoad����
		//
		// CarrierLoad()�̒��ŃZ�}�t�H���b�N���Ă���̂Œ���
		if(r){
			r = this->CarrierLoad(eTopPortNo, this->carrierId[eTopPortNo]);
		}
		// �r����return�֎~
		// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
		CSingleLock P1(&PortNoSema);
		P1.Lock();
		{
			CString msg;
			msg.Format("NotifyTopCarrierID ReadCarrierID");
			this->err.LogSaveNFL(msg);
		}
		// ���߂�PortNo���(�N�������������Ă邩������Ȃ��̂�)
		this->PutPortNo((unsigned int)2);	// ���ꂩ��o������Ă�PortID����������
		if(r){
			long	ret;
			vCarrierId.bstrVal = this->carrierId[eTopPortNo].AllocSysString();
			////////////////////////////////////
			//
			// CarrierID�̌��؊����֑J�ڂ���(HOST�֌��ؗv���͂��Ȃ�)�B
			//
			if((ret = m_hCsg300cms.ReadCarrierId(/*port_no*/2, vCarrierId, 3)) != 0){
				r = FALSE;
				this->err.PutError(Err_Dlg300_06);
				this->ErrorLogOut(__LINE__,ret);
			}
		}
		::Sleep(500);
		{
			CString msg;
			msg.Format("NotifyTopCarrierID ReadCarrierID End");
			this->err.LogSaveNFL(msg);
		}
		P1.Unlock();	// ���҂�PortNo�������݋���
	}
	if(r){
		long	ret;
		VARIANT vCarrierIdList;
		long	Count;
		VariantInit(&vCarrierIdList);
		if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
			VariantClear(&vCarrierIdList);
		}
#if !Release
		if(Count > 0){
			TRACE("NotifyTopCarrierID��Carrier is %d\n", Count);
		}
#endif
	}
	{
		CString msg;
		msg.Format("NotifyTopCarrierID ReadCarrierID End");
		this->err.LogSaveNFL(msg);
	}
	this->pEvFinInfoTopCarrierIdNotified	= NULL;
	this->pEvFailInfoTopCarrierIdNotified	= NULL;
	return r;
}
//////////////////////////////
//
// SlotMap�̌���(ReadBottomSlotMap��ReadTopSlotMap���قړ���
// ���\�b�h�ł��邪�A�����ɌĂ΂�邱�Ƃ��\�z����A����
// ���ꂼ��̎�M�C�x���g�������Ȃ���΂����Ȃ��̂ŁA
// ���\�b�h�͂��ꂼ�ꎝ���Ƃɂ���B
// ����Foup���Q�A�}�K�W�����Q�ɂȂ����ꍇ�A���\�b�h���S��
// ���ׂ��Ȃ̂��͕ʓr�l����B
// Bottom���X���b�g�}�b�v�̌���
BOOL DlgSG300::ReadBottomSlotMap(CString sCarrierId, int SlotMap[], int SlotCount)
{
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("ReadBottomSlotMap Start");
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId, vSlotMap;
	SAFEARRAYBOUND	rgsabound[1];
	SAFEARRAY FAR*	pas;
	LONG			i;
	// CarrierIDReadEvent
	CEvent EvFinReadSlotMap;
	CEvent EvFailReadSlotMap;
	EvFinReadSlotMap.ResetEvent();
	EvFailReadSlotMap.ResetEvent();
	this->PutPortNo((unsigned int)1);	// ���ꂩ��o������Ă�PortID����������
	//
	this->pEvFinInfoBottomSlotMap	= &EvFinReadSlotMap;
	this->pEvFailInfoBottomSlotMap	= &EvFailReadSlotMap;
	//
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	//
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = 25;
	pas = SafeArrayCreate(VT_I2, 1, rgsabound);
	BOOL r = TRUE;
	//
	if(r){
		if(pas == NULL){
			SafeArrayDestroy(pas);
			r = FALSE;
//			return r;
		}
	}
	//
	if(r){
		for(i = 0; i < (LONG)rgsabound[0].cElements; i++){
			ret = SafeArrayPutElement(pas, (long*)&i, (int*)&SlotMap[i]);
			if(ret != 0){
				r = FALSE;
				this->err.PutError(Err_SlotMapRead1);
				this->ErrorLogOut(__LINE__,ret);
			}
		}
		VariantInit(&vSlotMap);
		vSlotMap.vt = VT_ARRAY | VT_I2;
		vSlotMap.parray = pas;
	//
#if !Release
		TRACE("ReadBottomSlotMap = %s\n", sCarrierId);
#endif
	}
	if(r){
		if((ret = m_hCsg300cms.ReadSlotMap(vCarrierId, vSlotMap, SlotCount, 1)) != 0){
			SafeArrayDestroy(pas);
			VariantClear(&vCarrierId);
			VariantClear(&vSlotMap);
			r = FALSE;
			this->err.PutError(Err_SlotMapRead2);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	::Sleep(500);
	{
		CString msg;
		msg.Format("ReadBottomSlotMap Waiting HOST");
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();		// �����ň�U���҂�PortNo�������݉\�Ƃ���B
	if(r){
		enum{
			WaitCnt		= 3,
		};
		CSyncObject *ppObjects[WaitCnt] = {0};
		ppObjects[0]	= pEvFinInfoBottomSlotMap;		// VERIFICATION_OK
		ppObjects[1]	= pEvFailInfoBottomSlotMap;		// VERIFICATION_NG
		ppObjects[2]	= pEvStopWaitingSecsB;		// ���f
		CMultiLock	M(ppObjects,WaitCnt);
		if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
			// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
			int k = M.Lock(INFINITE, FALSE);
			M.Unlock();
			k -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == k) {
				// ����
				r = TRUE;
			} else if (1 == k) {
				// ���s
				r = FALSE;
				this->err.PutError(Err_BottomSlotMapCanceled);
			} else if (2 == k) {
				//�r����~(���f)
				r = FALSE;
				this->StoppedBEvent();
			}
			{
				CString msg;
				msg.Format("ReadBottomSlotMap finished = %d\n", r);
				if(!r){
					this->err.LogSaveNFL(msg);
				}
#if !Release
				TRACE(msg);
#endif
			}
		}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
				//����_SLOTMAPSTATUS:2   Slotmap Verification OK 
			this->setAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS", 2);
		}
	}
	if(r){
		////////////////////////////////////////////////////////////////////
		//
		// CarrierAccessStatus��IN ACCESS�ɂ���(����ȍ~��CancelCarrier�͕s��)
		//
		// ���߂�PortNo�������݋֎~�Ƃ���B
		// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
		CSingleLock P1(&PortNoSema);
		P1.Lock();
		{
			CString msg;
			msg.Format("ReadBottomSlotMap ChangeCarrierAccessState");
			this->err.LogSaveNFL(msg);
		}
		this->PutPortNo((unsigned int)1);	// ���ꂩ��o������Ă�PortID����������
		if(getAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS") == 2){
			if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*1*/eInAccess)) != 0){
				r = FALSE;
			}
		}
		this->pEvFinInfoBottomSlotMap	= NULL;
		this->pEvFailInfoBottomSlotMap	= NULL;
		SafeArrayDestroy(pas);
		VariantClear(&vCarrierId);
		VariantClear(&vSlotMap);
		{
			long	ret;
			VARIANT vCarrierIdList;
			long	Count;
			VariantInit(&vCarrierIdList);
			if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
				VariantClear(&vCarrierIdList);
			}
		}
		::Sleep(1000);
		{
			CString msg;
			msg.Format("ReadBottomSlotMap End");
			this->err.LogSaveNFL(msg);
		}
		P1.Unlock();	// PortNo�������݋���
	}
	return r;
}

BOOL DlgSG300::ReadTopSlotMap(CString sCarrierId, int SlotMap[], int SlotCount)
{
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("ReadTopSlotMap Start");
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId, vSlotMap;
	SAFEARRAYBOUND	rgsabound[1];
	SAFEARRAY FAR*	pas;
	LONG			i;
	// CarrierIDReadEvent
	CEvent EvFinReadSlotMap;
	CEvent EvFailReadSlotMap;
	EvFinReadSlotMap.ResetEvent();
	EvFailReadSlotMap.ResetEvent();
	this->PutPortNo((unsigned int)2);	// ���ꂩ��o������Ă�PortID����������
	//
	this->pEvFinInfoTopSlotMap	= &EvFinReadSlotMap;
	this->pEvFailInfoTopSlotMap	= &EvFailReadSlotMap;
	//
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	//
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = 25;
	pas = SafeArrayCreate(VT_I2, 1, rgsabound);
	//
	BOOL r = TRUE;
	if(r){
		if(pas == NULL){
			SafeArrayDestroy(pas);
			r = FALSE;
		}
	}
	//
	if(r){
		for(i = 0; i < (LONG)rgsabound[0].cElements; i++){
			ret = SafeArrayPutElement(pas, (long*)&i, (int*)&SlotMap[i]);
			if(ret != 0){
				r = FALSE;
				this->err.PutError(Err_SlotMapRead1);
				this->ErrorLogOut(__LINE__,ret);
			}
		}
		VariantInit(&vSlotMap);
		vSlotMap.vt = VT_ARRAY | VT_I2;
		vSlotMap.parray = pas;
	}
	//
	if(r){
#if !Release
		TRACE("ReadTopSlotMap = %s\n", sCarrierId);
#endif
		if((ret = m_hCsg300cms.ReadSlotMap(vCarrierId, vSlotMap, SlotCount, 1)) != 0){
			SafeArrayDestroy(pas);
			VariantClear(&vCarrierId);
			VariantClear(&vSlotMap);
			r = FALSE;
			this->err.PutError(Err_SlotMapRead2);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	::Sleep(500);
	{
		CString msg;
		msg.Format("ReadTopSlotMap Waiting HOST");
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();		// �����܂łň�U���҂�PortNo�������݋��Ƃ���B
	if(r){
		enum{
			WaitCnt		= 3,
		};
		CSyncObject *ppObjects[WaitCnt] = {0};
		ppObjects[0]	= pEvFinInfoTopSlotMap;		// VERIFICATION_OK
		ppObjects[1]	= pEvFailInfoTopSlotMap;	// VERIFICATION_NG
		ppObjects[2]	= pEvStopWaitingSecsT;		// ���f
		CMultiLock	M(ppObjects,WaitCnt);
		if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
			// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
			int k = M.Lock(INFINITE, FALSE);
			M.Unlock();
			k -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == k) {
				// ����
				r = TRUE;
			} else if (1 == k) {
				// ���s
				r = FALSE;
				this->err.PutError(Err_TopSlotMapCanceled);
			} else if (2 == k) {
				//�r����~(���f)
				r = FALSE;
				this->StoppedTEvent();
			}
			{
				CString msg;
				msg.Format("ReadTopSlotMap finished = %d\n", r);
				if(!r){
					this->err.LogSaveNFL(msg);
				}
#if !Release
				TRACE(msg);
#endif
			}
		}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
				//����_SLOTMAPSTATUS:2   Slotmap Verification OK 
			this->setAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS", 2);
		}
	}
	{
		CString msg;
		msg.Format("ReadTopSlotMap ChangeAccessState");
		this->err.LogSaveNFL(msg);
	}
	////////////////////////////////////////////////////////////////////
	//
	// CarrierAccessStatus��IN ACCESS�ɂ���(����ȍ~��CancelCarrier�͕s��)
	//
	if(r){
		// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
		CSingleLock P1(&PortNoSema);
		P1.Lock();
		this->PutPortNo((unsigned int)2);	// ���ꂩ��o������Ă�PortID����������
		if(getAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS") == 2){
			if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*1*/eInAccess)) != 0){		//In Access ����ȍ~CancelCarrier�s�\
				r = FALSE;
			}
		}
		::Sleep(1000);
		{
			CString msg;
			msg.Format("ReadTopSlotMap End");
			this->err.LogSaveNFL(msg);
		}
		P1.Unlock();
		this->pEvFinInfoTopSlotMap	= NULL;
		this->pEvFailInfoTopSlotMap	= NULL;
		SafeArrayDestroy(pas);
		VariantClear(&vCarrierId);
		VariantClear(&vSlotMap);
		{
			long	ret;
			VARIANT vCarrierIdList;
			long	Count;
			VariantInit(&vCarrierIdList);
			if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
				VariantClear(&vCarrierIdList);
			}
		}
	}
	return r;
}
/////////////////////////////
//
//	ContentMap�̎擾
//
void DlgSG300::GetContentMap(){
//	BOOL r = TRUE;
	CString	ObjType, ObjId;
	LPCSTR	attr_name;
	long	element, ret = 0;
	VARIANT	vObjType, vObjId, v;
	short	item_type;
	SAFEARRAY FAR	*pArray;
	unsigned char	cData;
	CString	dataStr;
	unsigned long i;
	//
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&v);
	//
	ObjId = this->carrierId[eBottomPortNo];
	vObjId.vt = VT_BSTR;
	vObjId.bstrVal = ObjId.AllocSysString();
	//
	ObjType = "Carrier";
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = ObjType.AllocSysString();
	//
	attr_name = "_SUBSTID_N1";	//wafer_ID
	//
	for(int j=0;j<eWaferNumberMax;j++){
		// Carrier�����́u_SUBSTID_N1�v�z��̒l�����Ԃ�1�`25�܂Ŏ擾����B
		ret = m_hXComSecs.GetAttrData(vObjType, vObjId, attr_name, &v, &item_type, &element, j+1, 0, 0, 0);
		if(ret==0){
			this->waferIdOfContentMap[j]	= v.bstrVal;
		}
	}
	//
	if(ret != 0){
	}else{
		if(v.vt & VT_ARRAY){
			pArray = v.parray;
			for(i = 0; i < SafeArrayGetElemsize(pArray); i++){
				if(SafeArrayGetElement(pArray, (long FAR*)&i, &cData) != S_OK){
					break;
				}
			}
		}else{
			if(v.vt == VT_BSTR){
			}else if(v.vt == VT_I4){
			}else if(v.vt == VT_UI1){
			}
		}
		VariantClear(&vObjId);
		VariantClear(&vObjType);
		VariantClear(&v);
	}
}

BOOL DlgSG300::DelALLCarrierObj(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vCarrierIdList;
	VARIANT vCarrierId;
	long	Count;
	SAFEARRAY FAR*	pArray;
	VariantInit(&vCarrierIdList);
	if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
		VariantClear(&vCarrierIdList);
		r = FALSE;
		return r;
	}
	if(Count == 0){
		VariantClear(&vCarrierIdList);
		return r;
	}
	if(Count != 0){
		CString msg;
		msg.Format("Delete All Carrier Object= %d\n", Count);
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
	}
	pArray = vCarrierIdList.parray;
	VariantInit(&vCarrierId);
	for(long i = 0; i < Count; i++){
		SafeArrayGetElement(pArray, &i, &vCarrierId);
		if((ret = m_hCsg300cms.DeleteCarrier(vCarrierId)) != 0){
			r = FALSE;
			break;
		}
	}
	SafeArrayDestroy(pArray);
	VariantClear(&vCarrierIdList);
	VariantClear(&vCarrierId);
	if(Count != 0){
		CString msg;
		msg.Format("Delete All finished\n");
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
		::Sleep(500);
	}
	return r;
}

BOOL DlgSG300::UnloadALLCarrierObj(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vCarrierIdList;
	VARIANT vCarrierId;
	long	Count;
	SAFEARRAY FAR*	pArray;
	VariantInit(&vCarrierIdList);
	if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
		VariantClear(&vCarrierIdList);
		r = FALSE;
		return r;
	}
	if(Count == 0){
		VariantClear(&vCarrierIdList);
		return r;
	}
	if(Count != 0){
		CString msg;
		msg.Format("Force Unload Carrier = %d\n", Count);
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
	}
	pArray = vCarrierIdList.parray;
	VariantInit(&vCarrierId);
	CString carrierId;
	for(long i = 0; i < Count; i++){
		SafeArrayGetElement(pArray, &i, &vCarrierId);
		carrierId = vCarrierId.bstrVal;
		this->CarrierForceTakeOut(eBottomPortNo, carrierId);
		this->CarrierForceTakeOut(eTopPortNo, carrierId);
	}
	if(Count != 0){
		CString msg;
		msg.Format("Unload All finished\n");
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
		::Sleep(500);
	}
//	this->carrierIsCreated	= false;
	SafeArrayDestroy(pArray);
	VariantClear(&vCarrierIdList);
	VariantClear(&vCarrierId);
	return r;
}
///////////////////////////////////////////////////////
//
//
//
//	R e c e i v e  S t r e a m F u n c t i o n
//	Receive Stream Function
//
//
//
//

BOOL DlgSG300::RecvCarrierRelease(int port_no)
{
	BOOL r = TRUE;
	long	ret;
	short carrierIdState, slotMapState, accessStateT, accessStateB;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	// Bottom Wafer��Status���擾����B
	{
		vCarrierId.bstrVal = this->carrierId[eBottomPortNo].AllocSysString();
		// CarrierState���擾����B
		if((ret = m_hCsg300cms.GetCarrierState(vCarrierId, &carrierIdState, &slotMapState, &accessStateB))){
			accessStateB = eNotIDRead;
			// �擾�ł��Ȃ����NotInRead�Ƃ���B
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	// Top Wafer��Status���擾����B
	{
		vCarrierId.bstrVal = this->carrierId[eTopPortNo].AllocSysString();
		// CarrierState���擾����B
		if((ret = m_hCsg300cms.GetCarrierState(vCarrierId, &carrierIdState, &slotMapState, &accessStateT))){
			accessStateT = eNotIDRead;
			// �擾�ł��Ȃ����NotInRead�Ƃ���B
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	{
		CString msg;
		msg.Format("ReceiveCarrierRelease(%d) AccessStateB(%d)T(%d)\n",
										port_no, accessStateB, accessStateT);
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
	}
	///////////////////////
	//
	// Bottom Wafer��CarrierRelease�̏ꍇ
	//
	if(port_no == eBottomPortNo){
		// �������g��CarrierComplete�ł���΁A
		if(accessStateB != eInAccess){	//CarrierComplete or CarrierStopped
			this->PutSecsItemSingleBIN("Itm_CAACK2", 0);	// Acknowledge
		}else{
			this->PutSecsItemSingleBIN("Itm_CAACK2", 2);	// Can not perform now
		}
		//S3F18���M
		if((ret = m_hXComSecs.PutSecsEvent("_GS03F18S_2")) != 0){
			r = FALSE;
		}
		// �L�����A�A�N�Z�X��Ԃ�CarrierComplete�ȏ�ł����
		if(r && (accessStateB > eInAccess)){	//CarrierComplete or CarrierStopped
			// 
			if(this->pEvBottomWaferUnloadReq){
				// BottomWaferUnload�v�����Ĕ�����
				this->pEvBottomWaferUnloadReq->SetEvent();
			}
		}
	}else if(port_no == eTopPortNo){
		// �������g��CarrierComplete���A�����łȂ��Ă�BottomWafer��CarrierComplete�ł���΁A
		// �n�j��Ԏ�����B
		if((accessStateB > eInAccess)||(accessStateT != eInAccess)){	//CarrierComplete or CarrierStopped
			this->PutSecsItemSingleBIN("Itm_CAACK2", 0);	// Acknowledge
		}else{
			this->PutSecsItemSingleBIN("Itm_CAACK2", 2);	// Can not perform now
		}
		//S3F18���M
		if((ret = m_hXComSecs.PutSecsEvent("_GS03F18S_2")) != 0){
			r = FALSE;
		}
		// �������g��CarrierComplete�̏ꍇ(TopWafer�����S���I����Ă���ꍇ)
		if(r && (accessStateT > eInAccess)){	//CarrierComplete or CarrierStopped
			// ���ɏ�ʂł���Ă��炤���Ƃ͂Ȃ��̂ŁA
			// ������CarrierUnload����B
			r = this->CarrierUnLoad(eTopPortNo);
			// TopWafer���́A�����������܂ł́A�b��ł�����ReadyToLoad�ɂ���B
			if(r){
				// ReadyToLoad �����s����B
				r = this->CarrierTakeOut(eTopPortNo);
			}
			if(r){
				// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
				if((!this->loadedByHost[eTopPortNo])&&(!this->loadedByHost[eBottomPortNo])){
					::Sleep(500);
					r = this->ProcessCompleteEvent();
				}
			}
			// �������g�͍�ƒ������ABottomWafer���I�����Ă���ꍇ
		}else  if(r && (accessStateB != eInAccess)){	//CarrierComplete or CarrierStopped
			if(this->pEvTopWaferUnloadReq){
				// TopWaferUnload�v�����Ĕ�����
				this->pEvTopWaferUnloadReq->SetEvent();
			}
		}
	}
	return r;
}


BOOL DlgSG300::RecvCarrierNotification(int port_no, CString carrierId)
{
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	// CarrierID�̎擾
	vCarrierId.bstrVal = carrierId.AllocSysString();
	VariantClear(&vCarrierId);
	// carrierId������name��"cancelcarrier"�ł���΁AcarrerId�̏ƍ���
	// HOST��NG�ɂ��ꂽ�ƌ��Ȃ��B
	if(strcmp(carrierId, "cancelcarrier") == 0){
		// �C�x���g���s
		if((port_no == eTopPortNo)&&(this->pEvFailInfoTopCarrierIdNotified)){
			this->pEvFailInfoTopCarrierIdNotified->SetEvent();
		}
	}else{// �����łȂ��ꍇ(HOST���K����CarrierID���擾�ł����ꍇ
		// 
		if(port_no == eBottomPortNo){
			this->TraceBotD.bottomWaferCarrierID	= carrierId;
			this->carrierId[eBottomPortNo]			= carrierId;
		}else{
			this->TraceTopD.topWaferCarrierID		= carrierId;
			this->TraceBotD.topWaferCarrierID		= carrierId;
			this->carrierId[eTopPortNo]				= carrierId;
		}
		// �C�x���g���s
		if((port_no == eTopPortNo)&&(this->pEvFinInfoTopCarrierIdNotified)){
			this->pEvFinInfoTopCarrierIdNotified->SetEvent();
		}
	}
	this->PutSecsItemSingleBIN("Itm_CAACK2", 0);	// Acknowledge
	//S3F18���M
	if((ret = m_hXComSecs.PutSecsEvent("_GS03F18S_2")) != 0){
		r = FALSE;
#if !Release
		TRACE("_GS03F18S_2 failed 0x%X\n",ret);
#endif
	}
	return r;
}

BOOL DlgSG300::StartCheck()
{
	BOOL r = TRUE;
	long	ret;
	{
		CString msg;
		msg.Format("%s(%d) CarrierManagementStartCheck = B(%d) T(%d)\n",
										__FILE__, __LINE__,
										this->loadedByHost[eBottomPortNo],
										this->loadedByHost[eTopPortNo]);
		this->err.LogSaveNFL(msg);
	}
	short carrierIdState, slotMapState, accessStateT, accessStateB;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	// Bottom Wafer��load����Ă���Ȃ��BottomWafer��Status���擾����B
	if(this->loadedByHost[eBottomPortNo]){
		vCarrierId.bstrVal = this->carrierId[eBottomPortNo].AllocSysString();
		// CarrierState���擾����B
		if((ret = m_hCsg300cms.GetCarrierState(vCarrierId, &carrierIdState, &slotMapState, &accessStateB))){
			// �擾�ł��Ȃ����NotIDRead�Ƃ���B
			accessStateB = eNotIDRead;
			this->ErrorLogOut(__LINE__,ret);
		}
		// ����ɓǂ߂�&&�A�N�Z�X�R���v���[�g��Ԃł���
		if((!ret)&&(accessStateB >= eCompleted)){// access 
			r = FALSE;
			this->err.PutError(Err_BottomWaferIsAlreadyComplete);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	// TopWafer��load����Ă���Ȃ��topWafer��Status���擾����B
	if(this->loadedByHost[eTopPortNo]){
		vCarrierId.bstrVal = this->carrierId[eTopPortNo].AllocSysString();
		// CarrierState���擾����B
		if((ret = m_hCsg300cms.GetCarrierState(vCarrierId, &carrierIdState, &slotMapState, &accessStateT))){
			// �擾�ł��Ȃ����NotIDRead�Ƃ���B
			accessStateT = eNotIDRead;
			this->err.PutError(Err_CarrierNotRecognizedT);
			this->ErrorLogOut(__LINE__,ret);
		}
		// ����ɓǂ߂�&&�A�N�Z�X�R���v���[�g��Ԃł���
		if((!ret)&&(accessStateT >= eCompleted)){// access 
			r = FALSE;
			this->err.PutError(Err_TopWaferIsAlreadyComplete);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	return r;
}


//////////////////////////////////////////////////////////
//
//
//
//
//	H o s t   C o m m a n d S e n d �֌W
//
//
//
//
void DlgSG300::SetPPRecipeSendReqEvent(CEventX* pEvSendReq)
{
	this->pEvPPRecipeSendReq = pEvSendReq;					// S7F25/26 �v���Z�X�v���O�������M�J�n	OK�񍐲����
}
void DlgSG300::SetPPSelectReqEvent(CEventX* pEvSelectReq)
{
	this->pEvPPSelectReq = pEvSelectReq;					// S2F41/42 OK�񍐲����
}
void DlgSG300::SetPPStartReqEvent(CEventX* pEvStartReqB, CEventX* pEvStartReqT)
{
	this->pEvPPStartReq_B = pEvStartReqB;						// S2F41/42 OK�񍐲����
	this->pEvPPStartReq_T = pEvStartReqT;						// S2F41/42 OK�񍐲����
}
void DlgSG300::ResetPPSelectReqEvent()
{
//	this->pEvPPSelectReq	= NULL;
//	this->pEvPPStartReq_B	= NULL;
//	this->pEvPPStartReq_T	= NULL;
	this->pEvPPSelectReq->ResetEvent();
	this->pEvPPStartReq_B->ResetEvent();
	this->pEvPPStartReq_T->ResetEvent();
}

void DlgSG300::RecvS02F41()
{
	BOOL r=true;
	short	item_type;
	long	ret,element;
	VARIANT	vtData;
	CString	ttmp;
	VariantInit( &vtData );
	ret = m_hXComSecs.GetItemData("Itm_RCMD2",&vtData, &item_type,&element,0,0,0,0);
	if( ret ){
		///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
		return;
	}
	ttmp = vtData.bstrVal;
	if(ttmp == "PPSELECT"){
		/////////////////////
		// CPVAL���擾
		//
		VariantClear( &vtData );
		ret = m_hXComSecs.GetItemData("Itm_CPVAL",&vtData, &item_type,&element,1,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
			return;
		}
		this->cpVal = vtData.bstrVal;
		// �����Œ�����CPVAL�������o�ϐ��ɃZ�b�g�B
		// SetEvent�̐�Ńt�@�C�����ɕ�������B
		/////////////////////
		//
		if(this->pEvPPSelectReq){
			this->pEvPPSelectReq->SetEvent();
		}
		//////////////////////////////////
		//
		// �Ԏ�(S2F42)�͕i��f�[�^�ǂݍ��݂��I����Ă���Ƃ���B
		//
#if !Release
		TRACE("SECS-Send S2F41-PPSELECT: Recipe=%s\n", cpVal);
#endif
	}
	else if(ttmp == "START"){
		int port_no = 0;
		VariantClear( &vtData );
		// �p�����[�^���̎擾
		ret = m_hXComSecs.GetItemData("V1",&vtData, &item_type,&element,0,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
			return;
		}
		int list_cnt = (int)vtData.iVal;	//���X�g���̎擾
		CString port_id = "", slot_map = "";
		for(int i = 0; i < list_cnt; i++){
			CString cp_name;
			VariantClear( &vtData );
			// i�Ԗڂ�CPName���擾����
			ret = m_hXComSecs.GetItemData("Itm_CPNAME",&vtData, &item_type,&element,i+1,0,0,0);
			if( ret ){
				///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
				return;
			}
			cp_name = vtData.bstrVal;
			// CPName��"PortID"��"WaferRange"�������ꍇ�̏���
			if((cp_name == "PortID") || (cp_name == "WaferRange")){
				ret = m_hXComSecs.GetItemData("Itm_CPVAL",&vtData, &item_type,&element,i+1,0,0,0);
				if( ret ){
					///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
					return;
				}
				if(cp_name == "PortID"){
					port_id = vtData.bstrVal;
				}else if(cp_name == "WaferRange"){
					slot_map = vtData.bstrVal;
				}
			}else{
				//�G���[����(cp_name���ُ�)
			}
		}
		////////////////////
		//
		// ���ꂼ���Item���擾�ł�����S2F42��ԐM���Ă��悢���ƂƂ���B
		//
		this->SendS02F42();
		// �߰�ID�ƃX���b�g�}�b�v�������Ă����
		if(port_id != "" && slot_map != ""){
			VARIANT	vObjType, vObjId, v;
			CString carrierID;
			CString ObjType = "Carrier";
			unsigned int data_v;
			VariantInit(&vObjType);
			VariantInit(&vObjId);
			// PortID�̔��f(Bottom��Top��)
			if(eBottomPortNo == _ttoi(port_id)){
				carrierID = this->carrierId[eBottomPortNo];
				port_no = eBottomPortNo;
			}else{
				carrierID = this->carrierId[eTopPortNo];
				port_no = eTopPortNo;
			}
			vObjType.vt = VT_BSTR;
			vObjType.bstrVal = ObjType.AllocSysString();
			vObjId.vt = VT_BSTR;
			vObjId.bstrVal = carrierID.AllocSysString();
			for(int i = 0; i < slot_map.GetLength(); i++){
				VariantInit(&v);
				data_v = (unsigned int)(slot_map.GetAt(i) - '0');
				this->waferUmu[port_no][i]	= (int)data_v;
				// �ȉ���^�ʖڂɂ��̂ł���΁A������ʉ߂��Ă���S2F42���o�����Ƃ���������B
				// �A���A�G���[������Ƃ�����S2F42���o������return���邱�Ƃ̂Ȃ��悤��
//				v.vt = VT_UI1;
//				v.bVal = data_v;
//
//				ret = m_hXComSecs.PutAttrData(vObjType, vObjId, "_ENUMERATED_N1", v, 0x00A4, 1, i+1, 0, 0, 0);
//				if( ret ){
//					///WriteLog( ERRMSGID2, "PutAttrData(PPID) Error: 0x%08X", ret );
//					VariantClear(&vObjType);
//					VariantClear(&vObjId);
//					VariantClear(&v);
//					return;
//				}
//				VariantClear(&v);
			}
			VariantClear(&vObjType);
			VariantClear(&vObjId);
		}else{
			//�G���[����(�l�������Ă��Ȃ�)
		}
		//////////////////////
		//
		// PortNo���󂯎���܂ł̎b��
		//
		if(port_no == eBottomPortNo){
			if(this->pEvPPStartReq_B){
				this->pEvPPStartReq_B->SetEvent();
			}
		}else if(port_no == eTopPortNo){
			if(this->pEvPPStartReq_T){
				this->pEvPPStartReq_T->SetEvent();
			}
		}
	}
	else if(ttmp == "GOLOCAL"){
		r = this->ChangeOnLineLocal();
//		if(r){
			this->SendS02F42();
//		}
		// todo : �G���[����
	}
	else if(ttmp == "GOREMOTE"){
		r = this->ChangeOnLineRemote();
		// todo : �G���[����
//		if(r){
			this->SendS02F42();
//		}
	}
	else{
		// todo : �G���[�����i�����ɓ����Ă͂����Ȃ��B�j
	}
}

void DlgSG300::SendS02F42(){
	int ret=0;
	ret = m_hXComSecs.PutSecsEvent( "_GS02F42S" );
	if( ret ){
		// todo �G���[�����B
	}
}

int DlgSG300::Receive_BottomPPStartAction()
{
	int r = 99999;
	//
	enum{
		ObjectMax = 3,
	};
	this->HostCommandStatus	= eNotReceived;
	CSyncObject *ppObjects[ObjectMax];
	ppObjects[0]	= pEvPPSelectReq;		// �����̃X���b�h�ő҂��Ă���\�����邪�A�������̏���
	ppObjects[1]	= pEvPPStartReq_B;		// Bottom��ʑ���PPStart�҂�
	ppObjects[2]	= pEvStopWaitingSecsB;	// ���f
	CMultiLock M(ppObjects, ObjectMax);		// �����~or�v���҂��錾
	int i = M.Lock(INFINITE, FALSE);		// �����I�u�W�F�N�g�̔z���҂����킹(FALSE:1�ȏ�̓����I�u�W�F�N�g���V�O�i����ԂƂȂ�Ƃ����ɕ��A)
	M.Unlock();								// ���L���铯���I�u�W�F�N�g�����
	i -= WAIT_OBJECT_0;						// ����ُ�ԂɂȂ�����޼ު��No.
	//
#if !Release
	TRACE("GetHostCommand(B) = %d\n", i);
#endif
	if (0 == i){		// PPSelect�������B
		this->HostCommandStatus	= eGetPPSelect;
		r = TRUE;
	}else if (1 == i){	// PPStrat�������B
		this->HostCommandStatus	= eGetPPStart_B;
		r = TRUE;
	}else if (2 == i){	// ���f�������B
		this->HostCommandStatus	= eNotReceived;
		r = FALSE;
	}
	return r;
}

int DlgSG300::Receive_TopPPStartAction()
{
	int r = 99999;
	//
	enum{
		ObjectMax = 3,
	};
	this->HostCommandStatus	= eNotReceived;
	CSyncObject *ppObjects[ObjectMax];
	ppObjects[0]	= pEvPPSelectReq;		// �����̃X���b�h�ő҂��Ă���\�����邪�A�������̏���
	ppObjects[1]	= pEvPPStartReq_T;		// TopWafer��PPStart������
	ppObjects[2]	= pEvStopWaitingSecsT;	// ���f
	CMultiLock M(ppObjects, ObjectMax);		// �����~or�v���҂��錾
	int i = M.Lock(INFINITE, FALSE);		// �����I�u�W�F�N�g�̔z���҂����킹(FALSE:1�ȏ�̓����I�u�W�F�N�g���V�O�i����ԂƂȂ�Ƃ����ɕ��A)
	M.Unlock();								// ���L���铯���I�u�W�F�N�g�����
	i -= WAIT_OBJECT_0;						// ����ُ�ԂɂȂ�����޼ު��No.
	//
#if !Release
	TRACE("GetHostCommand(T) = %d\n", i);
#endif
	if (0 == i){		// PPSelect�������B
		this->HostCommandStatus	= eGetPPSelect;
		r = TRUE;
	}else if (1 == i){	// PPStrat�������B
		this->HostCommandStatus	= eGetPPStart_T;
		r = TRUE;
	}else if (2 == i){	// ���f�������B
		this->HostCommandStatus	= eNotReceived;
		r = FALSE;
	}
	return r;
}

//////////////////////////////////////////////////////////////
//
//
//
//
//	E v e n t  R e p o r t  S e n d (S6F11/12 �C�x���g���M�֌W�j
//
//
//
//
BOOL DlgSG300::PutPortNo(unsigned int item_data){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	VariantInit(&vid_data);
	VariantClear(&vid_data);
	vid_data.vt = VT_UI1;
	vid_data.uiVal = item_data;
	if((ret = m_hXComSecs.SetVIDVal("_PORTIDForEvent",vid_data,0x00a4,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}
BOOL DlgSG300::PutProcessState(int status){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	VariantInit(&vid_data);
	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = status;
	//
	if((ret = m_hXComSecs.SetVIDVal("_ProcessState",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}

BOOL DlgSG300::PutProcessPPID(CString ppId){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	VariantInit(&vid_data);
	VariantClear(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = ppId.AllocSysString();
	// 
	if((ret = m_hXComSecs.SetVIDVal("_ProcessPPID",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	return r;
}
//#Ducmv 20150825 SECS S6F11 ReadRIFD (S)
BOOL DlgSG300::ReadRFIDEvent(){
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("ReadRFIDEvent",0)) != 0){
		r = FALSE;
	}
	return r;
}
//#Ducmv 20150825 SECS S6F11 ReadRIFD (E)

BOOL DlgSG300::ClampEvent(int port_no){
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("Clamp(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	BOOL r = TRUE;
	if((ret = m_hXComSecs.SndEvntInf("ClampEvent",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("Clamp(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}

//#Ducmv 20150825 SECS S6F11 Unclamp (S)
BOOL DlgSG300::UnclampEvent(int port_no){
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("UnClamp(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	BOOL r = TRUE;
	if((ret = m_hXComSecs.SndEvntInf("UnClampEvent",0)) != 0){
		r = FALSE;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("UnClamp(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}
//#Ducmv 20150825 SECS S6F11 Unclamp (E)

//#Ducmv 20150825 SECS S6F11 GetWafer (S)
BOOL DlgSG300::GetWaferEvent(int port_no){
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("Get Wafer(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	BOOL r = TRUE;
	if((ret = m_hXComSecs.SndEvntInf("GetWaferEvent",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("Get Wafer(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}
//#Ducmv 20150825 S6F11 GetWafer(E)

//#Ducmv 20150825 SECS S6F11 Dock/Undock (S)
BOOL DlgSG300::UndockEvent(int port_no){
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("Undock(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	BOOL r = TRUE;
	if((ret = m_hXComSecs.SndEvntInf("UnDockEvent",0)) != 0){
		r = FALSE;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("Undock(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}

BOOL DlgSG300::DockEvent(int port_no){
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("Dock(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	BOOL r = TRUE;
	if((ret = m_hXComSecs.SndEvntInf("DockEvent",0)) != 0){		//
		r = FALSE;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("Dock(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}
//#Ducmv 20150825 SECS S6F11 Dock/Undock (E)

BOOL DlgSG300::ProcessStartEvent(){

	BOOL r = TRUE;
	long	ret;

	if((ret = m_hXComSecs.SndEvntInf("ProcessStartExecuting",0)) != 0){		//ProcessStartExecuting ���b�Z�[�W���M
		r = FALSE;
	}

	return r;
}


BOOL DlgSG300::StoppedTEvent(){
	BOOL r = TRUE;
	long	ret;
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("EquipmentStoppedT",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}
BOOL DlgSG300::StoppedBEvent(){
	BOOL r = TRUE;
	long	ret;
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("EquipmentStoppedB",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}

BOOL DlgSG300::ProcessCompleteEvent(){
	BOOL r = TRUE;
	long	ret;
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("ProcessProcessingComplete",0)) != 0){		//ProcessProcessingComplete ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}
BOOL DlgSG300::BottomDieFinishedEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eBottomPortNo].AllocSysString();
	// �A�N�Z�X�X�e�[�g�ύX
	if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*2*/eCompleted)) != 0){		//COMPLETED
		VariantClear(&vCarrierId);
		r = FALSE;
		return r;
	}
	VariantClear(&vCarrierId);
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("BottomDieProcessingComplete",0)) != 0){		//ProcessProcessingComplete ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}


BOOL DlgSG300::TopDieFinishedEvent(/*CString sCarrierId*/){
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eTopPortNo].AllocSysString();
	// �A�N�Z�X�X�e�[�g�ύX
	if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*2*/eCompleted)) != 0){		//COMPLETED
		VariantClear(&vCarrierId);
		r = FALSE;
		return r;
	}
	VariantClear(&vCarrierId);
	if((ret = m_hXComSecs.SndEvntInf("TopDieProcessingComplete",0)) != 0){		//TopDieProcessingComplete ���b�Z�[�W���M
		r = FALSE;
	}
	return r;
}

BOOL DlgSG300::TopDieForceFinishedEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	VARIANT vid_data;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eTopPortNo].AllocSysString();
	////////////////////////////////
	//
	// TopWafer��VID�̃Z�b�g
	//
	// �Ǖi�{���f�B���O���ꂽ�J�E���g
	VariantInit(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_PickedUpCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�{���f�B���O���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_PickedUpCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �Ǖi�X�L�b�v���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.UnBondCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_UnBondCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�X�L�b�v���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.UnBondCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_UnBondCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �Ǖi�c��̃J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickRemainCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_RemainingCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�c��̃J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickRemainCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_RemainingCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// Top���J�e�S���[
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Top�E�F�n�h�c(�s�b�N�A�b�v�^�C�~���O)
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferID1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �A�N�Z�X�X�e�[�g�ύX
	if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*2*/eCompleted)) != 0){		//COMPLETED
		VariantClear(&vCarrierId);
		r = FALSE;
		return r;
	}
	VariantClear(&vCarrierId);
	if((ret = m_hXComSecs.SndEvntInf("TopDieForceCompleteEvent",0)) != 0){		//TopDieProcessingComplete ���b�Z�[�W���M
		r = FALSE;
	}
	if(r){
		// ������CarrierUnload����B
		r = this->CarrierUnLoad(eTopPortNo);
		// TopWafer���́A�����������܂ł́A�b��ł�����ReadyToLoad�ɂ���B
		if(r){
			// ReadyToLoad �����s����B
			r = this->CarrierTakeOut(eTopPortNo);
		}
		if(r){
			// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
			if((!this->loadedByHost[eTopPortNo])&&(!this->loadedByHost[eBottomPortNo])){
				::Sleep(500);
				r = this->ProcessCompleteEvent();
			}
		}
	}
	return r;
}

BOOL DlgSG300::BottomDieUnloadEvent(){
	BOOL r = TRUE;
	VARIANT	vCarrierId;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eBottomPortNo].AllocSysString();
	// �A�N�Z�X�X�e�[�g�ύX�͕s�v
	if(r){
		// ������CarrierUnload����B
		r = this->CarrierUnLoad(eBottomPortNo);
		if(r){
			// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
			if((!this->loadedByHost[eTopPortNo])&&(!this->loadedByHost[eBottomPortNo])){
				::Sleep(500);
				r = this->ProcessCompleteEvent();
			}
		}
	}
	return r;
}

BOOL DlgSG300::TopDieUnloadEvent(){
	BOOL r = TRUE;
	VARIANT	vCarrierId;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eTopPortNo].AllocSysString();
	// �A�N�Z�X�X�e�[�g�ύX�͕s�v
	if(r){
		// ������CarrierUnload����B
		r = this->CarrierUnLoad(eTopPortNo);
		if(r){
			// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
			if((!this->loadedByHost[eTopPortNo])&&(!this->loadedByHost[eBottomPortNo])){
				::Sleep(500);
				r = this->ProcessCompleteEvent();
			}
		}
	}
	return r;
}


BOOL DlgSG300::WaferEndEvent(bool isTopSide){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	CString tmp;
	CSingleLock W(&WaferEndSema);
	W.Lock();
	////////////////////////////////
	//
	// ���ꂼ��̃Z�b�g
	//
	////////////
	// Top���J�e�S���[
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #DDT(150908) SECS S6F11,12 (S)
	////////////
	// TopWafer Bin Code
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topDieBin.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferBinVals",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// Top Wafer Bin Counts
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	tmp.Format("%d", this->CntD.PickCountG + this->CntD.PickRemainCountG + this->CntD.UnBondCountG);
	vid_data.bstrVal = tmp.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	if(isTopSide){
		////////////
		// SlotID (temporary)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();	// #DDT-TODO
		if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// WaferID (temporary)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();	// #DDT-TODO
		if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// Top�E�F�n�h�c(�s�b�N�A�b�v�^�C�~���O)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferID1",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// Top Wafer Pickup Bin Counts
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		tmp.Format("%d", this->CntD.PickCountG);
		vid_data.bstrVal = tmp.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferPickBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// Top Wafer Remain Bin Counts
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		tmp.Format("%d", this->CntD.PickRemainCountG);
		vid_data.bstrVal = tmp.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferRemainBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}

		// Top slot ID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_SlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
// #DDT(150908) SECS S6F11,12 (E)
		// �C�x���g�o��
		if((ret = m_hXComSecs.SndEvntInf("TopWaferEnd",0)) != 0){		// DiePick ���b�Z�[�W���M
			r = FALSE;
		}
#if !Release
		TRACE("SECS-Send S6F11-TopWaferEnd: r=%d\n", r);
#endif
	}else{
// #DDT(150908) SECS S6F11,12 (S)
		////////////
		// SlotID (temporary)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.slotID.AllocSysString();	// #DDT-TODO
		if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// WaferID (temporary)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();	// #DDT-TODO
		if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// Bottom slot ID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.slotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_SlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
// #DDT(150908) SECS S6F11,12 (E)
		////////////
		// Top�E�F�n�h�c(�v���[�X�^�C�~���O)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.topWaferID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferID2",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// �C�x���g�o��
		if((ret = m_hXComSecs.SndEvntInf("BottomWaferEnd",0)) != 0){		// DiePick ���b�Z�[�W���M
			r = FALSE;
		}
#if !Release
		TRACE("SECS-Send S6F11-BottomWaferEnd: r=%d\n", r);
#endif
	}
	W.Unlock();
	return r;
}

BOOL DlgSG300::WaferStartEvent(bool isTopSide){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	CString tmp;
	CSingleLock W(&WaferEndSema);
	W.Lock();
	// Top���J�e�S���[
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////////////////////////
	//
	// ���ꂼ��̃Z�b�g
	//
	////////////
	if(isTopSide){
// #DDT(150908) SECS S6F11,12 (S)
		////////////
		// SlotID (temporary)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();	// #DDT-TODO
		if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// WaferID (temporary)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();	// #DDT-TODO
		if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// Top Wafer Pickup Bin Counts
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		tmp.Format("%d", this->CntD.PickCountG);
		vid_data.bstrVal = tmp.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferPickBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// Top Wafer Remain Bin Counts
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		tmp.Format("%d", this->CntD.PickRemainCountG);
		vid_data.bstrVal = tmp.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferRemainBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
// #DDT(150908) SECS S6F11,12 (E)
		// �C�x���g�o��
		if((ret = m_hXComSecs.SndEvntInf("TopWaferStart",0)) != 0){		// DiePick ���b�Z�[�W���M
			r = FALSE;
		}
#if !Release
		TRACE("SECS-Send S6F11-TopWaferStart: r=%d\n", r);
#endif
	}else{
// #DDT(150908) SECS S6F11,12 (S)
		////////////
		// SlotID (temporary)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.slotID.AllocSysString();	// #DDT-TODO
		if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// WaferID (temporary)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();	// #DDT-TODO
		if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
// #DDT(150908) SECS S6F11,12 (E)
		// �C�x���g�o��
		if((ret = m_hXComSecs.SndEvntInf("BottomWaferStart",0)) != 0){		// DiePick ���b�Z�[�W���M
			r = FALSE;
		}
#if !Release
		TRACE("SECS-Send S6F11-BottomWaferStart: r=%d\n", r);
#endif
	}
	W.Unlock();
	return r;
}

BOOL DlgSG300::WaferPickUpEvent(void)
{
	BOOL r = TRUE;
	long ret;
	if((ret = m_hXComSecs.SndEvntInf("WaferPickUpEvent",0)) != 0){		// DiePick ���b�Z�[�W���M
		r = FALSE;
	}
	return r;
}

BOOL DlgSG300::PickupReportEvent(){

	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
//#Ducmv 20150825 SECS S6F11 (S)
	////////////
	// Top�E�F�n�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferID1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// TopDie�r���R�[�h
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topDieBin.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopBin1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Top�E�F�n�L�����A�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topWaferCarrierID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferCarrierID1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// pickup�^�C���X�^���v
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.pickupTime.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_PickupedTime1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �i�햼
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.recipeName.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_RecipeName",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// SlotID (temporary)
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();	// #DDT-TODO
	if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// WaferID (temporary)
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();	// #DDT-TODO
	if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_SlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topPortID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopPortIDForPickReport",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
//#Ducmv 20150825 SECS S6F11 (E)
	///////////////////////////
	// DiePick ���b�Z�[�W���M
	if((ret = m_hXComSecs.SndEvntInf("DiePick",0)) != 0){
		r = FALSE;
	}
#if !Release
	TRACE("SECS-Send S6F11-DiePick: r=%d\n", r);
#endif
	VariantClear(&vid_data);
	return r;
}

BOOL DlgSG300::BondingReportEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
// #DDT(150908): SECS S6F11,12 (S)
	////////////
	// Top�E�F�n�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferID2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// TopDie�r���R�[�h
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topDieBin.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopBin2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Bottom�E�F�n�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomWaferID",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Bottom�E�F�n�L�����A�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomWaferCarrierID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomWaferCarrierID",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// pickup�^�C���X�^���v
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.pickupTime.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_PickupedTime2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// place�^�C���X�^���v
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.placeTime.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_PlacedTime",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �i�햼
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.recipeName.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_RecipeName",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// BgSite
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bgSite.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BondingSite",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// pick_X��
	VariantInit(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.pick_x;
	if((ret = m_hXComSecs.SetVIDVal("_TOPDIEPOSITION_X2",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// pick_Y��
	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.pick_y;
	if((ret = m_hXComSecs.SetVIDVal("_TOPDIEPOSITION_Y2",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// place_X��
	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.place_x;
	if((ret = m_hXComSecs.SetVIDVal("_BOTTOMDIEPOSITION_X",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// place_Y��
	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.place_y;
	if((ret = m_hXComSecs.SetVIDVal("_BOTTOMDIEPOSITION_Y",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// SlotID (temporary)
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.slotID.AllocSysString();	// #DDT-TODO
	if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// WaferID (temporary)
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();	// #DDT-TODO
	if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// SlotID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.slotID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_SlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Top�E�F�n�L�����A�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topWaferCarrierID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferCarrierID2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// BottomDie�r���R�[�h
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomDieBin.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomBin",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// TopPortID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topPortID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopPortIDForPlaceReport",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	////////////
	// BotPortID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topPortID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomPortIDForPlaceReport",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// ��BgForce
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.actualBgForce;
	if((ret = m_hXComSecs.SetVIDVal("_BgForceForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// ��BgLevel
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.actualBgLevel;
	if((ret = m_hXComSecs.SetVIDVal("_BgLevelForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	
	////////////
	// Actual bonding heat
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.actualBgTemp;
	if((ret = m_hXComSecs.SetVIDVal("_BgTempForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
// #DDT(150908): SECS S6F11,12 (E)
	//#Ducmv 20150826 SECS (S)
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.bgManuOffsetX;
	if((ret = m_hXComSecs.SetVIDVal("_BgManuOffsetX",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.bgManuOffsetY;
	if((ret = m_hXComSecs.SetVIDVal("_BgManuOffsetY",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.bgManuOffsetT;
	if((ret = m_hXComSecs.SetVIDVal("_BgManuOffsetT",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.manuHostOffsetX;
	if((ret = m_hXComSecs.SetVIDVal("_BgManuByHostOffsetX",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.manuHostOffsetY;
	if((ret = m_hXComSecs.SetVIDVal("_BgManuByHostOffsetY",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.manuHostOffsetT;
	if((ret = m_hXComSecs.SetVIDVal("_BgManuByHostOffsetT",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.bgHeadPosX;
	if((ret = m_hXComSecs.SetVIDVal("_BgHeadPosX",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.bgHeadPosY;
	if((ret = m_hXComSecs.SetVIDVal("_BgHeadPosY",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantInit(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.dblVal = this->TraceBotD.bgHeadPosT;
	if((ret = m_hXComSecs.SetVIDVal("_BgHeadPosT",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
//#Ducmv 20150826 SECS (E)
	/////////////////////////
	//
	// �C�x���g���s
	//
	if((ret = m_hXComSecs.SndEvntInf("DiePlace",0)) != 0){		// DiePlace ���b�Z�[�W���M
		r = FALSE;
	}
#if !Release
	TRACE("SECS-Send S6F11-DiePlace: r=%d\n", r);
#endif
	VariantClear(&vid_data);
	return r;
}

// #TT150402-01(S)
// �E�F�n�}�b�v�A���C�����g�����C�x���g���M�@���M�ꏊ�m��
BOOL DlgSG300::WfMapAlingmentReportEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	////////////
	// VID�ݒ�
	////////////
	// IndexX
	VariantInit(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceMapAlignD.indexX;
	if((ret = m_hXComSecs.SetVIDVal("_TopWfMapAlignmentIndex_X1",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// IndexY
	VariantInit(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceMapAlignD.indexY;
	if((ret = m_hXComSecs.SetVIDVal("_TopWfMapAlignmentIndex_Y1",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// MatchingRatio
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceMapAlignD.matchingRatio;
	if((ret = m_hXComSecs.SetVIDVal("_TopWfMapAlignmentMatchingRatio",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �C�x���g���s
	////////////
	if((ret = m_hXComSecs.SndEvntInf("MapAlignmentEvent",0)) != 0){		// DiePlace ���b�Z�[�W���M
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}
// Dipping�����C�x���g���M�@���M�ꏊ�m��
BOOL DlgSG300::DippingReportEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	////////////
	// VID�ݒ�
	////////////
	// ��DippingLevel
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceDippingD.actualDippingLevel;
	if((ret = m_hXComSecs.SetVIDVal("_ActualDippingLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �ݒ�׏d
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceDippingD.settingDippingForce;
	if((ret = m_hXComSecs.SetVIDVal("_SettingDippingForce",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// ���׏d
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceDippingD.actualDippingForce;
	if((ret = m_hXComSecs.SetVIDVal("_ActualDippingForce",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �]�ʎ���
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceDippingD.settingDippingTime;
	if((ret = m_hXComSecs.SetVIDVal("_SettingDippingTime",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �i�햼
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceDippingD.recipeName.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_RecipeName",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �]�ʎ���
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceDippingD.dippedTime.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_DippedTime1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �C�x���g���s
	//
	if((ret = m_hXComSecs.SndEvntInf("DippingEvent",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}
// �����^�]�̃X�g�b�v�C�x���g���M
// #TT150402-01 �����^�]��~�C�x���g
BOOL DlgSG300::ProcessEndReportEvent()
{
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("ProcessEndExecuting",0)) != 0){		// ProcessEndExecuting ���b�Z�[�W���M
		r = FALSE;
	}
	return r;
}
// �i��f�[�^�ύX�C�x���g���M�@���M�ꏊ�m��
BOOL DlgSG300::PPRecipeSendReportEvent()
{
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("PPRecipeSend",0)) != 0){		// PPRecipeSend ���b�Z�[�W���M
		r = FALSE;
	}
	return r;
}
// �E�F�n�s�b�N�A�b�v�ς݊����C�x���g���M�i���ɂ���jPickupReportEvent()
// Bonding�����C�x���g���M�i���ɂ��肾���A�g���܂킹�邩�����K�v�j	BondingReportEvent()
// �P��I���C�x���g���M�i���ɂ��肾���A�g���܂킹�邩�����K�v�jpMCC->dlgSG300.WaferEndEvent(false);
// �����^�]�̃X�^�[�g�C�x���g���M�@���M�ꏊ�m�� �g�p����֐���ProcessStartEvent()

// #TT150402-01(E)


///////////////////////////////////////////////////////////////////
//
//
//
//
//	G e t M a p F i l e N a m e
//
//
//
//
BOOL DlgSG300::GetBottomFileMapName(CString SlotID, int slotNo,/* int isTopSide,*/ char *mID, int timeout){
#if !Release
				TRACE("GetBottomFileMapName = %s\n", SlotID);
#endif
	CSingleLock W(&S12F73Sema);
	W.Lock();
	BOOL r = TRUE;
	//�A�C�e���ɃZ�b�g
	PutSecsItem4ByteInteger("V1", SlotID.GetLength(), 0, 0);
	PutSecsItemSingleASCII("Itm_SLOTID",SlotID);
	// �E�F�n�h�c�̎擾
	// �E�F�n�h�c�̓R���e���g�}�b�v����擾
	CString portID = "1";
	this->PutSecsItem4ByteInteger("V2", portID.GetLength(), 0, 0);
	this->PutSecsItemSingleASCII("Itm_PortIDAscii",portID);
	CString waferID = waferIdOfContentMap[slotNo-1];
	this->PutSecsItem4ByteInteger("V3", waferID.GetLength(), 0, 0);
	this->PutSecsItemSingleASCII("Itm_WaferID",waferID);
	//S12F73���M
	m_hXComSecs.PutSecsEvent("_GS12F73S");
#if !Release
	TRACE("SECS-Send S12F73-BottomMapFile: \n");
#endif
	//S12F74�҂�
	this->pEvFinInfoFileMapName		= &EvFinFileMapName;
	this->pEvFailInfoFileMapName	= &EvFailFileMapName;
	enum{
		WaitCnt		= 3,
	};
	EvFinFileMapName.ResetEvent();
	EvFailFileMapName.ResetEvent();
	// �}���`���b�N�҂�
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinInfoFileMapName;
	ppObjects[1]	= pEvFailInfoFileMapName;
	ppObjects[2]	= pEvStopWaitingSecsB;		// ���f
	CMultiLock	M(ppObjects,WaitCnt);
	// 
	if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
		// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
		// �ŏI�I�ɂ�ItemGet��T3�^�C���A�E�g���Z�b�g����
		int i = M.Lock(timeout+1000, FALSE);
		M.Unlock();
		if(i == WAIT_TIMEOUT){
			// T3�^�C���A�E�g
			r = FALSE;
		}else{
			i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == i) {
				//����
				r = TRUE;
			} else if (1 == i) {
				//���s
				r = FALSE;
			} else if (2 == i) {
				//�r����~(���f)
				r = FALSE;
			}
		}
	}
	this->pEvFinInfoFileMapName = NULL;
	this->pEvFailInfoFileMapName = NULL;
	if(r){
		strcpy(mID, GetItemDataSingleASCII("Itm_MAPFILENAME"));
	}
#if !Release
	//TRACE("GetBottomFileMapName = End\n");
	TRACE("SECS-Send S12F73-BottomMapFile: %s\n", CString(mID));
#endif
	W.Unlock();
	return r;
}

BOOL DlgSG300::GetTopFileMapName(CString SlotID, char *mID, int timeout){

#if !Release
				TRACE("GetTopFileMapName = %s\n", SlotID);
#endif
	CSingleLock W(&S12F73Sema);
	W.Lock();
	BOOL r = TRUE;
	//�A�C�e���ɃZ�b�g
///	PutSecsItemSingleLong("V1", (long)SlotID.GetLength());
	this->PutSecsItem4ByteInteger("V1", SlotID.GetLength(), 0, 0);
	PutSecsItemSingleASCII("Itm_SLOTID",SlotID);
	// �|�[�g�h�c = 2 �ƂƂ肠������`����B
	CString portID = "2";
///	this->PutSecsItemSingleLong("V2", (long)portID.GetLength());
	this->PutSecsItem4ByteInteger("V2", portID.GetLength(), 0, 0);
	this->PutSecsItemSingleASCII("Itm_PortIDAscii",portID);
	// �E�F�n�h�c�̎擾
	CString waferID;
	waferID.Format("%s", mID);
///	this->PutSecsItemSingleLong("V3", (long)waferID.GetLength());
	this->PutSecsItem4ByteInteger("V3", waferID.GetLength(), 0, 0);
	this->PutSecsItemSingleASCII("Itm_WaferID",waferID);
	//S12F73���M
	m_hXComSecs.PutSecsEvent("_GS12F73S");
#if !Release
	TRACE("SECS-Send S12F73-TopMapFile\n");
#endif
	//S12F74�҂�
	this->pEvFinInfoFileMapName		= &EvFinFileMapName;
	this->pEvFailInfoFileMapName	= &EvFailFileMapName;
	enum{
		WaitCnt		= 3,
	};
	EvFinFileMapName.ResetEvent();
	EvFailFileMapName.ResetEvent();
	// �}���`���b�N�҂�
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinInfoFileMapName;
	ppObjects[1]	= pEvFailInfoFileMapName;
	ppObjects[2]	= pEvStopWaitingSecsT;		// ���f
	CMultiLock	M(ppObjects,WaitCnt);
	//
	if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
		// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
		// �ŏI�I�ɂ�ItemGet��T3�^�C���A�E�g���Z�b�g����
		int i = M.Lock(timeout+1000, FALSE);
		M.Unlock();
		if(i == WAIT_TIMEOUT){
			// T3�^�C���A�E�g
			r = FALSE;
		}else{
			i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == i) {
				//����
				r = TRUE;
			} else if (1 == i) {
				//���s
				r = FALSE;
			} else if (2 == i) {
				//�r����~(���f)
				r = FALSE;
			}
		}
	}
	this->pEvFinInfoFileMapName = NULL;
	this->pEvFailInfoFileMapName = NULL;
	if(r){
		strcpy(mID, GetItemDataSingleASCII("Itm_MAPFILENAME"));
	}
#if !Release
	//TRACE("GetTopFileMapName = End\n");
	TRACE("SECS-Send S12F73-TopMapFile: %s\n", CString(mID));
#endif
	W.Unlock();
	return r;
}
//#Ducmv 20150821 SECS S12F75/76 (S)
BOOL DlgSG300::GetCSVFileName(CString SlotID, int slotNo,/* int isTopSide,*/ char *mID, int timeout){
	BOOL r = TRUE;
	//�A�C�e���ɃZ�b�g
	PutSecsItem4ByteInteger("V1", SlotID.GetLength(), 0, 0);
	PutSecsItemSingleASCII("Itm_SLOTID",SlotID);
	//S12F75
	m_hXComSecs.PutSecsEvent("_GS12F75S");
#if !Release
	TRACE("SECS-Send S12F75-GetCSVFileName\n");
#endif
	//S12F76�҂�
	this->pEvFinCSVFileName		= &EvFinCSVFileName;
	this->pEvFailCSVFileName	= &EvFailCSVFileName;
	enum{
		WaitCnt		= 3,
	};
	EvFinCSVFileName.ResetEvent();
	EvFailCSVFileName.ResetEvent();
	// �}���`���b�N�҂�
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinCSVFileName;
	ppObjects[1]	= pEvFailCSVFileName;
	ppObjects[2]	= pEvStopWaitingSecsB;		// ���f
	CMultiLock	M(ppObjects,WaitCnt);
	// 
	if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
		// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
		// �ŏI�I�ɂ�ItemGet��T3�^�C���A�E�g���Z�b�g����
		int i = M.Lock(timeout+1000, FALSE);
		M.Unlock();
		if(i == WAIT_TIMEOUT){
			// T3�^�C���A�E�g
			r = FALSE;
		}else{
			i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == i) {
				//����
				r = TRUE;
			} else if (1 == i) {
				//���s
				r = FALSE;
			} else if (2 == i) {
				//�r����~(���f)
				r = FALSE;
			}
		}
	}
	this->pEvFinCSVFileName = NULL;
	this->pEvFailCSVFileName = NULL;
	if(r){
		strcpy(mID, GetItemDataSingleASCII("Itm_OFFSETFILENAME"));
	}
#if !Release
	TRACE("SECS-Send S12F75-GetCSVFileName: %s\n", CString(mID));
#endif

	return r;
}
//#Ducmv 20150821 SECS S12F75/76 (E)

// #KS20130415-01 [�ǉ�]SECS�E�F�n�}�b�s���O
//�}�b�v���擾  add 130118_Misato
//S12F3

BOOL DlgSG300::MapSetupDataRequest(MapData *pMapD)
{
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (pSecsTDS) {
//			r = pSecsTDS->MapSetupDataRequest(pMapD);
//		}
//		return(r);
///	}

//	MapCtrl.EvReqMapOK.SetEvent();

// #KS20130417-01(E)
	BOOL r = TRUE;
	//
	if (this->getCtrlState() <= eHostOffline) {	// �ʐM���؂�Ă���
		this->MapCtrl.bReqMap = FALSE;
		return(FALSE);
	}
	if (pMapD) {	// �J�n
		if (this->MapCtrl.bReqMap) {
			//r = FALSE;
		}
		this->MapCtrl.pMapData = pMapD;
		this->MapCtrl.EvReqMapOK.ResetEvent();
		this->MapCtrl.EvReqMapEnd.ResetEvent();
		this->MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_Nothing;
		this->MapCtrl.bReqMap = true;
		if (r) r = SendS12F3();
		if (r) {
			CSingleLock L(&this->MapCtrl.EvReqMapOK, TRUE);	// S12F04�̌���
			if (this->MapCtrl.iReqMapErr) {
				r = FALSE;
			}
		}
		if (!r) {
			this->MapCtrl.bReqMap = false;
		}
	} else {	// �Q���
		if (!this->MapCtrl.bReqMap) {	// ���s���łȂ�
			r = FALSE;
		} else {
			CSingleLock L(&this->MapCtrl.EvReqMapEnd, TRUE);	// S12F16�̌���
			if (this->MapCtrl.iReqMapErr) {
				r = FALSE;
			}
			this->MapCtrl.bReqMap = false;
		}
	}
	return(r);
}

BOOL DlgSG300::SendS12F3()
{
	BOOL r = TRUE;
	this->PutSecsItemSingleUnsignInt("SendStrLen_4", MapCtrl.pMapData->MID.GetLength(), "U4");	//MID
	this->PutSecsItemSingleASCII("Item_MID", MapCtrl.pMapData->MID);
	this->PutSecsItemSingleBIN("Item_IDTYP", 0);												//IDTYP
	this->PutSecsItemSingleBIN("Item_MAPFT", 1);												//MAPFT
	this->PutSecsItemSingleUnsignInt("Item_FNLOC", MapCtrl.pMapData->FNLOC, "U2");				//FNLOC
	this->PutSecsItemSingleUnsignInt("Item_FFROT", 0, "U2");									//FFROT
	this->PutSecsItemSingleBIN("Item_ORLOC", 2);												//ORLOC
	this->PutSecsItemSingleBIN("Item_PRAXI", 0);												//PRAXI
	this->PutSecsItemSingleUnsignInt("SendStrLen_2", MapCtrl.pMapData->BCEQU.GetLength(), "U4");
	this->PutSecsItemSingleASCII("Item_BCEQU", MapCtrl.pMapData->BCEQU);
	this->PutSecsItemSingleUnsignInt("SendStrLen_3", MapCtrl.pMapData->NULBC.GetLength(), "U4");
	this->PutSecsItemSingleASCII("Item_NULBC", MapCtrl.pMapData->NULBC);
	if (m_hXComSecs.PutSecsEvent("_GS12F03S") != 0) {
		r = FALSE;
	}
	return(r);
}

//S12F4��M(Map Set-up Data)
BOOL DlgSG300::RecvS12F4()
{
	BOOL r = TRUE;
	int nByte = 0;
	if (!MapCtrl.bReqMap) {
		return(r);
	}
	//
	CString recv_mid = this->GetItemDataSingleASCII("Item_MID");
	unsigned int recv_idtyp = this->GetItemDataSingleUnsignInt("Item_IDTYP", "U1");
	int fnloc = this->GetItemDataSingleUnsignInt("Item_FNLOC", "U2");
	int orloc = this->GetItemDataSingleUnsignInt("Item_ORLOC", "U1");

	MapCtrl.pMapData->ROWCT = this->GetItemDataSingleUnsignInt("Item_ROWCT", "U2");
	MapCtrl.pMapData->COLCT = this->GetItemDataSingleUnsignInt("Item_COLCT", "U2");
	MapCtrl.pMapData->BCEQU = this->GetItemDataSingleASCII("Item_BCEQU");
	MapCtrl.pMapData->NULBC = this->GetItemDataSingleASCII("Item_NULBC");

	MapCtrl.pMapData->RPSEL = this->GetItemDataSingleUnsignInt("Item_RPSEL", "U1");

	if(MapCtrl.pMapData->RPSEL == 0)
	{
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}

	//�f�[�^�`�F�b�N
	if (0 != recv_mid.Compare(MapCtrl.pMapData->MID)) {
		nByte = 1;  
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if(recv_idtyp != 0){
		nByte = sizeof(recv_mid)  + 1;
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if(orloc != 2){
		nByte = sizeof(recv_mid) + sizeof(recv_idtyp) + sizeof(fnloc) + 1; 
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if (fnloc != MapCtrl.pMapData->FNLOC) {
		nByte = sizeof(recv_mid) + sizeof(recv_idtyp) + 1; 
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}

	//�ʐM�װ���A�װ��ʕ\��(S)
	if(r == FALSE){
		MapCtrl.bReqMap = FALSE;
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	}
	MapCtrl.EvReqMapOK.SetEvent();
	return(r);
}

// ϯ���ް��v��
BOOL DlgSG300::SendS12F15()
{
	BOOL r = TRUE;
	if (!MapCtrl.bReqMap) {
		return(r);
	}
	if (m_hXComSecs.PutSecsEvent("_GS12F15S") != 0) {
		r = FALSE;
		if (MapCtrl.bReqMap) {
			MapCtrl.bReqMap = FALSE;
			MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_Send;
			MapCtrl.EvReqMapEnd.SetEvent();
		}
	}
	return(r);
}

BOOL DlgSG300::RecvS12F16()
{
	BOOL r = TRUE;
	int nByte = 0;
	if (!MapCtrl.bReqMap) {
		return(r);
	}
	CString recv_mid = this->GetItemDataSingleASCII("Item_MID");
	unsigned int recv_idtyp = this->GetItemDataSingleUnsignInt("Item_IDTYP", "U1");
	
	//�f�[�^�`�F�b�N
	if (0 != recv_mid.Compare(MapCtrl.pMapData->MID)) {
		nByte = 1;  
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if(recv_idtyp != 0){
		nByte = sizeof(recv_mid) + 1;
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if(r == FALSE){
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	} else {
		MapCtrl.pMapData->BINLT = this->GetItemDataSingleASCII("Item_BINLT");
		int nSize = MapCtrl.pMapData->ROWCT * MapCtrl.pMapData->COLCT;
		int nLen = MapCtrl.pMapData->BINLT.GetLength();
		if( nSize != nLen ){
			nByte = sizeof(recv_mid)  + sizeof(recv_idtyp) + sizeof(MapCtrl.pMapData->STRPX) + sizeof(MapCtrl.pMapData->STRPY) + 1;
			SendS12F19(0, (BYTE)nByte);
			r = FALSE;
		}
		else{
			// #TT141113-02
			// Host���}�b�v�f�[�^����M�������_�ŁA�Ȃ����}�b�v����]�����Ă���B
			// ���j���킩��Ȃ������l�T�X����ɂ��̕����w�E����A�폜�B
			// �d�l�ł�Host����M�����}�b�v�f�[�^�����̂܂�WMV�ŕ\�������邱�ƂƂȂ��Ă���
///			MapCtrl.pMapData->BINLT.MakeReverse();
		}
	}
	MapCtrl.EvReqMapEnd.SetEvent();
	return(r);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// #MO20131129
//ϯ�ߏ��m�F
//S12F1

//BOOL DlgSG300::MapSetupDataSend(CString read_mid)
BOOL DlgSG300::MapSetupDataSend(MapData *pMapD)
{
	BOOL r = TRUE;

	//S12F1 Map Set-up Data Send
	this->PutSecsItemSingleUnsignInt("SendStrLen_4", MapCtrl.pMapData->MID.GetLength(), "U4");	//MID
	this->PutSecsItemSingleASCII("Item_MID", MapCtrl.pMapData->MID);
	this->PutSecsItemSingleBIN("Item_IDTYP", 0);												//IDTYP
	this->PutSecsItemSingleUnsignInt("Item_FNLOC", MapCtrl.pMapData->FNLOC, "U2");				//FNLOC
	this->PutSecsItemSingleUnsignInt("Item_FFROT", 0, "U2");									//FFROT
	this->PutSecsItemSingleBIN("Item_ORLOC", 2);												//ORLOC
	this->PutSecsItemSingleUnsignInt("Item_RPSEL", 1, "U1");									
	this->PutSecsItemSingleUnsignInt("SendStrLen_5", MapCtrl.pMapData->DUTMS.GetLength(), "U4");
	this->PutSecsItemSingleASCII("Item_DUTMS", MapCtrl.pMapData->DUTMS);											//Misato
	this->PutSecsItem8ByteFloating("Item_XDIES", MapCtrl.pMapData->XDIES, 0, 0);
	this->PutSecsItem8ByteFloating("Item_YDIES", MapCtrl.pMapData->YDIES, 0, 0);
	this->PutSecsItemSingleUnsignInt("Item_ROWCT", MapCtrl.pMapData->ROWCT, "U2");
	this->PutSecsItemSingleUnsignInt("Item_COLCT", MapCtrl.pMapData->COLCT, "U2");
//	this->PutSecsItemSingleUnsignInt("SendStrLen_2", MapCtrl.pMapData->BCEQU.GetLength(), "U4");
//	this->PutSecsItemSingleASCII("Item_BCEQU", MapCtrl.pMapData->BCEQU);
	this->PutSecsItemSingleUnsignInt("SendStrLen_3", MapCtrl.pMapData->NULBC.GetLength(), "U4");
	this->PutSecsItemSingleASCII("Item_NULBC", MapCtrl.pMapData->NULBC);
	this->PutSecsItemSingleUnsignInt("Item_PRDCT", MapCtrl.pMapData->PRDCT, "U2");								
	this->PutSecsItemSingleBIN("Item_PRAXI", 0);												//PRAXI
	//S12F2,S12F6,S12F10�҂�
	this->pEvS12F2Recv = &EvS12F2Recv;
	this->pEvS12F6Recv = &EvS12F6Recv;
	this->pEvS12F10Recv = &EvS12F10Recv;
	EvS12F2Recv.ResetEvent();
	EvS12F6Recv.ResetEvent();
	EvS12F10Recv.ResetEvent();
	//���M
	if(m_hXComSecs.PutSecsEvent("_GS12F01S") != 0){
		r = FALSE;
	}
	enum{
		WaitCnt =3,
	};
	//�}���`���b�N�҂�
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvS12F2Recv;
	ppObjects[1]	= pEvS12F6Recv;
	ppObjects[2]	= pEvS12F10Recv;
	CMultiLock	M(ppObjects,WaitCnt);
	//
	int timeout = 20000;
	while(r){
		if(this->getCtrlState() > eHostOffline){		//Online Remote �̂Ƃ��̂ݑ҂�
			// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
			// �ŏI�I�ɂ�ItemGet��T3�^�C���A�E�g���Z�b�g����
			int i = M.Lock(timeout+1000, FALSE);
			M.Unlock();
			if(i == WAIT_TIMEOUT){
				// T3�^�C���A�E�g
				r = FALSE;
				break;
			}else{
				i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
				if (0 == i) {
					//����
					r = TRUE;
					continue;
				} else if (1 == i) {
					//����
					r = TRUE;
					continue;
				} else if (2 == i) {
					//����
					r = TRUE;
					break;
				} else if (3 == i) {
					//�r����~(���f)
					r = FALSE;
					break;
				}else{
					r = FALSE;
					break;
				}
			}
		}
	}
	return(r);
}

//S12F2��M(Map Set-up Data)
BOOL DlgSG300::RecvS12F2()
{
	BOOL r = TRUE;

	unsigned int recv_sdack = this->GetItemDataSingleUnsignInt("Item_SDACK", "U1");

	//�f�[�^�`�F�b�N
	if(recv_sdack != 0){
		r = FALSE;
	}
	
	//�ʐM�װ���A�װ��ʕ\��(S)
	if(r == FALSE){
		MapCtrl.bReqMap = FALSE;
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	}
	if(r == TRUE){
		//S12F5 ���M
		this->PutSecsItemSingleUnsignInt("SendStrLen_4", MapCtrl.pMapData->MID.GetLength(), "U4");	//MID
		this->PutSecsItemSingleASCII("Item_MID", MapCtrl.pMapData->MID);
		this->PutSecsItemSingleBIN("Item_IDTYP", 0);												//IDTYP
		this->PutSecsItemSingleBIN("Item_MAPFT", 1);												//MAPFT

		if(m_hXComSecs.PutSecsEvent("_GS12F05S") != 0){
			r = FALSE;
			if (MapCtrl.bReqMap) {
			MapCtrl.bReqMap = FALSE;
			MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_Send;
			MapCtrl.EvReqMapEnd.SetEvent();
			}
		}else{
		pEvS12F2Recv->SetEvent();
		}
	}
	return(r);
}

BOOL DlgSG300::SendS12F5()
{
	BOOL r = TRUE;
	return(r);
}

BOOL DlgSG300::RecvS12F6()
{
	BOOL r = TRUE;

	unsigned int recv_grnt1 = this->GetItemDataSingleUnsignInt("Item_GRNT1", "U1");

	//�f�[�^�`�F�b�N
	if(recv_grnt1 != 0){
		r = FALSE;
	}
	if(r == FALSE){
		MapCtrl.bReqMap = FALSE;
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	}
	if(r == TRUE){
	//S12F9 Map Data Send Type2
		this->PutSecsItemSingleUnsignInt("SendStrLen_4", MapCtrl.pMapData->MID.GetLength(), "U4");		//MID
		this->PutSecsItemSingleASCII("Item_MID", MapCtrl.pMapData->MID);
		this->PutSecsItemSingleBIN("Item_IDTYP", 0);													//IDTYP
		this->PutSecsItemSingleUnsignInt("SendStrLen_5", MapCtrl.pMapData->BINLT.GetLength(), "U4");	//BINLT
		this->PutSecsItemSingleASCII("Item_BINLT", MapCtrl.pMapData->BINLT);
		//���M
		if(m_hXComSecs.PutSecsEvent("_GS12F09S") != 0){
			r = FALSE;
			if (MapCtrl.bReqMap) {
			MapCtrl.bReqMap = FALSE;
			MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_Send;
			MapCtrl.EvReqMapEnd.SetEvent();
			}
		}else{
		pEvS12F6Recv->SetEvent();
		}
	}
	MapCtrl.EvReqMapEnd.SetEvent();
	return(r);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ϯ���ް��m�F ����2
//S12F9
BOOL DlgSG300::SendS12F9()
{
	BOOL r = TRUE;
	return(r);
}

//S12F10��M(Map Data)
BOOL DlgSG300::RecvS12F10()
{
	BOOL r = TRUE;
	unsigned int recv_mdack = this->GetItemDataSingleUnsignInt("Item_MDACK", "U1");

	//�f�[�^�`�F�b�N
	if(recv_mdack != 0){
		r = FALSE;
	}
	
	//�ʐM�װ���A�װ��ʕ\��(S)
	if(r == FALSE){
		MapCtrl.bReqMap = FALSE;
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	}
	return(r);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// #MO20131130 [�ǉ�]SECSϯ��ݸ�
// S12F19 ϯ�ߴװ��M
BOOL DlgSG300::RecvS12F19()
{
	BOOL r = TRUE;
	return(r);
}

// S12F19 ϯ�ߴװ���M
BOOL DlgSG300::SendS12F19(int maper, BYTE datlc)
{
	BOOL r = TRUE;

	this->PutSecsItemSingleBIN("Item_MAPER", maper);
	this->PutSecsItemSingleUnsignInt("Item_DATLC", datlc, "U1");
	if (m_hXComSecs.PutSecsEvent("_GS12F19S") != 0) {
		r = FALSE;
	}
	return(r);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ϯ�߃`�b�v�ړ����M
//S6F81

BOOL DlgSG300::MapChipMoveSend(int cx, int cy)
{
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (pSecsTDS) {
//			r = pSecsTDS->MapChipMoveSend(cx, cy);
//		}
//		return(r);
//	}
// #KS20130417-01(E)
	BOOL r = TRUE;
	this->PutSecsItem4ByteInteger("Item_MOVEXY", cx, 1, 0);
	this->PutSecsItem4ByteInteger("Item_MOVEXY", cy, 2, 0);
	
	//���M
	if(m_hXComSecs.PutSecsEvent("_GS06F81S") != 0){
		;
//		MapSendMessage(3);		//NG
	}
	return(r);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ϯ�������߯��@���M
//S6F83

BOOL DlgSG300::MapChipPicked(int cx, int cy, unsigned char code)
{
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (pSecsTDS) {
//			r = pSecsTDS->MapChipPicked(cx, cy, code);
//		}
//		return(r);
//	}
// #KS20130417-01(E)
	BOOL r = TRUE;
	this->PutSecsItem4ByteInteger("Item_PICKXY", cx, 1, 0);
	this->PutSecsItem4ByteInteger("Item_PICKXY", cy, 2, 0);
	this->PutSecsItemSingleASCII("Item_BIN", code);

	//���M
	if(m_hXComSecs.PutSecsEvent("_GS06F83S") != 0){
		;
//		MapSendMessage(3);		//NG
	}
	return(r);
}
// #KS20130415-01(E)

// #DDT(150908): SECS S6F11,12 (S)

BOOL DlgSG300::ReadSlotMapEvent() 
{
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("SlotMapEvent",0)) != 0){
		r = FALSE;
	}
	return r;
}

BOOL DlgSG300::SendS06F11(int type, int port)
{
	BOOL r = TRUE;
	switch (type) {
	case eFoupClamp:
		r = ClampEvent(port);
		break;
	case eFoupUnclamp:
		r = UnclampEvent(port);
		break;
	case eRFIDRead:
		r = ReadRFIDEvent();
		break;
	case eFoupDock:
		r = DockEvent(port);
		break;
	case eFoupUndock:
		r = UndockEvent(port);
		break;
	case eSlotMapRead:
		r = ReadSlotMapEvent();
		break;
	case eGetWafer:
		r = GetWaferEvent(port);
		break;
	default:
		r = FALSE;
		break;
	}
#if !Release
	TRACE("SECS-Send S6F11: type=%d, port=%d, r=%d\n", type, port, r);
#endif
	return r;
}
// #DDT(150908): SECS S6F11,12 (E)

// #DDT(150908): SECS S2F41 (S)
int DlgSG300::WaitRecipeFromHost()
{
	int r = 99999;
	//
	enum{
		ObjectMax = 2,
	};
	this->HostCommandStatus	= eNotReceived;
//	this->isWaitingForPPID = true;
	CSyncObject *ppObjects[ObjectMax];
	ppObjects[0]	= pEvPPSelectReq;		// �����̃X���b�h�ő҂��Ă���\�����邪�A�������̏���
	ppObjects[1]	= pEvStopWaitingSecsB;	// ���f
	CMultiLock M(ppObjects, ObjectMax);		// �����~or�v���҂��錾
	int i = M.Lock(INFINITE, FALSE);		// �����I�u�W�F�N�g�̔z���҂����킹(FALSE:1�ȏ�̓����I�u�W�F�N�g���V�O�i����ԂƂȂ�Ƃ����ɕ��A)
	M.Unlock();								// ���L���铯���I�u�W�F�N�g�����
	i -= WAIT_OBJECT_0;						// ����ُ�ԂɂȂ�����޼ު��No.
	//
#if !Release
	TRACE("RecipeFromHost(S2F41) = %d\n", i);
#endif
	if (0 == i){		// PPSelect�������B
		this->HostCommandStatus	= eGetPPSelect;
		r = TRUE;
	} else if (1 == i){	// ���f�������B
		this->HostCommandStatus	= eNotReceived;
		r = FALSE;
	}
//	this->isWaitingForPPID = false;
	return r;
}
// #DDT(150908): SECS S2F41 (E)
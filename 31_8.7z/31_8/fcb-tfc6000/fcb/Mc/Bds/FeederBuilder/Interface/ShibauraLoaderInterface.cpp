// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ� (S)
// ShibauraLoaderInterface.cpp
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include "ShibauraLoaderInterface.h"
//#include "CommonDef.h"

//=====================================================
// Shibaura Loader interface 
//=====================================================

CSMLoaderIF::CSMLoaderIF()
{

}

CSMLoaderIF::~CSMLoaderIF()
{

}
CSMLoaderIF::CSMLoaderIF(
			CString name,				// Class name
			OrdinaryOutTBL* pPermit,	// 
			OrdinarySnsTBL* pReply,		// 
			OrdinaryOutTBL* pRequest,	// 
			OrdinarySnsTBL* pExecuting,	// 
			OrdinarySnsTBL* pBdExist,	// 
			CEventX* pEvStop,			// Stop event
			CEventX* pEvRequestLoad,	// Stop event
			CEventX* pEvLoadOK,		// Stop event
			CEventX* pEvLoadNG,		// Stop event
			CEventX* pEvloadStop,		// Stop event
			int errId,					// Error ID
			int myErrStart				// Error start
			): UpStreamIF(name, pPermit, pReply, pRequest, pExecuting, pEvStop, errId, myErrStart)
{
	this->pEvStopWaiting	= pEvStop;
	this->pEvRequestLoad	= pEvRequestLoad;
	this->pEvLoadOK			= pEvLoadOK;
	this->pEvLoadNG			= pEvLoadNG;
	this->pEvLoadStop		= pEvloadStop;

	this->pEvStopWaiting->ResetEvent();
	this->pEvRequestLoad->ResetEvent();
	this->pEvLoadOK->ResetEvent();
	this->pEvLoadNG->ResetEvent();
	this->pEvLoadStop->ResetEvent();
}

BOOL CSMLoaderIF::Request2() {
	return TRUE;
}
BOOL CSMLoaderIF::WaitExecute() {
	return TRUE;
}

BOOL CSMLoaderIF::Wait(){
	return TRUE;
}

BOOL CSMLoaderIF::SendPermit() {
	return TRUE;
}

BOOL CSMLoaderIF::RequestAndWaitAll()
{
	BOOL r = TRUE;

	// Reset reply event
	pEvLoadOK->ResetEvent();
	pEvLoadNG->ResetEvent();

	// Set request event
	pEvRequestLoad->SetEvent();
//	FCB_LOG("                                   [BDS]%s::Request AndWaitAll()Set pEvRequestLoad event: \n", this->name);

	enum{
		WaitCnt		= /*3*/2,		// yk130503
	};

	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvLoadOK;		// Request reply OK
	ppObjects[1]	= pEvLoadNG;		// Request reply NG
//	ppObjects[2]	= pEvStopWaiting;	// Request reply NG

	/*
	StopWatch	SW(this->delayTime);			// ��ѱ�Ď���
	SW.Start();
	int t;
	
	for (;r;) {
		int	i = M.Lock(100,FALSE);
		M.Unlock();
		t = SW.Read();
		if ((this->delayTime != 0)&&(t == 0)) {	// ��ѱ��
			this->err.PutError(Err_RequestTimeOut);
			r = FALSE;
		break;
	} else {

*/


	// Wait for reply event
	CMultiLock	M(ppObjects,WaitCnt);
	int i = M.Lock(INFINITE, FALSE);
	M.Unlock();

	i -= WAIT_OBJECT_0;		// If recieve any reply event
//	FCB_LOG("                                   [BDS]%s::Request AndWaitAll()Get request number<i=%d>\n", this->name, i);

	if (0 == i) {			// Recieve OK event
		r = TRUE;
	} else if (1 == i) {	// Recieve NG event
		r = FALSE;
	} else if (2 == i) {
		r = FALSE;
		pEvStopWaiting->ResetEvent();
		//TODO: Send stop event to loader magazine
	}
	return r;
}

void CSMLoaderIF::SetAutoEvent(CEventX* pEvRequest, CEventX* pEvOK, CEventX* pEvNG, CEventX* pEvLoadStop)
{
	this->pEvRequestLoad = pEvRequest;
	this->pEvLoadOK		 = pEvOK;
	this->pEvLoadNG		 = pEvNG;
	this->pEvLoadStop	 = pEvLoadStop;	
}


//============================================================
// Unloader interface
//============================================================
CSMUnloaderIF::CSMUnloaderIF()
{

}

CSMUnloaderIF::~CSMUnloaderIF()
{

}
CSMUnloaderIF::CSMUnloaderIF(
			CString name,					// Class name
			OrdinarySnsTBL* pWaitRequest,
			OrdinaryOutTBL* pExecuting,
			OrdinaryOutTBL* pPermit,
			OrdinarySnsTBL* pReply,
			CEventX* pEvStop,				// Stop event
			CEventX* pEvRequestUnLoad,		// Load request event
			CEventX* pEvUnLoadOK,			// Load OK report event
			CEventX* pEvUnLoadNG,			// Load NG report event
			CEventX* pEvUnLoadStop,			// Load stop event
			int errId,						// Error/ class ID
			int myErrStart					// Error start
			):DwnStreamIF(name, pWaitRequest, pExecuting, pPermit, pReply, pEvStop, errId, myErrStart)
{
	this->pEvStopWaiting		= pEvStop;
	this->pEvRequestUnLoad		= pEvRequestUnLoad;
	this->pEvUnLoadOK			= pEvUnLoadOK;
	this->pEvUnLoadNG			= pEvUnLoadNG;	
	this->pEvUnloadStop			= pEvUnLoadStop;

	this->pEvStopWaiting->ResetEvent();
	this->pEvRequestUnLoad->ResetEvent();
	this->pEvUnLoadOK->ResetEvent();
	this->pEvUnLoadNG->ResetEvent();	
	this->pEvUnloadStop->ResetEvent();
}

/////////////////////////////////////////////
// Wait and request to unload
//
BOOL CSMUnloaderIF::WaitRequest2(bool doExe) 
{
	BOOL r = TRUE;

	// Reset reply event
	pEvUnLoadOK->ResetEvent();
	pEvUnLoadNG->ResetEvent();

	// Set request event
	pEvRequestUnLoad->SetEvent();

	enum{
		WaitCnt		= 2,
	};

	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvUnLoadOK;		// Request reply OK
	ppObjects[1]	= pEvUnLoadNG;		// Request reply NG

	// Wait for reply event
	CMultiLock	M(ppObjects,WaitCnt);
	int i = M.Lock(INFINITE, FALSE);
	M.Unlock();

	i -= WAIT_OBJECT_0;		// If recieve any reply event
	if (0 == i) {			// Recieve OK event
		r = TRUE;
	} else if (1 == i) {	// Recieve NG event
		r = FALSE;
	}
	return r;
}

#if 0
void CSMUnloaderIF::SetAutoEvent(CEventX* pEvRequest, CEventX* pEvOK, CEventX* pEvNG, CEventX* pEvUnloadStop)
{	
	
	this->pEvRequestUnLoad = pEvRequest;
	this->pEvUnLoadOK		= pEvOK;
	this->pEvUnLoadNG		= pEvNG;
	this->pEvUnloadStop		= pEvUnloadStop;
	
}
#endif
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ� (E)

/*---------------------------------------------------------------------
	Base class for SM loader and unloader
								2013 HangNT / TSDV
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include <mcc.h>
#include "LoaderUnloader.h"
#include "CommonDef.h"

//==============================================
// Method implementation
//==============================================
StdSbstLDUDCtrl::~StdSbstLDUDCtrl()
{

}
StdSbstLDUDCtrl::StdSbstLDUDCtrl()
{

}

StdSbstLDUDCtrl::StdSbstLDUDCtrl (
					CString name,
					int class_id,					// Class ID					
					OrdinarySnsTBL* pSnsMgzExist,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsMgzExist2,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsCoverClose,	// Cover close detect sensor
					OrdinarySnsTBL* pSnsSubstExist,	// Subst exist sensor
					int idx_mtMgz,					// Transfer motor X index
					int myErrStart					// Error start
				)
{
	this->m_name = name;
	this->m_classID = class_id;
	this->m_err.Initinstance(m_classID, myErrStart);
	this->m_snsMgzExist[0].Initinstance(m_classID, pSnsMgzExist);		// Existence check sensor
	this->m_snsMgzExist[1].Initinstance(m_classID, pSnsMgzExist2);		// Existence check sensor
	this->m_snsCoverClose.Initinstance(m_classID, pSnsCoverClose);	// Dock clase sensor
	this->m_snsSubstExist.Initinstance(m_classID, pSnsSubstExist);	// Dock clase sensor
	this->m_mtMgz.InitInstance(m_classID, idx_mtMgz);				// Magazine control motor
// #IK20130508-02 [�C��] ۰�ޗ�O����ב΍�
	SetStopFlag(0);								// ��~�v������	
}


//=================================================			// #DongKD(TFC6100TSB) 20140504
// Method to check cover sensor while moving load magazine
//=================================================
BOOL StdSbstLDUDCtrl::LoadUnloadMgzMovingChk(int &open)
{
	BOOL r = TRUE;
	bool isOn;

	if (!this->m_snsCoverClose.IsDetected(isOn) || !isOn) {
		r = FALSE;
		open = true;
		this->m_mtMgz.MotorSdStop();
	}

	return r;
}
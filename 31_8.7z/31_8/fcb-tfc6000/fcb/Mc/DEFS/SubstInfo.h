/*---------------------------------------------------------------------
	SubstInfo header file
								2013 MinhNN / TSDV Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include <CBLE_DEF.h>
#include "ComplexWaferFrameData.h"
class FrameIcCtrl;

#ifndef SUBSTINFO_H
#define SUBSTINFO_H
class CSubstInfo 
{
public:
	CSubstInfo();
	virtual ~CSubstInfo();
	CSubstInfo(	CString	name,
				CString	Command,
				CString	CommandDir,
				/*CString identity,*/
				unsigned int BLE_Ctrl
				);
	void SetCWnd(CWnd *pCWnd) {
		cwnd = pCWnd;
	}
	CWnd *cwnd;
	CWnd *ble;
private:
	CString		bleCommand;
	CString		commandDir;
	CString		commandLine;
	CString		identity;
	int			m_frmDir[2];   //THAIHV 20151224 send direction
	unsigned int ble_Ctrl;
	enum{
		eLineMax	= 100,
	};
public:
	CComplexWaferFrameData* pCplxWaferD;
public:
	BOOL BLEInit(bool dir = false);
	BOOL BLECtrl(int Cmd, int regNo = 0, int x = 0, int y = 0);

	void SendBonded(int regNo, int x, int y);
	void SendMoved( int regNo, int x, int y, int lr = 0);
	BOOL SaveMapEachReg(int regNo, CString barcode, FrameIcCtrl *frame);
	void SendDirection(int lr, int dir);

	//////////////////////////////////////////////////////////////////////
	//	Callback function
	//
	CString (__cdecl *pMCDataPath)();				// Get machine data path
	void SetMCDataPath(CString (__cdecl *pFunc)()){
		pMCDataPath	= pFunc;
	}
};

#endif
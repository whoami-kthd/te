/*---------------------------------------------------------------------
	ComplexWaferFrameData source file
								2013 MinhNN / TSDV Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/

#include "stdafx.h"
#include "fcb.h"
#include <Mcc.h>
#include "ComplexWaferFrameData.h"
#include	<swatch.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define BUFFER_SIZE_MAX		100
#define DEFAULT_ICSIZE		R2Pos(50.0, 50.0)
#define DEFAULT_ICPITCH		R2Pos(50.0, 50.0)
#define DEFAULT_STARTPOS	R2Pos(0.0, 0.0)
#define DEFAULT_NUMBX		1
#define DEFAULT_NUMBY		1
#define DEFAULT_ICTYPE		1
#define DEFAULT_TOOLNO		1		//#DMV170720 Add ToolNo Locate Edit

CComplexWaferFrameData::CComplexWaferFrameData()
{
	// Initialize value here
	regNumbers = 1;

	for (int idx = 0; idx < eCplxRegNumberMax; idx++) {
		regOffset[idx] = R2Pos(0, 0);
		eachIcType[idx] = 1;
		chipSize[idx] = R2Pos(1, 1);
		chipPitch[idx] = R2Pos(1, 1);
		bgSiteName[idx] = _T("");
		BgLocateArrayX[idx] = 1;
		BgLocateArrayY[idx] = 1;
		eachToolNo[idx] = 1;				//#DMV170720 Add ToolNo Locate Edit
	}

}

CComplexWaferFrameData::~CComplexWaferFrameData()
{
}

/////////////////////////////////////////////////////////////////////////////////
// Read data from dv_.190, 
// information: regNumbers, MaxNumberX, MaxNumberY, IcSize, IcPitch, StartPos
BOOL CComplexWaferFrameData::ComplexDVDataReadRegNo(BOOL read, LPCTSTR FNam) {
	BOOL r = TRUE;
	if (!read) {
		return r;
	}
	CString Sec = "BgLocateICLocation";
	CString Key = "�e�o�^No.��IC�i��";
	GWPPfileData(FNam, Sec, Key, read, this->regNumbers, 1);
	if (regNumbers <= 0 || regNumbers > eCplxRegNumberMax) {
		return r;
	}

// #DDT131223: Change default data
	GWPPfileData(FNam, Sec, Key, read, eachIcType, regNumbers, DEFAULT_ICTYPE);	

	//#DMV170720 Add ToolNo Locate Edit (S)
	CString ToolSec = "FC����� �i���ް�(����ިݸ��Ư�):°ٌ����ް�_L";
	CString ToolKey = "IC���ߖ��c�[���ԍ�";
	GWPPfileData(FNam, ToolSec, ToolKey, read, eachToolNo, regNumbers, DEFAULT_TOOLNO);
	//#DMV170720 Add ToolNo Locate Edit (E)

	for (int i = 0; i < regNumbers; i++) {
		Key.Format("�o�^No(%d) ArrayNumberX", i+1);
		GWPPfileData(FNam, Sec, Key, read, BgLocateArrayX[i], DEFAULT_NUMBY);
		Key.Format("�o�^No(%d) ArrayNumberY", i+1);	
		GWPPfileData(FNam, Sec, Key, read, BgLocateArrayY[i], DEFAULT_NUMBX);
		Key.Format("�o�^No(%d) IcSize", i+1);
		GWPPfileData(FNam, Sec, Key, read, chipSize[i], DEFAULT_ICSIZE, 2);
		Key.Format("�o�^No(%d) Pitch", i+1);
		GWPPfileData(FNam, Sec, Key, read, chipPitch[i], DEFAULT_ICPITCH, 2);
		Key.Format("�o�^No(%d) StartPos", i+1);
		GWPPfileData(FNam, Sec, Key, read, regOffset[i], DEFAULT_STARTPOS, 2);
		Key.Format("BgSite��(%d)", i+1);
		GWPPfileData(FNam, Sec, Key, read, bgSiteName[i], CString(""));

	}
	return r;
}

/////////////////////////////////////////////////////////////////////////////////
// Read data from dv_.190, 
// information: bonding offset XY
BOOL CComplexWaferFrameData::ComplexDVDataReadOffsetAndValid(BOOL read, LPCTSTR FNam) {
	BOOL r = TRUE;
	if (!read) {
		return r;
	}
	CString SecXY = "BgLocateOffsetXY";
	CString SecT = "BgLocateOffsetT";
	CString SecV = "BgLocateValid";
	CString KeyXY,KeyT,KeyV;
	int		regNo;
	int		maxX;
	int		maxY;

	// Progress Bar�p�̑����Z�o
	int prgrsTotal = 0,prgrsCurrent = 0,prgrsOutput = 0;
	for (int k = 0; k < this->regNumbers; k++) {
		prgrsTotal += this->BgLocateArrayX[k] * this->BgLocateArrayY[k];
	}
	//TRACE("          [LocateEdit�Ǎ�]BgLocateOffset = %6d / %6d\n", prgrsCurrent, prgrsTotal);

	R2Pos bufferXY[BUFFER_SIZE_MAX];
	double	bufferT[BUFFER_SIZE_MAX];
	int	bufferV[BUFFER_SIZE_MAX];
	for (int i = 0; i < this->regNumbers; i++) {
		regNo = i + 1;
		maxX = this->BgLocateArrayX[i];
		maxY = this->BgLocateArrayY[i];
		
		for (int j = 0; j < maxY; j++) {
			int line = ((maxX % 100) == 0) ? (maxX / 100) : (maxX / 100 + 1);
			for (int k = 0; k < line; k++) {
				int count = (maxX >= 100 * (k + 1)) ? 100 : (maxX - 100 * k);
				KeyXY.Format("BgLocateOffsetXY Reg%d_row%03d_col%03d-%03d", regNo, j+1, 100 * k + 1, 100 * (k + 1));
				GWPPfileData(FNam, SecXY, KeyXY, read, bufferXY, count, R2Pos(0, 0), 2);
				KeyT.Format("BgLocateOffsetT Reg%d_row%03d_col%03d-%03d", regNo, j+1, 100 * k + 1, 100 * (k + 1));
				GWPPfileData(FNam, SecT, KeyT, read, bufferT, count, 0.0, 2);
				KeyV.Format("BgLocateValid Reg%d_row%03d_col%03d-%03d", regNo, j+1, 100 * k + 1, 100 * (k + 1));
				GWPPfileData(FNam, SecV, KeyV, read, bufferV, count, 0);

				for (int l = 0; l < count; l++) {
					BgLocateOffsetXY[i][100*k+l][j] = bufferXY[l];
					BgLocateOffsetT[i][100*k+l][j] = bufferT[l];
					BgLocateValid[i][100*k+l][j] = bufferV[l];
				}

				// Progress Bar�p�̏o��
				prgrsCurrent += count;
				if ((prgrsCurrent - prgrsOutput) >= (prgrsTotal / 5)){
					//TRACE("          [LocateEdit�Ǎ�]BgLocateOffset = %6d / %6d(%2d%%)\n", prgrsCurrent, prgrsTotal,(prgrsCurrent*100)/prgrsTotal);

					// #MH131009
					// Display Progress bar on TP
					CString str1 = "dv_.190 is Loading...";
					CString str2;
					str2.Format("BgLocateOffset = %6d / %6d(%2d%%)\n", prgrsCurrent, prgrsTotal,(prgrsCurrent*100)/prgrsTotal);

					if (pDisplayTPProgressBar) {
						pDisplayTPProgressBar(FALSE, NULL, NULL);
						pDisplayTPProgressBar(TRUE, str1, str2);
					}
					//////////////////////

					prgrsOutput = prgrsCurrent;
				}
			}
		}
	}

	// Return TP
	if (pDisplayTPProgressBar) {
		pDisplayTPProgressBar(false, NULL, NULL);
		pDisplayTPProgressBar(true, "", "");
	}

	return r;
}


/////////////////////////////////////////////////////////////////////////////////
// Total file data read write
BOOL CComplexWaferFrameData::ComplexDVDataRead(BOOL read, LPCTSTR FNam)
{
	BOOL r = TRUE;

	// ���v���ԑ���
	StopWatch	swPrgrs;
	swPrgrs.Reset();
	swPrgrs.Start();
	TRACE("                      [�i��Data�Ǎ�]LocateEdit(dv_.*90)�Ǎ��J�n\n");

	r = ComplexDVDataReadRegNo(read, FNam) && r;
	r = ComplexDVDataReadOffsetAndValid(read, FNam) && r;

	int swPass_sec = (swPrgrs.Read() / 1000);
	int min = (int)(swPass_sec / 60);
	int sec = (int)(swPass_sec - min * 60);
	//TRACE("          [�i��Data�Ǎ�]LocateEdit(dv_.*90)�Ǎ�����:���v����=%dm:%ds]\n",min,sec);

	return r;
}
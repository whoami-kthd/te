/*---------------------------------------------------------------------
	SubstInfo.cpp
								2013 MinhNN / TSDV Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/

#include	<mcc.h>
#include	<SubstInfo.h>
#include	<direct.h>
#include	<Winuser.h>

#define		SubInfoIni	"SubInfoMode.ini"

#define		SUBMAP_PATH_SECTION		"SubMapData"
#define		SUBMAP_PATH_KEY			"SubstrateMapDataFilePath"

//////////////////////////////////////////////////////////////////////
// Construction
CSubstInfo::CSubstInfo() :
		cwnd(NULL), 
		ble(NULL)
{
}

CSubstInfo::CSubstInfo(CString	name,
				   CString	Command,
				   CString	CommandDir,
				   /*CString	identity,*/
				   unsigned int BLE_Ctrl
				   ) :
					cwnd(NULL),
					ble(NULL)
{
//	this->name				= name;		// Debugging name
	this->bleCommand		= Command;
	this->commandDir		= CommandDir;
//	if (identity.Compare("_L") == 0) {
//		this->commandLine		= CommandDir+Command+".exe"+" -SubInfo "+"-L";	
//	} else  {
//		this->commandLine		= CommandDir+Command+".exe"+" -SubInfo "+"-R";
//	}
	this->commandLine		= CommandDir+Command+".exe"+" -SubInfo ";
	this->ble_Ctrl			= BLE_Ctrl;
//	this->identity			= identity;
	this->m_frmDir[0]		= 0;
	this->m_frmDir[1]		= 0;
}



//////////////////////////////////////////////////////////////////////
// ����
CSubstInfo::~CSubstInfo()
{
	ble = cwnd->FindWindow(NULL, this->bleCommand);
	if (ble) {
		ble->PostMessage(WM_CLOSE);
	}
}

//////////////////////////////////////////////////////////////////////
// Start LocateEdit tool
BOOL CSubstInfo::BLEInit(bool dir)
{
	if (!cwnd) return(FALSE);
	// If SubInfo window is existed
	ble = cwnd->FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);
	if (ble) {
		// SubInfo Reload data
		int lparam = 0;
		//if (dir == false) {
		//	if (identity.Compare("_L") == 0) {
		//		lparam = eLeftMode;	
		//	} else  {
		//		lparam = eRightMode;	
		//	}
		//} else {
		//	lparam = eLRMode;
		//}
		ble->PostMessage(BLE_CTRL, BLE_FILE, lparam);
		::Sleep(500);
		cwnd->PostMessage(TFC_CTRL, STARTUP_LOAD_L, 0);
		//cwnd->PostMessage(TFC_CTRL, STARTUP_LOAD_R, 0);
	} else {
	//Dont need to check because BLE subinfo mode has only 1 window		
		BOOL r;
		PROCESS_INFORMATION processInfo;
		STARTUPINFO startUpInfo;
		GetStartupInfo(&startUpInfo);
		char *cmdLine = NULL;
		char *cmdDir = NULL;
		CString tmp = "";
		if (dir == false) {			
			cmdLine	= this->commandLine.GetBuffer(eLineMax);
			cmdDir	= this->commandDir.GetBuffer(eLineMax);
		} else {
// #DDT131125: Init both side of SubInfo
			cmdDir	= this->commandDir.GetBuffer(eLineMax);
			tmp = this->commandDir + this->bleCommand + ".exe" + " -SubInfo ";	
			cmdLine	= tmp.GetBuffer(eLineMax);
		}
		r = CreateProcess(
			NULL,				// pointer to name of executable module
			cmdLine,			// pointer to command line string
			NULL,				// pointer to process security attributes
			NULL,				// pointer to thread security attributes
			FALSE,				// handle inheritance flag
			CREATE_NEW_CONSOLE | IDLE_PRIORITY_CLASS,	// creation flags
			NULL,				// pointer to new environment block
			cmdDir,				// pointer to current directory name
			&startUpInfo,		// pointer to STARTUPINFO
			&processInfo		// pointer to PROCESS_INFORMATION
			);
		if (r) {	// �v���Z�X��������
			for (int i = 0; i < 10; i++) {
				ble = cwnd->FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);
				if (ble) {
					break;
				}
				::Sleep(500);
			}
		}
	}
	BOOL r = (ble) ? TRUE : FALSE;
	return(r);
}


//////////////////////////////////////////////////////////////////////
// Control LocateEdit tool
//
BOOL CSubstInfo::BLECtrl(int Cmd, int regNo, int x, int y)
{
	
	BOOL r = TRUE;
	LPARAM lParam = 0;
	WPARAM wParam = 0;
	switch (Cmd) {
	case BLE_INIT:							// Initialize
		r = BLEInit();  
		lParam = x;
		break;
	case BLE_DISP:							// Display screen
		lParam = x;							// 0:erase	1:display
		break;
	case BLE_FILE:							// Load file
		lParam = x;							// 0: save	1: load
		break;
	case BOND_NDONE_L:
	case BOND_FAIL_L:
	case BOND_DONE_L:
	case BOND_STACK_L:
	case BOND_SKIP_L:
	case DET_UNKN_L:
	case DET_BAD_L:
	case DET_GOOD_L:
	case BOND_NDONE_R:
	case BOND_FAIL_R:
	case BOND_DONE_R:
	case BOND_STACK_R:
	case BOND_SKIP_R:
	case DET_UNKN_R:
	case DET_BAD_R:
	case DET_GOOD_R:
	case BLE_MOVED_L:
	case BLE_MOVED_R:
		{
			lParam = (pCplxWaferD->GetBgLocateArrayX(regNo) * (y - 1)) + x;
			for (int i = regNo - 1; i >= 1; i--) {
				lParam += pCplxWaferD->GetBgLocateArrayX(i) * pCplxWaferD->GetBgLocateArrayY(i);
			}
			// Correction of index to BLE
			lParam = lParam - 1;
			break;
		}
	case -1:
		ble = cwnd->FindWindow(NULL, this->bleCommand);
		if (ble) {
			r = ble->PostMessage(WM_CLOSE);
		}
		return(r);
		break;

	default:	// error
		r = FALSE;
		break;
	}

	// Stack count
	if (Cmd > STACK_COUNT_L && Cmd < STACK_COUNT_R + 30) {
		lParam = (pCplxWaferD->GetBgLocateArrayX(regNo) * (y - 1)) + x;
		for (int i = regNo - 1; i >= 1; i--) {
			// Override value (case default)
			lParam += pCplxWaferD->GetBgLocateArrayX(i) * pCplxWaferD->GetBgLocateArrayY(i);
		}
		lParam = lParam - 1; 
		r = TRUE;
	}
	if (r) {
		ble = cwnd->FindWindow(NULL,/*this->bleCommand*/DBLE_FRAMENAME_SUBINFO);
		if (ble) {
			r = ble->PostMessage(/*this->ble_Ctrl*/BLE_CTRL, Cmd, lParam);
		} else {
			r = FALSE;
		}
	}
	return(r);
}

void CSubstInfo::SendMoved(int regNo, int x, int y, int lr)
{
	//if (lr == eOnBgStgL) {
		BLECtrl(BLE_MOVED_L, regNo, x, y);
	//} else if(lr == eOnBgStgR) {
	//	BLECtrl(BLE_MOVED_R, regNo, x, y);
	//}
}

BOOL CSubstInfo::SaveMapEachReg(int regNo, CString barcode, FrameIcCtrl *frame)
{
	unsigned char bdSts;					// board status
//	unsigned char dsSts;					// dispense status
	unsigned char bgSts;					// bonding status
	unsigned short stackCount;				// stack count
	int	bgStg;

//	if (identity.Compare("_L") == 0) {
//		bgStg = eOnBgStgL;	
//	} else  {
//		bgStg = eOnBgStgR;
//	}
	bgStg = OnBgStg;

	BOOL r = TRUE;
	static	InitFlag=FALSE;				// �ŏ��̂P��(����Ȃ�)�t���O
	CString FNam;
	CString	Sec = _T("Map Data Type 2");
	//CString destPath = SUBMAP_FILE_PATH;
	CString destPath;
	// Get machine data file path
	CString dv200 = pMCDataPath() +  ".200";
	// Get submap file
	GWPPfileData(dv200, SUBMAP_PATH_SECTION, SUBMAP_PATH_KEY, TRUE, destPath, "D:\\MapData\\SmMap\\SmSubstMap\\");
	CString fileName;

	// �ŏ��P��̂݁A�t�H���_�L�����`�F�b�N���A�Ȃ���΍쐬
	if(!InitFlag){
		if (_access(destPath, 0)){
			if (_mkdir(destPath)) {
				OutputDebugString("Directory(FCB/LOG) Create Error\n");
				return FALSE;
			}
		}
		InitFlag = TRUE;
	}

	if (pCplxWaferD->MI.BCRead) {			// Barcode on
		fileName.Format("%s%s_Reg%d", barcode, identity, regNo);
	} else {								// Barcode off
		CTime time = CTime::GetCurrentTime();
		CString date = time.Format("%y%m%d%H%M%S");
		fileName.Format("-%s%s_Reg%d",date ,identity, regNo);
	}
	FNam.Format("%s%s", destPath, fileName);

	CString BINLT;
	CString RPSEL = _T("1");
	CString PRDCT = _T("0");
	CString MLCL = _T("0");
	CString STRPX = _T("0");
	CString STRPY = _T("0");
	CString DUTMS = _T("0");
	CString FID = _T("''");
	int REFPX[10],REFPY[10];				// ���t�@�����X�|�C���g				// #YK140116-03:Complex����SubstMap�o�͏C��
	CString BCEQU;
	CString NULBC;
	CString BCBND;

	double XDIES = pCplxWaferD->GetChipSize(regNo).x;
	double YDIES = pCplxWaferD->GetChipSize(regNo).y;
	int ROWCT = pCplxWaferD->GetBgLocateArrayY(regNo);
	int COLCT = pCplxWaferD->GetBgLocateArrayX(regNo);
	REFPX[0] = pCplxWaferD->MI.REFPX;											// #YK140116-03:Complex����SubstMap�o�͏C��
	REFPY[0] = pCplxWaferD->MI.REFPY;
	for(int i=1; i<10; i++){
		REFPX[i] = 0;
		REFPY[i] = 0;
	}
	BCEQU.Format("'%s'",pCplxWaferD->MI.BCEQU);									// ��
	NULBC.Format("'%s'",pCplxWaferD->MI.NULBC);
	BCBND.Format("'%s'",pCplxWaferD->MI.BCBND);

	r = GWPPfileData(FNam, Sec, "FNLOC", FALSE, pCplxWaferD->MI.FNLOC) && r;
	r = GWPPfileData(FNam, Sec, "RPSEL", FALSE, RPSEL) && r;
	r = GWPPfileData(FNam, Sec, "REFPX", FALSE, REFPX,10) && r;
	r = GWPPfileData(FNam, Sec, "REFPY", FALSE, REFPY,10) && r;
	r = GWPPfileData(FNam, Sec, "XDIES", FALSE, XDIES) && r;
	r = GWPPfileData(FNam, Sec, "YDIES", FALSE, YDIES) && r;
	r = GWPPfileData(FNam, Sec, "ROWCT", FALSE, ROWCT) && r;
	r = GWPPfileData(FNam, Sec, "COLCT", FALSE, COLCT) && r;
	r = GWPPfileData(FNam, Sec, "PRDCT", FALSE, PRDCT) && r;
	r = GWPPfileData(FNam, Sec, "MLCL",  FALSE, MLCL) && r;	
	r = GWPPfileData(FNam, Sec, "STRPX", FALSE, STRPX) && r;		
	r = GWPPfileData(FNam, Sec, "STRPY", FALSE, STRPY) && r;
	r = GWPPfileData(FNam, Sec, "MID",   FALSE, fileName) && r;					// #YK140116-03:Complex����SubstMap�o�͏C��
	r = GWPPfileData(FNam, Sec, "FID",   FALSE, FID) && r;						// ��
	r = GWPPfileData(FNam, Sec, "DUTMS", FALSE, DUTMS) && r;					// ��
	r = GWPPfileData(FNam, Sec, "BCEQU", FALSE, BCEQU) && r;					// ��
	r = GWPPfileData(FNam, Sec, "NULBC", FALSE, NULBC) && r;					// ��

	// #DDT140305: Add bond code
	r = GWPPfileData(FNam, Sec, "BCBND", FALSE, BCBND) && r;

	CString Key;
	for (int y = 1; y <= ROWCT; y++) {
		BINLT = "";
		for (int x = 1; x <= COLCT; x++) {
			if(!pCplxWaferD->GetBgLocateValid(regNo, x ,y)) {
				BINLT += pCplxWaferD->MI.NULBC;
			} else {
				frame->frameD[bgStg].GetIcStatus(regNo, x, y, bdSts, bgSts, stackCount);
				// #DDT140305: Write bond/pattern code
				if (bgSts == SucceededToBond) {
					BINLT += pCplxWaferD->MI.BCBND;
				} else if (bgSts != -1) {
					BINLT += pCplxWaferD->MI.BCEQU;
				} else {
					BINLT += pCplxWaferD->MI.NULBC;
				}
			}
		}
		Key.Format("BINLT(%3d)", y);
		GWPPfileData(FNam, Sec, Key, FALSE, BINLT);
	}	

	return r;
}

void CSubstInfo::SendDirection(int lr, int dir)
{
	lr = 0;
	if (m_frmDir[lr] == dir) {
		return;
	} else {
		m_frmDir[lr] = dir;
		ble = cwnd->FindWindow(NULL,/*this->bleCommand*/DBLE_FRAMENAME_SUBINFO);
		if (ble) {
			ble->PostMessage(/*this->ble_Ctrl*/BLE_CTRL, /*(lr == eLeft) ? */BLE_DIR_L /*: BLE_DIR_R*/, dir);
		}
	}
}
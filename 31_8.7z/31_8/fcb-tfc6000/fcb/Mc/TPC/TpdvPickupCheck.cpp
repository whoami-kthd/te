/*---------------------------------------------------------------------
	������ى�ʊ֐��i�i���ް�:�s�b�N�A�b�v�`�F�b�N�j

	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_PickupChk(int step,int page)
{
	int OptIdx = 0;
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r=OK_END;
	for(;;){
		if(step == 0){		// �ް��ݒ�
			if(page ==1)		r = DVd_PickupChk1();
			else				r = Data1_END;
		} else {				// è��ݸ�
			if(page == 1)		r = DVt_PickupChk1();
			else				r = Teach1_END;
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}


////////////////////////////////////////////////////////////////////////////////-
// �s�b�N�A�b�v�`�F�b�N�i�f�[�^�ݒ�j
int TPCtrl::DVd_PickupChk1()
{
	enum {
		// ��ʔԍ�
		SNo					= 1750,		// ���No.
		// �\���f�[�^�C���f�b�N�X
		SupAng				= 304,		// �����p�x
		RngHold				= 314,		// �ݸ����ޓ��a
		// �{�^���C���f�b�N�X
		KeyWfrSize12		= 64,		// ��ʻ���12���
		KeyWfrSize6			= 65,		// ��ʻ���6���
		// ��ԕێ��C���f�b�N�X
		AttWfrSize6			= 200,		// ��ʻ���6���
		AttWfrSize8			= 201,		// ��ʻ���8���
		// ���ʃ{�^���C���f�b�N�X
		KeyHome				= '0',
		KeyPrev					,
		KeyTeach				,

		RefChk				= 203,	// ���t�@�����X�m�F���@(0:���� 1:���E�F�n)

		//KTV#170824 Add key variables (S)
		AttPickChkOn		= 206,	
		AttPickChkOff		= 207,
		AttErrorSkipOn		= 208,
		AttErrorSkipOff		= 209,

		KeyCoase			= 86,
		Coase				= 338,

		KeyFine				= 73,
		Fine				= 316,

		KeyVertical			= 75,
		Vertical			= 337,

		KeyOblique			= 76,
		Oblique				= 339,

		KeyContrastThreshold = 83,
		ContrastThreshold	 = 336,

		KeyRetryNum			= 74,
		RetryNum			= 318,

		KeyRecogDelay		= 77,
		RecogDelay			= 340,

		KeyErrorSkipON		= 80,
		KeyErrorSkipOFF		= 81,

		KeyPickupChkON		= 82,
		KeyPickupChkOFF		= 85,
		//KTV#170824 Add key variables (E)
	};
	int	r;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;

		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
	for(;;){
			//#KTV: Initialize value of each button in this screen
			tpc.GpPut16(AttPickChkOn, pMCC->BND.MD.PickupChkCam.pickupChk ? ATTR_B00 : ATTR_B01);
			tpc.GpPut16(AttPickChkOff, !pMCC->BND.MD.PickupChkCam.pickupChk ? ATTR_B00 : ATTR_B01);
			tpc.GpPut16(AttErrorSkipOn, pMCC->BND.MD.PickupChkCam.errorSkip ? ATTR_B00 : ATTR_B01);
			tpc.GpPut16(AttErrorSkipOff, !pMCC->BND.MD.PickupChkCam.errorSkip ? ATTR_B00 : ATTR_B01);

			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			switch(key){
				case KeyCoase:
					{
						const char *msg[] = {
							"Coase",
							"Coase",
						};

						double coase = pMCC->BND.MD.PickupChkCam.coaseVal;
						if (DataEdit(msg[Lang], "", coase, 0, 9.9999, 1000)) {
							pMCC->BND.MD.PickupChkCam.coaseVal = coase;
							DataPut(Coase, pMCC->BND.MD.PickupChkCam.coaseVal, 1000);
							DataUpdate = true;
						}
					}
					break;
				case KeyFine:
					{
						const char *msg[] = {
							"Fine",
							"Fine",
						};

						double fine = pMCC->BND.MD.PickupChkCam.fineVal;
						if (DataEdit(msg[Lang], "", fine, 0, 9.9999, 1000)) {
							pMCC->BND.MD.PickupChkCam.fineVal = fine;
							DataPut(Fine, pMCC->BND.MD.PickupChkCam.fineVal, 1000);
							DataUpdate = true;
						}
					}
					break;
				case KeyVertical:
					{
						const char *msg[] = {
							"Vertical",
							"Vertical",
						};

						double vertical = pMCC->BND.MD.PickupChkCam.verticalVal;
						if (DataEdit(msg[Lang], "", vertical, 0, 9.9999, 1000)) {
							pMCC->BND.MD.PickupChkCam.verticalVal = vertical;
							DataPut(Vertical, pMCC->BND.MD.PickupChkCam.verticalVal, 1000);
							DataUpdate = true;
						}
					}
					break;
				case KeyOblique:
					{
						const char *msg[] = {
							"Oblique",
							"Oblique",
						};

						double oblique = pMCC->BND.MD.PickupChkCam.obliqueVal;
						if (DataEdit(msg[Lang], "", oblique, 0, 9.9999, 1000)) {
							pMCC->BND.MD.PickupChkCam.obliqueVal = oblique;
							DataPut(Oblique, pMCC->BND.MD.PickupChkCam.obliqueVal, 1000);
							DataUpdate = true;
						}
					}
					break;
				case KeyContrastThreshold:
					{
						const char *msg[] = {
							"Oblique",
							"Oblique",
						};

						double contrastThreshold = pMCC->BND.MD.PickupChkCam.constrastThresholdVal;
						if (DataEdit(msg[Lang], "", contrastThreshold, 0, 9.9999, 1000)) {
							pMCC->BND.MD.PickupChkCam.constrastThresholdVal = contrastThreshold;
							DataPut(ContrastThreshold, pMCC->BND.MD.PickupChkCam.constrastThresholdVal, 1000);
							DataUpdate = true;
						}
					}
					break;
				case KeyRetryNum:
					{
						const char *msg[] = {
							"RetryNum",
							"RetryNum",
						};

						double retryNum = pMCC->BND.MD.PickupChkCam.retryNumVal;
						if (DataEdit(msg[Lang], "", retryNum, 0, 9.9999, 1000)) {
							pMCC->BND.MD.PickupChkCam.retryNumVal = retryNum;
							DataPut(RetryNum, pMCC->BND.MD.PickupChkCam.retryNumVal, 1000);
							DataUpdate = true;
						}
					}
					break;
				case KeyRecogDelay:
					{
						const char *msg[] = {
							"RecogDelay",
							"RecogDelay",
						};

						double recogDelay = pMCC->BND.MD.PickupChkCam.recogDelayVal;
						if (DataEdit(msg[Lang], "", recogDelay, 0, 9.9999, 1000)) {
							pMCC->BND.MD.PickupChkCam.recogDelayVal = recogDelay;
							DataPut(RecogDelay, pMCC->BND.MD.PickupChkCam.recogDelayVal, 1000);
							DataUpdate = true;
						}
					}
					break;
				case KeyErrorSkipON:
					{
						if(!pMCC->BND.MD.PickupChkCam.errorSkip){
							pMCC->BND.MD.PickupChkCam.errorSkip = 1;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyErrorSkipOFF:
					{
						if(pMCC->BND.MD.PickupChkCam.errorSkip){
							pMCC->BND.MD.PickupChkCam.errorSkip = 0;
							DataUpdate = TRUE;
						}
					}
					break;

				case KeyPickupChkON:
					{
						if(!pMCC->BND.MD.PickupChkCam.pickupChk){
							pMCC->BND.MD.PickupChkCam.pickupChk = 1;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyPickupChkOFF:
					{
						if(pMCC->BND.MD.PickupChkCam.pickupChk){
							pMCC->BND.MD.PickupChkCam.pickupChk = 0;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyTeach:
					End = TRUE;
					r = Teach1_END;	// è��ݸ��߰��1��
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	return	r;
}

/////////////////////////////////////////////////////////////////////////////
//----- Pickup check camera after
int TPCtrl::DVt_PickupChk1()
{
	enum{
		PickupAfterSNo		= 1755,		// ���No.

		Msg					= 160,	// ү���ޕ\��������

		MXX					= 300,		// �{�� XX
		MXY					= 302,		// �{�� XY
		MYX					= 304,		// �{�� YX
		MYY					= 306,		// �{�� YY
		MXXUNIT				= 308,		// �{�� XX�P��
		MXYUNIT				= 310,		// �{�� XY�P��
		MYXUNIT				= 312,		// �{�� YX�P��
		MYYUNIT				= 314,		// �{�� YY�P��

		KeyEnter			= 'A'	,	// �o�^���s
		KeyCancel				,
		KeyBC					,	// ��¶��
		KeyIC					,	// IC���
		KeyDC					,	// �f�B�X�y���X��¶��
		KeyCursor				,	// ���وړ�
		KeyIVC					,	// IC�z��
		KeyBVC					,	// ��z��
		KeyBClmp		= 75	, 	// Bð�߸����(�J/��)

		AttEnter			= 200,	// �o�^���s
		AttCancel				,
		AttBC					,	// ��¶��
		AttIC					,	// IC���
		AttDC					,	// �f�B�X�y���X��¶��
		AttCursor				,	// ���وړ�
		AttIVC					,	// IC�z��
		AttBVC					,	// ��z��
		AttBClmp			= 210,	// Bð�߸����(�J/��)

		KeyHome			= '0'	,
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyTeach1				,
		KeyTeach2				,
		KeyTeach3				,
		KeyTeach4				,
		KeyTeach5				,

		KeyPatternSetup		= 80,
		AttPatternSetup		= 207,
		KeyTeachPanel		= 52,
	};

	int	 r = KeyPrev;
	double	keta;
	BOOL	DataUpdate=FALSE;

	const char*	Emsg[]=	{	"Please press [Set-up / Done]            ",
							"1/3 Setup & Select Unique Pattern       ",
							"2/3 Eye-point Pattern Left Up	         ",
							"3/3 Confirm teaching process is OK or not ",
						};

	const char*	EmsgEng[]=	{	"Please press [Set-up / Done]            ",
								"1/3 Setup & Select Unique Pattern       ",
								"2/3 Eye-point Pattern Left Up	         ",
								"3/3 Confirm Teaching is OK or not ",
							};

	int	Cam = PickChkCamNo;

	int maxstep = 4;
	bool doCalibPosCnv = true;

	BNDCtrl::MC_Data::CameraData::CamData	*pCD=&pMCC->BND.MD.CameraD.IC;
	pMCC->CameraSelect(Cam);
	pMCC->BND.LightSelect(1,Cam, BNDCtrl::SP_LightLevel);
	tpc.GpPut16(AttDC,0);
	tpc.GpPut16(AttBC,ATTR_SEL);
	tpc.GpPut16(AttIC,0);
	tpc.GpPut16(AttCancel	,0);
	tpc.GpPut16(AttEnter	,0);
	tpc.GpPut16(AttCursor	,0);
	tpc.GpPut16(AttPatternSetup,	0);

	for(;;){
		BOOL	End=FALSE;
		bool On;
		int	 ECnt=0;
		
		int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
		
		if (Step != 1) {	tpc.GpScreenDisp(PickupAfterSNo); }	// 	��ʐ؂�ւ� 
		else		   {	DVt_PickupChk2(); }

//		Step = 0;

		if (pMCC->C8200.Camera_Info[Cam].deform) {
			keta = 1;
			for (int i=0; i<4; i++)	tpc.GpPut16(MXXUNIT+2*i, 1);
		} else {
			keta = 1000;
			for (int i=0; i<4; i++)	tpc.GpPut16(MXXUNIT+2*i, 0);
		}
		DataPut(MXX,pCD->MX.X()*keta,10000);
		DataPut(MXY,pCD->MX.Y()*keta,10000);
		DataPut(MYX,pCD->MY.X()*keta,10000);
		DataPut(MYY,pCD->MY.Y()*keta,10000);

		tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0], 40);		// ү���ޕ\��

		bool ModelInput = false;
		for(;;){
			int rtn;
			rtn = pMCC->BND.bond.HeadIcVacuumSns(On);
			tpc.GpPut16(AttIVC, (rtn && On) ? ATTR_S0 : ATTR_S1);

			rtn = pMCC->BND.BgStgVacuum.Sns(true, On);
			tpc.GpPut16(AttBVC, (rtn && On) ? ATTR_S0 : ATTR_S1);

			BOOL	Restart=FALSE;

			int	key;
			int	Axis_Sw = BGH_XY | BGH_Z | CAM_XY | CAM_Z | STG_XY;
			key = KeyWait_Adjust_BND_STAGE_CAMERA(TRUE,eAdjMode_Normal,0,0,Axis_Sw);	//�@��ެ�ċ@�\�t��������
			if(key)	tpc.GpBeep();

			if(key == KeyEnter){
				bool	isAlreadyPatternSetUp = true;
				if (ECnt == 1 || ECnt == 2 || ECnt == 3) {
					if(!ModelInput){
						const char* msg[] = {
							"�p�^�[����ݒ肵�Ă��������B",
							"Please Set the Pattern.",
						};
						isAlreadyPatternSetUp = false;
						Warn(msg[Lang]);
					}
				}

				if(isAlreadyPatternSetUp){
					r = pMCC->BND.SubstratGlobalAlign_Teach(ECnt, doCalibPosCnv);	// �e�B�[�`���O�J�n
					
					if(r){
						ECnt ++;
						if(maxstep > ECnt){
							bool hasToSetIndexAutomatic = true;
							tpc.GpPut16(AttEnter	,ATTR_SEL);
							tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[ECnt] : Emsg[ECnt], 40);		// ү���ޕ\��
						
/*							if (ECnt == 2) {			//KTV#170830 Get top-left of first LED
								int currToolNo = pMCC->BND.GetCurrentToolNo();
								r = pMCC->BND.GetTopLeftLEDTeaching(currToolNo);
								if (r) {
									
								}
								else {
									
								}
							}
*/
							if(ECnt == 3) {		// KTV#170829 Confirm teaching process is OK or not
								r = IsTeachingOK();
								if (!r) {		// teaching process is NG
									const char* msg[] = {
										"Teaching is NG, please execute again !!!",
										"Teaching is NG, please execute again !!!",
									};
									Warn(msg[Lang]);
								}
							}
						}
						else{
							tpc.GpPut16(AttEnter	,0);
							tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0], 40);		// ү���ޕ\��
							ECnt = 0;
							DataUpdate = false;
							Restart = true;
							// �f�[�^������
							pMCC->BND.DD.BGlobalAlignD.DataRW(pMCC->C8200, FALSE , pMCC->BND.DD.FName);
						}
					}					
				}
			} else if (key == KeyPatternSetup) {	// KTV#170828: Add key pattern setup
				
				tpc.GpPut16(AttPatternSetup , ATTR_SEL);

				pMCC->BND.DD.ToolPickRecD.ToolPickModelD.Train(pMCC->BND.DD.ToolPickRecD, pMCC->C8200, 1, 1);
				DataUpdate = true;
				ModelInput = TRUE;
				
				tpc.GpPut16(AttPatternSetup , 0);

			} else if (key == KeyTeachPanel) {		// KTV#170828: Change to pickup teach before
				Step = 1;
				End = TRUE;
			} else if(key == KeyCursor && ECnt >= 1){		// ���وړ�
				MCC_Action_Call	A(pMCC);	// ����J�n���w��	�޽�׸��ŏI�����w��
				tpc.GpPut16(AttCursor	,ATTR_SEL);		// �I�����
				pMCC->BND.CameraMagInp(Cam);			// ���وړ�
				tpc.GpBeep();
				tpc.GpPut16(AttCursor	,0);			// ��I�����
				DataUpdate = TRUE;
			} else if(key == KeyCancel){
				tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
				pMCC->BND.CameraMagTeach(Cam,-1);		// ��ݾ�
				if(DataUpdate)
					pMCC->BND.MD.CameraD.DataRW(pMCC->C8200,TRUE,pMCC->BND.MD.FName);
				tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
				DataUpdate = FALSE;
				Restart = TRUE;
			} else if(ECnt == 0){	// �o�^���s�y�ъm�F���ł͂Ȃ�
				if(key == KeyPrev){
					End = TRUE;
					r = Prev_END;
				} else if(key == KeyHome){
					End = TRUE;
					r = Home_END;
				} else if(key == KeyData){
					End = TRUE;
					r = Data1_END;	// �ް��ݒ��߰��1��
				} else if(KeyTeach1 <= key && key <= KeyTeach5){
					End = TRUE;
					r = Teach1_END + key - KeyTeach1;
				} 
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}

	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.frame.DVDataRW(FALSE,pMCC->BND.DD.FName, pMCC->BND.DD.Sec);
		pMCC->BND.DD.BGlobalAlignD.DataRW(pMCC->C8200, FALSE , pMCC->BND.DD.FName);
	}
	
	return	r;
}


/////////////////////////////////////////////////////////////////////////////
//----- Pickup check camera before
int TPCtrl::DVt_PickupChk2()
{
	enum{
		SNo					= 1756,		// ���No.

		Msg					= 160,	// ү���ޕ\��������

		MXX					= 300,		// �{�� XX
		MXY					= 302,		// �{�� XY
		MYX					= 304,		// �{�� YX
		MYY					= 306,		// �{�� YY
		MXXUNIT				= 308,		// �{�� XX�P��
		MXYUNIT				= 310,		// �{�� XY�P��
		MYXUNIT				= 312,		// �{�� YX�P��
		MYYUNIT				= 314,		// �{�� YY�P��

		KeyEnter			= 'A'	,	// �o�^���s
		KeyCancel				,
		KeyBC					,	// ��¶��
		KeyIC					,	// IC���
		KeyDC					,	// �f�B�X�y���X��¶��
		KeyCursor				,	// ���وړ�
		KeyIVC					,	// IC�z��
		KeyBVC					,	// ��z��
		KeyBClmp		= 75	, 	// Bð�߸����(�J/��)

		AttEnter			= 200,	// �o�^���s
		AttCancel				,
		AttBC					,	// ��¶��
		AttIC					,	// IC���
		AttDC					,	// �f�B�X�y���X��¶��
		AttCursor				,	// ���وړ�
		AttIVC					,	// IC�z��
		AttBVC					,	// ��z��
		AttBClmp			= 210,	// Bð�߸����(�J/��)

		KeyHome			= '0'	,
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyTeach1				,
		KeyTeach2				,
		KeyTeach3				,
		KeyTeach4				,
		KeyTeach5				,
	};

	int	r;
	double	keta;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

	BOOL	DataUpdate=FALSE;
				//			 1234567890123456789012345678901234567890
	const char*	Emsg[]=	{	"Please press [Set-up / Done]            ",
							"1/3 Setup & Select Unique Pattern       ",
							"2/3 Eye-point Pattern Left Up	         ",
							"3/3 Confirm teaching process is OK or not ",
						};
					//			 1234567890123456789012345678901234567890
	const char*	EmsgEng[]=	{	"Please press [Set-up / Done]            ",
								"1/3 Setup & Select Unique Pattern       ",
								"2/3 Eye-point Pattern Left Up	         ",
								"3/3 Confirm teaching process is OK or not ",
							};

	int	Cam = PickChkCamNo;	// ��¶��

	int maxstep = 4;
	bool doCalibPosCnv = true;

	BNDCtrl::MC_Data::CameraData::CamData	*pCD=&pMCC->BND.MD.CameraD.BC;	// ��T������ް�
	pMCC->CameraSelect(Cam);								// ��אؑ�
	pMCC->BND.LightSelect(1,Cam, BNDCtrl::SP_LightLevel);	//  ch->	�Ɩ��I���@BCCamNo,ICCamNo
	tpc.GpPut16(AttDC,0);
	tpc.GpPut16(AttBC,ATTR_SEL);
	tpc.GpPut16(AttIC,0);
	tpc.GpPut16(AttCancel	,0);
	tpc.GpPut16(AttEnter	,0);
	tpc.GpPut16(AttCursor	,0);

	for(;;){
		BOOL	End=FALSE;
		int		ECnt=0;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		if (pMCC->C8200.Camera_Info[Cam].deform) {
			keta = 1;
			for (int i=0; i<4; i++)	tpc.GpPut16(MXXUNIT+2*i, 1);
		} else {
			keta = 1000;
			for (int i=0; i<4; i++)	tpc.GpPut16(MXXUNIT+2*i, 0);
		}
		DataPut(MXX,pCD->MX.X()*keta,10000);
		DataPut(MXY,pCD->MX.Y()*keta,10000);
		DataPut(MYX,pCD->MY.X()*keta,10000);
		DataPut(MYY,pCD->MY.Y()*keta,10000);

		tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0], 40);		// ү���ޕ\��

		bool On;
		for(;;){
			int rtn;
			rtn = pMCC->BND.bond.HeadIcVacuumSns(On);
			tpc.GpPut16(AttIVC, (rtn && On) ? ATTR_S0 : ATTR_S1);

			rtn = pMCC->BND.BgStgVacuum.Sns(true, On);
			tpc.GpPut16(AttBVC, (rtn && On) ? ATTR_S0 : ATTR_S1);

			BOOL	Restart=FALSE;
			int	key;
				int	Axis_Sw = BGH_XY | BGH_Z | CAM_XY | CAM_Z | STG_XY;

			key = KeyWait_Adjust_BND_STAGE_CAMERA(TRUE,eAdjMode_Normal,0,0,Axis_Sw);	//�@��ެ�ċ@�\�t��������
			
			if(key)	tpc.GpBeep();
			if(key == KeyEnter){
				r = pMCC->BND.SubstratGlobalAlign_Teach(ECnt, doCalibPosCnv);			// �e�B�[�`���O�J�n
				if(r){
					ECnt ++;
					if(maxstep > ECnt){
						bool hasToSetIndexAutomatic = true;
						tpc.GpPut16(AttEnter ,ATTR_SEL);
						tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[ECnt] : Emsg[ECnt], 40);	// ү���ޕ\��

						if (ECnt == 2) {			//KTV#170830 Get top-left of first LED
							int currToolNo = pMCC->BND.GetCurrentToolNo();
							r = pMCC->BND.GetTopLeftLEDTeaching(currToolNo);
							if (r) {
								
							}
							else {
								
							}
						}
						else if(ECnt == 3) {		//KTV#170829 Confirm teaching process is OK or not
							r = IsTeachingOK();
							if (r) {
								
							}
							else {
								
							}
						}
					}
					else{
						tpc.GpPut16(AttEnter , 0);
						tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0], 40);		// ү���ޕ\��
						ECnt = 0;
						DataUpdate = false;
						Restart = true;
						// �f�[�^������
						pMCC->BND.DD.BGlobalAlignD.DataRW(pMCC->C8200, FALSE , pMCC->BND.DD.FName);
					}
				}
			} else if(key == KeyCursor && ECnt >= 1){		// ���وړ�
				MCC_Action_Call	A(pMCC);	// ����J�n���w��	�޽�׸��ŏI�����w��
				tpc.GpPut16(AttCursor	,ATTR_SEL);		// �I�����
				pMCC->BND.CameraMagInp(Cam);			// ���وړ�
				tpc.GpBeep();
				tpc.GpPut16(AttCursor	,0);			// ��I�����
				DataUpdate = TRUE;
			} else if(key == KeyCancel){
				tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
				pMCC->BND.CameraMagTeach(Cam,-1);		// ��ݾ�
				if(DataUpdate)
					pMCC->BND.MD.CameraD.DataRW(pMCC->C8200,TRUE,pMCC->BND.MD.FName);
				tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
				DataUpdate = FALSE;
				Restart = TRUE;
			} else if(ECnt == 0){	// �o�^���s�y�ъm�F���ł͂Ȃ�
				if(key == KeyPrev){
					End = TRUE;
					r = Prev_END;
				} else if(key == KeyHome){
					End = TRUE;
					r = Home_END;
				} else if(key == KeyData){
					Step = 0;
					DVt_PickupChk1();	//KTV	
					End = TRUE;
					r = Data1_END;	// �ް��ݒ��߰��1��
				} else if(KeyTeach1 <= key && key <= KeyTeach5){
					End = TRUE;
					r = Teach1_END + key - KeyTeach1;
				}
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	
	return	r;
}

bool TPCtrl::IsTeachingOK() 
{
	R2Pos	CamSearchTopLeftPoint;
	// Get top left of camera view search
	// Need get and update value of ICTopLeftPoint
	CamSearchTopLeftPoint.x = pMCC->BND.WD.ICTopLeftPoint.x - (pMCC->BND.WD.ICTopLeftPoint.x/2);
	CamSearchTopLeftPoint.y = pMCC->BND.WD.ICTopLeftPoint.x - (pMCC->BND.WD.ICTopLeftPoint.x/2);
	
	// Choose the number of LEDs in each axis for suitable with Tool Size
	// 1st: Find the max of LED number in search view	PickChkSearchCamera					
	int xLEDMaxInSearchView = (int) ((pMCC->SD.Board.CameraInfo[0].Width - pMCC->BND.MD.ToolD.toolPitch.x)/ (pMCC->BND.MD.ToolD.toolSize.x + pMCC->BND.MD.ToolD.toolPitch.x) );
	int yLEDMaxInSearchView = (int) ((pMCC->SD.Board.CameraInfo[0].Hight - pMCC->BND.MD.ToolD.toolPitch.y)/ (pMCC->BND.MD.ToolD.toolSize.y + pMCC->BND.MD.ToolD.toolPitch.y) );

	int xLEDInSearchView, yLEDInSearchView;
	// 2nd: Choose the LED number of search view
	for(int i = 1; i < xLEDMaxInSearchView; i++ ) {
		if( (int)(pMCC->BND.MD.ToolD.toolIndex.x) % i == 0) {
			xLEDInSearchView = i;
		}
	}

	for(int j = 1; j < yLEDMaxInSearchView; j++ ) {
		if( (int)(pMCC->BND.MD.ToolD.toolIndex.y) % j == 0) {
			yLEDInSearchView = j;
		}
	}

	// Find the search area
	int xSearchSizeArea, ySearchSizeArea;
	xSearchSizeArea = xLEDInSearchView * (pMCC->ICS.DD.WaferD.WFD.SizeIC.x + pMCC->ICS.DD.WaferD.WFD.PitchIC.x);
	ySearchSizeArea = yLEDInSearchView * (pMCC->ICS.DD.WaferD.WFD.SizeIC.y + pMCC->ICS.DD.WaferD.WFD.PitchIC.y);

	// Find step number of camera moving for recognize all tool
	int xMoveStep, yMoveStep;
	xMoveStep = (pMCC->BND.MD.ToolD.toolIndex.x * (pMCC->ICS.DD.WaferD.WFD.SizeIC.x + pMCC->ICS.DD.WaferD.WFD.PitchIC.x))/ xSearchSizeArea;
	yMoveStep = (pMCC->BND.MD.ToolD.toolIndex.y * (pMCC->ICS.DD.WaferD.WFD.SizeIC.y + pMCC->ICS.DD.WaferD.WFD.PitchIC.y))/ ySearchSizeArea;
	
	// First camera view image center
	pMCC->BND.DD.ToolPickRecD.spara[0].SCent.x = CamSearchTopLeftPoint.x + xSearchSizeArea/2;
	pMCC->BND.DD.ToolPickRecD.spara[0].SCent.y = CamSearchTopLeftPoint.y + ySearchSizeArea/2;

	// First camera view size
	pMCC->BND.DD.ToolPickRecD.spara[0].SSize.x = xSearchSizeArea;
	pMCC->BND.DD.ToolPickRecD.spara[0].SSize.y = ySearchSizeArea;

	// Move tool to next recog
	// Move distance equal to size of search view
	int LEDNoInTool = 0;							
	int currToolNo = pMCC->BND.GetCurrentToolNo();
	BOOL r = TRUE;
	int dir = eDIR_LEFT;
	
	R2Pos SPForHeadMove;
	R2Pos2 RPForHeadMove, tempSPForHeadMove;

	for( i = 1; i <= xMoveStep; i++ ) {
		if (dir == eDIR_LEFT) {
			for (j = 1; j<=yMoveStep; j++) {
				SPForHeadMove = R2Pos(pMCC->BND.DD.ToolPickRecD.spara[0].SCent.X(), pMCC->BND.DD.ToolPickRecD.spara[0].SCent.Y()); // need to move this point which in CMV

				tempSPForHeadMove.P0 = SPForHeadMove;
				tempSPForHeadMove.P1 = R2Pos(0, 0);

				RPForHeadMove = pMCC->BND.MD.PickupChkCam.ICPickDB.SP_to_RP(tempSPForHeadMove);		// need to move this point which in head
				pMCC->BND.HeadMoveAbs(pMCC->BND.MtSel(BNDCtrl::HZI), RPForHeadMove.P0, 0.0, 0.0);
			
				r = pMCC->BND.ToolChkPickupTeaching(currToolNo);
				LEDNoInTool += pMCC->BND.WD.LEDRecogCount;

				if(j == yMoveStep) {		// revert direction
					dir = eDIR_RIGHT;
				}
			}
		}else{
			for (j = yMoveStep; j>= 1; j--) {
				SPForHeadMove = R2Pos(pMCC->BND.DD.ToolPickRecD.spara[0].SCent.X(), pMCC->BND.DD.ToolPickRecD.spara[0].SCent.Y()); // need to move this point which in CMV

				tempSPForHeadMove.P0 = SPForHeadMove;
				tempSPForHeadMove.P1 = R2Pos(0, 0);

				RPForHeadMove = pMCC->BND.MD.PickupChkCam.ICPickDB.SP_to_RP(tempSPForHeadMove);		// need to move this point which in head
				pMCC->BND.HeadMoveAbs(pMCC->BND.MtSel(BNDCtrl::HZI), RPForHeadMove.P0, 0.0, 0.0);

				r = pMCC->BND.ToolChkPickupTeaching(currToolNo);
				LEDNoInTool += pMCC->BND.WD.LEDRecogCount;

				if(j == 1) {			 // revert direction
					dir = eDIR_LEFT;
				}				
			}
		}
	}
	
	// Check if LED number of tool equal to vacuumns number or not
	if(LEDNoInTool == (pMCC->BND.MD.ToolD.toolIndex.X() * pMCC->BND.MD.ToolD.toolIndex.Y())) {
		return TRUE;		// it is OK
	} else {
		return FALSE;		// it is NG
	}
}
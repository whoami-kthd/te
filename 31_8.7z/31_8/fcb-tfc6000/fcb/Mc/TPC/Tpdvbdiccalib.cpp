/*---------------------------------------------------------------------
	�^�b�`�p�l����ʊ֐��i�i��f�[�^:���IC�J�����L�����u���[�V�����j
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

// #MU150828-01
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_BDICCalib(int step,int page)
{
	int	r=OK_END;
	for(;;){
		if (step == 0) {
			if(page == 1)		r = DVd_BDICCalib1();	// �L�����u���[�V�����p�w�b�h�^�[�Q�b�g
			else if(page == 2)	r = DVd_BDICCalib2();	// �L�����u���[�V�����p�X�e�[�W�^�[�Q�b�g
			else				r = Data1_END;
		} else {
			if(page == 1)		r = Teach1_END;
			else				r = Teach1_END;
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DVd_BDICCalib1()
{
	enum{
//		SNo					= 1680,		// ���No.
		SNo					= 1450,		// ���No.
		//
		KeyFeedbackON		= 65,		// Feedback ON
		KeyFeedbackOFF		= 66,		// Feedback OFF
		KeyIntervalBgCnt	= 67,		// Interval Bg Count
		//
		AttFeedback			= 200,		// Feedback
		//
		IntervalBgCnt		= 300,		// Interval Bg Count
		//
		KeyHome				= '0',
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyData1				,
		KeyData2				,
	};
	int	r = KeyPrev;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		/////////////////////
		// �����l�\��
		tpc.GpPut16(AttFeedback,	pMCC->BND.DD.BDICCalibH.feedback ? ATTR_B00 : ATTR_B01);	// Feedback�L��
		DataPut(IntervalBgCnt,		pMCC->BND.DD.BDICCalibH.intervalBg);						// Interval Bg Count
		//
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			switch(key){
				///////////////
				// Feedback�L��
				case KeyFeedbackON	:
				case KeyFeedbackOFF	:
					{
						if(key == KeyFeedbackON)	pMCC->BND.DD.BDICCalibH.feedback = 1;
						else						pMCC->BND.DD.BDICCalibH.feedback = 0;					
						tpc.GpPut16(AttFeedback,	pMCC->BND.DD.BDICCalibH.feedback ? ATTR_B00 : ATTR_B01);
						DataUpdate = TRUE;
					}
					break;
				///////////////
				// Interval Bg Count
				case KeyIntervalBgCnt	:
					{
						const char* msg[] = {
							{ "Interval Bg Count" },
							{ "Interval Bg Count" },
						};
						///////////////
						// �f�[�^�ҏW
						if(DataEdit(msg[Lang],"",pMCC->BND.DD.BDICCalibH.intervalBg,1,999,1)){
							DataPut(IntervalBgCnt,	pMCC->BND.DD.BDICCalibH.intervalBg,1);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// 
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyTeach:
					End = TRUE;
					break;					
				case KeyData1:
					if(pMCC->MD.OptionD.hasACalib_HeadTarget){
						r = Data1_END;
						End = TRUE;
					} else {
						Warn(OptionDisp[Lang]);
					}
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.DD.BDICCalibH.DataRW(FALSE,  pMCC->BND.DD.FName);
	}
	return r;
}
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DVd_BDICCalib2()
{
	enum{
		SNo					= 1681,		// ���No.
		//
		KeyFeedbackON		= 65,		// Feedback ON
		KeyFeedbackOFF		= 66,		// Feedback OFF
		KeyIntervalBgCnt	= 67,		// Interval Bg Count
		//
		AttFeedback			= 200,		// Feedback
		//
		IntervalBgCnt		= 300,		// Interval Bg Count
		//
		KeyHome				= '0',
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyData1				,
		KeyData2				,
	};
	int	r = KeyPrev;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		/////////////////////
		// �����l�\��
		tpc.GpPut16(AttFeedback,	pMCC->BND.DD.BDICCalibS.feedback ? ATTR_B00 : ATTR_B01);	// Feedback�L��
		DataPut(IntervalBgCnt,		pMCC->BND.DD.BDICCalibS.intervalBg);						// Interval Bg Count
		//
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			switch(key){
				///////////////
				// Feedback�L��
				case KeyFeedbackON	:
				case KeyFeedbackOFF	:
					{
						if(key == KeyFeedbackON)	pMCC->BND.DD.BDICCalibS.feedback = 1;
						else						pMCC->BND.DD.BDICCalibS.feedback = 0;					
						tpc.GpPut16(AttFeedback,	pMCC->BND.DD.BDICCalibS.feedback ? ATTR_B00 : ATTR_B01);
						DataUpdate = TRUE;
					}
					break;
				///////////////
				// Interval Bg Count
				case KeyIntervalBgCnt	:
					{
						const char* msg[] = {
							{ "Interval Bg Count" },
							{ "Interval Bg Count" },
						};
						///////////////
						// �f�[�^�ҏW
						if(DataEdit(msg[Lang],"",pMCC->BND.DD.BDICCalibS.intervalBg,1,999,1)){
							DataPut(IntervalBgCnt,	pMCC->BND.DD.BDICCalibS.intervalBg,1);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// 
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyTeach:
					End = TRUE;
					break;
				case KeyData1:
					if(pMCC->MD.OptionD.hasACalib_HeadTarget){
						r = Data1_END;
						End = TRUE;
					} else {
						Warn(OptionDisp[Lang]);
					}
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.DD.BDICCalibS.DataRW(FALSE,  pMCC->BND.DD.FName);
	}
	return r;
}
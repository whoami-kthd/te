// CMVDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMVDlg.h"
#include "CMV_Util.h"
#include "CMV_DEF.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMVDlg dialog

IMPLEMENT_DYNAMIC(CCMVDlg, CDialog);

CCMVDlg::CCMVDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCMVDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCMVDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon			= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pDoc			= NULL;
	m_RowMax		= 0;
	m_ColMax		= 0;
	m_nZoom			= 0;
}

CCMVDlg::~CCMVDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
}

void CCMVDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCMVDlg)
//	DDX_Control(pDX, IDC_LIST_INDEX_PICKUP, m_IndexPickupList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCMVDlg, CDialog)
	//{{AFX_MSG_MAP(CCMVDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTN_LOAD_MAP, OnBtnLoadMap)
	ON_BN_CLICKED(IDC_BTN_ZOOM_IN, OnBtnZoomIn)
	ON_BN_CLICKED(IDC_BTN_ZOOM_OUT, OnBtnZoomOut)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMVDlg message handlers

BOOL CCMVDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_IsLoadedMap = false;

	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;

	m_pDoc = new CMV_Doc();
	// Create Map view layout
	CRect rect;
	GetDlgItem(IDC_MAP_DISP_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_MapLayout = new CMV_Map_View();
	m_MapLayout->SetDocument(m_pDoc);
	m_MapLayout->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_MAP_DISP_LAYOUT, pContext);

	delete pContext;

	/* Init map view */
	char buf[BUFSIZ];
	GetModuleFileName(NULL, buf, BUFSIZ - 1);	
	m_pDoc->m_IniFile = buf;
	CString AppName(AfxGetAppName());
	AppName += ".exe";
	m_pDoc->m_IniFile.Replace(AppName, "");
	m_pDoc->m_LoadFile = m_pDoc->m_IniFile + STR_MD_LOAD;
	m_pDoc->m_IniFile += STR_MV ".ini";

	/* Initialize for scroll bar (S)
	m_pDoc->m_LineMax  = 1;
	m_pDoc->m_PageLine = 1;
	m_pDoc->m_CoulmMax = 1;
	m_pDoc->m_PageCoulm= 1;
	/* Initialize for scroll bar (E)	*/
	
	m_pDoc->m_CurX = 0;		// ���݈ʒu(x)
	m_pDoc->m_CurY = 0;		// ���݈ʒu(Y)

	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "DispMode", TRUE, m_pDoc->m_DispMode, 0);
	m_pDoc->m_nFormat = DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX | DT_CENTER | DT_NOCLIP;
	
	m_pDoc->m_Setting	= (_T("Setting"));
	m_pDoc->m_LoadFile	= (_T(""));
	m_pDoc->m_DispMode	= (0);
	m_pDoc->m_FNLOC		= (_T(""));
	m_pDoc->m_MID		= (_T(""));


	/* Init colors for each category (S) */
	m_pDoc->s1 = "G_CategoryColor";
	for( int i = 0 ; i < 256 ; i++){
		sprintf(m_pDoc->ch, "%03d", i);
		m_pDoc->s2 = m_pDoc->ch;
		m_pDoc->s3 = m_pDoc->s1 + m_pDoc->s2;
		GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, (LPCTSTR)m_pDoc->s3, TRUE, m_pDoc->colors, 3, 255);
		m_pDoc->m_gCategoryColor[i] = RGB(m_pDoc->colors[0], m_pDoc->colors[1], m_pDoc->colors[2]);
	}
	/* Init colors for each category (E) */

	/* Init variables */
	m_pDoc->m_IsLoadedMap = false;
	


	m_LoadMapBtn = (CButton*)GetDlgItem(IDC_BTN_LOAD_MAP);
	m_LoadMapBtn->EnableWindow(TRUE);
	

	/* Initialize Index pickup list (S) */
	CListCtrl*	m_IndexPickupList = (CListCtrl*)GetDlgItem(IDC_LIST_INDEX_PICKUP);;
	m_IndexPickupList->InsertColumn(0, "Step", LVCFMT_CENTER, 80);
	m_IndexPickupList->InsertColumn(1, "Index", LVCFMT_CENTER, 80);
	

	/* Initialize Index pickup list (E) */

	return TRUE;
}

void CCMVDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCMVDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}


	if (m_pDoc->m_IsLoadedMap){

		//m_MapLayout->InitMapView();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCMVDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Automation servers should not exit when a user closes the UI
//  if a controller still holds on to one of its objects.  These
//  message handlers make sure that if the proxy is still in use,
//  then the UI is hidden but the dialog remains around if it
//  is dismissed.

void CCMVDlg::OnClose() 
{
	if(m_pDoc->m_IsLoadedMap == true) {
		for(int i = 0; i < m_pDoc->m_LineMax; i++) {
			delete[] m_pDoc->LEDArrayInfo[i];
		}
		delete[] m_pDoc->LEDArrayInfo;

		delete[] m_pDoc->xAxisRectArray;
		delete[] m_pDoc->yAxisRectArray;
	}

	delete m_pDoc;
	CDialog::OnClose();
}

void CCMVDlg::GetCMV(CCMVApp* pCMVInfo){
	pCMV = pCMVInfo;
}


void CCMVDlg::OnBtnLoadMap() 
{
	CFileDialog FileDialog(TRUE, "*.*", NULL, OFN_HIDEREADONLY, "");

	if(FileDialog.DoModal() == IDOK)
	{
		CString PathName = FileDialog.GetPathName();

		LoadMapFile(PathName);

		m_MapLayout->Invalidate();
	}
	
	m_pDoc->m_IsLoadedMap = true;
	m_LoadMapBtn->EnableWindow(FALSE);

	UpdateWindow();
}



void CCMVDlg::LoadMapFile(CString pathMapFile) {

	if (m_pDoc->MapD.DataRW(TRUE, pathMapFile)) {

		m_pDoc->m_CoulmMax = m_pDoc->MapD.COLCT;
		m_pDoc->m_LineMax  = m_pDoc->MapD.ROWCT;
		
		int idx = m_pDoc->MapD.FNLOC / 90;
		if (0 > idx || 3 < idx || !(m_pDoc->m_DispMode & m_pDoc->DispFNLOC )) {
			idx = 4;
		}
		char *dirs[][5] = {
			{ "�a", "�k", "�s", "�q", "  " },
			{ "��", "��", "��", "�E", "  " },
		};

		if (m_pDoc->m_DispMode & m_pDoc->DispMID) {
			m_pDoc->m_MID.Format(" MID=%s", m_pDoc->MapD.MID);
		} else {
			m_pDoc->m_MID = "";
		}

		/* Put mapfile to str variable (S) */
		for (int y = 0; y < m_pDoc->m_LineMax; y++) {
			m_pDoc->str += m_pDoc->MapD.BINLT.Mid(m_pDoc->m_CoulmMax * y, m_pDoc->m_CoulmMax) + "\n";
		}
		/* Put mapfile to str variable (E) */

		/* Initialize LEDArrayInfo (S) */
		m_pDoc->LEDArrayInfo = new LEDInfo* [m_pDoc->m_LineMax * sizeof(LEDInfo *)];
		for(int i = 0; i < m_pDoc->m_LineMax; i++) {
			m_pDoc->LEDArrayInfo[i] = new LEDInfo [m_pDoc->m_CoulmMax * sizeof(LEDInfo)];
		}

		/* Create axisRects for display axis (S) */
		m_pDoc->xAxisRectArray = new CRect [m_pDoc->m_CoulmMax * sizeof(CRect)];
		m_pDoc->yAxisRectArray = new CRect [m_pDoc->m_LineMax * sizeof(CRect)];

		m_MapLayout->InitMapView();
	}
}

void CCMVDlg::OnBtnZoomIn() 
{
	if (m_pDoc->m_Zoom < 7) {
		m_pDoc->m_Zoom += 1;
	    m_MapLayout->OnUpdateMapView();
	}
}

void CCMVDlg::OnBtnZoomOut() 
{
	if (m_pDoc->m_Zoom > 1 ) {
		m_pDoc->m_Zoom = m_pDoc->m_Zoom - 1;
		m_MapLayout->OnUpdateMapView();
	}
	
}

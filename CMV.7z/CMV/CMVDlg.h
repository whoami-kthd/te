// CMVDlg.h : header file
//

#if !defined(AFX_CMVDLG_H__F57C7E05_8647_4C2C_A025_6E022E4AE9B9__INCLUDED_)
#define AFX_CMVDLG_H__F57C7E05_8647_4C2C_A025_6E022E4AE9B9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CMV_Map_View.h"
#include "CMV_ToolDispInfo.h"
#include "CMV_MapJump.h"
#include "CMV_Doc.h"


/////////////////////////////////////////////////////////////////////////////
// CCMVDlg dialog

class CCMVDlg : public CDialog
{
	DECLARE_DYNAMIC(CCMVDlg);

// Construction
public:
	CCMVDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CCMVDlg();

	CCMVApp *pCMV;
	void	GetCMV(CCMVApp* pCMVInfo);

// Dialog Data
	//{{AFX_DATA(CCMVDlg)
	enum { IDD = IDD_CMV_DIALOG };
	CListCtrl	m_ChipListCtrl;
	CListCtrl	m_ListIndexCtrl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCMVDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL


public:
	bool m_IsLoadedMap;


private:
	CMV_Map_View*		m_MapLayout;
	CMV_ToolDispInfo*	m_pToolDisp;
	CMV_MapJump*		m_pMapJump;
	CMV_Doc*			m_pDoc;

	int					m_nZoom;
	int					m_RowMax;
	int					m_ColMax;

	CButton*			m_LoadMapBtn;

public:
	void LoadMapFile(CString pathMapFile);
	void AddIndexPickup(CListCtrl &ctrl, int row, int col, const char *str);
	void OnUpdateIndexPickupList();
	void OnUpdateChipList();

// Implementation
protected:
	HICON m_hIcon;

	BOOL CanExit();

	// Generated message map functions
	//{{AFX_MSG(CCMVDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnBtnLoadMap();
	afx_msg void OnBtnZoomIn();
	afx_msg void OnBtnZoomOut();
	afx_msg void OnItemdblclickListIndexPickup(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickListIndexPickup(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangedListIndexPickup(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChipListCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMVDLG_H__F57C7E05_8647_4C2C_A025_6E022E4AE9B9__INCLUDED_)

#pragma once

#include "stdafx.h"
#include <vector>
#include "Pos.h"

using namespace std;

#define LED_MODE				1
#define INDEX_MODE				2

// Define PI constant
#define PI 3.141592653589793

#define ARRAY_LENGTH(_array)	(sizeof(_array)/sizeof(_array[0]))

#define DEG_TO_RAD(_deg)		(_deg * PI / 180)

#define RAD_TO_DEG(_rad)		(_rad * 180 / PI)

#define NUMBER_ZOOM_MAX			20
#define NUMBER_SHAPE_MAX		20

#define	TextVisibleHight		14
#define	TextVisibleWidth		9

// #DDT(1506): Extend map size
#define	X_MAX					1000
#define	Y_MAX					1000

#define TYOUSEI_TOP				28 /*�㑤�����l*/
#define TYOUSEI_LEFT			28 /*���������l*/

struct IndexModeStruct
{
	int xCoordirate;
	int yCoordirate;
};


struct LEDInfo
{
	int				top;
	int				left;
	int				right;
	int				bottom;
	unsigned char	ch;
	bool			isGoodBin;
	bool			isInGroup;
	int			    index;
};


#define SIZE_NUMBER			7
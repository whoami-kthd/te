// CMV_MapJump.cpp : implementation file
//

#include "stdafx.h"
#include "cmv.h"
#include "CMV_MapJump.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump

IMPLEMENT_DYNCREATE(CMV_MapJump, CEditView)

CMV_MapJump::CMV_MapJump()
{
}

CMV_MapJump::~CMV_MapJump()
{
}


BEGIN_MESSAGE_MAP(CMV_MapJump, CView)
	//{{AFX_MSG_MAP(CMV_MapJump)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump drawing

void CMV_MapJump::OnDraw(CDC* pDC)
{
	CRect rc;
	GetClientRect(&rc);

	pDC->FillSolidRect(rc, (::GetSysColor(COLOR_BTNFACE)));

	CPen pen(PS_SOLID, 1, RGB(80, 80, 80) );
	CPen* pOldPen = pDC->SelectObject(&pen);

	pDC->SelectObject(&m_pDoc->myFont);

	// size unit
	int xSizeUnit = (rc.right - rc.left)/3;
	int ySizeUnit = (rc.bottom - rc.top)/2;

	// Draw edge of table
	pDC->MoveTo(rc.left, rc.bottom);
	pDC->LineTo(rc.right, rc.bottom);
	pDC->MoveTo(rc.left, rc.top);
	pDC->LineTo(rc.right, rc.top);
	pDC->MoveTo(rc.left, rc.top);
	pDC->LineTo(rc.left, rc.bottom);
	pDC->MoveTo(rc.right, rc.top);
	pDC->LineTo(rc.right, rc.bottom);
	
	pDC->MoveTo(rc.left + xSizeUnit, rc.top);
	pDC->LineTo(rc.left + xSizeUnit, rc.bottom);

	pDC->MoveTo(rc.left + 2*xSizeUnit, rc.top);
	pDC->LineTo(rc.left + 2*xSizeUnit, rc.bottom);

	pDC->MoveTo(rc.left + xSizeUnit, rc.top+ySizeUnit);
	pDC->LineTo(rc.right, rc.top+ySizeUnit);

	CRect WorkRect = rc;
	WorkRect.right = rc.left + xSizeUnit;
	pDC->DrawText(_T("Index"), &WorkRect, m_pDoc->m_nFormat);

	WorkRect.left = rc.left + xSizeUnit;
	WorkRect.right = rc.left + 2*xSizeUnit;
	WorkRect.bottom = rc.left + ySizeUnit;
	pDC->DrawText(_T("X"), &WorkRect, m_pDoc->m_nFormat);

	WorkRect.left = rc.left + xSizeUnit;
	WorkRect.right = rc.left + 2*xSizeUnit;
	WorkRect.bottom = rc.bottom;
	WorkRect.top = rc.top + xSizeUnit;
	pDC->DrawText(_T("Y"), &WorkRect, m_pDoc->m_nFormat);
}

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump diagnostics

#ifdef _DEBUG
void CMV_MapJump::AssertValid() const
{
	CView::AssertValid();
}

void CMV_MapJump::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump message handlers
void CMV_MapJump::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}


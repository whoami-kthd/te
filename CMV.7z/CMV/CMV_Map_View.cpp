// CMV_Map_View.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMV_Map_View.h"
#include "CMV_Util.h"
#include "MemDC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View

IMPLEMENT_DYNAMIC(CMV_Map_View, CScrollView)

CMV_Map_View::CMV_Map_View()
{
}

CMV_Map_View::~CMV_Map_View()
{
}


BEGIN_MESSAGE_MAP(CMV_Map_View, CScrollView)
	//{{AFX_MSG_MAP(CMV_Map_View)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View drawing

void CMV_Map_View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	m_pDoc ->m_Zoom = 1;
	_SetScrollSizes();
}


void CMV_Map_View::OnDraw(CDC* pDC)
{
	ASSERT(MM_TEXT == pDC->GetMapMode());
	ASSERT(CPoint(0, 0) == pDC->GetViewportOrg());

	if (m_pDoc->m_IsLoadedMap == true)
	{
//		InitMapView(MapLayoutRect);
		
		CRect rcClient(0, 0, 0, 0);
		GetClientRect(rcClient);
		const int cx = rcClient.right;  // view client area width
		const int cy = rcClient.bottom; // view client area height

		CMemDC dcDraw(pDC, cx, cy);

//		DrawBackgound(&dcDraw);
		DrawLEDs(&dcDraw, pDC);

		CRect rcClip(0, 0, 0, 0);
		pDC->GetClipBox(rcClip);
		pDC->BitBlt(rcClip.left, rcClip.top, rcClip.Width(), rcClip.Height(), 
					&dcDraw, rcClip.left, rcClip.top, SRCCOPY);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View diagnostics

#ifdef _DEBUG
void CMV_Map_View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMV_Map_View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View message handlers

void CMV_Map_View::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}


void CMV_Map_View::InitMapView()
{
	int i, j;
	/* Get rect of LEDArrayInfo (S) */
	CRect Rect, Rect2, rc;

//	GetClientRect(rc);

	Rect2 = MapLayoutRect;
	Rect2.top    = MapLayoutRect.top  + TYOUSEI_TOP;
	Rect2.left   = MapLayoutRect.left + TYOUSEI_LEFT;
	Rect2.bottom = MapLayoutRect.top  + m_pDoc->m_SizeY - 1;
	Rect2.right  = MapLayoutRect.left + m_pDoc->m_SizeX - 1;

	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax ; i++){
		Rect.top    = Rect2.top + ((i - m_pDoc->m_CurY) * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY)) + m_pDoc->m_LEDPitchY;
//		if(Rect.top > rc.bottom) break;

		for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax ; j++){
			Rect.left   = Rect2.left + ((j - m_pDoc->m_CurX) * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX)) + m_pDoc->m_LEDPitchX;
//			if(Rect.left > rc.right) break;

			Rect.bottom = Rect.top  + m_pDoc->m_SizeY - 1;
			Rect.right  = Rect.left + m_pDoc->m_SizeX - 1;

			m_pDoc->LEDArrayInfo[i][j].top    = Rect.top;
			m_pDoc->LEDArrayInfo[i][j].left   = Rect.left;
			m_pDoc->LEDArrayInfo[i][j].right  = Rect.right;
			m_pDoc->LEDArrayInfo[i][j].bottom = Rect.bottom;

			m_pDoc->s2 = m_pDoc->str.Mid( ((m_pDoc->m_CoulmMax + 1) * i) + j, 1 );
			strcpy(m_pDoc->ch, (LPCTSTR)(m_pDoc->s2));
			m_pDoc->LEDArrayInfo[i][j].ch = m_pDoc->ch[0];

			if(m_pDoc->MapD.BCEQU.Find(CString(m_pDoc->ch[0])) != -1) {
				m_pDoc->LEDArrayInfo[i][j].isGoodBin = true;
			}else {
				m_pDoc->LEDArrayInfo[i][j].isGoodBin = false;
			}

			m_pDoc->LEDArrayInfo[i][j].isInGroup = false;
			m_pDoc->LEDArrayInfo[i][j].index	 = NULL;
		}
	}
	/* Get rect of LEDArrayInfo (E) */

	for(i = 0; i < m_pDoc->m_CoulmMax; i++) {
		m_pDoc->xAxisRectArray[i].left = m_pDoc->LEDArrayInfo[0][i].left;
		m_pDoc->xAxisRectArray[i].right = m_pDoc->LEDArrayInfo[0][i].right;
		m_pDoc->xAxisRectArray[i].bottom = m_pDoc->LEDArrayInfo[0][i].top;
		m_pDoc->xAxisRectArray[i].top = m_pDoc->LEDArrayInfo[0][i].top - TYOUSEI_TOP;
	}

	for(i = 0; i < m_pDoc->m_LineMax; i++) {		
		m_pDoc->yAxisRectArray[i].right = m_pDoc->LEDArrayInfo[i][0].left;
		m_pDoc->yAxisRectArray[i].left  = m_pDoc->LEDArrayInfo[i][0].left - TYOUSEI_LEFT;
		m_pDoc->yAxisRectArray[i].top = m_pDoc->LEDArrayInfo[i][0].top;
		m_pDoc->yAxisRectArray[i].bottom  = m_pDoc->LEDArrayInfo[i][0].bottom;
	}	
	/* Create axisRects for display axis (E) */

	m_mapDispSize.cx = m_pDoc->xAxisRectArray[m_pDoc->m_CoulmMax-1].right + TYOUSEI_LEFT;
	m_mapDispSize.cy = m_pDoc->yAxisRectArray[m_pDoc->m_LineMax-1].bottom + TYOUSEI_TOP;

/* If size of LEDs bitmap is smaller than size of client rect,
   assign LEDs bitmap size equal to client rect size (S) */
	GetClientRect(rc);	
	if (m_mapDispSize.cx <= rc.right) {
		m_mapDispSize.cx = rc.right;
	}

	if (m_mapDispSize.cy <= rc.bottom) {
		m_mapDispSize.cy = rc.bottom;
	}
// (E)

	_SetScrollSizes();
}


void CMV_Map_View::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	CScrollView::OnPrepareDC(pDC, pInfo);

	pDC->SetMapMode(MM_TEXT);          // force map mode to MM_TEXT
	
	CRect rc;
	GetClientRect(rc);

	pDC->SetViewportOrg(CPoint(0, 0)); // force viewport origin to zero
}


BOOL CMV_Map_View::OnScrollBy(CSize sizeScroll, BOOL bDoScroll) 
{
	int xOrig, x;
	int yOrig, y;

	// don't scroll if there is no valid scroll range (ie. no scroll bar)
	CScrollBar* pBar;
	DWORD dwStyle = GetStyle();
	pBar = GetScrollBarCtrl(SB_VERT);
	if ((pBar != NULL && !pBar->IsWindowEnabled()) ||
		(pBar == NULL && !(dwStyle & WS_VSCROLL)))
	{
		// vertical scroll bar not enabled
		sizeScroll.cy = 0;
	}
	pBar = GetScrollBarCtrl(SB_HORZ);
	if ((pBar != NULL && !pBar->IsWindowEnabled()) ||
		(pBar == NULL && !(dwStyle & WS_HSCROLL)))
	{
		// horizontal scroll bar not enabled
		sizeScroll.cx = 0;
	}

	// adjust current x position
	xOrig = x = GetScrollPos(SB_HORZ);
	int xMax = GetScrollLimit(SB_HORZ);
	x += sizeScroll.cx;
	if (x < 0)
		x = 0;
	else if (x > xMax)
		x = xMax;

	// adjust current y position
	yOrig = y = GetScrollPos(SB_VERT);
	int yMax = GetScrollLimit(SB_VERT);
	y += sizeScroll.cy;
	if (y < 0)
		y = 0;
	else if (y > yMax)
		y = yMax;

	// did anything change?
	if (x == xOrig && y == yOrig)
		return FALSE;

	if (bDoScroll)
	{
      Invalidate();
		if (x != xOrig)
			SetScrollPos(SB_HORZ, x);
		if (y != yOrig)
			SetScrollPos(SB_VERT, y);
	} 
	return TRUE;
}


void CMV_Map_View::_SetScrollSizes()
{
	CSize sizeView(100, 100);
	if(m_pDoc->m_LoadFile)
	{
	  CSize size = GetMapDispSize();
	  sizeView.cx = (int)(size.cx * m_pDoc->m_Zoom);
	  sizeView.cy = (int)(size.cy * m_pDoc->m_Zoom);
	}

   SetScrollSizes(MM_TEXT, sizeView);
}


CSize CMV_Map_View::GetMapDispSize(void)
{
	return m_mapDispSize;
}


int CMV_Map_View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
//	CSize sizeView(100, 100);
//	SetScrollSizes(MM_TEXT, sizeView);
 
	_SetScrollSizes();

	MapLayoutRect.top = 0;
	MapLayoutRect.bottom = 5000;
	MapLayoutRect.left = 0;
	MapLayoutRect.right = 5000;

	m_pDoc->m_MiniSizeX = 3;
	m_pDoc->m_MiniSizeY = 3;

	m_pDoc->m_MiniPitchLEDX = 1;
	m_pDoc->m_MiniPitchLEDY = 1;

	m_pDoc->MapSize = 6;
	m_pDoc->m_Zoom  = 1;

	m_pDoc->m_toolSizeX  = 2;
	m_pDoc->m_toolSizeY  = 2;

	m_pDoc->MapSize *= m_pDoc->m_Zoom;

	m_pDoc->m_SizeX = m_pDoc->m_MiniSizeX * m_pDoc->MapSize;
	m_pDoc->m_SizeY = m_pDoc->m_MiniSizeY * m_pDoc->MapSize;

	m_pDoc->m_LEDPitchX = m_pDoc->m_MiniPitchLEDX * m_pDoc->MapSize;
	m_pDoc->m_LEDPitchY = m_pDoc->m_MiniPitchLEDY * m_pDoc->MapSize;

	m_pDoc->m_toolPitchX = 2 * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX);	//  suppose that value of m_toolPitchX
	m_pDoc->m_toolPitchY = 2 * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY); //  suppose that value of m_toolPitchY
	
	return 0;
}


void CMV_Map_View::DrawLEDs(CMemDC* pDCDraw, CDC *pDC)
{
	CPoint point = GetScrollPosition();

	CRect rcClient(0, 0, 0, 0);
    GetClientRect(rcClient);

	const int cx = rcClient.right;				// view client area width
	const int cy = rcClient.bottom;				// view client area height
	const int bx = GetMapDispSize().cx;			// source bitmap width
	const int by = GetMapDispSize().cy;			// source bitmap height
	const int vx = (int)(bx * m_pDoc->m_Zoom);  // virtual document width
	const int vy = (int)(by * m_pDoc->m_Zoom);  // virtual document height
	const int xPos = point.x;					// horizontal scroll position
	const int yPos = point.y;					// vertical scroll position

	// source and destination cordinates and sizes
	int xSrc, ySrc, nSrcWidth, nSrcHeight, xDst, yDst, nDstWidth, nDstHeight;

	if(vx > cx)
	{
	  xSrc = (int)(xPos / m_pDoc->m_Zoom);
	  nSrcWidth = bx - xSrc;
	  xDst = 0;
	  nDstWidth = vx - xPos;
	}
	else 
	{
	  xSrc = 0;
	  nSrcWidth = bx;
	  xDst = 0;
	  nDstWidth = vx;
	}

	if(vy > cy)
	{
	  ySrc = (int)(yPos / m_pDoc->m_Zoom);
	  nSrcHeight = by - ySrc;
	  yDst = 0;
	  nDstHeight = vy - yPos;
	}
	else 
	{
	  ySrc = 0;
	  nSrcHeight = by;
	  yDst = 0;
	  nDstHeight = vy;
	}


	CMemDC pDCTemp(pDC, bx, by);
	/* Draw background color */
	pDCTemp.SelectObject(&m_brushBack);
	pDCTemp.PatBlt(0, 0, bx, by, PATCOPY);

	CRect WorkRect;
	int i, j;
	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax ; i++){
		for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax ; j++){
			
			WorkRect.left	= m_pDoc->LEDArrayInfo[i][j].left;
			WorkRect.top	= m_pDoc->LEDArrayInfo[i][j].top;
			WorkRect.bottom = m_pDoc->LEDArrayInfo[i][j].bottom;
			WorkRect.right  = m_pDoc->LEDArrayInfo[i][j].right;

			CBrush brush(m_pDoc->m_gCategoryColor[(int)(m_pDoc->LEDArrayInfo[i][j].ch)]);
			pDCTemp.FillRect( WorkRect, &brush );
			pDCTemp.SetBkMode(TRANSPARENT);

			pDCTemp.DrawText(m_pDoc->LEDArrayInfo[i][j].ch, &WorkRect, m_pDoc->m_nFormat);
		}
	}

	/* Create axisRects for display axis (S) */
	CString text;	
	for(i = 0; i < m_pDoc->m_CoulmMax; i++) {
		text.Format(_T("%d"), i);
		pDCTemp.DrawText( text, m_pDoc->xAxisRectArray[i], m_pDoc->m_nFormat);
	}
	
	for(i = 0; i < m_pDoc->m_LineMax; i++) {
		text.Format(_T("%d"), i);
		pDCTemp.DrawText( text, m_pDoc->yAxisRectArray[i], m_pDoc->m_nFormat);
	}	
	/* Create axisRects for display axis (E) */
	
	pDCDraw->SetStretchBltMode(HALFTONE);
	pDCDraw->StretchBlt(xDst, yDst, nDstWidth, nDstHeight, &pDCTemp, xSrc, ySrc, nSrcWidth, nSrcHeight, SRCCOPY);
}


void CMV_Map_View::OnUpdateMapView(void)
{
	m_pDoc->MapSize *= m_pDoc->m_Zoom;

	m_pDoc->m_SizeX = m_pDoc->m_MiniSizeX * m_pDoc->MapSize;
	m_pDoc->m_SizeY = m_pDoc->m_MiniSizeY * m_pDoc->MapSize;

	m_pDoc->m_LEDPitchX = m_pDoc->m_MiniPitchLEDX * m_pDoc->MapSize;
	m_pDoc->m_LEDPitchY = m_pDoc->m_MiniPitchLEDY * m_pDoc->MapSize;

	m_pDoc->m_toolPitchX = 2 * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX);	//  suppose that value of m_toolPitchX
	m_pDoc->m_toolPitchY = 2 * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY); //  suppose that value of m_toolPitchY

	_SetScrollSizes();
	Invalidate();
	UpdateWindow();
}


BOOL CMV_Map_View::OnEraseBkgnd(CDC* pDC) 
{
	return CScrollView::OnEraseBkgnd(pDC);
}


void CMV_Map_View::DrawBackgound(CMemDC* pDCDraw)
{
	ASSERT_VALID(pDCDraw);
	ASSERT(NULL != m_brushBack.GetSafeHandle());

	CRect rcClient(0, 0, 0, 0);
	GetClientRect(rcClient);
	pDCDraw->SelectObject(&m_brushBack);
	pDCDraw->PatBlt(0, 0, rcClient.right, rcClient.bottom, PATCOPY);
}
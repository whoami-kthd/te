// CMV_Map_View.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMV_Map_View.h"
#include "CMV_Util.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View

IMPLEMENT_DYNCREATE(CMV_Map_View, CScrollView)

CMV_Map_View::CMV_Map_View()
{
}

CMV_Map_View::~CMV_Map_View()
{
}


BEGIN_MESSAGE_MAP(CMV_Map_View, CScrollView)
	//{{AFX_MSG_MAP(CMV_Map_View)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View drawing

void CMV_Map_View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	CSize sizeTotal;
	// TODO: calculate the total size of this view
	sizeTotal.cx = sizeTotal.cy = 100;
	SetScrollSizes(MM_TEXT, sizeTotal);
}


void CMV_Map_View::OnDraw(CDC* pDC)
{
	// CDocument* pDoc = GetDocument();
	// TODO: add draw code here
	if (m_pDoc->m_IsLoadedMap == true)
	{
		CRect rc, WorkRect;
		GetClientRect(&rc);

		int i, j;
		for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax ; i++){
			for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax ; j++){

				WorkRect.left   = m_pDoc->LEDArrayInfo[i][j].left;
				WorkRect.top    = m_pDoc->LEDArrayInfo[i][j].top;
				WorkRect.bottom = m_pDoc->LEDArrayInfo[i][j].bottom;
				WorkRect.right  = m_pDoc->LEDArrayInfo[i][j].right;

				CBrush brush(m_pDoc->m_gCategoryColor[(int)(m_pDoc->LEDArrayInfo[i][j].ch)]);
				
				pDC->FillRect(WorkRect, &brush);
				pDC->SetBkMode(TRANSPARENT);

				pDC->DrawText(m_pDoc->LEDArrayInfo[i][j].ch, &WorkRect, m_pDoc->m_nFormat);
			}
		}

		/* Create axisRects for display axis (S) */
		CString text;
		for(i = 0; i < m_pDoc->m_CoulmMax; i++) {
			text.Format(_T("%d"), i);
			pDC->DrawText( text, m_pDoc->xAxisRectArray[i], m_pDoc->m_nFormat);
		}
		
		for(i = 0; i < m_pDoc->m_LineMax; i++) {
			text.Format(_T("%d"), i);
			pDC->DrawText( text, m_pDoc->yAxisRectArray[i], m_pDoc->m_nFormat);
		}	
		/* Create axisRects for display axis (E) */

		//pDC->BitBlt(0, 0, rc.Width(), rc.Height(), pDC, 0, 0, SRCCOPY);
		
		Invalidate(false);
		UpdateWindow();
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View diagnostics

#ifdef _DEBUG
void CMV_Map_View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMV_Map_View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View message handlers

void CMV_Map_View::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}


void CMV_Map_View::SetScale(double scale, bool isZoom)
{
	m_pDoc->m_Scale = scale;
	// Get region
	CRect rect;
	GetClientRect(&rect);

	// Store previous scroll bar
	double Vpercent = 0.0;
	if(GetScrollLimit(SB_VERT) != 0){
		Vpercent = (double)GetScrollPos(SB_VERT)/(double)GetScrollLimit(SB_VERT);
	}
	double Hpercent = 0.0;
	if(GetScrollLimit(SB_HORZ) != 0){
		Hpercent = (double)GetScrollPos(SB_HORZ)/(double)GetScrollLimit(SB_HORZ);
	}

	// Set scroll size
	long wndStyle = GetWindowLong(GetSafeHwnd(), GWL_STYLE);
	int HSize = ((wndStyle & WS_HSCROLL) == 0) ? 0 : GetSystemMetrics(SM_CXHSCROLL);
	int VSize = ((wndStyle & WS_VSCROLL) == 0) ? 0 : GetSystemMetrics(SM_CXVSCROLL);

	CSize size = rect.Size();
	CSize scaleSize = CMV_Util::ScaleXYSize(m_pDoc->m_sizebmp,m_pDoc->m_imgCount,m_pDoc->m_imgCount) + CSize(HSize, VSize);
	SetScrollSizes(MM_TEXT, CMV_Util::GetMaxSize(CMV_Util::ScaleSize(scaleSize, scale),size));

	// Calculate the scroll position
	GetClientRect(&rect);
//	CPoint center = GetRootPoint();
	
	int HPos = 0, VPos = 0;
	// Zooming center is current scroll bar position
	VPos = CMV_Util::Round(Vpercent * GetScrollLimit(SB_VERT));
	HPos = CMV_Util::Round(Hpercent * GetScrollLimit(SB_HORZ));
	
	// Handle exception case: restore scroll bar whel scale is 1.0
	if (scale == 1.0) {
		VPos = 0;
		HPos = 0;
	}
	
	// Handle exception case: zooming center is center of display when zoom for the first time
		if (Vpercent == 0) VPos = CMV_Util::Round(0.5 * GetScrollLimit(SB_VERT));
		if (Hpercent == 0) HPos = CMV_Util::Round(0.5 * GetScrollLimit(SB_HORZ));

	// Set scroll position
	SetScrollPos(SB_HORZ, HPos);
	SetScrollPos(SB_VERT, VPos);
}


int CMV_Map_View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	SetScale(1, true);
	SetScroll();

	return 0;
}


void CMV_Map_View::SetScroll(void)
{
	// Get region
	CRect rect;
	GetClientRect(&rect);

	const double SCROLL_AREA_RATE = 0.1;
	// Get current scroll position
	int HPos = GetScrollPos(SB_HORZ);
	int VPos = GetScrollPos(SB_VERT);

	int diff = rect.CenterPoint().y - HPos;
	if ((diff < rect.Width() * SCROLL_AREA_RATE) || (diff > rect.Width() * (1-SCROLL_AREA_RATE))) {
		// Hozirontal
		HPos = (m_pDoc->m_Scale == 1.0) ? 0 : (rect.CenterPoint().y - rect.Width()/2);
		if(HPos < 0){
			HPos = 0;
		}else if(HPos > GetScrollLimit(SB_HORZ)){
			HPos = GetScrollLimit(SB_HORZ);
		}
	}
	diff = rect.CenterPoint().y - VPos;
	if ((diff < rect.Height() * SCROLL_AREA_RATE) || (diff > rect.Height() * (1 - SCROLL_AREA_RATE))) {
		// Vertical
		VPos = (m_pDoc->m_Scale == 1.0) ? 0 : (rect.CenterPoint().y - rect.Height()/2);
		if(VPos < 0){
			VPos = 0;
		}else if(VPos > GetScrollLimit(SB_VERT)){
			VPos = GetScrollLimit(SB_VERT);
		}
	}

	// Set scroll position
	SetScrollPos(SB_HORZ, HPos);
	SetScrollPos(SB_VERT, VPos);
}

void CMV_Map_View::OnSize(UINT nType, int cx, int cy) 
{
	CScrollView::OnSize(nType, cx, cy);
	
	SetScroll();
	
}

void CMV_Map_View::InitMapView(void)
{
	m_pDoc->MapSize *= m_pDoc->m_Zoom ;

	m_pDoc->m_MiniSizeX = 3;
	m_pDoc->m_MiniSizeY = 3;
	
	m_pDoc->m_MiniPitchLEDX = 1;
	m_pDoc->m_MiniPitchLEDY = 1;

	m_pDoc->m_SizeX = m_pDoc->m_MiniSizeX * m_pDoc->MapSize;
	m_pDoc->m_SizeY = m_pDoc->m_MiniSizeY * m_pDoc->MapSize;

	m_pDoc->m_LEDPitchX = m_pDoc->m_MiniPitchLEDX * m_pDoc->MapSize;
	m_pDoc->m_LEDPitchY = m_pDoc->m_MiniPitchLEDY * m_pDoc->MapSize;

	m_pDoc->m_toolSizeX  = 2;
	m_pDoc->m_toolSizeY  = 2;

	m_pDoc->m_toolPitchX = 2 * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX);	//  suppose that value of m_toolPitchX
	m_pDoc->m_toolPitchY = 2 * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY); //  suppose that value of m_toolPitchY

	int i, j;
	
	/* Get rect of LEDArrayInfo (S) */
	CRect Rect, Rect2, rc;

	/* Get rect of map viewer */
	this->GetClientRect(&rc);
	
	Rect2 = rc;
	Rect2.top    = rc.top  + TYOUSEI_TOP;
	Rect2.left   = rc.left + TYOUSEI_LEFT;
	Rect2.bottom = rc.top  + m_pDoc->m_SizeY - 1;
	Rect2.right  = rc.left + m_pDoc->m_SizeX - 1;

	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax ; i++){
		Rect.top    = Rect2.top + ((i - m_pDoc->m_CurY) * (m_pDoc->m_SizeY + m_pDoc->m_LEDPitchY)) + m_pDoc->m_LEDPitchY;
		if(Rect.top > rc.bottom) break;

		for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax ; j++){
			Rect.left   = Rect2.left + ((j - m_pDoc->m_CurX) * (m_pDoc->m_SizeX + m_pDoc->m_LEDPitchX)) + m_pDoc->m_LEDPitchX;
			if(Rect.left > rc.right) break;

			Rect.bottom = Rect.top  + m_pDoc->m_SizeY - 1;
			Rect.right  = Rect.left + m_pDoc->m_SizeX - 1;

			m_pDoc->LEDArrayInfo[i][j].top    = Rect.top;
			m_pDoc->LEDArrayInfo[i][j].left   = Rect.left;
			m_pDoc->LEDArrayInfo[i][j].right  = Rect.right;
			m_pDoc->LEDArrayInfo[i][j].bottom = Rect.bottom;

			m_pDoc->s2 = m_pDoc->str.Mid( ((m_pDoc->m_CoulmMax + 1) * i) + j, 1 );
			strcpy(m_pDoc->ch, (LPCTSTR)(m_pDoc->s2));
			m_pDoc->LEDArrayInfo[i][j].ch = m_pDoc->ch[0];

			if(m_pDoc->MapD.BCEQU.Find(CString(m_pDoc->ch[0])) != -1) {
				m_pDoc->LEDArrayInfo[i][j].isGoodBin = true;
			}else {
				m_pDoc->LEDArrayInfo[i][j].isGoodBin = false;
			}

			m_pDoc->LEDArrayInfo[i][j].isInGroup = false;
			m_pDoc->LEDArrayInfo[i][j].index	 = NULL;
		}
	}
	/* Get rect of LEDArrayInfo (E) */

	for(i = 0; i < m_pDoc->m_CoulmMax; i++) {
		m_pDoc->xAxisRectArray[i].left = m_pDoc->LEDArrayInfo[0][i].left;
		m_pDoc->xAxisRectArray[i].right = m_pDoc->LEDArrayInfo[0][i].right;
		m_pDoc->xAxisRectArray[i].bottom = m_pDoc->LEDArrayInfo[0][i].top;
		m_pDoc->xAxisRectArray[i].top = m_pDoc->LEDArrayInfo[0][i].top - TYOUSEI_TOP;
	}

	for(i = 0; i < m_pDoc->m_LineMax; i++) {		
		m_pDoc->yAxisRectArray[i].right = m_pDoc->LEDArrayInfo[i][0].left;
		m_pDoc->yAxisRectArray[i].left  = m_pDoc->LEDArrayInfo[i][0].left - TYOUSEI_LEFT;
		m_pDoc->yAxisRectArray[i].top = m_pDoc->LEDArrayInfo[i][0].top;
		m_pDoc->yAxisRectArray[i].bottom  = m_pDoc->LEDArrayInfo[i][0].bottom;
	}	
	/* Create axisRects for display axis (E) */
}


/*
BOOL CMV_Map_View::OnEraseBkgnd(CDC* pDC)
{
	// do nothing
	return FALSE;
}
*/
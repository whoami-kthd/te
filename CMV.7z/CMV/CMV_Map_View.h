#if !defined(AFX_CMV_MAP_VIEW_H__70D57CD3_8A94_495E_87C9_A223E42379AE__INCLUDED_)
#define AFX_CMV_MAP_VIEW_H__70D57CD3_8A94_495E_87C9_A223E42379AE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_Map_View.h : header file
//

#include "CMV_Doc.h"
#include "MemDC.h"


/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View view
class CMemDC;
class CMV_Map_View : public CScrollView
{
	DECLARE_DYNCREATE(CMV_Map_View)

public:
	CMV_Map_View();           // protected constructor used by dynamic creation

// Attributes
public:

	CMV_Doc*	m_pDoc;

	CSize		m_mapDispSize;
	CRect		MapLayoutRect;
	CDC			m_MemDC;
	CBrush		m_brushBack;

// Operations
public:
	void SetDocument(CMV_Doc* pDoc);
	void InitMapView(void);
	void OnUpdateMapView(void);

	void DrawBackgound(CMemDC* pDCDraw);
	void DrawLEDs(CMemDC* pDCDraw, CDC *pDC);
	void DrawIndexPickup(CMemDC *pDCDraw, int index);

	CSize GetMapDispSize(void);
	void _SetScrollSizes(void);

   
// Overrides
protected:

// Attributes
public:


// Implementation
private:
 
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_Map_View)
	public:
	virtual void OnInitialUpdate();     // first time after construct
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL OnScrollBy(CSize sizeScroll, BOOL bDoScroll = TRUE);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMV_Map_View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CMV_Map_View)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_MAP_VIEW_H__70D57CD3_8A94_495E_87C9_A223E42379AE__INCLUDED_)

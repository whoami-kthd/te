#if !defined(AFX_CMV_MAP_VIEW_H__70D57CD3_8A94_495E_87C9_A223E42379AE__INCLUDED_)
#define AFX_CMV_MAP_VIEW_H__70D57CD3_8A94_495E_87C9_A223E42379AE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_Map_View.h : header file
//

#include "CMV_Doc.h"

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View view

class CMV_Map_View : public CScrollView
{
public:
	CMV_Map_View();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMV_Map_View)

// Attributes
public:

	CMV_Doc*	m_pDoc;

// Operations
public:
	void SetDocument(CMV_Doc* pDoc);
	void SetScale(double scale, bool isZoom);
	void InitMapView(void);

	void DrawLEDMode(void);
	void SetScroll(void);

	CDC		m_MemDC;
	CBitmap m_bmpView;
	int		m_nBmpWidth,m_nBmpHeight;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_Map_View)
	public:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnInitialUpdate();     // first time after construct
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMV_Map_View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CMV_Map_View)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
//	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_MAP_VIEW_H__70D57CD3_8A94_495E_87C9_A223E42379AE__INCLUDED_)

// CMV_Util.cpp: implementation of the CMV_Util class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CMV.h"
#include "CMV_Util.h"
#include "math.h"
#include <vector>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMV_Util::CMV_Util()
{

}

CMV_Util::~CMV_Util()
{

}

#define DECISION 0.001

// Rotate a point arround a another point
void CMV_Util::RotatePoint(double& pX, double& pY, double centerX, double centerY, double angle)
{
	if(angle == 0.0) {
		return;
	}

	double r = angle * (PI / 180);
	double ct = cos(r);
	double st = sin(r);
	double tempX = (ct * (pX - centerX) - st * (pY - centerY)) + centerX;
	double tempY = (st * (pX - centerX) + ct * (pY - centerY)) + centerY;

	pX = tempX;
	pY = tempY;
}

// Round a float number
int CMV_Util::Round(double number)
{
	return int(number + 0.5);
}

// Scale a point
CPoint CMV_Util::ScalePoint(CPoint point, double scale)
{
	return CPoint(Round(point.x*scale), Round(point.y*scale));
}

// Scale a size
CSize CMV_Util::ScaleSize(CSize size, double scale)
{
	return CSize(Round(size.cx*scale), Round(size.cy*scale));
}

// Scale X size
CSize CMV_Util::ScaleXYSize(CSize size, double scaleX, double scaleY)
{
	if(scaleX > scaleX/2){
		scaleX = scaleX/2;
	}
	if(scaleY > 2){
		scaleY = 2;
	}
	return CSize(Round(size.cx*scaleX), Round(size.cy*scaleY));
}


// Compare two double number
bool CMV_Util::DoubleComparison(double a, double b)
{
	double diff = a - b;
	if (fabs(diff) < DECISION) {
		return true;
	} else {
		return false;
	}
}

// Calculate triangle area
double CMV_Util::TriangleArea(double a, double b, double c)
{
	if (((a + b) > c) && ((c + b) > a) && ((a + c) > b)) {
		double p = (a+b+c) / 2;
		return sqrt(p * (p-a) * (p-b) * (p-c));
	} else {
		return 0;
	}
}

void CMV_Util::SaveWindowPlace(CWnd* pWnd, CString appName, CString dialogName)
{
	WINDOWPLACEMENT wp;
    pWnd->GetWindowPlacement(&wp);
    AfxGetApp()->WriteProfileBinary(appName, dialogName, (LPBYTE)&wp, sizeof(wp));
}

// Get window 
bool CMV_Util::GetWindowPlace(CWnd* pWnd, CString appName, CString dialogName)
{
	WINDOWPLACEMENT *lwp;
    UINT nl;
	bool r = false;
    if(AfxGetApp()->GetProfileBinary(appName, dialogName, (LPBYTE*)&lwp, &nl))
    {
		pWnd->SetWindowPlacement(lwp);
		delete [] lwp;
		r = true;
	}
	return r;
}

int CMV_Util::GetCBitmapWidth(const CBitmap & cbm)
{
	BITMAP bm;
	cbm.GetObject(sizeof(BITMAP),&bm);
	return bm.bmWidth;
}


int CMV_Util::GetCBitmapHeight(const CBitmap & cbm)
{
/*	BITMAP bm;
	cbm.GetObject(sizeof(BITMAP),&bm);
	return bm.bmHeight;*/
	return 1;
}

CSize CMV_Util::GetMaxSize(CSize oldSize, CSize newSize)
{
	CSize maxSize;
	maxSize.cx = (oldSize.cx > newSize.cx)? oldSize.cx : newSize.cx;
	maxSize.cy = (oldSize.cy > newSize.cy)? oldSize.cy : newSize.cy;
	return maxSize;
}


HBITMAP CMV_Util::ScaleBitmapInt(HBITMAP hBitmap, 
					   WORD wNewWidth, WORD wNewHeight)
{
	// Create a memory DC compatible with the display
	CDC sourceDC, destDC;
	sourceDC.CreateCompatibleDC( NULL );
	destDC.CreateCompatibleDC( NULL );
	
	// Get logical coordinates
	BITMAP bm;
	::GetObject( hBitmap, sizeof( bm ), &bm );
	
	// Create a bitmap to hold the result
	HBITMAP hbmResult = ::CreateCompatibleBitmap(CClientDC(NULL), 
		wNewWidth, wNewHeight);
	
	// Select bitmaps into the DCs
	HBITMAP hbmOldSource = (HBITMAP)::SelectObject( sourceDC.m_hDC, hBitmap );
	HBITMAP hbmOldDest = (HBITMAP)::SelectObject( destDC.m_hDC, hbmResult );
	
	destDC.StretchBlt( 0, 0, wNewWidth, wNewHeight, &sourceDC, 
		0, 0, bm.bmWidth, bm.bmHeight, SRCCOPY );
	
	// Reselect the old bitmaps
	::SelectObject( sourceDC.m_hDC, hbmOldSource );
	::SelectObject( destDC.m_hDC, hbmOldDest );
	
	return hbmResult;
}

bool CMV_Util::SeparateString(CString FileName, int& RowIdx, int& ColIdx, int& Total)
{
	int tempIdx = FileName.ReverseFind('.');
	if(tempIdx == -1) return false;
	CString tempSpName = FileName.Left(tempIdx);
	CString tempStrIdx;
	for(int i = 0; i < 3; i++){
		int tempIdx = tempSpName.ReverseFind('_');
		if(tempIdx == -1) return false;
		switch(i){
		case 0:
			tempStrIdx = tempSpName.Mid(tempIdx+1);
			Total = atoi(tempStrIdx);
			tempSpName = tempSpName.Left(tempIdx);
			break;
		case 1:
			tempStrIdx = tempSpName.Mid(tempIdx+1);
			ColIdx = atoi(tempStrIdx);
			tempSpName = tempSpName.Left(tempIdx);
			break;
		case 2:
			tempStrIdx = tempSpName.Mid(tempIdx+1);
			RowIdx = atoi(tempStrIdx);
			break;
		}
	}
	return true;
}

bool CMV_Util::CheckDataImage(CStringList& strList, int& RowMax, int& ColMax)
{
	bool r = true;
	int size = strList.GetCount();
	int row = 1, col = 1, total = 0;
	if(size){
		int **checkIdx;
		checkIdx = new int*[size];
		for(int idx = 0; idx < size; idx++){
			checkIdx[idx] = new int[size];
		}
		for(int i = 0; i < size; i++){
			for(int j = 0; j < size; j++){
				checkIdx[i][j] = 0;
			}
		}

		for(i = 0; i < size; i++){
			r = SeparateString(strList.GetAt(strList.FindIndex(i)),row,col,total);
			if((!r) || (size != total)){
				r = false;
				break;
			}
			checkIdx[row-1][col-1] = 1;
		}
		RowMax = row-1; ColMax = col-1;
		for(i = 0; i < RowMax-1; i++){
			for(int j = 0;j < ColMax-1; j++){
				if(!checkIdx[i][j]){
					r = false;
					break;
				}
			}
		}

		for(idx = 0; idx < size; idx++){
			delete[] checkIdx[idx];
		}
		delete[] checkIdx;
	} else {
		r = false;
	}
	return r;
}

// CMV_Util.h: interface for the CMV_Util class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CMV_UTIL_H__CFC807FD_5F20_45DA_8568_73C409DC059B__INCLUDED_)
#define AFX_CMV_UTIL_H__CFC807FD_5F20_45DA_8568_73C409DC059B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	PI  3.141592653589793

class CMV_Util  
{
public:
	CMV_Util();
	virtual ~CMV_Util();

public:

	// Rotate a point arround a another point
	static void RotatePoint(double& pX, double& pY, double centerX, double centerY, double angle);

	// Round a float number
	static int Round(double number);

	// Scale a point
	static CPoint ScalePoint(CPoint point, double scale);

	// Scale a size
	static CSize ScaleSize(CSize size, double scale);

	// Scale X size
	static CSize ScaleXYSize(CSize size, double scaleX, double scaleY);


	// Compare two double numbers.
	static bool DoubleComparison(double a, double b);

	// Calculate triangle area
	static double TriangleArea(double a, double b, double c);

	// Save window place
	static void SaveWindowPlace(CWnd* pWnd, CString appName, CString dialogName);

	// Get window place
	static bool GetWindowPlace(CWnd* pWnd, CString appName, CString dialogName);
	
	static int GetCBitmapWidth(const CBitmap & cbm);
	
	static int GetCBitmapHeight(const CBitmap & cbm);

	static CSize GetMaxSize(CSize oldSize, CSize newSize);
	
	static HBITMAP ScaleBitmapInt(HBITMAP hBitmap, WORD wNewWidth, WORD wNewHeight);

	static bool SeparateString(CString FileName, int& RowIdx, int& ColIdx, int& Total);

	static bool CheckDataImage(CStringList& strList, int& RowMax, int& ColMax);

};

#endif // !defined(AFX_CMV_UTIL_H__CFC807FD_5F20_45DA_8568_73C409DC059B__INCLUDED_)

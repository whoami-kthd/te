//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CMV.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_CMV_DIALOG                  102
#define IDD_PROPPAGE_SMALL              103
#define IDR_MAINFRAME                   128
#define IDC_STATIC_MAP_NAME             1000
#define IDC_EDIT_MAP_NAME               1001
#define IDC_STATIC_MAP_MID              1002
#define IDC_EDIT_MAP_MID                1003
#define IDC_STATIC_MAP_BCEQU            1004
#define IDC_EDIT_MAP_BCEQU              1005
#define IDC_STATIC_MAP_ZOOM             1006
#define IDC_MAP_ZOOM                    1007
#define IDC_BTN_ZOOM_IN                 1008
#define IDC_BTN_ZOOM_OUT                1009
#define IDC_BTN_LOAD_MAP                1010
#define IDC_MAP_DISP_LAYOUT             1011
#define IDC_BTN_LOAD_MAP2               1012
#define IDC_STATIC_MAP_MID2             1013
#define IDC_BUTTON1                     1014
#define IDC_EDIT1                       1015
#define IDC_EDIT_MAP_FNLOC              1015
#define IDC_LIST_INDEX_PICKUP           1016
#define IDC_TOOL_LED_INFO               1017
#define IDC_BUTTON2                     1018
#define IDC_BUTTON3                     1019
#define IDC_BUTTON4                     1020
#define IDC_CUSTOM1                     1021
#define IDC_CHIP_LIST                   1021
#define IDC_MAP_JUMP                    1022
#define IDC_STATIC_MAP_BCEQU2           1023
#define IDC_EDIT_MAP_NULBC              1024
#define IDC_BUTTON5                     1025
#define IDC_BUTTON6                     1029
#define IDC_BUTTON7                     1030
#define IDC_BUTTON8                     1031
#define IDC_BTN_JUMP                    1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

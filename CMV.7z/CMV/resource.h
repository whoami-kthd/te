//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CMV.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_ABOUTBOX                    101
#define IDD_CMV_DIALOG                  102
#define IDD_PROPPAGE_SMALL              103
#define IDR_MAINFRAME                   128
#define IDC_STATIC_MAP_NAME             1000
#define IDC_EDIT_MAP_NAME               1001
#define IDC_STATIC_MAP_MID              1002
#define IDC_EDIT_MAP_MID                1003
#define IDC_STATIC_MAP_BCEQU            1004
#define IDC_EDIT_MAP_BCEQU              1005
#define IDC_STATIC_MAP_ZOOM             1006
#define IDC_MAP_ZOOM                    1007
#define IDC_BTN_ZOOM_IN                 1008
#define IDC_BTN_ZOOM_OUT                1009
#define IDC_BTN_LOAD_MAP                1010
#define IDC_MAP_DISP_LAYOUT             1011
#define IDC_BTN_LOAD_MAP2               1012
#define IDC_BUTTON1                     1014
#define IDC_EDIT1                       1015
#define IDC_LIST_INDEX_PICKUP           1016
#define IDC_BUTTON2                     1018
#define IDC_BUTTON3                     1019
#define IDC_BUTTON4                     1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

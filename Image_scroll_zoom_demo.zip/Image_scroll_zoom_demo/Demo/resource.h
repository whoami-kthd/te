//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DEMOTYPE                    129
#define IDB_BACKGROUND                  131
#define IDB_BITMAP0                     134
#define IDB_BITMAP1                     135
#define IDB_BITMAP2                     136
#define IDB_BITMAP3                     137
#define IDB_BITMAP4                     138
#define IDB_BITMAP5                     139
#define IDB_BITMAP6                     140
#define IDB_BITMAP7                     141
#define IDB_BITMAP8                     142
#define IDB_BITMAP9                     143
#define IDC_CURSOR_HAND                 144
#define IDC_CURSOR_HANDDRAG             147
#define ID_IMAGE_ZOOMIN                 32771
#define ID_IMAGE_ZOOMOUT                32772
#define ID_IMAGE_ORIGINALSIZE           32773
#define ID_IMAGE_FITWIDTH               32774
#define ID_IMAGE_FITWINDOW              32775
#define ID_OVERLAY_SHOWDIGGER           32778
#define ID_OVERLAY_SHOWTEXT             32779
#define ID_OVERLAY_ANIMATEDIGGER        32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

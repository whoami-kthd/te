// Convert.cpp : Defines the entry point for the console application.
//

#include "io.h"
#include <afxinet.h>
#include "stdafx.h"
#include <afxinet.h>
#include <sys/stat.h>
#include <string>
#include <sstream>					// istringstream
#include <iomanip>					// setw
using namespace std;

enum {
	CONVERT_ONLY,
	GET_AND_CONVERT,
};

CWinApp Session;

const char *ErrMsg[][2] = {
	/* 0*/	{ "�R�}���h���C���ُ�",			"Illegal Command line." },
	/* 1*/	{ "�ϊ����t�@�C�����o�ُ�",		"Failed in finding the input file." },
	/* 2*/	{ "�ϊ���t�H���_�ُ�",			"Error in the input folder." },
	/* 3*/	{ "�ϊ��v���O�����ُ�",			"Error in the convert program." },
	/* 4*/	{ "�f�[�^�ُ�",					"Data is abnormal." },
};

SYSPARA_DATA m_sysPara;
MINMAX_DATA m_minMaxData;

int LangIdx;
int fnloc;
int PathFlag;
int convert_type = 0;

char inifile[_MAX_PATH];
char *pdstdir;
char ErrBuf[128][255];

CString FtpFileName;

// Header of SM file
int m_numRow = 0;
int m_numCol = 0;
double m_xDies = 0.0;
double m_yDies = 0.0;
int m_productCount = 0;

// Read ini file
BOOL ReadSystemParameter(CString fileName)
{	
	BOOL r = TRUE;	
	
	CString Sec_Converter = _T("Converter");
	CString Sec_FTP = _T("FTP");
	
	GWPPfileData(fileName, Sec_FTP, "IP�A�h���X", TRUE, m_sysPara.IPAddress, "127.0.0.1");
	GWPPfileData(fileName, Sec_FTP, "���[�U��", TRUE, m_sysPara.UserName, "dongkd");
	GWPPfileData(fileName, Sec_FTP, "�p�X���[�h", TRUE, m_sysPara.Password, "123456");
	GWPPfileData(fileName, Sec_FTP, "FTP file path(read)", TRUE, m_sysPara.FTPFilePath_Read, "/noinkmap/raw");
	GWPPfileData(fileName, Sec_FTP, "Connection type (1:FTP 0:SDD)", TRUE, m_sysPara.connectionType, 1);
	GWPPfileData(fileName, Sec_Converter, "FAB Directory", TRUE, m_sysPara.ConversionPath, "D:/MapData/Map_FAB");
	GWPPfileData(fileName, Sec_Converter, "SM Directory", TRUE, m_sysPara.DesPath, "D:/MapData/Map_SM");
	GWPPfileData(fileName, Sec_FTP, "Port", TRUE, m_sysPara.ftpPort, 10000);
	
	return r;
}

//===========================================================================
BOOL GWPPfileData(		// int data type
				  LPCTSTR	lpFileName, 	// points to initialization filename 
				  LPCTSTR	lpszSection,	// address of section name
				  LPCTSTR	lpszKey,		// address of key name
				  BOOL	Get,			// TRUE:Specify read�@FALSE:Specify write
				  int&	Data,			// store data
				  int		DataD)			// default data
{
	int r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
			NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%d",&Data) != 1){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD; 
	}
	else{
		CString	str;
		str.Format("%d",Data);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	
	return	r;
}

BOOL GWPPfileData(			// character string data type
				  LPCTSTR	lpFileName, 	// points to initialization filename 
				  LPCTSTR	lpszSection,	// address of section name
				  LPCTSTR	lpszKey,		// address of key name
				  BOOL	Get,			// TRUE:Specify read�@FALSE:Specify write
				  CString&	Data,		// store data
				  CString		DataD)		// default data
{
	int r=TRUE;
	if(Get){
		char	inBuf[BUFSIZ];
		r = GetPrivateProfileString (lpszSection,lpszKey,
			NULL,inBuf,BUFSIZ,lpFileName); 
		if(r){
			r = TRUE;
			Data = inBuf;
		}
		if(!r)	Data = DataD;
	}
	else{
		r = WritePrivateProfileString (lpszSection,lpszKey,Data,lpFileName); 
	}
	
	return	r;
}

//==================================================================================
// Put errors
//==================================================================================
void ConvErr(const int code)
{
	if (pdstdir) {
		FILE *fp;
		char filename[_MAX_PATH];
		sprintf(filename, "%sConvertError.txt", pdstdir);
		if (fp = fopen(filename, "wt")) {
			if (0 <= code && code < sizeof(ErrMsg) / sizeof(ErrMsg[0])) {
				fprintf(fp, "%s\n", ErrMsg[code][LangIdx]);
			} else {
				fprintf(fp, "Error %d\n", code);
			}
			
			fclose(fp);
		}
	}
}


//====================================================================================
// Main function
//====================================================================================
int main(int argc, char* argv[])
{
	int r = TRUE;
	afxCurrentAppName = "Session";
	
	InitData();
	
	// Get the convert type
	if (argv[4]) {
		convert_type = atoi(argv[4]);
	} else {
		convert_type = GET_AND_CONVERT;
	}
	
	// Check argument	
	if(argc != 5){
		fprintf(stderr, "Usage:%s <Src folders> <dst folder> <MID>\n", argv[0]);
		fprintf(stderr, "Version 1.00\n");
		ConvErr(ERR_CMD);
		return 0;
	}
	
	// Check ini file for convert
	strcpy(inifile, argv[0]);
	char *pslash = strrchr(inifile, '/');
	if (pslash) {
		*pslash = 0;
	} else if (pslash = strrchr(inifile, '\\')) {
		*pslash = 0;
	} else {
		ConvErr(ERR_APP);
		return 0;
	}
	strcat(inifile, "/Convert.ini");
	
	printf("Ini file: %s\n", inifile);
	
	if (!_access(inifile, 0)) {	// inifile exists
		fnloc = GetPrivateProfileInt("Converter Default Value", "FNLOC", 0, inifile);
		LangIdx = GetPrivateProfileInt("Option", "Language", 0, inifile);
	}
	
	// Check conversion source folder if exists or not
	if (_access(argv[2], 0)) {
		ConvErr(ERR_DST_DIR);
		return 0;
	} else {
		pdstdir = argv[2];
	}
	
	// Read system parameter  
	ReadSystemParameter(inifile);
	CString pSrc = "";
	
	// => Get the source file from FTP server to source file folder - 'D:/MapData/WfMap_TSB
	if (convert_type == GET_AND_CONVERT) {
		if (m_sysPara.connectionType == 1) {
			r = FTPGetFile(m_sysPara.ConversionPath, CString(argv[3]));		
		} else {
			r = SDDGetFile(m_sysPara.ConversionPath, CString(argv[3]));		
		}
		pSrc = m_sysPara.ConversionPath;
	} else {
		pSrc = m_sysPara.DesPath;
	}	
	
	// Look for the conversion source file
	FILE *fp = NULL;
	char filename[_MAX_PATH];	
	
	if (r) {
		for (; pSrc;) {
			if (!_access(pSrc, 0)) {
				if (convert_type == GET_AND_CONVERT) {
					sprintf(filename, "%s%s%s%s", pSrc, "/", argv[3], ".FAB");
				} else {
					sprintf(filename, "%s%s%s", pSrc, "/", argv[3]);
				}			
				
				if (fp = fopen(filename, "r")) {
					break;
				}
			}			
		}
	}	
	
	
	if (NULL == fp) {
		printf("File open false\n");		
		ConvErr(ERR_SRC_NIL);
		return 0;
	}
	
	if (!Convert(filename, argv)) {
		printf("Read file false\n");
		ConvErr(ERR_DATA);
		return 0;
	}
	
	return(1);	
}

//====================================================================================
// Init data
//====================================================================================
void InitData(){
	pdstdir = NULL;
	LangIdx = 0;
	fnloc = 0;
}

int ErrBuffCheck()
{
	int cnt = 0;
	for(int i = 0; i < 10; i++){
		if(strlen(ErrBuf[i])){
			cnt++;
		}
	}
	return cnt;
}

//////////////////////////////////////////////////////////////////////////
// Process barcode ID
int BarcodeSeparate(char *Str, int Flag)
{
	CString StrLeft, StrRight, StrFileName;
	int FileLen;
	StrFileName = Str;
	if(Flag){
		// Detach .FAB
		FileLen = StrFileName.ReverseFind('.');
		StrRight = StrFileName.Right(StrFileName.GetLength() - FileLen);
	}
	FileLen = StrFileName.ReverseFind('-');
	
	// Remove checksum and wafer ID
	StrLeft = StrFileName.Left((Flag)? FileLen : FileLen + 3);
	StrFileName.Empty();
	StrFileName += StrLeft;
	if(Flag) StrFileName += StrRight;
	strcpy(Str, StrFileName);
	return 1;
}

//====================================================================================
// Get file from server and save to local file path
//====================================================================================
int FTPGetFile(CString LocalFilePath, CString &barcodeNo)
{
	int r = 0;
	int Msg = IDRETRY;
	
	char *StrFtpFileName;
	CStdioFile	File;
    CInternetSession    *m_pInetSession;                // pointer to internet section object
    CFtpConnection      *m_pFtpConnection;              // pointer to FTP connection object
    INTERNET_PORT   nPortWk;
    DWORD           dwServiceType, ECode;
    CString IPAddress, UserName, Password, FtpFilePath;
    CString FtpSite, strObject, OldFilePath, wkPath, msg;
	// Generic Host Process For Win32 Sevices error measure
	CString strServerPath;
	FtpFileName = "";
	
	FtpFileName += barcodeNo;
	FtpFileName += ".FAB";	
	
	FtpFilePath = m_sysPara.FTPFilePath_Read;
	// Modify delimiter of file of "\" to "/"
	FtpFilePath += "/";
	FtpFilePath += FtpFileName;
	IPAddress = m_sysPara.IPAddress;
	UserName = m_sysPara.UserName;
	Password = m_sysPara.Password;
	FtpSite += "ftp://";
	int port = m_sysPara.ftpPort;
	// Generic Host Process For Win32 Sevices error measure
	FtpSite += IPAddress;
	// [Inconvenient] Corresponding with silence of FTP connection (for test)
    m_pInetSession = new CInternetSession(NULL, 1,INTERNET_OPEN_TYPE_DIRECT);
	
	printf ("FTPGetFile/n");
	printf ("IP address: %s\n", IPAddress);
	printf ("User Name: %s\n", UserName);
	printf ("Password: %s\n", Password);
	printf ("FtpFilePath: %s\n", FtpFilePath);
	
	// svchost error measure (S)
    DWORD BufSize;
    BufSize = sizeof(DWORD);
    m_pFtpConnection = NULL;
	DWORD Timeout;
	BufSize = sizeof(DWORD);
	Timeout = 500;
	m_pInetSession->SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, &Timeout, BufSize);
	
	// Generic Host Process For Win32 Sevices error measure
	if( !AfxParseURL( (LPCTSTR)FtpSite, dwServiceType, strServerPath, strObject, nPortWk)){     
		delete m_pInetSession;              // release information of session
		m_pInetSession = NULL;
		r = FALSE;
		return r;
	}
	
	if( (dwServiceType == INTERNET_SERVICE_FTP) && !strServerPath.IsEmpty() ){      
		// Generic Host Process For Win32 Sevices error measure(E)
		int ReCnt = 1;
		for(int RoopCnt=0;RoopCnt<ReCnt+1;RoopCnt++){
			try{
				m_pFtpConnection = m_pInetSession->GetFtpConnection( (LPCTSTR)strServerPath, (LPCTSTR)UserName, (LPCTSTR)Password, port); 
				msg.Format("GetFtpConnection: m_pFtpConnection=0x%08X, m_pInetSession=0x%08X", m_pFtpConnection, m_pInetSession);
			}
			catch ( CInternetException* pEx ){
				if(RoopCnt<ReCnt){
					Sleep(500);
					continue;		
				}
				ECode = GetLastError();
				int ECnt = ErrBuffCheck();
				pEx->Delete();
				if(m_pFtpConnection != NULL){
					m_pFtpConnection->Close();
				}
			}
			break;
		}
	}
	PathFlag = 1;
	
	int iRetry = 0;
	
	//Copy current local file path
	CString SavedLocalFilePath(LocalFilePath);
	StrFtpFileName = (char *)malloc(512);
	if( m_pFtpConnection != NULL ){
		msg.Format("IPAddress=%s User=%s Password=%s", (LPCTSTR)IPAddress, (LPCTSTR)UserName, (LPCTSTR)Password);
		
		CFtpFileFind *FtpFind = new CFtpFileFind( m_pFtpConnection );      
		if(PathFlag){
			r = FtpFind->FindFile(FtpFilePath);  			
			if(!r){
				printf("Not Find File Name=%s\n", FtpFileName);
			}
		} else {
			r = FtpFind->FindFile(FtpFileName);                              
			printf("Not Find File Name=%s\n", FtpFileName);
		}
		
Retry:
		if(!r){
			strcpy(StrFtpFileName, FtpFileName);
			BarcodeSeparate(StrFtpFileName, 1);
			FtpFilePath = m_sysPara.FTPFilePath_Read;
			FtpFilePath += "/";
			FtpFilePath += StrFtpFileName;
			if(PathFlag){ 
				r = FtpFind->FindFile(FtpFilePath);    
			} else {
				r = FtpFind->FindFile(StrFtpFileName);  
			}
			if(r){
				FtpFileName = StrFtpFileName;
			}else{
				// 
				ECode = GetLastError();
				int ECnt = ErrBuffCheck();
			}
		}
		
		if( r && m_pFtpConnection != NULL ){
			LocalFilePath = SavedLocalFilePath + "/" + FtpFileName;	
			r = m_pFtpConnection->GetFile((PathFlag)? (LPCTSTR)FtpFilePath : (LPCTSTR)FtpFileName, (LPCTSTR)LocalFilePath,
				FALSE, FILE_ATTRIBUTE_NORMAL, FTP_TRANSFER_TYPE_BINARY, 1 );
		}
		if(r){
			msg.Format("GetFile=%s", FtpFileName);
		}else{
			ECode = GetLastError();
			msg.Format("�T�[�o�p�X=%s, �ۑ���p�X=%s", (LPCTSTR)FtpFilePath, (LPCTSTR)LocalFilePath);
			int ECnt = ErrBuffCheck();
			if (0 == iRetry) {
				iRetry = 1;
				goto Retry;	
			}
		}
		FtpFind->Close();                                 
		delete FtpFind;                                     
	}
	
    if(m_pFtpConnection != NULL){      
		msg.Format("m_pFtpConnection Close");
        m_pFtpConnection->Close();
	}
	delete m_pFtpConnection;            
    m_pFtpConnection = NULL;
	
	if(m_pInetSession != NULL){
		msg.Format("m_pInetSession Close");
        m_pInetSession->Close();
	}
	
	delete m_pInetSession;
	m_pInetSession = NULL;
	
	free(StrFtpFileName);
	return r;
}

//====================================================================================
// Get file from shared folder and save to local file path
//====================================================================================
int SDDGetFile(CString LocalFilePath, CString barcodeNo)
{
	int r = 0;
	CString batchExcute = "";
	CString sourceFileName = "";
	CString desFileName= "";
	
	system("net use * /delete /y");
	
	batchExcute = batchExcute + "net use X: " + "\\\\" + m_sysPara.IPAddress + "\\" + m_sysPara.FTPFilePath_Read + " " + m_sysPara.Password + " /USER:" + m_sysPara.UserName/* + " /P:yes"*/;
	system(batchExcute);
	
	sourceFileName += "X:\\";
	sourceFileName += barcodeNo;
	sourceFileName += ".FAB";
	
	desFileName += LocalFilePath;
	desFileName += "\\";
	desFileName += barcodeNo;
	desFileName += ".FAB";
	r = ::CopyFile(sourceFileName, desFileName, FALSE);
	return r;
}

// Get index in one-dimension array from row and column index base 1
int GetIndex(int row, int col)
{
	return ((row - 1) * m_minMaxData.maxX + (col - 1));
}

//====================================================================================
// Convert items from FAB format to SM format
//====================================================================================
BOOL Convert(CString filePath, char* argv[]) 
{
	ifstream fin(filePath);
	
	if (fin.bad()) {
		fin.close();
		return FALSE;
	}
	
	// Get number of row and number of column
	CountRowColFAB(fin);
	
	// Reset reading position 
	fin.clear();
	fin.seekg(0, std::ios::beg);
	
	// Convert FAB to SM
	if (ReadBinCodeFAB(fin, argv)) {
		fin.close();
		return TRUE;
	} else {
		fin.close();
		return FALSE;
	}
}

// Write conterted data to file
void WriteDataToFile(int *array, char* argv[])
{
	ofstream fout;
	
	int i = 0;
	int j = 0;
	
	CString tempBin = _T("");
	CString filePath = _T("");
	filePath = m_sysPara.DesPath;
	filePath += "/";
	filePath += argv[3];

	fout.open(filePath);

	if (fout.fail()) {
		printf("Open folder to write false\n");		
		return;
	}

	fout << SECTION			<< endl;
	fout << FLAT_NOTCH		<< "="	<< fnloc						<< endl;
	fout << REFER_POINT_SEL << "="	<< "1"							<< endl;
	fout << REFER_X			<< "="	<< "10,1,1,1,1,1,1,1,1,1,1"		<< endl;
	fout << REFER_Y			<< "="	<< "10,1,1,1,1,1,1,1,1,1,1"		<< endl;
	fout << X_DIE			<< "="	<< m_xDies						<< endl;
	fout << Y_DIE			<< "="	<< m_yDies						<< endl;

	fout << ROW_COUNT		<< "="	<< m_minMaxData.maxY			<< endl;
	fout << COL_COUNT		<< "="	<< m_minMaxData.maxX			<< endl;
	fout << PRODUCT_COUNT	<< "="	<< "1"							<< endl;
	fout << MESSAGE_LEN		<< "="	<< "1"							<< endl;
	fout << START_DIE_POS_X	<< "="	<< "1"							<< endl;
	fout << START_DIE_POS_Y << "="	<< "1"							<< endl;
	fout << MATERIAL_ID		<< "="	<< "1"							<< endl;
	fout << FRAME_ID		<< "="	<< "1"							<< endl;
	fout << DIE_UNIT		<< "="	<< "1"							<< endl;
	fout << GOOD_BINCODE	<< "="	<< "1"							<< endl;
	fout << NULL_BINCODE	<< "="	<< "...."						<< endl;
	fout << VER				<< "="	<< "1"						<< endl;

	// Fixed 4 characters to print
	for (i = 0; i < m_minMaxData.maxY; i++) {
		tempBin.Format("BINLT(%3d)=", i);
		fout << tempBin.GetBuffer(tempBin.GetLength());
		tempBin.ReleaseBuffer();

		for (j = 0; j < m_minMaxData.maxX; j++) {
			if (*(array + GetIndex(i + 1, j + 1)) == 0) {
				fout << "....";
			} else {
				tempBin.Format("%04d", *(array + GetIndex(i + 1, j + 1)));
				fout << tempBin.GetBuffer(tempBin.GetLength());
				tempBin.ReleaseBuffer();
			}
		}
		fout << endl;
	}
	
	fout.close();
}

void CountRowColFAB(ifstream &fin)
{
	bool flag = false;
	int tempX = 0;
	int tempY = 0;
	int sizeArr = 0;
	string line;
	char tempChar[1024];
	
	// Init to 0
	m_minMaxData.minX = 0;
	m_minMaxData.maxX = 0;
	m_minMaxData.minY = 0;
	m_minMaxData.maxY = 0;
	
	// Read until line not include '[' 
	while(getline(fin, line)) {	
		if (line.length() != 0) {
			if (line.at(0) != _T('[')) {
				if (line.at(0) == _T('X')) {
					// Copy string to char array for read format
					strncpy(tempChar, line.c_str(), sizeof(tempChar));
					tempChar[sizeof(tempChar) - 1] = 0;
					
					// Read format
					sscanf(tempChar,"%*s%d %*s%d", &tempX, &tempY);
					
					// Init min, max to first item's value
					m_minMaxData.minX = m_minMaxData.maxX = tempX;
					m_minMaxData.minY = m_minMaxData.maxY = tempY;
				}
				break;
			}
		}
	}
	
	// Start read following line to get bincode
	while(getline(fin, line)) {
		if (line.length() != 0) {			
			if (line.at(0) != _T('X')) {
				continue;
			}
			
			// Copy string to char array for read format
			strncpy(tempChar, line.c_str(), sizeof(tempChar));
			tempChar[sizeof(tempChar) - 1] = 0;
			
			// Read format
			sscanf(tempChar,"%*s%d %*s%d", &tempX, &tempY);
			
			// Check with each value to get min and max values
			if (tempX < m_minMaxData.minX) {
				m_minMaxData.minX = tempX;
			}
			
			if (tempX > m_minMaxData.maxX) {
				m_minMaxData.maxX = tempX;
			}
			
			if (tempY < m_minMaxData.minY) {
				m_minMaxData.minY = tempY;
			}
			
			if (tempY > m_minMaxData.maxY) {
				m_minMaxData.maxY = tempY;
			}
		}
	}
	
	// Number of columns
	m_numCol = m_minMaxData.maxX - m_minMaxData.minX + 1;
	// Number of rows
	m_numRow = m_minMaxData.maxY - m_minMaxData.minY + 1;
}

BOOL ReadBinCodeFAB(ifstream &fin, char* argv[])
{
	bool flag = false;
	int tempX = 0;
	int tempY = 0;
	int tempB = 0;
	int sizeArr = 0;
	int count = 0;
	int *array;
	int flatZone = 0;
	string line;
	string field;
	char tempChar[1024];
	
	// Calculate size of array based on data
	if ((m_numCol == 0) && (m_numRow == 0)) {
		sizeArr = 1;
	} else if (m_numCol == 0) {
		sizeArr = m_minMaxData.maxY;
	} else if (m_numRow == 0) {
		sizeArr = m_minMaxData.maxX;
	} else {
		sizeArr = m_minMaxData.maxX * m_minMaxData.maxY;
	}
	
	// Allocate size for one-dimension array
	array = new int[sizeArr];
	
	// Initialize all array's item to 0
	memset(array, 0, sizeof(int) * sizeArr);
	
	getline(fin, line);
	getline(fin, line);
	istringstream s(line);
	
	while(getline(s, field, '/')){
		count++;
		switch(count){
		case 5: // FNLOC
			if (ValidateIntegerString(field.c_str())) {
				if (field == _T("")) {				// NULL <-> 0 degree
					fnloc = 0;
				} else {
					flatZone = atoi(field.c_str());
					if (flatZone == 5) {			// 5 <-> 0 degree
						fnloc = 0;
					} else if (flatZone == 7) {		// 7 <-> 90 degree
						fnloc = 90;
					} else if (flatZone == 0) {		// 0 <-> 180 degree
						fnloc = 180;
					} else if (flatZone == 3) {		// 3 <-> 270 degree
						fnloc = 270;
					} else {
						fnloc = 0;					// Others <-> 0 degree
					}
				}
			} else {
				// Delete array to avoid memory leaks
				delete array;
				return FALSE;
			}
			break;
		case 6: // XDIES
			if (ValidateDoubleString(field.c_str())) {
				m_xDies = atof(field.c_str()) / 1000; // Convert from [�ʂ�] to [mm]
			} else {
				// Delete array to avoid memory leaks
				delete array;
				return FALSE;
			}
			break;
		case 7: // YDIES
			if (ValidateDoubleString(field.c_str())) {
				m_yDies = atof(field.c_str()) / 1000; // Convert from [�ʂ�] to [mm]
			} else {
				// Delete array to avoid memory leaks
				delete array;
				return FALSE;
			}
			break;
		case 8: // Product count (%)
			field.erase(0, 1);
			if (ValidateIntegerString(field.c_str())) {
				m_productCount = atoi(field.c_str());
			} else {
				// Delete array to avoid memory leaks
				delete array;
				return FALSE;
			}
			break;
		default:
			break;
		}
	}
	
	
	// Read until line not include '['
	while(getline(fin, line)) {	
		if (line.length() != 0) {
			if (line.at(0) != _T('[')) {
				if (line.at(0) == _T('X')) {
					// Copy string to char array for read format
					strncpy(tempChar, line.c_str(), sizeof(tempChar));
					tempChar[sizeof(tempChar) - 1] = 0;
					
					// Read format
					sscanf(tempChar,"%*s%d %*s%d %*s%d\n", &tempX, &tempY, &tempB);
					
					// Assign bincode into array
					array[GetIndex(tempY, tempX)] = tempB;
				}
				break;
			}
		}
	}
	
	// Start read following line to get bincode
	while(getline(fin, line)) {
		if (line.length() != 0) {
			// Check line has beginning character is 'E' equal to 'EOW'
			if (line.at(0) == _T('E')) {
				if (flag) {			// Reset flag when match second EOW
					flag = false;
					continue;
				} else {
					flag = true;	// Math first EOW
					continue;
				}
			}
			
			if (flag) {
				continue;
			}
			
			if (line.at(0) != _T('X')) {
				continue;
			}
			
			// Copy string to char array for read format
			strncpy(tempChar, line.c_str(), sizeof(tempChar));
			tempChar[sizeof(tempChar) - 1] = 0;
			
			// Read format
			sscanf(tempChar,"%*s%d %*s%d %*s%d", &tempX, &tempY, &tempB);
			
			// Assign bincode into array
			array[GetIndex(tempY, tempX)] = tempB;
		}
	}
	
	// Write converted data to file
	WriteDataToFile(array, argv);

	// Delete array to avoid memory leaks
	delete array;

	return TRUE;
}

/* Validate if string is integer */
bool ValidateIntegerString(CString value)
{
	bool stringShouldChange = true;
	LPTSTR invalidStr;
	int intValue;

	intValue = _tcstol(value, &invalidStr, 10);

	if(*invalidStr)
	{
		stringShouldChange = false;
	}

	return stringShouldChange;
}

/* Validate if string is double */
bool ValidateDoubleString(CString value)
{
	bool stringShouldChange = true;
	LPTSTR invalidStr;
	double doubleValue;

	/* The code will return double value from the string 
	** and if any other characters are left after extracting 
	** double value, they will be stored in invalidStr */
	doubleValue = _tcstod(value, &invalidStr);

	if(*invalidStr)
	{
		stringShouldChange = false;
	}

	return stringShouldChange;
}
// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__4A1A7192_1F7A_4CE0_BA3B_85B6E676C38C__INCLUDED_)
#define AFX_STDAFX_H__4A1A7192_1F7A_4CE0_BA3B_85B6E676C38C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define NO_BOND				0

#define SECTION				_T("[Map Data Type 2]")
#define FLAT_NOTCH			_T("FNLOC")
#define REFER_POINT_SEL		_T("RPSEL")
#define REFER_X				_T("REFPX")
#define REFER_Y				_T("REFPY")
#define X_DIE				_T("XDIES")
#define Y_DIE				_T("YDIES")
#define ROW_COUNT			_T("ROWCT")
#define COL_COUNT			_T("COLCT")
#define PRODUCT_COUNT		_T("PRDCT")
#define MESSAGE_LEN			_T("MLCL")
#define START_DIE_POS_X		_T("STRPX")
#define START_DIE_POS_Y		_T("STRPY")
#define MATERIAL_ID			_T("MID")
#define FRAME_ID			_T("FID")
#define DIE_UNIT			_T("DUTMS")
#define GOOD_BINCODE		_T("BCEQU")
#define NULL_BINCODE		_T("NULBC")
#define BIN_LIST			_T("BINLT")
#define VER					_T("VER")

#include <io.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <afx.h>
#include <afxinet.h>
#include <afxwin.h>         // Core and standard components of MFC
#include <afxext.h>         // Expaned portion of MFC
#include <afxdisp.h>        // Automation class of MFC
#include <afxdtctl.h>		// Internet Explorer 4 common control support of MFC
#include <fstream>			// ifstream

using namespace std;

enum {
	ERR_CMD					= 0,
	ERR_SRC_NIL				= 1,
	ERR_DST_DIR				= 2,
	ERR_APP					= 3,
	ERR_DATA				= 4,
};

typedef struct{		
	CString IPAddress;
	CString UserName;
	CString Password;		
	CString ConversionPath;
	CString DesPath;
	CString FTPFilePath_Read;
	int connectionType;
	int ftpPort;
}SYSPARA_DATA;

typedef struct {
	int maxX;
	int minX;
	int maxY;
	int minY;
} MINMAX_DATA;

int BarcodeSeparate(char *Str, int Flag);
int FTPGetFile(CString LocalFilePath, CString &barcodeNo);	
int SDDGetFile(CString LocalFilePath, CString barcodeNo);
int ErrBuffCheck();
int GetIndex(int row, int col);

void InitData();
BOOL Convert(CString filePath, char* argv[]);
void WriteDataToFile(int *array, char* argv[]);
void CountRowColFAB(ifstream &fin);
BOOL ReadBinCodeFAB(ifstream &fin, char* argv[]);

BOOL ReadSystemParameter(CString FNam);
BOOL GWPPfileData(			// int data type
				  LPCTSTR	lpFileName, 	// points to initialization filename 
				  LPCTSTR	lpszSection,	// address of section name
				  LPCTSTR	lpszKey,		// address of key name
				  BOOL	Get,				// TRUE:Specify read�@FALSE:Specify write
				  int&	Data,				// store data
				  int		DataD=0);		// default data
BOOL GWPPfileData(			// character string data type
				  LPCTSTR	lpFileName, 	// points to initialization filename 
				  LPCTSTR	lpszSection,	// address of section name
				  LPCTSTR	lpszKey,		// address of key name
				  BOOL	Get,				// TRUE:Specify read�@FALSE:Specify write
				  CString& Data,			// store data
				  CString	DataD);			// default data
bool ValidateIntegerString(CString value);	// Check string only include integer
bool ValidateDoubleString(CString value);	// Check string only include double

// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__4A1A7192_1F7A_4CE0_BA3B_85B6E676C38C__INCLUDED_)

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WMV.rc
//
#define IDD_WMV_DIALOG                  102
#define IDR_MAINFRAME                   128
#define IDD_CHIP_DIALOG                 130
#define IDC_MAP                         1000
#define IDC_BUTTON_CLOSE                1001
#define IDC_ST_POS                      1002
#define IDC_MENU_Zoom1                  1003
#define IDC_MENU_Zoom2                  1004
#define IDC_MENU_Zoom3                  1005
#define IDC_MENU_Zoom4                  1006
#define IDC_MENU_Zoom5                  1007
#define IDC_MENU_Zoom6                  1008
#define IDC_MENU_ColorSetting           1009
#define IDC_BUTTON1_PICK                1010
#define IDC_MENU_CountDispOn            1011
#define IDC_BUTTON1_CUR                 1012
#define IDC_MENU_CountDispOff           1013
#define IDC_STATIC_PICK                 1013
#define IDC_BUTTON1_REF                 1014
#define IDC_MENU_ColorSave              1015
#define IDC_BUTTON1_BACK                1016
#define IDC_CHIP_LIST                   1017
#define IDC_STATUS_BAR                  1018
#define IDC_DRAW_LIST                   1019
#define IDC_SCROLLBAR_GRPH_H            1020
#define IDC_SCROLLBAR_GRPH_V            1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

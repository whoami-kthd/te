/*---------------------------------------------------------------------
	CONTEC PC-HELPER PIO-32/32L(PC) ����ٓ��o��Ӽޭ�ِ��� �׽ײ����
								1996 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------
---------------------------------------------------------------------*/
#include	<c_pio32.h>

#ifdef	WIN_NT
HANDLE WinRTOpenDeviceB(int dno,int s);
#endif

#ifndef	CONTEC_PIO32_None	//#######################################
//###################################################################

/////////////////////////////////////////////////////////////////////
///	����J���ފ֐�

unsigned char CONTEC_PIO32::InputB(unsigned char	*adrs)
{
#ifdef	WIN_NT
	int	data;
	CSingleLock	S(&WinRTSema);
	S.Lock(INFINITE);
//%%
//#OnError errorTrap
//#SetAbsolute	On
//#SetSize	8
//    data = inpb(adrs);
//%%
{
//	WINRT_CONTROL_ITEM _WinRTpp01[] =
//	{//	command	param1	param2
//		{INP_BA,	0,	0},
//	};

	_WinRTpp01[ 0].command = INP_BA;
	_WinRTpp01[ 0].port = (ULONG)adrs;
	if (!WinRTProcessIoBuffer(hWinRT, _WinRTpp01,
				sizeof(_WinRTpp01), &iWinRTlength))
		 goto errorTrap;
	data = _WinRTpp01[ 0].value;
//
}

	return	data;
errorTrap:
	int err = GetLastError();
	if(TRUE){	//if(err != ERROR_SUCCESS){
		char	buff[125];
		sprintf(buff,"inpb(%x) Error:%d\n",adrs,err);
		OutputDebugString(buff);
		return	0;
	}
	else{
		return	0;
	}

#else
	return(::_inp((unsigned short)adrs));
#endif
}
void CONTEC_PIO32::OutputB(unsigned char	*adrs,unsigned char data)
{
#ifdef	WIN_NT
	CSingleLock	S(&WinRTSema);
	S.Lock(INFINITE);
//%%
//#OnError errorTrap
//#SetAbsolute	On
//#SetSize	8
//    outpb(adrs,data);  
//%%
{
//	WINRT_CONTROL_ITEM _WinRTpp02[] =
//	{//	command	param1	param2
//		{OUTP_BA,	0,	0},
//	};
	_WinRTpp02[ 0].command = OUTP_BA;
	_WinRTpp02[ 0].port = (ULONG)adrs;
	_WinRTpp02[ 0].value = data;
	if (!WinRTProcessIoBuffer(hWinRT, _WinRTpp02,
				sizeof(_WinRTpp02), &iWinRTlength))
		 goto errorTrap;
//
}
	return;

errorTrap:
	int err = GetLastError();
	if(err != ERROR_SUCCESS){
		char	buff[125];
		sprintf(buff,"outb(%x,%x) Error:%d\n",adrs,data,err);
		OutputDebugString(buff);
	}
#else
	::_outp((unsigned short)adrs,(unsigned short)data);
#endif
}

/////////////////////////////////////////////////////////////////////
//	�ݽ�׸�
CONTEC_PIO32::CONTEC_PIO32()
{
	iopt = (IOPort*)NULL;
#ifdef	WIN_NT
	hWinRT = INVALID_HANDLE_VALUE;
#endif
}
CONTEC_PIO32::~CONTEC_PIO32()
{
	if(iopt != NULL){
			// �o�͸ر
		for(int i=0;i<4;i++)	OutputB(&iopt->out[i],0);
	}
#ifdef	WIN_NT
	if(hWinRT != INVALID_HANDLE_VALUE){
		WinRTCloseDevice(hWinRT);
	}
#endif

}
/////////////////////////////////////////////////////////////////////
//	�Ƽ�ײ��
void	CONTEC_PIO32::InitInstance(int dno,void *p,long)
{
#ifdef	WIN_NT
	if(hWinRT != INVALID_HANDLE_VALUE){
		WinRTCloseDevice(hWinRT);
	}
	 hWinRT = WinRTOpenDeviceB(dno, TRUE);
	if(hWinRT == INVALID_HANDLE_VALUE){
		OutputDebugString("\nWinRTOpenDevice()   Error\n");
	}
#endif
	CSingleLock	S(&out_buff_Sema,TRUE);
	// I/O�߰� ���ڽ�ݒ�
	iopt = (IOPort*)p;
		// �o���ޯ̧�ر
	for(int i=0;i<4;i++)	out_buff[i] = 0;
		// �o�͸ر
	for(i=0;i<4;i++)	OutputB(&iopt->out[i],out_buff[i]);
}
/////////////////////////////////////////////////////////////////////
//	�ް��̓��́i32bit�ꊇ���́j
unsigned long	CONTEC_PIO32::Input()
{
	unsigned long	data=0;
	
	for(int i=0;i<4;i++){
		data <<= 8;
		data |= InputB(&iopt->in[3-i]) & 0xff;
	}
	return(data);
}
/////////////////////////////////////////////////////////////////////
//	�ް��̏o�́i32bit�ꊇ�o�́j
void CONTEC_PIO32::Output(unsigned long data)
{
	unsigned char	buff[4];
	CSingleLock	S(&out_buff_Sema,TRUE);
		// �ޯ̧���ް���ݒ�
	for(int i=0;i<4;i++){
		buff[i] = (unsigned char)data;
		data >>= 8;
	}
		// �ް��o��
	for(i=0;i<4;i++){
		if(out_buff[i] != buff[i]){
			out_buff[i] = buff[i];
			OutputB(&iopt->out[i],out_buff[i]);
		}
	}
}
/////////////////////////////////////////////////////////////////////
//	�ް��̏o�͏�ԁi32bit�ꊇ�o�́j
unsigned long CONTEC_PIO32::OutputStts()
{
	CSingleLock	S(&out_buff_Sema,TRUE);
	unsigned long	data=0;
	for(int i=3;i>=0;i--){
		data <<= 8;
		data |= out_buff[i];
	}
	return(data);
}
/////////////////////////////////////////////////////////////////////
//	�ް��̏o�́i�C�� bit ��� �jON�ޯĂ��
void CONTEC_PIO32::SetBit(unsigned long mask)
{
	CSingleLock	S(&out_buff_Sema,TRUE);
	unsigned char	buff[4];
		// �ޯ̧���ް���ݒ�
	for(int i=0;i<4;i++){
		buff[i] = (unsigned char)(out_buff[i] | mask);
		mask >>= 8;
	}
		// �ް��o��
	for(i=0;i<4;i++){
		if(out_buff[i] != buff[i]){
			out_buff[i] = buff[i];
			OutputB(&iopt->out[i],out_buff[i]);
		}
	}
}
/////////////////////////////////////////////////////////////////////
//	�ް��̏o�́i�C�� bit ؾ�� �jON�ޯĂ�ؾ��
void CONTEC_PIO32::ResBit(unsigned long mask)
{
	CSingleLock	S(&out_buff_Sema,TRUE);
	unsigned char	buff[4];
		// �ޯ̧���ް���ݒ�
	for(int i=0;i<4;i++){
		buff[i] = (unsigned char)(out_buff[i] & ~mask);
		mask >>= 8;
	}
		// �ް��o��
	for(i=0;i<4;i++){
		if(out_buff[i] != buff[i]){
			out_buff[i] = buff[i];
			OutputB(&iopt->out[i],out_buff[i]);
		}
	}
}
//###################################################################
#endif	//###########################################################
#ifdef	CONTEC_PIO32_None	//###########################################
//###################################################################

/////////////////////////////////////////////////////////////////////
//	�ݽ�׸�
CONTEC_PIO32::CONTEC_PIO32()
{

	INBUF=OUTBUF=0;
}
CONTEC_PIO32::~CONTEC_PIO32()
{
}
/////////////////////////////////////////////////////////////////////
//	�Ƽ�ײ��
void	CONTEC_PIO32::InitInstance(int dno,void *p,long inpd)
{
	INBUF = OUTBUF = 0;
	INBUF = inpd;
}
/////////////////////////////////////////////////////////////////////
//	�ް��̓��́i32bit�ꊇ���́j
unsigned long	CONTEC_PIO32::Input()
{
//	static	cnt=0;
//	cnt ++;
//	if(cnt > 15){
//		INBUF += 0x11111111;
//		cnt = 0;
//	}
	return	INBUF;
}
/////////////////////////////////////////////////////////////////////
//	�ް��̏o�́i32bit�ꊇ�o�́j
void CONTEC_PIO32::Output(unsigned long data)
{
	CSingleLock	S(&out_buff_Sema,TRUE);
	OUTBUF = data;
}
/////////////////////////////////////////////////////////////////////
//	�ް��̏o�͏�ԁi32bit�ꊇ�o�́j
unsigned long CONTEC_PIO32::OutputStts()
{
	CSingleLock	S(&out_buff_Sema,TRUE);
	return	OUTBUF;
}
/////////////////////////////////////////////////////////////////////
//	�ް��̏o�́i�C�� bit ��� �jON�ޯĂ��
void CONTEC_PIO32::SetBit(unsigned long mask)
{
	CSingleLock	S(&out_buff_Sema,TRUE);
	OUTBUF |= mask;
}
/////////////////////////////////////////////////////////////////////
//	�ް��̏o�́i�C�� bit ؾ�� �jON�ޯĂ�ؾ��
void CONTEC_PIO32::ResBit(unsigned long mask)
{
	CSingleLock	S(&out_buff_Sema,TRUE);
	OUTBUF &= ~mask;
}
//###################################################################
#endif	//###########################################################

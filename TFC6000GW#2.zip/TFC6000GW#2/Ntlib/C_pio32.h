/*---------------------------------------------------------------------
	CONTEC PC-HELPER PIO-32/32L(PC) ����ٓ��o��Ӽޭ�ِ��� �׽ײ����
								1996 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------
---------------------------------------------------------------------*/
#ifndef	c_pio32_h
#define	c_pio32_h

//#define	CONTEC_PIO32_None
#define	WIN_NT

#include	<afxmt.h>
#include	<stdio.h>
#include	<semaxx.h>                        



#ifdef	WIN_NT
	#ifndef	WinRTOpenDevice
	#include	<WinRTctl.h> 
	#endif                          
#include	<winioctl.h>
#else
#include	<conio.h>
#endif

/////////////////////////////////////////////////////////////////////
//	
//	CONTEC_PIO32

class CONTEC_PIO32{
// I/O �߰�
	union IOPort{		//	I/O �߰� �z�u	
		unsigned char	out[4];	// �o���ް��߰� 8bit * 4
		unsigned char	in[4];	// �����ް��߰� 8bit * 4
	} *iopt;
	unsigned char	out_buff[4];	// �o���ް��ޯ̧ 8bit * 4
	CSemaphoreX		out_buff_Sema;
#ifdef	WIN_NT
	HANDLE hWinRT;
    DWORD  iWinRTlength;                  // length of returned buffers
	WINRT_CONTROL_ITEM _WinRTpp01[1];
	WINRT_CONTROL_ITEM _WinRTpp02[1];
	CSemaphoreX		WinRTSema;
	HANDLE WinRTOpenDeviceB(int dno,int s)
	{
		char	buff[32];

		sprintf(buff,"\\\\.\\WRTdev%d",dno);
		return	CreateFile(buff,
	             0,
	             ((s) ? FILE_SHARE_READ | FILE_SHARE_WRITE : 0),
	             NULL, OPEN_EXISTING, 0, NULL);
	}
#endif

#ifndef	CONTEC_PIO32_None	//#######################################
//###################################################################
	unsigned char InputB(unsigned char	*adrs);
	void OutputB(unsigned char	*adrs,unsigned char data);
//###################################################################
#endif	//###########################################################

public:
/////////////////////////////////////////////////////////////////////
//	���J����
	CONTEC_PIO32();	
	~CONTEC_PIO32();	
/////////////////////////////////////////////////////////////////////
//	
//--- �����ݒ�
	void InitInstance(int dno,void *p,long inpd=0);	// p=�ް�ޱ��ڽ	
//--- DI/DO ����
	unsigned long	Input();				// �ް��̓��́i32bit�ꊇ���́j
	void Output(unsigned long data);		// �ް��̏o�́i32bit�ꊇ�o�́j
	unsigned long OutputStts();				// �ް��̏o�͏�ԁi32bit�ꊇ�j
	void SetBit(unsigned long mask);		// �ް��̏o�́i�C�� bit ��� �jON�ޯĂ��
	void ResBit(unsigned long mask);		// �ް��̏o�́i�C�� bit ؾ�ājON�ޯĂ�ؾ��

#ifdef	CONTEC_PIO32_None	//#######################################
//###################################################################

 	long	INBUF,OUTBUF;

//###################################################################
#endif	//###########################################################


};

#endif

// HardCopy.cpp: CHardCopy �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <afxmt.h>
#include <afxwin.h>
#include "Semaxx.h"
#include "HardCopy.h"
#include "FileService.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CHardCopy::CHardCopy()
{
	this->sema = NULL;
	this->pWnd = NULL;
	memset( this->BmpPath, 0, sizeof(this->BmpPath) );
	memset( this->Title, 0, sizeof(this->Title) );
}

CHardCopy::~CHardCopy()
{

}

BOOL	CHardCopy::HardCopy()
{
	BOOL	r = TRUE;
	CFileService	fs;
	long	pc;
	char	FilePath[1000];
	char	FileName[1000];
	char	WinTitle[32];
	CDC		*pDC;	// �f�o�C�X�R���e�L�X�g
	CDC		DCMem;	// �������f�o�C�X�R���e�L�X�g
	HBITMAP	hBitmap;// �r�b�g�}�b�v�n���h��
	HBITMAP	Soh;	// �r�b�g�}�b�v�n���h��
	CRect	rect;	// �_�C�A���O�̈�
	HANDLE	hFile;
	DWORD				dwResult;
	DWORD				dwSizeImage;
	BITMAPFILEHEADER	bmfHeader;
	BITMAPINFOHEADER	bmiHeader;

//	int	yy,mm,dd,hh,mn,ss,ms;
	SYSTEMTIME	systime;

	if( pWnd == NULL )
		return	TRUE;

	if( this->sema != NULL )
		CSingleLock Sema(this->sema,true);

	pWnd->SetWindowPos( &CWnd::wndTopMost, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );
	::Sleep(100);	// �E�B���h�E���őO�ʂ֏o��܂ő҂��Ȃ��ƃL���v�`���ł��Ȃ��B
	// �E�B���h�E�̗̈���擾����
	pWnd->GetWindowRect( &rect );
	pWnd->GetWindowText( WinTitle, 30 );

	// �f�B�X�v���C �f�o�C�X�R���e�L�X�g�쐬
	pDC = pWnd->GetWindowDC();	// ���jGetDC()�́A�N���C�A���g�̈�ɂȂ�
	LPBITMAPINFO	lpbi;
	LPTSTR		lpBits = NULL;

	#define WIDTHBYTES(bits) ((((bits) + 31) / 32) * 4)

	// Fill in the BITMAPINFOHEADER
	lpbi = (LPBITMAPINFO) new BYTE[sizeof(BITMAPINFOHEADER)];
	lpbi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	lpbi->bmiHeader.biWidth = rect.Width(); 
	lpbi->bmiHeader.biHeight = rect.Height(); 
	lpbi->bmiHeader.biPlanes = 1;
	lpbi->bmiHeader.biBitCount = 24;
	lpbi->bmiHeader.biCompression = BI_RGB;
	lpbi->bmiHeader.biSizeImage = WIDTHBYTES(rect.Width()) * rect.Height();
	lpbi->bmiHeader.biXPelsPerMeter = 0;
	lpbi->bmiHeader.biYPelsPerMeter = 0;
	lpbi->bmiHeader.biClrUsed = 0;
	lpbi->bmiHeader.biClrImportant = 0;

	hBitmap = CreateDIBSection( pDC->m_hDC, lpbi, DIB_RGB_COLORS, (void **)&lpBits, NULL, 0 );

	// DSP������ �f�o�C�X�R���e�L�X�g�쐬
	DCMem.CreateCompatibleDC( pDC );
	Soh = (HBITMAP)SelectObject( DCMem.m_hDC, hBitmap );

	// �r�b�g�}�b�v����
	DCMem.BitBlt( 0, 0, rect.Width(), rect.Height(), pDC, 0, 0, SRCCOPY );

	pWnd->SetWindowPos( &CWnd::wndTop, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE );

	pWnd->ReleaseDC( pDC );

	GetLocalTime( &systime );
	sprintf( FileName, "%s\\%s%04d%02d%02d%02d%02d%02d%03d.bmp",
				this->BmpPath, this->Title,
				systime.wYear, systime.wMonth, systime.wDay, systime.wHour, systime.wMinute, systime.wSecond, systime.wMilliseconds );
	hFile = CreateFile( FileName, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );

	if (hFile != INVALID_HANDLE_VALUE){
		dwSizeImage = rect.Height() * ((3 * rect.Width() + 3) / 4) * 4;

		ZeroMemory(&bmfHeader, sizeof(BITMAPFILEHEADER));
		bmfHeader.bfType    = *(LPWORD)"BM";
		bmfHeader.bfSize    = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + dwSizeImage;
		bmfHeader.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

		WriteFile( hFile, &bmfHeader, sizeof(BITMAPFILEHEADER), &dwResult, NULL );

		ZeroMemory(&bmiHeader, sizeof(BITMAPINFOHEADER));
		bmiHeader.biSize        = sizeof(BITMAPINFOHEADER);
		bmiHeader.biWidth       = rect.Width();
		bmiHeader.biHeight      = rect.Height();
		bmiHeader.biPlanes      = 1;
		bmiHeader.biBitCount    = 24;
		bmiHeader.biSizeImage   = dwSizeImage;
		bmiHeader.biCompression = BI_RGB;
		
		WriteFile( hFile, &bmiHeader, sizeof(BITMAPINFOHEADER), &dwResult, NULL );

		WriteFile( hFile, lpBits, dwSizeImage, &dwResult, NULL );

		CloseHandle(hFile);

		sprintf( FilePath, this->BmpPath );
		fs.CutOverFiles( FilePath, "*.bmp", 100 );
	} else {
		r = FALSE;
	}
	delete [] lpbi;
	SelectObject(DCMem.m_hDC, Soh);
	DCMem.DeleteDC();

	DeleteObject(hBitmap);

	if( this->sema != NULL )
		ReleaseSemaphore( this->sema, 1, &pc );			// ��̫�̉��
	return	r;

}

// HardCopy.h: CHardCopy �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HARDCOPY_H__70F0135C_E78A_4CA5_B6C8_006FE56AFD43__INCLUDED_)
#define AFX_HARDCOPY_H__70F0135C_E78A_4CA5_B6C8_006FE56AFD43__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CHardCopy  
{
public:
	CHardCopy();
	virtual ~CHardCopy();

	BOOL	HardCopy( void );


	CSemaphoreX	*sema;
	CWnd	*pWnd;
	char	BmpPath[1024];
	char	Title[100];				// #DucMV 20160317 Flux function

};

#endif // !defined(AFX_HARDCOPY_H__70F0135C_E78A_4CA5_B6C8_006FE56AFD43__INCLUDED_)

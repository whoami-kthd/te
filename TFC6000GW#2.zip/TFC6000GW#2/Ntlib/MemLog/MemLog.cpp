// MEMLOG.cpp: CMEMLOG �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include	<stdio.h>
#include	<memory.h>
#include	<windows.h>
#include	"MEMLOG.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CMEMLOG::CMEMLOG()
{
	logbuff = NULL;
}

CMEMLOG::~CMEMLOG()
{
	if( logbuff )
		free( logbuff );

}

int		CMEMLOG::Init( int Col, int Line )
{
	int		ret = 0;

	if( logbuff ){
		free( logbuff );
		logbuff = NULL;
	}

	MaxLen = Col;
	MaxLine = Line;

	logbuff = (char *)malloc( MaxLen * MaxLine );
	if( logbuff == NULL ){
		ret = -1;
	} else {
		memset( logbuff, 0, (MaxLen * MaxLine) );
		this->Clear();
	}
	return	ret;
}

int		CMEMLOG::Add( const char *msg )
{
	int		ret = 0;
	SYSTEMTIME	ntime;
	char	*buff;
	char	*work;

	if( logbuff == NULL ){
		return	-9;
	}
	if( msg ){
		buff = (char *)malloc( MaxLen+30 );
		if( buff ){
			memset( buff, 0, MaxLen+30 );
			work = (char *)malloc( MaxLen );
			if( work ){
				GetLocalTime( &ntime );
				memset( work, 0, MaxLen );
				strncpy( work, msg, (MaxLen - 1) );
				sprintf( buff, "%04d/%02d/%02d %02d:%02d:%02d.%03d %s", ntime.wYear, ntime.wMonth, ntime.wDay, ntime.wHour, ntime.wMinute, ntime.wSecond, ntime.wMilliseconds, work );
				buff[MaxLen-1] = 0x00;
				memcpy( (logbuff + (MaxLen * spoint)), buff, MaxLen );
				spoint ++;
				if( spoint >= MaxLine ){
					spoint = 0;
				}
				lognum ++;
				if( lognum >= MaxLine ){
					lognum = MaxLine;
					tpoint ++;
					if( tpoint >= MaxLine ){
						tpoint = 0;
					}
				}
				free( work );
			} else {
				ret = -1;
			}
			free( buff );
		} else {
			ret = -1;
		}
	}
	return	ret;
}

int		CMEMLOG::Clear( void )
{
	tpoint = 0;		// Top Point
//	epoint = 0;		// End Point
	spoint = 0;		// Store Point
	lognum = 0;		// Log Number

	return	0;
}

int		CMEMLOG::Write( const char *fname )
{
	int		ret = 0;
	FILE	*fp;

	if( logbuff == NULL ){
		return	-9;
	}

	if( lognum ){
		fp = fopen( fname, "w" );
		if( fp ){
			int		i, l;
			i = tpoint;
			for( l=0 ; l<lognum ; l++ ){
				fputs( logbuff + (MaxLen * i), fp );
				i ++;
				if( i>=MaxLine ){
					i = 0;
				}
			}
			fclose( fp );
		} else {
			ret = -1;
		}
	}
	return	ret;
}

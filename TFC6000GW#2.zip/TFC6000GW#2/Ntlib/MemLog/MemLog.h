// MEMLOG.h: CMEMLOG �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MEMLOG_H__1BDF1798_7965_4EAA_964F_2EA3D79EFC90__INCLUDED_)
#define AFX_MEMLOG_H__1BDF1798_7965_4EAA_964F_2EA3D79EFC90__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMEMLOG  
{
public:
	CMEMLOG();
	virtual ~CMEMLOG();

	int		Init( int Col=256, int Line=2000 );
	int		Add( const char *msg );
	int		Clear( void );
	int		Write( const char *fname );

private:
	int		MaxLen;
	int		MaxLine;

	char	*logbuff;
	int		tpoint;		// Top Point
//	int		epoint;		// End Point
	int		spoint;		// Store Point
	int		lognum;		// Log Number

};

#endif // !defined(AFX_MEMLOG_H__1BDF1798_7965_4EAA_964F_2EA3D79EFC90__INCLUDED_)

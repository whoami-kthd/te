/*---------------------------------------------------------------------
	WinRT�pײ����
								1996 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------
---------------------------------------------------------------------*/
#include	<stdio.h>
#include	<afxmt.h>
#include	<WinRTctl.h> 

// WinRT ��ײ�ނ̵���� �i���޲�No.�����Ұ��ϐ��Ƃ����j
HANDLE WinRTOpenDeviceB(int dno,int s)
{
	char	buff[32];

	sprintf(buff,"\\\\.\\WRTdev%d",dno);
	return	CreateFile(buff,
                0,
                ((s) ? FILE_SHARE_READ | FILE_SHARE_WRITE : 0),
                NULL, OPEN_EXISTING, 0, NULL);
}




/*---------------------------------------------------------------------
	Cognex MVS-8200 ���� �N���X���C�u����
	�g�p�ς݊�S�̑��B�e�N���X

								2000 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------
  --------------------------------------------------------------------*/
//-------------------------------------------------------------------


#include <ch_cvl/defs.h>
#include <ch_cvl/board.h>
#include <ch_cvl/acq.h>

#include <ch_cvl/except.h>
#include <ch_cvl/pelmap.h>

// #KS1154(S) 02-07-04 COG8200�p�c�ݕ␳�ڐA
#include <ch_cvl/diagsrv.h>

#include <ch_cvl/vidfmt.h>
#include <ch_cvl/constrea.h>
#include <ch_cvl/units.h>

//#include <ch_cog/rpc.h>
//#include <ch_cvl/vp8200.h>
#include <ch_cvl/vp8504.h>
#include <ch_cvl/pelbuf.h>
#include <ch_cvl/pelfunc.h>
#include <ch_cvl/windisp.h>
#include <ch_cvl/uishapes.h>
#include <ch_cvl/shapes.h>
#include <ch_cvl/pmalign.h>
#include <ch_cvl/autoslct.h>
#include <ch_cvl/atslptmx.h>
#include <ch_cvl/timer.h>
#include <ch_cvl/blobtool.h>
#include <ch_cvl/blobdesc.h>
#include <ch_cvl/histo.h>
#include <ch_cvl/histstat.h>
#include <ch_cvl/scnangle.h>
#include <ch_cvl/caliper.h>

#include <iostream>
#include <string>


#include <afxwin.h>
#include "libstd.h"
#include "semaxx.h"
#include "c8200dlg.h"
#include "c8200rpc.h"
#include "c8200.h"
//#include "dib.h"
#include "pos.h"


// #OZ20160211-01[�ǉ�] �g�p�ς݊�����o������Pan�摜�B�e�@�\�ǉ� (S)
//----------------------------
void	CPMTool::photo(	// �B�e���s�J�n
						CString	&filename,						// �������݃t�@�C����(���Path)
						double x,double y,double w,double h,	// �摜���S(xy)�C�T�C�Y(wh)
						int	displaymode)						// ���ʕ\�����[�h eDisplay******
{
	CSingleLock	Sema(&(pPC->CogSema),false);

	ccPelBuffer<c_UInt8> pb;
	{
		CSingleLock	Sema2(&CogfifoSema,true);
		GetFifo()->properties().movePartCallback(pPC->nullCallbackPtrh);
		GetFifo()->properties().completeCallback(pPC->nullCallbackPtrh);
// #OZ20160208-02[�ǉ�] Third-party Imaging Device����̉摜�捞�Ή�
		if( pPC->Camera_Info[m_CameraIndex].imgDevType == 1 ){
			GetFifo()->properties().roi(ccPelRect(0,0,pPC->widthArray[m_CameraIndex],pPC->heightArray[m_CameraIndex]));
		} else {
			GetFifo()->properties().roi(ccPelRect(0,0,0,0));
		}
		GetFifo()->start();									// start acquisition
		pb = GetFifo()->complete();	// wait on acq.
	}
	Sema.Lock();
// #OZ20160208-02[�ǉ�] Third-party Imaging Device����̉摜�捞�Ή�
	if( (pb.height() != 0) && (pb.width() != 0) ){
		if(displaymode){
			pPC->display->image( pb );							// display this image
		}
		ccDIB dib;
		dib.init(pb);
		dib.write(std::string(LPCTSTR(filename)));
	} else {
		TRACE( "photo :: Camera[%d] Size Error : pb.height=%d pb.width()=%d\n", m_CameraIndex, pb.height(), pb.width() );
	}

	Sema.Unlock();

}
// #OZ20160211-01[�ǉ�] �g�p�ς݊�����o������Pan�摜�B�e�@�\�ǉ� (E)

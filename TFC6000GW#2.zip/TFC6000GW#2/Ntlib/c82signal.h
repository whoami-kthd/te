#ifndef	c_c82signal_h
#define	c_c82signal_h
//------------------------------------------------------------
// �^�N�g�^�C����͗p�̐M���o�͗p

extern int Global_TactSignal;
// #IK050616-01(S) �����ё���p
#include	<Gwpp.h>
extern TSigDioData	*pGlobal_AcqSig;
extern TSigDioData	*pGlobal_SearchSig;
// #IK050616-01(E)
extern void	Global_XMPOUT(int idx, int val);	// idx = 1~5

#include	<AnyWire.h>
extern	AnyWire	*pGlobal_DIO;		// AnyWire  DIO   �׽	��޼ު��

// #IK050616-01(S) �����ё���p
/*
#define Tact_NodeAdr		0x06
#define Tact_Acq			0x00000001	// ��荞��
#define Tact_Search			0x00000002	// �T�[�`
*/
#if GPDEBUG && !BOARDONLY_Cognex	// #OZ20160208-01
#define	Tact_AcqOnOff(m) { ;}
#define	Tact_SearchOnOff(m)	{ ; }
#else
#define	Tact_AcqOnOff(m)	\
	{	\
		if (1 == Global_TactSignal) {	\
			UCHAR	ErrCode;	\
			if(m){pGlobal_DIO->DIO_SetBit  (pGlobal_AcqSig->Type, pGlobal_AcqSig->Node, pGlobal_AcqSig->Mask, ErrCode);}	\
			else {pGlobal_DIO->DIO_ResetBit(pGlobal_AcqSig->Type, pGlobal_AcqSig->Node, pGlobal_AcqSig->Mask, ErrCode);}	\
		} else if (2 == Global_TactSignal) {	\
			Global_XMPOUT(1,(m)?1:0);	\
/* #KS080927-02(S) �摜�^�C�~���O��XMP�ɏo�� */	\
		} else if (3 == Global_TactSignal) {	\
			Global_XMPOUT(1,(m)?1:0);	\
/* #KS080927-02(E) */	\
		}	\
	}

#define	Tact_SearchOnOff(m)	\
	{	\
		if (1 == Global_TactSignal) {	\
			UCHAR	ErrCode;	\
			if(m){pGlobal_DIO->DIO_SetBit  (pGlobal_SearchSig->Type, pGlobal_SearchSig->Node, pGlobal_SearchSig->Mask, ErrCode);}	\
			else {pGlobal_DIO->DIO_ResetBit(pGlobal_SearchSig->Type, pGlobal_SearchSig->Node, pGlobal_SearchSig->Mask, ErrCode);}	\
		} else if (2 == Global_TactSignal) {	\
			Global_XMPOUT(2,(m)?1:0);	\
/* #KS080927-02(S) �摜�^�C�~���O��XMP�ɏo�� */	\
		} else if (3 == Global_TactSignal) {	\
			Global_XMPOUT(2,(m)?1:0);	\
/* #KS080927-02(E) */	\
		}	\
	}
// #IK050616-01(E)
#endif

#define	BxAcquisition(m)	 	Tact_AcqOnOff(m)
#define	BxSearch(m)			 	Tact_SearchOnOff(m)
#define	DxAcquisition(m)	 	Tact_AcqOnOff(m)	
#define	DxSearch(m)			 	Tact_SearchOnOff(m)
#define	ICAcquisition(m)	 	Tact_AcqOnOff(m)
#define	ICSearch(m)			 	Tact_SearchOnOff(m)
#define	ICRAcquisition(m)	 	Tact_AcqOnOff(m)
#define	ICRSearch(m)		 	Tact_SearchOnOff(m)
#define	WfAcquisition(m)	 	Tact_AcqOnOff(m)
#define	WfSearch(m)			 	Tact_SearchOnOff(m)

// #IK050613-01(E)
#endif

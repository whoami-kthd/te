#if ZMP_BOARD

#include	<afxmt.h>
#include	<stdio.h>
#include	<semaxx.h>                        
#include	<ZMPCtrl.h>                     
#include	<swatchd.h>
#include	<pos.h>

#include	<stdlib.h>

#include	"stdmpi.h"
#include	"stdmei.h"
#include	"apputil.h"

#include	<bghZMP_define.h>

// #OZ20120917 ADD ZMP�Ή�
extern ZMP_ADCData		ADCTBL[];

// ���x�o�͒l�̎擾
double	BGH_XMP::GetTemp(bool outByDegree){
	double	n_Pos = 0.0;
	{
#if GPDEBUG
	return true;
#endif
		long	msg;
		long	position;
		long	lPos;
		//
// #OZ20120917 UPD ZMP�Ή�
//		msg = mpiAdcInput(H_TempAdc, &position);
		msg = meiSqNodeAnalogIn(H_sqNode[ADCTBL[TempInpCh].sqNodeNo], ADCTBL[TempInpCh].channel, &position);

		lPos = position;
		//----------------------------
		// �f�W�^���l�ŕԂ�
		if(!outByDegree){
			n_Pos = (double)lPos;
		//----------------------------
		// �ݒ艷�x�ŕԂ�
		}else{
			n_Pos = (double)lPos * this->BGHPara.Heater_a + this->BGHPara.Heater_b;
		}
		//----------------------------
	}
	return n_Pos;
}

#endif


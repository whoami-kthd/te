#pragma once

#include	<mcc.h>

struct MT;//�O���Q��

#define BUTTONS 10

class CDebugWnd : public CWnd
{
public:
    CDebugWnd (MCCtrl* p,bool show);
    virtual ~CDebugWnd(){}
protected:
	MCCtrl*    m_pMCC;
	CWnd*      m_activeView;
	CListCtrl  m_list;
	CEdit      m_edit;

	CStatusBar m_statusBar;
	CButton    m_buttons[BUTTONS];

	CRect      m_clientRect;
	int        m_motors;
	MT*        m_pMTTBL;
	MT*        m_MTTBL_EXISTS[64];
	
	CString    m_textBuffer;
	int	       m_status;
	double     m_value;
	BOOL       m_SuperSts;
	BOOL       m_OrgSts;

	int  ListInit();
	void UpdateButtonLabel();
	void UpdateMTTBL();
	BOOL CreateStatusBar();
	BOOL CreateButtons();
	BOOL UpdateLayout();
	virtual void PostNcDestroy ();
	int  OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void OnPaint ();
	afx_msg void OnButtonClick(UINT nID);
	BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	void OnGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult);
	void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult);
	void OnTimer(UINT nIDEvent);
	void OnDestroy();
	void OnSize(UINT nType, int cx, int cy);
    DECLARE_MESSAGE_MAP ()
};

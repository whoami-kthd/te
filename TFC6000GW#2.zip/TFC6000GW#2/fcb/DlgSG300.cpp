// DlgSG300.cpp : �C���v�������e�[�V���� �t�@�C��
//
// #KS20130510-01 [���P]S5F2���s�v�ȃA���[���Ή�
#include <mcc.h>
#include "stdafx.h"
#include "fcb.h"
#include "DlgSG300.h"
// #KS20130417-01 [�ǉ�]GEM�Q�|�[�g��
//#include	<io.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CString TRStateMsg[] = {
	"StateOutOfService",
	"StateTransferBlocked",
	"StateReadyToLoad",
	"StateReadyToUnload",
};

/////////////////////////////////////////////////////////////////////////////
// DlgSG300 �_�C�A���O


DlgSG300::DlgSG300(CWnd* pParent /*=NULL*/)
	: CDialog(DlgSG300::IDD, pParent)
// #KS20130417-01 [�ǉ�]GEM�Q�|�[�g��
//	,ID(0)
//	,pSecsTDS(NULL)
// #KS20130510-01 [���P]S5F2���s�v�ȃA���[���Ή�
	,AlarmMsgName("_GS05F01S")
{
	//{{AFX_DATA_INIT(DlgSG300)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_DATA_INIT

	this->pEvFinInfoComState		= NULL;
	this->pEvFailInfoComState		= NULL;

	this->pEvPPRecipeSendReq		= NULL;

	this->pEvPPSelectReq			= NULL;
	this->pEvPPStartReq_B			= NULL;
	this->pEvPPStartReq_T			= NULL;
	for (int i = 0; i < NO_OF_TOP_PORT; i++) {
		this->pEvTopWaferUnloadReq[i]		= NULL;
	}
	
	this->pEvBottomWaferUnloadReq	= NULL;
	for(i=0; i<NO_OF_TOP_PORT; i++){
		this->beAbleToRelease[i]		= false;
		this->beAbleToAutoRun[i]		= true;
		this->pEvTopWaferUnloadReq[i]	= NULL;
	}
	this->pEvStopWaitingSecsT	= &this->EvStopWaitingDummy;	// ���Ƀ_�~�[�����Ă����B
	this->pEvStopWaitingSecsB	= &this->EvStopWaitingDummy;	// ���Ƀ_�~�[�����Ă����B
	this->EvStopWaitingDummy.ResetEvent();
	//
	this->pEvFinInfoBottomCarrierIdRead		= NULL;
	this->pEvFailInfoBottomCarrierIdRead	= NULL;
	this->pEvFinInfoTopCarrierIdNotified	= NULL;
	this->pEvFailInfoTopCarrierIdNotified	= NULL;
	this->pEvFinInfoBottomSlotMap			= NULL;
	this->pEvFailInfoBottomSlotMap			= NULL;
	this->pEvFinInfoTopCarrierIdRead[0]		= NULL;
	this->pEvFailInfoTopCarrierIdRead[0]	= NULL;
	this->pEvFinInfoTopCarrierIdRead[1]		= NULL;
	this->pEvFailInfoTopCarrierIdRead[1]	= NULL;
	this->pEvFinInfoTopCarrierIdRead[2]		= NULL;
	this->pEvFailInfoTopCarrierIdRead[2]	= NULL;
	this->pEvFinInfoTopSlotMap				= NULL;
	this->pEvFailInfoTopSlotMap				= NULL;
	count_S1F13 = 0;
	this->goRemote	= false;
	this->goLocal	= false;
	this->goOffline	= false;
//	this->goOnlineRemote_flg = FALSE;
	this->initCarrierObj_flg = FALSE;

	this->ppID = "";
	this->fileNameCount		= 0;
	this->comState			= 0;
	this->HostCommandStatus	= eNotReceived;
//	this->carrierIsCreated	= false;
//	this->carrierIsPlaced	= false;
	//
	this->CntD.PickCountG			= 0;
	this->CntD.PickCountB			= 0;
	this->CntD.PlaceCountG			= 0;
	this->CntD.PlaceCountB			= 0;
	this->CntD.UnBondCountG			= 0;
	this->CntD.UnBondCountB			= 0;
	this->CntD.PickRemainCountG		= 0;
	this->CntD.PickRemainCountB		= 0;
	this->CntD.PlaceRemainCountG	= 0;
	this->CntD.PlaceRemainCountB	= 0;
	this->SetCWnd(this);
	for(i=0; i<Error_NumberMax; i++){
		this->almIsAlreadySend[i] = false;
	}
	for(i=0;i<ePortNoMax;i++){
		this->loadedByHost[i]			= false;
		this->carrierId[i]				= "";
	}
// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O
	this->MapCtrl.bReqMap = false;
	this->MapCtrl.pMapData = NULL;
// #KS20130415-01(E)	
	// #DucMV 20160405 Flux Function
	this->MonitorMode = 0;
	this->pEvStartMonitor = NULL;
	this->isHostRequestMonitor = false;
	// #DucMV 20160405 Flux Function
}

DlgSG300::~DlgSG300(){
	m_hXComSecs.CloseProject();
	this->comState = 0;
}

void DlgSG300::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DlgSG300)
	DDX_Control(pDX, IDC_XCOMSECSCTRL1, m_hXComSecs);
	DDX_Control(pDX, IDC_SG300CMSCTRL1, m_hCsg300cms);
	DDX_Control(pDX, IDC_SG300CJMCTRL1, m_hCsg300cjm);
	DDX_Control(pDX, IDC_SG300PJMCTRL1, m_hCsg300pjm);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(DlgSG300, CDialog)
	//{{AFX_MSG_MAP(DlgSG300)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// DlgSG300 ���b�Z�[�W �n���h��

BEGIN_EVENTSINK_MAP(DlgSG300, CDialog)
    //{{AFX_EVENTSINK_MAP(DlgSG300)
	ON_EVENT(DlgSG300, IDC_XCOMSECSCTRL1, 14 /* InfoComState */, OnInfoComStateXcomsecsctrl1, VTS_I2 VTS_I2 VTS_I2)
	ON_EVENT(DlgSG300, IDC_XCOMSECSCTRL1, 15 /* InfoControlStateEvent */, OnInfoControlStateEventXcomsecsctrl1, VTS_I2)
	ON_EVENT(DlgSG300, IDC_XCOMSECSCTRL1, 2 /* GetSecsEvent */, OnGetSecsEventXcomsecsctrl1, VTS_BSTR)
	ON_EVENT(DlgSG300, IDC_SG300CMSCTRL1, 9 /* InfoCarrierIdStateEvent */, OnInfoCarrierIdStateEventSg300cmsctrl1, VTS_I2 VTS_VARIANT VTS_I2)
	ON_EVENT(DlgSG300, IDC_SG300CMSCTRL1, 10 /* InfoSlotMapStateEvent */, OnInfoSlotMapStateEventSg300cmsctrl1, VTS_I2 VTS_VARIANT VTS_VARIANT VTS_I2 VTS_I2)
	ON_EVENT(DlgSG300, IDC_SG300CMSCTRL1, 2 /* GetServiceEvent */, OnGetServiceEventSg300cmsctrl1, VTS_BSTR)
	ON_EVENT(DlgSG300, IDC_XCOMSECSCTRL1, 18 /* LinkXComChanged */, OnLinkXComChangedXcomsecsctrl1, VTS_I2 VTS_I2)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()


///////////////////////////////////////////////////
//
//
//
//
//	�� �� �� / O p e n P r o j ec t �֌W
//
//
//
BOOL DlgSG300::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	SystemParametersInfo( SPI_GETWORKAREA, 0, &m_WorkRect, sizeof(m_WorkRect) );
	this->DlgStatus.Create( IDD_STATUS, this );
	SetTimer( 1, 1000, NULL );
	
	return TRUE;  // �R���g���[���Ƀt�H�[�J�X��ݒ肵�Ȃ��Ƃ��A�߂�l�� TRUE �ƂȂ�܂�
	              // ��O: OCX �v���p�e�B �y�[�W�̖߂�l�� FALSE �ƂȂ�܂�
}

void DlgSG300::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID && pSecsTDS) {
//		int sts = pSecsTDS->GetStatus();
//		sts = (2 == sts) ? 4 : 0;
//		if (this->DlgStatus.nowCtrlState != sts) {
//			this->DlgStatus.nowCtrlState = sts;
//			this->DlgStatus.CheckTheCtrlState();
//		}
//	}
// #KS20130417-01(E)
}

int	DlgSG300::SetSecsSystemItem(CString item_name, long item_data)
{
	int		isErr;
	VARIANT	vtData;
	VariantInit( &vtData );
	vtData.vt	= VT_I4;				// LONG�^
	vtData.lVal	= item_data;			// 
	isErr = m_hXComSecs.PutSecsItem(item_name, vtData, 0, 0, 0, 0);		// ���[�U�ϐ��ɑ��M������e���Z�b�g
	VariantClear( &vtData );
	return isErr;
}
void DlgSG300::Init(int class_id, int myErrorStart){
	// �G���[�̏�����
	this->err.Initinstance(class_id, myErrorStart);
	CString waferId;
	for(int i=0;i<eWaferNumberMax;i++){
		waferId.Format("BottomWafer%02d",i+1);
		waferIdOfContentMap[i]	= waferId;
		waferIdOfManual[i]		= waferId;
	}
}
void DlgSG300::ErrorLogOut(int line,int Error){
	CString buf;
	buf.Format("SoftComGem300 Error(%d) 0x%08X", line, Error);
	// �G���[�̏�����
	this->err.LogSaveNFL(buf);
}


// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//BOOL DlgSG300::OpenProject(){
BOOL DlgSG300::OpenProject(int iMode){
	GWPPfileData(SECS_INIT_FILE_PATH, "OPTION", "AlarmMsgName", TRUE, AlarmMsgName, AlarmMsgName);
	BOOL r = TRUE;
	long lRet;
	// ���O�ɃG�O�[���E���B
	this->KillTheExeFiles();
	m_hXComSecs.SetOpenMode(1);
	if((lRet = m_hXComSecs.OpenProject(this->pathName,this->projectName)) != 0){
		r = FALSE;
		this->err.PutError(Err_ProjectNotOpened1);
		this->ErrorLogOut(__LINE__,lRet);
		return r;
	}
	m_hXComSecs.SetOpenMode(2);
	if((lRet = m_hXComSecs.OpenProject(this->pathName,this->projectName)) != 0){
		m_hXComSecs.CloseProject();	//���s������v���W�F�N�g���N���[�Y
		r = FALSE;
		this->err.PutError(Err_ProjectNotOpened2);
		this->ErrorLogOut(__LINE__,lRet);
		return r;
	}
// #MO20131101 [�ǉ�] SoftComGem300�@�\���g�p���Ă��邩�Z�b�g
	if(this->useSoftComGem300){
		this->initCarrierObj_flg = TRUE;	//�c���Ă���S�L�����A�̏�����(�r�o)
		m_hCsg300cms.SetOpenMode(0);
		if((lRet = m_hCsg300cms.OpenProject(this->pathName,this->projectName)) != 0){
			m_hXComSecs.CloseProject();	//���s������v���W�F�N�g���N���[�Y
			r = FALSE;
			//#MO20131105[�ǉ�]Gem300NG�p�̃G���[�쐬�E�\��
			this->err.PutError(Err_Gem300ProjectNotOpened);
			this->ErrorLogOut(__LINE__,lRet);
			return r;
		}
		//Create PJM project
		m_hCsg300pjm.SetOpenMode(0);
		lRet = m_hCsg300pjm.OpenProject(this->pathName,this->projectName);
		if(lRet != 0){
			m_hCsg300pjm.CloseProject();
			r = FALSE;
			return r;
		}
		
		//Create CJM project
		m_hCsg300cjm.SetOpenMode(0);
		lRet = m_hCsg300cjm.OpenProject(this->pathName,this->projectName);
		if(lRet != 0){
			m_hCsg300cjm.CloseProject();
			r = FALSE;
			return r;
		}
	}
	BOOL r2 = TRUE;
	// �ʐM�m����Ԃ̐ݒ�B
// #KS20130511-01 [�s�]OFFLINE�ɂȂ�Ȃ�
	this->DlgStatus.nowCtrlState = 0;
	this->DlgStatus.ShowWindow( SW_SHOWNA );
// #KS20130417-01 [�ǉ�]GEM�Q�|�[�g��
	if(false){
//		this->DlgStatus.SetWindowPos( &wndTopMost, m_WorkRect.left+m_WorkRect.right-ST_W * (ID + 1), m_WorkRect.top+m_WorkRect.bottom-ST_H, ST_W, ST_H, 0 );
	}else{
		this->DlgStatus.SetWindowPos( &wndTopMost, m_WorkRect.left+m_WorkRect.right-ST_W, m_WorkRect.top+m_WorkRect.bottom-ST_H, ST_W, ST_H, 0 );
	}
	this->DlgStatus.ShowWindow( SW_SHOWNOACTIVATE );
	// S1F13�p�̐ݒ�B
	this->PutSecsVidSingleASCII("_MDLN"		, "FC6000");
	this->PutSecsVidSingleASCII("_SOFTREV"	, this->softRevision);
	if(r2 != 0){
	}
	this->goRemote = false;
	for(int i=0;i<ePortNoMax;i++){
		this->loadedByHost[i]			= false;
		this->carrierId[i]				= "";
	}
	return r;
}

void DlgSG300::KillTheExeFiles()
{
	CString comLogExe = "COMLOG  [" + this->projectName + "]";
	this->KillTheExe(comLogExe);								// ComLog.exe	�I��
	this->KillTheExe(this->pathName + "\\Hsms.exe");			// Hsms.exe		�I��
	this->KillTheExe(this->pathName + "\\Spool.exe");			// Spool.exe	�I��
}
void DlgSG300::KillTheExe(CString fileName)
{
	CString strWndName;
	CWnd	*cwnd;
	strWndName.Format(fileName);
	cwnd = pCwnd->FindWindow(NULL, strWndName);
	if(cwnd != NULL){
		cwnd->PostMessage(WM_CLOSE);
	}
}
BOOL DlgSG300::CloseProject(){
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (pSecsTDS) {
//			if (0 == pSecsTDS->Terminate()) {
//				r = TRUE;
//			}
//		}
//		this->DlgStatus.CloseTheDialog();
//		KillTimer(1);
//		return(r);
//	}
// #KS20130417-01(E)
	BOOL r = TRUE;
	// Unload�͒ʏ�̕��@�Ɏ~�߂�
//	int r2 = this->UnloadALLCarrierObj();
	//Force take out carrier
	for(int i = 0; i < ePortNoMax; i++) {
		this->CarrierForceTakeOut(i, this->carrierId[i]);
	}
	this->DeleteAllCtrJob();
	this->DeleteAllPrJob(); 
	if(this->useSoftComGem300){
		this->m_hCsg300cms.SetCloseMode(0);
		this->m_hCsg300cms.CloseProject();
	}
	this->m_hXComSecs.SetCloseMode(0);
	this->m_hXComSecs.CloseProject();
	this->comState = 0;
	this->DlgStatus.CloseTheDialog();
	return r;
}
///////////////////////////////////////////////////
//
//
//
//
//	O n l i n e  / O f f l i n e �֌W
//
//
//

BOOL DlgSG300::ChangeCR(){

	CString	sStr;
	BOOL r = TRUE;
	//
	this->pEvFinInfoSeleStat	= &EvFinSeleStat;
	this->pEvFailInfoSeleStat	= &EvFailSeleStat;
	//
	m_hXComSecs.ChangeCR();
	return r;
}

BOOL DlgSG300::ChangeOffLine(){
	BOOL r = TRUE;
	long lRet;
	if(getCtrlState() > eHostOffline){	//�X�e�[�^�X��OnLine��������
//		this->goOffline	= true;
		this->goLocal	= false;
		this->goRemote	= false;
		if((lRet = m_hXComSecs.ChangeOnline(0)) != 0){
			r = FALSE;
		}
	}
	return r;
}


BOOL DlgSG300::ChangeOnLineLocal(){

	BOOL r = TRUE;
	long lRet;

//	this->goLocal	= true;
//	this->goRemote	= false;
	if(getCtrlState() <= eHostOffline){	//OffLine��������
		if((lRet = m_hXComSecs.ChangeOnline(1)) != 0){
			r = FALSE;
		}
	}else if(getCtrlState() == eOnlineRemote){	//OnLineRemote��������
		if((lRet = m_hXComSecs.ChangeOnlineSubState(0)) != 0){
			r = FALSE;
		}
	}
	return r;
}


BOOL DlgSG300::ChangeOnLineRemote(){
	BOOL r = TRUE;
	long lRet;
	// 
	if(getCtrlState() == eOnlineLocal){	//OnLineLocal��������
		if((lRet = m_hXComSecs.ChangeOnlineSubState(1)) != 0){
			r = FALSE;
			return r;
		}
	}else if(getCtrlState() <= eHostOffline){	//OffLine��������
		if((lRet = m_hXComSecs.ChangeOnline(1)) != 0){
			r = FALSE;
			return r;
		}
		this->goRemote = true;
	}

	return r;
}


/////////////////////////////////////////////////////////
//
//
//
//	I t e m  and  V I D �֌W
//
//
//
//

short DlgSG300::getVIDValSingleUNIT1(LPCSTR vid_name)
{
	//�v�f��1 UNIT1 ��VID�̒l���擾����(��ɃX�e�[�^�X���)
	short status, i_type;
	long elm;
	VARIANT	v;
	VariantInit(&v);
	m_hXComSecs.GetVIDVal(vid_name, &v, &i_type, &elm, 0,0,0,0);
	status = v.bVal;
	VariantClear(&v);
	return status;
}


BOOL DlgSG300::setAttDataSingleUINT1(CString ObjType, CString ObjId, LPCSTR attr_name, unsigned char data_v){

	BOOL r = TRUE;
	long	ret;
	VARIANT	vObjType, vObjId, v;
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&v);
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = ObjType.AllocSysString();
	vObjId.vt = VT_BSTR;
	vObjId.bstrVal = ObjId.AllocSysString();
	v.vt = VT_UI1;
	v.bVal = data_v;
	if((ret = m_hXComSecs.PutAttrData(vObjType, vObjId, attr_name, v, 0x00A4, 1, 0, 0, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&vObjType);
	VariantClear(&vObjId);
	VariantClear(&v);
	return r;
}

short DlgSG300::getAttDataSingleUINT1(CString ObjType, CString ObjId, LPCSTR attr_name){
	VARIANT	vObjType, vObjId, v;
	short val, item_type;
	long	element;
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&v);
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = ObjType.AllocSysString();
	vObjId.vt = VT_BSTR;
	vObjId.bstrVal = ObjId.AllocSysString();
	item_type = 0x00A4;
	element = 1;
	m_hXComSecs.GetAttrData(vObjType, vObjId, attr_name, &v, &item_type, &element, 0, 0, 0, 0);
	val = v.bVal;
	VariantClear(&vObjType);
	VariantClear(&vObjId);
	VariantClear(&v);
	return val;
}

CString DlgSG300::getCarrierID(){
	CString sCarrierID;
	short i_type;
	long elm;
	VARIANT	v;
	VariantInit(&v);
	m_hXComSecs.GetVIDVal("_CARRIERID", &v, &i_type, &elm, 0,0,0,0);
	sCarrierID = v.bstrVal;
	VariantClear(&v);
	return sCarrierID;
}

// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O

BOOL DlgSG300::PutSecsItemSingleUnsignInt(CString item_name, unsigned int data_ui, CString data_format)
{
	//data_format : "U1"or"U2"or"U4"
	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;

	VariantInit(&v_data);

	if(data_format == "U1"){
		v_data.vt = VT_UI1;
		v_data.bVal = data_ui;
	}else if(data_format =="U2"){
		v_data.vt = VT_I4;
		v_data.lVal = data_ui;
	}else if(data_format == "U4"){
		v_data.vt = VT_R8;
		v_data.dblVal = data_ui;
	}else{
		r = FALSE;
		VariantClear(&v_data);
		return r;
	}

	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, 0, 0, 0, 0)) != 0){
		r = FALSE;
///		WriteLog( ERRMSGID7, "PutSecsItemSingleUnsignInt() Error: 0x%08X,  ItemName=%s", ret, item_name, data_format);
	}

	VariantClear(&v_data);
	return r;
}

// #KS20130415-01(E)

BOOL DlgSG300::PutSecsItemSingleASCII(CString item_name, CString item_data){
	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_BSTR;
	v_data.bstrVal = item_data.AllocSysString();
	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, 0, 0, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}

BOOL DlgSG300::PutSecsVidSingleASCII(CString item_name, CString item_data)
{
	BOOL isErr = FALSE;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_BSTR;
	v_data.bstrVal = item_data.AllocSysString();
	isErr = m_hXComSecs.PutSecsItem(item_name, v_data, item_data.GetLength(), 0, 0, 0);
	VariantClear(&v_data);
	return isErr;
}


BOOL DlgSG300::PutSecsItemSingleBIN(CString item_name, unsigned char item_data){

	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_UI1;
	v_data.bVal = item_data;
	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, 0, 0, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}
BOOL DlgSG300::PutExtendItemSingleASCII(CString item_name, CString item_data, int element1, int element2)
{
	BOOL r = TRUE;
	long isErr	= FALSE;
	VARIANT v_data;
	VariantInit( &v_data );
	v_data.vt = VT_BSTR;
	v_data.bstrVal	= item_data.AllocSysString();
	if((isErr = m_hXComSecs.PutExtendItem(item_name, v_data, 0x0040, item_data.GetLength(), element1, element2, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}


BOOL DlgSG300::PutExtendItem4ByteInteger(CString item_name, int item_data, int element1, int element2)
{
	BOOL r = TRUE;
	long isErr	= FALSE;
	VARIANT v_data;
	VariantInit( &v_data );
	v_data.vt	= VT_I4;										// LONG�^
	v_data.lVal = item_data;
	if((isErr = m_hXComSecs.PutExtendItem(item_name, v_data, 0x0070, 1, element1, element2, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}

BOOL DlgSG300::PutSecsItem4ByteInteger(CString item_name, int item_data, int element1, int element2)
{
	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_I4;
	v_data.lVal = item_data;
//	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, 0, 0, 0, 0)) != 0){
	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, element1, element2, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}
// #MO20131129 [�ǉ�]SECS�E�F�n�}�b�s���O
BOOL DlgSG300::PutSecsItem8ByteFloating(CString item_name, int item_data, int element1, int element2)
{
	BOOL r = TRUE;
	long	ret;
	VARIANT v_data;
	VariantInit(&v_data);
	v_data.vt = VT_R8;
	v_data.lVal = item_data;
	if((ret = m_hXComSecs.PutSecsItem(item_name, v_data, element1, element2, 0, 0)) != 0){
		r = FALSE;
	}
	VariantClear(&v_data);
	return r;
}

// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O
unsigned int DlgSG300::GetItemDataSingleUnsignInt(CString item_name, CString data_format)
{
	//data_format : "U1"or"U2"or"U4"
	BOOL r = TRUE;
	VARIANT v_data;
	SHORT	i_type;
	LONG	i_elm;
	unsigned int val;

	VariantInit(&v_data);
	m_hXComSecs.GetItemData(item_name, &v_data, &i_type, &i_elm, 0, 0, 0, 0);

	if(data_format == "U1"){
		val = v_data.bVal;
	}else if(data_format == "U2"){
		val = v_data.lVal;
	}else if(data_format == "U4"){
		val = v_data.ulVal;
	}else if(data_format == "I2"){
		val = v_data.iVal;
	}

	VariantClear(&v_data);
	return val;
}
// #KS20130415-01(E)

CString DlgSG300::GetItemDataSingleASCII(CString item_name){
	VARIANT v_data;
	short i_type;
	long elm;
	CString item_data;
	VariantInit(&v_data);
	m_hXComSecs.GetItemData(item_name, &v_data, &i_type, &elm, 0, 0, 0, 0);
	item_data = v_data.bstrVal;
	VariantClear(&v_data);
	return item_data;
}

// #MO20131130 [�ǉ�]SECSϯ��ݸ�
int DlgSG300::GetItemDataSingleInt(CString item_name)
{
	VARIANT v_data;
	SHORT	i_type;
	LONG	i_elm;
	int		val;
	VariantInit(&v_data);
	m_hXComSecs.GetItemData(item_name, &v_data, &i_type, &i_elm, 0, 0, 0, 0);
    val = v_data.iVal;
	VariantClear(&v_data);
	return val;
}

///////////////////////////////////////////////////
//
//
//
//
//	��@�M�@E�@v�@e�@n�@t�@�ց@�W
//
//
//
//
BOOL DlgSG300::WaitingMessageCancel(){
	//HOST�񓚑҂���Ԃ���̊J��

	BOOL r = TRUE;
	CString sCarrierId;
	sCarrierId = this->getCarrierID();
	//  _CARRIERIDSTATUS:1  ID Read  (HOST�񓚑҂�) 
	if(getAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS") == 1){
		if(this->pEvFinInfoBottomCarrierIdRead){	//�҂���ԊJ��
			this->pEvFinInfoBottomCarrierIdRead->SetEvent();
		}
		//����_CARRIERIDSTATUS:2   ID Verification OK 
		this->setAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS", 2);
	//  _SLOTMAPSTATUS:1  SLOTMAP Read  (HOST�񓚑҂�) 
	}else if(getAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS") == 1){
		if(this->pEvFinInfoBottomSlotMap){	//�҂���ԊJ��
			this->pEvFinInfoBottomSlotMap->SetEvent();
		}
		if(this->pEvFinInfoTopSlotMap){	//�҂���ԊJ��
			this->pEvFinInfoTopSlotMap->SetEvent();
		}
		//����_SLOTMAPSTATUS:2   Slotmap Verification OK 
		this->setAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS", 2);
	}
	return r;
}

void DlgSG300::OnInfoComStateXcomsecsctrl1(short com_state, short hst_sts, short eq_sts) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������

	CString	sStr;
	this->comState = com_state;
	switch(com_state){
		case 0:		//�ʐM����
			if(this->pEvFailInfoComState){
				this->pEvFailInfoComState->SetEvent();
			}
#if !Release
				TRACE("comstatus = 0 �ʐM�L�� �ʐM���s\n");
#endif
			break;
		case 1:		//�ʐM�L���@�ʐM���f
			if(eq_sts!= 0){	//wait��Ԃ̂Ƃ�0 ����ȊO�̂Ƃ�0�ȊO(���M)
				this->count_S1F13 ++;
//				sStr.Format("%s%x%s%d", "COM_STATAS:", com_state, " ��:", this->count_S1F13);
//				sStr.Format("%s%x%s%x%s%x", "COM_STATAS:", com_state, " hst_sts:", hst_sts, " eq_sts:", eq_sts);
//				AfxMessageBox(sStr, MB_OK, 0);
			}
#if !Release
				TRACE("comstatus = 1 �ʐM�L�� �ʐM���f\n");
#endif
			if(this->count_S1F13 > 10){
				if(this->pEvFailInfoComState){
					this->pEvFailInfoComState->SetEvent();
				}
			}

			break;
		case 2:		//�ʐM�L��	�ʐM���s
			if(this->pEvFinInfoComState){
				this->pEvFinInfoComState->SetEvent();
			}
#if !Release
				TRACE("comstatus = 2 �ʐM�L�� �ʐM���s\n");
#endif
			break;
	}
}

void DlgSG300::OnInfoControlStateEventXcomsecsctrl1(short state) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������

	switch(state)
	{
		case 0: //Equip OFFLINE
#if !Release
	TRACE("OnInfoControlState = 0(Equip OFFLINE)\n");
#endif
			if(this->goRemote || this->goLocal){
				this->goLocal = false;
				m_hXComSecs.ChangeOnline(1);
#if !Release
	TRACE("m_hXComSecs.ChangeOnline(1)\n");
#endif
			}else if(getVIDValSingleUNIT1("_PRECTRLSTATE") == 5){	//�O��Ԃ��R���g���[�������[�g��������
				this->WaitingMessageCancel();	//HOST�҂���Ԃ���̊J��
			}
			break;
		case 1:	//Host OFFLINE
#if !Release
	TRACE("OnInfoControlState = 1(Host OFFLINE)\n");
#endif
			if(getVIDValSingleUNIT1("_PRECTRLSTATE") == 5){	//�O��Ԃ��R���g���[�������[�g��������
				this->WaitingMessageCancel();	//HOST�҂���Ԃ���̊J��
			}
			break;

		case 2: //Attempt ONLINE
#if !Release
	TRACE("OnInfoControlState = 2(Attempt OFFLINE)\n");
#endif
			if(getVIDValSingleUNIT1("_PRECTRLSTATE") == 5){	//�O��Ԃ��R���g���[�������[�g��������
				this->WaitingMessageCancel();	//HOST�҂���Ԃ���̊J��
			}
			break;

		case 3: //CONTROL_STAT_ONLINE_LOCAL:
#if !Release
	TRACE("OnInfoControlState = 3(ONLINE LOCAL)\n");
#endif
			if(this->goRemote){
				m_hXComSecs.ChangeOnlineSubState(1);	//REQ_ONLINE_SUBSTATE_REMOTE
				this->goRemote = false;
			}else if(getVIDValSingleUNIT1("_PRECTRLSTATE") == 5){	//�O��Ԃ��R���g���[�������[�g��������
				this->WaitingMessageCancel();	//HOST�҂���Ԃ���̊J��
			}
			break;

		case 4: //CONTROL_STAT_ONLINE_REMOTE:
#if !Release
	TRACE("OnInfoControlState = 4(ONLINE REMOTE)\n");
#endif
			break;
	}
	// �ʐM�m����Ԃ̕\���ύX
	this->DlgStatus.nowCtrlState = this->getCtrlState();	// ���ʃN���X�փZ�b�g
	this->DlgStatus.CheckTheCtrlState();
}

void DlgSG300::OnGetSecsEventXcomsecsctrl1(LPCTSTR event_name) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	if(strcmp(event_name, "_GS02F41R") == 0){
		this->RecvS02F41();
	}
	else if(strcmp(event_name, "_GS03F17R") == 0){
		// ContentMap�̎擾�͂����ł͂��Ȃ�(���ۂɗ~�������O�ɍs��)
	}
	else if(strcmp(event_name, "_GS07F19R") == 0){
		this->RecvS07F19();
	}
	else if(strcmp(event_name, "_GS07F25R") == 0){
		this->RecvS07F25();
	}
	else if(strcmp(event_name, "_GS12F74R") == 0){
		if(this->pEvFinInfoFileMapName)	//�҂���ԊJ��
			this->pEvFinInfoFileMapName->SetEvent();
	}
// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O	
	else if(strcmp(event_name, "_GS12F02R") == 0){
		if (this->RecvS12F2()) {
			SendS12F5();
		}
	}
	else if(strcmp(event_name, "_GS12F04R") == 0){
		if (this->RecvS12F4()) {
			this->SendS12F15();
		}
	}
	else if(strcmp(event_name, "_GS12F16R") == 0){											//130206_Misato
		this->RecvS12F16();
	}
	else if(strcmp(event_name, "_GS12F06R") == 0){											//13020_Misato
		if (this->RecvS12F6()) {
			SendS12F9();
		}
	}
	else if(strcmp(event_name, "_GS12F10R") == 0){											//13020_Misato
		this->RecvS12F10();
	}
// #KS20130415-01(E)
	else if(strcmp(event_name, "_GS12F74R") == 0){
		if(this->pEvFinInfoFileMapName)	//�҂���ԊJ��
			this->pEvFinInfoFileMapName->SetEvent();
	}
	else if(strcmp(event_name, "_InternalErr") == 0){
		long errcode = m_hXComSecs.GetErrorStatus();
		if(errcode == 0xC600B105 || errcode == 0xC600B205){
#if 0
			if(this->pEvFinInfoSeleStat){	//�҂���ԊJ��
				this->pEvFinInfoSeleStat->SetEvent();
			}
#else
	m_hXComSecs.ChangeCR();
#endif
		}
	}
// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O	
	else if (0 == strcmp(event_name, "_Illegal_SF")
		|| 0 == strcmp(event_name, "_TransactionTimeout")
		|| 0 == strcmp(event_name, "_AbortTransaction")) {
		VARIANT vtMHead;
		VariantInit(&vtMHead);
		vtMHead = m_hXComSecs.GetMhead();
		SAFEARRAY FAR *pArray = vtMHead.parray;
		char DispStr[80], DataStr[16];
		unsigned char cData;
		long i;
		int s, f;
		wsprintf((LPSTR) DispStr, "MHEAD = ");
		for(i = 0; i < 10; i++) {
			if (SafeArrayGetElement(pArray, (long FAR*)&i, &cData) != S_OK) {
				break;
			}
			if (2 == i) {
				s = cData;
			} else if (3 == i) {
				f = cData;
			}
			wsprintf((LPSTR)DataStr, "%02x ", cData);
			strcat(DispStr, DataStr);
		}
		if (10 == i) {
			if (12 == (~0x80 & s)) {	// ���s
				if (MapCtrl.bReqMap) {
					MapCtrl.bReqMap = FALSE;
					MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_FailRecv;
					MapCtrl.EvReqMapOK.SetEvent();
					MapCtrl.EvReqMapEnd.SetEvent();
				}
			}
		}
		if(i == 10) {
// #KS20130415-01 [�C���K�v]SECS�E�F�n�}�b�s���O	
// #KS20130510-01 [���P]S5F2���s�v�ȃA���[���Ή�
//			AfxMessageBox(DispStr, MB_OK | MB_ICONINFORMATION, 0);
		}
		VariantClear(&vtMHead);
	}
// #KS20130415-01(E)
	else if(strcmp(event_name, "__GS03F17R_CR") == 0){
		// �ʏ��S3F17�͂����ł͎󂯎��Ȃ����߁ACarrierRelease��p��__GS03F17R_CR���쐬����
		// �󂯎�邱�ƂƂ���B
		short	item_type;
		long	ret,element;
		VARIANT	vtData;
		short	port_no;
		VariantInit( &vtData );
		ret = m_hXComSecs.GetItemData("Itm_PORT_NO",&vtData, &item_type,&element,0,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
//			return;
		}
		port_no = vtData.bVal;
		this->RecvCarrierRelease(port_no);
	}
	else if(strcmp(event_name, "__GS03F17R_CN") == 0){		//�ǉ�120524
		// �ʏ��S3F17�͂����ł͎󂯎��Ȃ����߁ACarrierNotification��p��__GS03F17R_CN���쐬����
		// �󂯎�邱�ƂƂ���B
		short	item_type;
		long	ret,element;
		VARIANT	vtData;
		short	port_no;
		CString carrierId;
		VariantInit( &vtData );
		ret = m_hXComSecs.GetItemData("Itm_PORT_NO",&vtData, &item_type,&element,0,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
			return;
		}
		port_no = vtData.bVal;
		VariantInit( &vtData );
		ret = m_hXComSecs.GetItemData("Itm_CARRIERID",&vtData, &item_type,&element,0,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
			return;
		}
		carrierId = vtData.bstrVal;
		VariantClear(&vtData);
		this->RecvCarrierNotification(port_no, carrierId);
	}
	// TCP/IP�ؒf�ʒm
	else if(strcmp(event_name, "_Disconnect") == 0){
		// �v���W�F�N�g�t�@�C������U�ۑ�����
		this->m_hXComSecs.WriteCurrentData();
		// �v���W�F�N�g�̃N���[�Y
		this->m_hXComSecs.SetCloseMode(2);
		this->m_hXComSecs.CloseProject();
		// �f�B���C
		::Sleep(500);
		m_hXComSecs.SetOpenMode(2);
		m_hXComSecs.OpenProject(this->pathName,this->projectName);
	} else if (strcmp(event_name, "__GS16F15R_T") == 0) {
		// meke enough time to pEvCJCreate not NULL
		::Sleep(100);
		this->RecvS16F15(false);
	} else if (strcmp(event_name, "__GS16F15R_B") == 0) {
		// meke enough time to pEvCJCreate not NULL
		::Sleep(100);
		this->RecvS16F15(true);
	} else if (strcmp(event_name, "__GS14F09R_N") == 0) {
		::Sleep(100);
		this->RecvS14F09();
	}
}
void DlgSG300::OnInfoCarrierIdStateEventSg300cmsctrl1(short ptn, const VARIANT FAR& carrierid, short state) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
#if !Release
	TRACE("OnInfoCarrierIdState = port(%d),Status(%d)\n", ptn, state);
#endif
	CString msg;
	switch(state)
	{
	case 0:	//Not Read
		break;
	case 1:	//Waitting For Host
		break;
	case 2: //VERIFICATION_OK
#if !Release
	TRACE("(Verification OK)\n");
#endif
		if((ptn == eBottomPortNo)&&(this->pEvFinInfoBottomCarrierIdRead)){
			this->EvBottomCJCreate.ResetEvent();
			this->pEvFinInfoBottomCarrierIdRead->SetEvent();
		}
		//If it is top wafer port
		if((MIN_TOP_PORT_NO <= ptn) && (MAX_TOP_PORT_NO >= ptn)
		&& (this->pEvFinInfoTopCarrierIdRead[ptn - MIN_TOP_PORT_NO])){
			// �����ŏ��߂�PJ CJ���󂯕t����(CJ is Acceptable)
			this->EvTopCJCreate.ResetEvent();
			this->pEvFinInfoTopCarrierIdRead[ptn - MIN_TOP_PORT_NO]->SetEvent();
			msg.Format("pEvFinInfoTopCarrierIdRead[%d].SetEvent()\n", ptn - MIN_TOP_PORT_NO);
		}
		break;
	case 3: //VERIFICATION_NG
#if !Release
	TRACE("(Verification NG)\n");
#endif
		{
			CString msg;
			msg.Format("CancelCarrierIDRead None\n");
			if((ptn == eBottomPortNo)&&(this->pEvFailInfoBottomCarrierIdRead)){
				this->pEvFailInfoBottomCarrierIdRead->SetEvent();
				msg.Format("EvFailInfoBottomCarrierIdRead.SetEvent()\n");
			}
			if((ptn == eTopPortNo1)&&(this->pEvFailInfoTopCarrierIdNotified)){
				this->pEvFailInfoTopCarrierIdNotified->SetEvent();
				msg.Format("pEvFailInfoTopCarrierIdNotified.SetEvent()\n");
			}
			//If it is top wafer port
			if((MIN_TOP_PORT_NO <= ptn) && (MAX_TOP_PORT_NO >= ptn)
			&& (this->pEvFailInfoTopCarrierIdRead[ptn - MIN_TOP_PORT_NO])){
				this->pEvFailInfoTopCarrierIdRead[ptn - MIN_TOP_PORT_NO]->SetEvent();
				msg.Format("pEvFailInfoTopCarrierIdRead[%d].SetEvent()\n", ptn - MIN_TOP_PORT_NO);
			}
			this->err.LogSaveNFL(msg);
#if !Release
			TRACE(msg);
#endif
			if(this->getCtrlState() != eOnlineRemote){		//Online Remote�ȊO��NG�𖳎����Đ�ɐi�߂�悤�ɂ���
				this->setAttDataSingleUINT1("Carrier", this->getCarrierID(), "_CARRIERIDSTATUS", 2);
			}
		}
		break;
	}
}

void DlgSG300::OnInfoSlotMapStateEventSg300cmsctrl1(short ptn, const VARIANT FAR& carrierid, const VARIANT FAR& slotmap, short slotcount, short state) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
#if !Release
	TRACE("OnInfoSlotMapState = port(%d),Status(%d)\n", ptn, state);
#endif
	switch(state)
	{
	case 0:	//Not Read
		break;
	case 1:	//Waitting For Host
		break;
	case 2: //VERIFICATION OK
#if !Release
	TRACE("(Verification OK)\n");
#endif
		if((ptn == eBottomPortNo)&&(this->pEvFinInfoBottomSlotMap)){
			this->pEvFinInfoBottomSlotMap->SetEvent();
		}
		if((ptn == eTopPortNo1) && (this->pEvFinInfoTopSlotMap)){
			this->pEvFinInfoTopSlotMap->SetEvent();
		}
		break;
	case 3: //VERIFICATION NG
#if !Release
	TRACE("(Verification NG)\n");
#endif
		{
			CString msg;
			msg.Format("CancelSlotMapRead None\n");
			if((ptn == eBottomPortNo)&&(this->pEvFailInfoBottomSlotMap)){
				this->pEvFailInfoBottomSlotMap->SetEvent();
				msg.Format("EvFailInfoBottomSlotMap.SetEvent()\n");
			}
			if((ptn == eTopPortNo1)&&(this->pEvFailInfoTopSlotMap)){
				this->pEvFailInfoTopSlotMap->SetEvent();
				msg.Format("EvFailInfoTopSlotMap.SetEvent()\n");
			}
			this->err.LogSaveNFL(msg);
#if !Release
			TRACE(msg);
#endif
			if(this->getCtrlState() != eOnlineRemote){		//Online Remote�ȊO��NG�𖳎����Đ�ɐi�߂�悤�ɂ���
				this->setAttDataSingleUINT1("Carrier", this->getCarrierID(), "_SLOTMAPSTATUS", 2);
			}
		}
		break;
	}
}

void DlgSG300::OnGetServiceEventSg300cmsctrl1(LPCTSTR service_name) 
{
	//S3F17�̃��b�Z�[�W���e���擾����(CarrierAction)
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	short status	= 0;
	int	port_no		= 0;
	//
	if(strcmp(service_name, "CancelCarrier") == 0){
//		::Sleep(1500);
		// CancelCarrier�Ƃ����T�[�r�X�̓f�t�H���g�ő��݂���̂ŁA��������̗p����B
		status = getVIDValSingleUNIT1("_CARRIERACCESSSTATUS");
		port_no = getVIDValSingleUNIT1("_PORTID");
		{
			CString msg;
			msg.Format("%s(%d) CancelCarrierReceived status(%d), port_no(%d)\n",
											__FILE__, __LINE__,status,port_no);
			this->err.LogSaveNFL(msg);
#if !Release
			TRACE(msg);
#endif
		}
		if(status == 0){	//CARRIERACCESSSTATUS��not accessed�̂Ƃ��̂݉\����ȍ~�͋���
			CString msg;
			//�҂���ԉ���
			if((port_no==eBottomPortNo)&&(this->pEvFailInfoBottomCarrierIdRead)){
				this->pEvFailInfoBottomCarrierIdRead->SetEvent();
				msg.Format("EvFailInfoBottomCarrierIdRead.SetEvent()\n");
			} else if (((MIN_TOP_PORT_NO <= port_no) && (MAX_TOP_PORT_NO >= port_no))
			&& (this->pEvFailInfoTopCarrierIdRead[port_no - MIN_TOP_PORT_NO])){
				this->pEvFailInfoTopCarrierIdRead[port_no - MIN_TOP_PORT_NO]->SetEvent();
				msg.Format("pEvFailInfoTopCarrierIdRead[%d].SetEvent()\n", port_no - MIN_TOP_PORT_NO);
			
			}else if((port_no==eBottomPortNo)&&(this->pEvFailInfoBottomSlotMap)){
				this->pEvFailInfoBottomSlotMap->SetEvent();
				msg.Format("EvFailInfoBottomSlotMap.SetEvent()\n");
			}else if((port_no==eTopPortNo1)&&(this->pEvFailInfoTopSlotMap)){
				this->pEvFailInfoTopSlotMap->SetEvent();
				msg.Format("EvFailInfoBottomSlotMap.SetEvent()\n");
			}else{
				msg.Format("EventNone\n");
			}
			this->err.LogSaveNFL(msg);
#if !Release
			TRACE(msg);
#endif
		}
	}else if(strcmp(service_name, "CarrierRelease") == 0){
		// CarrierRelease�Ƃ����T�[�r�X���f�t�H���g�ł͑��݂��Ȃ��̂ŁAOnGetSecsEventXcomsecsctrl1�Ŏ󂯎�邱�Ƃɂ���B
	}
}
void DlgSG300::OnLinkXComChangedXcomsecsctrl1(short ocx_type, short status) 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	if(ocx_type == 4){	//1:SG300PJM  4:SG300CMS  5:SG300STS  6:SG300CJM
		if(status == 0){	//0:�����NOK�@1,2,3:�����N���s 10:�����N�����҂�
			if(this->initCarrierObj_flg == TRUE){
				::Sleep(1000);
				this->UnloadALLCarrierObj();
				this->DelALLCarrierObj();
				this->initCarrierObj_flg = FALSE;
			}
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////
//
//
//
//
//	C M S(C a r r i e r   M a n a g e m e n t)�֌W
//	Carrier Management�֌W
//
//
//
// �L�����A���u���ꂽ
BOOL DlgSG300::CarrierPlaced(short PortNo, bool placed)
{
	BOOL r = TRUE;
	// 
//	this->carrierIsPlaced	= true;
	// �ʐM�m�����Ă���OnlineRemote�ł���΁A
	if((this->comState == eCommunicating)
		/*&&(this->getCtrlState() == eOnlineRemote)*/){
		if(placed){	// �u���ꂽ
			// ReadyToUnload �����s����B
			r = this->CarrierTakeIn(PortNo);
		}else{		// ��������ꂽ
			// ReadyToLoad �����s����B
			r = this->CarrierTakeOut(PortNo);
		}
	}
	return r;
}
//////////////////////////////////////////////
//
// CarrierLoad
//
BOOL DlgSG300::CarrierLoad(short port_no, CString sCarrierId)
{
	// �r����return�֎~
	// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&CarrierSema);
	P.Lock();
	{
		CString msg;
		msg.Format("CarrierLoad(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
//	vCarrierId.vt = VT_BSTR;
//	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	short transferState;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	// TransferState���擾����B
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
			// �擾�ł��Ȃ����OutOfService�ƌ��Ȃ��B
			transferState	= eStateOutOfService;
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	if(r){
		// Bottom Wafer �� ReadyToUnload��Ԃł���΁A��U�A�����[�h���Ă��炤
		if((port_no == eBottomPortNo)&&(transferState == /*3*/eStateReadyToUnload)){
			this->err.PutError(Err_CarrierIsNotUnload);
			r = FALSE;
		}
	}
	if(r){
		// ReadyToLoad�łȂ����ReadyToLoad�ɂ���(���̍ہA��xTransferBlocked���o�R����B
		if(transferState != /*2*/eStateReadyToLoad){
			// ��UTransferBlocked�ɂ������Ƃ�ReadyToLoad
			if(transferState != /*1*/eStateTransferBlocked){	//not transfer blocked
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*2*/eCmdTransferBlocked)) != 0){	//transfer blocked
					r = FALSE;
					this->err.PutError(Err_Dlg300_03);
					this->ErrorLogOut(__LINE__,ret);
				}
			}
			////////////////////
			//
			// ReadyToLoad�ɕύX
			//
			if(r){
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*3*/eCmdReadyToLoad)) != 0){	//
					r = FALSE;
					this->err.PutError(Err_Dlg300_04);
					this->ErrorLogOut(__LINE__,ret);
				}
			}
		}
	}
	if(r){
		VariantInit(&vCarrierId);
		vCarrierId.vt = VT_BSTR;
		vCarrierId.bstrVal = sCarrierId.AllocSysString();
		/////////////////
		//
		// �L�����A�̃Z�[�u
		//
		this->carrierId[port_no]	= sCarrierId;
		//
		if(port_no == eBottomPortNo){
			this->TraceBotD.bottomWaferCarrierID	= sCarrierId;
		}else{
		}
		/////////////////////////
		//
		// �L�����A���[�h�J�n
		//
		if((ret = m_hCsg300cms.CarrierLoad(port_no, vCarrierId, /*1*/eCarrierStart)) != 0){		//���[�h�J�n
			VariantClear(&vCarrierId);
			r = FALSE;
			this->err.PutError(Err_CarrierLoadFailed);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	// 
	if(r){
		if((ret = m_hCsg300cms.CarrierLoad(port_no, vCarrierId, /*2*/eCarrierFinished)) != 0){
			r = FALSE;
			this->err.PutError(Err_CarrierLoadFailed);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("CarrierLoad(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	VariantClear(&vCarrierId);
	return r;
}
//////////////////////////////////////////////
//
// CarrierUnload
//
BOOL DlgSG300::CarrierUnLoad(short port_no)
{
	// �r����return�֎~
	// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("CarrierUnLoad(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
//	vCarrierId.vt = VT_BSTR;
//	vCarrierId.bstrVal = this->carrierId[port_no].AllocSysString();
	short transferState/* = getLPTransferState()*/;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	/////////////////////////
	//
	// TransferState���擾����B
	// ��{�I��LPTransferState���擾�ł��Ȃ����Ƃ͂��肦�Ȃ����c
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
			r = FALSE;
			this->err.PutError(Err_CarrierNotRecognizedB+port_no-1);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	if(r){
		// �X�e�[�^�X��ReadyToUnload�ɂ���(���̍ہATransferBlocked���o�R����)
		if(transferState != /*3*/eStateReadyToUnload){
			if(transferState != /*1*/eStateTransferBlocked){
				// TransferBlocked�ɂ���B
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*2*/eCmdTransferBlocked)) != 0){
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
			/////////////////////////
			//
			// ReadyToUnload�ɕύX����B
			//
			if(r){
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*4*/eCmdReadyToUnload)) != 0){	//ready to unload
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
		}
	}
	if(r){
		this->loadedByHost[port_no]	= false;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("CarrierUnLoad(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}

//////////////////////////////////////////////
//
// CarrierTakeIn
//
BOOL DlgSG300::CarrierTakeIn(short port_no)
{
	BOOL r = TRUE;
	// ���ɂȂ�
	// #DucMV 20160401 SECS ECID (S)
	// �C�x���g���s����
	r = this->PlacedEvent(port_no);
	// #DucMV 20160401 SECS ECID (E)
	return r;
}

//////////////////////////////////////////////
//
// CarrierTakeOut
//
BOOL DlgSG300::CarrierTakeOut(short port_no/*, bool errOut*/)
{
	// �r����return�֎~
	// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("CarrierTakeOut(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
//	vCarrierId.vt = VT_BSTR;
//	vCarrierId.bstrVal = this->carrierId[port_no].AllocSysString();
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	short transferState/* = getLPTransferState()*/;
	//////////////////////////////
	//
	// TransferState���擾����B
	//
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
			r = FALSE;
			this->err.PutError(Err_CarrierNotRecognizedB+port_no-1);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	
	// #DucMV 20160401 SECS ECID (S)
	if(transferState == /*2*/eStateReadyToLoad){
		r = TRUE;
		// �C�x���g���s����
		r = this->TakeOutEvent(port_no);
		return r;
	}
	// #DucMV 20160401 SECS ECID (E)
	///////////////////////////
	//
	// ���ł�ReadyToLoad��Ԃł���΁A(���łɃA�����[�h���ꂽ�Ƃ݂Ȃ�)�������Ȃ�
	//
	if(r&&(transferState != /*2*/eStateReadyToLoad)){
		/////////////////////////
		//
		// ���݂�ReadyToUnload�łȂ���΁A�X�e�[�^�X��ReadyToUnload�ɂ���(���̍ہATransferBlocked���o�R����)
		//
		if(transferState != /*3*/eStateReadyToUnload){
			if(transferState != /*1*/eStateTransferBlocked){
				// TransferBlocked�ɂ���B
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*2*/eCmdTransferBlocked)) != 0){
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
			//////////////////////////
			//
			// ReadyToUnload�ɕύX����B
			//
			if(r){
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*4*/eCmdReadyToUnload)) != 0){	//ready to unload
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
		}
		if(r){
			VariantInit(&vCarrierId);
			vCarrierId.vt = VT_BSTR;
			vCarrierId.bstrVal = this->carrierId[port_no].AllocSysString();
		}
		////////////////////////////////
		//
		// CarrierUnload����(�X�e�[�^�X�͎�����ReadyToLoad�ɂȂ�)
		//
		if(r){
			if((ret = m_hCsg300cms.CarrierUnLoad(port_no, vCarrierId, /*1*/eCarrierStart)) != 0){		//���o�J�n
				VariantClear(&vCarrierId);
				this->err.PutError(Err_Dlg300_10);
				this->ErrorLogOut(__LINE__,ret);
				r = FALSE;
			}
		}
		if(r){
			if((ret = m_hCsg300cms.CarrierUnLoad(port_no, vCarrierId, /*2*/eCarrierFinished)) != 0){	//���o����
				this->err.PutError(Err_Dlg300_10);
				this->ErrorLogOut(__LINE__,ret);
				r = FALSE;
			}
		}
	}// end of if(r)
	if(r){
		this->loadedByHost[port_no]	= false;
	}
	// #DucMV 20160401 SECS ECID (S)
	if(r){
		// �C�x���g���s����
		r = this->TakeOutEvent(port_no);
	}
	// #DucMV 20160401 SECS ECID (E)
	VariantClear(&vCarrierId);
	::Sleep(1000);
	{
		CString msg;
		msg.Format("CarrierTakeOut(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}
////////////////////////////
//
// �����I�ɃL�����A���A�����[�h����
//
//
BOOL DlgSG300::CarrierForceTakeOut(short port_no, CString sCarrierId)
{
	// �r����return�֎~
	// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("CarrierForceTakeOut(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
//	vCarrierId.vt = VT_BSTR;
//	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	short transferState/* = getLPTransferState()*/;
	// TransferState���擾����B
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
			r = FALSE;
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	/////////////////////////////////
	//
	// �X�e�[�^�X��ReadyToUnload�ɂ���(���̍ہATransferBlocked���o�R����)
	//
	if(r){
		if(transferState != /*3*/eStateReadyToUnload){
			if(transferState != /*1*/eStateTransferBlocked){
				// TransferBlocked�ɂ���B
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*2*/eCmdTransferBlocked)) != 0){
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
			////////////////////////
			//
			// ReadyToUnload�ɕύX����B
			//
			if(r){
				if((ret = m_hCsg300cms.ChangeLPTransferState(port_no, /*4*/eCmdReadyToUnload)) != 0){	//ready to unload
					r = FALSE;
					this->ErrorLogOut(__LINE__,ret);
				}
			}
		}
		VariantInit(&vCarrierId);
		vCarrierId.vt = VT_BSTR;
		vCarrierId.bstrVal = sCarrierId.AllocSysString();
	}
	///////////////////////////////
	//
	// CarrierUnload����(������ReadyToLoad�ɂȂ�)
	//
	if(r){
		if((ret = m_hCsg300cms.CarrierUnLoad(port_no, vCarrierId, /*1*/eCarrierStart)) != 0){		//���o�J�n
			VariantClear(&vCarrierId);
			this->ErrorLogOut(__LINE__,ret);
			r = FALSE;
		}
	}
	if(r){
		if((ret = m_hCsg300cms.CarrierUnLoad(port_no, vCarrierId, /*2*/eCarrierFinished)) != 0){	//���o����
			this->ErrorLogOut(__LINE__,ret);
			r = FALSE;
		}
		this->loadedByHost[port_no]	= false;
		::Sleep(1000);
	}
	{
		CString msg;
		msg.Format("CarrierForceTakeOut(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	VariantClear(&vCarrierId);
	return r;
}


short DlgSG300::getCtrlState()
{
	//���݂̃R���g���[����Ԃ��擾
	//1:Equipment Offline  2:Attempt Offline 3:Host Offline  4:Online Local  5:Online Remote
	short status, i_type;
	long elm;
	VARIANT	v;
	VariantInit(&v);
	m_hXComSecs.GetVIDVal("_CTRLSTATE",&v, &i_type, &elm, 0,0,0,0);
	status = v.bVal;
	VariantClear(&v);
	return status;
}

short DlgSG300::getLPTransferState()
{
	//���݂̃��[�h�|�[�g������Ԃ��擾
	//1:TRANSFER BLOCKED  2:READY TO LOAD 3:READY TO UNLOAD
	short status, i_type;
	long elm;
	VARIANT	v;
	VariantInit(&v);
	m_hXComSecs.GetVIDVal("_PORTTRANSFERSTATE",&v, &i_type, &elm, 0,0,0,0);
	status = v.bVal;
	VariantClear(&v);
	return status;
}

short DlgSG300::getLPTransferState(int port_no, CString sCarrierId)
{
	//���݂̃��[�h�|�[�g������Ԃ��擾
	//1:TRANSFER BLOCKED  2:READY TO LOAD 3:READY TO UNLOAD
//	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
//	vCarrierId.vt = VT_BSTR;
//	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	short transferState/* = getLPTransferState()*/;
	// TransferState���擾����B
	if((ret = m_hCsg300cms.GetLPTransferState(port_no, &vCarrierId, &transferState))){
		transferState = 0;
	}
	return(transferState);
}
///////////////////////////////////////
//
// �L�����A�h�c�̌���
//
BOOL DlgSG300::ReadBottomCarrierID(CString sCarrierId)
{
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&CarrierSema);
	P.Lock();
	{
		CString msg;
		msg.Format("ReadBottomCarrierID Start");
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	// CarrierIDReadEvent
	CEvent EvFinReadCarrierID;
	CEvent EvFailReadCarrierID;
	// �C�x���g�����Z�b�g����B
	EvFinReadCarrierID.ResetEvent();
	EvFailReadCarrierID.ResetEvent();
	pEvStopWaitingSecsB->ResetEvent();		// #DDT160703-02 Reset Stop Event
	// �C�x���g�̎��̐ݒ�
	this->pEvFinInfoBottomCarrierIdRead		= &EvFinReadCarrierID;
	this->pEvFailInfoBottomCarrierIdRead	= &EvFailReadCarrierID;
	this->PutPortNo((unsigned int)1);	// ���ꂩ��o������Ă�PortID����������
	///////////////////////////////////
	//
	// HOST��CarrierID�̌��ؗv�����s���B
	//
	BOOL r = TRUE;
	if(r){
		if((ret = m_hCsg300cms.ReadCarrierId(/*port_no*/1, vCarrierId, 1)) != 0){
			r = FALSE;
			this->err.PutError(Err_Dlg300_06);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("ReadBottomCarrierID Waiting Host");
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();		// �ȍ~�͑��҂�PortNo��ύX���Ă��悢�B
	if(r){
		VariantClear(&vCarrierId);
		enum{
			WaitCnt		= 3,
		};
		//
		CSyncObject *ppObjects[WaitCnt] = {0};
		ppObjects[0]	= pEvFinInfoBottomCarrierIdRead;	// VERIFICATION_OK
		ppObjects[1]	= pEvFailInfoBottomCarrierIdRead;	// VERIFICATION_NG
		ppObjects[2]	= pEvStopWaitingSecsB;		// ���f
		CMultiLock	M(ppObjects,WaitCnt);
		//
		if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
			// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
			int i = M.Lock(INFINITE, FALSE);
			M.Unlock();
			i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == i) {
				// ����
				r = TRUE;
			} else if (1 == i) {
				// ���s
				r = FALSE;
				this->err.PutError(Err_BottomReadIdCanceled);
			} else if (2 == i) {
				//�r����~(���f)
				r = FALSE;
				this->StoppedBEvent();
			}
			{
				CString msg;
				msg.Format("ReadBottomCarrierID finished = %d\n", r);
				if(!r){
					this->err.LogSaveNFL(msg);
				}
#if !Release
				TRACE(msg);
#endif
			}
		
		}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
				//����_CARRIERIDSTATUS:2   ID Verification OK 
			this->setAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS", 2);
		}
		{
			CString msg;
			msg.Format("ReadBottomCarrierID End r = %d",r);
			this->err.LogSaveNFL(msg);
		}
		{
			long	ret;
			VARIANT vCarrierIdList;
			long	Count;
			VariantInit(&vCarrierIdList);
			if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
				VariantClear(&vCarrierIdList);
			}
#if !Release
			if(Count > 0){
				TRACE("ReadBottomCarrierID��Carrier is %d\n", Count);
			}
#endif
		}
	}
	this->pEvFinInfoBottomCarrierIdRead		= NULL;
	this->pEvFailInfoBottomCarrierIdRead	= NULL;
	return r;
}
//////////////////////////////
//
//	���u��RFID���[�_�������Ă��Ȃ��ꍇ�̏���
//	HOST����CarrierID���擾���āACarrierLoad����B
//
BOOL DlgSG300::NotifyTopCarrierID()
{
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	// CarrierIDReadEvent
	CEvent EvFinNotifyCarrier;
	CEvent EvFailNotifyCarrier;
	// �C�x���g�����Z�b�g����B
	EvFinNotifyCarrier.ResetEvent();
	EvFailNotifyCarrier.ResetEvent();
	// �C�x���g�̎��̐ݒ�
	this->pEvFinInfoTopCarrierIdNotified	= &EvFinNotifyCarrier;
	this->pEvFailInfoTopCarrierIdNotified	= &EvFailNotifyCarrier;
//	this->PutPortNo((unsigned int)2);	// ���ꂩ��o������Ă�PortID����������
	{
		CString msg;
		msg.Format("NotifyTopCarrierID Start");
		this->err.LogSaveNFL(msg);
	}
	///////////////////////////////////////////
	//
	// �N�����v�C�x���g�̏o��(HOST��RFID��ǂ�ł������Ɠ`����)
	//
	BOOL r = TRUE;
	if(r){
		// �N�����v�C�x���g�̒��ŃZ�}�t�H���b�N���Ă���̂Œ��ӁB
		r = this->ClampEvent(eTopPortNo1);
	}
	enum{
		WaitCnt		= 3,
	};
	{
		CString msg;
		msg.Format("NotifyTopCarrierID Waiting Host");
		this->err.LogSaveNFL(msg);
	}
	///////////////////////////////////////////
	//
	// Notify�C�x���g�҂�
	//
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinInfoTopCarrierIdNotified;	// VERIFICATION_OK
	ppObjects[1]	= pEvFailInfoTopCarrierIdNotified;	// VERIFICATION_NG
	ppObjects[2]	= pEvStopWaitingSecsT;		// ���f
	CMultiLock	M(ppObjects,WaitCnt);
	//
	if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
		// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
		int i = M.Lock(INFINITE, FALSE);
		M.Unlock();
		i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
		if (0 == i) {
			// ����
			r = TRUE;
		} else if (1 == i) {
			// ���s
			r = FALSE;
			this->err.PutError(Err_TopReadIDCanceled);
		} else if (2 == i) {
			//�r����~(���f)
			r = FALSE;
			this->StoppedTEvent();
		}
		{
			CString msg;
			msg.Format("NotifyTopCarrierID finished = %d\n", r);
			if(!r){
				this->err.LogSaveNFL(msg);
			}
#if !Release
			TRACE(msg);
#endif
		}
	}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
			//����_CARRIERIDSTATUS:2   ID Verification OK 
//		this->setAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS", 2);
	}
#if !Release
	TRACE("CarrierLoad = %s\n", this->carrierId[eTopPortNo1]);
#endif
	if(r){
		////////////////////////////
		//
		// ������CarrierLoad����
		//
		// CarrierLoad()�̒��ŃZ�}�t�H���b�N���Ă���̂Œ���
		if(r){
			r = this->CarrierLoad(eTopPortNo1, this->carrierId[eTopPortNo1]);
		}
		// �r����return�֎~
		// �֐����I���܂ŁAPortNo�͕ύX�����Ȃ��B
		CSingleLock P1(&PortNoSema);
		P1.Lock();
		{
			CString msg;
			msg.Format("NotifyTopCarrierID ReadCarrierID");
			this->err.LogSaveNFL(msg);
		}
		// ���߂�PortNo���(�N�������������Ă邩������Ȃ��̂�)
		this->PutPortNo((unsigned int)2);	// ���ꂩ��o������Ă�PortID����������
		if(r){
			long	ret;
			vCarrierId.bstrVal = this->carrierId[eTopPortNo1].AllocSysString();
			////////////////////////////////////
			//
			// CarrierID�̌��؊����֑J�ڂ���(HOST�֌��ؗv���͂��Ȃ�)�B
			//
			if((ret = m_hCsg300cms.ReadCarrierId(/*port_no*/2, vCarrierId, 3)) != 0){
				r = FALSE;
				this->err.PutError(Err_Dlg300_06);
				this->ErrorLogOut(__LINE__,ret);
			}
		}
		::Sleep(500);
		{
			CString msg;
			msg.Format("NotifyTopCarrierID ReadCarrierID End");
			this->err.LogSaveNFL(msg);
		}
		P1.Unlock();	// ���҂�PortNo�������݋���
	}
	if(r){
		long	ret;
		VARIANT vCarrierIdList;
		long	Count;
		VariantInit(&vCarrierIdList);
		if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
			VariantClear(&vCarrierIdList);
		}
#if !Release
		if(Count > 0){
			TRACE("NotifyTopCarrierID��Carrier is %d\n", Count);
		}
#endif
	}
	{
		CString msg;
		msg.Format("NotifyTopCarrierID ReadCarrierID End");
		this->err.LogSaveNFL(msg);
	}
	this->pEvFinInfoTopCarrierIdNotified	= NULL;
	this->pEvFailInfoTopCarrierIdNotified	= NULL;
	return r;
}
//////////////////////////////
//
// SlotMap�̌���(ReadBottomSlotMap��ReadTopSlotMap���قړ���
// ���\�b�h�ł��邪�A�����ɌĂ΂�邱�Ƃ��\�z����A����
// ���ꂼ��̎�M�C�x���g�������Ȃ���΂����Ȃ��̂ŁA
// ���\�b�h�͂��ꂼ�ꎝ���Ƃɂ���B
// ����Foup���Q�A�}�K�W�����Q�ɂȂ����ꍇ�A���\�b�h���S��
// ���ׂ��Ȃ̂��͕ʓr�l����B
// Bottom���X���b�g�}�b�v�̌���
BOOL DlgSG300::ReadBottomSlotMap(CString sCarrierId, int SlotMap[], int SlotCount)
{
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("ReadBottomSlotMap Start");
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId, vSlotMap;
	SAFEARRAYBOUND	rgsabound[1];
	SAFEARRAY FAR*	pas;
	LONG			i;
	// CarrierIDReadEvent
	CEvent EvFinReadSlotMap;
	CEvent EvFailReadSlotMap;
	EvFinReadSlotMap.ResetEvent();
	EvFailReadSlotMap.ResetEvent();
	this->PutPortNo((unsigned int)1);	// ���ꂩ��o������Ă�PortID����������
	//
	this->pEvFinInfoBottomSlotMap	= &EvFinReadSlotMap;
	this->pEvFailInfoBottomSlotMap	= &EvFailReadSlotMap;
	//
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	//
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = 25;
	pas = SafeArrayCreate(VT_I2, 1, rgsabound);
	BOOL r = TRUE;
	//
	if(r){
		if(pas == NULL){
			SafeArrayDestroy(pas);
			r = FALSE;
//			return r;
		}
	}
	//
	if(r){
		for(i = 0; i < (LONG)rgsabound[0].cElements; i++){
			ret = SafeArrayPutElement(pas, (long*)&i, (int*)&SlotMap[i]);
			if(ret != 0){
				r = FALSE;
				this->err.PutError(Err_SlotMapRead1);
				this->ErrorLogOut(__LINE__,ret);
			}
		}
		VariantInit(&vSlotMap);
		vSlotMap.vt = VT_ARRAY | VT_I2;
		vSlotMap.parray = pas;
	//
#if !Release
		TRACE("ReadBottomSlotMap = %s\n", sCarrierId);
#endif
	}
	if(r){
		if((ret = m_hCsg300cms.ReadSlotMap(vCarrierId, vSlotMap, SlotCount, 1)) != 0){
			SafeArrayDestroy(pas);
			VariantClear(&vCarrierId);
			VariantClear(&vSlotMap);
			r = FALSE;
			this->err.PutError(Err_SlotMapRead2);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	::Sleep(500);
	{
		CString msg;
		msg.Format("ReadBottomSlotMap Waiting HOST");
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();		// �����ň�U���҂�PortNo�������݉\�Ƃ���B
	if(r){
		enum{
			WaitCnt		= 3,
		};
		CSyncObject *ppObjects[WaitCnt] = {0};
		ppObjects[0]	= pEvFinInfoBottomSlotMap;		// VERIFICATION_OK
		ppObjects[1]	= pEvFailInfoBottomSlotMap;		// VERIFICATION_NG
		ppObjects[2]	= pEvStopWaitingSecsB;		// ���f
		CMultiLock	M(ppObjects,WaitCnt);
		if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
			// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
			int k = M.Lock(INFINITE, FALSE);
			M.Unlock();
			k -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == k) {
				// ����
				r = TRUE;
			} else if (1 == k) {
				// ���s
				r = FALSE;
				this->err.PutError(Err_BottomSlotMapCanceled);
			} else if (2 == k) {
				//�r����~(���f)
				r = FALSE;
				this->StoppedBEvent();
			}
			{
				CString msg;
				msg.Format("ReadBottomSlotMap finished = %d\n", r);
				if(!r){
					this->err.LogSaveNFL(msg);
				}
#if !Release
				TRACE(msg);
#endif
			}
		}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
				//����_SLOTMAPSTATUS:2   Slotmap Verification OK 
			this->setAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS", 2);
		}
	}
	if(r){
		////////////////////////////////////////////////////////////////////
		//
		// CarrierAccessStatus��IN ACCESS�ɂ���(����ȍ~��CancelCarrier�͕s��)
		//
		// ���߂�PortNo�������݋֎~�Ƃ���B
		// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
		CSingleLock P1(&PortNoSema);
		P1.Lock();
		{
			CString msg;
			msg.Format("ReadBottomSlotMap ChangeCarrierAccessState");
			this->err.LogSaveNFL(msg);
		}
		this->PutPortNo((unsigned int)1);	// ���ꂩ��o������Ă�PortID����������
		if(getAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS") == 2){
			if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*1*/eInAccess)) != 0){
				r = FALSE;
			}
		}
		this->pEvFinInfoBottomSlotMap	= NULL;
		this->pEvFailInfoBottomSlotMap	= NULL;
		SafeArrayDestroy(pas);
		VariantClear(&vCarrierId);
		VariantClear(&vSlotMap);
		{
			long	ret;
			VARIANT vCarrierIdList;
			long	Count;
			VariantInit(&vCarrierIdList);
			if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
				VariantClear(&vCarrierIdList);
			}
		}
		::Sleep(1000);
		{
			CString msg;
			msg.Format("ReadBottomSlotMap End");
			this->err.LogSaveNFL(msg);
		}
		P1.Unlock();	// PortNo�������݋���
	}
	return r;
}

BOOL DlgSG300::ReadTopSlotMap(CString sCarrierId, int SlotMap[], int SlotCount)
{
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("ReadTopSlotMap Start");
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	VARIANT	vCarrierId, vSlotMap;
	SAFEARRAYBOUND	rgsabound[1];
	SAFEARRAY FAR*	pas;
	LONG			i;
	// CarrierIDReadEvent
	CEvent EvFinReadSlotMap;
	CEvent EvFailReadSlotMap;
	EvFinReadSlotMap.ResetEvent();
	EvFailReadSlotMap.ResetEvent();
	this->PutPortNo((unsigned int)2);	// ���ꂩ��o������Ă�PortID����������
	//
	this->pEvFinInfoTopSlotMap	= &EvFinReadSlotMap;
	this->pEvFailInfoTopSlotMap	= &EvFailReadSlotMap;
	//
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	//
	rgsabound[0].lLbound = 0;
	rgsabound[0].cElements = 25;
	pas = SafeArrayCreate(VT_I2, 1, rgsabound);
	//
	BOOL r = TRUE;
	if(r){
		if(pas == NULL){
			SafeArrayDestroy(pas);
			r = FALSE;
		}
	}
	//
	if(r){
		for(i = 0; i < (LONG)rgsabound[0].cElements; i++){
			ret = SafeArrayPutElement(pas, (long*)&i, (int*)&SlotMap[i]);
			if(ret != 0){
				r = FALSE;
				this->err.PutError(Err_SlotMapRead1);
				this->ErrorLogOut(__LINE__,ret);
			}
		}
		VariantInit(&vSlotMap);
		vSlotMap.vt = VT_ARRAY | VT_I2;
		vSlotMap.parray = pas;
	}
	//
	if(r){
#if !Release
		TRACE("ReadTopSlotMap = %s\n", sCarrierId);
#endif
		if((ret = m_hCsg300cms.ReadSlotMap(vCarrierId, vSlotMap, SlotCount, 1)) != 0){
			SafeArrayDestroy(pas);
			VariantClear(&vCarrierId);
			VariantClear(&vSlotMap);
			r = FALSE;
			this->err.PutError(Err_SlotMapRead2);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	::Sleep(500);
	{
		CString msg;
		msg.Format("ReadTopSlotMap Waiting HOST");
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();		// �����܂łň�U���҂�PortNo�������݋��Ƃ���B
	if(r){
		enum{
			WaitCnt		= 3,
		};
		CSyncObject *ppObjects[WaitCnt] = {0};
		ppObjects[0]	= pEvFinInfoTopSlotMap;		// VERIFICATION_OK
		ppObjects[1]	= pEvFailInfoTopSlotMap;	// VERIFICATION_NG
		ppObjects[2]	= pEvStopWaitingSecsT;		// ���f
		CMultiLock	M(ppObjects,WaitCnt);
		if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
			// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
			int k = M.Lock(INFINITE, FALSE);
			M.Unlock();
			k -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == k) {
				// ����
				r = TRUE;
			} else if (1 == k) {
				// ���s
				r = FALSE;
				this->err.PutError(Err_TopSlotMapCanceled);
			} else if (2 == k) {
				//�r����~(���f)
				r = FALSE;
				this->StoppedTEvent();
			}
			{
				CString msg;
				msg.Format("ReadTopSlotMap finished = %d\n", r);
				if(!r){
					this->err.LogSaveNFL(msg);
				}
#if !Release
				TRACE(msg);
#endif
			}
		}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
				//����_SLOTMAPSTATUS:2   Slotmap Verification OK 
			this->setAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS", 2);
		}
	}
	{
		CString msg;
		msg.Format("ReadTopSlotMap ChangeAccessState");
		this->err.LogSaveNFL(msg);
	}
	////////////////////////////////////////////////////////////////////
	//
	// CarrierAccessStatus��IN ACCESS�ɂ���(����ȍ~��CancelCarrier�͕s��)
	//
	if(r){
		// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
		CSingleLock P1(&PortNoSema);
		P1.Lock();
		this->PutPortNo((unsigned int)2);	// ���ꂩ��o������Ă�PortID����������
		if(getAttDataSingleUINT1("Carrier", sCarrierId, "_SLOTMAPSTATUS") == 2){
			if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*1*/eInAccess)) != 0){		//In Access ����ȍ~CancelCarrier�s�\
				r = FALSE;
			}
		}
		::Sleep(1000);
		{
			CString msg;
			msg.Format("ReadTopSlotMap End");
			this->err.LogSaveNFL(msg);
		}
		P1.Unlock();
		this->pEvFinInfoTopSlotMap	= NULL;
		this->pEvFailInfoTopSlotMap	= NULL;
		SafeArrayDestroy(pas);
		VariantClear(&vCarrierId);
		VariantClear(&vSlotMap);
		{
			long	ret;
			VARIANT vCarrierIdList;
			long	Count;
			VariantInit(&vCarrierIdList);
			if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
				VariantClear(&vCarrierIdList);
			}
		}
	}
	return r;
}
/////////////////////////////
//
//	ContentMap�̎擾
//
void DlgSG300::GetContentMap(){
//	BOOL r = TRUE;
	CString	ObjType, ObjId;
	LPCSTR	attr_name, attr_name2;							// #DucMV 20160331 SECS ECID
	long	element, ret = 0;
	VARIANT	vObjType, vObjId, v;
	short	item_type;
	SAFEARRAY FAR	*pArray;
	unsigned char	cData;
	CString	dataStr;
	unsigned long i;
	//
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&v);
	//
	ObjId = this->carrierId[eBottomPortNo];
	vObjId.vt = VT_BSTR;
	vObjId.bstrVal = ObjId.AllocSysString();
	//
	ObjType = "Carrier";
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = ObjType.AllocSysString();
	//
	attr_name = "_SUBSTID_N1";	//wafer_ID
	attr_name2 = "_LOTID_N1";	//lotID						// #DucMV 20160331 SECS ECID
	//
	for(int j=0;j<eWaferNumberMax;j++){
		// Carrier�����́u_SUBSTID_N1�v�z��̒l�����Ԃ�1�`25�܂Ŏ擾����B
		ret = m_hXComSecs.GetAttrData(vObjType, vObjId, attr_name, &v, &item_type, &element, j+1, 0, 0, 0);
		if(ret==0){
			// #TT160607-02(S) �R���e���g�}�b�v�o�͕s�ǒ����pLog�ǉ�
			CString msg;
			msg.Format("SoftComGem300 GetContentMap() waferIdOfContentMap[%d]=%s",j ,v.bstrVal);
			this->err.LogSaveNFL(msg);
			// #TT160607-02(E)
			this->waferIdOfContentMap[j]	= v.bstrVal;
		}
		// #DucMV 20160331 SECS ECID (S)
		VariantClear(&v);
		ret = m_hXComSecs.GetAttrData(vObjType, vObjId, attr_name2, &v, &item_type, &element, j+1, 0, 0, 0);
		if(ret == 0){
			lotIdOfContentMap[j] = v.bstrVal;
		} else {
			//break;
		}
		// #DucMV 20160331 SECS ECID (E)
	}
	//
	if(ret != 0){
	}else{
		if(v.vt & VT_ARRAY){
			pArray = v.parray;
			for(i = 0; i < SafeArrayGetElemsize(pArray); i++){
				if(SafeArrayGetElement(pArray, (long FAR*)&i, &cData) != S_OK){
					break;
				}
			}
		}else{
			if(v.vt == VT_BSTR){
			}else if(v.vt == VT_I4){
			}else if(v.vt == VT_UI1){
			}
		}
		VariantClear(&vObjId);
		VariantClear(&vObjType);
		VariantClear(&v);
	}
}

BOOL DlgSG300::DelALLCarrierObj(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vCarrierIdList;
	VARIANT vCarrierId;
	long	Count;
	SAFEARRAY FAR*	pArray;
	VariantInit(&vCarrierIdList);
	if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
		VariantClear(&vCarrierIdList);
		r = FALSE;
		return r;
	}
	if(Count == 0){
		VariantClear(&vCarrierIdList);
		return r;
	}
	if(Count != 0){
		CString msg;
		msg.Format("Delete All Carrier Object= %d\n", Count);
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
	}
	pArray = vCarrierIdList.parray;
	VariantInit(&vCarrierId);
	for(long i = 0; i < Count; i++){
		SafeArrayGetElement(pArray, &i, &vCarrierId);
		if((ret = m_hCsg300cms.DeleteCarrier(vCarrierId)) != 0){
			r = FALSE;
			break;
		}
	}
	SafeArrayDestroy(pArray);
	VariantClear(&vCarrierIdList);
	VariantClear(&vCarrierId);
	if(Count != 0){
		CString msg;
		msg.Format("Delete All finished\n");
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
		::Sleep(500);
	}
	return r;
}

BOOL DlgSG300::UnloadALLCarrierObj(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vCarrierIdList;
	VARIANT vCarrierId;
	long	Count;
	SAFEARRAY FAR*	pArray;
	VariantInit(&vCarrierIdList);
	if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
		VariantClear(&vCarrierIdList);
		r = FALSE;
		return r;
	}
	if(Count == 0){
		VariantClear(&vCarrierIdList);
		return r;
	}
	if(Count != 0){
		CString msg;
		msg.Format("Force Unload Carrier = %d\n", Count);
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
	}
	pArray = vCarrierIdList.parray;
	VariantInit(&vCarrierId);
	CString carrierId;
	for(long i = 0; i < Count; i++){
		SafeArrayGetElement(pArray, &i, &vCarrierId);
		carrierId = vCarrierId.bstrVal;
		this->CarrierForceTakeOut(eBottomPortNo, carrierId);
		this->CarrierForceTakeOut(eTopPortNo1, carrierId);
	}
	if(Count != 0){
		CString msg;
		msg.Format("Unload All finished\n");
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
		::Sleep(500);
	}
//	this->carrierIsCreated	= false;
	SafeArrayDestroy(pArray);
	VariantClear(&vCarrierIdList);
	VariantClear(&vCarrierId);
	return r;
}
///////////////////////////////////////////////////////
//
//
//
//	R e c e i v e  S t r e a m F u n c t i o n
//	Receive Stream Function
//
//
//
//

BOOL DlgSG300::RecvCarrierRelease(int port_no)
{
	BOOL r = TRUE;
	long	ret;
	short carrierIdState, slotMapState, accessStateT[NO_OF_TOP_PORT], accessStateB;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	// Bottom Wafer��Status���擾����B
	{
		vCarrierId.bstrVal = this->carrierId[eBottomPortNo].AllocSysString();
		// CarrierState���擾����B
		if((ret = m_hCsg300cms.GetCarrierState(vCarrierId, &carrierIdState, &slotMapState, &accessStateB))){
			accessStateB = eNotIDRead;
			// �擾�ł��Ȃ����NotInRead�Ƃ���B
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	// Top Wafer��Status���擾����B
	for (int i = 0; i < NO_OF_TOP_PORT; i++) {
		vCarrierId.bstrVal = this->carrierId[eTopPortNo1].AllocSysString();
		// CarrierState���擾����B
		if((ret = m_hCsg300cms.GetCarrierState(vCarrierId, &carrierIdState, &slotMapState, &accessStateT[i]))){
			accessStateT[i] = eNotIDRead;
			// �擾�ł��Ȃ����NotInRead�Ƃ���B
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	{
		CString msg;
		msg.Format("ReceiveCarrierRelease(%d) AccessStateB(%d)T(%d,%d,%d)\n",
										port_no, accessStateB, accessStateT[0],accessStateT[1],accessStateT[2]);
		this->err.LogSaveNFL(msg);
#if !Release
		TRACE(msg);
#endif
	}
	///////////////////////
	//
	// Bottom Wafer��CarrierRelease�̏ꍇ
	//
	if(port_no == eBottomPortNo){
		// �������g��CarrierComplete�ł���΁A
		if(accessStateB != eInAccess){	//CarrierComplete or CarrierStopped
			this->PutSecsItemSingleBIN("Itm_CAACK2", 0);	// Acknowledge
		}else{
			this->PutSecsItemSingleBIN("Itm_CAACK2", 2);	// Can not perform now
		}
		//S3F18���M
		if((ret = m_hXComSecs.PutSecsEvent("_GS03F18S_2")) != 0){
			r = FALSE;
		}
		// �L�����A�A�N�Z�X��Ԃ�CarrierComplete�ȏ�ł����
		if(r && (accessStateB > eInAccess)){	//CarrierComplete or CarrierStopped
			// 
			if(this->pEvBottomWaferUnloadReq){
				// BottomWaferUnload�v�����Ĕ�����
				this->pEvBottomWaferUnloadReq->SetEvent();
			}
		}
	// #DDT160625-03 (S)
	}else if((port_no >= MIN_TOP_PORT_NO) && (port_no <= MAX_TOP_PORT_NO)){
		// �������g��CarrierComplete���A�����łȂ��Ă�BottomWafer��CarrierComplete�ł���΁A
		// �n�j��Ԏ�����B
		if((accessStateB != eInAccess)||(accessStateT[port_no - MIN_TOP_PORT_NO] != eInAccess) || (this->GetAbleToRelease(port_no))){	//CarrierComplete or CarrierStopped
			this->PutSecsItemSingleBIN("Itm_CAACK2", 0);	// Acknowledge
		}else{
			this->PutSecsItemSingleBIN("Itm_CAACK2", 2);	// Can not perform now
		}
		//S3F18���M
		if((ret = m_hXComSecs.PutSecsEvent("_GS03F18S_2")) != 0){
			r = FALSE;
		}
		// �������g��CarrierComplete�̏ꍇ(TopWafer�����S���I����Ă���ꍇ)
		if(r && (accessStateT[port_no - MIN_TOP_PORT_NO] > eInAccess)){	//CarrierComplete or CarrierStopped
			// ���ɏ�ʂł���Ă��炤���Ƃ͂Ȃ��̂ŁA
			// ������CarrierUnload����B
			r = this->CarrierUnLoad(port_no);
			// TopWafer���́A�����������܂ł́A�b��ł�����ReadyToLoad�ɂ���B
			if(r){
				// ReadyToLoad �����s����B
				r = this->CarrierTakeOut(port_no);
			}
			if(r){
				// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
				bool unloaded = (!this->loadedByHost[eTopPortNo1])
					&&(!this->loadedByHost[eTopPortNo2])
					&&(!this->loadedByHost[eTopPortNo3])
					&&(!this->loadedByHost[eBottomPortNo]);
				// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
				if(unloaded){
					::Sleep(500);
					r = this->ProcessCompleteEvent();
				}
			}
			this->PutSecsItemSingleBIN("Itm_CAACK2", 0);	// Acknowledge
			// �������g�͍�ƒ������ABottomWafer���I�����Ă���ꍇ
		}else  if(r && (accessStateB != eInAccess)){	//CarrierComplete or CarrierStopped
			if(this->pEvTopWaferUnloadReq[port_no - MIN_TOP_PORT_NO]){
				// TopWaferUnload�v�����Ĕ�����
				this->pEvTopWaferUnloadReq[port_no - MIN_TOP_PORT_NO]->SetEvent();
			}
		} else if(r && this->GetAbleToRelease(port_no)) {
			if(this->pEvTopWaferUnloadReq[port_no - MIN_TOP_PORT_NO]){
				// TopWaferUnload�v�����Ĕ�����
				this->pEvTopWaferUnloadReq[port_no - MIN_TOP_PORT_NO]->SetEvent();
			}
		}
		// #DDT160625-03 (E)
	}
	return r;
}


BOOL DlgSG300::RecvCarrierNotification(int port_no, CString carrierId)
{
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	// CarrierID�̎擾
	vCarrierId.bstrVal = carrierId.AllocSysString();
	VariantClear(&vCarrierId);
	// carrierId������name��"cancelcarrier"�ł���΁AcarrerId�̏ƍ���
	// HOST��NG�ɂ��ꂽ�ƌ��Ȃ��B
	if(strcmp(carrierId, "cancelcarrier") == 0){
		// �C�x���g���s
		if((port_no == eTopPortNo1)&&(this->pEvFailInfoTopCarrierIdNotified)){
			this->pEvFailInfoTopCarrierIdNotified->SetEvent();
		}
	}else{// �����łȂ��ꍇ(HOST���K����CarrierID���擾�ł����ꍇ
		// 
		if(port_no == eBottomPortNo){
			this->TraceBotD.bottomWaferCarrierID	= carrierId;
			this->carrierId[eBottomPortNo]			= carrierId;
		}else{
			this->TraceTopD.topWaferCarrierID		= carrierId;
			this->TraceBotD.topWaferCarrierID		= carrierId;
			this->carrierId[eTopPortNo1]			= carrierId;
		}
		// �C�x���g���s
		if((port_no == eTopPortNo1)&&(this->pEvFinInfoTopCarrierIdNotified)){
			this->pEvFinInfoTopCarrierIdNotified->SetEvent();
		}
	}
	this->PutSecsItemSingleBIN("Itm_CAACK2", 0);	// Acknowledge
	//S3F18���M
	if((ret = m_hXComSecs.PutSecsEvent("_GS03F18S_2")) != 0){
		r = FALSE;
#if !Release
		TRACE("_GS03F18S_2 failed 0x%X\n",ret);
#endif
	}
	return r;
}

BOOL DlgSG300::StartCheck()
{
	BOOL r = TRUE;
	long	ret;
	{
		CString msg;
		msg.Format("%s(%d) CarrierManagementStartCheck = B(%d) T(%d)\n",
										__FILE__, __LINE__,
										this->loadedByHost[eBottomPortNo],
										this->loadedByHost[eTopPortNo1]);
		this->err.LogSaveNFL(msg);
	}
	short carrierIdState, slotMapState, accessStateT, accessStateB;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	// Bottom Wafer��load����Ă���Ȃ��BottomWafer��Status���擾����B
	if(this->loadedByHost[eBottomPortNo]){
		vCarrierId.bstrVal = this->carrierId[eBottomPortNo].AllocSysString();
		// CarrierState���擾����B
		if((ret = m_hCsg300cms.GetCarrierState(vCarrierId, &carrierIdState, &slotMapState, &accessStateB))){
			// �擾�ł��Ȃ����NotIDRead�Ƃ���B
			accessStateB = eNotIDRead;
			this->ErrorLogOut(__LINE__,ret);
		}
		// ����ɓǂ߂�&&�A�N�Z�X�R���v���[�g��Ԃł���
		if((!ret)&&(accessStateB >= eCompleted)){// access 
			r = FALSE;
			this->err.PutError(Err_BottomWaferIsAlreadyComplete);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	// TopWafer��load����Ă���Ȃ��topWafer��Status���擾����B
	if(this->loadedByHost[eTopPortNo1]){
		vCarrierId.bstrVal = this->carrierId[eTopPortNo1].AllocSysString();
		// CarrierState���擾����B
		if((ret = m_hCsg300cms.GetCarrierState(vCarrierId, &carrierIdState, &slotMapState, &accessStateT))){
			// �擾�ł��Ȃ����NotIDRead�Ƃ���B
			accessStateT = eNotIDRead;
			this->err.PutError(Err_CarrierNotRecognizedT);
			this->ErrorLogOut(__LINE__,ret);
		}
		// ����ɓǂ߂�&&�A�N�Z�X�R���v���[�g��Ԃł���
		if((!ret)&&(accessStateT >= eCompleted)){// access 
			r = FALSE;
			this->err.PutError(Err_TopWaferIsAlreadyComplete);
			this->ErrorLogOut(__LINE__,ret);
		}
	}
	return r;
}


//////////////////////////////////////////////////////////
//
//
//
//
//	H o s t   C o m m a n d S e n d �֌W
//
//
//
//
void DlgSG300::SetPPRecipeSendReqEvent(CEventX* pEvSendReq)
{
	this->pEvPPRecipeSendReq = pEvSendReq;					// S7F25/26 �v���Z�X�v���O�������M�J�n	OK�񍐲����
}
void DlgSG300::SetPPSelectReqEvent(CEventX* pEvSelectReq)
{
	this->pEvPPSelectReq = pEvSelectReq;					// S2F41/42 OK�񍐲����
}
void DlgSG300::SetPPStartReqEvent(CEventX* pEvStartReqB, CEventX* pEvStartReqT)
{
	this->pEvPPStartReq_B = pEvStartReqB;						// S2F41/42 OK�񍐲����
	this->pEvPPStartReq_T = pEvStartReqT;						// S2F41/42 OK�񍐲����
}
void DlgSG300::ResetPPSelectReqEvent()
{
//	this->pEvPPSelectReq	= NULL;
//	this->pEvPPStartReq_B	= NULL;
//	this->pEvPPStartReq_T	= NULL;
	this->pEvPPSelectReq->ResetEvent();
	this->pEvPPStartReq_B->ResetEvent();
	this->pEvPPStartReq_T->ResetEvent();
}

// #DucMV 20160405 Flux Function
void DlgSG300::SetMonitorEvent(CEventX *pEv)
{
	this->pEvStartMonitor = pEv;
}

void DlgSG300::RecvS02F41()
{
	BOOL r=true;
	short	item_type;
	long	ret,element;
	VARIANT	vtData;
	CString	ttmp;
	VariantInit( &vtData );
	ret = m_hXComSecs.GetItemData("Itm_RCMD2",&vtData, &item_type,&element,0,0,0,0);
	if( ret ){
		///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
		return;
	}
	ttmp = vtData.bstrVal;
	if(ttmp == "PPSELECT"){
		/////////////////////
		// CPVAL���擾
		//
		VariantClear( &vtData );
		ret = m_hXComSecs.GetItemData("Itm_CPVAL",&vtData, &item_type,&element,1,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
			return;
		}
		this->cpVal = vtData.bstrVal;
		// �����Œ�����CPVAL�������o�ϐ��ɃZ�b�g�B
		// SetEvent�̐�Ńt�@�C�����ɕ�������B
		/////////////////////
		//
		if(this->pEvPPSelectReq){
			this->pEvPPSelectReq->SetEvent();
		}
		//////////////////////////////////
		//
		// �Ԏ�(S2F42)�͕i��f�[�^�ǂݍ��݂��I����Ă���Ƃ���B
		//
	}
	else if(ttmp == "START"){
		int port_no = 0;
		VariantClear( &vtData );
		// �p�����[�^���̎擾
		ret = m_hXComSecs.GetItemData("V1",&vtData, &item_type,&element,0,0,0,0);
		if( ret ){
			///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
			return;
		}
		int list_cnt = (int)vtData.iVal;	//���X�g���̎擾
		CString port_id = "", slot_map = "";
		for(int i = 0; i < list_cnt; i++){
			CString cp_name;
			VariantClear( &vtData );
			// i�Ԗڂ�CPName���擾����
			ret = m_hXComSecs.GetItemData("Itm_CPNAME",&vtData, &item_type,&element,i+1,0,0,0);
			if( ret ){
				///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
				return;
			}
			cp_name = vtData.bstrVal;
			// CPName��"PortID"��"WaferRange"�������ꍇ�̏���
			if((cp_name == "PortID") || (cp_name == "WaferRange")){
				ret = m_hXComSecs.GetItemData("Itm_CPVAL",&vtData, &item_type,&element,i+1,0,0,0);
				if( ret ){
					///WriteLog( ERRMSGID2, "GetItemData(PPID) Error: 0x%08X", ret );
					return;
				}
				if(cp_name == "PortID"){
					port_id = vtData.bstrVal;
				}else if(cp_name == "WaferRange"){
					slot_map = vtData.bstrVal;
				}
			}else{
				//�G���[����(cp_name���ُ�)
			}
		}
		////////////////////
		//
		// ���ꂼ���Item���擾�ł�����S2F42��ԐM���Ă��悢���ƂƂ���B
		//
		this->SendS02F42();
		// �߰�ID�ƃX���b�g�}�b�v�������Ă����
		if(port_id != "" && slot_map != ""){
			VARIANT	vObjType, vObjId, v;
			CString carrierID;
			CString ObjType = "Carrier";
			unsigned int data_v;
			VariantInit(&vObjType);
			VariantInit(&vObjId);
			// PortID�̔��f(Bottom��Top��)
			if(eBottomPortNo == _ttoi(port_id)){
				carrierID = this->carrierId[eBottomPortNo];
				port_no = eBottomPortNo;
			}else{
				carrierID = this->carrierId[eTopPortNo1];
				port_no = eTopPortNo1;
			}
			vObjType.vt = VT_BSTR;
			vObjType.bstrVal = ObjType.AllocSysString();
			vObjId.vt = VT_BSTR;
			vObjId.bstrVal = carrierID.AllocSysString();
			for(int i = 0; i < slot_map.GetLength(); i++){
				VariantInit(&v);
				data_v = (unsigned int)(slot_map.GetAt(i) - '0');
				this->waferUmu[port_no][i]	= (int)data_v;
				// �ȉ���^�ʖڂɂ��̂ł���΁A������ʉ߂��Ă���S2F42���o�����Ƃ���������B
				// �A���A�G���[������Ƃ�����S2F42���o������return���邱�Ƃ̂Ȃ��悤��
//				v.vt = VT_UI1;
//				v.bVal = data_v;
//
//				ret = m_hXComSecs.PutAttrData(vObjType, vObjId, "_ENUMERATED_N1", v, 0x00A4, 1, i+1, 0, 0, 0);
//				if( ret ){
//					///WriteLog( ERRMSGID2, "PutAttrData(PPID) Error: 0x%08X", ret );
//					VariantClear(&vObjType);
//					VariantClear(&vObjId);
//					VariantClear(&v);
//					return;
//				}
//				VariantClear(&v);
			}
			VariantClear(&vObjType);
			VariantClear(&vObjId);
		}else{
			//�G���[����(�l�������Ă��Ȃ�)
		}
		//////////////////////
		//
		// PortNo���󂯎���܂ł̎b��
		//
		if(port_no == eBottomPortNo){
			if(this->pEvPPStartReq_B){
				this->pEvPPStartReq_B->SetEvent();
			}
		}else if(port_no == eTopPortNo1){
			if(this->pEvPPStartReq_T){
				this->pEvPPStartReq_T->SetEvent();
			}
		}
	}
	else if(ttmp == "GOLOCAL"){
		r = this->ChangeOnLineLocal();
//		if(r){
			this->SendS02F42();
//		}
		// todo : �G���[����
	}
	else if(ttmp == "GOREMOTE"){
		r = this->ChangeOnLineRemote();
		// todo : �G���[����
//		if(r){
			this->SendS02F42();
//		}
	}
	// #DucMV 20160317 Flux function
	else if(ttmp == "FLUXMON_X"){
		this->SendS02F42();
		this->MonitorMode = 1;
		if (this->pEvStartMonitor) {
			this->pEvStartMonitor->SetEvent();
		}
	}
	else if(ttmp == "FLUXMON_Y"){
		this->SendS02F42();
		this->MonitorMode = 2;
		if (this->pEvStartMonitor) {
			this->pEvStartMonitor->SetEvent();
		}
	}
	else if(ttmp == "PMSTART"){
		this->SendS02F42();
		this->MonitorMode = 3;
		if (this->pEvStartMonitor) {
			this->pEvStartMonitor->SetEvent();
		}
	}
	// #DucMV 20160317 Flux function
	else{
		// todo : �G���[�����i�����ɓ����Ă͂����Ȃ��B�j
	}
}

void DlgSG300::SendS02F42(){
	int ret=0;
	ret = m_hXComSecs.PutSecsEvent( "_GS02F42S" );
	if( ret ){
		// todo �G���[�����B
	}
}

int DlgSG300::Receive_BottomPPStartAction()
{
	int r = 99999;
	//
	enum{
		ObjectMax = 3,
	};
	this->HostCommandStatus	= eNotReceived;
	CSyncObject *ppObjects[ObjectMax];
	ppObjects[0]	= pEvPPSelectReq;		// �����̃X���b�h�ő҂��Ă���\�����邪�A�������̏���
	ppObjects[1]	= pEvPPStartReq_B;		// Bottom��ʑ���PPStart�҂�
	ppObjects[2]	= pEvStopWaitingSecsB;	// ���f
	CMultiLock M(ppObjects, ObjectMax);		// �����~or�v���҂��錾
	int i = M.Lock(INFINITE, FALSE);		// �����I�u�W�F�N�g�̔z���҂����킹(FALSE:1�ȏ�̓����I�u�W�F�N�g���V�O�i����ԂƂȂ�Ƃ����ɕ��A)
	M.Unlock();								// ���L���铯���I�u�W�F�N�g�����
	i -= WAIT_OBJECT_0;						// ����ُ�ԂɂȂ�����޼ު��No.
	//
#if !Release
	TRACE("GetHostCommand(B) = %d\n", i);
#endif
	if (0 == i){		// PPSelect�������B
		this->HostCommandStatus	= eGetPPSelect;
		r = TRUE;
	}else if (1 == i){	// PPStrat�������B
		this->HostCommandStatus	= eGetPPStart_B;
		r = TRUE;
	}else if (2 == i){	// ���f�������B
		this->HostCommandStatus	= eNotReceived;
		r = FALSE;
	}
	return r;
}

int DlgSG300::Receive_TopPPStartAction()
{
	int r = 99999;
	//
	enum{
		ObjectMax = 3,
	};
	this->HostCommandStatus	= eNotReceived;
	CSyncObject *ppObjects[ObjectMax];
	ppObjects[0]	= pEvPPSelectReq;		// �����̃X���b�h�ő҂��Ă���\�����邪�A�������̏���
	ppObjects[1]	= pEvPPStartReq_T;		// TopWafer��PPStart������
	ppObjects[2]	= pEvStopWaitingSecsT;	// ���f
	CMultiLock M(ppObjects, ObjectMax);		// �����~or�v���҂��錾
	int i = M.Lock(INFINITE, FALSE);		// �����I�u�W�F�N�g�̔z���҂����킹(FALSE:1�ȏ�̓����I�u�W�F�N�g���V�O�i����ԂƂȂ�Ƃ����ɕ��A)
	M.Unlock();								// ���L���铯���I�u�W�F�N�g�����
	i -= WAIT_OBJECT_0;						// ����ُ�ԂɂȂ�����޼ު��No.
	//
#if !Release
	TRACE("GetHostCommand(T) = %d\n", i);
#endif
	if (0 == i){		// PPSelect�������B
		this->HostCommandStatus	= eGetPPSelect;
		r = TRUE;
	}else if (1 == i){	// PPStrat�������B
		this->HostCommandStatus	= eGetPPStart_T;
		r = TRUE;
	}else if (2 == i){	// ���f�������B
		this->HostCommandStatus	= eNotReceived;
		r = FALSE;
	}
	return r;
}

//////////////////////////////////////////////////////////////
//
//
//
//
//	E v e n t  R e p o r t  S e n d (S6F11/12 �C�x���g���M�֌W�j
//
//
//
//
BOOL DlgSG300::PutPortNo(unsigned int item_data){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	VariantInit(&vid_data);
	VariantClear(&vid_data);
	vid_data.vt = VT_UI1;
	vid_data.uiVal = item_data;
	if((ret = m_hXComSecs.SetVIDVal("_PORTIDForEvent",vid_data,0x00a4,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}
BOOL DlgSG300::PutProcessState(int status){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	VariantInit(&vid_data);
	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = status;
	//
	if((ret = m_hXComSecs.SetVIDVal("_ProcessState",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}

BOOL DlgSG300::PutProcessPPID(CString ppId){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	VariantInit(&vid_data);
	VariantClear(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = ppId.AllocSysString();
	// 
	if((ret = m_hXComSecs.SetVIDVal("_ProcessPPID",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	return r;
}

BOOL DlgSG300::ClampEvent(int port_no){
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("Clamp(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	BOOL r = TRUE;
	if((ret = m_hXComSecs.SndEvntInf("ClampedEvent",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("Clamp(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}

BOOL DlgSG300::DockEvent(int port_no){
	// Unlock�����܂ŁAPortNo�͕ύX�����Ȃ��B
	CSingleLock P(&PortNoSema);
	P.Lock();
	{
		CString msg;
		msg.Format("Dock(%d) Start", port_no);
		this->err.LogSaveNFL(msg);
	}
	long	ret;
	this->PutPortNo((unsigned int)port_no);	// ���ꂩ��o������Ă�PortID����������
	BOOL r = TRUE;
	if((ret = m_hXComSecs.SndEvntInf("DockEvent",0)) != 0){		//
		r = FALSE;
	}
	::Sleep(1000);
	{
		CString msg;
		msg.Format("Dock(%d) End", port_no);
		this->err.LogSaveNFL(msg);
	}
	P.Unlock();
	return r;
}

// #DucMV 20160401 SECS ECID (S)
BOOL DlgSG300::BarcodeReadEvent(CString SlotID)
{
	BOOL r = TRUE;
	{
		long	ret;
		// �����X���b�h�������ɃA�N�Z�X���Ȃ��悤�ɃZ�}�t�H��������
		CSingleLock W(&this->CarrierSema);
		W.Lock();
		::Sleep(500);
		{
			VARIANT vid_data;
			LPCTSTR	vid_name;
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();
			vid_name = "_TopWaferID1";
			if((ret = m_hXComSecs.SetVIDVal(vid_name,vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			////////////
			// SlotID
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
			vid_name = "_SlotIDForEvent";
			if((ret = m_hXComSecs.SetVIDVal(vid_name,vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			////////////
			// LOTID
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.lotID.AllocSysString();
			if((ret = m_hXComSecs.SetVIDVal("_tmpLotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			////////////
			// SLOTID
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
			if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			////////////
			// WaferID
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.topCMapWfID.AllocSysString();
			if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			// KeyValue
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.keyVal.AllocSysString();
			if((ret = m_hXComSecs.SetVIDVal("_tmpKeyValueForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
		}
		if((ret = m_hXComSecs.SndEvntInf("BarcodeReadEvent",0)) != 0){	//
			r = FALSE;
		}
		W.Unlock();
	}
	return r;
}
// #DucMV 20160401 SECS ECID (E)
// #DucMV 20160401 SECS ECID (S)
BOOL DlgSG300::ExpandReportEvent()
{
	BOOL r = TRUE;
	{
		long	ret;
		// �����X���b�h�������ɃA�N�Z�X���Ȃ��悤�ɃZ�}�t�H��������
		CSingleLock W(&this->CarrierSema);
		W.Lock();
		{
			::Sleep(500);
			VARIANT vid_data;
			LPCTSTR	vid_name;
			////////////
			// SlotID
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
			vid_name = "_SlotIDForEvent";
			if((ret = m_hXComSecs.SetVIDVal(vid_name,vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			////////////
			// LOTID
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.lotID.AllocSysString();
			if((ret = m_hXComSecs.SetVIDVal("_tmpLotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			////////////
			// SLOTID
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
			if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			////////////
			// WaferID
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.topCMapWfID.AllocSysString();
			if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
			// KeyValue
			VariantInit(&vid_data);
			vid_data.vt = VT_BSTR;
			vid_data.bstrVal = this->TraceTopD.keyVal.AllocSysString();
			if((ret = m_hXComSecs.SetVIDVal("_tmpKeyValueForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
				r = FALSE;
			}
		}
		if((ret = m_hXComSecs.SndEvntInf("ExpandReportEvent",0)) != 0){	//
			r = FALSE;
		}
		W.Unlock();
	}
	return r;
}
// #DucMV 20160401 SECS ECID (E)

// #DucMV 20160401 SECS ECID (S)
BOOL DlgSG300::PutDoorID(unsigned int item_data){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	VariantInit(&vid_data);
	VariantClear(&vid_data);
	vid_data.vt = VT_UI1;
	vid_data.uiVal = item_data;
	// ���O��DoorID�ɕύX�������������A���łɓo�^VID�̖��O�̕ύX��
	// ���܂��s���Ȃ������̂ŁA���̂܂܂Ƃ���
	// (�{���Ȃ�΁A���ꂪ�q���o��VID���X�g�ɂ��Ȃ�̂ŁA���O��
	// �ύX����ɉz�������Ƃ͂Ȃ�
	if((ret = m_hXComSecs.SetVIDVal("_DoorIDForEvent",vid_data,0x00a4,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}

// �h�A���J����/����
BOOL DlgSG300::DoorOpenEvent(short doorID, bool opened)
{
	BOOL r = TRUE;
	// 
	// �ʐM�m�����Ă���OnlineRemote�ł���΁A
	if((this->comState == eCommunicating)
		&&(this->getCtrlState() >= eOnlineLocal)){
		long	ret;
		// �����X���b�h�������ɃA�N�Z�X���Ȃ��悤�ɃZ�}�t�H��������
		CSingleLock W(&this->CarrierSema);
		W.Lock();
		this->PutDoorID((unsigned int)doorID);	// ���ꂩ��o������Ă�PortID����������
		if(opened){
			if((ret = m_hXComSecs.SndEvntInf("DoorOpenEvent",0)) != 0){		//
				r = FALSE;
			}
		}else{
			if((ret = m_hXComSecs.SndEvntInf("DoorCloseEvent",0)) != 0){	//
				r = FALSE;
			}
		}
		W.Unlock();
	}
	return r;
}
// #DucMV 20160401 SECS ECID (E)

// #DucMV 20160401 SECS ECID (S)
BOOL DlgSG300::PlacedEvent(int port_no){
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("PlacedEvent",0)) != 0){		//
		r = FALSE;
	}
	return r;
}

BOOL DlgSG300::TakeOutEvent(int port_no){
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("TakeOutEvent",0)) != 0){		//
		r = FALSE;
	}
	return r;
}
// #DucMV 20160401 SECS ECID (E)

BOOL DlgSG300::ProcessStartEvent(){

	BOOL r = TRUE;
	long	ret;

	if((ret = m_hXComSecs.SndEvntInf("ProcessStartExecuting",0)) != 0){		//ProcessStartExecuting ���b�Z�[�W���M
		r = FALSE;
	}

	return r;
}


BOOL DlgSG300::StoppedTEvent(){
	BOOL r = TRUE;
	long	ret;
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("EquipmentStoppedT",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}
BOOL DlgSG300::StoppedBEvent(){
	BOOL r = TRUE;
	long	ret;
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("EquipmentStoppedB",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}

BOOL DlgSG300::ProcessCompleteEvent(){
	BOOL r = TRUE;
	long	ret;
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("ProcessProcessingComplete",0)) != 0){		//ProcessProcessingComplete ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}
BOOL DlgSG300::BottomDieFinishedEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eBottomPortNo].AllocSysString();
	// �A�N�Z�X�X�e�[�g�ύX
	if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*2*/eCompleted)) != 0){		//COMPLETED
		VariantClear(&vCarrierId);
		r = FALSE;
		return r;
	}
	VariantClear(&vCarrierId);
	// #DucMV 20160331 SECS ECID (S)
	{
		////////////
		// CJID
		VARIANT vid_data;
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.tmpCJID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_CrJobIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){	
//				r = FALSE;
		}
	}
	// #DucMV 20160331 SECS ECID (E)
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("BottomDieProcessingComplete",0)) != 0){		//ProcessProcessingComplete ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}


BOOL DlgSG300::TopDieFinishedEvent(/*CString sCarrierId*/){
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eTopPortNo1].AllocSysString();
	// �A�N�Z�X�X�e�[�g�ύX
	if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*2*/eCompleted)) != 0){		//COMPLETED
		VariantClear(&vCarrierId);
		r = FALSE;
		return r;
	}
	VariantClear(&vCarrierId);
	{
		////////////
		// CJID
		VARIANT vid_data;
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.tmpCJID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_CrJobIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
		////////////
		// BinVals
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.binVals.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferBinVals",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// BinVals (remain)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.remainBinCounts.AllocSysString();						//##QuyetVK 20130610 Update VID
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferRemainBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// BinVals (Pick)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.pickBinCounts.AllocSysString();							//##QuyetVK 20130610 Update VID
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferPickBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
		////////////
		// BinVals (Pick)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.pickBinCounts.AllocSysString();							//##QuyetVK 20130610 Update VID
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
	}
	if((ret = m_hXComSecs.SndEvntInf("TopDieProcessingComplete",0)) != 0){		//TopDieProcessingComplete ���b�Z�[�W���M
		r = FALSE;
	}
	return r;
}

BOOL DlgSG300::TopDieForceFinishedEvent(int portNo){
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	VARIANT vid_data;
	this->PutPortNo((unsigned int)portNo);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[portNo].AllocSysString();
#if 0
	////////////////////////////////
	//
	// TopWafer��VID�̃Z�b�g
	//
	// �Ǖi�{���f�B���O���ꂽ�J�E���g
	VariantInit(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_PickedUpCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�{���f�B���O���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_PickedUpCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �Ǖi�X�L�b�v���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.UnBondCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_UnBondCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�X�L�b�v���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.UnBondCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_UnBondCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �Ǖi�c��̃J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickRemainCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_RemainingCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�c��̃J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickRemainCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_RemainingCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// Top���J�e�S���[
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Top�E�F�n�h�c(�s�b�N�A�b�v�^�C�~���O)
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferID1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
#endif
	// #DucMV 20160331 SECS ECID (S)
	// Top���J�e�S���[
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #DucMV 20160331 SECS ECID (E)
	// �A�N�Z�X�X�e�[�g�ύX
	// #DDT160625-03 (S)
	if(portNo < eTopPortNo2){
		if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*2*/eCompleted)) != 0){		//COMPLETED
			VariantClear(&vCarrierId);
			r = FALSE;
			return r;
		}
	}
	// #DDT160625-03 (E)
	VariantClear(&vCarrierId);
	if((ret = m_hXComSecs.SndEvntInf("TopDieForceCompleteEvent",0)) != 0){		//TopDieProcessingComplete ���b�Z�[�W���M
		r = FALSE;
	}
	if(r){
		// #DDT160625-03 (S)
		// ������CarrierUnload����B
		//r = this->CarrierUnLoad(eTopPortNo1);
		r = this->CarrierUnLoad(portNo);
		// TopWafer���́A�����������܂ł́A�b��ł�����ReadyToLoad�ɂ���B
		if(r){
			// ReadyToLoad �����s����B
			//r = this->CarrierTakeOut(eTopPortNo1);
			r = this->CarrierTakeOut(portNo);
		}
		if(r){
			bool unloaded = (!this->loadedByHost[eTopPortNo1])
							&&(!this->loadedByHost[eTopPortNo2])
							&&(!this->loadedByHost[eTopPortNo3])
							&&(!this->loadedByHost[eBottomPortNo]);
			// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
			if(unloaded){
				::Sleep(500);
				r = this->ProcessCompleteEvent();
			}
		}
		// #DDT160625-03 (E)
	}
	return r;
}

BOOL DlgSG300::BottomDieUnloadEvent(){
	BOOL r = TRUE;
	VARIANT	vCarrierId;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eBottomPortNo].AllocSysString();
	// �A�N�Z�X�X�e�[�g�ύX�͕s�v
	if(r){
		// ������CarrierUnload����B
		r = this->CarrierUnLoad(eBottomPortNo);
		if(r){
			bool unloaded = (!this->loadedByHost[eTopPortNo1])
							&&(!this->loadedByHost[eTopPortNo2])
							&&(!this->loadedByHost[eTopPortNo3])
							&&(!this->loadedByHost[eBottomPortNo]);
			// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
			if(unloaded){
				::Sleep(500);
				r = this->ProcessCompleteEvent();
			}
		}
	}
	return r;
}

BOOL DlgSG300::TopDieUnloadEvent(){
	BOOL r = TRUE;
	VARIANT	vCarrierId;
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = this->carrierId[eTopPortNo1].AllocSysString();
	// �A�N�Z�X�X�e�[�g�ύX�͕s�v
	if(r){
		// ������CarrierUnload����B
		r = this->CarrierUnLoad(eTopPortNo1);
		if(r){
			bool unloaded = (!this->loadedByHost[eTopPortNo1])
							&&(!this->loadedByHost[eTopPortNo2])
							&&(!this->loadedByHost[eTopPortNo3])
							&&(!this->loadedByHost[eBottomPortNo]);
			// Top����Bottom����Release����Ă���΁AProcessProcessingComplete����Ă��o��
			if(unloaded){
				::Sleep(500);
				r = this->ProcessCompleteEvent();
			}
		}
	}
	return r;
}


BOOL DlgSG300::WaferEndEvent(bool isTopSide){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	// #TT160624-03(S) ���R��~�΍�
//	CSingleLock W(&WaferEndSema);
//	W.Lock();
	CSingleLock W(&ReportSema, TRUE);
	// #TT160624-03(E)

#if 0
	////////////////////////////////
	//
	// TopWafer��VID�̃Z�b�g
	//
	// �Ǖi�{���f�B���O���ꂽ�J�E���g
	VariantInit(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_PickedUpCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�{���f�B���O���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_PickedUpCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �Ǖi�X�L�b�v���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.UnBondCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_UnBondCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�X�L�b�v���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.UnBondCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_UnBondCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �Ǖi�c��̃J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickRemainCountG;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_RemainingCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�c��̃J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PickRemainCountB;
	if((ret = m_hXComSecs.SetVIDVal("_TopWf_RemainingCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////////////////////////
	//
	// BottomWafer��VID�̃Z�b�g
	//
	// �Ǖi�{���f�B���O���ꂽ�J�E���g
	VariantInit(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PlaceCountG;
	if((ret = m_hXComSecs.SetVIDVal("_BottomWf_PlacedUpCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�{���f�B���O���ꂽ�J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PlaceCountB;
	if((ret = m_hXComSecs.SetVIDVal("_BottomWf_PlacedUpCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �Ǖi�c��̃J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PlaceRemainCountG;
	if((ret = m_hXComSecs.SetVIDVal("_BottomWf_RemainingCount_GDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// �s�Ǖi�c��̃J�E���g
	VariantClear(&vid_data);
	vid_data.vt = VT_I4;
	vid_data.iVal = this->CntD.PlaceRemainCountB;
	if((ret = m_hXComSecs.SetVIDVal("_BottomWf_RemainingCount_BDie",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////////////////////////
	//
	// ���ꂼ��̃Z�b�g
	//
	////////////
	// Top���J�e�S���[
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Bottom���J�e�S���[
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.Category.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Bottom�E�F�n�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomWaferID",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
#endif
	if(isTopSide){
		// #DucMV 20160331 SECS ECID (S)
		////////////////////////////////
		//
		// TopWafer��VID�̃Z�b�g
		//
		////////////////////////////////
		//
		// ���ꂼ��̃Z�b�g
		//
		////////////
		// Top���J�e�S���[
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// LOTID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.lotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpLotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// SLOTID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// SLOTID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_SlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// WaferID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.topCMapWfID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// KeyValue
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.keyVal.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpKeyValueForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// BinVals
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.binVals.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferBinVals",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// BinVals (remain)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.remainBinCounts.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferRemainBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
		////////////
		// BinVals (Pick)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.pickBinCounts.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferPickBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// BinVals (Pick)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.pickBinCounts.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
		////////////
		// CJID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.tmpCJID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_CrJobIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
		////////////
		// PJID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.tmpPJID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_PrJobIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
		// #DucMV 20160331 SECS ECID (E)
		////////////
		// Top�E�F�n�h�c(�s�b�N�A�b�v�^�C�~���O)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferID1",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// �C�x���g�o��
		if((ret = m_hXComSecs.SndEvntInf("TopWaferEnd",0)) != 0){		// DiePick ���b�Z�[�W���M
			r = FALSE;
		}
	}else{
		// #DucMV 20160331 SECS ECID (S)
		////////////////////////////////
		//
		// TopWafer��VID�̃Z�b�g
		//
		////////////
		// Top���J�e�S���[
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// CJID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.tmpCJID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_CrJobIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){	
//			r = FALSE;
		}
		////////////
		// PJID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.tmpPJID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_PrJobIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){	
//			r = FALSE;
		}
		////////////
		// BinVals
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.binVals.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferBinVals",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// BinVals (Pick)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.pickBinCounts.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
		////////////
		// LOTID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomLotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpLotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// SLOT ID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomSlotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// SLOT ID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomSlotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_SlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// Wafer ID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// KeyValue
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomkeyVal.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpKeyValueForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// BinVals
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.binVals.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_BottomWaferBinVals",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// BinCounts
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bondBinCounts.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_BottomWaferBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// Bottom���J�e�S���[
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.Category.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_BottomCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// #DucMV 20160331 SECS ECID (E)
		////////////
		// Top�E�F�n�h�c(�v���[�X�^�C�~���O)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.topWaferID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferID2",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// �C�x���g�o��
		if((ret = m_hXComSecs.SndEvntInf("BottomWaferEnd",0)) != 0){		// DiePick ���b�Z�[�W���M
			r = FALSE;
		}
	}
	W.Unlock();
	return r;
}

BOOL DlgSG300::WaferStartEvent(bool isTopSide){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	// #TT160624-03(S) ���R��~�΍�
//	CSingleLock W(&WaferEndSema);
//	W.Lock();
	CSingleLock W(&ReportSema, TRUE);
	// #TT160624-03(E) ���R��~�΍�
	////////////////////////////////
	//
	// ���ꂼ��̃Z�b�g
	//
	////////////
	// Top���J�e�S���[
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.Category.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopCategory",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	if(isTopSide){
		// #DucMV 20160331 SECS ECID (S)
		////////////
		// LOTID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.lotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpLotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// SLOTID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// WaferID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.topCMapWfID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// KeyValue
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.keyVal.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpKeyValueForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		////////////
		// BinVals (remain)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.remainBinCounts.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferRemainBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){	
			r = FALSE;
		}
		////////////
		// BinVals (Pick)
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceTopD.pickBinCounts.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_TopWaferPickBinCounts",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// #DucMV 20160331 SECS ECID (E)
		// �C�x���g�o��
		if((ret = m_hXComSecs.SndEvntInf("TopWaferStart",0)) != 0){		// DiePick ���b�Z�[�W���M
			r = FALSE;
		}
	}else{
		// #DucMV 20160331 SECS ECID (S)
		////////////
		// LOTID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomLotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpLotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// SLOT ID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomSlotID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// Wafer ID
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// KeyValue
		VariantInit(&vid_data);
		vid_data.vt = VT_BSTR;
		vid_data.bstrVal = this->TraceBotD.bottomkeyVal.AllocSysString();
		if((ret = m_hXComSecs.SetVIDVal("_tmpKeyValueForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
			r = FALSE;
		}
		// #DucMV 20160331 SECS ECID (E)
		// �C�x���g�o��
		if((ret = m_hXComSecs.SndEvntInf("BottomWaferStart",0)) != 0){		// DiePick ���b�Z�[�W���M
			r = FALSE;
		}
	}
	W.Unlock();
	return r;
}

BOOL DlgSG300::WaferPickUpEvent(void)
{
	BOOL r = TRUE;
	long ret;
	if((ret = m_hXComSecs.SndEvntInf("WaferPickUpEvent",0)) != 0){		// DiePick ���b�Z�[�W���M
		r = FALSE;
	}
	return r;
}

BOOL DlgSG300::PickupReportEvent(){

	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	CSingleLock W(&ReportSema, TRUE);	// #TT160624-03 ���R��~�΍�
	////////////
	// �i�햼
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.recipeName.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_RecipeName",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Top�E�F�n�L�����A�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topWaferCarrierID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferCarrierID1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Top�E�F�n�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferID1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// X��
	VariantInit(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceTopD.pick_x;
	if((ret = m_hXComSecs.SetVIDVal("_TOPDIEPOSITION_X1",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// Y��
	VariantClear(&vid_data);
	vid_data.vt = VT_BSTR;
	CString temp;
	if (this->TraceTopD.portNo >= eTopPortNo2) {
		temp.Format("%s",this->TraceTopD.pickIcID);
	} else {
		temp.Format("%d",this->TraceTopD.pick_y);
	}
	vid_data.bstrVal = temp.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TOPDIEPOSITION_Y1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// pickup�^�C���X�^���v
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.pickupTime.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_PickupedTime1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// TopDie�r���R�[�h
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topDieBin.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopBin1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #TT150402-01(S)
	////////////
	// �����WX
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceTopD.actualCoordinateX;
	if((ret = m_hXComSecs.SetVIDVal("_TopDieActualCoordinate_X",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �����WY
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceTopD.actualCoordinateY;
	if((ret = m_hXComSecs.SetVIDVal("_TopDieActualCoordinate_Y",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �}�b�`���O���P�_��
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceTopD.matchingRatio_1stPos;
	if((ret = m_hXComSecs.SetVIDVal("_TopDieRecogMatchRatio_1stPos",vid_data,0x0080,1,0,0,0,0)) != 0){	// #TT150421-01
		r = FALSE;
	}
	////////////
	// �}�b�`���O���Q�_��
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceTopD.matchingRatio_2ndPos;
	if((ret = m_hXComSecs.SetVIDVal("_TopDieRecogMatchRatio_2ndPos",vid_data,0x0080,1,0,0,0,0)) != 0){	// #TT150421-01
		r = FALSE;
	}
	// #TT150402-01(E)
	// DuyND 20160218 (S)
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceTopD.settingBgLevel;
	if((ret = m_hXComSecs.SetVIDVal("_SettingBgLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceTopD.settingDippingLevel;
	if((ret = m_hXComSecs.SetVIDVal("_SettingDippingLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceTopD.actualPickLevel;
	if((ret = m_hXComSecs.SetVIDVal("_ActualPickLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceTopD.settingPickLevel;
	if((ret = m_hXComSecs.SetVIDVal("_SettingPickLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// DuyND 20160218 (E)
	// #DucMV 20160331 SECS ECID (S)
	////////////
	// LOTID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.lotID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_tmpLotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// SLOTID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// SLOTID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.slotID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_SlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// WaferID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.topCMapWfID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// KeyValue
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceTopD.keyVal.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_tmpKeyValueForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	
	/////////////////////
	// PickLevel
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceTopD.tmpFlipHeight;
	if((ret = m_hXComSecs.SetVIDVal("_PickLevelForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// TopPortIDForReport
	VariantClear(&vid_data);
	vid_data.vt = VT_UI1;
	vid_data.uiVal = this->TraceTopD.portNo;
	if((ret = m_hXComSecs.SetVIDVal("_TopPortIDForPickReport",vid_data,0x00a4,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #DucMV 20160331 SECS ECID (E)
//#if 0	// #TT160621-03 FDC�@�\�̒ǉ��𐶂���
	// #DuyND20160427 (S)
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceTopD.recogResult1X;
	if((ret = m_hXComSecs.SetVIDVal("_TDRecogResult1X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceTopD.recogResult1Y;
	if((ret = m_hXComSecs.SetVIDVal("_TDRecogResult1Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceTopD.recogResult2X;
	if((ret = m_hXComSecs.SetVIDVal("_TDRecogResult2X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceTopD.recogResult2Y;
	if((ret = m_hXComSecs.SetVIDVal("_TDRecogResult2Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceTopD.recogScore1;
	if((ret = m_hXComSecs.SetVIDVal("_TDRecogScore1",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceTopD.recogScore2;
	if((ret = m_hXComSecs.SetVIDVal("_TDRecogScore2",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceTopD.lCheck;
	if((ret = m_hXComSecs.SetVIDVal("_TDLCheck",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #DuyND20160427 (E)
//#endif	
	///////////////////////////
	// DiePick ���b�Z�[�W���M
	if((ret = m_hXComSecs.SndEvntInf("DiePick",0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	return r;
}

BOOL DlgSG300::BondingReportEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	CSingleLock W(&ReportSema, TRUE);	// #TT160624-03 ���R��~�΍�
	////////////
	// �i�햼
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.recipeName.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_RecipeName",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Top�E�F�n�L�����A�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topWaferCarrierID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferCarrierID2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Top�E�F�n�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopWaferID2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// pick_X��
	VariantInit(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.pick_x;
	if((ret = m_hXComSecs.SetVIDVal("_TOPDIEPOSITION_X2",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// pick_Y��
	VariantClear(&vid_data);
	vid_data.vt = VT_BSTR;
	CString temp;
	if (this->TraceBotD.topPortNo >= eTopPortNo2) {
		temp.Format("%s",this->TraceBotD.pickIcID);
	} else {
		temp.Format("%d",this->TraceBotD.pick_y);
	}
	vid_data.bstrVal = temp.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TOPDIEPOSITION_Y2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// pickup�^�C���X�^���v
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.pickupTime.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_PickupedTime2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// TopDie�r���R�[�h
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.topDieBin.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_TopBin2",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Bottom�E�F�n�L�����A�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomWaferCarrierID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomWaferCarrierID",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// Bottom�E�F�n�h�c
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomWaferID",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// place_X��
	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.place_x;
	if((ret = m_hXComSecs.SetVIDVal("_BOTTOMDIEPOSITION_X",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// place_Y��
	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.place_y;
	if((ret = m_hXComSecs.SetVIDVal("_BOTTOMDIEPOSITION_Y",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// BgSite
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bgSite.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BondingSite",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// BottomDie�r���R�[�h
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomDieBin.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_BottomBin",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// place�^�C���X�^���v
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.placeTime.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_PlacedTime",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #TT150402-01(S)
	////////////
	// ��BgLevel
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.actualBgLevel;
	if((ret = m_hXComSecs.SetVIDVal("_ActualBondingLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �ݒ�BgForce
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.settingBgForce;
	if((ret = m_hXComSecs.SetVIDVal("_SettingBondingForce",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// ��BgForce
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.actualBgForce;
	if((ret = m_hXComSecs.SetVIDVal("_ActualBondingForce",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////	// #TT150421-01
	// �ݒ�BgTime
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.settingBgTime;
	if((ret = m_hXComSecs.SetVIDVal("_SettingBondingTime",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// ��F���}�b�`���O���P�_��
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.substMatchingRatio_1stPos;
	if((ret = m_hXComSecs.SetVIDVal("_SubstRecogMatchingRatio_1stPos",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// ��F���}�b�`���O���Q�_��
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.substMatchingRatio_2ndPos;
	if((ret = m_hXComSecs.SetVIDVal("_SubstRecogMatchingRatio_2ndPos",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// ��}�[�N�X�p��
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.substMarkDistance;
	if((ret = m_hXComSecs.SetVIDVal("_SubstRecogMarkDistance",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �h�b�F���}�b�`���O���P�_��
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.icMatchingRatio_1stPos;
	if((ret = m_hXComSecs.SetVIDVal("_IcRecogMatchingRatio_1stPos",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �h�b�F���}�b�`���O���Q�_��
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.icMatchingRatio_2ndPos;
	if((ret = m_hXComSecs.SetVIDVal("_IcRecogMatchingRatio_2ndPos",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �h�b�}�[�N�X�p��
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.icMarkDistance;
	if((ret = m_hXComSecs.SetVIDVal("_IcRecogMarkDistance",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #TT150402-01(E)
	// DuyND 20160218 (S)
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.settingBgLevel;
	if((ret = m_hXComSecs.SetVIDVal("_SettingBgLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.settingDippingLevel;
	if((ret = m_hXComSecs.SetVIDVal("_SettingDippingLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.actualDippingLevel;
	if((ret = m_hXComSecs.SetVIDVal("_ActualDippingLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.placeUpX;
	if((ret = m_hXComSecs.SetVIDVal("_PlaceUpX",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.placeUpY;
	if((ret = m_hXComSecs.SetVIDVal("_PlaceUpY",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceBotD.placeUpZ;
	if((ret = m_hXComSecs.SetVIDVal("_PlaceUpZ",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// DuyND 20160218 (E)

	// #DucMV 20160331 SECS ECID (S)
	////////////
	// LOTID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomLotID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_tmpLotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// SLOT ID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomSlotID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_tmpSlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// SLOT ID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomSlotID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_SlotIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// Wafer ID
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomWaferID.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_tmpWaferIDForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// KeyValue
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceBotD.bottomkeyVal.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_tmpKeyValueForEvent",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// BottomPortIDForReport
	VariantClear(&vid_data);
	vid_data.vt = VT_UI1;
	vid_data.uiVal = this->TraceBotD.bottomPortNo;
	if((ret = m_hXComSecs.SetVIDVal("_BottomPortIDForPlaceReport",vid_data,0x00a4,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// TopPortIDForReport
	VariantClear(&vid_data);
	vid_data.vt = VT_UI1;
	vid_data.uiVal = this->TraceBotD.topPortNo;
	if((ret = m_hXComSecs.SetVIDVal("_TopPortIDForPlaceReport",vid_data,0x00a4,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// BgForce
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpBgForce;
	if((ret = m_hXComSecs.SetVIDVal("_BgForceForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// BgLevel
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpBgLevel;
	if((ret = m_hXComSecs.SetVIDVal("_BgLevelForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// BgGap
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpBgOverTravel;
	if((ret = m_hXComSecs.SetVIDVal("_BgGapForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// BgTemperature
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpBgTemp;
	if((ret = m_hXComSecs.SetVIDVal("_BgTempForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// BgStgTemperature
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpBgStgTemp;
	if((ret = m_hXComSecs.SetVIDVal("_BgStgTempForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// DippingForce
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpDipForce;
	if((ret = m_hXComSecs.SetVIDVal("_DipForceForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// DippingLevel
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpDipLevel;
	if((ret = m_hXComSecs.SetVIDVal("_DipLevelForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// DiePlace��BondingStageXY�̈ʒu��ǉ�
	/////////////////////
	// Bonding Stage X Axis
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpStage_x;
	if((ret = m_hXComSecs.SetVIDVal("_BgStgXForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// Bonding Stage X Axis
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.tmpStage_y;
	if((ret = m_hXComSecs.SetVIDVal("_BgStgYForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// Pre Pick Level
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.prePickLevel;
	if((ret = m_hXComSecs.SetVIDVal("_PrePickLevelForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	/////////////////////
	// Pre Pick Force
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.prePickForce;
	if((ret = m_hXComSecs.SetVIDVal("_PrePickForceForEvent",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #DucMV 20160331 SECS ECID (E)
//#if 0	// #TT160621-03 FDC�@�\�̒ǉ��𐶂���
	// #DuyND20160427 (S)
	// ��� (S)
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogMovePos1X;;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogMovePos1X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogMovePos1Y;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogMovePos1Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogMovePos2X;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogMovePos2X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogMovePos2Y;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogMovePos2Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.subRecogScore1;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogScore1",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogResult1X;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogResult1X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogResult1Y;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogResult1Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.subRecogScore2;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogScore2",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogResult2X;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogResult2X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogResult2Y;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogResult2Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogResultPos1X;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogResultPos1X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogResultPos1Y;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogResultPos1Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogResultPos2X;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogResultPos2X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subRecogResultPos2Y;
	if((ret = m_hXComSecs.SetVIDVal("_SubRecogResultPos2Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.subLCheck;
	if((ret = m_hXComSecs.SetVIDVal("_SubLCheck",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// ��� (E)

	// IC (S)
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogMovePos1X;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogMovePos1X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogMovePos1Y;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogMovePos1Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogMovePos2X;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogMovePos2X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogMovePos2Y;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogMovePos2Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.icRecogScore1;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogScore1",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogResult1X;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogResult1X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogResult1Y;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogResult1Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceBotD.icRecogScore2;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogScore2",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogResult2X;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogResult2X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogResult2Y;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogResult2Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogResultPos1X;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogResultPos1X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogResultPos1Y;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogResultPos1Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogResultPos2X;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecodResultPos2X",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icRecogResultPos2Y;
	if((ret = m_hXComSecs.SetVIDVal("_ICRecogResultPos2Y",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.icLCheck;
	if((ret = m_hXComSecs.SetVIDVal("_ICLCheck",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// IC (E)

	// Bonding (S)
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.bgPosCorX;
	if((ret = m_hXComSecs.SetVIDVal("_BgPosCorX",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.bgPosCorY;
	if((ret = m_hXComSecs.SetVIDVal("_BgPosCorY",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.bgPosCorT;
	if((ret = m_hXComSecs.SetVIDVal("_BgPosCorT",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.stgPosX;
	if((ret = m_hXComSecs.SetVIDVal("_StgPosX",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.stgPosY;
	if((ret = m_hXComSecs.SetVIDVal("_StgPosY",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.stgActualPosX;
	if((ret = m_hXComSecs.SetVIDVal("_StgActualPosX",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.stgActualPosY;
	if((ret = m_hXComSecs.SetVIDVal("_StgActualPosY",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}

	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.stgCorX;
	if((ret = m_hXComSecs.SetVIDVal("_StgCorX",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.stgCorY;
	if((ret = m_hXComSecs.SetVIDVal("_StgCorY",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.dipLevel;
	if((ret = m_hXComSecs.SetVIDVal("_DipLevel",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	
	VariantClear(&vid_data);
	vid_data.vt = VT_R4;
	vid_data.fltVal = this->TraceBotD.bgLevel;
	if((ret = m_hXComSecs.SetVIDVal("_BgLevel",vid_data,0x0090,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	// #DuyND20160427 (E)
//#endif	
	/////////////////////////
	//
	// �C�x���g���s
	//
	if((ret = m_hXComSecs.SndEvntInf("DiePlace",0)) != 0){		// DiePlace ���b�Z�[�W���M
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}

// #TT150402-01(S)
// �E�F�n�}�b�v�A���C�����g�����C�x���g���M�@���M�ꏊ�m��
BOOL DlgSG300::WfMapAlingmentReportEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	////////////
	// VID�ݒ�
	////////////
	// IndexX
	VariantInit(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceMapAlignD.indexX;
	if((ret = m_hXComSecs.SetVIDVal("_TopWfMapAlignmentIndex_X1",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// IndexY
	VariantInit(&vid_data);
	vid_data.vt = VT_I2;
	vid_data.iVal = this->TraceMapAlignD.indexY;
	if((ret = m_hXComSecs.SetVIDVal("_TopWfMapAlignmentIndex_Y1",vid_data,0x0068,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// MatchingRatio
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceMapAlignD.matchingRatio;
	if((ret = m_hXComSecs.SetVIDVal("_TopWfMapAlignmentMatchingRatio",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �C�x���g���s
	////////////
	if((ret = m_hXComSecs.SndEvntInf("MapAlignmentEvent",0)) != 0){		// DiePlace ���b�Z�[�W���M
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}
// Dipping�����C�x���g���M�@���M�ꏊ�m��
BOOL DlgSG300::DippingReportEvent(){
	BOOL r = TRUE;
	long	ret;
	VARIANT vid_data;
	////////////
	// VID�ݒ�
	////////////
	// ��DippingLevel
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceDippingD.actualDippingLevel;
	if((ret = m_hXComSecs.SetVIDVal("_ActualDippingLevel",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �ݒ�׏d
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceDippingD.settingDippingForce;
	if((ret = m_hXComSecs.SetVIDVal("_SettingDippingForce",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// ���׏d
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceDippingD.actualDippingForce;
	if((ret = m_hXComSecs.SetVIDVal("_ActualDippingForce",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �]�ʎ���
	VariantInit(&vid_data);
	vid_data.vt = VT_R8;
	vid_data.dblVal = this->TraceDippingD.settingDippingTime;
	if((ret = m_hXComSecs.SetVIDVal("_SettingDippingTime",vid_data,0x0080,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �i�햼
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceDippingD.recipeName.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_RecipeName",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �]�ʎ���
	VariantInit(&vid_data);
	vid_data.vt = VT_BSTR;
	vid_data.bstrVal = this->TraceDippingD.dippedTime.AllocSysString();
	if((ret = m_hXComSecs.SetVIDVal("_DippedTime1",vid_data,0x0040,1,0,0,0,0)) != 0){
		r = FALSE;
	}
	////////////
	// �C�x���g���s
	//
	if((ret = m_hXComSecs.SndEvntInf("DippingEvent",0)) != 0){		// ���b�Z�[�W���M
		r = FALSE;
	}
	VariantClear(&vid_data);
	return r;
}
// �����^�]�̃X�g�b�v�C�x���g���M

// #DucMV 20160317 Flux function (S)
BOOL DlgSG300::FluxFinishEvent()
{
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("FluxFinishEvent",0)) != 0){
		r = FALSE;
	}
	return r;
}
// #DucMV 20160317 Flux function (E)

// #DucMV 20160317 Flux function (S)
BOOL DlgSG300::ParticleFinishEvent()
{
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("ParticleFinishEvent",0)) != 0){
		r = FALSE;
	}
	return r;
}
// #DucMV 20160317 Flux function (E)

// #TT150402-01 �����^�]��~�C�x���g
BOOL DlgSG300::ProcessEndReportEvent()
{
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("ProcessEndExecuting",0)) != 0){		// ProcessEndExecuting ���b�Z�[�W���M
		r = FALSE;
	}
	return r;
}
// �i��f�[�^�ύX�C�x���g���M�@���M�ꏊ�m��
BOOL DlgSG300::PPRecipeSendReportEvent()
{
	BOOL r = TRUE;
	long	ret;
	if((ret = m_hXComSecs.SndEvntInf("PPRecipeSend",0)) != 0){		// PPRecipeSend ���b�Z�[�W���M
		r = FALSE;
	}
	return r;
}
// �E�F�n�s�b�N�A�b�v�ς݊����C�x���g���M�i���ɂ���jPickupReportEvent()
// Bonding�����C�x���g���M�i���ɂ��肾���A�g���܂킹�邩�����K�v�j	BondingReportEvent()
// �P��I���C�x���g���M�i���ɂ��肾���A�g���܂킹�邩�����K�v�jpMCC->dlgSG300.WaferEndEvent(false);
// �����^�]�̃X�^�[�g�C�x���g���M�@���M�ꏊ�m�� �g�p����֐���ProcessStartEvent()

// #TT150402-01(E)


///////////////////////////////////////////////////////////////////
//
//
//
//
//	G e t M a p F i l e N a m e
//
//
//
//
//BOOL DlgSG300::GetBottomFileMapName(CString SlotID, int slotNo,/* int isTopSide,*/ char *mID, int timeout){
BOOL DlgSG300::GetBottomFileMapName(CString SlotID, int slotNo, CString waferID, char *mID, int timeout){
#if !Release
				TRACE("GetBottomFileMapName = %s\n", SlotID);
#endif
	CSingleLock W(&S12F73Sema);
	W.Lock();
	BOOL r = TRUE;
	//�A�C�e���ɃZ�b�g
	PutSecsItem4ByteInteger("V1", SlotID.GetLength(), 0, 0);
	PutSecsItemSingleASCII("Itm_SLOTID",SlotID);
	// �E�F�n�h�c�̎擾
	// �E�F�n�h�c�̓R���e���g�}�b�v����擾
	CString portID = "1";
	this->PutSecsItem4ByteInteger("V2", portID.GetLength(), 0, 0);
	this->PutSecsItemSingleASCII("Itm_PortIDAscii",portID);
	// #TT160525-01 S12F73�����������M����Ȃ����̑΍�
	// #TT160601-01 OCR�̓ǂݎ�茋�ʂ�SlotID�ł͂Ȃ�waferID�ɒǉ�����B
	//CString waferID = waferIdOfContentMap[slotNo-1];
//	this->PutSecsItem4ByteInteger("V3", waferID.GetLength(), 0, 0);
	this->PutSecsItem4ByteInteger("V5", waferID.GetLength(), 0, 0);
	// #TT160525-01 S12F73�����������M����Ȃ����̑΍�
//	this->PutSecsItemSingleASCII("Itm_WaferID",waferID);
	this->PutSecsItemSingleASCII("Itm_WaferID5",waferID);
	//S12F73���M
	m_hXComSecs.PutSecsEvent("_GS12F73S");
	//S12F74�҂�
	this->pEvFinInfoFileMapName		= &EvFinFileMapName;
	this->pEvFailInfoFileMapName	= &EvFailFileMapName;
	enum{
		WaitCnt		= 3,
	};
	EvFinFileMapName.ResetEvent();
	EvFailFileMapName.ResetEvent();
	// �}���`���b�N�҂�
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinInfoFileMapName;
	ppObjects[1]	= pEvFailInfoFileMapName;
	ppObjects[2]	= pEvStopWaitingSecsB;		// ���f
	CMultiLock	M(ppObjects,WaitCnt);
	// 
	if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
		// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
		// �ŏI�I�ɂ�ItemGet��T3�^�C���A�E�g���Z�b�g����
		int i = M.Lock(timeout+1000, FALSE);
		M.Unlock();
		if(i == WAIT_TIMEOUT){
			// T3�^�C���A�E�g
			r = FALSE;
		}else{
			i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == i) {
				//����
				r = TRUE;
			} else if (1 == i) {
				//���s
				r = FALSE;
			} else if (2 == i) {
				//�r����~(���f)
				r = FALSE;
			}
		}
	}
	this->pEvFinInfoFileMapName = NULL;
	this->pEvFailInfoFileMapName = NULL;
	if(r){
		strcpy(mID, GetItemDataSingleASCII("Itm_MAPFILENAME"));
	}
#if !Release
				TRACE("GetBottomFileMapName = End\n");
#endif
	W.Unlock();
	return r;
}

// #DDT160428-01 (S) Add port number
BOOL DlgSG300::GetTopFileMapName(int portNo, CString SlotID, char *mID, int timeout){

#if !Release
				TRACE("GetTopFileMapName = Port=%d,Slot=%s\n", portNo, SlotID);
#endif
	CSingleLock W(&S12F73Sema);
	W.Lock();
	BOOL r = TRUE;
	//�A�C�e���ɃZ�b�g
///	PutSecsItemSingleLong("V1", (long)SlotID.GetLength());
	this->PutSecsItem4ByteInteger("V1", SlotID.GetLength(), 0, 0);
	PutSecsItemSingleASCII("Itm_SLOTID",SlotID);
	// �|�[�g�h�c = 2 �ƂƂ肠������`����B
	CString portID = "2";
	// #DDT160428 Add port number
	portID.Format(_T("%d"), portNo);
///	this->PutSecsItemSingleLong("V2", (long)portID.GetLength());
	this->PutSecsItem4ByteInteger("V2", portID.GetLength(), 0, 0);
	this->PutSecsItemSingleASCII("Itm_PortIDAscii",portID);
	// �E�F�n�h�c�̎擾
	CString waferID;
	waferID.Format("%s", mID);
///	this->PutSecsItemSingleLong("V3", (long)waferID.GetLength());
//	this->PutSecsItem4ByteInteger("V3", waferID.GetLength(), 0, 0);
//	this->PutSecsItemSingleASCII("Itm_WaferID",waferID);
	// #TT160525-01 S12F73�����������M����Ȃ����̑΍�
	this->PutSecsItem4ByteInteger("V5", waferID.GetLength(), 0, 0);
	this->PutSecsItemSingleASCII("Itm_WaferID5",waferID);
	//S12F73���M
	m_hXComSecs.PutSecsEvent("_GS12F73S");
	//S12F74�҂�
	this->pEvFinInfoFileMapName		= &EvFinFileMapName;
	this->pEvFailInfoFileMapName	= &EvFailFileMapName;
	enum{
		WaitCnt		= 3,
	};
	EvFinFileMapName.ResetEvent();
	EvFailFileMapName.ResetEvent();
	// �}���`���b�N�҂�
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinInfoFileMapName;
	ppObjects[1]	= pEvFailInfoFileMapName;
	ppObjects[2]	= pEvStopWaitingSecsT;		// ���f
	CMultiLock	M(ppObjects,WaitCnt);
	//
	if(this->getCtrlState() == eOnlineRemote){		//Online Remote �̂Ƃ��̂ݑ҂�
		// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
		// �ŏI�I�ɂ�ItemGet��T3�^�C���A�E�g���Z�b�g����
		int i = M.Lock(timeout+1000, FALSE);
		M.Unlock();
		if(i == WAIT_TIMEOUT){
			// T3�^�C���A�E�g
			r = FALSE;
		}else{
			i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
			if (0 == i) {
				//����
				r = TRUE;
			} else if (1 == i) {
				//���s
				r = FALSE;
			} else if (2 == i) {
				//�r����~(���f)
				r = FALSE;
			}
		}
	}
	this->pEvFinInfoFileMapName = NULL;
	this->pEvFailInfoFileMapName = NULL;
	if(r){
		strcpy(mID, GetItemDataSingleASCII("Itm_MAPFILENAME"));
	}
#if !Release
				TRACE("GetTopFileMapName = End\n");
#endif
	W.Unlock();
	return r;
}
// #DDT160428-01 (E)

// #KS20130415-01 [�ǉ�]SECS�E�F�n�}�b�s���O
//�}�b�v���擾  add 130118_Misato
//S12F3

BOOL DlgSG300::MapSetupDataRequest(MapData *pMapD)
{
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (pSecsTDS) {
//			r = pSecsTDS->MapSetupDataRequest(pMapD);
//		}
//		return(r);
///	}

//	MapCtrl.EvReqMapOK.SetEvent();

// #KS20130417-01(E)
	BOOL r = TRUE;
	//
	if (this->getCtrlState() <= eHostOffline) {	// �ʐM���؂�Ă���
		this->MapCtrl.bReqMap = FALSE;
		return(FALSE);
	}
	if (pMapD) {	// �J�n
		if (this->MapCtrl.bReqMap) {
			//r = FALSE;
		}
		this->MapCtrl.pMapData = pMapD;
		this->MapCtrl.EvReqMapOK.ResetEvent();
		this->MapCtrl.EvReqMapEnd.ResetEvent();
		this->MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_Nothing;
		this->MapCtrl.bReqMap = true;
		if (r) r = SendS12F3();
		if (r) {
			CSingleLock L(&this->MapCtrl.EvReqMapOK, TRUE);	// S12F04�̌���
			if (this->MapCtrl.iReqMapErr) {
				r = FALSE;
			}
		}
		if (!r) {
			this->MapCtrl.bReqMap = false;
		}
	} else {	// �Q���
		if (!this->MapCtrl.bReqMap) {	// ���s���łȂ�
			r = FALSE;
		} else {
			CSingleLock L(&this->MapCtrl.EvReqMapEnd, TRUE);	// S12F16�̌���
			if (this->MapCtrl.iReqMapErr) {
				r = FALSE;
			}
			this->MapCtrl.bReqMap = false;
		}
	}
	return(r);
}

BOOL DlgSG300::SendS12F3()
{
	BOOL r = TRUE;
	this->PutSecsItemSingleUnsignInt("SendStrLen_4", MapCtrl.pMapData->MID.GetLength(), "U4");	//MID
	this->PutSecsItemSingleASCII("Item_MID", MapCtrl.pMapData->MID);
	this->PutSecsItemSingleBIN("Item_IDTYP", 0);												//IDTYP
	this->PutSecsItemSingleBIN("Item_MAPFT", 1);												//MAPFT
	this->PutSecsItemSingleUnsignInt("Item_FNLOC", MapCtrl.pMapData->FNLOC, "U2");				//FNLOC
	this->PutSecsItemSingleUnsignInt("Item_FFROT", 0, "U2");									//FFROT
	this->PutSecsItemSingleBIN("Item_ORLOC", 2);												//ORLOC
	this->PutSecsItemSingleBIN("Item_PRAXI", 0);												//PRAXI
	this->PutSecsItemSingleUnsignInt("SendStrLen_2", MapCtrl.pMapData->BCEQU.GetLength(), "U4");
	this->PutSecsItemSingleASCII("Item_BCEQU", MapCtrl.pMapData->BCEQU);
	this->PutSecsItemSingleUnsignInt("SendStrLen_3", MapCtrl.pMapData->NULBC.GetLength(), "U4");
	this->PutSecsItemSingleASCII("Item_NULBC", MapCtrl.pMapData->NULBC);
	if (m_hXComSecs.PutSecsEvent("_GS12F03S") != 0) {
		r = FALSE;
	}
	return(r);
}

//S12F4��M(Map Set-up Data)
BOOL DlgSG300::RecvS12F4()
{
	BOOL r = TRUE;
	int nByte = 0;
	if (!MapCtrl.bReqMap) {
		return(r);
	}
	//
	CString recv_mid = this->GetItemDataSingleASCII("Item_MID");
	unsigned int recv_idtyp = this->GetItemDataSingleUnsignInt("Item_IDTYP", "U1");
	int fnloc = this->GetItemDataSingleUnsignInt("Item_FNLOC", "U2");
	int orloc = this->GetItemDataSingleUnsignInt("Item_ORLOC", "U1");

	MapCtrl.pMapData->ROWCT = this->GetItemDataSingleUnsignInt("Item_ROWCT", "U2");
	MapCtrl.pMapData->COLCT = this->GetItemDataSingleUnsignInt("Item_COLCT", "U2");
	MapCtrl.pMapData->BCEQU = this->GetItemDataSingleASCII("Item_BCEQU");
	MapCtrl.pMapData->NULBC = this->GetItemDataSingleASCII("Item_NULBC");

	MapCtrl.pMapData->RPSEL = this->GetItemDataSingleUnsignInt("Item_RPSEL", "U1");

	if(MapCtrl.pMapData->RPSEL == 0)
	{
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}

	//�f�[�^�`�F�b�N
	if (0 != recv_mid.Compare(MapCtrl.pMapData->MID)) {
		nByte = 1;  
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if(recv_idtyp != 0){
		nByte = sizeof(recv_mid)  + 1;
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if(orloc != 2){
		nByte = sizeof(recv_mid) + sizeof(recv_idtyp) + sizeof(fnloc) + 1; 
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if (fnloc != MapCtrl.pMapData->FNLOC) {
		nByte = sizeof(recv_mid) + sizeof(recv_idtyp) + 1; 
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}

	//�ʐM�װ���A�װ��ʕ\��(S)
	if(r == FALSE){
		MapCtrl.bReqMap = FALSE;
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	}
	MapCtrl.EvReqMapOK.SetEvent();
	return(r);
}

// ϯ���ް��v��
BOOL DlgSG300::SendS12F15()
{
	BOOL r = TRUE;
	if (!MapCtrl.bReqMap) {
		return(r);
	}
	if (m_hXComSecs.PutSecsEvent("_GS12F15S") != 0) {
		r = FALSE;
		if (MapCtrl.bReqMap) {
			MapCtrl.bReqMap = FALSE;
			MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_Send;
			MapCtrl.EvReqMapEnd.SetEvent();
		}
	}
	return(r);
}

BOOL DlgSG300::RecvS12F16()
{
	BOOL r = TRUE;
	int nByte = 0;
	if (!MapCtrl.bReqMap) {
		return(r);
	}
	CString recv_mid = this->GetItemDataSingleASCII("Item_MID");
	unsigned int recv_idtyp = this->GetItemDataSingleUnsignInt("Item_IDTYP", "U1");
	
	//�f�[�^�`�F�b�N
	if (0 != recv_mid.Compare(MapCtrl.pMapData->MID)) {
		nByte = 1;  
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if(recv_idtyp != 0){
		nByte = sizeof(recv_mid) + 1;
		SendS12F19(0, (BYTE)nByte);
		r = FALSE;
	}
	if(r == FALSE){
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	} else {
		MapCtrl.pMapData->BINLT = this->GetItemDataSingleASCII("Item_BINLT");
		int nSize = MapCtrl.pMapData->ROWCT * MapCtrl.pMapData->COLCT;
		int nLen = MapCtrl.pMapData->BINLT.GetLength();
		if( nSize != nLen ){
			nByte = sizeof(recv_mid)  + sizeof(recv_idtyp) + sizeof(MapCtrl.pMapData->STRPX) + sizeof(MapCtrl.pMapData->STRPY) + 1;
			SendS12F19(0, (BYTE)nByte);
			r = FALSE;
		}
		else{
			// #TT141113-02
			// Host���}�b�v�f�[�^����M�������_�ŁA�Ȃ����}�b�v����]�����Ă���B
			// ���j���킩��Ȃ������l�T�X����ɂ��̕����w�E����A�폜�B
			// �d�l�ł�Host����M�����}�b�v�f�[�^�����̂܂�WMV�ŕ\�������邱�ƂƂȂ��Ă���
///			MapCtrl.pMapData->BINLT.MakeReverse();
		}
	}
	MapCtrl.EvReqMapEnd.SetEvent();
	return(r);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// #MO20131129
//ϯ�ߏ��m�F
//S12F1

//BOOL DlgSG300::MapSetupDataSend(CString read_mid)
BOOL DlgSG300::MapSetupDataSend(MapData *pMapD)
{
	BOOL r = TRUE;

	//S12F1 Map Set-up Data Send
	this->PutSecsItemSingleUnsignInt("SendStrLen_4", MapCtrl.pMapData->MID.GetLength(), "U4");	//MID
	this->PutSecsItemSingleASCII("Item_MID", MapCtrl.pMapData->MID);
	this->PutSecsItemSingleBIN("Item_IDTYP", 0);												//IDTYP
	this->PutSecsItemSingleUnsignInt("Item_FNLOC", MapCtrl.pMapData->FNLOC, "U2");				//FNLOC
	this->PutSecsItemSingleUnsignInt("Item_FFROT", 0, "U2");									//FFROT
	this->PutSecsItemSingleBIN("Item_ORLOC", 2);												//ORLOC
	this->PutSecsItemSingleUnsignInt("Item_RPSEL", 1, "U1");									
	this->PutSecsItemSingleUnsignInt("SendStrLen_5", MapCtrl.pMapData->DUTMS.GetLength(), "U4");
	this->PutSecsItemSingleASCII("Item_DUTMS", MapCtrl.pMapData->DUTMS);											//Misato
	this->PutSecsItem8ByteFloating("Item_XDIES", MapCtrl.pMapData->XDIES, 0, 0);
	this->PutSecsItem8ByteFloating("Item_YDIES", MapCtrl.pMapData->YDIES, 0, 0);
	this->PutSecsItemSingleUnsignInt("Item_ROWCT", MapCtrl.pMapData->ROWCT, "U2");
	this->PutSecsItemSingleUnsignInt("Item_COLCT", MapCtrl.pMapData->COLCT, "U2");
//	this->PutSecsItemSingleUnsignInt("SendStrLen_2", MapCtrl.pMapData->BCEQU.GetLength(), "U4");
//	this->PutSecsItemSingleASCII("Item_BCEQU", MapCtrl.pMapData->BCEQU);
	this->PutSecsItemSingleUnsignInt("SendStrLen_3", MapCtrl.pMapData->NULBC.GetLength(), "U4");
	this->PutSecsItemSingleASCII("Item_NULBC", MapCtrl.pMapData->NULBC);
	this->PutSecsItemSingleUnsignInt("Item_PRDCT", MapCtrl.pMapData->PRDCT, "U2");								
	this->PutSecsItemSingleBIN("Item_PRAXI", 0);												//PRAXI
	//S12F2,S12F6,S12F10�҂�
	this->pEvS12F2Recv = &EvS12F2Recv;
	this->pEvS12F6Recv = &EvS12F6Recv;
	this->pEvS12F10Recv = &EvS12F10Recv;
	EvS12F2Recv.ResetEvent();
	EvS12F6Recv.ResetEvent();
	EvS12F10Recv.ResetEvent();
	//���M
	if(m_hXComSecs.PutSecsEvent("_GS12F01S") != 0){
		r = FALSE;
	}
	enum{
		WaitCnt =3,
	};
	//�}���`���b�N�҂�
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvS12F2Recv;
	ppObjects[1]	= pEvS12F6Recv;
	ppObjects[2]	= pEvS12F10Recv;
	CMultiLock	M(ppObjects,WaitCnt);
	//
	int timeout = 20000;
	while(r){
		if(this->getCtrlState() > eHostOffline){		//Online Remote �̂Ƃ��̂ݑ҂�
			// ��x�X���b�h�N������ƁA�v���O�����I���܂ő҂�������B
			// �ŏI�I�ɂ�ItemGet��T3�^�C���A�E�g���Z�b�g����
			int i = M.Lock(timeout+1000, FALSE);
			M.Unlock();
			if(i == WAIT_TIMEOUT){
				// T3�^�C���A�E�g
				r = FALSE;
				break;
			}else{
				i -= WAIT_OBJECT_0;		// �ǂ�����C�x���g�������̂�
				if (0 == i) {
					//����
					r = TRUE;
					continue;
				} else if (1 == i) {
					//����
					r = TRUE;
					continue;
				} else if (2 == i) {
					//����
					r = TRUE;
					break;
				} else if (3 == i) {
					//�r����~(���f)
					r = FALSE;
					break;
				}else{
					r = FALSE;
					break;
				}
			}
		}
	}
	return(r);
}

//S12F2��M(Map Set-up Data)
BOOL DlgSG300::RecvS12F2()
{
	BOOL r = TRUE;

	unsigned int recv_sdack = this->GetItemDataSingleUnsignInt("Item_SDACK", "U1");

	//�f�[�^�`�F�b�N
	if(recv_sdack != 0){
		r = FALSE;
	}
	
	//�ʐM�װ���A�װ��ʕ\��(S)
	if(r == FALSE){
		MapCtrl.bReqMap = FALSE;
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	}
	if(r == TRUE){
		//S12F5 ���M
		this->PutSecsItemSingleUnsignInt("SendStrLen_4", MapCtrl.pMapData->MID.GetLength(), "U4");	//MID
		this->PutSecsItemSingleASCII("Item_MID", MapCtrl.pMapData->MID);
		this->PutSecsItemSingleBIN("Item_IDTYP", 0);												//IDTYP
		this->PutSecsItemSingleBIN("Item_MAPFT", 1);												//MAPFT

		if(m_hXComSecs.PutSecsEvent("_GS12F05S") != 0){
			r = FALSE;
			if (MapCtrl.bReqMap) {
			MapCtrl.bReqMap = FALSE;
			MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_Send;
			MapCtrl.EvReqMapEnd.SetEvent();
			}
		}else{
		pEvS12F2Recv->SetEvent();
		}
	}
	return(r);
}

BOOL DlgSG300::SendS12F5()
{
	BOOL r = TRUE;
	return(r);
}

BOOL DlgSG300::RecvS12F6()
{
	BOOL r = TRUE;

	unsigned int recv_grnt1 = this->GetItemDataSingleUnsignInt("Item_GRNT1", "U1");

	//�f�[�^�`�F�b�N
	if(recv_grnt1 != 0){
		r = FALSE;
	}
	if(r == FALSE){
		MapCtrl.bReqMap = FALSE;
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	}
	if(r == TRUE){
	//S12F9 Map Data Send Type2
		this->PutSecsItemSingleUnsignInt("SendStrLen_4", MapCtrl.pMapData->MID.GetLength(), "U4");		//MID
		this->PutSecsItemSingleASCII("Item_MID", MapCtrl.pMapData->MID);
		this->PutSecsItemSingleBIN("Item_IDTYP", 0);													//IDTYP
		this->PutSecsItemSingleUnsignInt("SendStrLen_5", MapCtrl.pMapData->BINLT.GetLength(), "U4");	//BINLT
		this->PutSecsItemSingleASCII("Item_BINLT", MapCtrl.pMapData->BINLT);
		//���M
		if(m_hXComSecs.PutSecsEvent("_GS12F09S") != 0){
			r = FALSE;
			if (MapCtrl.bReqMap) {
			MapCtrl.bReqMap = FALSE;
			MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_Send;
			MapCtrl.EvReqMapEnd.SetEvent();
			}
		}else{
		pEvS12F6Recv->SetEvent();
		}
	}
	MapCtrl.EvReqMapEnd.SetEvent();
	return(r);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ϯ���ް��m�F ����2
//S12F9
BOOL DlgSG300::SendS12F9()
{
	BOOL r = TRUE;
	return(r);
}

//S12F10��M(Map Data)
BOOL DlgSG300::RecvS12F10()
{
	BOOL r = TRUE;
	unsigned int recv_mdack = this->GetItemDataSingleUnsignInt("Item_MDACK", "U1");

	//�f�[�^�`�F�b�N
	if(recv_mdack != 0){
		r = FALSE;
	}
	
	//�ʐM�װ���A�װ��ʕ\��(S)
	if(r == FALSE){
		MapCtrl.bReqMap = FALSE;
		MapCtrl.iReqMapErr = MapCtrlData::eReqMapErr_NGData;
	}
	return(r);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// #MO20131130 [�ǉ�]SECSϯ��ݸ�
// S12F19 ϯ�ߴװ��M
BOOL DlgSG300::RecvS12F19()
{
	BOOL r = TRUE;
	return(r);
}

// S12F19 ϯ�ߴװ���M
BOOL DlgSG300::SendS12F19(int maper, BYTE datlc)
{
	BOOL r = TRUE;

	this->PutSecsItemSingleBIN("Item_MAPER", maper);
	this->PutSecsItemSingleUnsignInt("Item_DATLC", datlc, "U1");
	if (m_hXComSecs.PutSecsEvent("_GS12F19S") != 0) {
		r = FALSE;
	}
	return(r);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ϯ�߃`�b�v�ړ����M
//S6F81

BOOL DlgSG300::MapChipMoveSend(int cx, int cy)
{
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (pSecsTDS) {
//			r = pSecsTDS->MapChipMoveSend(cx, cy);
//		}
//		return(r);
//	}
// #KS20130417-01(E)
	BOOL r = TRUE;
	this->PutSecsItem4ByteInteger("Item_MOVEXY", cx, 1, 0);
	this->PutSecsItem4ByteInteger("Item_MOVEXY", cy, 2, 0);
	
	//���M
	if(m_hXComSecs.PutSecsEvent("_GS06F81S") != 0){
		;
//		MapSendMessage(3);		//NG
	}
	return(r);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ϯ�������߯��@���M
//S6F83

BOOL DlgSG300::MapChipPicked(int cx, int cy, unsigned char code)
{
// #KS20130417-01(S) [�ǉ�]GEM�Q�|�[�g��
//	if (2 == ID) {
//		BOOL r = FALSE;
//		if (pSecsTDS) {
//			r = pSecsTDS->MapChipPicked(cx, cy, code);
//		}
//		return(r);
//	}
// #KS20130417-01(E)
	BOOL r = TRUE;
	this->PutSecsItem4ByteInteger("Item_PICKXY", cx, 1, 0);
	this->PutSecsItem4ByteInteger("Item_PICKXY", cy, 2, 0);
	this->PutSecsItemSingleASCII("Item_BIN", code);

	//���M
	if(m_hXComSecs.PutSecsEvent("_GS06F83S") != 0){
		;
//		MapSendMessage(3);		//NG
	}
	return(r);
}
// #KS20130415-01(E)


BOOL DlgSG300::ForceCompleteByOPEvent(int portNo){
	BOOL r = TRUE;
	long	ret;
	CSingleLock W(&this->CarrierSema, TRUE);
	::Sleep(500);
	this->PutPortNo((unsigned int)portNo);	// ���ꂩ��o������Ă�PortID����������
	if((ret = m_hXComSecs.SndEvntInf("ForceCompleteByOP",0)) != 0){
		r = FALSE;
	}
	return r;
}

BOOL DlgSG300::ForceCompleteByEQPEvent()
{
	BOOL r = TRUE;
	long	ret;
//	this->PutPortNo((unsigned int)portNo);	// ���ꂩ��o������Ă�PortID����������
	if((ret = m_hXComSecs.SndEvntInf("ForceCompleteByEQP",0)) != 0){
		r = FALSE;
	}
	return r;
}

void DlgSG300::NotToBeAbleToRelease()
{
	for(int i=0; i<NO_OF_TOP_PORT; i++){
		this->beAbleToRelease[i] = false;
	}
}

void DlgSG300::SetAbleToRelease(int portNo)
{
	TRACE("[SECS_DEBUG] SetAbleToRelease portNo = %d\n",portNo);
	this->beAbleToRelease[portNo - MIN_TOP_PORT_NO] = true;

}

bool DlgSG300::GetAbleToRelease(int portNo)
{
	return(this->beAbleToRelease[portNo - MIN_TOP_PORT_NO]);
}

// #DDT160625-02 (S)
void DlgSG300::SetAbleToAutoRun(int portNo, bool isAble)
{
	TRACE("[SECS_DEBUG] beAbleToAutoRun portNo = %d\n",portNo);
	this->beAbleToAutoRun[portNo - MIN_TOP_PORT_NO] = isAble;

}

bool DlgSG300::GetAbleToAutoRun(int portNo)
{
	return(this->beAbleToAutoRun[portNo - MIN_TOP_PORT_NO]);
}
// #DDT160625-02 (E)

BOOL DlgSG300::ReadTopCarrierID(int portNo, CString sCarrierId)
{
	BOOL r = TRUE;
	long	ret;
	VARIANT	vCarrierId;
	VariantInit(&vCarrierId);
	vCarrierId.vt = VT_BSTR;
	vCarrierId.bstrVal = sCarrierId.AllocSysString();
	
	TRACE("[SECS_DEBUG] DlgSG300::ReadTopCarrierID, portNo = %d, sCarrierId = %s \n", portNo, sCarrierId);

	// CarrierIDReadEvent
	CEvent EvFinReadCarrierID;
	CEvent EvFailReadCarrierID;
	
	// Reset event�B
	EvFinReadCarrierID.ResetEvent();
	EvFailReadCarrierID.ResetEvent();
	
	// #KI130514-01
	// �����X���b�h�������ɃA�N�Z�X���Ȃ��悤�ɃZ�}�t�H��������
	CSingleLock W(&this->CarrierSema);
	W.Lock();
	// Set up event
	this->pEvFinInfoTopCarrierIdRead[portNo - MIN_TOP_PORT_NO]	= &EvFinReadCarrierID;
	this->pEvFailInfoTopCarrierIdRead[portNo - MIN_TOP_PORT_NO]	= &EvFailReadCarrierID;
	pEvStopWaitingSecsT->ResetEvent();
	::Sleep(500);
	this->PutPortNo((unsigned int)portNo);

	// #TT160607-03(S) Err_Dlg300_06�G���[�̂ł錴���̒����pLog�ǉ�
	CString msg;
	msg.Format("SoftComGem300 ReadTopCarrierID() portNo=%d sCarrierId=%s", portNo, sCarrierId);
	this->err.LogSaveNFL(msg);
	// #TT160607-03(E)
	///////////////////////////////////
	//
	// Make request to Host to verify carrier ID
	//
	if((ret = m_hCsg300cms.ReadCarrierId(portNo, vCarrierId, 1)) != 0){
		r = FALSE;
#if TFC6000SPEC
		this->err.PutError(Err_Dlg300_06);
		this->ErrorLogOut(__LINE__,ret);
#endif
		W.Unlock();	// #KI130514-01
		return r;
	}
	VariantClear(&vCarrierId);
	if(r){
		::Sleep(500);
	}	
	W.Unlock();	// #KI130514-01
	enum{
		WaitCnt		= 3,
	};
	
	//
	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinInfoTopCarrierIdRead[portNo - MIN_TOP_PORT_NO];		// VERIFICATION_OK
	ppObjects[1]	= pEvFailInfoTopCarrierIdRead[portNo - MIN_TOP_PORT_NO];		// VERIFICATION_NG
	ppObjects[2]	= pEvStopWaitingSecsT;		// Interrupt
	CMultiLock	M(ppObjects,WaitCnt);
	//
	if(this->getCtrlState() == eOnlineRemote){		//State is Online Remote 
		int i = M.Lock(INFINITE, FALSE);
		M.Unlock();
		i -= WAIT_OBJECT_0;		// To determine where event come from
		if (0 == i) {
			// Success
			r = TRUE;
		} else if (1 == i) {
			// False
			r = FALSE;
			this->err.PutError(Err_TopReadIDCanceled);
		} else if (2 == i) {
			//Stop by interrupt
			r = FALSE;
		}
	}else{	//Online Remote�ȊO�̍ۂ͑҂����ɐ�ɐi�߂�悤�ɂ���
			//����_CARRIERIDSTATUS:2   ID Verification OK 
		this->setAttDataSingleUINT1("Carrier", sCarrierId, "_CARRIERIDSTATUS", 2);
	}
	// #KI160218-03(S)
//	if(r && portNo >= eTopPortNo5){
//		VariantInit(&vCarrierId);
//		vCarrierId.vt = VT_BSTR;
//		vCarrierId.bstrVal = sCarrierId.AllocSysString();
//		if((ret = m_hCsg300cms.ChangeCarrierAccessState(vCarrierId, /*1*/eInAccess)) != 0){
//			r = FALSE;
//		}
//	}
	// #KI160218-03(E)
	{
#if !Release
		CString msg;
		msg.Format("ReadTopCarrierID(port%d) finished r = %d\n", portNo, r);
		if(!r){
			this->err.LogSaveNFL(msg);
		}
		TRACE(msg);
#endif
	}
	{
		long	ret;
		VARIANT vCarrierIdList;
		long	Count;
		VariantInit(&vCarrierIdList);
		if((ret = m_hCsg300cms.GetAllCarrierId(&vCarrierIdList, &Count)) != 0){
			VariantClear(&vCarrierIdList);
//			r = FALSE;
//			return r;
		}
#if !Release
		if(Count > 0){
			TRACE("ReadTopCarrierID��Carrier is %d\n", Count);
		}
#endif
	}
	
	//Reset pointer event
	this->pEvFinInfoTopCarrierIdRead[portNo - MIN_TOP_PORT_NO]			= NULL;
	this->pEvFailInfoTopCarrierIdRead[portNo - MIN_TOP_PORT_NO]			= NULL;
	
	return r;
}
DlgSG300::Receive_TopCJCreateAction(int portNo) 
{
	BOOL r = TRUE;

	// Wait for CJCreate from host
	int cnt = 0;
		
	TRACE("[SECS_DEBUG] DlgSG300::Receive_TopCJCreateActionStart(port%d) \n", portNo);

	enum{
		ObjectMax = 2,
	};
// #TN130521
	this->EvTopCJCreate.ResetEvent();	// #KI130423-04
	CSyncObject *ppObjects[ObjectMax];
//	ppObjects[0] = pEvTopCJCreate[portNo - MIN_TOP_PORT_NO];	// #KI130423-04
	ppObjects[0] = &this->EvTopCJCreate;	// #KI130423-04
	ppObjects[1] = pEvStopWaitingSecsT;

	CMultiLock M(ppObjects, ObjectMax);		

	for(;;){
		int	i = M.Lock(INFINITE, FALSE);
		M.Unlock();
		i -= WAIT_OBJECT_0;

		if (0 == i) {
			r = TRUE;
			break;
		} else if (1 == i) {
			r = FALSE;
			break;
		} else {
			
		}
	}
//	pEvTopCJCreate[portNo - MIN_TOP_PORT_NO]	= NULL;
	TRACE("[SECS_DEBUG] DlgSG300::Receive_TopCJCreateActionEnd(port%d) r = %d\n", portNo, r);

	return r;
}

DlgSG300::Receive_BottomCJCreateAction() 
{
	BOOL r = TRUE;

	// Wait for CJCreate from host
	int cnt = 0;
		
	TRACE("[SECS_DEBUG] DlgSG300::Receive_BottomCJCreateActionStart \n");

	enum{
		ObjectMax = 2,
	};
	this->EvBottomCJCreate.ResetEvent();	// #KI130423-04
	CSyncObject *ppObjects[ObjectMax];
//	ppObjects[0] = pEvBottomCJCreate[portNo - MIN_BOTTOM_PORT_NO];		// #KI130523-04
	ppObjects[0] = &this->EvBottomCJCreate;// #KI130523-04
	ppObjects[1] = pEvStopWaitingSecsB;	// #KI130523-04

	CMultiLock M(ppObjects, ObjectMax);		

	for(;;){
		int	i = M.Lock(INFINITE, FALSE);
		M.Unlock();
		i -= WAIT_OBJECT_0;

		if (0 == i) {
			r = TRUE;
			break;
		} else if (1 == i) {
			r = FALSE;
			break;
		} else {
			
		}
	}
//	pEvBottomCJCreate[portNo - MIN_BOTTOM_PORT_NO]	= NULL;
	TRACE("[SECS_DEBUG] DlgSG300::Receive_BottomCJCreateActionEnd r = %d\n", r);

	return r;
}


BOOL DlgSG300::CreatePrJob(CString prJobId)
{
	BOOL	r = TRUE;
	long	cnt = 0;
	VARIANT vPrJobId;

	VariantInit(&vPrJobId);

	vPrJobId.vt = VT_BSTR;
	vPrJobId.bstrVal = prJobId.AllocSysString();
// #TN130515-01
//	if (!m_hCsg300pjm.CreatePRJob(vPrJobId)) {
	long ret = m_hCsg300pjm.CreatePRJob(vPrJobId);
	if(!ret){
		// Do nothing
	} else {
		TRACE("[SECS_DEBUG] DlgSG300::CreatePrJob() failed, prJobId = %s, ret = 0x%0X \n", prJobId, ret);
		// ������d���͔������Ȃ��̂ŁA��U�폜���č쐬�ł���Ȃ�A��������B
		r = DeletePrJob(prJobId);
		r = FALSE;
		::Sleep(100);
#if 0
		// Re-Create
		if(r){
			ret = m_hCsg300pjm.CreatePRJob(vPrJobId);
		}
		if(!ret){
			// Do nothing
		}else{
			CString buf;
			buf.Format("SoftComGem300 CreatePRJob Error ret=0x%08X, JobID=%s", ret, prJobId);
			this->err.LogSaveNFL(buf);
			this->err.PutError(Err_CreatePJFailed);
			r = FALSE;
		}
#endif
	}

	VariantClear(&vPrJobId);

	TRACE("[SECS_DEBUG] DlgSG300::CreatePrJob(), prJobId = %s, r = %d \n", prJobId, r);

	return r;
}

BOOL DlgSG300::CreateCtrlJob(CString ctrlJobId)
{
	BOOL	r = TRUE;
	long	cnt = 0;
	VARIANT vCtrlJobId;

	VariantInit(&vCtrlJobId);

	vCtrlJobId.vt = VT_BSTR;
	vCtrlJobId.bstrVal = ctrlJobId.AllocSysString();

	//Create PR
// #TN130515-01
//	if (!m_hCsg300cjm.CreateCtrlJob(vCtrlJobId)) {
	long ret = m_hCsg300cjm.CreateCtrlJob(vCtrlJobId);
	if (!ret) {
		// Do nothing
	} else {
		TRACE("[SECS_DEBUG] DlgSG300::CreateCtrlJob() failed, ctrlJobId = %s, ret = 0x%0X \n", ctrlJobId, ret);
		// ������d���͔������Ȃ��̂ŁA��U�폜���č쐬�ł���Ȃ�A��������B
		r = DeleteCtrlJob(ctrlJobId);
		::Sleep(100);
		// Re-Create
		if(r){
			ret = m_hCsg300cjm.CreateCtrlJob(vCtrlJobId);
		}
		if(!ret){
			// Do nothing
		}else{
			CString buf;
			buf.Format("SoftComGem300 CreateCtrlJob Error ret=0x%08X, JobID=%s", ret, ctrlJobId);
			this->err.LogSaveNFL(buf);
			r = FALSE;
			// TODO DuyND
//			this->err.PutError(Err_CreateCJFailed);
		}
	}

	VariantClear(&vCtrlJobId);

	TRACE("[SECS_DEBUG] DlgSG300::CreateCtrlJob(), ctrlJobId = %s, r = %d \n", ctrlJobId, r);

	return r;
}

BOOL	DlgSG300::GetPrJob_KeyVal(CString prJobId, CString& keyValue, int portNo)// #KI150323-01
{
	BOOL	r = TRUE;
	CString objType;
	LPCSTR	attr_name;
	short	item_type;
	long	element;
	VARIANT	vPrJobId;
	VARIANT vObjType;
	VARIANT	vData;

	// Get recipe num
	VariantInit(&vData);
	attr_name = "_RCPPARVAL_N1";
//	attr_name = "_RECIPE_NUM";
	
	// Set object type value
	VariantInit(&vObjType);
	vObjType.vt			= VT_BSTR;
	objType				= "ProcessJob";
	vObjType.bstrVal	= objType.AllocSysString();

	// Set process job ID
	VariantInit(&vPrJobId);
	vPrJobId.vt = VT_BSTR;
	vPrJobId.bstrVal = prJobId.AllocSysString();
	// Get key value
	if (!m_hCsg300pjm.GetAttrData(vObjType, vPrJobId, attr_name, &vData, &item_type, &element, 1, 0, 0, 0)) {
		if (vData.vt == VT_BSTR) {
			keyValue = vData.bstrVal;
		}
	} else {
		r = FALSE;
	}

	return r;
}

BOOL	DlgSG300::GetPrJob_BinVal(CString prJobId, int slotNo, CString& binVal, CString& binCnt)
{
	BOOL	r = TRUE;
	CString objType;
	LPCSTR	attr_name;
	short	item_type;
	long	ret, element;
	VARIANT	vPrJobId;
	VARIANT vObjType;
	VARIANT	vData;
	int cnt = -1;
	//Init value
	VariantInit(&vData);
	// Set object type value
	VariantInit(&vObjType);
	vObjType.vt			= VT_BSTR;
	objType				= "ProcessJob";
	vObjType.bstrVal	=  objType.AllocSysString();
	// Set process job ID
	VariantInit(&vPrJobId);
	vPrJobId.vt = VT_BSTR;
	vPrJobId.bstrVal = prJobId.AllocSysString();
	// Get slot no
	//Init value
	VariantInit(&vData);
	attr_name = "_SLOT_NUM_N1";
	ret = m_hCsg300pjm.GetAttrData(vObjType, vPrJobId, attr_name, &vData, &item_type, &element, 1, 0, 0, 0); 
	if (!ret) {
		int slotVal;
		int noOfSlot;
		noOfSlot = vData.intVal;
		// Find target slot value
		for (int i = 0; i < noOfSlot; i++) {
			VariantInit(&vData);
			attr_name = "_SLOTID_N1N2";
			ret = m_hCsg300pjm.GetAttrData(vObjType, vPrJobId, attr_name, &vData, &item_type, &element, 1, i + 1, 0, 0);
			if (!ret) {
				slotVal = vData.uintVal;
				if (slotVal == slotNo) {
					cnt = i;
					break;
				}
			} else {
				r = FALSE;
				break;
			}
		}
		// Get bin value
		VariantInit(&vData);
		attr_name = "_BIN_VALUE";
		if (!m_hCsg300pjm.GetAttrData(vObjType, vPrJobId, attr_name, &vData, &item_type, &element, cnt + 1, 0, 0, 0)) {
			if (vData.vt == VT_BSTR) {
				binVal = vData.bstrVal;
			} else {
				// #KI151004-01(S)
				// �b��
				vData.vt = VT_BSTR;
				binVal		= "#";
				// #KI151004-01E)
			}
			if (r) {
				// Get bin count
				VariantInit(&vData);
				attr_name = "_BIN_COUNT";
				// Get bin value
				if (!m_hCsg300pjm.GetAttrData(vObjType, vPrJobId, attr_name, &vData, &item_type, &element, cnt + 1, 0, 0, 0)) {
					if (vData.vt == VT_BSTR) {
						binCnt = vData.bstrVal;
					} else {
						// #KI151004-01(S)
						// �b��
						vData.vt = VT_BSTR;
						binVal		= "0";
						// #KI151004-01(E)
					}
				} else {
					// #KI151004-01(S)
					// �b��
					vData.vt = VT_BSTR;
					binVal		= "0";
					// #KI151004-01(E)
				}
			}
		} else {
			// #KI151004-01(S)
			// �b��
			vData.vt = VT_BSTR;
			binVal		= "#";
			// #KI151004-01(E)
		}
	} else {
		r = FALSE;
	}

	return r;
}

BOOL DlgSG300::GetCtrlJob_State(CString ctrlJobId, short& state)
{
	BOOL r = TRUE;
	VARIANT vCtrlJobId; 

	long ret;
	VariantInit(&vCtrlJobId); 
	vCtrlJobId.vt = VT_BSTR;
	vCtrlJobId.bstrVal = ctrlJobId.AllocSysString(); 
	ret = m_hCsg300cjm.GetCtrlJobState(vCtrlJobId, &state);
	if (ret) {
		r = FALSE;
		CString buf;
		buf.Format("SoftComGem300 GetCtrlJob_State Error ret=0x%08X, state=%d", ret, state);
		this->err.LogSaveNFL(buf);
	}
	
	VariantClear(&vCtrlJobId); 

	TRACE("[SECS_DEBUG] DlgSG300::GetCtrlJob_State(), ctrlJobId = %s, state = %d, r = %d \n",ctrlJobId, state, r);

	return r;
}

BOOL DlgSG300::SetCtrlJob_State(CString ctrlJobId, short state, short portNo)
{
	BOOL r = TRUE;
	VARIANT vCtrlJobId; 

	VariantInit(&vCtrlJobId); 
	
	vCtrlJobId.vt = VT_BSTR; 
	vCtrlJobId.bstrVal = ctrlJobId.AllocSysString(); 
		
	CSingleLock W(&this->CarrierSema, TRUE);
	::Sleep(500);

    long ret = m_hCsg300cjm.ChangeCtrlJobState(vCtrlJobId, state);
	if(!ret){
		// Do nothing
	}else{
		CString buf;
		buf.Format("SoftComGem300 SetCtrlJob_State Error ret=0x%08X, state=%d, ID:%s", ret, state, ctrlJobId);
		this->err.LogSaveNFL(buf);
		r = FALSE;
	}
	VariantClear(&vCtrlJobId); 

	TRACE("[SECS_DEBUG] DlgSG300::SetCtrlJob_State(), ctrlJobId = %s, state = %d, r = %d\n",ctrlJobId, state, r);

	return r;
}

BOOL DlgSG300::GetPrJob_State(CString prJobId, short& state)
{
	BOOL r = TRUE;
	VARIANT vObjId;
	CString ObjId;
	VariantInit(&vObjId);

	vObjId.vt = VT_BSTR;
	vObjId.bstrVal = prJobId.AllocSysString();
	
	if (m_hCsg300pjm.GetPRJobState(vObjId, &state)) {
		r = FALSE;
	}

	VariantClear(&vObjId);

	TRACE("[SECS_DEBUG] DlgSG300::GetPrJob_State(), prJobId = %s, state = %d r = %d \n", prJobId, state, r);

	return r;
}

BOOL DlgSG300::SetPrJob_State(CString prJobId, short state, short portNo)
{
	BOOL r = TRUE;
	VARIANT vPRJobId;

	VariantInit(&vPRJobId);
	
	vPRJobId.vt = VT_BSTR;
	vPRJobId.bstrVal = prJobId.AllocSysString();
	CSingleLock W(&this->CarrierSema, TRUE);
	::Sleep(500);
	this->PutPortNo((unsigned int)portNo);	// ���ꂩ��o������Ă�PortID����������
	long ret;
	
	//##QuyetVK 20130704 SECS (S)
	//Get current state
	short currState;
	ret = m_hCsg300pjm.GetPRJobState(vPRJobId, &currState); 
	if (!ret) {
		if (currState == state) {
			return TRUE;
		}
	}
	//##QuyetVK 20130704 SECS (E)

	ret = m_hCsg300pjm.ChangePRJobState(vPRJobId, state);
	if(!ret){
		// Do nothing
	}else{
		CString buf;
		buf.Format("SoftComGem300 SetPrJob_State Error ret=0x%08X, state=%d", ret, state);
		this->err.LogSaveNFL(buf);
		TRACE(buf+"\n");
		r = FALSE;
	}

	VariantClear(&vPRJobId);

	TRACE("[SECS_DEBUG] DlgSG300::SetPrJob_State(), prJobId = %s, state = %d r = %d \n", prJobId, state, r);

	return r;
}

BOOL DlgSG300::GetCtrlJob_PrJobList(CString ctrlJobId, CString* prJobList, int& prJobNo)
{
	BOOL	r = TRUE;
	long	ret, element;
	CString	ObjType;
	LPCSTR	attr_name;
	short	item_type;
	VARIANT	vObjType;
	VARIANT	vObjId;
	VARIANT	vData;
//	CSingleLock W(&this->CJPJSema);
//	W.Lock();

	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&vData);

	ObjType = "ControlJob";
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = ObjType.AllocSysString();
	
	vObjId.vt = VT_BSTR;
	vObjId.bstrVal = ctrlJobId.AllocSysString();

	
	// Get no of prJob
	attr_name = "_PROCCTRLSPEC_NUM";
	
	ret = m_hCsg300cjm.GetAttrData(vObjType, vObjId, attr_name, &vData, &item_type, &element, 0, 0, 0, 0); 
	
	// Get all ctrl job
	if (!ret) {
		prJobNo = vData.bVal;
		attr_name = "_PROCCTRLSPEC_PRJOBID_N1";


		for (int i = 0; i < prJobNo; i++) {
			VariantInit(&vData);

			ret = m_hCsg300cjm.GetAttrData(vObjType, vObjId, attr_name, &vData, &item_type, &element, i + 1, 0, 0, 0);

			if (!ret) {
				prJobList[i] = vData.bstrVal;
			} else {
				TRACE("[SECS_DEBUG] GetCtrlJob_PrJobList(%s) m_hCsg300cjm.GetAttrData(%d) ret=0x%0x\n",ctrlJobId,i,ret);
				r = FALSE;
				break;
			}
		}
	} else {
		TRACE("[SECS_DEBUG] GetCtrlJob_PrJobList(%s) m_hCsg300cjm.GetAttrData() ret=0x%0x\n",ctrlJobId,ret);
		r = FALSE;
	}

	VariantClear(&vObjType);
	VariantClear(&vObjId);
	VariantClear(&vData);
//	W.Unlock();
	return r;
}

int	DlgSG300::GetCtrlJob_PortNo(CString ctrlJobId)
{
	CString	ObjType;
	LPCSTR	attr_name;
	short	item_type;
	VARIANT	vObjType;
	VARIANT	vObjId;
	VARIANT	vData;
	int		portNo = MAX_PORT_NO;
	long	element;

	// Init variant variable
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&vData);

	// Init value
	ObjType				= "ControlJob";
	vObjType.vt			= VT_BSTR;
	vObjType.bstrVal	= ObjType.AllocSysString();

	vObjId.vt		= VT_BSTR;
	vObjId.bstrVal	= ctrlJobId.AllocSysString();
	
	attr_name = "_INPUT_CARRIERID_N1";
	item_type = ITEM_TYPE__ASCII;

	if (!m_hCsg300cjm.GetAttrData(vObjType, vObjId, attr_name, &vData, &item_type, &element, 1, 0, 0, 0)) {
		for (int i = 1; i < ePortNoMax/*7*/; i++) {
			if (this->carrierId[i] == vData.bstrVal) {
//				portNo = i + 1;			
				portNo = i;
				break;
			}
		}
	}

	return portNo;
}

BOOL DlgSG300::GetPrJob_SlotNoList(CString proJobId, int* slotNoList, int& slotNo)
{
	BOOL r = TRUE;
	long ret, element;

	CString	ObjType;
	LPCSTR	attr_name;
	short	item_type;
	VARIANT	vObjType;
	VARIANT	vObjId;
	VARIANT	vData;
//	CSingleLock W(&this->CJPJSema);
//	W.Lock();

	// Init variant variable
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&vData);

	// Init value
	ObjType				= "ProcessJob";
	vObjType.vt			= VT_BSTR;
	vObjType.bstrVal	= ObjType.AllocSysString();

	vObjId.vt		= VT_BSTR;
	vObjId.bstrVal	= proJobId.AllocSysString();
	
	attr_name = "_SLOT_NUM_N1";

	ret = m_hCsg300pjm.GetAttrData(vObjType, vObjId, attr_name, &vData, &item_type, &element, 1, 0, 0, 0); 

	if (!ret) {
		slotNo = vData.intVal;

		attr_name = "_SLOTID_N1N2";

		for (int i = 0; i < slotNo; i++) {
			VariantInit(&vData);
			
			ret = m_hCsg300pjm.GetAttrData(vObjType, vObjId, attr_name, &vData, &item_type, &element, 1, i + 1, 0, 0);  
			if (!ret) {
				slotNoList[i] = vData.uintVal;
			} else {
				TRACE("[SECS_DEBUG] GetPrJob_SlotNoList(%s) m_hCsg300cjm.GetAttrData(%d) ret=0x%0x\n",proJobId,i,ret);
				r = FALSE;
				break;
			}

		}
	} else {
		TRACE("[SECS_DEBUG] GetPrJob_SlotNoList(%s) m_hCsg300cjm.GetAttrData() ret=0x%0x\n",proJobId,ret);
		r = FALSE;
	}
//	W.Unlock();
	return r;
}

CString	DlgSG300::GetPrJob_PPID(CString prJobId)
{
	CString PPID = "";
	CString	ObjType;
	LPCSTR	attr_name;
	short	item_type;
	VARIANT	vObjType;
	VARIANT	vObjId;
	VARIANT	vData;
	int		slotNo = 0;
	long	ret, element;

	// Init variant variable
	VariantInit(&vObjType);
	VariantInit(&vObjId);
	VariantInit(&vData);

	// Init value
	ObjType				= "ProcessJob";
	vObjType.vt			= VT_BSTR;
	vObjType.bstrVal	= ObjType.AllocSysString();

	vObjId.vt		= VT_BSTR;
	vObjId.bstrVal	= prJobId.AllocSysString();
	
	attr_name = "_RCPSPEC";

	ret = m_hCsg300pjm.GetAttrData(vObjType, vObjId, attr_name, &vData, &item_type, &element, 0, 0, 0, 0); 

//	if (!ret) {
	if (!ret && VT_BSTR == vData.vt) {
		PPID = vData.bstrVal;
	}

	return PPID;
}

void DlgSG300::RecvS16F15(bool isBottom)
{
	long	ret;			// Hold result
	BOOL	r = TRUE;
	VARIANT	vtData;			// Hold recived data
	VARIANT v;				// Hold temporary variant to put to database
	VARIANT vObjType;		// Object type
	int		prJobNo = 0;	// Hold number of process jobs
	short	item_type;		// Hold temporary item type
	long	element;		// Hold temporary item element
	CString objType;		// Object type
	CString ttmp;			// Hold temporary value
	CString	attr_name;		// Attribute name
	CString prJobId = "";	// Process job Id
	int		list_cnt = 0;	// Store no of element of list
	// #KI141218-01(S)
	CSingleLock W0(&this->CarrierSema, TRUE);
	::Sleep(100);
	// #KI141218-01(E)
	CSingleLock W(&this->CJPJSema);
	W.Lock();
// #TN130515-01
	//int ErrList[]=0;		//##QuyetVK 20130905 SECS
	int ErrListCnt = 0;		//Store number of error PJs ##QuyetVK 20130905 SECS
	int ErrList[25];		//Store list of error PJs ##QuyetVK 20130905 SECS
	//Initialize data
	VariantInit(&vtData);
	VariantInit(&vObjType);

	//Set object type data
	objType = "ProcessJob";
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = objType.AllocSysString();

	//Get Name dataID
	if (!(m_hXComSecs.GetItemData("Itm_DATAID2", &vtData, &item_type, &element, 0, 0, 0, 0))) {
		//Todo
	} else {
		r = FALSE;
	}

	if (r) {
		//Clear data
		VariantClear( &vtData );

		//Get number of process job will be created
		if (m_hXComSecs.GetItemData("V2", &vtData, &item_type, &element, 0, 0, 0, 0)) {
			r = FALSE;
		} else {
			prJobNo = (int)vtData.iVal;
		}
	}
	
	if (r) {
		VARIANT vPrJobId;
		int carrierNo = 0;
		int slotNo = 0;

		VariantInit(&vPrJobId);

		for(int i = 0; i < prJobNo; i++) {
			VariantClear(&vtData );
			VariantClear(&vPrJobId);

			vPrJobId.vt = VT_BSTR;
			
			////////////////////////////////////////////
			//Get ProcessJobID
			///////////////////////////////////////////
			ret = m_hXComSecs.GetItemData("Itm_PRJOBID_N2_2", &vtData, &item_type, &element, i + 1, 0, 0, 0);
			if ((!ret) && (vtData.vt == VT_BSTR)) {
				prJobId = vtData.bstrVal;
				vPrJobId.bstrVal = prJobId.AllocSysString();
				// #KI141224-01(S)
				// If this PJ is existed (TSDV's new idea)
//				short state = 0x0;
//				ret = m_hCsg300pjm.GetPRJobState(vPrJobId, &state);
//				if(!ret) {
//					// Reset Slot data for PJ
//					VariantClear(&vtData);
//					vtData.vt = VT_UI1;
//					for (int j = 0; j < eWaferNumberMax; j++) {
//						attr_name	= "_SLOTID_N1N2";
//						ret = m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, ITEM_TYPE__UINT1, 1, 1, j + 1, 0, 0);
//						if (ret) {
//							r = FALSE;
//							break;
//						}
//					}
//				} else {
					//Create PJ
					r = CreatePrJob(prJobId);
//				}
				// #KI141224-01(E)
				if (r) {
					// Do nothing
				} else {
					::Sleep(1000);
					r = CreatePrJob(prJobId);
// #TN130515-01		
//					ErrList++;
					if(!r) {
						r = FALSE;
//						break;
					}
				}
			} else {
				r = FALSE;
//				break;
			}
			
			////////////////////////////////////////////
			//Get MF
			///////////////////////////////////////////
			VariantClear(&vtData);
			VariantClear(&v);
			
			if (r) {
				ret = m_hXComSecs.GetItemData("Itm_MF_BW", &vtData, &item_type, &element, 0, 0, 0, 0);
				if (!ret) {
					attr_name	= "_MF";
					
					// Save to database
					if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, 0, 0, 0, 0, 0)) {
						r = FALSE;
					}
				} else {
					r = FALSE;
				}
				
				VariantClear(&vtData);
				VariantClear(&v);			
			}

			////////////////////////////////////////////
			//Get PRMtlNameList
			///////////////////////////////////////////
			
			if (r) {
				// Get & save carrierID
				ret = m_hXComSecs.GetItemData("Itm_CARRIERID_N2", &vtData, &item_type, &element, i + 1, 0, 0, 0);
				if((!ret) && (vtData.vt == VT_BSTR)) {
					attr_name	= "_CARRIERID_N1";
					////////////////////////////
					//
					// Check Port from Carrier
					//
					bool found = false;
					for (int k = 1; k < ePortNoMax/*-1*/; k++) {
						if (vtData.bstrVal == this->carrierId[k]) {
							found = true;
							if ((MIN_TOP_PORT_NO <= k) && (MAX_TOP_PORT_NO >= k)) {
								// if still not waiting
								CString buf;
								buf.Format("RecvS16F15-1 found carrierID(%s) port(%d)\n", this->carrierId[k], k);
								this->err.LogSaveNFL(buf);
							} else {
								CString buf;
								buf.Format("RecvS16F15-2 found carrierID(%s) port(%d)\n", this->carrierId[k], k);
								this->err.LogSaveNFL(buf);
							}
//							break;
						}
					}// end of for
					if(!found){
						r = FALSE;
						TRACE("PJ Not found1 %s\n", vtData.bstrVal);
						CString buf;
						buf.Format("PJ Not found1 %s\n", vtData.bstrVal);
						this->err.LogSaveNFL(buf);
						// break;
					}
					if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, 0, 1, 0, 0, 0)) {
						r = FALSE;
					}
				} else {
					r = FALSE;
				}
				
				VariantClear(&vtData);
				VariantClear(&v);			
			}
			// Get & save slot value
			// Get number of slot
			if (r) {
				if (!m_hXComSecs.GetItemData("V2_N2", &vtData, &item_type, &element, i + 1, 0, 0, 0)) {
					slotNo = vtData.iVal;
					TRACE("SlotNo =%d\n",slotNo);
					item_type	= ITEM_TYPE__INT4;
					attr_name	= "_SLOT_NUM_N1";

					if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, element, 1, 0, 0, 0)) {
						r = FALSE;
						// break;
					}
				} else {
					r = FALSE;
					// break;
				}
			}

			// Get and save slot
			if (r) {
				for (int j = 0; j < slotNo; j++) {
					VariantClear(&vtData);
					VariantClear(&v);
					
					if (!m_hXComSecs.GetItemData("Itm_SLOTID_N2N3", &vtData, &item_type, &element, i + 1, j + 1, 0, 0)) {
						attr_name	= "_SLOTID_N1N2";

						if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, element, 1, j + 1, 0, 0)) {
							r = FALSE;
							break;
						}
					} else {
						r = FALSE;
						break;
					}

					VariantClear(&vtData);
					VariantClear(&v);
					
					// Save bin code value
					if (!isBottom) {
						if (!m_hXComSecs.GetItemData("Itm_BINVAL_N2N3", &vtData, &item_type, &element, i + 1, j + 1, 0, 0)) {
							attr_name	= "_BIN_VALUE";

							if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, element, j + 1, 0, 0, 0)) {
								r = FALSE;
								break;
							}

							VariantClear(&vtData);

							if (!m_hXComSecs.GetItemData("Itm_BINCOUNT_N2N3", &vtData, &item_type, &element, i + 1, j + 1, 0, 0)) {
								attr_name	= "_BIN_COUNT";

								if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, element, j + 1, 0, 0, 0)) {
									r = FALSE;
									break;
								}
							}
						} else {
							r = FALSE;
							break;
						}
					}			
				}
				
				VariantClear(&vtData );
				VariantClear(&v);
			}

			////////////////////////////////////////////
			//Get receipe information
			///////////////////////////////////////////
			if (r) {
				//Get PRRecipeMethod
				if (!m_hXComSecs.GetItemData("Itm_PRRECIPEMETHOD_N2", &vtData, &item_type, &element, i + 1, 0, 0, 0)) {
					attr_name	= "_PRRECIPEMETHOD";
					
					if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, element, 0, 0, 0, 0)) {
						r = FALSE;
						//break;
					}
				} else {
					r = FALSE;
					//break;			
				} 
				
				VariantClear(&vtData );
				VariantClear(&v);
				
				//Get receipe spec for first head
				if (r && !m_hXComSecs.GetItemData("Itm_RCPSPEC_H1", &vtData, &item_type, &element, i + 1, 0, 0, 0)) {
					attr_name	= "_RCPSPEC";
					
					if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, element, 0, 0, 0, 0)) {
						r = FALSE;
						break;
					}
				} else {
					r = FALSE;
					//break;			
				}
				
				VariantClear(&vtData );
				VariantClear(&v);
				
				//Get receipe spec for seconds head
				if (r && !m_hXComSecs.GetItemData("Itm_RCPSPEC_H2", &vtData, &item_type, &element, i + 1, 0, 0, 0)) {
					attr_name	= "_RCPSPEC";
					
					if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, element, 0, 0, 0, 0)) {
						r = FALSE;
						//break;
					}
				} else {
					r = FALSE;
					//break;			
				}
				
				VariantClear(&vtData );
				VariantClear(&v);
			}
			if (r) {
				// Get & save carrierID
				ret = m_hXComSecs.GetItemData("Itm_CARRIERID_N2", &vtData, &item_type, &element, i + 1, 0, 0, 0);
				if((!ret) && (vtData.vt == VT_BSTR )) {
					attr_name	= "_CARRIERID_N1";
					////////////////////////////
					//
					// Check Port from Carrier
					//
					bool found = false;
					for (int k = 1; k < ePortNoMax/*-1*/; k++) {
						if (vtData.bstrVal == this->carrierId[k]) {
							found = true;
							if ((MIN_TOP_PORT_NO <= k) && (MAX_TOP_PORT_NO >= k)) {
								// if still not waiting
								CString buf;
								buf.Format("RecvS16F15-3 found carrierID(%s) port(%d)\n", this->carrierId[k], k);
								this->err.LogSaveNFL(buf);
							} else {// Bottom Port
								CString buf;
								buf.Format("RecvS16F15-4 found carrierID(%s) port(%d)\n", this->carrierId[k], k);
								this->err.LogSaveNFL(buf);
							}
//							break;
						}
					}// end of for
					if(!found){
						r = FALSE;
						TRACE("PJ Not found2 %s\n", vtData.bstrVal);
						CString buf;
						buf.Format("PJ Not found2 %s\n", vtData.bstrVal);
						this->err.LogSaveNFL(buf);
						// break;
					}
					if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, 0, 1, 0, 0, 0)) {
						r = FALSE;
					}
				}
				VariantClear(&vtData);
				VariantClear(&v);			
			}
			ret = m_hXComSecs.GetItemData("Itm_RCPPARNM_N2N4", &vtData, &item_type, &element, i + 1, 1, 0, 0);
			if ((!ret) &&  (vtData.vt == VT_BSTR)) {
				ttmp = vtData.bstrVal;
				if (ttmp == "keyvalue") {
					VariantClear(&vtData );
					attr_name	= "_RCPPARVAL_N1";
					if (!m_hXComSecs.GetItemData("Itm_RCPPARVAL_N2N4", &vtData, &item_type, &element, i + 1, 1, 0, 0)) {
						if (m_hCsg300pjm.PutAttrData(vObjType, vPrJobId, attr_name, vtData, item_type, element, 1, 0, 0, 0)) {
							this->err.PutError(Err_InvalidKeyValue1);// Conttrol Job Create is Failed
							r = FALSE;
						}
					} else {
						this->err.PutError(Err_InvalidKeyValue2);// Conttrol Job Create is Failed
						r = FALSE;
					}
				} else {
					//TODO DuyND
				}
			} else {
				r = FALSE;
			}
			////////////////////////////////////////////
			//Get PRProcessStart
			///////////////////////////////////////////
			if (r) {
				VariantClear(&vtData );
				VariantClear(&v);

				if (!m_hXComSecs.GetItemData("Itm_PRPROCESSSTART_N2", &vtData, &item_type, &element, i + 1, 0, 0, 0)) {				
					if (m_hCsg300pjm.SetPRJobStartMethod(vPrJobId, vtData.boolVal)) {
						r = FALSE;
						//break;
					}
				} else {
					r = FALSE;
					//break;
				}
			}
// #TN130515-01
			if(!r){
				ErrList[ErrListCnt] = i;
				ErrListCnt++;
			}
		}
	}

	//If create PJ successfully
	if (r && (ErrListCnt == 0)) {
		//Send reponse PRJobCreateAck
//		this->PutSecsItemSingleBIN("Itm_ACKA1", 0);
		VariantInit(&vtData);
		vtData.vt = VT_UI1;
		vtData.bVal = 0;
		if((ret = m_hXComSecs.PutExtendItem("Itm_ACKA1",vtData,0xA4,1,0,0,0,0)) != 0){
			VariantClear(&vtData);
			r = FALSE;
		}
// #TN130515-01
		this->PutSecsItem4ByteInteger("Val_N1", 0, 0, 0);
	} else {
// #TN130515-01
		int cnt=0;
		for(int i = 0; i < ErrListCnt; i++){
			VariantClear(&vtData );
			this->PutSecsItem4ByteInteger("Itm_ERRCODE_N1", 64, i, 0);
			VariantClear(&vtData );
			ret = m_hXComSecs.GetItemData("Itm_PRJOBID_N2_2", &vtData, &item_type, &element, ErrList[i] + 1, 0, 0, 0);
			if((!ret) && (vtData.vt == VT_BSTR)){
				this->PutExtendItemSingleASCII("Itm_ERRTEXT_N1", vtData.bstrVal, i + 1, 0);
				DeletePrJob(vtData.bstrVal);
			}
			// �ʐM���O
			CString buf;
			buf.Format("SoftComGem300 ERRCODE Error 0x%08X", ret);
			this->err.LogSaveNFL(buf);
		}
//		this->PutSecsItemSingleBIN("Itm_ACKA1", 1);
		// Put error code?
		VariantInit(&vtData);
		vtData.vt = VT_UI1;
		vtData.bVal = 1;
		if((ret = m_hXComSecs.PutExtendItem("Itm_ACKA1",vtData,0xA4,1,0,0,0,0)) != 0){
			VariantClear(&vtData);
			r = FALSE;
		}
// #TN130515-01
		this->PutSecsItem4ByteInteger("Val_N1", ErrListCnt, 0, 0);

		VariantClear(&vtData);
		r = FALSE;

	}

	this->SendS16F16();
	W.Unlock();
}

void DlgSG300::SendS16F16(){
	int ret=0;
	ret = m_hXComSecs.PutSecsEvent( "_GS16F16S_2" );
	if( ret ){
		// todo �G���[�����B
	}
}

BOOL DlgSG300::DeletePrJob(CString prJobId)
{
	BOOL	r = TRUE;
	long	ret;
	VARIANT	vPrJobId;

	VariantInit(&vPrJobId);
	vPrJobId.vt			= VT_BSTR;
	vPrJobId.bstrVal	= prJobId.AllocSysString();

	//Delete PJ
	ret = m_hCsg300pjm.DeletePRJob(vPrJobId, 0);

	//If delete successful
	if (!ret) {
		r = true;
	}

	VariantClear(&vPrJobId);

	TRACE("[SECS_DEBUG] DlgSG300::DeletePrJob(), prJobId = %s, r = %d \n", prJobId, r);

	return r;
}

BOOL DlgSG300::DeleteCtrlJob(CString ctrlJobId)
{
	BOOL	r = TRUE;
// #TN130515-01
//	VARIANT	vPrJobIdList;
	VARIANT	CtrlIdList;
	SAFEARRAY FAR *pArray = NULL;
	unsigned long ulelement;
	long Count;
// #TN130515-01
//	VARIANT vPrJobId;

// #TN130515-01
//	VariantInit(&vPrJobIdList);
	VariantInit(&CtrlIdList);
	
	// Get all ctrl job
// #TN130515-01
//	if (!m_hCsg300pjm.GetAllPRJobId(&vPrJobIdList, &Count)) {
//		if ((vPrJobIdList.vt & VT_ARRAY)== VT_ARRAY) {
//			pArray = vPrJobIdList.parray;
	if (!m_hCsg300cjm.GetAllCtrlJobId(&CtrlIdList, &Count)) {
		if ((CtrlIdList.vt & VT_ARRAY)== VT_ARRAY) {
			pArray = CtrlIdList.parray;
			ulelement = pArray->rgsabound[0].cElements;

			VARIANT vData;
			VariantInit(&vData);

			for (unsigned long i = 0; i < ulelement; i ++) {
// #TN130515-01
//				if ((vPrJobIdList.vt & 0x0FFF) == VT_VARIANT) {
				if ((CtrlIdList.vt & 0x0FFF) == VT_VARIANT) {
					if (SafeArrayGetElement(pArray, (long FAR*)&i, &vData) == S_OK) {	
						// #KI150324-01(S)
						// Delete only assigned CJID
						if ((vData.vt == VT_BSTR) && (vData.bstrVal == ctrlJobId)) {
							m_hCsg300cjm.DeleteCtrlJob(vData);
						}
						{	
							CString buf;
							buf.Format("DeleteCtrlJob Done(%s)\n", ctrlJobId);
							this->err.LogSaveNFL(buf);
						}
						// #KI150324-01(E)
					} else {
						r = FALSE;
						break;
					}
				}

			}
		}
	}

// #TN130515-01
//	VariantClear(&vPrJobIdList);
	VariantClear(&CtrlIdList);

	TRACE("[SECS_DEBUG] DlgSG300::DeleteCtrlJob(), ctrlJobId = %s, r = %d \n", ctrlJobId, r);

	return r;
}


BOOL DlgSG300::DeleteAllPrJob()
{
	BOOL	r = TRUE;
	long	Count;	
	VARIANT	vPrJobIdList;
	VARIANT vPrJobId;
	
	SAFEARRAY FAR *pArray = NULL;
	unsigned long ulelement;

	VariantInit(&vPrJobIdList);
	VariantInit(&vPrJobId);
	
	// Get all ctrl job
	if (!m_hCsg300pjm.GetAllPRJobId(&vPrJobIdList, &Count)) {
		if ((vPrJobIdList.vt & VT_ARRAY)== VT_ARRAY) {
			pArray = vPrJobIdList.parray;
			ulelement = pArray->rgsabound[0].cElements;

			VARIANT vData;
			VariantInit(&vData);

			for (unsigned long i = 0; i < ulelement; i ++) {
				if ((vPrJobIdList.vt & 0x0FFF) == VT_VARIANT) {
					if (SafeArrayGetElement(pArray, (long FAR*)&i, &vData) == S_OK) {	
						
						m_hCsg300pjm.DeletePRJob(vData, 0);
					} else {
						r = FALSE;
						break;
					}
				}

			}
		}
	}

	VariantClear(&vPrJobIdList);

	return r;
}

BOOL DlgSG300::DeleteAllCtrJob()
{
	long			ret;
	BOOL			r = FALSE;
	VARIANT			CtrlIdList;
	VARIANT			vCJobId;
	CString			ctrlJobId = "";
	long			Count;
	int				ulelement;
	SAFEARRAY FAR	*pArray = NULL;

	VariantInit(&CtrlIdList); 

	ret = m_hCsg300cjm.GetAllCtrlJobId(&CtrlIdList, &Count);

	if (!ret) { 
		if ((CtrlIdList.vt & VT_ARRAY) == VT_ARRAY) {
			pArray = CtrlIdList.parray;
			ulelement = pArray->rgsabound[0].cElements;

			VARIANT vData;
			VariantInit(&vData);

			for (int i = 0; i < ulelement; i ++) {
				if ((CtrlIdList.vt & 0x0FFF) == VT_VARIANT) {
					if (SafeArrayGetElement(pArray, (long FAR*)&i, &vData) == S_OK) {	
						
						m_hCsg300cjm.DeleteCtrlJob(vData);
						::Sleep(50);
					} else {
						r = FALSE;
						break;
					}
				}

			}
		}
	} else {
		r = FALSE;
	}

	VariantClear(&CtrlIdList);
	VariantClear(&vCJobId);

	return r;
}

void DlgSG300::RecvS14F09()
{
	BOOL	r = true;
	short	item_type;
	long	ret, element;
	CString	ttmp;
	int		carrierNo = 0;
	int		i = 0;
	int		j = 0;
	int	getPortNo = 0;	// #KI141205-03
	CString objType = "";
	CString attrId = "";
	CString attr_name = "";
	CString ctrJobId = "";
	CString carrierId= "";
	
	VARIANT	vtData;		//Hold recived data
	VARIANT vObjType;	//Object type
	VARIANT vObjId;		//Hold object ID

	VariantInit(&vtData);
	VariantInit(&vObjType); 
	VariantInit(&vObjId); 

	//Set object type data
	objType = "ControlJob";
	vObjType.vt = VT_BSTR;
	vObjType.bstrVal = objType.AllocSysString();

	//Set object id data
	vObjId.vt = VT_BSTR;
	
	CSingleLock W0(&this->CarrierSema, TRUE);
	::Sleep(500);
	CSingleLock W(&this->CJPJSema);
	W.Lock();
	// Get OBJSPEC
	if (!m_hXComSecs.GetItemData("Itm_OBJSPEC_2", &vtData, &item_type, &element, 0, 0, 0, 0)) {
		ttmp = vtData.bstrVal;
	} else {
		r = FALSE;
	}

	// Get OBJTYPE
	VariantInit(&vtData);
	if (r && (!m_hXComSecs.GetItemData("Itm_OBJTYPE", &vtData, &item_type, &element, 0, 0, 0, 0))) {
		ttmp = vtData.bstrVal;

		if (ttmp != "ControlJob") {
			r = FALSE;
		}
	} else {
		r = FALSE;
	}

	// Get ObjID
	VariantInit(&vtData);
	if (r && (!m_hXComSecs.GetItemData("Itm_ATTRDATA_OBJID", &vtData, &item_type, &element, 0, 0, 0, 0))) {
		ctrJobId = vtData.bstrVal;
		vObjId.bstrVal = ctrJobId.AllocSysString();

		// Create control job
		r = this->CreateCtrlJob(ctrJobId);
	} else {
		r = FALSE;
	}

	
	// Get ProcessOrderMgmt
	VariantInit(&vtData);
	if (r && (!m_hXComSecs.GetItemData("Itm_ATTRDATA_ProcessOrderMgmt", &vtData, &item_type, &element, 0, 0, 0, 0))) {
		// Update attribute data
		attr_name = "_PROCESSORDERMGMT";
		if (m_hCsg300cjm.PutAttrData(vObjType, vObjId, attr_name, vtData, item_type, element, 0, 0, 0, 0)) {
			r = FALSE;
		}
	} else {
		r = FALSE;
	}
	
	// Get StartMethod
	VariantInit(&vtData);
	if (r && (!m_hXComSecs.GetItemData("Itm_ATTRDATA_StartMethod", &vtData, &item_type, &element, 0, 0, 0, 0))) {
		// StartMethod��0 or 1(1�ȏ�̒l�Ȃ�1)
		short StartMthod = 0;
		if(vtData.bVal >= 1) StartMthod = 1;
		// Update attribute data
		if (m_hCsg300cjm.SetCtrlJobStartMethod(vObjId, StartMthod)) {
//			TRACE("[SECS_DEBUG] DlgSG300::SetCtrlJobStartMethod fail, vtData = %s\n", vtData.bVal);
			r = FALSE;
		}
	} else {
		r = FALSE;
	}

	// Get CarrierInputSpec
	VariantInit(&vtData);
	if (r && (!m_hXComSecs.GetItemData("Itm_CARRIERID", &vtData, &item_type, &element, 0, 0, 0, 0))) {
		// Update attribute data
		attr_name = "_INPUT_CARRIERID_N1";
		// 
		carrierId = vtData.bstrVal;
		// CtrlJobId�����X�g�ɓ����(������ςȂ�?)
		if (!m_hCsg300cjm.PutAttrData(vObjType, vObjId, attr_name, vtData, item_type, element, 1, 0, 0, 0)) { // TODO: CarrierID is only for one CJ, array index is always 1
			r = this->UpdateCtrlList(ctrJobId, vtData.bstrVal);
		} else {
			r = FALSE;
		}
	} else {
		r = FALSE;
	}
	// Get MtrOutSpec
	// Get ProcessCtrlSpec
	// Get no of PrJob
	VariantInit(&vtData);
	if (r && (!m_hXComSecs.GetItemData("V2", &vtData, &item_type, &element, 0, 0, 0, 0))) {
		int list_cnt = vtData.iVal;

		VariantInit(&vtData);
		vtData.vt = VT_UI1;
		vtData.uiVal = list_cnt;
		attr_name = "_PROCCTRLSPEC_NUM";

		if ( ret = m_hCsg300cjm.PutAttrData(vObjType, vObjId, attr_name, vtData, ITEM_TYPE__UINT1, 1, 0, 0, 0, 0)) {
			r = FALSE;
		} else {

			// Get list of PrJob
			for (i = 0; i < list_cnt; i++) {
				VariantInit(&vtData);
				if (r && (!m_hXComSecs.GetItemData("Itm_PRJOBID_N2_2", &vtData, &item_type, &element, i + 1, 0, 0, 0))) {
					// Determine PJ is created or not
					short state;
					ret = m_hCsg300pjm.GetPRJobState(vtData, &state);
					
					// If process job is not valid (if PJ is not created, ret = 0x60020037
					if (ret) {
						r = FALSE;
						break;
					}
					// Update attribute data
					attr_name = "_PROCCTRLSPEC_PRJOBID_N1";
					if (m_hCsg300cjm.PutAttrData(vObjType, vObjId, attr_name, vtData, item_type, element, i + 1, 0, 0, 0)) {
						r = FALSE;
						break;
					}
				} else {
					r = FALSE;
					break;
				}
			}
		}
	} else {
		r = FALSE;
	}
	//////////////////////////////////////////////////
	//
	//Notify that receive CJ creating request from host
	//
	/////////////////////////////////////////////////
	//Initialize variable
	VariantInit(&vtData);
	VariantInit(&vObjType);

	//Determine CJ for host or bottom ports
	if (r) {
		//TODO (QuyetVK): Send response message
		CString carrierID = "";
		//Get carrierID following to CJ
		if(!m_hCsg300cjm.GetAttrData(vObjType, vObjId, "_INPUT_CARRIERID_N1", &vtData, &item_type, &element, 1, 0, 0, 0)) {
			carrierID = vtData.bstrVal;
			//Determine which port has carrierID
			for (i = 1; i < ePortNoMax/*-1*/; i++) {// #KI130523-04
				if (carrierID == this->carrierId[i]) {// #KI130423-04
					if ((MIN_TOP_PORT_NO <= i) && (MAX_TOP_PORT_NO >= i)) {// Top Port
						// if still not waiting
						this->EvTopCJCreate.SetEvent();
						getPortNo	= i;// #KI141205-03
						CString buf;
						buf.Format("RecvS14F09-1 found carrierID(%s) port(%d)\n",
																carrierID, i);
						this->err.LogSaveNFL(buf);
					} else {// Bottom Port
						this->EvBottomCJCreate.SetEvent();
						getPortNo	= i;// #KI141205-03
						CString buf;
						buf.Format("RecvS14F09-2 found carrierID(%s) port(%d) (1:%s 2:%s)\n",
																	carrierID, i);
						this->err.LogSaveNFL(buf);
					}
//					break;
				}
			}// end of for
		} else {
			r = FALSE;
		}
		if(r){
			this->PutSecsItemSingleBIN("Itm_OBJACK2", 0);
		}
	}
	if(!r){
		// #KI141205-03(S)
		// �|�[�g�ԍ����擾�ł��Ă���Ȃ�
		if(getPortNo > 0){
			if ((MIN_TOP_PORT_NO <= getPortNo) && (MAX_TOP_PORT_NO >= getPortNo)) {
				this->TopCtrlJobIdList[getPortNo-eTopPortNo1] = _T("");// #KI141221-03
				if(this->pEvStopWaitingSecsT != NULL){
					this->pEvStopWaitingSecsT->SetEvent();
				}
			}else{
				this->BottomCtrlJobIdList = _T("");
				if(this->pEvStopWaitingSecsB != NULL){
					this->pEvStopWaitingSecsB->SetEvent();
				}
			}
		}else{
			// �Ƃ肠�����S���X�g�b�v
			if(this->pEvStopWaitingSecsT != NULL){
				this->pEvStopWaitingSecsT->SetEvent();
			}
			if(this->pEvStopWaitingSecsB != NULL){
				this->pEvStopWaitingSecsB->SetEvent();
			}
		}
		this->err.PutError(Err_CrJobCreateFail1);// Conttrol Job Create is Failed
		// #KI141205-03(E)
		//Delete all created CJ
		// �S����Ctrl Job�ł͂Ȃ��A��������Job�݂̂�Delete
		DeleteCtrlJob(ctrJobId);
		// Set error
		this->PutSecsItemSingleBIN("Itm_OBJACK2", 1);
	}

	// Send ACK
	this->SendS14F10();
	::Sleep(500);
	W.Unlock();
	return;
}

BOOL DlgSG300::UpdateCtrlList(CString ctrlJobId, CString carrierID)
{
	BOOL r = TRUE;
	bool isFound = false;
	for (int i = 1; i < ePortNoMax; i++) {
		if (strcmp(this->carrierId[i], carrierID) == 0) {
			if (i == eTopPortNo1) {
				this->TopCtrlJobIdList[i - eTopPortNo1] = ctrlJobId;
			} else {
				this->BottomCtrlJobIdList = ctrlJobId;
			}
			isFound = true;
			break;
		}
	}

	// If carrierID is not match with any carrier of all ports
	if (!isFound) {
		r = FALSE;
	}

	return r;
}

void DlgSG300::SendS14F10(){
	int ret=0;
	ret = m_hXComSecs.PutSecsEvent( "_GS14F10S_2" );
	if( ret ){
		// todo �G���[�����B
	}
}

BOOL DlgSG300::SetCurrentKeyValue(CString keyVal)
{
	BOOL r = TRUE;

	if (keyVal == "") {
		r = FALSE;	
	} else {
		this->m_keyValue = keyVal;
	}

	return r;
}

BOOL DlgSG300::SetCurrentTopCarrier(int portNo)
{
	BOOL r = TRUE;

	// Check input parameters
	if (portNo == eTopPortNo1
		|| portNo == eTopPortNo2 || portNo == eTopPortNo3) {
		// Set current top carrier
		this->TraceTopD.topWaferCarrierID = this->carrierId[portNo];		//##QuyetVK 20130704 SECS
	} else {
		r = FALSE;
	}

	return r;
}

BOOL DlgSG300::SetCurrentBottomCarrier(int portNo)
{
	BOOL r = TRUE;

	// Check input parameters
	if (portNo == eBottomPortNo) {
		// Set current top carrier
		this->TraceBotD.bottomWaferCarrierID = this->carrierId[portNo];		//##QuyetVK 20130704 SECS
	} else {
		r = FALSE;
	}

	return r;
}

BOOL DlgSG300::TopCarrierReleseByHostEvent(){
	BOOL r = TRUE;
	long	ret;
#if !Release
	TRACE("ForceCompleteByHOST\n");
#endif
	// �C�x���g���M
	if((ret = m_hXComSecs.SndEvntInf("ForceCompleteByHOST",0)) != 0){		//ProcessProcessingComplete ���b�Z�[�W���M
		r = FALSE;
		return r;
	}
	return r;
}

BOOL DlgSG300::ReportBottomCtrlJobStatus(int portNo, CString ctrlJobId, CString prJobId)	//##QuyetVK 20130704 SECS Add portNo as parameter
{
	BOOL	r = TRUE;
	short	ctrlJobState;
	short	prJobState;
	bool	doStopPJ = false;

	TRACE("[SECS_DEBUG] DlgSG300::ReporBottomCtrlJobStatus(), prevCJID = %s, nextCJID = %s, prevPJID = %s, nextPJID = %s \n",
															 this->m_CurrBottomCtrlJobId, ctrlJobId, m_CurrBottomPrJobId, prJobId);
	
	if (ctrlJobId != this->m_CurrBottomCtrlJobId) {
		if (this->m_CurrBottomCtrlJobId != "") {
			// Get current process job state
			r = this->GetPrJob_State(this->m_CurrBottomPrJobId, prJobState);

			if (r &&  (prJobState == ePrJobStateProcessing)) {
				// Change state
				r = this->SetPrJob_State(this->m_CurrBottomPrJobId, ePrJobStateProcessingComplete, portNo);
				// ���݂�PrJob��ProcessingComplete�֏�ԑJ�ڂ��APRJobComplete����
				VARIANT	vData;
				VariantInit(&vData);
				vData.bstrVal = this->m_CurrBottomPrJobId.AllocSysString();
				if(r) r = this->m_hCsg300pjm.PRJobComplete(vData);

				doStopPJ = true;
			}
			// Get current bottom ctrl job state
			if(r) r = this->GetCtrlJob_State(this->m_CurrBottomCtrlJobId, ctrlJobState);

			if (r && (ctrlJobState != eCtrlJobStateQueuedPool)) {
				// Finish current control job
				r = this->SetCtrlJob_State(m_CurrBottomCtrlJobId, eCtrlJobStateCompleted, portNo);
				// CtrlJob�폜���ɓo�^����Ă���PrJob���폜����
				CString prJobIdList[25];
				int		prJobNo = 0;
				this->GetCtrlJob_PrJobList(m_CurrBottomCtrlJobId, prJobIdList, prJobNo);
				for(int i=0; i < prJobNo; i++){
					r = this->DeletePrJob(prJobIdList[i]) && r;
				}
				// Delete control job
				r = this->DeleteCtrlJob(m_CurrBottomCtrlJobId) && r;
			}

		}

		//Execute control job
		if (r) {
			r = this->GetCtrlJob_State(ctrlJobId, ctrlJobState);

			if (r
			&& ((ctrlJobState == eCtrlJobStateSelected)
			 || (ctrlJobState == eCtrlJobStateWaitingForStart)
			 || (ctrlJobState == eCtrlJobStatePaused))) {
				// Change state
				r = this->SetCtrlJob_State(ctrlJobId, eCtrlJobStateExecuting, portNo);
			}
		}

		this->m_CurrBottomCtrlJobId = ctrlJobId;

		// Set current bottom carrier ID
		this->SetCurrentBottomCarrier(portNo);
	}

	if (prJobId != this->m_CurrBottomPrJobId) {
		if (!doStopPJ && (this->m_CurrBottomPrJobId != "")) {
			// Get current process job state
			r = this->GetPrJob_State(this->m_CurrBottomPrJobId, prJobState);

			if (r &&  (prJobState == ePrJobStateProcessing)) {
				// Change state
				r = this->SetPrJob_State(this->m_CurrBottomPrJobId, ePrJobStateProcessingComplete, portNo);

//				// Delete process job
//				r = this->DeletePrJob(m_CurrBottomPrJobId);
				// ���݂�PrJob��ProcessingComplete�֏�ԑJ�ڂ��APRJobComplete����
				VARIANT	vData;
				VariantInit(&vData);
				vData.bstrVal = this->m_CurrBottomPrJobId.AllocSysString();
				if(r) r = this->m_hCsg300pjm.PRJobComplete(vData);
			}
		}
		// ���Ɏ��s����PrJob��Processing��ԂɑJ�ڂ�����
		if (r) {
			r = this->GetPrJob_State(prJobId, prJobState);

			if (r) {
				if (prJobState == ePrJobStateQueuedPool) {
					// Change to SETTING UP state
					r = this->SetPrJob_State(prJobId, ePrJobStateSettingUp, portNo);

					//  Peform all required resource preconditioning
					// TODO (QuyetVK): Using callback function?

					// Waiting for start
					// TODO (QuyetVK): Always auto start?

					// Change to Processing state
					if (r) {
						r = this->SetPrJob_State(prJobId, ePrJobStateProcessing, portNo);
					}
				}
			}
		}
	
		this->m_CurrBottomPrJobId = prJobId;
	}

	return r;
}

// #KI141221-03(S)
BOOL DlgSG300::DeleteJobsOfPort(int portNo)
{
	BOOL	r = TRUE;
	CString	CtrlJobID = _T("");
	if (portNo == eTopPortNo1) {
		CtrlJobID = this->TopCtrlJobIdList[portNo - eTopPortNo1];
	} else if (portNo == eBottomPortNo) {
		CtrlJobID = this->BottomCtrlJobIdList;
	} else {
		return FALSE;
	}
	{
		CString buf;
		buf.Format("DeleteJobsOfPort(%d) CtrlJobID(%s) (1:%s 2:%s)\n",
							portNo, CtrlJobID,
							this->BottomCtrlJobIdList,
							this->TopCtrlJobIdList[0]
							);
		this->err.LogSaveNFL(buf);
		TRACE(buf);
	}
//	TRACE("DeleteJobsOfPort(%d) CtrlJobID(%s)\n", portNo, CtrlJobID);
	// ����ControlJob�������(if this port has already create Ctrl Job)
	if (CtrlJobID != "") {
		// CtrlJob�폜���ɓo�^����Ă���PrJob���폜����
		CString prJobIdList[25];
		int		prJobNo = 0;
		this->GetCtrlJob_PrJobList(CtrlJobID, prJobIdList, prJobNo);
		for(int i=0; i < prJobNo; i++){
			r = this->DeletePrJob(prJobIdList[i]) && r;
		}
		// Delete control job
		r = this->DeleteCtrlJob(CtrlJobID) && r;
		// delete Control Job List
		if (portNo == eTopPortNo1) {
			this->TopCtrlJobIdList[portNo-eTopPortNo1] = _T("");
		} else {
			this->BottomCtrlJobIdList = _T("");
		}
		TRACE("DeleteJobsOfPort(%d) r=(%d)\n", portNo, r);
	}
	return r;
}
// #KI141221-03(E)
//{{AFX_INCLUDES()
#include "xcomsecs.h"
#include "sg300cms.h"
#include "sg300cjm.h"
#include "sg300pjm.h"
//}}AFX_INCLUDES
#if !defined(AFX_DLGSG300_H__94B9D1F1_650C_4EEA_AC8C_0A62A4B2FFA3__INCLUDED_)
#define AFX_DLGSG300_H__94B9D1F1_650C_4EEA_AC8C_0A62A4B2FFA3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include	"afxmt.h"
// DlgSG300.h : �w�b�_�[ �t�@�C��
//

#include <MCSTD.H>					// #TT120125-01

#define	TFC6000SPEC	1

#if TFC6000SPEC
#include	"CommonBghPara.h"		// #TT120125-01
#include	"..\COM\CommonDef.h"	// #TT120125-01
#include	<ulib.h>		
#endif
// #KS20130415-01 [�ǉ�]SECS�E�F�n�}�b�s���O
//#include <SecsTDS.h>
#include <SecsCom.h>
#include <WMVif.h>


#include "StatusDlg.h"				// #TT120208-01 ClassView�Œǉ����Ăˁ[���Ǒ��v���H

#define FileNameCntMax (100)

#define MIN_BOTTOM_PORT_NO		(1)
#define MAX_BOTTOM_PORT_NO		(1)
#define NO_OF_BOTTOM_PORT		(1)

#define MIN_TOP_PORT_NO			(2)
#define MAX_TOP_PORT_NO			(4)
#define NO_OF_TOP_PORT			(3)

#define MAX_PORT_NO				(NO_OF_BOTTOM_PORT + NO_OF_TOP_PORT)


// Define item type value
#define ITEM_TYPE__LIST		0x0000	// List
#define ITEM_TYPE__BIN		0x0020	// Binary type
#define	ITEM_TYPE__BOOL		0x0024	// Bool type
#define	ITEM_TYPE__ASCII	0x0040	// ASCII type
#define	ITEM_TYPE__JIS_8	0x0044	// JIS8 type
#define	ITEM_TYPE__INT1		0x0064	// 1-byte int type
#define	ITEM_TYPE__INT2		0x0068	// 2-byte int type
#define	ITEM_TYPE__INT4		0x0070	// 4-byte int type
#define	ITEM_TYPE__F8		0x0080	// 8-byte float type
#define	ITEM_TYPE__F4		0x0090	// 4-byte float type
#define	ITEM_TYPE__UINT1	0x00A4	// 1-byte uint type
#define	ITEM_TYPE__UINT2	0x00A8	// 2-byte uint type
#define	ITEM_TYPE__UINT4	0x00B0	// 4-byte uint type
#define	ITEM_TYPE__USER		0x0120	// User define type


struct	FileNameTBL {
	CString	fileName;	// �t�@�C����
	int		nameLength;	// �t�@�C����������
};

/////////////////////////////////////////////////////////////////////////////
// DlgSG300 �_�C�A���O

class DlgSG300 : public CDialog, MCCStd
{
// �R���X�g���N�V����
public:
	DlgSG300(CWnd* pParent = NULL);   // �W���̃R���X�g���N�^
	virtual ~DlgSG300();

// �_�C�A���O �f�[�^
	//{{AFX_DATA(DlgSG300)
	enum { IDD = IDD_SG300_DIALOG };
	CXcomSecs	m_hXComSecs;
	CSG300CMS	m_hCsg300cms;
	CSG300CJM	m_hCsg300cjm;
	CSG300PJM	m_hCsg300pjm;
	//}}AFX_DATA

	CStatusDlg	DlgStatus;					// TT120208-01 �ʐM��ԕ\���_�C�A���O
	RECT		m_WorkRect;					// TT120208-01 �ʐM��ԕ\���_�C�A���O
public:
	/////////////////////////////////////
	//
	// Public enum
	//
	enum communicate{
		eDisabled		= 0,
		eNotCommu		= 1,
		eCommunicating	= 2,
	};
	enum CtrlState{
		eCtrlNone		= 0,
		eEuipOffline	= 1,
		eAttemptOffline	= 2,
		eHostOffline	= 3,
		eOnlineLocal	= 4,
		eOnlineRemote	= 5,
	};
	enum comMainState{
		eGoOffline		= 0,
		eGoOnline		= 1,
	};
	enum comSubState{
		eGoLocal		= 0,
		eGoRemote		= 1,
	};
	enum transferState{
		eStateOutOfService		= 0,	// 0
		eStateTransferBlocked,			// 1
		eStateReadyToLoad,				// 2
		eStateReadyToUnload,			// 3
	};
	enum transferCmd{
		eCmdOutOfService		= 0,	// 0
		eCmdInService,					// 1
		eCmdTransferBlocked,			// 2
		eCmdReadyToLoad,				// 3
		eCmdReadyToUnload,				// 4
	};
	enum myPortNo{
		eNonePort		= 0,
		eBottomPortNo	= 1,
		eTopPortNo1		= 2,
		eTopPortNo2		= 3,
		eTopPortNo3		= 4,
		ePortNoMax,
	};
	enum carrierLoadUnload{
		eCarrierLoadNone		= 0,	// 0
		eCarrierStart,					// 1
		eCarrierFinished,				// 2
		eCarrierFailed,					// 3
	};
	enum carrierAccess{
		eNotIDRead				= 0,	// 0
		eInAccess,						// 1
		eCompleted,						// 2
		eStopped,						// 3
	};
	enum CtrlJobState {
		eCtrlJobStateQueuedPool			= 0,
		eCtrlJobStateSelected			= 1,
		eCtrlJobStateWaitingForStart	= 2,
		eCtrlJobStateExecuting			= 3,
		eCtrlJobStatePaused				= 4,
		eCtrlJobStateCompleted			= 5,
	};
	enum PrJobState {
		ePrJobStateQueuedPool			= 0,
		ePrJobStateSettingUp			= 1,
		ePrJobStateWaitingForStart		= 2,
		ePrJobStateProcessing			= 3,
		ePrJobStateProcessingComplete	= 4,
		ePrJobStatePausing				= 5,
		ePrJobStatePaused				= 6,
		ePrJobStateStopping				= 7,
		ePrJobStateAborting				= 8,
		ePrJobStateStopped				= 9,
		ePrJobStateAborted				= 10,
	};
private:
///	CStatusDlg	DlgStatus;					// TT120208-01 �ʐM��ԕ\���_�C�A���O
///	RECT		m_WorkRect;					// TT120208-01 �ʐM��ԕ\���_�C�A���O
	/////////////////////////////////////
	//
	// Private Event
	//
	CEventX*	pEvPPRecipeSendReq;			// S7F25/26 �v���Z�X�v���O�������J�n	OK�񍐲����	(TPCtrl�׽������̂��擾)	// #TT120125-01
	CEventX*	pEvPPSelectReq;				// S2F41/42 PPSelect/PPStart			OK�񍐲����	(TPCtrl�׽������̂��擾)	// #TT120204-01
	CEventX*	pEvPPStartReq_B;			// S2F41/42 PPSelect/PPStart			OK�񍐲����	(TPCtrl�׽������̂��擾)	// #TT120204-01
	CEventX*	pEvPPStartReq_T;			// S2F41/42 PPSelect/PPStart			OK�񍐲����	(TPCtrl�׽������̂��擾)	// #TT120204-01
	/////////////////////////////////////
	//
	// Private Variable
	//
	CString		pathName;					// �p�X��
	CString		projectName;				// �v���W�F�N�g��
	CString		ppID;
	CString		cpVal;
	CString		softRevision;
	int			fileNameCount;
	FileNameTBL	FName_TBL[FileNameCntMax];
	int			comState;					// comstate
// #KS20130510-01 [���P]S5F2���s�v�ȃA���[���Ή�
	CString		AlarmMsgName;
// #MO20131101 [�ǉ�]SoftComGem300�@�\���g�p���Ă��邩�ǂ������Z�b�g
	bool		useSoftComGem300;
	CString			m_CurrBottomCtrlJobId;			// Current bottom control job ID
	CString			m_CurrBottomPrJobId;			// Current bottom process job ID
	CString			m_CurrTopCtrlJobId;				// Current top control job ID
	CString			m_CurrTopPrJobId;				// Current top process job ID
	CString			m_keyValue;						// Current key value
// #KS20130415-01 [�ǉ�]SECS�E�F�n�}�b�s���O
//	int ID;
//	SecsTDS *pSecsTDS;
//Gem300�Ή��}�b�v���_130123_Misato_S
	struct MapCtrlData {
		CEventX EvReqMapOK;		// �Ή�OK�C�x���g
		CEventX EvReqMapEnd;	// �Ή������C�x���g
		bool bReqMap;			// �v����
		int iReqMapErr;			// 0:�G���[��
		enum {
			eReqMapErr_Nothing	= 0,
			eReqMapErr_FailRecv	= 1,
			eReqMapErr_NGData	= 2,
			eReqMapErr_Send		= 3,
		};
		MapData *pMapData;
	} MapCtrl;
	BOOL SendS12F1();
	BOOL RecvS12F2();
	BOOL SendS12F3();
	BOOL RecvS12F4();
	BOOL SendS12F9();
	BOOL RecvS12F10();
	BOOL SendS12F5();
	BOOL RecvS12F6();
	BOOL SendS12F15();	
	BOOL RecvS12F16();
// #MO20131130(S) [�ǉ�]SECSϯ��ݸ�
	BOOL RecvS12F19();
	BOOL SendS12F19(int, BYTE);
	int	 maper;
	int  datlc;
// #MO20131130(E) [�ǉ�]SECSϯ��ݸ�
//	int timeout;
//Gem300�Ή��}�b�v���_130123_Misato_E
// #KS20130415-01(E)
	int			bgMode;						// Bg���[�h
	int			numberOfStack;				// IC�i�ςݐݒ萔
	double		chipThickness[IC_TypeMax];	// �`�b�v����
	s_IcData	secsPPData[IC_TypeMax];		// IC�i��P�� �e��p�����[�^
//	bool		carrierIsCreated;			// �L�����A������B
//	bool		almIsAlreadySend[2000];		// S5F1/2�̏d������M���
// #DDT160428-01
	bool		almIsAlreadySend[Error_NumberMax];		// S5F1/2�̏d������M���
	bool		loadedByHost[ePortNoMax];	// Host�o�R�ŃL�����A�����[�h����
	bool		zantei;
public:
	CString			carrierId[ePortNoMax];		// carrierId
	CSemaphoreX		PPSelectSema;		// PPSelect���ɓ����Ă͂����Ȃ��C���^�[���b�N(TP�׽��BDS�׽��ICS�׽�Ŕr�����Ƃ�)
	CSemaphoreX		CarrierSema;		// PortID��CarrierID�Ȃǂ𕡐��X���b�h���㏑�����Ȃ��悤�ɂ���Z�}�t�H
	CSemaphoreX		CJPJSema;	
	CSemaphoreX		ReportSema;			// WaferEnd�ɑ΂���BND��ICS�̔r������
	CSemaphoreX		CMSSema;			// ������"_PORTID"�Ȃǂ��㏑�����Ȃ��悤�ɂ���Z�}�t�H#KI150120-01
#if TFC6000SPEC
	ErrorMediator	err;					// �G���[�o��(�Ȃ�ׂ����̃N���X��pMCC���Ăт����Ȃ�����)
#endif
	enum{
		eWaferNumberMax	= 25,			//
	};
	CString	waferIdOfContentMap[eWaferNumberMax];	// ContentMap�Ŏ擾����E�F�n�h�c
	CString lotIdOfContentMap[eWaferNumberMax];		// #DucMV 20160331 SECS ECID
	CString	waferIdOfManual[eWaferNumberMax];		// Manual�Ŏ擾����E�F�n�h�c
	CSemaphoreX		S12F73Sema;			// S12F73�ɑ΂���BND��ICS�̔r������
	CSemaphoreX		WaferEndSema;		// WaferEnd�ɑ΂���BND��ICS�̔r������
	CSemaphoreX		PortNoSema;			// ProtNo�ɑ΂���BND��ICS�̔r������
private:
	bool	beAbleToRelease[NO_OF_TOP_PORT];
	bool	beAbleToAutoRun[NO_OF_TOP_PORT];
public:
	int		waferUmu[ePortNoMax][eWaferNumberMax];	// �E�F�n�L��(Bottom/Top)
	CString	TopCtrlJobIdList[NO_OF_TOP_PORT];
	CString	BottomCtrlJobIdList;
public:
	struct Count_Data{
		int PickCountG;			// �Ǖi�s�b�N�A�b�v���ꂽ�J�E���g
		int PickCountB;			// �s�Ǖi�s�b�N�A�b�v���ꂽ�J�E���g
		int PlaceCountG;		// �Ǖi�{���f�B���O���ꂽ�J�E���g
		int PlaceCountB;		// �s�Ǖi�{���f�B���O���ꂽ�J�E���g
		int UnBondCountG;		// �Ǖi�X�L�b�v(unbond)���ꂽ�J�E���g
		int UnBondCountB;		// �s�Ǖi�X�L�b�v(unbond)���ꂽ�J�E���g
		int PickRemainCountG;	// �Ǖi�c��̃J�E���g
		int PickRemainCountB;	// �s�Ǖi�c��̃J�E���g
		int PlaceRemainCountG;	// �Ǖi�c��̃J�E���g
		int PlaceRemainCountB;	// �s�Ǖi�c��̃J�E���g
	}CntD;
	struct TopTrace_Data{
		CString	recipeName;
		CString	topWaferCarrierID;
		CString	topWaferID;
		CString	pickupTime;
		CString topDieBin;
		CString Category;
		CString pickIcID;
		int pick_x;
		int pick_y;
		// #TT150402-01
		double actualCoordinateX;	// �����WX
		double actualCoordinateY;	// �����WY
		double matchingRatio_1stPos;// �}�b�`���O���P�_��
		double matchingRatio_2ndPos;// �}�b�`���O���Q�_��
		// DuyND 20160217 (S)
		double actualPickLevel;
		double settingPickLevel;
		double settingDippingLevel;
		double settingBgLevel;
		// DuyND 20160217 (E)
		// #DucMV 20160331 SECS ECID (S)
		CString binVals;
		CString remainBinCounts;
		CString pickBinCounts;
		CString tmpCJID;
		CString tmpPJID;		
		CString lotID;
		CString slotID;
		CString	topCMapWfID;			// contentMap		
		CString keyVal;
		float	tmpFlipHeight;		
		int		portNo;
		// #DucMV 20160331 SECS ECID (E)
		// #DuyND160427 (S)
		float	recogResult1X;
		float	recogResult1Y;
		float	recogResult2X;
		float	recogResult2Y;
		int		recogScore1;
		int		recogScore2;
		float	lCheck;
		// #DuyND160427 (E)
	}TraceTopD;
	struct BottomTrace_Data{
		CString	recipeName;
		CString	topWaferCarrierID;
		CString	topWaferID;
		CString	pickupTime;
		CString topDieBin;
		CString	bottomWaferCarrierID;
		CString bottomWaferID;
		CString bottomDieBin;
		CString Category;
		CString	placeTime;
		CString pickIcID;
		int pick_x;
		int pick_y;
		int place_x;
		int place_y;
		CString	bgSite;
		CString	substrateID;
		CString	operatorID;
		// #TT150402-01(S)
		double actualBgLevel;
		double settingBgForce;
		double actualBgForce;
		double settingBgTime;
		double substMatchingRatio_1stPos;	// ��}�b�`���O���P�_��
		double substMatchingRatio_2ndPos;	// ��}�b�`���O���Q�_��
		double substMarkDistance;			// ��}�[�N�X�p��
		double icMatchingRatio_1stPos;		// �h�b�}�b�`���O���P�_��
		double icMatchingRatio_2ndPos;		// �h�b�}�b�`���O���Q�_��
		double icMarkDistance;				// �h�b�}�[�N�X�p��
		// #TT150402-01(E)
		// DuyND 20160217 (S)
		double settingBgLevel;
		double settingDippingLevel;
		double actualDippingLevel;
		double placeUpX;
		double placeUpY;
		double placeUpZ;
		// DuyND 20160217 (E)
		// #DucMV 20160331 SECS ECID (S)
		CString tmpCJID;
		CString tmpPJID;
		CString binVals;
		CString bondBinCounts;
		float	tmpBgForce;
		float	tmpBgLevel;
		float	tmpBgTemp;
		float	tmpBgOverTravel;
		float	tmpBgStgTemp;
		float	tmpDipForce;
		float	tmpDipLevel;
		int		bottomPortNo;
		int		topPortNo;
		CString bottomSlotID;
		CString bottomLotID;
		CString bottomkeyVal;
		float	tmpStage_x;
		float	tmpStage_y;
		double	prePickLevel;
		double	prePickForce;
		// #DucMV 20160331 SECS ECID (E)
		// #DuyND160427 (S)
		float	subRecogMovePos1X;
		float	subRecogMovePos1Y;
		float	subRecogMovePos2X;
		float	subRecogMovePos2Y;
		int		subRecogScore1;
		float	subRecogResult1X;
		float	subRecogResult1Y;
		int		subRecogScore2;
		float	subRecogResult2X;
		float	subRecogResult2Y;
		float	subRecogResultPos1X;
		float	subRecogResultPos1Y;
		float	subRecogResultPos2X;
		float	subRecogResultPos2Y;
		float	subLCheck;

		float	icRecogMovePos1X;
		float	icRecogMovePos1Y;
		float	icRecogMovePos2X;
		float	icRecogMovePos2Y;
		int		icRecogScore1;
		float	icRecogResult1X;
		float	icRecogResult1Y;
		int		icRecogScore2;
		float	icRecogResult2X;
		float	icRecogResult2Y;
		float	icRecogResultPos1X;
		float	icRecogResultPos1Y;
		float	icRecogResultPos2X;
		float	icRecogResultPos2Y;
		float	icLCheck;

		float	bgPosCorX;
		float	bgPosCorY;
		float	bgPosCorT;
		float	stgPosX;
		float	stgPosY;
		float	stgActualPosX;
		float	stgActualPosY;
		float	stgCorX;
		float	stgCorY;
		float	bgLevel;
		float	dipLevel;
		// #DuyND160427 (E)
	}TraceBotD;
	struct MapAlignTrace_Data{	// #TT150402-01
		int indexX;
		int indexY;
		double matchingRatio;
	}TraceMapAlignD;
	struct DippingTrace_Data{	// #TT150402-01
		DippingTrace_Data(){
		}
		CString	recipeName;
		CString	dippedTime;
		double actualDippingLevel;
		double settingDippingForce;
		double actualDippingForce;
		double settingDippingTime;
	}TraceDippingD;
public:
	/////////////////////////////////////
	//
	// Public Event
	//
	CEvent* pEvFinInfoComState;
	CEvent* pEvFailInfoComState;
	CEvent* pEvFinInfoBottomCarrierIdRead;
	CEvent* pEvFailInfoBottomCarrierIdRead;
	CEvent* pEvFinInfoTopCarrierIdRead[NO_OF_TOP_PORT];
	CEvent* pEvFailInfoTopCarrierIdRead[NO_OF_TOP_PORT];
	
	CEvent* pEvFinInfoTopCarrierIdNotified;
	CEvent* pEvFailInfoTopCarrierIdNotified;
	
	// ReadSlotMapEvent
	CEvent* pEvFinInfoBottomSlotMap;
	CEvent* pEvFailInfoBottomSlotMap;
	CEvent* pEvFinInfoTopSlotMap;
	CEvent* pEvFailInfoTopSlotMap;
	// 
	CEvent* pEvFinInfoFileMapName;
	CEvent* pEvFailInfoFileMapName;
	CEvent* pEvFinInfoSeleStat;
	CEvent* pEvFailInfoSeleStat;
	CEvent*	pEvStopWaitingSecsT;			// ���f�v���C�x���g
	CEvent*	pEvStopWaitingSecsB;			// ���f�v���C�x���g
	CEvent*	pEvTopWaferUnloadReq[NO_OF_TOP_PORT];		// 
	CEvent*	pEvBottomWaferUnloadReq;	// 
	//
	// #MO20131129 [�ǉ�]SECSϯ��ݸ�
	CEvent* pEvS12F2Recv;
	CEvent* pEvS12F6Recv;
	CEvent* pEvS12F10Recv;
	// 
	CEvent EvFinChangeCR;
	CEvent EvFailChangeCR;
	//
	CEvent EvFinFileMapName;
	CEvent EvFailFileMapName;
	CEvent EvFinSeleStat;
	CEvent EvFailSeleStat;
	CEvent	EvStopWaitingDummy;			// ���f�v���C�x���g�_�~�[
	CEventX		EvPPRecipeReciveOK;		// S7F25/26 �v���Z�X�v���O�������I��	OK�񍐲����		// #TT120125-01
	//
	// #MO20131129 [�ǉ�]SECSϯ��ݸ� 
	CEvent EvS12F2Recv;
	CEvent EvS12F6Recv;
	CEvent EvS12F10Recv;
	//Event for notifying that receiving CJ create request from host
	CEvent EvTopCJCreate;
	CEvent EvBottomCJCreate;

	// #DucMV 20160405 Flux Function (S)
	int			MonitorMode;
	CEventX*	pEvStartMonitor;
	bool		isHostRequestMonitor;
	// #DucMV 20160405 Flux Function (E)
private:
	/////////////////////////////////////
	//
	// Private Method
	//
	void RecvS02F41();
	void RecvS07F19();
	void RecvS07F25();
	// SECS mesage
	void	RecvS14F09();
	void	SendS14F10();
	void	RecvS16F15(bool isBottom);
	void	SendS16F16();
	
	
	int	ArrayVSet(long sidx,long s2idx,long vidx,char *vname);
	int ArrayPPARMSet(long sidx,long s2idx, char *vname, int item_type, int arrayNo, double *arrayData);
	int ItemTypeGet(short item_type);
	CString FtoStr(double value);
	int GetArrayNo(int ictype, int stack);
	
	CWnd *pCwnd;
	void SetCWnd(CWnd *pCWnd) {
		this->pCwnd = pCWnd;
	}
	void KillTheExeFiles();
	void KillTheExe(CString fileName);

public:
	/////////////////////////////////////
	//
	// Public Method
	//
public:
	void	SendS02F42();
	void	RecvS07F26();
	void Init(int class_id, int myErrorStart);
	void ErrorLogOut(int line, int Error);
// #KS20130417-01 [�ǉ�]GEM�Q�|�[�g��
//	BOOL OpenProject();
	BOOL OpenProject(int iMode = 0);
	BOOL ChangeCR();
	BOOL CloseProject();
	BOOL CarrierLoad(short, CString);
	BOOL ReadBottomCarrierID(CString);
	BOOL NotifyTopCarrierID();
	BOOL ReadBottomSlotMap(CString, int[], int);
	BOOL ReadTopSlotMap(CString, int[], int);
	BOOL ReadTopCarrierID(int portNo, CString);
	void GetContentMap();
	short getCtrlState();
	short getLastCtrlState();
	short getLPTransferState();
	short getLPTransferState(int, CString);
	BOOL ClampEvent(int);
	BOOL DockEvent(int);
	BOOL ProcessStartEvent();
	BOOL ProcessCompleteEvent();
	BOOL StoppedTEvent();
	BOOL StoppedBEvent();
	BOOL CarrierUnLoad(short);
	BOOL CarrierTakeIn(short);
	BOOL CarrierTakeOut(short/*, bool errOut=true*/);
	BOOL CarrierForceTakeOut(short, CString);
	BOOL CarrierPlaced(short,bool);
	BOOL TopDieFinishedEvent(void);
	BOOL TopDieForceFinishedEvent(int);
	BOOL BottomDieFinishedEvent(void);
	BOOL BottomDieUnloadEvent(void);
	BOOL TopDieUnloadEvent(void);
	BOOL WaferEndEvent(bool);
	BOOL WaferStartEvent(bool);
	BOOL WaferPickUpEvent(void);
	BOOL PickupReportEvent();
	BOOL BondingReportEvent(/*int, int, int, int*/);
	BOOL setAttDataSingleUINT1(CString, CString, LPCSTR, unsigned char);
	short getAttDataSingleUINT1(CString, CString, LPCSTR);
	BOOL WaitingMessageCancel();
	short DlgSG300::getVIDValSingleUNIT1(LPCSTR);
	CString getCarrierID();
	BOOL ChangeOffLine();
	BOOL ChangeOnLineLocal();
	BOOL ChangeOnLineRemote();
	BOOL PutSecsItemSingleASCII(CString, CString);
	BOOL PutSecsVidSingleASCII(CString item_name, CString item_data);
	CString GetItemDataSingleASCII(CString);
//	BOOL GetBottomFileMapName(CString SlotID, int slotNo/*, int isTopSide*/, char *mID, int timeout);	// #TT160601-01
	BOOL GetBottomFileMapName(CString SlotID, int slotNo, CString waferID, char *mID, int timeout);
	BOOL GetTopFileMapName(int portNo, CString SlotID, char *mID, int timeout);	// #DDT160428-01 Add port number
// #KS20130415-01(S) [�ǉ�]SECS�E�F�n�}�b�s���O
	BOOL GetItemDataSingleBIN(CString);										//130205_Misato
	unsigned int GetItemDataSingleUnsignInt(CString, CString);				//Gem300�Ή�_130123_Misato
	BOOL MapSetupDataRequest(MapData *pMapD);
//	BOOL MapSetupDataRequest(CString, unsigned int);
	BOOL MapSetupDataSend(MapData *pMapD);							//Misato_S
//	BOOL MapSetupDataSend(CString);							//Misato_S
	BOOL MapDataSend(CString);
	BOOL MapChipMoveSend(int, int);
	BOOL MapChipPicked(int, int, unsigned char);										//Misato_E
	BOOL PutSecsItemSingleUnsignInt(CString, unsigned int, CString);
//	void SetID(int id) { ID = id; }
// #KS20130415-01(E)

// #DucMV 20160401 SECS ECID (S)
	BOOL BarcodeReadEvent(CString);
	BOOL ExpandReportEvent();
	BOOL DoorOpenEvent(short, bool);
	BOOL PutDoorID(unsigned int);
	BOOL TakeOutEvent(int);
	BOOL PlacedEvent(int);
// #DucMV 20160401 SECS ECID (E)

// #MO20131130
	int GetItemDataSingleInt(CString);
	
	BOOL PutSecsItemSingleBIN(CString, unsigned char);
	BOOL PutPortNo(unsigned int);
	BOOL PutProcessState(int);
	BOOL PutProcessPPID(CString);
	BOOL DelALLCarrierObj();
	BOOL UnloadALLCarrierObj();

	int  SetSecsSystemItem(CString item_name, long item_data);

	BOOL PutExtendItemSingleASCII(CString item_name, CString item_data, int element1, int element2);
	BOOL PutExtendItem4ByteInteger(CString item_name, int item_data, int element1, int element2);
	BOOL PutSecsItem4ByteInteger(CString item_name, int item_data, int element1, int element2);
	BOOL PutSecsItem8ByteFloating(CString item_name, int item_data, int element1, int element2);

	BOOL SendAlarm(bool isReport, int alID, CString alTX);
	BOOL SetAlarmData(bool isReport, int alID, CString alTX);
	BOOL RecvCarrierRelease(int);
	BOOL RecvCarrierNotification(int, CString);
	BOOL StartCheck();
	//
	//
	enum S2F41Status{
		eNotReceived	= 0,
		eGetPPSelect,
		eGetPPStart_B,
		eGetPPStart_T,
	};
	int	HostCommandStatus;
	int	Receive_BottomPPStartAction();	// 
	int	Receive_TopPPStartAction();		// 
	// #TT150402-01(S)
	BOOL WfMapAlingmentReportEvent();	// �E�F�n�}�b�v�A���C�����g�����C�x���g���M
	BOOL DippingReportEvent();			// Dipping�����C�x���g���M
	BOOL ProcessEndReportEvent();		// �����^�]�̃X�g�b�v�C�x���g���M
	BOOL PPRecipeSendReportEvent();		// �i��f�[�^�ύX�C�x���g���M
	// #TT150402-01(E)
	BOOL ForceCompleteByOPEvent(int);				//
	BOOL ForceCompleteByEQPEvent();
	void NotToBeAbleToRelease();
	void SetAbleToRelease(int);
	bool GetAbleToRelease(int);
	void SetAbleToAutoRun(int port, bool isAble);
	bool GetAbleToAutoRun(int port);

	BOOL	Receive_TopCJCreateAction(int portNo);
	BOOL	Receive_BottomCJCreateAction();
	// Process job management
	BOOL	CreatePrJob(CString prJobId);	
	BOOL	DeletePrJob(CString prJobId);
	BOOL	DeleteAllPrJob();
	BOOL	GetPrJob_SlotNoList(CString proJobList, int* slotNoList, int& slotNo);
	BOOL	GetPrJob_BinVal(CString prJobId, int slotNo, CString& binVal, CString& binCnt);
	BOOL	GetPrJob_State(CString prJobId, short& state);
	BOOL	SetPrJob_State(CString prJobId, short state, short portNo);
	BOOL	GetCtrlJob_PrJobList(CString ctrlJobId, CString* prJobList, int& prJobNo);
	CString	GetPrJob_PPID(CString prJobId);
	BOOL	GetPrJob_KeyVal(CString prJobId, CString& keyValue, int portNo);	// #KI150323-01
	BOOL	UpdateCtrlList(CString ctrlJobId, CString carrierID);

	// Control job 
	BOOL	CreateCtrlJob(CString ctrJobId);
	BOOL	DeleteCtrlJob(CString ctrlJobId);
	BOOL	DeleteAllCtrJob();
	int		GetCtrlJob_PortNo(CString ctrlJobId);
	BOOL	GetCtrlJob_State(CString ctrlJobId, short& state);
	BOOL	SetCtrlJob_State(CString ctrlJobId, short state, short portNo);

	BOOL	ReportBottomCtrlJobStatus(int portNo, CString ctrlJobId, CString prJobId);	//##QuyetVK 20130704 SECS Add portNo as parameters
//	BOOL	ReportTopCtrlJobStatus(CString ctrlJobId, CString prJobId, int lr);

	BOOL	SetCurrentKeyValue(CString keyVal);										// Set current key value		//##QuyetVK 20130629 SECS
	BOOL	SetCurrentTopCarrier(int portNo);								// Set current top carrier		//##QuyetVK 20130704 SECS
	BOOL	SetCurrentBottomCarrier(int portNo);
	BOOL	TopCarrierReleseByHostEvent();
	BOOL FluxFinishEvent();				// #DucMV 20160317 Flux function
	void SetMonitorEvent(CEventX *pEv);	// #DucMV 20160405 Flux Function
	BOOL ParticleFinishEvent();				// #DucMV 20160408 Monitor function
	BOOL	DeleteJobsOfPort(int);	// #KI141221-03
	/////////////////////////////////////
	//
	// Getter
	//
	/////////////////////////////////////
	CString GetPPID(){
		return ppID;
	}
	CString GetCPVAL(){
		return cpVal;
	}
	int GetComState(){
		return this->comState;
	}
	CString GetWaferId_C(int slotNo){
		return this->waferIdOfContentMap[slotNo-1];
	}
	// #DucMV 20160331 SECS ECID (S)
	CString GetLotId_C(int slotNo){
		return this->lotIdOfContentMap[slotNo-1];
	}
	// #DucMV 20160331 SECS ECID (E)
	CString GetWaferId_M(int slotNo){
		return this->waferIdOfManual[slotNo-1];
	}
	// �z�X�g���烍�[�h���ꂽ��
	bool GetLoadedByHost(int portNo){
		return this->loadedByHost[portNo];		// portNo-1����Ȃ��撍��
	}
	/////////////////////////////////////
	//
	// Setter
	//
	/////////////////////////////////////
	void SetPathName(CString name){
		this->pathName = name;
	}
	void SetProjectName(CString name){
		this->projectName = name;
	}
	void SetFileName(int arrayNo, CString fileName, int fileNameLength){	// S7F19/20
		this->FName_TBL[arrayNo].fileName	= fileName;
		this->FName_TBL[arrayNo].nameLength	= fileNameLength;
	}
	void SetFileCount(int cnt){												// S7F19/20
		this->fileNameCount = cnt;
	}
	void SetPPRecipeSendReqEvent(CEventX* pEvStartOK);		// S7F25/26 �C�x���g�̃Z�b�g
	void SetPPSelectReqEvent(CEventX* pEvSelectReq);		// S2F41/42 �C�x���g�̃Z�b�g
	void SetPPStartReqEvent(CEventX*,CEventX*);				// S2F41/42 �C�x���g�̃Z�b�g
	void ResetPPSelectReqEvent();							// S2F41/42 �C�x���g�̎g�p�֎~��
	void SetSoftRev(CString rev){
		this->softRevision = rev;
	}
	// �z�X�g���烍�[�h���ꂽ�����Z�b�g
	void SetLoadedByHost(int portNo, bool loaded){
		this->loadedByHost[portNo]	= loaded;		// portNo-1����Ȃ��撍��
	}
// #MO20131101 [�ǉ�] SoftComGem300�@�\���g�p���Ă��邩�ǂ������Z�b�g
	void SetuseSoftComGem300(bool use){
		this->useSoftComGem300 = use;
	}
	////////////////
	BOOL SendPPTime(int &element1);
	BOOL SendPPForce(int &element1);
	BOOL SendPPTemp(int &element1);
	BOOL SendPPLevel(int &element1);
	BOOL SendPPVacuumOffDelay(int &element1);
	BOOL SendPPOverTravel(int &element1);
	BOOL SendPPBgLevel(int &element1);
	BOOL SendPPSearchLevel(int &element1);
	BOOL SendPPSearchSpeed(int &element1);
	BOOL SendPPReturnLevel(int &element1);
	BOOL SendPPReturnSpeed(int &element1);
	BOOL SendPPReturnVacuumOffTiming(int &element1);
	BOOL SendPPBlowOffTiming(int &element1);
	BOOL SendPPChipThickness(int &element1);
	BOOL SendPPBondingHoldTime(int &element1);
	BOOL SendPPBackgroundTemp(int &element1);
	BOOL SendPPTempWhenHeadRises(int &element1);
	////////////////
	// bgMode
	void SetBgMode(int mode){
		this->bgMode = mode;
	}
	////////////////
	// stack
	void SetPPNumberOfStack(int stack){
		this->numberOfStack = stack;
	}
	////////////////
	// ChipThickness
	void SetChipThickness(int icType, double thickness){
		this->chipThickness[icType-1] = thickness;
	}
	////////////////
	// BgLevel
	void	SetBgLevel(int icType, double bglevel){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].FData[0].BgLevel = bglevel;
	}
	////////////////
	// SearchSpeed
	void SetSrchSpeed(int icType, double speed){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].FData[0].SachSpeed = speed;
	}
	////////////////
	// SearchLevel
	void SetSrchLevel(int icType, double level){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].FData[0].SachLevel = level;
	}
	////////////////
	// ReturnSpeed
	void SetRetnSpeed(int icType, double speed){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].FData[0].RetnSpeed = speed;
	}
	////////////////
	// ReturnLevel
	void SetRetnLevel(int icType, double level){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].FData[0].RetnLevel = level;
	}
	////////////////
	// Over Travel
	void	SetSinkLevel(int icType, int sCount, double level){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(sCount < 0)||(sCount >= STACK_Max)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d, sCount=%d", __FILE__, __LINE__, icType, sCount);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].FData[sCount].SinkLevel = level;
	}

	// �p���X�q�[�g
	////////////////
	// time
	void SetTime(int icType, int sCount, int step, double time){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(sCount < 0)||(sCount >= STACK_Max)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d, sCount=%d", __FILE__, __LINE__, icType, sCount);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].PData[sCount].Time[step] = time;
	}
	////////////////
	// force
	void SetForce(int icType, int sCount, int step, double force){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(sCount < 0)||(sCount >= STACK_Max)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d, sCount=%d", __FILE__, __LINE__, icType, sCount);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].PData[sCount].Force[step] = force;
	}
	////////////////
	// temp
	void SetTemp(int icType, int sCount, int step, double temp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(sCount < 0)||(sCount >= STACK_Max)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d, sCount=%d", __FILE__, __LINE__, icType, sCount);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].PData[sCount].Temp[step] = temp;
	}
	////////////////
	// IC�z���j��OFF���ݸ�
	void	SetPulse_ICBlowOFFSel(int icType, int blow){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].PData[0].ICBlowOFFSel = blow;
	}
	////////////////
	// IC�z��OFF���ݸ�
	void	SetPulse_VacuumOFF_Timing(int icType, int timing){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].PData[0].VacuumOFF_Timing = timing;
	}
	////////////////
	// BackGroundTemp
	void SetBackGroundTemp(int icType, int sCount, double temp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(sCount < 0)||(sCount >= STACK_Max)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d, sCount=%d", __FILE__, __LINE__, icType, sCount);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].PData[sCount].BackGroundTemp = temp;
	}
	////////////////
	// Temp_WhenHeadRises
	void SetTemp_WhenHeadRises(int icType, int sCount, double temp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(sCount < 0)||(sCount >= STACK_Max)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d, sCount=%d", __FILE__, __LINE__, icType, sCount);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].PData[sCount].Temp_WhenHeadRises= temp;
	}
	////////////////
	// �z���n�e�e�f�B���[
	void SetVCOffDelay_Steps(int icType, int sCount, double delay){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(sCount < 0)||(sCount >= STACK_Max)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d, sCount=%d", __FILE__, __LINE__, icType, sCount);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].PData[sCount].VCOffDelay = delay;
	}

	// ���[�J�����t���[
	////////////////
	// Time(����)
	void SetStepA_Time(int icType, int step, double time){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= BGH_BG_Step_Max )){
			CString msg;
			msg.Format("Error %s(%d) icType=%d,step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.StepA_Time[step] = time;
	}
	////////////////
	// Temp(����)
	void SetStepA_Temp(int icType, int step, double temp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= LocalReflow_StepMax_A )){
			CString msg;
			msg.Format("Error %s(%d) icType=%d,step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.StepA_Temp[step] = temp;
	}
	////////////////
	// Level(����)
	void SetStepA_Displace(int icType, int step, double disp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= LocalReflow_StepMax_A )){
			CString msg;
			msg.Format("Error %s(%d) icType=%d,step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.StepA_Displace[step] = disp;
	}
	////////////////
	// Time(���`)
	void SetStepB_Time(int icType, int step, double time){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= LocalReflow_StepMax_B )){
			CString msg;
			msg.Format("Error %s(%d) icType=%d,step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.StepB_Time[step] = time;
	}
	////////////////
	// Level(���`)
	void SetStepB_Displace(int icType, int step, double disp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= LocalReflow_StepMax_B )){
			CString msg;
			msg.Format("Error %s(%d) icType=%d,step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.StepB_Displace[step] = disp;
	}
	////////////////
	// Time(�~��)
	void SetStepC_Time(int icType, int step, double time){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= LocalReflow_StepMax_C )){
			CString msg;
			msg.Format("Error %s(%d) icType=%d,step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.StepC_Time[step] = time;
	}
	////////////////
	// Temp(�~��)
	void SetStepC_Temp(int icType, int step, double temp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= LocalReflow_StepMax_C )){
			CString msg;
			msg.Format("Error %s(%d) icType=%d,step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.StepC_Temp[step] = temp;
	}
	////////////////
	// Level(�~��)
	void SetStepC_Displace(int icType, int step, double disp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= LocalReflow_StepMax_C )){
			CString msg;
			msg.Format("Error %s(%d) icType=%d,step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.StepC_Displace[step] = disp;
	}
	////////////////
	// force
	void SetLocal_Force(int icType, int step, double force){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)||(step < 0)||(step >= BGH_BG_Step_Max)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d, step = %d", __FILE__, __LINE__, icType, step);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.Force[step] = force;
	}
	////////////////
	// �z���n�e�e�f�B���[
	void	SetLocal_VCOffDelay(int icType, double delay){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.VCOffDelay = delay;
	}
	////////////////
	// IC�z���j��OFF���ݸ�
	void	SetLocalICBlowOFFSel(int icType, int blow){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.ICBlowOFFSel = blow;
	}
	////////////////
	// IC�z��OFF���ݸ�
	void	SetLocalVacuumOFF_Timing(int icType, int timing){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.VacuumOFF_Timing = timing;
	}
	////////////////
	// BackGroundTemp
	void SetLocal_BackGroundTemp(int icType, double temp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.BackGroundTemp = temp;
	}
	////////////////
	// Temp_WhenHeadRises
	void SetLocal_Temp_WhenHeadRises(int icType, double temp){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].LData.Temp_WhenHeadRises = temp;
	}
	////////////////
	// �׏d�ێ�����
	void SetLocal_PressHoldTime(int icType, double time){
		// ���O����(S)
		if((icType < 1)||(icType > IC_TypeMax)){
			CString msg;
			msg.Format("Error %s(%d) icType=%d", __FILE__, __LINE__, icType);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}// ���O����(E)
		this->secsPPData[icType-1].FData[0].pressHoldTime = time;
	}

public:
	int count_S1F13;			//S1F13�𑗐M������
	bool goRemote;				//�I�����C�������[�g�ڍs�t���O
	bool goLocal;				//�I�����C�����[�J���ڍs�t���O
	bool goOffline;				//�I�t���C���ڍs�t���O
	BOOL initCarrierObj_flg;	//�c���Ă���S�L�����A�I�u�W�F�N�g�̏�����(���o)�t���O
///////////////////////////
//
// Error
//
	enum{		// �װNo.
		Err_ProjectNotOpened1			= 1,	// (+ 1)
		Err_ProjectNotOpened2,					// (+ 2)
		Err_Dlg300_03,							// (+ 3)
		Err_Dlg300_04,							// (+ 4)
		Err_CarrierLoadFailed,					// (+ 5)
		Err_Dlg300_06,							// (+ 6)
		Err_SlotMapRead1,						// (+ 7)
		Err_SlotMapRead2,						// (+ 8)
		Err_CarrierIsNotUnload,					// (+ 9)
		Err_Dlg300_10,							// (+10)
		Err_CarrierNotRecognizedB,				// (+11)
		Err_CarrierNotRecognizedT,				// (+12)
		Err_BottomWaferIsAlreadyComplete,		// (+13)
		Err_TopWaferIsAlreadyComplete,			// (+14)
		Err_TopCarrierIsNotCreated,				// (+15)
		Err_TopReadIDCanceled,					// (+16)
		Err_TopSlotMapCanceled,					// (+17)
		Err_BottomReadIdCanceled,				// (+18)
		Err_BottomSlotMapCanceled,				// (+19)
		Err_TopCJPJCreateTimingIsTooFast,		// (+20) 
		Err_BottomCJPJCreateTimingIsTooFast,	// (+21)
		Err_CreatePJFailed,						// (+22)
		Err_CreateCJFailed,						// (+23)
		Err_EmptyPJInCJ,						// (+24)
		Err_CrJobCreateFail1,					// (+25)
		Err_InvalidKeyValue1,					// (+26)
		Err_InvalidKeyValue2,					// (+27)
		Err_Gem300ProjectNotOpened,				// (+28) #MO20131105[�ǉ�]Gem300NG�p�̃G���[�쐬�E�\��
		Err_Dlg300_29,							// (+29)
	};
	enum InternalError{
		// 
		eErr_0x00008101		= 0x00008101,
		eErr_0x00008102		= 0x00008102,
		eErr_0x00008103		= 0x00008101,
		eErr_0x00008105		= 0x00008101,
		eErr_0x00008111		= 0x00008111,
		eErr_0x00008302		= 0x00008302,
		eErr_0x00008303		= 0x00008303,
		eErr_0x00008304		= 0x00008304,
		eErr_0x00008305		= 0x00008305,
		eErr_0x00008306		= 0x00008306,
		eErr_0x00008307		= 0x00008307,
		eErr_0x0000fd01		= 0x0000fd01,
		eErr_0x0000fd0c		= 0x0000fd0c,
		eErr_0x0000fdff		= 0x0000fdff,
		//
		eErr_0x48000018		= 0x48000018,	// CEID��"����"���
		// CMS�̃G���[
		eErr_0x60040007		= 0x60040007,
		eErr_0x6004102a		= 0x6004102a,
		//
		eErr_0xc600b105		= 0xc600b105,
		eErr_0xc600b205		= 0xc600b205,
	};
	// �I�[�o�[���C�h
	// ClassWizard �͉��z�֐��̃I�[�o�[���C�h�𐶐����܂��B
	//{{AFX_VIRTUAL(DlgSG300)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g
	//}}AFX_VIRTUAL

// �C���v�������e�[�V����
protected:

	// �������ꂽ���b�Z�[�W �}�b�v�֐�
	//{{AFX_MSG(DlgSG300)
	afx_msg void OnInfoComStateXcomsecsctrl1(short com_state, short hst_sts, short eq_sts);
	afx_msg void OnInfoControlStateEventXcomsecsctrl1(short state);
	afx_msg void OnGetSecsEventXcomsecsctrl1(LPCTSTR event_name);
	afx_msg void OnInfoCarrierIdStateEventSg300cmsctrl1(short ptn, const VARIANT FAR& carrierid, short state);
	afx_msg void OnInfoSlotMapStateEventSg300cmsctrl1(short ptn, const VARIANT FAR& carrierid, const VARIANT FAR& slotmap, short slotcount, short state);
	afx_msg void OnGetServiceEventSg300cmsctrl1(LPCTSTR service_name);
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnLinkXComChangedXcomsecsctrl1(short ocx_type, short status);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ �͑O�s�̒��O�ɒǉ��̐錾��}�����܂��B

#endif // !defined(AFX_DLGSG300_H__94B9D1F1_650C_4EEA_AC8C_0A62A4B2FFA3__INCLUDED_)

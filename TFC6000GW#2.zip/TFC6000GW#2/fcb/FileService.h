// FileService.h: FileService �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILESERVICE_H__D77B3014_EC6F_4015_A30E_D3A8C7E3FBB1__INCLUDED_)
#define AFX_FILESERVICE_H__D77B3014_EC6F_4015_A30E_D3A8C7E3FBB1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFileService  
{
public:
	CFileService();
	virtual ~CFileService();

	int		CutOverFiles( const char *path, const char *file, int num );
	int		CountFilesInFolder( const char *path, const char *file );

};

#endif // !defined(AFX_FILESERVICE_H__D77B3014_EC6F_4015_A30E_D3A8C7E3FBB1__INCLUDED_)

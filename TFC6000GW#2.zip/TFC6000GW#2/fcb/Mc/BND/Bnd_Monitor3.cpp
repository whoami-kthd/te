// #OZ20150725 US�o�͒l�����j�^�[�\�� (S)
/*---------------------------------------------------------------------
	�{���f�B���O���H�_���j�^�����O ����

	Edition History
	 #   Date     Changes Made
	 #YM1001 2001-09-25 ���H�_����ݸދ@�\�ǉ�
	 (Bnd_Monitor.cpp�Ƃ��Ēǉ�)
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	<mcc.h>
#include	<iodef.h>
#include	"BNDiodef.h"
#include	"WMonitorDlg.h"							//�g�`�\���p
#include	<direct.h>
#include	<stdlib.h>
#include	<stdio.h>
#include	"tpc.h"
#include	"Tpctrl.h"

// #NK120410-10 [�ڐA]�v���Z�X���j�^�����O�@�\(TFC900A�x�[�X��TFC6000�p)
#define		BGH_DSP			bond.pBGHD
//���H�_����ݸދ@�\
#define		Monitor 		pMCC->MD.OptionF.MonitorFlg //���H�_����ݸދ@�\�̎g�p�̗L��
#define		BgDisplay   	pMCC->DD.ModeD.BgDisplayFlg //�g�`�\���̗L��
#define		BgSave  		pMCC->DD.ModeD.BgSaveFlg	//�g�`����ۑ��̗L��
#define		BgLogSave  		pMCC->DD.ModeD.BgLogSaveFlg	//BG۸�(�ő�l��)�ۑ��̗L��
#define		S_Wave			pMCC->DD.ModeD.Sel_Wave		//�g�`�\�����ڑI��
#define		ASel_Wave		pMCC->MD.OptionD.Air_Sel_Wave	//�g�`�\�����ڑI��AirCylinder	
#define		MSel_Wave		pMCC->MD.OptionD.Motor_Sel_Wave	//�g�`�\�����ڑI��AirCylinder	
// #NK120410-10 [�ڐA]�v���Z�X���j�^�����O�@�\(TFC900A�x�[�X��TFC6000�p)
#define		AveFlg			pMCC->MD.OptionF.AvePlotFlg	//���ω��\���I��
#define		AveTime_D		pMCC->MD.OptionF.AveTime_D	//�ړ����ω�����(�ψ�)
#define		AveTime_F		pMCC->MD.OptionF.AveTime_F	//�ړ����ω�����(�׏d)
#define		AveTime_T		pMCC->MD.OptionF.AveTime_T	//�ړ����ω�����(���x)
// #NK120410-10 [�ڐA]�v���Z�X���j�^�����O�@�\(TFC900A�x�[�X��TFC6000�p)
#define		AveTime_G		pMCC->MD.OptionF.AveTime_G	//�ړ����ω�����(Gap)


//XMP����؂܂���̧�ق���ǂݍ��܂ꂽ�ް��̕\��(�׏d��ψʥ���x)
// #OZ20150725 US�o�͒l�����j�^�[�\��	
#if 1
bool BNDCtrl::BG_MonitorDataPlot5(int Ssw,bool mode)
{
	bool r=true;
// #NK120410-10 [�ڐA]�v���Z�X���j�^�����O�@�\(TFC900A�x�[�X��TFC6000�p)-S
	if ( 1==BGH_DSP->GetMonitorMode() ) {
		return false;	// US �Œ�׏d�͗L�蓾�Ȃ�
	}
// #NK120410-10-E

//	int	bgmode = bond.GetBgMode();
	int	bgmode = 3;
	int	sw = Ssw & 0x07;

	if(PlotFlg&&BgDisplay&&sw){
		//�ړ����ώZ�o�p�ϐ�
		int k,Coeff;//k:�ړ����ϕ��Z�o�ϐ��ACoeff:�ړ����ώZ�o���̃f�[�^No(�W��)���ex) PActPos[Coeff]
		int R_End;  //�ړ����ώZ�o�J��Ԃ����Z��(R_End=4*AveTime+1 AveTime:�ړ����ϕ����AveTime=1[ms]�Ȃ�Ίe����ْl�́}1[ms]�̃f�[�^���g�p�����ϒl�Z�o)
		double Each_Data,M_Ave;
		int right,left,top,bottom;
		CString	Scale;				// ���̕\���p�ڐ���i�[�ϐ�
		CWnd	*pWnd=displayDlg;
		CDC*pDC = pWnd->GetDC( );
		RECT	rect;
		pWnd->GetWindowRect(&rect);
		left  = rect.left;
		top   = rect.top;
		right = rect.right-rect.left;
		bottom= rect.bottom-rect.top;
		CRgn Area;
		Area.CreateRectRgn(0,0,right,bottom);
		CBrush Wh_bh(RGB(255,255,255));
		pDC->SelectObject(&Wh_bh);
		pDC->PaintRgn(&Area);
		//�\���p�t�H���g�̐ݒ�
		CFont PL_Font;
		PL_Font.CreateFont(14,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,SHIFTJIS_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
			DEFAULT_PITCH|FF_DONTCARE,"MS P�S�V�b�N");
		pDC->SelectObject(&PL_Font);
		pDC->SetTextColor(RGB(0,0,0));
		//BaseGraph�̍쐬
		CPen RD_Pen,BK_Pen,BL_Pen,BK_DotPen;
		RD_Pen.CreatePen(PS_SOLID,1,RGB(255,0,0));
		BK_Pen.CreatePen(PS_SOLID,1,RGB(0,0,0));
		BL_Pen.CreatePen(PS_SOLID,1,RGB(0,0,255));
		BK_DotPen.CreatePen(PS_DASH ,1,RGB(0,0,0));
		pDC->SelectObject(&BK_Pen);

//		bool Wave_FAct = false;	// �׏d��Act�͕\�����Ȃ�
		bool Wave_FAct = true;	// �׏d��Act�͉׏dL�Ƃ��ĕ\������

		int wave_count = 0;
#if 0
		if ( pMCC->DD.ModeD.eWave_P & sw )	wave_count++;
		if ( pMCC->DD.ModeD.eWave_F & sw )	wave_count++;
		if ( pMCC->DD.ModeD.eWave_G & sw )	wave_count++;
		if ( pMCC->DD.ModeD.eWave_T & sw )	wave_count++;
#endif
		// #DongKD(20141013) Update reading wave selection from mc_.000 
		// Check wave selection in case of motor 
		switch( sw ){
		case	1:
			wave_count = 3;
			break;
		case	2:
			wave_count = 2;
			break;
		case	3:
			wave_count = 1;
			break;
		case	4:
			wave_count = 2;
			break;
		case	5:
			wave_count = 1;
			break;
		case	6:
			wave_count = 1;
			break;
		case	7:
			wave_count = 2;
			break;
		default:
			wave_count = 3;
			break;
		}
		if( bgmode == 3 ){
			wave_count ++;
		}

		// #DongKD(20141013) Update reading wave selection from mc_.000 
		int wave_hight = 0;
			 if ( 4==wave_count )	wave_hight = 27;
		else if ( 3==wave_count )	wave_hight = 36;
		else if ( 2==wave_count )	wave_hight = 54;
		else						wave_hight =108;

		int Hight = 108;
		int A,B,C,D,E,F,G;
			A = (int)(bottom*115/120-5);
			B = (int)(bottom*110/120-5);
//			C = (int)(bottom*83/120-5);
			C = (int)(bottom*(110-Hight/wave_count*1)/120-5);
//			D = (int)(bottom*56/120-5);
			D = (int)(bottom*(110-Hight/wave_count*2)/120-5);
//			E = (int)(bottom*29/120-5);
			E = (int)(bottom*(110-Hight/wave_count*3)/120-5);
			F = (int)(bottom*2/120-5);
			G = (int)(right*15/160-5);
		//���Ԏ�
	//	pDC->MoveTo(left,A);
	//	pDC->LineTo(right,A);
		//
		pDC->MoveTo(0,B);
		pDC->LineTo(right,B);

		if ( 4==wave_count ) {
			pDC->MoveTo(0,C);
			pDC->LineTo(right,C);
			pDC->MoveTo(0,D);
			pDC->LineTo(right,D);
			pDC->MoveTo(0,E);
			pDC->LineTo(right,E);
		} else if ( 3==wave_count ) {
			pDC->MoveTo(0,C);
			pDC->LineTo(right,C);
			pDC->MoveTo(0,D);
			pDC->LineTo(right,D);
		} else if ( 2==wave_count ) {
			pDC->MoveTo(0,C);
			pDC->LineTo(right,C);
		}

		pDC->MoveTo(0,F);
		pDC->LineTo(right,F);
		//�c��
		pDC->MoveTo(G,bottom);
		pDC->LineTo(G,0);

		int H,I,J,K,L,M,N,P,Q;
		H=(int)(right*2/160);
		I=(int)(bottom*106/120);
		if ( 4==wave_count ) {
			J=(int)(bottom*96/120);
			K=(int)(bottom*69/120);
			L=(int)(bottom*42/120);
			Q=(int)(bottom*15/120);
		} else if ( 3==wave_count ) {
			J=(int)(bottom*92/120);
			K=(int)(bottom*56/120);
			L=(int)(bottom*20/120);
		} else if ( 2==wave_count ) {
			J=(int)(bottom*83/120);
			K=(int)(bottom*29/120);
		} else {
			J=(int)(bottom*56/120);
		}

		M=(int)(bottom*4/120)+1;
		N=(int)(right*5/128);
		P=(int)(bottom*1/160);

		pDC->TextOut(H-4,I-4,"Time");
		pDC->TextOut(H-4,I+M-4," [ms]");

		CString Lavel[4], Unit[4];
		if( 4==wave_count ){
			Lavel[3].Format( "Temp" );
			Unit[3].Format( "[V]" );
			Lavel[2].Format( "US" );
			Unit[2].Format( "[v]" );
			Lavel[1].Format( "Force" );
			Unit[1].Format( "[N]" );
			Lavel[0].Format( "Pos" );
			Unit[0].Format( "[mm]" );
			pDC->TextOut(H-4,J-4,Lavel[3]);
			pDC->TextOut(H-4,J+M-4,Unit[3]);
			pDC->TextOut(H-4,K-4,Lavel[2]);
			pDC->TextOut(H-4,K+M-4,Unit[2]);
			pDC->TextOut(H-4,L-4,Lavel[1]);
			pDC->TextOut(H-4,L+M-4,Unit[1]);
			pDC->TextOut(H-4,Q-4,Lavel[0]);
			pDC->TextOut(H-4,Q+M-4,Unit[0]);
		} else if( 3==wave_count ){
			// #DongKD(20141013) Update reading wave selection from mc_.000 
			if( (sw == 1) || (sw == 2) ){
				Lavel[0].Format( "Pos" );
				Unit[0].Format( "[mm]" );
				Lavel[1].Format( "Force" );
				Unit[1].Format( "[N]" );
				if( sw == 1 ){
					Lavel[2].Format( "Temp" );
					Unit[2].Format( "[V]" );
				} else {
					Lavel[2].Format( "US" );
					Unit[2].Format( "[v]" );
				}
			} else
			if( sw == 4 ){
				Lavel[0].Format( "Force" );
				Unit[0].Format( "[N]" );
				Lavel[1].Format( "US" );
				Unit[1].Format( "[V]" );
				Lavel[2].Format( "Temp" );
				Unit[2].Format( "[V]" );
			} else {
				Lavel[0].Format( "Pos" );
				Unit[0].Format( "[mm]" );
				Lavel[1].Format( "US" );
				Unit[1].Format( "[v]" );
				Lavel[2].Format( "Temp" );
				Unit[2].Format( "[V]" );
			}
			// #DongKD(20141013) Update reading wave selection from mc_.000 
			
			pDC->TextOut(H-4,J-4,Lavel[2]);
			pDC->TextOut(H-4,J+M-4,Unit[2]);
			pDC->TextOut(H-4,K-4,Lavel[1]);
			pDC->TextOut(H-4,K+M-4,Unit[1]);
			pDC->TextOut(H-4,L-4,Lavel[0]);
			pDC->TextOut(H-4,L+M-4,Unit[0]);
		}else if( 2==wave_count ){
			// #DongKD(20141013) Update reading wave selection from mc_.000 
			if( sw == 2 ){
				Lavel[0].Format( "Pos" );
				Unit[0].Format( "[mm]" );
				Lavel[1].Format( "Force" );
				Unit[1].Format( "[N]" );		
			} else
			if( sw == 3 ){
				Lavel[0].Format( "Force" );
				Unit[0].Format( "[N]" );
				Lavel[1].Format( "US" );
				Unit[1].Format( "[V]" );
			} else
			if( sw == 4 ){
				Lavel[0].Format( "Force" );
				Unit[0].Format( "[N]" );					
				Lavel[1].Format( "Temp" );
				Unit[1].Format( "[V]" );
			} else
			if( sw == 5 ){
				Lavel[0].Format( "Pos" );
				Unit[0].Format( "[mm]" );
				Lavel[1].Format( "US" );
				Unit[1].Format( "[V]" );
			} else
			if( sw == 6 ){
				Lavel[0].Format( "US" );
				Unit[0].Format( "[V]" );
				Lavel[1].Format( "Temp" );
				Unit[1].Format( "[V]" );
			} else {
				Lavel[0].Format( "Pos" );
				Unit[0].Format( "[mm]" );
				Lavel[1].Format( "Temp" );
				Unit[1].Format( "[V]" );
			}
			// #DongKD(20141013) Update reading wave selection from mc_.000 
			pDC->TextOut(H-4,J-4,Lavel[1]);
			pDC->TextOut(H-4,J+M-4,Unit[1]);
			pDC->TextOut(H-4,K-4,Lavel[0]);
			pDC->TextOut(H-4,K+M-4,Unit[0]);
		} else {
			if( sw == 3 ){
				Lavel[0].Format( "Force" );
				Unit[0].Format( "[N]" );
			} else
			if( sw == 5 ){
				Lavel[0].Format( "Pos" );
				Unit[0].Format( "[mm]" );
			} else {
				Lavel[0].Format( "Temp" );
				Unit[0].Format( "[V]" );
			}
			pDC->TextOut(H-4,J-4,Lavel[0]);
			pDC->TextOut(H-4,J+M-4,Unit[0]);
		}
		long index;
		if(mode)
			if(MoniIndex)index=MoniIndex-1;
			else		 index=MoniMaxSize-1;
		else	 index=FileSize;//̧�ق���ǂݍ��񂾌��ʂ͊m�ۂ����̈�̍Ō�Ɋi�[���Ă���B

		long num=monidata[index].Rec_Count-2;

		//�v�������̕\��
		pDC->TextOut((int)(right*93/160),F+5,"Measurement Date(Y_M_D_H_M_S)");
		Scale.Format("%s",monidata[index].date);
		pDC->TextOut((int)(right*108/160),F+20,Scale);

//		//�v�����x�̕\��
//		CString	Temperature;
//		Temperature.Format("Tool Temperature : %3.0f [��]",monidata[index].Start_F);
//		pDC->TextOut((int)(right*108/160),F+35,Temperature);

		//num=num-2;
		//�e�g�`�̕\��
		double Coeff_X_Chk=(double)num/(double)(right*145/160);
		int Coeff_X;
		int OffsetX=G;
		int i,j=1;	//Repeat�p�ϐ�
		int y;//�\���p���W�f�[�^
		//���Ԃ̕\��
		pDC->SelectObject(&BK_DotPen);//�j���ݒ�
		Scale.Format("%1.0f",monidata[index].SampleCou[0]);
		pDC->TextOut(OffsetX-10,I+M-3,Scale);
		if(Coeff_X_Chk>1.0){
			Coeff_X=(int)(num/(right*145/160))+1;//��΂��f�[�^����ݒ肵�A1dot�Ԋu�ŕ\��������B
			for(i=Coeff_X*100;i<num;i+=Coeff_X*100){
					Scale.Format("%4.0f",monidata[index].SampleCou[i]);
					pDC->TextOut(OffsetX+i/Coeff_X,I+M-3,Scale);
					pDC->MoveTo(OffsetX+i/Coeff_X,A);
					pDC->LineTo(OffsetX+i/Coeff_X,0);
			}
		}else{
			Coeff_X=(int)((right*145/160)/num);//��΂��f�[�^����ݒ肵�A1dot�Ԋu�ŕ\��������B
			for(i=40;i<num;i+=40){
					Scale.Format("%4.0f",monidata[index].SampleCou[i]);
					pDC->TextOut(OffsetX+i*Coeff_X-10,I+M-3,Scale);
					pDC->MoveTo(OffsetX+i*Coeff_X,A);
					pDC->LineTo(OffsetX+i*Coeff_X,0);
			}
		}
		pDC->SelectObject(&BK_Pen);//�����ɖ߂�

	// ----------------------------------------------
		//�e�ް��̍ő�E�ŏ��l�擾
		double PC_Max,PA_Max,FC_Max,FA_Max,Us_Max,Te_Max;
		double PC_Min,PA_Min,FC_Min,FA_Min,Us_Min,Te_Min;

		if( (sw == 1) || (sw == 2) || (sw == 5) || (sw == 7) ){
			PC_Max = PC_Min=monidata[index].PCmdPos[0];
			PA_Max = PA_Min=monidata[index].PActPos[0];
			for( i=0 ; i<num ; i++ ){
				if( monidata[index].PCmdPos[i] > PC_Max )
					PC_Max = monidata[index].PCmdPos[i];
				if( monidata[index].PCmdPos[i] < PC_Min )
					PC_Min = monidata[index].PCmdPos[i];
				if( monidata[index].PActPos[i] > PA_Max )
					PA_Max = monidata[index].PActPos[i];
				if( monidata[index].PActPos[i] < PA_Min )
					PA_Min = monidata[index].PActPos[i];
			}
		}
		if( (sw == 1) || (sw == 2) || (sw == 3) || (sw == 4) ){
			FC_Max = FC_Min=monidata[index].FCmdPos[0];
			FA_Max = FA_Min=monidata[index].FActPos[0];
			for( i=0 ; i<num ; i++ ){
				if( monidata[index].FCmdPos[i]>FC_Max )
					FC_Max = monidata[index].FCmdPos[i];
				if( monidata[index].FCmdPos[i]<FC_Min )
					FC_Min = monidata[index].FCmdPos[i];
				if( monidata[index].FActPos[i]>FA_Max )
					FA_Max = monidata[index].FActPos[i];
				if( monidata[index].FActPos[i]<FA_Min )
					FA_Min = monidata[index].FActPos[i];
			}
		}
		if ((sw == 1) || (sw == 4) || (sw == 6) || (sw == 7) ){
			Te_Max = Te_Min = monidata[index].TempOut[0];
			for( i=0 ; i<num ; i++ ){
				if( monidata[index].TempOut[i]>Te_Max )
					Te_Max = monidata[index].TempOut[i];
				if( monidata[index].TempOut[i]<Te_Min )
					Te_Min = monidata[index].TempOut[i];
			}
		}
		if( bgmode == 3 ){
			Us_Max = Us_Min = monidata[index].UsValue[0];
			for( i=0 ; i<num ; i++ ){
				if( monidata[index].UsValue[i]>Us_Max )
					Us_Max = monidata[index].UsValue[i];
				if( monidata[index].UsValue[i]<Us_Min )
					Us_Min = monidata[index].UsValue[i];
			}
		}

// ----------
		//�ψʂ̕\��
//		if ( pMCC->DD.ModeD.eWave_P & sw ) {
// #DongKD(20141013) Update reading wave selection from mc_.000 
		if ((sw == 1) || (sw == 2) || (sw == 5) || (sw == 7) ) {
			double D_Max,D_Min;
			if(PC_Max>=PA_Max) D_Max=PC_Max;
			else			   D_Max=PA_Max;
			if(PA_Min>=PC_Min) D_Min=PC_Min;
			else			   D_Min=PA_Min;

			int D_OffsetY=F;

			double hight = wave_hight;

			double D_Coeff_Y_Chk=(D_Max-D_Min)/(bottom*hight/120);//�\���̍ۂ̊g��/�k������
			int D_Coeff_Y;
			//�ψʂ���ؕ\��
			Scale.Format("%3.0f",D_Min);
			pDC->TextOut(H+N,2*P+D_OffsetY,Scale);
			if(D_Coeff_Y_Chk<1.0){//�ψʕ����O���t�c���͈�dot����葽�����H������Ώk��/���Ȃ���Ίg�債�ĕ\��
				if((D_Max-D_Min)==0)
					D_Coeff_Y=0;
				else
					D_Coeff_Y=(int)((bottom*hight/120)/(D_Max-D_Min));//�ψʏc���̔{���ݒ�
				//�ψʂ���ؕ\��
				if((int)D_Max-(int)D_Min){
					Scale.Format("%3.0f",D_Max);
					pDC->TextOut(H+N,-5*P+(int)(D_Max*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y),Scale);
					pDC->MoveTo(G,(int)(D_Max*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y));
					pDC->LineTo(G+H,(int)(D_Max*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y));
				}
				//�ψʔg�`(����)�\��
				//�w��
				pDC->SelectObject(&BL_Pen);
				pDC->MoveTo(OffsetX,(int)(monidata[index].PCmdPos[0]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y));//�����ʒu(��_)�ړ�
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						y=(int)(monidata[index].PCmdPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						y=(int)(monidata[index].PCmdPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
				//�o��
				j=1;
				pDC->SelectObject(&RD_Pen);
				pDC->MoveTo(OffsetX,(int)(monidata[index].PActPos[0]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						if(AveFlg){
							M_Ave=0.0;
							Each_Data=0.0;

							R_End=(int)(4.0*AveTime_D)+1;
							for(k=1;k<=R_End;k++){//�}AveTime[ms]����
								Coeff=i-((int)(-2.0*AveTime_D)+k-1);
								if((Coeff>=0) && (Coeff<num))
										Each_Data=monidata[index].PActPos[Coeff];
								else	Each_Data=0.0;
								M_Ave+=1.0/((double)R_End)*Each_Data;
							}
							if(M_Ave>=D_Min) y=(int)(M_Ave*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
							else		     y=(int)(monidata[index].PActPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);//���ϒl���ŏ��l�������ꍇ�A���f�[�^�\��
							pDC->LineTo(OffsetX+j,y);
							j++;
						}else{
							y=(int)(monidata[index].PActPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
							pDC->LineTo(OffsetX+j,y);
							j++;
						}
					}
				}else{
					for(i=1;i<num-1;i++){
						if(AveFlg){
							M_Ave=0.0;
							Each_Data=0.0;

							R_End=(int)(4.0*AveTime_D)+1;
							for(k=1;k<=R_End;k++){//�}AveTime[ms]����
								Coeff=i-((int)(-2.0*AveTime_D)+k-1);
								if((Coeff>=0) && (Coeff<num))
										Each_Data=monidata[index].PActPos[Coeff];
								else	Each_Data=0.0;
								M_Ave+=1.0/((double)R_End)*Each_Data;
							}
							if(M_Ave>=D_Min) y=(int)(M_Ave*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
							else			 y=(int)(monidata[index].PActPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);//���ϒl���ŏ��l�������ꍇ�A���f�[�^�\��
							pDC->LineTo(OffsetX+i*Coeff_X,y);
						}else{
							y=(int)(monidata[index].PActPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
							pDC->LineTo(OffsetX+i*Coeff_X,y);
						}
					}
				}

			}else{
				D_Coeff_Y=(int)((D_Max-D_Min)/(bottom*hight/120))+1;//�ψʏc���̔{���ݒ�
				//�ψʂ���ؕ\��
			//	Scale.Format("%.2f",D_Min);
			//	pDC->TextOut(H+N,2*P+D_OffsetY,Scale);
				if((int)D_Max-(int)D_Min){
					Scale.Format("%3.0f",D_Max);
					pDC->TextOut(H+N,-5*P+(int)(D_Max/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y),Scale);
					pDC->MoveTo(G,(int)(D_Max/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y));
					pDC->LineTo(G+H,(int)(D_Max/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y));
				}
				//�ψʔg�`(����)�\��
				//�w��
				pDC->SelectObject(&BL_Pen);
				pDC->MoveTo(OffsetX,(int)(monidata[index].PCmdPos[0]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						y=(int)(monidata[index].PCmdPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						y=(int)(monidata[index].PCmdPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}

				j=1;
				pDC->SelectObject(&RD_Pen);
				pDC->MoveTo(OffsetX,(int)(monidata[index].PActPos[0]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						if(AveFlg){
							M_Ave=0.0;
							Each_Data=0.0;

							R_End=(int)(4.0*AveTime_D)+1;
							for(k=1;k<=R_End;k++){//�}AveTime[ms]����
								Coeff=i-((int)(-2.0*AveTime_D)+k-1);
								if((Coeff>=0) && (Coeff<num))
										Each_Data=monidata[index].PActPos[Coeff];
								else	Each_Data=0.0;
								M_Ave+=1.0/((double)R_End)*Each_Data;
							}
							if(M_Ave>=D_Min) y=(int)(M_Ave/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
							else		     y=(int)(monidata[index].PActPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);//���ϒl���ŏ��l�������ꍇ�A���f�[�^�\��
							pDC->LineTo(OffsetX+j,y);
							j++;
						}else{
							y=(int)(monidata[index].PActPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
							pDC->LineTo(OffsetX+j,y);
							j++;
						}
					}
				}else{
					for(i=1;i<num-1;i++){
						if(AveFlg){
							M_Ave=0.0;
							Each_Data=0.0;

							R_End=(int)(4.0*AveTime_D)+1;
							for(k=1;k<=R_End;k++){//�}AveTime[ms]����
								Coeff=i-((int)(-2.0*AveTime_D)+k-1);
								if((Coeff>=0) && (Coeff<num))
										Each_Data=monidata[index].PActPos[Coeff];
								else	Each_Data=0.0;
								M_Ave+=1.0/((double)R_End)*Each_Data;
							}
							if(M_Ave>=D_Min) y=(int)(M_Ave/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
							else		     y=(int)(monidata[index].PActPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);//���ϒl���ŏ��l�������ꍇ�A���f�[�^�\��
							pDC->LineTo(OffsetX+i*Coeff_X,y);
						}else{
							y=(int)(monidata[index].PActPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
							pDC->LineTo(OffsetX+i*Coeff_X,y);
						}
					}
				}
			}
		}

// ----------
		//�׏d�̕\��
//		if ( pMCC->DD.ModeD.eWave_F & sw ) {
		// #DongKD(20141013) Update reading wave selection from mc_.000 
		if ((sw == 1) || (sw == 2) || (sw == 3) || (sw == 4) ) {
			j=1;
			double F_Max,F_Min;
			if(FC_Max>=FA_Max) F_Max=FC_Max;
			else			   F_Max=FA_Max;
			if(FA_Min>=FC_Min) F_Min=FC_Min;
			else			   F_Min=FA_Min;
			double F_Ave;
			F_Ave=BG_MonitorF_Average(FC_Max,mode);
			//�ő�׏d�̉�ʕ\��
			int Q,R,S;
			Q=(int)(right*117/160);
			R=(int)(right*140/160);

			int F_OffsetY;
			if( 4==wave_count ){
				S=(int)(bottom*29/120);
				F_OffsetY = D;
			} else if( 3==wave_count ){
				if ((sw == 1) || (sw == 4) || (sw == 6) || (sw == 7)) {
//					if (sw >= 8 && sw <= 15) {
						S=(int)(bottom*(2+5)/120);
						F_OffsetY = D;
//					} else {
//						S=(int)(bottom*(35+3)/120);
//						F_OffsetY = C;
//					}
				} else {
					S=(int)(bottom*(35+3)/120);
					F_OffsetY = C;
				}
			}else if( 2==wave_count ){
				if ((sw == 1) || (sw == 4) || (sw == 6) || (sw == 7)) {
					S=(int)(bottom*2/120+40);
					F_OffsetY = C;
				} else {
					S=(int)(bottom*2/120+40);
					F_OffsetY = C;
//				} else {
//					S=(int)(bottom*(56+2)/120);
//					F_OffsetY = B;
				}
			} else {
				S=(int)(bottom*2/120+40);
				F_OffsetY = B;
			}

			if ( false ) {	// ���ω׏d�͕\�������Ȃ�
				pDC->TextOut(Q,S,"AverageForce[N]=");
				Scale.Format("%.2f",F_Ave);
				pDC->TextOut(R,S,Scale);
			}

			double F_hight = wave_hight;

			//�׏d�̕\���͈͂�0����Ƃ���B
			//�����ʌ��׏d�Ǝ擾���ʂ���̍������Ƃ�ƕ��̒l����������B
			//���Ƃ��Ƃ́A���͈̔͂����̂܂ܕ\�����Ă������A���̏ꍇ��0�ɂ��ĕ\�����邱�ƂƂ����B
			//(���̉׏d�ɈӖ����Ȃ����߁B)
			double F_Coeff_Y_Chk=(F_Max)/(bottom*F_hight/120);//�\���̍ۂ̊g��/�k������
			int F_Coeff_Y;
			if(F_Coeff_Y_Chk<1.0){
				if((F_Max-F_Min)==0)
					F_Coeff_Y=0;
				else
					F_Coeff_Y=(int)((bottom*F_hight/120)/(F_Max));//�ψʏc���̔{���ݒ�(�g��)
				//�׏d����ؕ\��
				pDC->TextOut(OffsetX-20,-5*P+F_OffsetY,"0");
				Scale.Format("%3.0f",F_Max);
				pDC->TextOut(H+N,-P-(int)(F_Max*F_Coeff_Y)+F_OffsetY,Scale);
				pDC->SelectObject(&BK_Pen);
				pDC->MoveTo(G,-(int)(F_Max*F_Coeff_Y)+F_OffsetY);
				pDC->LineTo(G+H,-(int)(F_Max*F_Coeff_Y)+F_OffsetY);
				//�׏d�g�`(����)�\��
				pDC->SelectObject(&BL_Pen);
				if(monidata[index].FCmdPos[0]>=0)
					pDC->MoveTo(OffsetX,-(int)(monidata[index].FCmdPos[0]*F_Coeff_Y)+F_OffsetY);
				else
					pDC->MoveTo(OffsetX,F_OffsetY);
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						if(monidata[index].FCmdPos[i]>=0)
							y=-(int)(monidata[index].FCmdPos[i]*F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						if(monidata[index].FCmdPos[i]>=0)
							y=-(int)(monidata[index].FCmdPos[i]*F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
				j=1;
				if ( Wave_FAct ){	// �׏d��Act�͕\�����Ȃ�
					pDC->SelectObject(&RD_Pen);
					if(monidata[index].FActPos[0]>=0)
						pDC->MoveTo(OffsetX,-(int)(monidata[index].FActPos[0]*F_Coeff_Y)+F_OffsetY);
					else
						pDC->MoveTo(OffsetX,F_OffsetY);
					if(Coeff_X_Chk>1.0){
						for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
							if(AveFlg){
								M_Ave=0.0;
								Each_Data=0.0;

								R_End=(int)(4.0*AveTime_F)+1;
								for(k=1;k<=R_End;k++){//�}AveTime[ms]����
									Coeff=i-((int)(-2.0*AveTime_F)+k-1);
									if((Coeff>=0) && (Coeff<num))
											Each_Data=monidata[index].FActPos[Coeff];
									else	Each_Data=0.0;
									M_Ave+=Each_Data;
								}
								if(M_Ave>=0.0){
									y=-(int)(1.0/((double)R_End)*M_Ave*F_Coeff_Y)+F_OffsetY;
								}else
									y=F_OffsetY;
								pDC->LineTo(OffsetX+j,y);
								j++;
							}else{
								if(monidata[index].FActPos[i]>=0)
									y=-(int)(monidata[index].FActPos[i]*F_Coeff_Y)+F_OffsetY;
								else
									y=F_OffsetY;
								pDC->LineTo(OffsetX+j,y);
								j++;
							}
						}
					}else{
						for(i=1;i<num-1;i++){
							if(AveFlg){
								M_Ave=0.0;
								Each_Data=0.0;

								R_End=(int)(4.0*AveTime_F)+1;
								for(k=1;k<=R_End;k++){//�}AveTime[ms]����
									Coeff=i-((int)(-2.0*AveTime_F)+k-1);
									if((Coeff>=0) && (Coeff<num))
											Each_Data=monidata[index].FActPos[Coeff];
									else	Each_Data=0.0;
									M_Ave+=Each_Data;
								}
								if(M_Ave>=0.0){
									y=-(int)(1.0/((double)R_End)*M_Ave*F_Coeff_Y)+F_OffsetY;
								}else
									y=F_OffsetY;
								pDC->LineTo(OffsetX+i*Coeff_X,y);
							}else{
								if(monidata[index].FActPos[i]>=0)
									y=-(int)(monidata[index].FActPos[i]*F_Coeff_Y)+F_OffsetY;
								else
									y=F_OffsetY;
								pDC->LineTo(OffsetX+i*Coeff_X,y);
							}
						}
					}
				}
			}else{
				F_Coeff_Y=(int)((F_Max)/(bottom*F_hight/120))+1;//�ψʏc���̔{���ݒ�(�k��)
				pDC->TextOut(OffsetX-20,-5*P+F_OffsetY,"0");
				Scale.Format("%3.0f",F_Max);
				pDC->TextOut(H+N,-P-(int)(F_Max/F_Coeff_Y)+F_OffsetY,Scale);
				pDC->SelectObject(&BK_Pen);
				pDC->MoveTo(G,-(int)(F_Max/F_Coeff_Y)+F_OffsetY);
				pDC->LineTo(G+H,-(int)(F_Max/F_Coeff_Y)+F_OffsetY);
				//�׏d�g�`(����)�\��
				pDC->SelectObject(&BL_Pen);
				if(monidata[index].FCmdPos[0]>=0)
					pDC->MoveTo(OffsetX,-(int)(monidata[index].FCmdPos[0]/F_Coeff_Y)+F_OffsetY);
				else
					pDC->MoveTo(OffsetX,F_OffsetY);
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						if(monidata[index].FCmdPos[i]>=0)
							y=-(int)(monidata[index].FCmdPos[i]/F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						if(monidata[index].FCmdPos[i]>=0)
							y=-(int)(monidata[index].FCmdPos[i]/F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
							pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
				j=1;
				if ( Wave_FAct ){	// �׏d��Act�͕\�����Ȃ�
					pDC->SelectObject(&RD_Pen);
					pDC->MoveTo(OffsetX,-(int)(monidata[index].FActPos[0]/F_Coeff_Y)+F_OffsetY+(int)(F_Min/F_Coeff_Y));
					if(Coeff_X_Chk>1.0){
						for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
							if(AveFlg){
								M_Ave=0.0;
								Each_Data=0.0;

								R_End=(int)(4.0*AveTime_F)+1;

								for(k=1;k<=R_End;k++){//�}AveTime[ms]����
									Coeff=i-((int)(-2.0*AveTime_F)+k-1);
									if((Coeff>=0) && (Coeff<num))
											Each_Data=monidata[index].FActPos[Coeff];
									else	Each_Data=0.0;
									M_Ave+=Each_Data;
								}
								if(M_Ave>=0.0){
									y=-(int)(1.0/((double)R_End)*M_Ave/F_Coeff_Y)+F_OffsetY;
								}else
									y=F_OffsetY;
								pDC->LineTo(OffsetX+j,y);
								j++;
							}else{
								if(monidata[index].FActPos[i]>=0)
									y=-(int)(monidata[index].FActPos[i]/F_Coeff_Y)+F_OffsetY;
								else
									y=F_OffsetY;
								pDC->LineTo(OffsetX+j,y);
								j++;
							}
						}
					}else{
						for(i=1;i<num-1;i++){
							if(AveFlg){
								M_Ave=0.0;
								Each_Data=0.0;

								R_End=(int)(4.0*AveTime_F)+1;
								for(k=1;k<=R_End;k++){//�}AveTime[ms]����
									Coeff=i-((int)(-2.0*AveTime_F)+k-1);
									if((Coeff>=0) && (Coeff<num))
											Each_Data=monidata[index].FActPos[Coeff];
									else	Each_Data=0.0;
									M_Ave+=Each_Data;
								}
								if(M_Ave>=0.0)
									y=-(int)(1.0/((double)R_End)*M_Ave/F_Coeff_Y)+F_OffsetY;
								else
									y=F_OffsetY;
								pDC->LineTo(OffsetX+i*Coeff_X,y);
							}else{
								if(monidata[index].FActPos[i]>=0)
									y=-(int)(monidata[index].FActPos[i]/F_Coeff_Y)+F_OffsetY;
								else
									y=F_OffsetY;
								pDC->LineTo(OffsetX+i*Coeff_X,y);
							}
						}
					}
				}
			}
		}

// ----------
// ----------
		//���x�̕\��
		if ((sw == 1) || (sw == 4) || (sw == 6) || (sw == 7) ) {
			j=1;
			double T_Max=Te_Max;		
			double T_Min=Te_Min;
			int T_OffsetY=B;
			double T_hight=wave_hight;
			double T_Coeff_Y_Chk=(T_Max-T_Min)/(bottom*T_hight/120);//�\���̍ۂ̊g��/�k������
			int T_Coeff_Y;
			//���x����ؕ\��
			Scale.Format("%.0f",T_Min);
			pDC->TextOut(H+N,-5*P+T_OffsetY,Scale);
			if(T_Coeff_Y_Chk>1.0){
				T_Coeff_Y=(int)((T_Max-T_Min)/(bottom*T_hight/120))+1;//���x�c���̔{���ݒ�(�k��)
				if((int)T_Max-(int)T_Min){
					Scale.Format("%3.0f",T_Max);
					pDC->TextOut(H+N,-2*P-(int)(T_Max/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y),Scale);
					pDC->SelectObject(&BK_Pen);
///					pDC->MoveTo(F,-(int)(T_Max/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y));
///					pDC->LineTo(F+H,-(int)(T_Max/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y));
					// #DongKD(20141014) Fix dash line position of max index 
					pDC->MoveTo(G,-(int)(T_Max/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y));
					pDC->LineTo(G+H,-(int)(T_Max/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y));
				}
				//���x�g�`(����)�\��
				pDC->SelectObject(&BL_Pen);
				pDC->MoveTo(OffsetX,-(int)(monidata[index].TempOut[0]/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}1[ms]�ŕ��ω�����(120[Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_T)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_T)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].TempOut[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=T_Min) 
							y=-(int)(M_Ave/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y);
						else			 
							y=-(int)(monidata[index].TempOut[i]/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y); 
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}1[ms]�ŕ��ω�����(120[Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_T)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_T)+k-1);
							if((Coeff>=0) && (Coeff<num))
								Each_Data=monidata[index].TempOut[Coeff];
							else		 Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=T_Min) 
							y=-(int)(M_Ave/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y);
						else			 
							y=-(int)(monidata[index].TempOut[i]/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y); 	 
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
			}else{
				if((T_Max-T_Min)==0)
					T_Coeff_Y=0;
				else
					T_Coeff_Y=(int)((bottom*T_hight/120)/(T_Max-T_Min));//���x�c���̔{���ݒ�(�g��)
				if((int)T_Max-(int)T_Min){
					Scale.Format("%3.0f",T_Max);
					pDC->TextOut(H+N,-P-(int)(T_Max*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y),Scale);
					pDC->SelectObject(&BK_Pen);
///					pDC->MoveTo(F,-(int)(T_Max*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y));
///					pDC->LineTo(F+H,-(int)(T_Max*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y));
					// #DongKD(20141014) Fix dash line position of max index 
					pDC->MoveTo(G,-(int)(T_Max*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y));
					pDC->LineTo(G+H,-(int)(T_Max*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y));
				}
				//���x�g�`(����)�\��
				pDC->SelectObject(&BL_Pen);
				pDC->MoveTo(OffsetX,-(int)(monidata[index].TempOut[0]*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						M_Ave=0.0;
						Each_Data=0.0;
						R_End=(int)(4.0*AveTime_T)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_T)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].TempOut[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=T_Min)
							y=-(int)(M_Ave*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y);
						else			 
							y=-(int)(monidata[index].TempOut[i]*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y);
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						M_Ave=0.0;
						Each_Data=0.0;
						R_End=(int)(4.0*AveTime_T)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_T)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].TempOut[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=T_Min) 
							y=-(int)(M_Ave*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y);
						else             
							y=-(int)(monidata[index].TempOut[i]*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y);
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
			}
		}

		//US�̕\��
		if( bgmode == 3 ){
			j=1;
			double U_Max = Us_Max;
			double U_Min = Us_Min;

			int U_OffsetY;
			if( 4==wave_count ){
				U_OffsetY = C;
			} else if( 3==wave_count ){
				if ((sw == 1) || (sw == 4) || (sw == 6) || (sw == 7) ) {
					U_OffsetY = C;
				} else {
					U_OffsetY = B;
				}
			}else if( 2==wave_count ){
				if ((sw == 1) || (sw == 4) || (sw == 6) || (sw == 7) ) {
					U_OffsetY = C;
				} else {
					U_OffsetY = B;
				}
			} else {
				U_OffsetY = B;
			}

			double U_hight = wave_hight;

			double U_Coeff_Y_Chk=(U_Max-U_Min)/(bottom*U_hight/120);//�\���̍ۂ̊g��/�k������
			int U_Coeff_Y;
			//US����ؕ\��
			Scale.Format("%.3f",U_Min);	// US�̍ő�E�ŏ��͏����_�ȉ�3���Ƃ���
			pDC->TextOut(H+N,-5*P+U_OffsetY,Scale);
			if(U_Coeff_Y_Chk>1.0){
				U_Coeff_Y=(int)((U_Max-U_Min)/(bottom*U_hight/120))+1;//US�c���̔{���ݒ�(�k��)
				if((int)U_Max-(int)U_Min){
					Scale.Format("%3.3f",U_Max);	// US�̍ő�E�ŏ��͏����_�ȉ�3���Ƃ���
					pDC->TextOut(H+N,-2*P-(int)(U_Max/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y),Scale);
					pDC->SelectObject(&BK_Pen);
					pDC->MoveTo(G,-(int)(U_Max/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y));
					pDC->LineTo(G+H,-(int)(U_Max/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y));
				}
				//US�g�`(����)�\��
				pDC->SelectObject(&RD_Pen);
				pDC->MoveTo(OffsetX,-(int)(monidata[index].UsValue[0]/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						if(AveFlg){
							M_Ave=0.0;
							Each_Data=0.0;

							R_End=(int)(4.0*AveTime_G)+1;
							for(k=1;k<=R_End;k++){//�}AveTime[ms]����
								Coeff=i-((int)(-2.0*AveTime_G)+k-1);
								if((Coeff>=0) && (Coeff<num))
										Each_Data=monidata[index].UsValue[Coeff];
								else	Each_Data=0.0;
								M_Ave+=1.0/((double)R_End)*Each_Data;
							}
							if(M_Ave>=U_Min)
								y=-(int)(M_Ave/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y);
							else
								y=-(int)(monidata[index].UsValue[i]/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y);
							pDC->LineTo(OffsetX+j,y);
							j++;
						}else{
							y=-(int)(monidata[index].UsValue[i]/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y);
							pDC->LineTo(OffsetX+j,y);
							j++;
						}
					}
				}else{
					for(i=1;i<num-1;i++){
						if(AveFlg){
							M_Ave=0.0;
							Each_Data=0.0;

							R_End=(int)(4.0*AveTime_G)+1;
							for(k=1;k<=R_End;k++){//�}AveTime[ms]����
								Coeff=i-((int)(-2.0*AveTime_G)+k-1);
								if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].UsValue[Coeff];
								else		 Each_Data=0.0;
								M_Ave+=1.0/((double)R_End)*Each_Data;
							}
							if(M_Ave>=U_Min)
								y=-(int)(M_Ave/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y);
							else
								y=-(int)(monidata[index].UsValue[i]/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y);
							pDC->LineTo(OffsetX+i*Coeff_X,y);
						}else{
							y=-(int)(monidata[index].UsValue[i]/U_Coeff_Y)+U_OffsetY+(int)(U_Min/U_Coeff_Y);
							pDC->LineTo(OffsetX+i*Coeff_X,y);
						}
					}
				}
			}else{
				if((U_Max-U_Min)==0)
					U_Coeff_Y=0;
				else
					U_Coeff_Y=(int)((bottom*U_hight/120)/(U_Max-U_Min));//US�c���̔{���ݒ�(�g��)
				if((int)U_Max-(int)U_Min){
					Scale.Format("%3.3f",U_Max);	// US�̍ő�E�ŏ��͏����_�ȉ�3���Ƃ���
					pDC->TextOut(H+N,-P-(int)(U_Max*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y),Scale);
					pDC->SelectObject(&BK_Pen);
					pDC->MoveTo(G,-(int)(U_Max*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y));
					pDC->LineTo(G+H,-(int)(U_Max*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y));
				}
				//US�g�`(����)�\��
				pDC->SelectObject(&RD_Pen);
				pDC->MoveTo(OffsetX,-(int)(monidata[index].UsValue[0]*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						if(AveFlg){
							M_Ave=0.0;
							Each_Data=0.0;

							R_End=(int)(4.0*AveTime_G)+1;
							for(k=1;k<=R_End;k++){//�}AveTime[ms]����
								Coeff=i-((int)(-2.0*AveTime_G)+k-1);
								if((Coeff>=0) && (Coeff<num))
										Each_Data=monidata[index].UsValue[Coeff];
								else	Each_Data=0.0;
								M_Ave+=1.0/((double)R_End)*Each_Data;
							}
							if(M_Ave>=U_Min)
								y=-(int)(M_Ave*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y);
							else
								y=-(int)(monidata[index].UsValue[i]*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y);
							pDC->LineTo(OffsetX+j,y);
							j++;
						}else{
							y=-(int)(monidata[index].UsValue[i]*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y);
							pDC->LineTo(OffsetX+j,y);
							j++;
						}
					}
				}else{
					for(i=1;i<num-1;i++){
						if(AveFlg){
							M_Ave=0.0;
							Each_Data=0.0;

							R_End=(int)(4.0*AveTime_G)+1;
							for(k=1;k<=R_End;k++){//�}AveTime[ms]����
								Coeff=i-((int)(-2.0*AveTime_G)+k-1);
								if((Coeff>=0) && (Coeff<num))
										Each_Data=monidata[index].UsValue[Coeff];
								else	Each_Data=0.0;
								M_Ave+=1.0/((double)R_End)*Each_Data;
							}
							if(M_Ave>=U_Min)
								y=-(int)(M_Ave*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y);
							else
								y=-(int)(monidata[index].UsValue[i]*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y);
							pDC->LineTo(OffsetX+i*Coeff_X,y);
						}else{
							y=-(int)(monidata[index].UsValue[i]*U_Coeff_Y)+U_OffsetY+(int)(U_Min*U_Coeff_Y);
							pDC->LineTo(OffsetX+i*Coeff_X,y);
						}
					}
				}
			}
		}


		//�v�������̕\��(̧�ٓǍ���)
		if(!mode){
			Scale.Format("%3d/%3d",Act_FileNo,LastFile_No);
			pDC->TextOut((int)(right*145/160),F-2,Scale);
		}
		PL_Font.DeleteObject();

		// �O���t�ĕ`��
		if ( !displayDlg->m_InitFlg ) {
			displayDlg->m_InitFlg = TRUE;
		}
		pWnd->ReleaseDC(pDC);
	}else{
	//		AfxMessageBox("�g�`��ʕ\�����݂������Ă�������");
			r=false;
	}
	return r;
}



#else
bool BNDCtrl::BG_MonitorDataPlot5(int Ssw,bool mode)
{
	bool r=true;
// #NK120410-10 [�ڐA]�v���Z�X���j�^�����O�@�\(TFC900A�x�[�X��TFC6000�p)-S
	if ( BGH_DSP_GetMonitorMode /*1==BGH_DSP->GetMonitorMode()*/ ) {
		return false;	// US �Œ�׏d�͗L�蓾�Ȃ�
	}
// #NK120410-10-E

//	int	bgmode = bond.GetBgMode();
	int	bgmode = 3;
	int	sw = Ssw & 0x07;

	if(PlotFlg&&BgDisplay&&sw){
		//�ړ����ώZ�o�p�ϐ�
		int k,Coeff;//k:�ړ����ϕ��Z�o�ϐ��ACoeff:�ړ����ώZ�o���̃f�[�^No(�W��)���ex) PActPos[Coeff]
		int R_End;  //�ړ����ώZ�o�J��Ԃ����Z��(R_End=4*AveTime+1 AveTime:�ړ����ϕ����AveTime=1[ms]�Ȃ�Ίe����ْl�́}1[ms]�̃f�[�^���g�p�����ϒl�Z�o)
		double Each_Data,M_Ave;
		int right,left,top,bottom;
		CString	Scale;				// ���̕\���p�ڐ���i�[�ϐ�
		CWnd	*pWnd=displayDlg;
		CDC*pDC = pWnd->GetDC( );
		RECT	rect;
		pWnd->GetWindowRect(&rect);
		left  = rect.left;
		top   = rect.top;
		right = rect.right-rect.left;
		bottom= rect.bottom-rect.top;
		CRgn Area;
		Area.CreateRectRgn(0,0,right,bottom);
		CBrush Wh_bh(RGB(255,255,255));
		pDC->SelectObject(&Wh_bh);
		pDC->PaintRgn(&Area);
		//�\���p�t�H���g�̐ݒ�
		CFont PL_Font;
		PL_Font.CreateFont(14,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,SHIFTJIS_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,
			DEFAULT_PITCH|FF_DONTCARE,"MS P�S�V�b�N");
		pDC->SelectObject(&PL_Font);
		pDC->SetTextColor(RGB(0,0,0));
		//BaseGraph�̍쐬
		CPen RD_Pen,BK_Pen,BL_Pen,BK_DotPen;
		RD_Pen.CreatePen(PS_SOLID,1,RGB(255,0,0));
		BK_Pen.CreatePen(PS_SOLID,1,RGB(0,0,0));
		BL_Pen.CreatePen(PS_SOLID,1,RGB(0,0,255));
		BK_DotPen.CreatePen(PS_DASH ,1,RGB(0,0,0));
		pDC->SelectObject(&BK_Pen);
		int A,B,C,D,E,F;
		// B ���Ԏ�
		A = (int)(bottom*115/120-5);
		B = (int)(bottom*110/120-5);
		if(sw==1||sw==3||sw==5||sw==6)	  C = (int)(bottom*74/120-5);
		else if(sw==2||sw==4||sw==7)	  C = (int)(bottom*56/120-5);
		D = (int)(bottom*38/120-5);
		E = (int)(bottom*2/120-5);
		F = (int)(right*15/160-5);
		//���Ԏ�
		pDC->MoveTo(0,B);
		pDC->LineTo(right,B);
		if(sw==1){
			pDC->MoveTo(0,C);
			pDC->LineTo(right,C);
			pDC->MoveTo(0,D);
			pDC->LineTo(right,D);
		}else if(sw==2||sw==4||sw==7){
			pDC->MoveTo(0,C);
			pDC->LineTo(right,C);
		}
		pDC->MoveTo(0,E);
		pDC->LineTo(right,E);
		//�c��
		pDC->MoveTo(F,bottom);
		pDC->LineTo(F,0);
		int H,I,J,K,L,M,N,P;
			H=(int)(right*2/160);
			I=(int)(bottom*106/120);
			if(sw==1)				J=(int)(bottom*92/120);
			else if(sw==4||sw==7)	J=(int)(bottom*80/120);
			else					J=(int)(bottom*56/120);

			if(sw==1||sw==3)		K=(int)(bottom*56/120);
			else if(sw==2)			K=(int)(bottom*80/120);
			else					K=(int)(bottom*18/120);
			
			if(sw==1||sw==2||sw==7)	L=(int)(bottom*18/120);
			else					L=(int)(bottom*56/120);
			
			M=(int)(bottom*4/120)+1;
			N=(int)(right*5/128);
			P=(int)(bottom*1/160);
		pDC->TextOut(H-4,I-4,"����");
		pDC->TextOut(H-4,I+M-4," [ms]");
		if(sw==1){
			pDC->TextOut(H-4,J-4,"���x");
			pDC->TextOut(H-4,J+M-4," [��]");
			pDC->TextOut(H-4,K-4,"�׏d");
			pDC->TextOut(H-4,K+M-4," [N] ");
			pDC->TextOut(H-4,L-4,"�ψ�");
			pDC->TextOut(H-4,L+M-4,"[mm]");
		}else if(sw==2){
			pDC->TextOut(H-4,K-4,"�׏d");
			pDC->TextOut(H-4,K+M-4," [N] ");
			pDC->TextOut(H-4,L-4,"�ψ�");
			pDC->TextOut(H-4,L+M-4,"[mm]");
		}else if(sw==3){
			pDC->TextOut(H-4,K-4,"�׏d");
			pDC->TextOut(H-4,K+M-4," [N] ");
		}else if(sw==4){
			pDC->TextOut(H,J-4,"���x");
			pDC->TextOut(H,J+M-4," [��]");
			pDC->TextOut(H,K-3,"�׏d");
			pDC->TextOut(H,K+M-4," [N] ");
		}else if(sw==5){
			pDC->TextOut(H-4,L-4,"�ψ�");
			pDC->TextOut(H-4,L+M-4,"[mm]");
		}else if(sw==6){
			pDC->TextOut(H-4,J-4,"���x");
			pDC->TextOut(H-4,J+M-4," [��]");
		}else if(sw==7){
			pDC->TextOut(H-4,J-4,"���x");
			pDC->TextOut(H-4,J+M-4," [��]");
			pDC->TextOut(H-4,L-4,"�ψ�");
			pDC->TextOut(H-4,L+M-4,"[mm]");
		}
		long index;
		if(mode) 
			if(MoniIndex)index=MoniIndex-1;
			else		 index=MoniMaxSize-1;
		else	 index=FileSize;//̧�ق���ǂݍ��񂾌��ʂ͊m�ۂ����̈�̍Ō�Ɋi�[���Ă���B

		long num=monidata[index].Rec_Count-2;
		
		pDC->TextOut((int)(right*93/160),E+5,"�v������(�N-��-��-��-��-�b)");
		Scale.Format("%s",monidata[index].date);
		pDC->TextOut((int)(right*108/160),E+20,Scale);
		
		//num=num-2;
		//�e�g�`�̕\��
		double Coeff_X_Chk=(double)num/(double)(right*145/160);
		int Coeff_X;
		int OffsetX=F;
		int i,j=1;	//Repeat�p�ϐ�
		int y;//�\���p���W�f�[�^
		//���Ԃ̕\��
		pDC->SelectObject(&BK_DotPen);//�j���ݒ�
		Scale.Format("%1.0f",monidata[index].SampleCou[0]);
		pDC->TextOut(OffsetX-10,I+M-3,Scale);
		if(Coeff_X_Chk>1.0){
			Coeff_X=(int)(num/(right*145/160))+1;//��΂��f�[�^����ݒ肵�A1dot�Ԋu�ŕ\��������B
			for(i=Coeff_X*100;i<num;i+=Coeff_X*100){
					Scale.Format("%4.0f",monidata[index].SampleCou[i]);
					pDC->TextOut(OffsetX+i/Coeff_X,I+M-3,Scale);
					pDC->MoveTo(OffsetX+i/Coeff_X,A);
					pDC->LineTo(OffsetX+i/Coeff_X,0);
			}
		}else{
			Coeff_X=(int)((right*145/160)/num);//��΂��f�[�^����ݒ肵�A1dot�Ԋu�ŕ\��������B
			for(i=40;i<num;i+=40){
					Scale.Format("%4.0f",monidata[index].SampleCou[i]);
					pDC->TextOut(OffsetX+i*Coeff_X-10,I+M-3,Scale);
					pDC->MoveTo(OffsetX+i*Coeff_X,A);
					pDC->LineTo(OffsetX+i*Coeff_X,0);
			}
		}
		pDC->SelectObject(&BK_Pen);//�����ɖ߂�
		//�e�ް��̍ő�E�ŏ��l�擾
		double PC_Max,PA_Max,FC_Max,FA_Max,Te_Max;
		double PC_Min,PA_Min,FC_Min,FA_Min,Te_Min;
		if(sw==1){//�ψʥ�׏d����x�̍ő�l�E�ŏ��l�擾
			PC_Max=PC_Min=monidata[index].PCmdPos[0];
			PA_Max=PA_Min=monidata[index].PActPos[0];
			FC_Max=FC_Min=monidata[index].FCmdPos[0];
			FA_Max=FA_Min=monidata[index].FActPos[0];
			Te_Max=Te_Min=monidata[index].TempOut[0];
			for(i=0;i<num;i++){
				if(monidata[index].PCmdPos[i]>PC_Max)	PC_Max=monidata[index].PCmdPos[i];
				if(monidata[index].PCmdPos[i]<PC_Min)	PC_Min=monidata[index].PCmdPos[i];
				if(monidata[index].PActPos[i]>PA_Max)	PA_Max=monidata[index].PActPos[i];
				if(monidata[index].PActPos[i]<PA_Min)	PA_Min=monidata[index].PActPos[i];
				if(monidata[index].FCmdPos[i]>FC_Max)	FC_Max=monidata[index].FCmdPos[i];
				if(monidata[index].FCmdPos[i]<FC_Min)	FC_Min=monidata[index].FCmdPos[i];
				if(monidata[index].FActPos[i]>FA_Max)	FA_Max=monidata[index].FActPos[i];
				if(monidata[index].FActPos[i]<FA_Min)	FA_Min=monidata[index].FActPos[i];
				if(monidata[index].TempOut[i]>Te_Max)	Te_Max=monidata[index].TempOut[i];
				if(monidata[index].TempOut[i]<Te_Min)	Te_Min=monidata[index].TempOut[i];
			}
		}else if(sw==2){//�ψʥ�׏d�̍ő�l�E�ŏ��l�擾
			PC_Max=PC_Min=monidata[index].PCmdPos[0];
			PA_Max=PA_Min=monidata[index].PActPos[0];
			FC_Max=FC_Min=monidata[index].FCmdPos[0];
			FA_Max=FA_Min=monidata[index].FActPos[0];
			for(i=0;i<num;i++){
				if(monidata[index].PCmdPos[i]>PC_Max)	PC_Max=monidata[index].PCmdPos[i];
				if(monidata[index].PCmdPos[i]<PC_Min)	PC_Min=monidata[index].PCmdPos[i];
				if(monidata[index].PActPos[i]>PA_Max)	PA_Max=monidata[index].PActPos[i];
				if(monidata[index].PActPos[i]<PA_Min)	PA_Min=monidata[index].PActPos[i];
				if(monidata[index].FCmdPos[i]>FC_Max)	FC_Max=monidata[index].FCmdPos[i];
				if(monidata[index].FCmdPos[i]<FC_Min)	FC_Min=monidata[index].FCmdPos[i];
				if(monidata[index].FActPos[i]>FA_Max)	FA_Max=monidata[index].FActPos[i];
				if(monidata[index].FActPos[i]<FA_Min)	FA_Min=monidata[index].FActPos[i];
			}
		}else if(sw==3){//�׏d�̍ő�l�E�ŏ��l�擾
			FC_Max=FC_Min=monidata[index].FCmdPos[0];
			FA_Max=FA_Min=monidata[index].FActPos[0];
			for(i=0;i<num;i++){
				if(monidata[index].FCmdPos[i]>FC_Max)	FC_Max=monidata[index].FCmdPos[i];
				if(monidata[index].FCmdPos[i]<FC_Min)	FC_Min=monidata[index].FCmdPos[i];
				if(monidata[index].FActPos[i]>FA_Max)	FA_Max=monidata[index].FActPos[i];
				if(monidata[index].FActPos[i]<FA_Min)	FA_Min=monidata[index].FActPos[i];
			}
		}else if(sw==4){//�׏d����x�̍ő�l�E�ŏ��l�擾
			FC_Max=FC_Min=monidata[index].FCmdPos[0];
			FA_Max=FA_Min=monidata[index].FActPos[0];
			Te_Max=Te_Min=monidata[index].TempOut[0];
			for(i=0;i<num;i++){
				if(monidata[index].FCmdPos[i]>FC_Max)	FC_Max=monidata[index].FCmdPos[i];
				if(monidata[index].FCmdPos[i]<FC_Min)	FC_Min=monidata[index].FCmdPos[i];
				if(monidata[index].FActPos[i]>FA_Max)	FA_Max=monidata[index].FActPos[i];
				if(monidata[index].FActPos[i]<FA_Min)	FA_Min=monidata[index].FActPos[i];
				if(monidata[index].TempOut[i]>Te_Max)	Te_Max=monidata[index].TempOut[i];
				if(monidata[index].TempOut[i]<Te_Min)	Te_Min=monidata[index].TempOut[i];
			}
		}else if(sw==5){//�ψʂ̍ő�l�E�ŏ��l�擾
			PC_Max=PC_Min=monidata[index].PCmdPos[0];
			PA_Max=PA_Min=monidata[index].PActPos[0];
			for(i=0;i<num;i++){
				if(monidata[index].PCmdPos[i]>PC_Max)	PC_Max=monidata[index].PCmdPos[i];
				if(monidata[index].PCmdPos[i]<PC_Min)	PC_Min=monidata[index].PCmdPos[i];
				if(monidata[index].PActPos[i]>PA_Max)	PA_Max=monidata[index].PActPos[i];
				if(monidata[index].PActPos[i]<PA_Min)	PA_Min=monidata[index].PActPos[i];
			}
		}else if(sw==6){//���x�̍ő�l�E�ŏ��l�擾
			Te_Max=Te_Min=monidata[index].TempOut[0];
			for(i=0;i<num;i++){
				if(monidata[index].TempOut[i]>Te_Max)	Te_Max=monidata[index].TempOut[i];
				if(monidata[index].TempOut[i]<Te_Min)	Te_Min=monidata[index].TempOut[i];
			}
		}else if(sw==7){//�ψʥ���x�̍ő�l�E�ŏ��l�擾
			PC_Max=PC_Min=monidata[index].PCmdPos[0];
			PA_Max=PA_Min=monidata[index].PActPos[0];
			Te_Max=Te_Min=monidata[index].TempOut[0];
			for(i=0;i<num;i++){
				if(monidata[index].PCmdPos[i]>PC_Max)	PC_Max=monidata[index].PCmdPos[i];
				if(monidata[index].PCmdPos[i]<PC_Min)	PC_Min=monidata[index].PCmdPos[i];
				if(monidata[index].PActPos[i]>PA_Max)	PA_Max=monidata[index].PActPos[i];
				if(monidata[index].PActPos[i]<PA_Min)	PA_Min=monidata[index].PActPos[i];
				if(monidata[index].TempOut[i]>Te_Max)	Te_Max=monidata[index].TempOut[i];
				if(monidata[index].TempOut[i]<Te_Min)	Te_Min=monidata[index].TempOut[i];
			}
		}

		//�ψʂ̕\��
		if(sw==1||sw==2||sw==5||sw==7){
			double D_Max,D_Min;
			if(PC_Max>=PA_Max) D_Max=PC_Max;
			else			   D_Max=PA_Max;
			if(PA_Min>=PC_Min) D_Min=PC_Min;
			else			   D_Min=PA_Min;
			
			int D_OffsetY=E;
			double hight;
			if(sw==1)				hight=36.0;
			else if(sw==2||sw==7)	hight=54.0;
			else					hight=108.0;//sw=5		
			
			double D_Coeff_Y_Chk=(D_Max-D_Min)/(bottom*hight/120);//�\���̍ۂ̊g��/�k������
			int D_Coeff_Y;
			//�ψʂ���ؕ\��
			Scale.Format("%3.0f",D_Min);
			pDC->TextOut(H+N,2*P+D_OffsetY,Scale);
			if(D_Coeff_Y_Chk<1.0){//�ψʕ����O���t�c���͈�dot����葽�����H������Ώk��/���Ȃ���Ίg�債�ĕ\��
				if((D_Max-D_Min)==0)
					D_Coeff_Y=0;
				else
					D_Coeff_Y=(int)((bottom*hight/120)/(D_Max-D_Min));//�ψʏc���̔{���ݒ�	
				//�ψʂ���ؕ\��
				if((int)D_Max-(int)D_Min){
					Scale.Format("%3.0f",D_Max);
					pDC->TextOut(H+N,-5*P+(int)(D_Max*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y),Scale);
					pDC->MoveTo(F,(int)(D_Max*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y));
					pDC->LineTo(F+H,(int)(D_Max*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y));
				}
				//�ψʔg�`(����)�\��
				//�w��
				pDC->SelectObject(&BL_Pen);
				pDC->MoveTo(OffsetX,(int)(monidata[index].PCmdPos[0]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y));//�����ʒu(��_)�ړ�
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						y=(int)(monidata[index].PCmdPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						y=(int)(monidata[index].PCmdPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
				//�o��
				j=1;
				pDC->SelectObject(&RD_Pen);
				pDC->MoveTo(OffsetX,(int)(monidata[index].PActPos[0]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}0.5[ms]�ŕ��ω�����( [Hz]LPF�ɑ����j
					//	if(AveTime_D < 0.5) 
					//		AveTime_D=0.5;
						R_End=(int)(4.0*AveTime_D)+1;
					//	for(k=1;k<=21;k++){//�}5ms����
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
						//	Coeff=i-k+11;
							Coeff=i-((int)(-2.0*AveTime_D)+k-1);
						//	if(Coeff>=0)
							if((Coeff>=0) && (Coeff<num)) 
									Each_Data=monidata[index].PActPos[Coeff];
							else	Each_Data=0.0;
						//	M_Ave+=1.0/21.0*Each_Data;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=D_Min) y=(int)(M_Ave*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
						else		     y=(int)(monidata[index].PActPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);//���ϒl���ŏ��l�������ꍇ�A���f�[�^�\��
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}0.5[ms]�ŕ��ω�����([Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_D)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_D)+k-1);
							if((Coeff>=0) && (Coeff<num)) 
									Each_Data=monidata[index].PActPos[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=D_Min) y=(int)(M_Ave*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);
						else			 y=(int)(monidata[index].PActPos[i]*D_Coeff_Y+D_OffsetY-D_Min*D_Coeff_Y);//���ϒl���ŏ��l�������ꍇ�A���f�[�^�\��
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}

			}else{
				D_Coeff_Y=(int)((D_Max-D_Min)/(bottom*hight/120))+1;//�ψʏc���̔{���ݒ�
				//�ψʂ���ؕ\��
				if((int)D_Max-(int)D_Min){
					Scale.Format("%3.0f",D_Max);
					pDC->TextOut(H+N,-5*P+(int)(D_Max/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y),Scale);
					pDC->MoveTo(F,(int)(D_Max/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y));
					pDC->LineTo(F+H,(int)(D_Max/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y));
				}
				//�ψʔg�`(����)�\��
				//�w��
				pDC->SelectObject(&BL_Pen);
				pDC->MoveTo(OffsetX,(int)(monidata[index].PCmdPos[0]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						y=(int)(monidata[index].PCmdPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						y=(int)(monidata[index].PCmdPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}

				j=1;
				pDC->SelectObject(&RD_Pen);
				pDC->MoveTo(OffsetX,(int)(monidata[index].PActPos[0]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}0.5[ms]�ŕ��ω�����([Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_D)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_D)+k-1);
							if((Coeff>=0) && (Coeff<num)) 
									Each_Data=monidata[index].PActPos[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=D_Min) y=(int)(M_Ave/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
						else		     y=(int)(monidata[index].PActPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);//���ϒl���ŏ��l�������ꍇ�A���f�[�^�\��
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}1[ms]�ŕ��ω�����(120[Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_D)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_D)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].PActPos[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=D_Min) y=(int)(M_Ave/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);
						else		     y=(int)(monidata[index].PActPos[i]/D_Coeff_Y+D_OffsetY-D_Min/D_Coeff_Y);//���ϒl���ŏ��l�������ꍇ�A���f�[�^�\��
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
			}
		}

		//�׏d�̕\��
		if(sw==1||sw==2||sw==3||sw==4){
			j=1;
			double F_Max,F_Min;
			if(FC_Max>=FA_Max) F_Max=FC_Max;
			else			   F_Max=FA_Max;
			if(FA_Min>=FC_Min) F_Min=FC_Min;
			else			   F_Min=FA_Min;
			double F_Ave;
			F_Ave=BG_MonitorF_Average(FC_Max,mode);
			//�ő�׏d�̉�ʕ\��
			int Q,R,S;
			Q=(int)(right*117/160);
			R=(int)(right*140/160);
			if(sw==1)				S=(int)(bottom*38/120);
			else if(sw==2)			S=(int)(bottom*56/120);
			else if(sw==3||sw==4)	S=(int)(bottom*2/120+40);
			pDC->TextOut(Q,S,"���ω׏d[N]=");
			Scale.Format("%.2f",F_Ave);
			pDC->TextOut(R,S,Scale);
			int F_OffsetY;
			if(sw==1||sw==4)		F_OffsetY=C;
			else if(sw==2||sw==3)	F_OffsetY=B;
			double F_hight;
			if(sw==1)				F_hight=36.0;
			else if(sw==2||sw==4)	F_hight=54.0;
			else					F_hight=108.0;//sw=3
			//�׏d�̕\���͈͂�0����Ƃ���B
			//�����ʌ��׏d�Ǝ擾���ʂ���̍������Ƃ�ƕ��̒l����������B
			//���Ƃ��Ƃ́A���͈̔͂����̂܂ܕ\�����Ă������A���̏ꍇ��0�ɂ��ĕ\�����邱�ƂƂ����B
			//(���̉׏d�ɈӖ����Ȃ����߁B)
			double F_Coeff_Y_Chk=(F_Max)/(bottom*F_hight/120);//�\���̍ۂ̊g��/�k������
			int F_Coeff_Y;
			if(F_Coeff_Y_Chk<1.0){
				if((F_Max-F_Min)==0)
					F_Coeff_Y=0;
				else
				//	F_Coeff_Y=(int)((bottom*F_hight/120)/(F_Max-F_Min));//�ψʏc���̔{���ݒ�(�g��)	
					F_Coeff_Y=(int)((bottom*F_hight/120)/(F_Max));//�ψʏc���̔{���ݒ�(�g��)
				//�׏d����ؕ\��
				pDC->TextOut(OffsetX-20,-5*P+F_OffsetY,"0");
				Scale.Format("%3.0f",F_Max);
				pDC->TextOut(H+N,-P-(int)(F_Max*F_Coeff_Y)+F_OffsetY,Scale);
				pDC->SelectObject(&BK_Pen);
				pDC->MoveTo(F,-(int)(F_Max*F_Coeff_Y)+F_OffsetY);
				pDC->LineTo(F+H,-(int)(F_Max*F_Coeff_Y)+F_OffsetY);
				//�׏d�g�`(����)�\��
				pDC->SelectObject(&BL_Pen);
				if(monidata[index].FCmdPos[0]>=0)
					pDC->MoveTo(OffsetX,-(int)(monidata[index].FCmdPos[0]*F_Coeff_Y)+F_OffsetY);
				else
					pDC->MoveTo(OffsetX,F_OffsetY);
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						if(monidata[index].FCmdPos[i]>=0)
						//	y=-(int)(monidata[index].FCmdPos[i]*F_Coeff_Y)+F_OffsetY+(int)(F_Min*F_Coeff_Y);
							y=-(int)(monidata[index].FCmdPos[i]*F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						if(monidata[index].FCmdPos[i]>=0)
						//	y=-(int)(monidata[index].FCmdPos[i]*F_Coeff_Y)+F_OffsetY+(int)(F_Min*F_Coeff_Y);
							y=-(int)(monidata[index].FCmdPos[i]*F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
				j=1;
				pDC->SelectObject(&RD_Pen);
				if(monidata[index].FActPos[0]>=0)
					pDC->MoveTo(OffsetX,-(int)(monidata[index].FActPos[0]*F_Coeff_Y)+F_OffsetY);
				else
					pDC->MoveTo(OffsetX,F_OffsetY);
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						M_Ave=0.0;
						Each_Data=0.0;
						R_End=(int)(4.0*AveTime_F)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_F)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].FActPos[Coeff];
							else	Each_Data=0.0;
							M_Ave+=Each_Data;
						}
						if(M_Ave>=0.0){
							y=-(int)(1.0/((double)R_End)*M_Ave*F_Coeff_Y)+F_OffsetY;
						}else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}1[ms]�ŕ��ω�����(120[Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_F)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_F)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].FActPos[Coeff];
							else	Each_Data=0.0;
							M_Ave+=Each_Data;
						}
						if(M_Ave>=0.0){
							y=-(int)(1.0/((double)R_End)*M_Ave*F_Coeff_Y)+F_OffsetY;
						}else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}

			}else{
				F_Coeff_Y=(int)((F_Max)/(bottom*F_hight/120))+1;//�ψʏc���̔{���ݒ�(�k��)
				//�׏d����ؕ\��
				pDC->TextOut(OffsetX-20,-5*P+F_OffsetY,"0");
				Scale.Format("%3.0f",F_Max);
				pDC->TextOut(H+N,-P-(int)(F_Max/F_Coeff_Y)+F_OffsetY,Scale);
				pDC->SelectObject(&BK_Pen);
				pDC->MoveTo(F,-(int)(F_Max/F_Coeff_Y)+F_OffsetY);
				pDC->LineTo(F+H,-(int)(F_Max/F_Coeff_Y)+F_OffsetY);
				//�׏d�g�`(����)�\��
				pDC->SelectObject(&BL_Pen);
				if(monidata[index].FCmdPos[0]>=0)
					pDC->MoveTo(OffsetX,-(int)(monidata[index].FCmdPos[0]/F_Coeff_Y)+F_OffsetY);
				else
					pDC->MoveTo(OffsetX,F_OffsetY);
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						if(monidata[index].FCmdPos[i]>=0)
							y=-(int)(monidata[index].FCmdPos[i]/F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						if(monidata[index].FCmdPos[i]>=0)
							y=-(int)(monidata[index].FCmdPos[i]/F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
							pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
				j=1;
				pDC->SelectObject(&RD_Pen);
				pDC->MoveTo(OffsetX,-(int)(monidata[index].FActPos[0]/F_Coeff_Y)+F_OffsetY+(int)(F_Min/F_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}1[ms]�ŕ��ω�����(120[Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_F)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_F)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].FActPos[Coeff];
							else	Each_Data=0.0;
							M_Ave+=Each_Data;
						}
						if(M_Ave>=0.0){
							y=-(int)(1.0/((double)R_End)*M_Ave/F_Coeff_Y)+F_OffsetY;
						}else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}1[ms]�ŕ��ω�����(120[Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_F)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_F)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].FActPos[Coeff];
							else	Each_Data=0.0;
							M_Ave+=Each_Data;
						}
						if(M_Ave>=0.0)
							y=-(int)(1.0/((double)R_End)*M_Ave/F_Coeff_Y)+F_OffsetY;
						else
							y=F_OffsetY;
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}

			}
		}
		//���x�̕\��
		if(sw==1||sw==4||sw==6||sw==7){
			j=1;
			double T_Max=Te_Max;		
			double T_Min=Te_Min;
			int T_OffsetY=B;
			double T_hight;
			if(sw==1)				T_hight=36.0;
			else if(sw==4||sw==7)	T_hight=54.0;
			else					T_hight=108.0;//sw=6
			double T_Coeff_Y_Chk=(T_Max-T_Min)/(bottom*T_hight/120);//�\���̍ۂ̊g��/�k������
			int T_Coeff_Y;
			//���x����ؕ\��
			Scale.Format("%.0f",T_Min);
			pDC->TextOut(H+N,-5*P+T_OffsetY,Scale);
			if(T_Coeff_Y_Chk>1.0){
				T_Coeff_Y=(int)((T_Max-T_Min)/(bottom*T_hight/120))+1;//���x�c���̔{���ݒ�(�k��)
				if((int)T_Max-(int)T_Min){
					Scale.Format("%3.0f",T_Max);
					pDC->TextOut(H+N,-2*P-(int)(T_Max/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y),Scale);
					pDC->SelectObject(&BK_Pen);
					pDC->MoveTo(F,-(int)(T_Max/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y));
					pDC->LineTo(F+H,-(int)(T_Max/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y));
				}
				//���x�g�`(����)�\��
				pDC->SelectObject(&BL_Pen);
				pDC->MoveTo(OffsetX,-(int)(monidata[index].TempOut[0]/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}1[ms]�ŕ��ω�����(120[Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_T)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_T)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].TempOut[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=T_Min) 
							y=-(int)(M_Ave/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y);
						else			 
							y=-(int)(monidata[index].TempOut[i]/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y); 
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						M_Ave=0.0;
						Each_Data=0.0;
						//���ω��\����I�����Ă���̂�������炸���ω����Ԃ�0�̏ꍇ�A�}1[ms]�ŕ��ω�����(120[Hz]LPF�ɑ����j
						R_End=(int)(4.0*AveTime_T)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_T)+k-1);
							if((Coeff>=0) && (Coeff<num))
								Each_Data=monidata[index].TempOut[Coeff];
							else		 Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=T_Min) 
							y=-(int)(M_Ave/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y);
						else			 
							y=-(int)(monidata[index].TempOut[i]/T_Coeff_Y)+T_OffsetY+(int)(T_Min/T_Coeff_Y); 	 
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
			}else{
				if((T_Max-T_Min)==0)
					T_Coeff_Y=0;
				else
					T_Coeff_Y=(int)((bottom*T_hight/120)/(T_Max-T_Min));//���x�c���̔{���ݒ�(�g��)
				if((int)T_Max-(int)T_Min){
					Scale.Format("%3.0f",T_Max);
					pDC->TextOut(H+N,-P-(int)(T_Max*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y),Scale);
					pDC->SelectObject(&BK_Pen);
					pDC->MoveTo(F,-(int)(T_Max*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y));
					pDC->LineTo(F+H,-(int)(T_Max*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y));
				}
				//���x�g�`(����)�\��
				pDC->SelectObject(&BL_Pen);
				pDC->MoveTo(OffsetX,-(int)(monidata[index].TempOut[0]*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y));
				if(Coeff_X_Chk>1.0){
					for(i=Coeff_X;i<num-Coeff_X;i+=Coeff_X){
						M_Ave=0.0;
						Each_Data=0.0;
						R_End=(int)(4.0*AveTime_T)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_T)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].TempOut[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=T_Min)
							y=-(int)(M_Ave*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y);
						else			 
							y=-(int)(monidata[index].TempOut[i]*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y);
						pDC->LineTo(OffsetX+j,y);
						j++;
					}
				}else{
					for(i=1;i<num-1;i++){
						M_Ave=0.0;
						Each_Data=0.0;
						R_End=(int)(4.0*AveTime_T)+1;
						for(k=1;k<=R_End;k++){//�}AveTime[ms]����
							Coeff=i-((int)(-2.0*AveTime_T)+k-1);
							if((Coeff>=0) && (Coeff<num))
									Each_Data=monidata[index].TempOut[Coeff];
							else	Each_Data=0.0;
							M_Ave+=1.0/((double)R_End)*Each_Data;
						}
						if(M_Ave>=T_Min) 
							y=-(int)(M_Ave*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y);
						else             
							y=-(int)(monidata[index].TempOut[i]*T_Coeff_Y)+T_OffsetY+(int)(T_Min*T_Coeff_Y);
						pDC->LineTo(OffsetX+i*Coeff_X,y);
					}
				}
			}
		}
		//�v�������̕\��(̧�ٓǍ���)
		if(!mode){
			Scale.Format("%3d/%3d",Act_FileNo,LastFile_No);
			pDC->TextOut((int)(right*145/160),E-2,Scale);
		}
		PL_Font.DeleteObject();
// #NK120410-10 [�ڐA]�v���Z�X���j�^�����O�@�\(TFC900A�x�[�X��TFC6000�p)-S
		if ( !displayDlg->m_InitFlg ) {
			displayDlg->m_InitFlg = TRUE;
		}
		pWnd->ReleaseDC(pDC);
// #NK120410-10-E
	}else{
	//		AfxMessageBox("�g�`��ʕ\�����݂������Ă�������");
			r=false;
	}
	return r;
}
#endif
// #OZ20150725 US�o�͒l�����j�^�[�\�� (E)

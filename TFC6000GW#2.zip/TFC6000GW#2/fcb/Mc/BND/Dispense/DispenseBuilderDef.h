/*---------------------------------------------------------------------
	DispenseBuilder I/O ��`
								2008.11.XX Toshiyuki Takahashi
	Edition History
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/

//***************************************************************************
//	�Z���T�A�h���X�֘A
//***************************************************************************
///////////////////////////////////////////
// ��������
//
#define	IO_Dis_FluxPos_SNS_IN					DINTBL_41				// Dispnese �w�� �o��
#define	IO_Dis_EscPos_SNS_IN					DINTBL_42				// Dispnese �w�� �ߌ�
#define	IO_Dis_FluxPos_OUT						DOUTTBL_22				// Dispnese �w���쓮

#define	IO_Dis_Flux_OUT							DOUTTBL_127				// Dispnese �f�o

///////////////////////////////////////////
// ���ʂ̾ݻ
//
#define	IO_Dis_Touch_SNS_IN						DINTBL_43				// Dispnese �^�b�`��
#define	IO_Dis_RemainAmount_SNS_IN				DINTBL_143				// Dispnese �c�ʌx����



// TDKLoadPortComm.cpp: implementation of the TDKLoadPortComm class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "TDKLoadPortComm.h"

// #T.Tachi160115-01(S)
//////////////////////////////////////////////////////////////////////
// Utility
//////////////////////////////////////////////////////////////////////
void Char2HexString(const char* src,CString& dst,unsigned int len)
{
	CString buf;
	for(unsigned int i = 0;i < len;++i){
		buf.Format("0x%02X , ",src[i]);
		dst += buf;
	}
}
// #T.Tachi160115-01(E)

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

TDKLoadPortComm::TDKLoadPortComm()
{
	eventAnswer.ResetEvent();
	eventFINISH.ResetEvent();
	
	pRThread = AfxBeginThread(CommRecv, this, THREAD_PRIORITY_NORMAL);
	if( !pRThread ){
		AfxMessageBox("Cannot create receive thread", MB_OK, 0);
	}
	m_hCommRThread = pRThread->m_hThread;
	int i;
	for (i = 0; i < LP_ANSWER_QMAX; i++) {
		lp_reply_q[i].CmdNum = 0;
	}
	for (i = 0; i < LP_EVENT_QMAX; i++) {
		lp_event_q[i].EventNum = 0;
	}
	// #T.Tachi151212-02(S)
	this->err.Initinstance(0,0);		// �G���[�o�͂ɂ͎g�p���Ȃ��ŁBLog�ɂ̂ݎg�p����
	// #T.Tachi151212-01(E)
}

TDKLoadPortComm::~TDKLoadPortComm()
{

}

void TDKLoadPortComm::SetCommPara( CString ComPort, int boudrate, int databit, int stopbit, int parity, int evenodd)
{
	PortComm.SetCommOpenInfo(ComPort, boudrate, databit, stopbit, parity, evenodd);
}

BOOL TDKLoadPortComm::OpenComm()
{
	BOOL r;
	r = PortComm.CommOpen();
	if( r ){
		CommSetting();
	}
	return r;
}

BOOL TDKLoadPortComm::CloseComm()
{
	BOOL r = TRUE;
	if(PortComm.m_hComm && PortComm.m_hComm != INVALID_HANDLE_VALUE) {
		CloseHandle(PortComm.m_hComm);
		PortComm.m_hComm = 0;
	}

	return r;
}

BOOL TDKLoadPortComm::CommSetting()
{
	// get any early notifications
	SetCommMask(PortComm.m_hComm, EV_RXCHAR) ;
	// setup device buffers
	if(!SetupComm( PortComm.m_hComm, 4096, 4096))
		return FALSE;
	// purge any information in the buffer
	PurgeComm(PortComm.m_hComm,	PURGE_TXABORT | PURGE_RXABORT |
						PURGE_TXCLEAR | PURGE_RXCLEAR) ;

	// set up for overlapped I/O (Timeout)
	PortComm.m_CommTimeOuts.ReadIntervalTimeout =0xFFFFFFFF ;		// ������ Timeout
	PortComm.m_CommTimeOuts.ReadTotalTimeoutMultiplier = 0 ;
//	PortComm.m_CommTimeOuts.ReadTotalTimeoutConstant = 3000 ;		// ��M Timeout(ms)
	PortComm.m_CommTimeOuts.ReadTotalTimeoutConstant = 100 ;		// ��M Timeout(ms)
	PortComm.m_CommTimeOuts.WriteTotalTimeoutMultiplier = 0 ;
//	PortComm.m_CommTimeOuts.WriteTotalTimeoutConstant = 1000 ;		// ���M Timeout(ms)
	PortComm.m_CommTimeOuts.WriteTotalTimeoutConstant = 100 ;		// ���M Timeout(ms)
	// Timeout
	if(!SetCommTimeouts(PortComm.m_hComm, &PortComm.m_CommTimeOuts))
		return FALSE;

	//*** COM Port Setup ***
		
	PortComm.m_Dcb.DCBlength = sizeof( DCB ) ;
	if(!GetCommState(PortComm.m_hComm, &PortComm.m_Dcb))
		return FALSE;

	// DCB�\���̂ɐݒ�l��āi�����w�蕔���j

	PortComm.m_Dcb.BaudRate = PortComm.m_BaudRate;	// �`�����x
	PortComm.m_Dcb.ByteSize = PortComm.m_ByteSize;	// �ް���(4�`8)
	PortComm.m_Dcb.StopBits = PortComm.m_StopBits;	// STOP�r�b�g 0=1�r�b�g 1=2�r�b�g
	PortComm.m_Dcb.fParity  = PortComm.m_fParity;		// ���è���� 0=���A1=�L
	if( PortComm.m_fParity == 0 )
		PortComm.m_Dcb.Parity   = NOPARITY;   // 0=no, 1=odd, 2=even
	else
		PortComm.m_Dcb.Parity = PortComm.m_Parity;

	// �ʐM�߰Ă̐ݒ��ύX���܂��B
	if(!SetCommState(PortComm.m_hComm, &PortComm.m_Dcb)){
		long we = GetLastError();
		return FALSE;
	}

	return TRUE;
}

bool TDKLoadPortComm::SetEventObject(int eventNum, CEvent* evOK, CEvent* evNG, LP_EVENTDATA *evData)
{
	int	i;
	for( i=0 ; i<LP_EVENT_QMAX ; i++ ){
		if( lp_event_q[i].EventNum == 0 ){
			lp_event_q[i].EventNum = eventNum;
			lp_event_q[i].pEventObjOK = evOK;
			lp_event_q[i].pEventObjNG = evNG;
			lp_event_q[i].eventData = evData;
			return true;
		}
	}
	return false;
}

bool TDKLoadPortComm::SetAnswerObject(int cmdNum, CEvent* evOK, CEvent* evNG, LP_ANSWERDATA *ansData)
{
	int	i;
	for( i=0 ; i<LP_ANSWER_QMAX ; i++ ){
		if( lp_reply_q[i].CmdNum == 0 ){
			lp_reply_q[i].CmdNum = cmdNum;
			lp_reply_q[i].pEventObjOK = evOK;
			lp_reply_q[i].pEventObjNG = evNG;
			lp_reply_q[i].ansData = ansData;
			return true;
		}
	}
	return false;
}

UINT TDKLoadPortComm::CommRecv(LPVOID pParam)
{
	enum {
		IDLE = 0,		// Idle
		WETX = 1,		// 0x03 End of text character
		WTCR = 2,		// 0x0D CR character
		WTLF = 3		// 0x0A LF character
	};
	int		i, fReadStat;
	int		PStatus;
	int		length = 0;
	unsigned long	dwLength = 0;
	char	rcvBuf[1000];
	char	rstr[100];
	TDKLoadPortComm	*pLoadPort = (TDKLoadPortComm *)pParam;
	PStatus = IDLE;
	for(;;) {
		if((pLoadPort->PortComm.m_hComm != (void *)0) && ((pLoadPort->PortComm.m_hComm != (void *)0xffffffff))){
			fReadStat = ReadFile( pLoadPort->PortComm.m_hComm, &rcvBuf, 100, &dwLength, 0 );
			if(fReadStat && dwLength){
				for(i=0 ; i<(int)dwLength ; i++){
					switch(PStatus){
					case	IDLE:		// Idle condition
						if (rcvBuf[i] == TDKLoadPortComm::STARTHEADER) {
							//rstr += rcvBuf[i];
							length = 0;
							PStatus = WTCR;
						}
						break;
					case	WTCR:		// Wait CR character
						// #KI150719-03(S)
						// �f���~�^�Ƃ���<CR>�ǉ�
						if (rcvBuf[i] != TDKLoadPortComm::TERMCHAR1 && rcvBuf[i] != TDKLoadPortComm::TERMCHAR2&& rcvBuf[i] != TDKLoadPortComm::TERMCHAR3){
							rstr[length] = rcvBuf[i];
							length++;
						} else if (rcvBuf[i] == TDKLoadPortComm::TERMCHAR1 ){
							PStatus = WTLF;
						} else if (rcvBuf[i] == TDKLoadPortComm::TERMCHAR2 ){
							PStatus = IDLE;
						} else if (rcvBuf[i] == TDKLoadPortComm::TERMCHAR3 ){
							int ae = pLoadPort->AnalizeReceiveData(rstr, length);
							memset(rstr, 0x0, sizeof(rstr));
							length = 0;
							PStatus = IDLE;
						}
						// #KI150719-03(E)
						break;
					case	WTLF:
						if (rcvBuf[i] != TDKLoadPortComm::TERMCHAR2 ){
							PStatus = IDLE;
						} else {
							int ae = pLoadPort->AnalizeReceiveData(rstr, length);
							memset(rstr, 0x0, sizeof(rstr));
							length = 0;
							PStatus = IDLE;
						}
						break;
					}
				}
			} else {
				Sleep( 10 );
			}
		} else {
			Sleep( 10 );
		}
	}
	return 0;
}

///////////////////////////////////////////////////////////////////
// Command format
// 
//	Format:		| SOH | LEN | ADR | CMD | CSH | CSI | DEL |
//  Length:	   	   1     2     2     X     1     1     2
//
///////////////////////////////////////////////////////////////////
int	TDKLoadPortComm::AnalizeReceiveData(char* rstr, int length)
{
	// #T.Tachi151212-02(S)
	CString buffer;
	// #T.Tachi160115-01(S)
	CString hexString;
	::Char2HexString(rstr,hexString,length);
	// #T.Tachi160114-01(E)
	buffer.Format("[LP ->TFC:]%s\n",hexString);// #T.Tachi160115-01
	
	this->err.SaveSoftLogNFL(buffer,TRUE);
	// #T.Tachi151212-02(E)

	const static char* cmdArray[] =
		{
			"RESET","INITL","LPLOD","BLLOD","LOLOD","LPULD","BLULD",
			"LOULD","LPMSW","BLMSW","LOMSW","LPCON","BLCON","LOCON",
			"LPCST","BLCST","LOCST","LON07","LBL07","LOF07","LON08",
			"LBL08","LOF08",
			
			"ONMGV","MENTE","TEACH",
			
			"STATE","VERSN","LEDST","MAPDT","MAPRD","WFCNT",
			
			"ORGSH","ABORG","CLOAD","CLDDK","CLDYD","CLDOP","CLDMP",
			"CLMPO","CULOD","CULDK","CUDCL","CUDNC","CULYD","CULFC",
			"CUDMP","CUMDK","CUMFC","MAPDO","REMAP",
			"PODOP","PODCL","VACON","VACOF","DOROP","DORCL","MAPOP",
			"MAPCL","ZDRUP","ZDRDW","ZDRMP","ZMPST","ZMPED","MSTON",
			"MSTOF","YWAIT","YDOOR","DORBK","DORFW",
			"RETRY","STOP_","PAUSE","ABORT","RESUM",
			
			"fffff"
		};
	const static int codeArray[] =
		{
			Cmd_SET_RESET,Cmd_SET_INITL,Cmd_SET_LPLOD,Cmd_SET_BLLOD,Cmd_SET_LOLOD,Cmd_SET_LPULD,Cmd_SET_BLULD,
			Cmd_SET_LOULD,Cmd_SET_LPMSW,Cmd_SET_BLMSW,Cmd_SET_LOMSW,Cmd_SET_LPCON,Cmd_SET_BLCON,Cmd_SET_LOCON,
			Cmd_SET_LPCST,Cmd_SET_BLCST,Cmd_SET_LOCST,Cmd_SET_LON07,Cmd_SET_LBL07,Cmd_SET_LOF07,Cmd_SET_LON08,
			Cmd_SET_LBL08,Cmd_SET_LOF08,
			
			Cmd_MOD_ONMGV,Cmd_MOD_MENTE,Cmd_MOD_TEACH,
		
			Cmd_GET_STATE,Cmd_GET_VERSN,Cmd_GET_LEDST,Cmd_GET_MAPDT,Cmd_GET_MAPRD,Cmd_GET_WFCNT,
		
			Cmd_MOV_ORGSH,Cmd_MOV_ABORG,Cmd_MOV_CLOAD,Cmd_MOV_CLDDK,Cmd_MOV_CLDYD,Cmd_MOV_CLDOP,Cmd_MOV_CLDMP,
			Cmd_MOV_CLMPO,Cmd_MOV_CULOD,Cmd_MOV_CULDK,Cmd_MOV_CUDCL,Cmd_MOV_CUDNC,Cmd_MOV_CULYD,Cmd_MOV_CULFC,
			Cmd_MOV_CUDMP,Cmd_MOV_CUMDK,Cmd_MOV_CUMFC,Cmd_MOV_MAPDO,Cmd_MOV_REMAP,
		    
			Cmd_MOV_PODOP,Cmd_MOV_PODCL,Cmd_MOV_VACON,Cmd_MOV_VACOF,Cmd_MOV_DOROP,Cmd_MOV_DORCL,Cmd_MOV_MAPOP,
			Cmd_MOV_MAPCL,Cmd_MOV_ZDRUP,Cmd_MOV_ZDRDW,Cmd_MOV_ZDRMP,Cmd_MOV_ZMPST,Cmd_MOV_ZMPED,Cmd_MOV_MSTON,
			Cmd_MOV_MSTOF,Cmd_MOV_YWAIT,Cmd_MOV_YDOOR,Cmd_MOV_DORBK,Cmd_MOV_DORFW,
		    
			Cmd_MOV_RETRY,Cmd_MOV_STOP_,Cmd_MOV_PAUSE,Cmd_MOV_ABORT,Cmd_MOV_RESUM
		};
	const static char* nakArray[] =
		{
			"CKSUM",		"CMDER",		"SFSER",		"INTER",
			"INTER//CKSUM",	"INTER//CMDER",	"INTER//SFSER",	"INTER//CBUSY",
			"INTER//FPILG",	"INTER//LATCH",	"INTER//FPCLP",	"INTER//YPOSI",
			"INTER//DOCPO",	"INTER//DPOSI",	"INTER//PROTS",	"INTER//MPARM",
			"INTER//ZPOSI",	"INTER//MPSTP",	"INTER//DVACM",	"INTER//ERROR",
			"INTER//ORGYT",	"INTER//CLDDK",	"INTER//CULDK",	"INTER//CLOAD",
			"INTER//RMPOS", "fffff"
		};
	const static char* infArray[] =
		{
			"PODON","PODOF","SMTON","ABNST","MANSW","MA2SW","MANOF","MA2OF",
			"POWON","FANST","ITLON","ITLOF","AIRSN","AIRSR","PRSIN","PRSCL",
			"OTOON","OTOOF","TVAON","TVAOF","POWLO", "fffff"
		};
		
	int i, r;
	char* P;
	char lengthD[2] = {0};
	char adr[2] = {0};
	char cmdKind[100] = {0};
	char cmdContent[100] = {0};
	char csh = 0;
	char csl = 0;
	char cmdName[10] = {0};
	char cmdPara[100] = {0};
	r = RcvERROR;
	
	// Checksum calculator
	if (!RecvChecksumCalculator(rstr, length, true)) {
		r = FALSE;
	} else {
		r = TRUE;
	}
	///////////////////////////////////////////////////////
	//
	//	rstr: not contain Start header (0x01) and delimiter ([CR][LF])
	//
	///////////////////////////////////////////////////////
	if (r) {
		if(length >= LP_TDK_RECEIVE_MIN_SIZE){
			P = (char *)malloc(length);
			memset(P, 0, length);
			memcpy(P, rstr+2, length-2);
//			strcpy(P, rstr);
			lengthD[0] = rstr[0];
			lengthD[1] = rstr[1];
			csh = rstr[length - 2];
			csl = rstr[length - 1];
			sscanf(P, "%2c%[^:]:%[^;];", adr, cmdKind, cmdContent);
			TRACE("%s-%s\n", cmdKind, cmdContent);
			if (strcmp(cmdKind, "ACK") == 0) {
				r = RcvANSWER;
				if (cmdContent[5] != '/') {
					for (int a = 0; a < 5; a++) {
						cmdName[a] = cmdContent[a];
					}
				} else {
					sscanf(cmdContent, "%5s/%s", cmdName, cmdPara);
				}
				for (i=0;;i++) {
					if (strcmp(cmdArray[i], "fffff") == 0) {	
						r = RcvERROR;							
						break;
					}
					if (strcmp(cmdName, cmdArray[i]) == 0) {
						break;
					}
				}
				
				if (r != RcvERROR) {
					if (codeArray[i] >= Cmd_SET_RESET && codeArray[i] <= Cmd_MOD_TEACH) {
						// Do nothing
					} else if (codeArray[i] >= Cmd_MOV_ORGSH && codeArray[i] <= Cmd_MOV_RESUM) {
						// Do nothing
					} else {
						switch (codeArray[i]) {
							case Cmd_GET_STATE:	
								{
									for (int j = 0; j < LP_ANSWER_QMAX; j++) {
										if (lp_reply_q[j].CmdNum == codeArray[i]) {
											sscanf(cmdPara, "%20c", lp_reply_q[j].ansData->u_asdata.stateLP);
											TRACE("%s\n",lp_reply_q[j].ansData->u_asdata.stateLP);
											break;
										}
									}
								}
								break;
							case Cmd_GET_VERSN:
								{
									for (int j = 0; j < LP_ANSWER_QMAX; j++) {
										if (lp_reply_q[j].CmdNum == codeArray[i]) {
											sscanf(cmdPara, "%12c", lp_reply_q[j].ansData->u_asdata.version);
											TRACE("%s\n",lp_reply_q[j].ansData->u_asdata.version);
											break;
										}
									}
								}
								break;
							case Cmd_GET_LEDST:
								{
									int ledSts[13];
									memset(ledSts, 0, sizeof(ledSts));
									for (int j = 0; j < LP_ANSWER_QMAX; j++) {
										if (lp_reply_q[j].CmdNum == codeArray[i]) {
											sscanf(cmdPara, "%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d", 
												&ledSts[ 0],&ledSts[ 1],&ledSts[ 2],&ledSts[ 3],&ledSts[ 4],
												&ledSts[ 5],&ledSts[ 6],&ledSts[ 7],&ledSts[ 8],&ledSts[ 9],
												&ledSts[10],&ledSts[11],&ledSts[12]);
											TRACE("%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d\n",
												ledSts[ 0],ledSts[ 1],ledSts[ 2],ledSts[ 3],ledSts[ 4],
												ledSts[ 5],ledSts[ 6],ledSts[ 7],ledSts[ 8],ledSts[ 9],
												ledSts[10],ledSts[11],ledSts[12]);
											memcpy(lp_reply_q[j].ansData->u_asdata.ledStatus, ledSts, sizeof(ledSts));
										}
									}
								}
								break;
							case Cmd_GET_MAPDT:
								{
									char c_mapInf[LP_SLOT_MAX];
									int mapInf[LP_SLOT_MAX];
									memset(mapInf, 0, sizeof(mapInf));
									for (int j = 0; j < LP_ANSWER_QMAX; j++) {
										if (lp_reply_q[j].CmdNum == codeArray[i]) {
											// #KI150814-02
											sscanf(cmdPara, "%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c",
												&c_mapInf[24], &c_mapInf[23], &c_mapInf[22], &c_mapInf[21], &c_mapInf[20], &c_mapInf[19], &c_mapInf[18], &c_mapInf[17], &c_mapInf[16], &c_mapInf[15],
												&c_mapInf[14], &c_mapInf[13], &c_mapInf[12], &c_mapInf[11], &c_mapInf[10], &c_mapInf[ 9], &c_mapInf[ 8], &c_mapInf[ 7], &c_mapInf[ 6], &c_mapInf[ 5],
												&c_mapInf[ 4], &c_mapInf[ 3], &c_mapInf[ 2], &c_mapInf[ 1], &c_mapInf[ 0]);
											for (int i = 0; i < LP_SLOT_MAX; i++) {
												if (c_mapInf[i] == '0') {
													mapInf[i] = 0;		// Empty
												} else if (c_mapInf[i] == '1') {
													mapInf[i] = 1;		// Exist
												} else if (c_mapInf[i] == '2') {
													mapInf[i] = 2;		// Cross
												} else if (c_mapInf[i] == '?') {
													mapInf[i] = 3;		// Unknown
												} else if (c_mapInf[i] == 'W') {
													mapInf[i] = 4;		// 2 layers
												} else {
												}
											}
											// #KI150814-02
											TRACE("%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d\n",
												mapInf[24], mapInf[23], mapInf[22], mapInf[21], mapInf[20], mapInf[19], mapInf[18], mapInf[17], mapInf[16], mapInf[15],
												mapInf[14], mapInf[13], mapInf[12], mapInf[11], mapInf[10], mapInf[ 9], mapInf[ 8], mapInf[ 7], mapInf[ 6], mapInf[ 5],
												mapInf[ 4], mapInf[ 3], mapInf[ 2], mapInf[ 1], mapInf[ 0]);
											memcpy(lp_reply_q[j].ansData->u_asdata.mapInfo, mapInf, sizeof(mapInf));
											break;
										}
									}
								}
								break;
							case Cmd_GET_MAPRD:
								{
									char c_mapInf[LP_SLOT_MAX];
									int mapInf[LP_SLOT_MAX];
									memset(mapInf, 0, sizeof(mapInf));
									for (int j = 0; j < LP_ANSWER_QMAX; j++) {
										if (lp_reply_q[j].CmdNum == codeArray[i]) {
											// #KI150814-02
											sscanf(cmdPara, "%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c%1c",
												&c_mapInf[ 0], &c_mapInf[ 1], &c_mapInf[ 2], &c_mapInf[ 3], &c_mapInf[ 4], &c_mapInf[ 5], &c_mapInf[ 6], &c_mapInf[ 7], &c_mapInf[ 8], &c_mapInf[ 9],
												&c_mapInf[10], &c_mapInf[11], &c_mapInf[12], &c_mapInf[13], &c_mapInf[14], &c_mapInf[15], &c_mapInf[16], &c_mapInf[17], &c_mapInf[18], &c_mapInf[19],
												&c_mapInf[20], &c_mapInf[21], &c_mapInf[22], &c_mapInf[23], &c_mapInf[24]);
											for (int i = 0; i < LP_SLOT_MAX; i++) {
												if (c_mapInf[i] == '0') {
													mapInf[i] = 0;		// Empty
												} else if (c_mapInf[i] == '1') {
													mapInf[i] = 1;		// Exist
												} else if (c_mapInf[i] == '2') {
													mapInf[i] = 2;		// Cross
												} else if (c_mapInf[i] == '?') {
													mapInf[i] = 3;		// Unknown
												} else if (c_mapInf[i] == 'W') {
													mapInf[i] = 4;		// 2 layers
												} else {
												}
											}
											// #KI150814-02
											TRACE("%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d\n",
												mapInf[ 0], mapInf[ 1], mapInf[ 2], mapInf[ 3], mapInf[ 4], mapInf[ 5], mapInf[ 6], mapInf[ 7], mapInf[ 8], mapInf[ 9],
												mapInf[10], mapInf[11], mapInf[12], mapInf[13], mapInf[14], mapInf[15], mapInf[16], mapInf[17], mapInf[18], mapInf[19],
												mapInf[20], mapInf[21], mapInf[22], mapInf[23], mapInf[24]);
											memcpy(lp_reply_q[j].ansData->u_asdata.mapInfo, mapInf, sizeof(mapInf));
											break;
										}
									}
								}
								break;
							case Cmd_GET_WFCNT:
								{
									int numberOfWafer = 0;
									for (int j = 0; j < LP_ANSWER_QMAX; j++) {
										if (lp_reply_q[j].CmdNum == codeArray[i]) {
											if (strcmp(cmdPara, "??") == 0) {
												numberOfWafer = 0;										
											} else {
												sscanf(cmdPara, "%d", &numberOfWafer);	// #KI151021-01
											}
											TRACE("%d\n",numberOfWafer);
											lp_reply_q[j].ansData->u_asdata.waferNo = numberOfWafer;
											break;
										}
									}
								}
								break;
							default: 
								r = RcvERROR;
								break;
						}
					}
				}
				// Notify to caller
				for (int j = 0; j < LP_ANSWER_QMAX; j++) {
					if (lp_reply_q[j].CmdNum == codeArray[i]) {
						TRACE("+++++REPLY--pEventObjOK is set\n");
						lp_reply_q[j].pEventObjOK->SetEvent();
						break;
					}
				}
			} else if (strcmp(cmdKind, "NAK") == 0) {
				r = RcvANSWER;
				sscanf(cmdContent, "%5s/%s", cmdName, cmdPara);
				for (i=0;;i++) {
					if (strcmp(cmdArray[i], "fffff") == 0) {	
						r = RcvERROR;							
						break;
					}
					if (strcmp(cmdName, cmdArray[i]) == 0) {
						break;
					}
				}
				if (r != RcvERROR) {
					// Notify to caller
					for (int j = 0; j < LP_ANSWER_QMAX; j++) {
						if (lp_reply_q[j].CmdNum == codeArray[i]) {
							memcpy(lp_reply_q[j].ansData->error, cmdPara, 11);
							lp_reply_q[j].pEventObjNG->SetEvent();
							break;
						}
					}
				}
			} else if ((strcmp(cmdKind, "INF") == 0) || (strcmp(cmdKind, "RIF") == 0)) {
				bool eventNotify = false;
				r = RcvEVENT;
				memcpy(cmdName, cmdContent, 5);
				for (i=0;;i++) {
					if (strcmp(cmdArray[i], "fffff") == 0) {	
						r = RcvERROR;							
						break;
					}
					if (strcmp(cmdName, cmdArray[i]) == 0) {
						eventNotify = false;
						break;
					}
				}
				// LP notify event (not reply)
				if (r == RcvERROR) {
					for (i=0;;i++) {
						if (strcmp(infArray[i], "fffff") == 0) {	
							r = RcvERROR;							
							break;
						}
						if (strcmp(cmdName, infArray[i]) == 0) {
							r = RcvEVENT;
							eventNotify = true;
							break;
						}
					}
				}				
				if (r != RcvERROR) {
					if (!eventNotify) {
						// Notify to caller
						for (int j = 0; j < LP_EVENT_QMAX; j++) {
							if (lp_event_q[j].EventNum == codeArray[i]) {
								TRACE("+++++EVENT--pEventObjOK is set\n");
								lp_event_q[j].pEventObjOK->SetEvent();
								break;
							}
						}
					} else {
						// TODO notify about load port status
						memcpy(pEventData->command, cmdName, 5);
						evEVENT->SetEvent();
					}
				}
			} else if ((strcmp(cmdKind, "ABS") == 0) || (strcmp(cmdKind, "RAS") == 0)) {
				r = RcvEVENT;
				sscanf(cmdContent, "%5s/%s", cmdName, cmdPara);
				for (i=0;;i++) {
					if (strcmp(cmdArray[i], "fffff") == 0) {	
						r = RcvERROR;							
						break;
					}
					if (strcmp(cmdName, cmdArray[i]) == 0) {
						break;
					}
				}
				if (r != RcvERROR) {
					// Notify to caller
					for (int j = 0; j < LP_EVENT_QMAX; j++) {
						if (lp_event_q[j].EventNum == codeArray[i]) {
							lp_event_q[j].pEventObjNG->SetEvent();
							break;
						}
					}
				}
			} else {
				r = RcvERROR;
			}
			free(P);
		}
	}
	return r; 
}

int	TDKLoadPortComm::MakeCommandString(int CmdCode, char* CommandLine, bool retry)
{
	BOOL r = TRUE;
	char StartHeader[2] = {0};
	char checksum[3] = {0};
	char length[3] = {0};
	char Address[3] = {0};
	char Terminate[3] = {0};
	char cmd[11] = {0};
	char checksumRange[20] = {0};
	
	StartHeader[0] = 0x01;
	length[0] = 0x00;
	length[1] = 0x0E;	// Send command of TDK-A have length of 14 bytes
	Address[0] = '0';
	Address[1] = '0';
	// #KI150719-01 �f���~�^��<CR>���f�t�H���g
#if 0
	Terminate[0] = 0x0D;
	Terminate[1] = 0x0A;
#else
	Terminate[0] = 0x03;
	Terminate[1] = 0x00;
#endif	

	switch(CmdCode) {
		case Cmd_SET_RESET:
			if (!retry) {
				sprintf(cmd, "SET:RESET;");
			} else {
				sprintf(cmd, "RST:RESET;");
			}			
			break;
		case Cmd_SET_INITL:
			if (!retry) {
				sprintf(cmd, "SET:INITL;");
			} else {
				sprintf(cmd, "RST:INITL;");
			}
			break;
		case Cmd_SET_LPLOD:
			if (!retry) {
				sprintf(cmd, "SET:LPLOD;");
			} else {
				sprintf(cmd, "RST:LPLOD;");
			}
			break;
		case Cmd_SET_BLLOD:
			if (!retry) {
				sprintf(cmd, "SET:BLLOD;");
			} else {
				sprintf(cmd, "RST:BLLOD;");
			}
			break;
		case Cmd_SET_LOLOD:
			if (!retry) {
				sprintf(cmd, "SET:LOLOD;");
			} else {
				sprintf(cmd, "RST:LOLOD;");
			}
			break;
		case Cmd_SET_LPULD:
			if (!retry) {
				sprintf(cmd, "SET:LPULD;");
			} else {
				sprintf(cmd, "RST:LPULD;");
			}
			break;
		case Cmd_SET_BLULD:
			if (!retry) {
				sprintf(cmd, "SET:BLULD;");
			} else {
				sprintf(cmd, "RST:BLULD;");
			}
			break;
		case Cmd_SET_LOULD:
			if (!retry) {
				sprintf(cmd, "SET:LOULD;");
			} else {
				sprintf(cmd, "RST:LOULD;");
			}
			break;
		case Cmd_SET_LPMSW:
			if (!retry) {
				sprintf(cmd, "SET:LPMSW;");
			} else {
				sprintf(cmd, "RST:LPMSW;");
			}
			break;
		case Cmd_SET_BLMSW:
			if (!retry) {
				sprintf(cmd, "SET:BLMSW;");
			} else {
				sprintf(cmd, "RST:BLMSW;");
			}
			break;
		case Cmd_SET_LOMSW:
			if (!retry) {
				sprintf(cmd, "SET:LOMSW;");
			} else {
				sprintf(cmd, "RST:LOMSW;");
			}
			break;
		case Cmd_SET_LPCON:
			if (!retry) {
				sprintf(cmd, "SET:LPCON;");
			} else {
				sprintf(cmd, "RST:LPCON;");
			}
			break;
		case Cmd_SET_BLCON:
			if (!retry) {
				sprintf(cmd, "SET:BLCON;");
			} else {
				sprintf(cmd, "RST:BLCON;");
			}
			break;
		case Cmd_SET_LOCON:
			if (!retry) {
				sprintf(cmd, "SET:LOCON;");
			} else {
				sprintf(cmd, "RST:LOCON;");
			}
			break;
		case Cmd_SET_LPCST:
			if (!retry) {
				sprintf(cmd, "SET:LPCST;");
			} else {
				sprintf(cmd, "RST:LPCST;");
			}
			break;
		case Cmd_SET_BLCST:
			if (!retry) {
				sprintf(cmd, "SET:BLCST;");
			} else {
				sprintf(cmd, "RST:BLCST;");
			}
			break;
		case Cmd_SET_LOCST:
			if (!retry) {
				sprintf(cmd, "SET:LOCST;");
			} else {
				sprintf(cmd, "RST:LOCST;");
			}
			break;
		case Cmd_SET_LON07:
			if (!retry) {
				sprintf(cmd, "SET:LON07;");
			} else {
				sprintf(cmd, "RST:LON07;");
			}
			break;
		case Cmd_SET_LBL07:
			if (!retry) {
				sprintf(cmd, "SET:LBL07;");
			} else {
				sprintf(cmd, "RST:LBL07;");
			}
			break;
		case Cmd_SET_LOF07:
			if (!retry) {
				sprintf(cmd, "SET:LOF07;");
			} else {
				sprintf(cmd, "RST:LOF07;");
			}
			break;
		case Cmd_SET_LON08:
			if (!retry) {
				sprintf(cmd, "SET:LON08;");
			} else {
				sprintf(cmd, "RST:LON08;");
			}
			break;
		case Cmd_SET_LBL08:
			if (!retry) {
				sprintf(cmd, "SET:LBL08;");
			} else {
				sprintf(cmd, "RST:LBL08;");
			}
			break;
		case Cmd_SET_LOF08:
			if (!retry) {
				sprintf(cmd, "SET:LOF08;");
			} else {
				sprintf(cmd, "RST:LOF08;");
			}
			break;
		                  
		case Cmd_MOD_ONMGV:
			sprintf(cmd, "MOD:ONMGV;");
			break;
		case Cmd_MOD_MENTE:
			sprintf(cmd, "MOD:MENTE;");
			break;
		case Cmd_MOD_TEACH:
			sprintf(cmd, "MOD:TEACH;");
			break;				
		case Cmd_GET_STATE:
			sprintf(cmd, "GET:STATE;");
			break;
		case Cmd_GET_VERSN:
			sprintf(cmd, "GET:VERSN;");
			break;
		case Cmd_GET_LEDST:
			sprintf(cmd, "GET:LEDST;");
			break;
		case Cmd_GET_MAPDT:	
			sprintf(cmd, "GET:MAPDT;");
			break;
		case Cmd_GET_MAPRD:
			sprintf(cmd, "GET:MAPRD;");
			break;
		case Cmd_GET_WFCNT:
			sprintf(cmd, "GET:WFCNT;");
			break;
                          
		case Cmd_MOV_ORGSH:
			if (!retry) {
				sprintf(cmd, "MOV:ORGSH;");
			} else {
				sprintf(cmd, "RMV:ORGSH;");
			}
			break;
		case Cmd_MOV_ABORG:
			if (!retry) {
				sprintf(cmd, "MOV:ABORG;");
			} else {
				sprintf(cmd, "RMV:ABORG;");
			}
			break;
		case Cmd_MOV_CLOAD:
			if (!retry) {
				sprintf(cmd, "MOV:CLOAD;");
			} else {
				sprintf(cmd, "RMV:CLOAD;");
			}
			break;
		case Cmd_MOV_CLDDK:
			if (!retry) {
				sprintf(cmd, "MOV:CLDDK;");
			} else {
				sprintf(cmd, "RMV:CLDDK;");
			}
			break;
		case Cmd_MOV_CLDYD:
			if (!retry) {
				sprintf(cmd, "MOV:CLDYD;");
			} else {
				sprintf(cmd, "RMV:CLDYD;");
			}
			break;
		case Cmd_MOV_CLDOP:
			if (!retry) {
				sprintf(cmd, "MOV:CLDOP;");
			} else {
				sprintf(cmd, "RMV:CLDOP;");
			}
			break;
		case Cmd_MOV_CLDMP:
			if (!retry) {
				sprintf(cmd, "MOV:CLDMP;");
			} else {
				sprintf(cmd, "RMV:CLDMP;");
			}
			break;
		case Cmd_MOV_CLMPO:
			if (!retry) {
				sprintf(cmd, "MOV:CLMPO;");
			} else {
				sprintf(cmd, "RMV:CLMPO;");
			}
			break;
		case Cmd_MOV_CULOD:
			if (!retry) {
				sprintf(cmd, "MOV:CULOD;");
			} else {
				sprintf(cmd, "RMV:CULOD;");
			}
			break;
		case Cmd_MOV_CULDK:
			if (!retry) {
				sprintf(cmd, "MOV:CULDK;");
			} else {
				sprintf(cmd, "RMV:CULDK;");
			}
			break;
		case Cmd_MOV_CUDCL:
			if (!retry) {
				sprintf(cmd, "MOV:CUDCL;");
			} else {
				sprintf(cmd, "RMV:CUDCL;");
			}
			break;
		case Cmd_MOV_CUDNC:
			if (!retry) {
				sprintf(cmd, "MOV:CUDNC;");
			} else {
				sprintf(cmd, "RMV:CUDNC;");
			}
			break;
		case Cmd_MOV_CULYD:
			if (!retry) {
				sprintf(cmd, "MOV:CULYD;");
			} else {
				sprintf(cmd, "RMV:CULYD;");
			}
			break;
		case Cmd_MOV_CULFC:
			if (!retry) {
				sprintf(cmd, "MOV:CULFC;");
			} else {
				sprintf(cmd, "RMV:CULFC;");
			}
			break;
		case Cmd_MOV_CUDMP:
			if (!retry) {
				sprintf(cmd, "MOV:CUDMP;");
			} else {
				sprintf(cmd, "RMV:CUDMP;");
			}
			break;
		case Cmd_MOV_CUMDK:
			if (!retry) {
				sprintf(cmd, "MOV:CUMDK;");
			} else {
				sprintf(cmd, "RMV:CUMDK;");
			}
			break;
		case Cmd_MOV_CUMFC:
			if (!retry) {
				sprintf(cmd, "MOV:CUMFC;");
			} else {
				sprintf(cmd, "RMV:CUMFC;");
			}
			break;
		case Cmd_MOV_MAPDO:
			if (!retry) {
				sprintf(cmd, "MOV:MAPDO;");
			} else {
				sprintf(cmd, "RMV:MAPDO;");
			}
			break;
		case Cmd_MOV_REMAP:
			if (!retry) {
				sprintf(cmd, "MOV:REMAP;");
			} else {
				sprintf(cmd, "RMV:REMAP;");
			}
			break;
                          
		case Cmd_MOV_PODOP:
			if (!retry) {
				sprintf(cmd, "MOV:PODOP;");
			} else {
				sprintf(cmd, "RMV:PODOP;");
			}
			break;
		case Cmd_MOV_PODCL:
			if (!retry) {
				sprintf(cmd, "MOV:PODCL;");
			} else {
				sprintf(cmd, "RMV:PODCL;");
			}
			break;
		case Cmd_MOV_VACON:
			if (!retry) {
				sprintf(cmd, "MOV:VACON;");
			} else {
				sprintf(cmd, "RMV:VACON;");
			}
			break;
		case Cmd_MOV_VACOF:
			if (!retry) {
				sprintf(cmd, "MOV:VACOF;");
			} else {
				sprintf(cmd, "RMV:VACOF;");
			}
			break;
		case Cmd_MOV_DOROP:
			if (!retry) {
				sprintf(cmd, "MOV:DOROP;");
			} else {
				sprintf(cmd, "RMV:DOROP;");
			}
			break;
		case Cmd_MOV_DORCL:
			if (!retry) {
				sprintf(cmd, "MOV:DORCL;");
			} else {
				sprintf(cmd, "RMV:DORCL;");
			}
			break;
		case Cmd_MOV_MAPOP:
			if (!retry) {
				sprintf(cmd, "MOV:MAPOP;");
			} else {
				sprintf(cmd, "RMV:MAPOP;");
			}
			break;
		case Cmd_MOV_MAPCL:
			if (!retry) {
				sprintf(cmd, "MOV:MAPCL;");
			} else {
				sprintf(cmd, "RMV:MAPCL;");
			}
			break;
		case Cmd_MOV_ZDRUP:
			if (!retry) {
				sprintf(cmd, "MOV:ZDRUP;");
			} else {
				sprintf(cmd, "RMV:ZDRUP;");
			}
			break;
		case Cmd_MOV_ZDRDW:
			if (!retry) {
				sprintf(cmd, "MOV:ZDRDW;");
			} else {
				sprintf(cmd, "RMV:ZDRDW;");
			}
			break;
		case Cmd_MOV_ZDRMP:
			if (!retry) {
				sprintf(cmd, "MOV:ZDRMP;");
			} else {
				sprintf(cmd, "RMV:ZDRMP;");
			}
			break;
		case Cmd_MOV_ZMPST:
			if (!retry) {
				sprintf(cmd, "MOV:ZMPST;");
			} else {
				sprintf(cmd, "RMV:ZMPST;");
			}
			break;
		case Cmd_MOV_YWAIT:
			if (!retry) {
				sprintf(cmd, "MOV:YWAIT;");
			} else {
				sprintf(cmd, "RMV:YWAIT;");
			}
			break;
		case Cmd_MOV_YDOOR:
			if (!retry) {
				sprintf(cmd, "MOV:YDOOR;");
			} else {
				sprintf(cmd, "RMV:YDOOR;");
			}
			break;
		case Cmd_MOV_DORBK:
			if (!retry) {
				sprintf(cmd, "MOV:DORBK;");
			} else {
				sprintf(cmd, "RMV:DORBK;");
			}
			break;
		case Cmd_MOV_DORFW:
			if (!retry) {
				sprintf(cmd, "MOV:DORFW;");
			} else {
				sprintf(cmd, "RMV:DORFW;");
			}
			break;
                          
		case Cmd_MOV_RETRY:
			sprintf(cmd, "MOV:RETRY;");
			break;
		case Cmd_MOV_STOP_:
			sprintf(cmd, "MOV:STOP_;");
			break;
		case Cmd_MOV_PAUSE:
			sprintf(cmd, "MOV:PAUSE;");
			break;
		case Cmd_MOV_ABORT:
			sprintf(cmd, "MOV:ABORT;");
			break;
		case Cmd_MOV_RESUM:
			sprintf(cmd, "MOV:RESUM;");
			break;
	}
	// Build checksum calculated string
//	strcat(checksumRange, length);
	strcat(checksumRange, Address);
	strcat(checksumRange, cmd);
//	strcat(checksumRange, length);
	CString strChecksum(checksumRange);
	// Calculate check sum
	SendChecksumCalculator(strChecksum, checksum[0], checksum[1]);
	// Build sending command 
//	strcat(CommandLine, StartHeader);
	CommandLine[0] = StartHeader[0];
//	strcat(CommandLine, length);
	CommandLine[1] = length[0];
	CommandLine[2] = length[1];
//	strcat(CommandLine, Address);
	CommandLine[3] = Address[0];
	CommandLine[4] = Address[1];
//	strcat(CommandLine, cmd);
	for (int i = 0; i < 10; i++) {
		CommandLine[i+5] = cmd[i];
	}
	CommandLine[15] = checksum[0];
	CommandLine[16] = checksum[1];
	CommandLine[17] = Terminate[0];
	CommandLine[18] = Terminate[1];
//	strcat(CommandLine, checksum);
//	strcat(CommandLine, Terminate);
	
	return r;
}

bool TDKLoadPortComm::SendChecksumCalculator(CString data, char& CSH, char& CSI)
{
	bool r = true;
	int i;
	CString chkSum;
	int length = data.GetLength();
	BSTR temp = data.AllocSysString();
	int sum = 0;
	for (i = 0; i< length; i++) {
		sum += (int)temp[i];
	}
	sum += 0x0E;
	chkSum.Format("%x", sum);
	chkSum = chkSum.Right(2);
	CSH = chkSum[0];
	CSI = chkSum[1];
	return r;
}

bool TDKLoadPortComm::RecvChecksumCalculator(char* data, int length, bool hasToCheck)
{
	bool result = false;
	int sum = 0;
	CString chkSum;
	for (int i = 0; i < length - 2; i++) {
		sum += (int)data[i];
	}
	chkSum.Format("%3X", sum);
	chkSum = chkSum.Right(2);
	BSTR temp = chkSum.AllocSysString();
	if (((int)temp[0] != (int)data[length - 2]) || ((int)temp[1] != (int)data[length - 1])) {
		result = false;
	} else {
		result = true;
	}
	if (!hasToCheck) {
		result = true;
	}
	return result;
}

int TDKLoadPortComm::Send(char* CommandLine)
{
	int		r = Err_None;
	BOOL	fWriteStat;
	DWORD	dwBytesWritten=0;
	int		len = 19;
	
	PortComm.CommPurge();
//	len = strlen(CommandLine);
	dwBytesWritten = 0;
	fWriteStat = WriteFile(PortComm.m_hComm, CommandLine, len, &dwBytesWritten, 0);
	TRACE("LPM Send(%s)\n",CommandLine);

	// #T.Tachi151212-02(S)
	CString buffer;
	// #T.Tachi160115-01(S)
	CString hexString;
	::Char2HexString(CommandLine,hexString,dwBytesWritten);
	// #T.Tachi160114-01(E)

	buffer.Format("[TFC->LP :]%s\n",hexString);// #T.Tachi160115-01
	this->err.SaveSoftLogNFL(buffer,TRUE);
	// #T.Tachi151212-02(E)

	if(!fWriteStat || !dwBytesWritten) {
		r = Err_SendError;
	}
	
	return r;
}

int	TDKLoadPortComm::WaitForAnswer(int cmdNo)
{
	int r = Err_None;
	int i;
	for (i = 0; i < LP_ANSWER_QMAX; i++) {
		if (lp_reply_q[i].CmdNum == cmdNo) {
			r = Err_None;
			break;
		} else {
			r = Err_InvalidCmd;
		}
	}
	
	if (r) {
		CSyncObject *ppObjects[2] = {0};
		ppObjects[0] = lp_reply_q[i].pEventObjOK;
		ppObjects[1] = lp_reply_q[i].pEventObjNG;
		
		CMultiLock	M(ppObjects,2);
		int	m = M.Lock(LP_REPLY_TIMEOUT,FALSE);
		if (m == WAIT_TIMEOUT) {
			r = Err_RTimeOut;
		} else if (m == 0) {
			r = Err_None;
		} else {
			r = GetErrorCode(false, cmdNo);
		}
	}
	
	return r;
}

int	TDKLoadPortComm::WaitForEvent(int eventNo)
{
	int r = Err_None;
	int i;
	for (i = 0; i < LP_EVENT_QMAX; i++) {
		if (lp_event_q[i].EventNum == eventNo) {
			r = Err_None;
			break;
		} else {
			r = Err_InvalidCmd;
		}
	}
	
	if (r) {
		CSyncObject *ppObjects[2] = {0};
		ppObjects[0] = lp_event_q[i].pEventObjOK;
		ppObjects[1] = lp_event_q[i].pEventObjNG;
		
		CMultiLock	M(ppObjects,2);
		int	m = M.Lock(LP_EVENT_TIMEOUT,FALSE);
		if (m == WAIT_TIMEOUT) {
			r = Err_ETimeOut;
		} else if (m == 0) {
			r = Err_None;
		} else {
			r = GetErrorCode(true);
		}
	}
	
	return r;
}

void TDKLoadPortComm::DequeueFromAnswerQueue(int cmdNo)
{
	int i;
	for (i = 0; i < LP_ANSWER_QMAX; i++) {
		if (lp_reply_q[i].CmdNum == cmdNo) {
			break;
		}
	}
	if (i < LP_ANSWER_QMAX) {
		lp_reply_q[i].CmdNum = 0;
	}
}

void TDKLoadPortComm::DequeueFromEventQueue(int eventNo)
{
	int i;
	for (i = 0; i < LP_EVENT_QMAX; i++) {
		if (lp_event_q[i].EventNum == eventNo) {
			break;
		}
	}
	if (i < LP_EVENT_QMAX) {
		lp_event_q[i].EventNum = 0;
	}
}

int TDKLoadPortComm::GetErrorCode(bool event, int cmdNo) 
{
	int err;
	const static char* nakArray[] =
	{
		"CKSUM",		"CMDER",		"SFSER",		"INTER",
		"INTER//CKSUM",	"INTER//CMDER",	"INTER//SFSER",	"INTER//CBUSY",
		"INTER//FPILG",	"INTER//LATCH",	"INTER//FPCLP",	"INTER//YPOSI",
		"INTER//DOCPO",	"INTER//DPOSI",	"INTER//PROTS",	"INTER//MPARM",
		"INTER//ZPOSI",	"INTER//MPSTP",	"INTER//DVACM",	"INTER//ERROR",
		"INTER//ORGYT",	"INTER//CLDDK",	"INTER//CULDK",	"INTER//CLOAD",
		"INTER//RMPOS", "fffff"
	};
	if (event) {			// Get error code from event
		LP_ANSWERDATA	answerD;
		char error[2];
		// Send get state command
		int ret = SendLoadPort_GET_STATE(&answerD);
		if (ret) {
			// Get result
			error[0] = answerD.u_asdata.stateLP[4];
			error[1] = answerD.u_asdata.stateLP[5];
			err = strtol(error, NULL, 16);
		}
	} else {				// Get error code from answer
		int i, j;
		for (i = 0; i < LP_ANSWER_QMAX; i++) {
			if (lp_reply_q[i].CmdNum == cmdNo) {
				break;
			}
		}
		if (i < LP_ANSWER_QMAX) {
			for (j = 0; ; j++) {
				// #KI150719-03(S)
				// �s��C��(error�͂��̂܂܂�nakArray���A�b�v)
//				if (strcmp(nakArray[i], "fffff") == 0) {
				if (strcmp(nakArray[j], "fffff") == 0) {	
					err = Err_InvalidCmd;
					break;
				}
//				if (strcmp(lp_reply_q[i].ansData->error, nakArray[i]) == 0) {
				if (strcmp(lp_reply_q[i].ansData->error, nakArray[j]) == 0) {
					err = Err_CKSUM + (j * 0x100);
					break;
				}
				// #KI150719-03(E)
			}
		} else {
			err = Err_InvalidCmd;
		}
	}
	
	return err;
}

bool	TDKLoadPortComm::SetEventEventObject( CEvent *evObj, struct LP_EVENTDATA *evData )
{
	pEventData = evData;
	evEVENT = evObj;
	return true;
}
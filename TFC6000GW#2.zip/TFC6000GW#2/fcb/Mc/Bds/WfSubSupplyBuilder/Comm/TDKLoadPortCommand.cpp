// TDKLoadPortComm.cpp: implementation of the TDKLoadPortComm class.
//
//////////////////////////////////////////////////////////////////////

#include "TDKLoadPortComm.h"

// Get status of load port
int TDKLoadPortComm::SendLoadPort_GET_STATE(LP_ANSWERDATA* ansData)
{
	int 	ret = TRUE;
	char 	CommandLine[1000] = {0};
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_GET_STATE, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_GET_STATE, &EvAnswerOK, &EvAnswerNG, ansData);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_GET_STATE);
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_GET_STATE);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Get slot map information
int TDKLoadPortComm::SendLoadPort_GET_MAPRD(LP_ANSWERDATA* ansData)
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_GET_MAPRD, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_GET_MAPRD, &EvAnswerOK, &EvAnswerNG, ansData);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_GET_MAPRD);
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_GET_MAPRD);
	} while (ret != Err_None && retryCnt < 3);
	
	
	return ret;
}

// Initialize move
int TDKLoadPortComm::SendLoadPort_MOV_ORGSH()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_ORGSH, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_ORGSH, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_ORGSH);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_ORGSH, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_ORGSH);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_ORGSH);
		DequeueFromEventQueue(Event_MOV_ORGSH);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Initialize move (force)
int TDKLoadPortComm::SendLoadPort_MOV_ABORG()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_ABORG, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_ABORG, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_ABORG);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_ABORG, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_ABORG);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_ABORG);
		DequeueFromEventQueue(Event_MOV_ABORG);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Load and make slot map
int TDKLoadPortComm::SendLoadPort_MOV_CLDMP()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_CLDMP, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_CLDMP, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_CLDMP);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_CLDMP, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_CLDMP);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_CLDMP);
		DequeueFromEventQueue(Event_MOV_CLDMP);
	} while (ret != Err_None && retryCnt < 3);
		
	return ret;
}

// Unload and make slot map
int TDKLoadPortComm::SendLoadPort_MOV_CUDMP()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_CUDMP, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_CUDMP, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_CUDMP);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_CUDMP, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_CUDMP);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_CUDMP);
		DequeueFromEventQueue(Event_MOV_CUDMP);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Load only
int TDKLoadPortComm::SendLoadPort_MOV_CLOAD()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_CLOAD, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_CLOAD, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_CLOAD);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_CLOAD, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_CLOAD);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_CLOAD);
		DequeueFromEventQueue(Event_MOV_CLOAD);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Unload only
int TDKLoadPortComm::SendLoadPort_MOV_CULOD()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_CULOD, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_CULOD, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_CULOD);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_CULOD, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_CULOD);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_CULOD);
		DequeueFromEventQueue(Event_MOV_CULOD);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Unload until close carrier door
int TDKLoadPortComm::SendLoadPort_MOV_CULYD()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_CULYD, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_CULYD, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_CULYD);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_CULYD, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_CULYD);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_CULYD);
		DequeueFromEventQueue(Event_MOV_CULYD);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Dock
int TDKLoadPortComm::SendLoadPort_MOV_YDOOR()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_YDOOR, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_YDOOR, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_YDOOR);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_YDOOR, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_YDOOR);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_YDOOR);
		DequeueFromEventQueue(Event_MOV_YDOOR);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Undock
int TDKLoadPortComm::SendLoadPort_MOV_YWAIT()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_YWAIT, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_YWAIT, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_YWAIT);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_YWAIT, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_YWAIT);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_YWAIT);
		DequeueFromEventQueue(Event_MOV_YWAIT);
	} while (ret != Err_None && retryCnt < 3);
	
	DequeueFromAnswerQueue(Cmd_MOV_YWAIT);
	DequeueFromEventQueue(Event_MOV_YWAIT);
	return ret;
}

// Clamp open
int TDKLoadPortComm::SendLoadPort_MOV_PODOP()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_PODOP, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_PODOP, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_PODOP);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_PODOP, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_PODOP);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_PODOP);
		DequeueFromEventQueue(Event_MOV_PODOP);
	} while (ret != Err_None && retryCnt < 3);
	
	
	return ret;
}

// Clamp close
int TDKLoadPortComm::SendLoadPort_MOV_PODCL()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_PODCL, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_PODCL, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_PODCL);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_PODCL, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_PODCL);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_PODCL);
		DequeueFromEventQueue(Event_MOV_PODCL);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

// Release error 
int TDKLoadPortComm::SendLoadPort_SET_RESET()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_SET_RESET, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_SET_RESET, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_SET_RESET);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_SET_RESET, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_SET_RESET);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_SET_RESET);
		DequeueFromEventQueue(Event_SET_RESET);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

int TDKLoadPortComm::SendLoadPort_MOV_VACON()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_VACON, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_VACON, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_VACON);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_VACON, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_VACON);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_VACON);
		DequeueFromEventQueue(Event_MOV_VACON);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

int TDKLoadPortComm::SendLoadPort_MOV_VACOF()
{
	int 	ret = TRUE;
	char 	CommandLine[1000];
	bool 	retry = false;
	int 	retryCnt = 0;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	CEvent 	EvEventOK;
	CEvent	EvEventNG;
	LP_ANSWERDATA	answerD;
	LP_EVENTDATA	eventD;
	
	do {
		// Reset event
		EvAnswerOK.ResetEvent();
		EvAnswerNG.ResetEvent();
		EvEventOK.ResetEvent();
		EvEventNG.ResetEvent();
		// Clear command buffer
		memset(CommandLine, 0, sizeof(CommandLine));
		// Make command string 
		MakeCommandString(Cmd_MOV_VACOF, CommandLine, retry);
		// Send command to Load port
		ret = Send(CommandLine);
		if (ret == Err_None) {
			// Set answer object event
			SetAnswerObject(Cmd_MOV_VACOF, &EvAnswerOK, &EvAnswerNG, &answerD);
			// Wait for answer from load port
			ret = WaitForAnswer(Cmd_MOV_VACOF);
			if (ret == Err_None) {
				// Set event object event
				SetEventObject(Event_MOV_VACOF, &EvEventOK, &EvEventNG, &eventD);
				// Wait for reply
				ret = WaitForEvent(Event_MOV_VACOF);
			}
		}
		if (ret != Err_None) {
			retry = true;
			retryCnt++;
		}
		DequeueFromAnswerQueue(Cmd_MOV_VACOF);
		DequeueFromEventQueue(Event_MOV_VACOF);
	} while (ret != Err_None && retryCnt < 3);
	
	return ret;
}

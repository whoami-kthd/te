// LoadPort.cpp: LoadPort �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LoadPort.h"
#include "RobotArm.h"	// ���{�b�g�̃X�e�[�^�X�����邽��

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

LoadPort::LoadPort()
{

}

LoadPort::~LoadPort()
{

}

LoadPort::LoadPort(
					CString	name,					// ���O
					OrdinarySnsTBL* pLpmReady,		// LPM_Ready
					OrdinarySnsTBL* pDoorOpened,	// DoorOpened
					OrdinarySnsTBL* pCarrierPlaced,	// CarrierPlaced
					OrdinarySnsTBL* pDoorClosed,	// DoorClosed
					int	class_id,					// ���̃N���X�h�c
					int myErrStart)					// �����̃G���[�擪
					:LoadPortComm(),					// ��M�X���b�h�̋N���Ƃ����Ă���̂ŁA�����I�ɃR���X�g���N�^�N������B
					 m_RFIDComm()
{
	this->name	= name;
	// �G���[�̏�����
	this->err.Initinstance(class_id, myErrStart);
	//
	this->isEnable = false;
	// LPM_Ready���o������
	if(pLpmReady->sensor_no >= 0){// �A�h���X���_�~�[�łȂ����
		this->snsLpmReady.Initinstance(class_id, pLpmReady);
	}
	// DoorOpened���o������
	if(pDoorOpened->sensor_no >= 0){// �A�h���X���_�~�[�łȂ����
		this->snsDoorOpened.Initinstance(class_id, pDoorOpened);
	}
	// CarrierPlaced���o������
	if(pCarrierPlaced->sensor_no >= 0){// �A�h���X���_�~�[�łȂ����
		this->snsCarrierPlaced.Initinstance(class_id, pCarrierPlaced);
	}
	// DoorClosed���o������
	if(pDoorClosed->sensor_no >= 0){// �A�h���X���_�~�[�łȂ����
		this->snsDoorClosed.Initinstance(class_id, pDoorClosed);
	}
	this->waferNumberMax	= 25;
	this->Plset				= 1;
	this->accessSW[0]		= false;
	this->accessSW[1]		= false;
	this->makeSlotMap		= false;
	for(int i=0;i<eWaferNumberMax;i++){
		this->waferID[i]	= '0';
		this->waferUmu[i]	= LoadPort::eWaferNone;
	}
	pRobotStatus = NULL;
	this->slotMapIsMade		= false;
	this->m_accessSW		= false;

	this->pEvCarrierActionRequested	= NULL;
}
BOOL LoadPort::Init(){
	int	r = TRUE;
	// �C�x���g��M�X���b�h�N��(�ꎞ��~���[�h�ŋN������ɍĊJ����)
	pEThread = AfxBeginThread( EventProc, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED );
	if( !pEThread ){
		AfxMessageBox( "�C�x���g��M�X���b�h�̋N���Ɏ��s���܂����B", MB_OK, 0 );
		return FALSE;
	}
	// �گ������ٕۑ�
	m_hEventRThread = pEThread->m_hThread;
	pEThread->ResumeThread();	// �C�x���g��M�X���b�h����J�n
	LoadPortComm.SetEventEventObject(&evEVENT, &evData);
//	LoadPortComm.SetEventEventObject( &evEVENT2000, &evData2000 );
	return	r;
}
// �C�x���g��M�X���b�h
UINT	LoadPort::EventProc( LPVOID pParam )
{
	CString			str;
	LoadPort	*pLPt = (LoadPort *)pParam;
	CSingleLock	S( &(pLPt->evEVENT) );
	str.Empty();
	for(;;) {
		S.Lock( INFINITE );
		if ((strcmp(pLPt->evData.command, "MANSW") == 0) /*|| (strcmp(pLPt->evData.command, "MA2SW") == 0)*/) {
			pLPt->m_accessSW = true;
			///////////////////////////////
		} else if ((strcmp(pLPt->evData.command, "MANOF") == 0) /*|| (strcmp(pLPt->evData.command, "MA2OF") == 0)*/) {
			pLPt->m_accessSW = false;
		} else {
			// Do nothing
		}
		S.Unlock();
	}
	return 0;
}
//////////////////////////////////////////////////////////////////////
//
// �Z���T�֌W
//
bool LoadPort::LPMReadySns(bool &isOn)
{
	return (this->snsLpmReady.IsDetected(isOn));
}
bool LoadPort::DoorOpenedSns(bool &isOn)
{
	return (this->snsDoorOpened.IsDetected(isOn));
}
bool LoadPort::CarrierPlacedSns(bool &isOn)
{
	return (this->snsCarrierPlaced.IsDetected(isOn));
}
bool LoadPort::DoorClosedSns(bool &isOn)
{
	return (this->snsDoorClosed.IsDetected(isOn));
}
bool LoadPort::RobotArmIsSafety(bool errOut)
{
	bool isSafety = true;
// #KI150721-01(S)Todo
#if 1
	// ���{�b�g�A�[���̈ʒu���`�F�b�N
	if((this->pRobotStatus == NULL)
		||(*this->pRobotStatus == RobotArm::eDirUnknown)){
		isSafety = false;
		if(errOut){
			this->err.PutError(Err_RobotArmIsUnknown);
		}
	}
	else if(*this->pRobotStatus == RobotArm::eDirCasette){
		isSafety = false;
		if(errOut){
			this->err.PutError(Err_RobotArmIsNotSafety);
		}
	}
#endif
// #KI150721-01(E)
	return(isSafety);
}
// #DDT160515-05 (S)
int		LoadPort::GetSlotSts(int slot)
{
	if(slot > waferNumberMax || slot <= 0){
		CString msg;
		msg.Format("Error %s(%d) Slot number is invalid = %d", __FILE__, __LINE__, slot);
		AfxMessageBox(msg);
		AfxDebugBreak();
		return 0;
	}
	return this->waferUmu[slot-1];
}
void	LoadPort::UpdateSlotSts(int slot, int status)
{
	if(slot > waferNumberMax || slot <= 0){
		CString msg;
		msg.Format("Error %s(%d) Slot number is invalid = %d", __FILE__, __LINE__, slot);
		AfxMessageBox(msg);
		AfxDebugBreak();
		return;
	}
	this->waferUmu[slot-1] = status;
}
// #DDT160515-05 (E)
void	LoadPort::PutLoadPortError(int code, const char *buf){
	if(code == TDKLoadPortComm::Err_RTimeOut
			|| code == TDKLoadPortComm::Err_ETimeOut
			|| code == TDKLoadPortComm::Err_SendError
			|| code == TDKLoadPortComm::Err_INTER_CKSUM
			|| code == TDKLoadPortComm::Err_INTER_CMDER){
		this->err.PutError(Err_Communication);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0x02
			|| code == TDKLoadPortComm::Err0x42
			|| code == TDKLoadPortComm::Err0x04
			|| code == TDKLoadPortComm::Err0x44
			|| code == TDKLoadPortComm::Err_INTER_YPOSI
			|| code == TDKLoadPortComm::Err_INTER_ZPOSI) {
		this->err.PutError(Err_PivotStatusAbnormal);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err_INTER_CBUSY
			|| code == TDKLoadPortComm::Err_INTER_ERROR
			|| code == TDKLoadPortComm::Err_INTER_ORGYT) {
		this->err.PutError(Err_LpmIsNotReady);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0x07
			|| code == TDKLoadPortComm::Err0x47) {
		this->err.PutError(Err_WaferSlideOout);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0x08
			|| code == TDKLoadPortComm::Err0x48
			|| code == TDKLoadPortComm::Err0x31
			|| code == TDKLoadPortComm::Err0xF1
			|| code == TDKLoadPortComm::Err_INTER_DOCPO
			|| code == TDKLoadPortComm::Err_INTER_DPOSI) {
		this->err.PutError(Err_DoorStatusAbnormal);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0x09
			|| code == TDKLoadPortComm::Err0x12
			|| code == TDKLoadPortComm::Err0x49
			|| code == TDKLoadPortComm::Err0xA3
			|| code == TDKLoadPortComm::Err0xEF
			|| code == TDKLoadPortComm::Err0xEE
			|| code == TDKLoadPortComm::Err_INTER_MPARM
			|| code == TDKLoadPortComm::Err_INTER_MPSTP
			|| code == TDKLoadPortComm::Err_INTER_RMPOS) {
		this->err.PutError(Err_Mapper);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0x21
			|| code == TDKLoadPortComm::Err0x22
			|| code == TDKLoadPortComm::Err_INTER_FPCLP) {
		this->err.PutError(Err_Clamp);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0x23) {
		this->err.PutError(Err_LatchNotOpen);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0x24) {
		this->err.PutError(Err_LatchNotClose);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0x25
			|| code == TDKLoadPortComm::Err0x26
			|| code == TDKLoadPortComm::Err_INTER_DVACM) {
		this->err.PutError(Err_VacuumStatusAbnormal);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err0xA1
			|| code == TDKLoadPortComm::Err0xA2) {
		this->err.PutError(Err_CarrierDoorInterlock);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err_INTER_LATCH) {
		this->err.PutError(Err_LatchStatusAbnormal);
		this->err.LogSaveNFL(buf);
		// #KI150719-02(S)
		// �W���̃G���[�ǉ�
	} else if (code == TDKLoadPortComm::Err_INTER) {
		this->err.PutError(Err_InterLock);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err_CMDER) {
		this->err.PutError(Err_Command);
		this->err.LogSaveNFL(buf);
	} else if (code == TDKLoadPortComm::Err_CKSUM) {
		this->err.PutError(Err_CheckSum);
		this->err.LogSaveNFL(buf);
		// #KI150719-02(E)
	} else {
		this->err.PutError(Err_59);
	}

}

/////////////////////////////////////////
//
// TSR
// ������RS-232C�Ƃ�I/F�ƍŏ��̃R�}���h���L�q
//
//


#include "stdafx.h"

#include "CodeReader.h"

CKeyenceReader Code2DReader;

//------------------------------------------------------------------------------

CCodeReader::CCodeReader()
: m_UpTime(0)
, m_Timer(5)
// #KS20141203-01 [�ǉ�]2D���[�_(SR-1000)�Ή�
, m_Type(0)
{

}
CCodeReader::~CCodeReader()
{

}

void CCodeReader::DumpData(const int sr, BOOL r, const char *buf, const int sz)
{
	if (0 == sr) {	// send
		TRACE("Send(%d)(%d)[", sz, r);
	} else {
		TRACE("Recv(%d)(%d)[", sz, r);
	}
	for (int i = 0; i < sz; i++) {
		if (isprint(buf[i])) {
			TRACE("%c", buf[i]);
		} else {
			TRACE("<%02x>", buf[i]);
		}
	}
	TRACE("]\n");
}
BOOL CCodeReader::CommEventWaitRead( BYTE *pszBuf )
{
	BOOL r = CPortComm::CommEventWaitRead(pszBuf);
#if GPDEBUG
	DumpData(1, r, (const char *)pszBuf, (r) ? 1 : 0);
#endif
	return(r);
}

BOOL CCodeReader::WriteComP(const char* lpByte ,int dwBytesToWrite)
{
	BOOL r = CPortComm::WriteComP(lpByte, dwBytesToWrite);
#if GPDEBUG
	DumpData(0, r, lpByte, dwBytesToWrite);
#endif
	return(r);
}

// �^�C�}�[���Z�b�g����
void CCodeReader::SetTimerVal(int TimeUpSec)
{
	m_Timer = TimeUpSec;
}

void CCodeReader::StartTimer()
{
	time(&m_UpTime);
	m_UpTime += m_Timer;
}

BOOL CCodeReader::IsTimeUp()
{
	time_t t;
	time(&t);
	return((0 <= (t - m_UpTime)) ? TRUE : FALSE);
}

// #KS20141203-01(S) [�ǉ�]2D���[�_(SR-1000)�Ή�
void CCodeReader::SetType(int iType)
{
	m_Type = iType;
	return;
}
// #KS20141203-01(E)

//------------------------------------------------------------------------------

CKeyenceReader::CKeyenceReader()
: m_Header(0x00)
, m_Terminator(0x0d)
{

}

CKeyenceReader::~CKeyenceReader()
{

}

BOOL CKeyenceReader::CommSetting()
{
	// get any early notifications(�ʐM�|�[�g�ɑ΂���Ď��C�x���g�𖾊m�ɂ���)
	SetCommMask( m_hComm, EV_RXCHAR ) ;
	// setup device buffers (����M�ޯ̧���ނ̎w��)
	if( !SetupComm( m_hComm, 4096, 4096 ) )
		return FALSE;
	// purge any information in the buffer(����M�ޯ̧�̸ر)
	PurgeComm( m_hComm,	PURGE_TXABORT | PURGE_RXABORT |
						PURGE_TXCLEAR | PURGE_RXCLEAR ) ;

	// set up for overlapped I/O (Timeout�ݒ�)
	m_CommTimeOuts.ReadIntervalTimeout =0xFFFFFFFF ;		// ������ Timeout
	m_CommTimeOuts.ReadTotalTimeoutMultiplier = 0 ;
	m_CommTimeOuts.ReadTotalTimeoutConstant = 3000 ;		// ��M Timeout(ms)
	m_CommTimeOuts.WriteTotalTimeoutMultiplier = 0 ;
	m_CommTimeOuts.WriteTotalTimeoutConstant = 1000 ;		// ���M Timeout(ms)
	// ��ѱ�Đݒ�
	if(!SetCommTimeouts(m_hComm, &m_CommTimeOuts))
		return FALSE;

	//*** COM Port Setup ***
		
	m_Dcb.DCBlength = sizeof( DCB ) ;
	if(!GetCommState( m_hComm, &m_Dcb ))	// �ʐM�߰Ă̌��ݒ�̎擾
		return FALSE;

	// DCB�\���̂ɐݒ�l��āi�����w�蕔���j
	m_Dcb.BaudRate = m_BaudRate;	// �`�����x
	m_Dcb.ByteSize = m_ByteSize;	// �ް���(4�`8)
	m_Dcb.StopBits = m_StopBits;	// STOP�r�b�g 0=1�r�b�g 1=2�r�b�g
	m_Dcb.fParity  = m_fParity;		// ���è���� 0=���A1=�L
	if( m_fParity == 0 )
		m_Dcb.Parity   = NOPARITY;   // 0=no, 1=odd, 2=even
	else
		m_Dcb.Parity = m_Parity;
	                                // ���è���������̏ꍇ�AParity�ɂ�NOPARYTY���
	                                // �L��̏ꍇ�́AODD | EVEN �̐���������Ă��鎖�B

	// DCB�\���̂�ݒ肵�܂��B�i�����w�蕔���O�j
	m_Dcb.XonLim = 100;
	m_Dcb.XoffLim = 100;
	// other various settings
	m_Dcb.fBinary = TRUE ;						// binary mode

	m_Dcb.fTXContinueOnXoff = 0;
	m_Dcb.fOutX = FALSE;							// XON/XOFF out flow control
	m_Dcb.fInX = FALSE;							// XON/XOFF in flow control
	m_Dcb.fDtrControl = DTR_CONTROL_DISABLE;  // DTR flow control type
	m_Dcb.fRtsControl = RTS_CONTROL_DISABLE;   // RST flow control (default)
	m_Dcb.fAbortOnError = 0;

	m_Dcb.fNull = FALSE;			// NULL�����̔j��
	m_Dcb.EofChar = 0x0;        // end of input character ���̕������������ް��I��
	m_Dcb.EvtChar = 0x0;        // received event character ���̕�������M����Ʋ���Ă�����

	// �ʐM�߰Ă̐ݒ��ύX���܂��B
	if(!SetCommState(m_hComm, &m_Dcb))
		return FALSE;

	//// DTR( data-terminal-ready)�M���𑗂�܂��B�[���̓��f�B��ԂɂȂ�B
	//if( !EscapeCommFunction(m_hComm, SETDTR)) {
	//	return FALSE;
	//}

	return TRUE;
}

// �o�[�R�[�h���[�_�ɃR�}���h�𑗂�
BOOL CKeyenceReader::SendCmd(const char *pCode, const char *pPara, int iSz)
{
	char Buff[BUFSIZ];
	BOOL r = TRUE;
	if (m_Header) {
		sprintf(Buff, "%c%s%c", m_Header, pCode, m_Terminator);
	} else {
		sprintf(Buff, "%s%c", pCode, m_Terminator);
	}
	CommPurge();
	int ret = 0;	// ����ɏ�����
	r = WriteComP((LPCTSTR)Buff, strlen(Buff));
// #KS20141203-01(S) [�ǉ�]2D���[�_(SR-1000)�Ή�
	if (r && 1 == m_Type
		&& (0 == strcmp("LON", pCode) || 0 == strcmp("LOFF", pCode))
		) {
		return(r);
	}
// #KS20141203-01(E)
	if (r) r = RecvData((LPSTR)Buff);
// #KS20141203-01(S) [�ǉ�]2D���[�_(SR-1000)�Ή�
	if (r && 1 == m_Type) {
		if (0 == strcmp("BCLR", pCode)) {
			if (strcmp("OK", Buff)) {
				r = FALSE;
			}
		} else {
			r = FALSE;
		}
	} else
// #KS20141203-01(E)
	if (r) {
		if (!strncmp(Buff, "OK", 2)) {
			if (',' == Buff[2]
				&& !strncmp(&Buff[3], pCode, strlen(pCode))) {
				;	//
			} else {
				r = FALSE;
			}
		} else if (!strncmp(Buff, "ER", 2)) {
			r = FALSE;
		} else {
			r = FALSE;
		}
	}
	return(r);
}

BOOL CKeyenceReader::RecvData(LPSTR txtptr)
{
	BYTE Buff[BUFSIZ];
	BYTE dt;
	BYTE ret;

	StartTimer();
	ret = 0;
	int j = 0;
	bool bData = (m_Header) ? false : true;
	while (true) {
		dt = 0;
		if (CommEventWaitRead(&dt)) {
			if (bData) {
				if (m_Terminator == dt) {
					Buff[j] = 0;
					memcpy(txtptr, Buff, j + 1);
					ret = 1;
					break;
				} else if (dt) {
					Buff[j++] = dt;
				}
				if (BUFSIZ <= j) {
					break;
				}
			} else if (m_Header == dt) {
				bData = true;
			}
		}
		if (IsTimeUp()) {
			break;	// time out
		}
	}
	return((1 == ret) ? TRUE : FALSE);
}


BOOL CKeyenceReader::Reset()
{
	BOOL r = TRUE;
	r = SendCmd("BCLR", NULL, 0);
	return(r);
}

BOOL CKeyenceReader::IDRead(CString &strID)
{
	BYTE Buff[BUFSIZ];
	memset(Buff ,0x00, sizeof(Buff));

	BOOL r = SendCmd("BCLR", NULL, 0); 
	if (r) r = SendCmd("LON", NULL , 0);
	if (r) r = RecvData((LPSTR)Buff);
	strID = (r) ? (char *)Buff : "";
// #KS20141203-01(S) [�ǉ�]2D���[�_(SR-1000)�Ή�
	if (r && 1 == m_Type && 0 == strcmp("ERROR", (char *)Buff)) {
		r = FALSE;
		strID = "";
	}
// #KS20141203-01(E)
	SendCmd("LOFF", NULL , 0);
// #KS20141203-01(S) [�ǉ�]2D���[�_(SR-1000)�Ή�
#if 0	// ���[�_�{�̂őΉ��\
	if (r && 1 == m_Type) {
		SendCmd("AMOFF", NULL, 0);
	}
#endif
// #KS20141203-01(E)
	return(r);
}

// Cycloid.cpp: Cycloid �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include "MC\DEFS\Cycloid.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

Cycloid::Cycloid()
{

}

Cycloid::~Cycloid()
{

}

Cycloid::Cycloid(double radius, double lift)
{
	this->radius	= radius;
	this->lift		= lift;
}

double Cycloid::AngleCnvPos(double angle)
// double angle : (rad)�Ŋp�x�w��
// �p�x(rad)����ʒu(mm)���Z�o����B
{
	double r,l,result, zOffset;
	r = this->radius;
	l = this->lift/2;
	zOffset = r - l;
//	if (angle < 0) {
//		result = -(sqrt((r*r)-2*(r*l)*cos(angle)+(l*l)) - sqrt((r*r)-2*(r*l)*cos(0)+(l*l)));
//	} else {
		result = sqrt((r*r)-2*(r*l)*cos(angle)+(l*l)) - zOffset;
//	}
	return result;
}

double Cycloid::PosCnvAngle(double pos)
// double pos : (mm)�ňʒu�w��
// �ʒu(mm)����p�x(rad)���Z�o����B
{
	double r,l,result, zOffset;
	r = this->radius;
	l = this->lift/2;
	zOffset = r - l;
//	if (pos < 0) {	// �ʒu�����Ȃ��
//		pos = -pos;
//		pos += sqrt((r*r)-2*(r*l)*cos(0)+(l*l));
//		result = -acos(((r*r)+(l*l)-(pos*pos))/(2*r*l));
//	} else {
		pos += zOffset;
		result = acos(((r*r)+(l*l)-(pos*pos))/(2*r*l));
		if(l < 0){result *= (-1);}
//	}
	return result;
}


// SecsGem300.cpp: SecsGem300 �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SecsGem300.h"

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

SecsGem300::SecsGem300()
{
	this->pEvFinInfoComState	= NULL;
	this->pEvFailInfoComState	= NULL;
}

SecsGem300::~SecsGem300()
{

}

BOOL SecsGem300::OpenProject(){


	BOOL r = TRUE;
	return r;
}


BOOL SecsGem300::ChangeCR(){
	BOOL r = TRUE;
	return r;
}

void SecsGem300::OnInfoComStateXcomsecsctrl1(short com_state, short hst_sts, short eq_sts) 
{
	// 
	//
	//
	// this->pEvFinInfoComState->SetEvent();



}



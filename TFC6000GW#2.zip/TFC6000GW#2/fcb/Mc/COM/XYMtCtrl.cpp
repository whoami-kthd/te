// XYMtCtrl.cpp: XYMtCtrl �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include "MC\DEFS\XYMtCtrl.h"
#include "mcc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////
XYMtStatus::XYMtStatus()
{

}

XYMtStatus::~XYMtStatus()
{

}
MCCtrl	*XYMtStatus::pMCC = NULL;		// ���u����׽�ւ��߲��
void	XYMtStatus::InitInstance(int class_id, int mIdx1, int mIdx2)
{
	this->class_id	= class_id;
	this->mIdx1		= mIdx1;
	this->mIdx2		= mIdx2;
}
bool	XYMtStatus::GetOriginSensor(void){			// ���_�Z���T��Ԏ擾
	int	status1 = 0;
	int	status2 = 0;
	if(this->class_id == BND_ID){
		status1 = pMCC->BND.MotorStatus(this->mIdx1);		// Ӱ���ð���̎擾
		status2 = pMCC->BND.MotorStatus(this->mIdx2);		// Ӱ���ð���̎擾
	}else if(this->class_id == BDS_ID){
		status1 = pMCC->BDS.MotorStatus(this->mIdx1);		// Ӱ���ð���̎擾
		status2 = pMCC->BDS.MotorStatus(this->mIdx2);		// Ӱ���ð���̎擾
	}else if(this->class_id == ICS_ID){
		status1 = pMCC->ICS.MotorStatus(this->mIdx1);		// Ӱ���ð���̎擾
		status2 = pMCC->ICS.MotorStatus(this->mIdx2);		// Ӱ���ð���̎擾
	}else{
		status1 = 0;
		status2 = 0;
		CString msg;
		msg.Format("Error %s(%d) MCC�N���X�͂��肦�Ȃ� = %d", __FILE__, __LINE__, this->class_id);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	return ((status1 & MelecC864::NORG)||(status2 & MelecC864::NORG)) ? true : false;
}
BOOL XYMtStatus::MotorPosition(R2Pos& p){	// ���݈ʒu�̎擾
	int	r = FALSE;
	if(this->class_id == BND_ID){
		// ���݈ʒu�̎擾
		r = pMCC->BND.MotorPosition(this->mIdx1, p.x);
		r = pMCC->BND.MotorPosition(this->mIdx2, p.y);
	}else if(this->class_id == BDS_ID){
		// ���݈ʒu�̎擾
		r = pMCC->BDS.MotorPosition(this->mIdx1, p.x);
		r = pMCC->BDS.MotorPosition(this->mIdx2, p.y);
	}else if(this->class_id == ICS_ID){
		// ���݈ʒu�̎擾
		r = pMCC->ICS.MotorPosition(this->mIdx1, p.x);
		r = pMCC->ICS.MotorPosition(this->mIdx2, p.y);
	}else{
		CString msg;
		msg.Format("Error %s(%d) MCC�N���X�͂��肦�Ȃ� = %d", __FILE__, __LINE__, this->mIdx1);
		msg.Format("Error %s(%d) MCC�N���X�͂��肦�Ȃ� = %d", __FILE__, __LINE__, this->mIdx2);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	return(r);
}

XYMtCtrl::XYMtCtrl()
{

}

XYMtCtrl::~XYMtCtrl()
{

}

BOOL XYMtCtrl::MotorMoveAbs(R2Pos p,double s,BOOL EWait)	// ��΋쓮	p:���W(mm,rad) s:�쓮���x (mm/s,rad/s) 0�Œʏ푬�x
{
	int	r = FALSE;
	int status;
	double time1,time2;
	if(this->class_id == BND_ID){
		// ��Έʒu�ړ�
		r = pMCC->BND.MotorMoveAbs(this->mIdx1, p.x, s, EWait);
		if (r) r = pMCC->BND.MotorMoveAbs(this->mIdx2, p.y, s, EWait);
		if (!EWait) {
			pMCC->BND.GetTimeOut(this->mIdx1, p.x, s, time1);
			pMCC->BND.GetTimeOut(this->mIdx2, p.y, s, time2);
			r = pMCC->BND.MotorMoveEnd(this->mIdx1, time1, status) && r;
			r = pMCC->BND.MotorMoveEnd(this->mIdx2, time2, status) && r;
		}
	}else if(this->class_id == BDS_ID){
		// ��Έʒu�ړ�
		r = pMCC->BDS.MotorMoveAbs(this->mIdx1, p.x, s, EWait);
		if (r) r = pMCC->BDS.MotorMoveAbs(this->mIdx2, p.y, s, EWait);
		if (!EWait) {
			pMCC->BND.GetTimeOut(this->mIdx1, p.x, s, time1);
			pMCC->BND.GetTimeOut(this->mIdx2, p.y, s, time2);
			r = pMCC->BND.MotorMoveEnd(this->mIdx1, time1, status) && r;
			r = pMCC->BND.MotorMoveEnd(this->mIdx2, time2, status) && r;
		}
	}else if(this->class_id == ICS_ID){
		// ��Έʒu�ړ�
		r = pMCC->ICS.MotorMoveAbs(this->mIdx1, p.x, s, EWait);
		if (r) r = pMCC->ICS.MotorMoveAbs(this->mIdx2, p.y, s, EWait);
		if (!EWait) {
			pMCC->ICS.GetTimeOut(this->mIdx1, p.x, s, time1);
			pMCC->ICS.GetTimeOut(this->mIdx2, p.y, s, time2);
			r = pMCC->ICS.MotorMoveEnd(this->mIdx1, time1, status) && r;
			r = pMCC->ICS.MotorMoveEnd(this->mIdx2, time2, status) && r;
		}
	}else{
		CString msg;
		msg.Format("Error %s(%d) MCC�N���X�͂��肦�Ȃ� = %d", __FILE__, __LINE__, this->mIdx1);
		msg.Format("Error %s(%d) MCC�N���X�͂��肦�Ȃ� = %d", __FILE__, __LINE__, this->mIdx2);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	return(r);
}



// Cycloid.h: Cycloid �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CYCLOID_H__8468A462_3AAD_4427_823F_2A3717DE4E88__INCLUDED_)
#define AFX_CYCLOID_H__8468A462_3AAD_4427_823F_2A3717DE4E88__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include	<pos.h>
#include	<SingleMtCtrl.h>

class Cycloid  
{
public:
	Cycloid();
	virtual ~Cycloid();
	Cycloid(double radius, double lift);
private:
//*******************************************
//
//	private �ϐ�
//
//*******************************************
	double	radius;							// �~�J���̔��a
	double	lift;							// �~�J���̃��t�g��
//	double	tOffset;

public:
//*******************************************
//
//	public �ϐ�
//
//*******************************************

public:
//*******************************************
//
//	public getter
//
//*******************************************

public:
//*******************************************
//
//	public setter
//
//*******************************************

public:
//*******************************************
//
//	public method
//
//*******************************************
double AngleCnvPos(double angle);			// �ʒu����p�x���Z�o����
double PosCnvAngle(double pos);				// �p�x����ʒu���Z�o����

public:
//*******************************************
//
//	error
//
//*******************************************
};

#endif // !defined(AFX_CYCLOID_H__8468A462_3AAD_4427_823F_2A3717DE4E88__INCLUDED_)

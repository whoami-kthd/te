/*---------------------------------------------------------------------
	Base class for SM loader and unloader
								2013 HangNT / TSDV
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
////////////////////////////////////////////////////////////////////////

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include	<mcstd.h>
#include	<SingleMtCtrl.h>
#include	"..\COM\PauseAndWait.h"

#include	"..\COM\CommonDef.h"

class StdSbstLDUDCtrl : public MCCStd
{
	public:
		StdSbstLDUDCtrl();
		virtual ~StdSbstLDUDCtrl();
		StdSbstLDUDCtrl (
					CString name,
					int class_id,					// Class ID					
					OrdinarySnsTBL* pSnsMgzExist,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsMgzExist2,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsCoverClose,	// Cover close detect sensor
					OrdinarySnsTBL* pSnsSubstExist,	// Subst exist sensor
					int idx_mtMgz,					// Transfer motor X index
					int myErrStart					// Error start
				);

	public:
		enum {					
				ELVZ	= 0 ,	// Elevator-Z		
				MT_MAX			// Motor�@Number		
			};
	protected:
		CString			m_name;
		CString			m_MCSec;
		CString			m_DVSec;
		CString			m_PDSec;			// yk130508

		int				m_classID;
		OrdinarySensor	m_snsMgzExist[2];			// Magazine existence check sensor
		OrdinarySensor	m_snsCoverClose;		// Dock close check sensor
		OrdinarySensor	m_snsSubstExist;		// Magazine subst exist sensor
		ErrorMediator	m_err;
		int				m_currentSlot;			// Current active slot number	
		SingleMtCtrl	m_mtMgz;				// Magazine control motor
		bool			m_slotMapIsMade;		// Slot map made status
		int				m_isAutoRunning;
		bool			m_isAging;				// yk130430#7:aging�^�]���ɾݻ�𖳎�����
		int				m_MgzNumber;
		int				m_mgzFeedType;
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
		CSemaphoreX*	pMCPauseSema;
	public:
		enum {
			eSubstNumberMax = 40,		// #yk150522-2:���϶޼�݌���ү���ނ̗�O�s��C��
		};
		int				waferUmu[eMgzMax][eSubstNumberMax+1];		// #yk150522-2:���϶޼�݌���ү���ނ̗�O�s��C��
		

	public:
		PauseAndWait	pauseWait;	
			
		struct MC_Data {
			MC_Data() {	//			
				FName		= _T("");
						}
			CString	Sec;		// Data Section
			CString	FName;		// File name			

			// Magazine data struct
			struct MgzData {
				MgzData() {
					Sec = _T(":Magazine data");
				}

				CString Sec;	// Data section
				CString	FName;
				
				double	mgzHeightTeach;	// Magazine height at teaching
				double	elvOffset[2];		// Elevator offset				
				double	mgzExchgPos;	// Magazine exchange position
				double	mgzWaitPos;		// Magazine wait position
				double	pusherLimitPos;	// Feed pusher limit position
				double	speedRatio;		// Moving speed ratio
			} MgzD;
		} m_MD;

		
		
		struct DV_Data {
			DV_Data() {			
				FName	= _T("");
			}
			
			CString FName;
			
			double	pitch;					// Pitch
			double  EscLvl;					// Magazine escape level
			int		stockNo[eMgzMax];		// Stock number
			double	topHeight;				// Top height
			double	mgzWidth;				// Magazine width
			double	mgzHeight;				// Magazine height
			double	frmTopHeight;			// Frame top height
			double	frmStoreHeight;			// Frame store height
			double	EvtRingChkOfsHeight;	// Ring check position
			int		ElvSns_Timer;			// Elevator sensor timer	
			double	BackPushTimer;			// Backpush timer
		} m_DD;			

		struct PD_Data{			// yk130508
			PD_Data(){
				currSlitNo[0]	= 1;
				currSlitNo[1]	= 1;
				currMgzNo		= 0;		// 0=Low,1=Up
			}
			int		currSlitNo[2];			// Pitch
			int		currMgzNo;				// Current magazine		// 0=Low,1=Up
		} m_PD;

	public:
		virtual BOOL WaitAndExecute() = 0;
		// Get next slot number
		virtual BOOL GetNextSlot(int& mgzNo, int& slot, bool& canGet) = 0;
		virtual BOOL MgEndSub() = 0;
		virtual BOOL MakeSlotMap() = 0;
		virtual BOOL MgRingCheckPosMove(int mgzNo, int No) = 0;
		virtual BOOL InitInstance() = 0;
		virtual BOOL MCDataRW(BOOL Read,LPCTSTR FNam, CString MSec) = 0;
		virtual BOOL DVDataRW(BOOL Read,LPCTSTR FNam, CString MSec) = 0;
		// #DongKD(TFC6100TSB) 20140504 Add method to check cover sensor while moving load unload magazine
		BOOL LoadUnloadMgzMovingChk(int &open);

		BOOL (__cdecl *pMovePusherToWait)(bool);	
		void SetMoveClampToWaitFunc(BOOL (__cdecl *pFunc)(bool)) {
			pMovePusherToWait = pFunc;
		}

		BOOL (__cdecl *pMovePusherToMgzEsc)(bool);	
		void SetMovePusherToMgzEsc(BOOL (__cdecl *pFunc)(bool)) {
			pMovePusherToMgzEsc = pFunc;
		}

		BOOL (__cdecl *pGetPusherPos)(bool, double&);	
		void SetGetPusherPosFunc(BOOL (__cdecl *pFunc)(bool, double&)) {
			pGetPusherPos = pFunc;
		}		

		BOOL (__cdecl *pFeedChuckOnSns)(bool&);
		void SetFeedChuckOnSns(BOOL (__cdecl *pFunc)(bool&)) {
			pFeedChuckOnSns = pFunc;
		}

	public:	
		void SetMgzHeightAtTeaching(double height) {
			this->m_MD.MgzD.mgzHeightTeach = height;
		}
		void SetSpeedRatio(double speedRatio) {
			this->m_MD.MgzD.speedRatio = speedRatio;
		}
		
		void SetSubstExist(int mgzNo, int exist) {
//			int slotNo = this->m_MD.MgzD.currSlitNo;		// yk130508
			int slotNo = this->m_PD.currSlitNo[mgzNo];
			this->waferUmu[mgzNo][slotNo] = exist;
		}

		void SetMgzExchPos(double exchPos) {
			this->m_MD.MgzD.mgzExchgPos = exchPos;
		}

		// Set elevator offset
		void SetElvOffSet(int mgzNo, double elvOffSet)
		{
			this->m_MD.MgzD.elvOffset[mgzNo] = elvOffSet;
		}	

		void SetStockNo(int mgzNo, int stockNo)
		{
			this->m_DD.stockNo[mgzNo] = stockNo;
		}

		void SetTopHeight(double topHeight)
		{
			this->m_DD.topHeight = topHeight;
		}

		// Set value of pitch
		void SetPitch(double pitch)
		{
			this->m_DD.pitch = pitch;
		}

		// Set value of magazine escape level
		void SetEscLevel(double EscLvl)
		{
			this->m_DD.EscLvl = EscLvl;
		}	

		void SetCurrMgSlot(int mgzNo, int slotNo) 
		{
			if(slotNo >= /*1*/0 && slotNo <= (this->m_DD.stockNo[mgzNo]+1)) {		// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
//				this->m_MD.MgzD.currSlitNo = slotNo;	// yk130508
				this->m_PD.currSlitNo[mgzNo] = slotNo;
			}

			// TODO put error
//			FCB_LOG("                                   [BDS]FCB-%s::SetCurrMgSlot() - Current slot is set to: %d\n", this->m_name, slotNo);
		}
		
		void SetMgzWidth(double mgzWidth) 
		{
			this->m_DD.mgzWidth = mgzWidth;
		}

		void SetMgzHeight(double mgzHeight)
		{
			this->m_DD.mgzHeight = mgzHeight;
		}

		void SetFrmTopHeight(double frmTopHeight)
		{
			this->m_DD.frmTopHeight = frmTopHeight;
		}

		void SetFrmStoreHeight(double frmStoreHeight)
		{
			this->m_DD.frmStoreHeight = frmStoreHeight;
		}
		
		void SetPusherLimit(double pos) {
			this->m_MD.MgzD.pusherLimitPos = pos;
		}

		void SetAutoRunFlag(bool isAutoRun) {
			this->m_isAutoRunning = isAutoRun;
		}

		void SetIsAging(bool isAging) {					// yk130430#7:aging�^�]���ɾݻ�𖳎�����
			this->m_isAging = isAging;
		}

		void SetMgzNumber(int no) {
			this->m_MgzNumber = no;
		}

		void SetMgzFeedType(int type) {
			this->m_mgzFeedType = type;
		}

		void SetCurrMgz(int no) {
			this->m_PD.currMgzNo = no;
		}
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
		void SetMCPauseSema(CSemaphoreX* pMCPSema) {
			pMCPauseSema = pMCPSema;
		}

		//==================================================
		// Get data function
		//==================================================
		double GetMgzHeightAtTeaching() {
			return(this->m_MD.MgzD.mgzHeightTeach);
		}

		int	GetSlitForDisplay(int mgzNo) {
//			int SlitNo = this->m_MD.MgzD.currSlitNo;		// yk130508
			int SlitNo = this->m_PD.currSlitNo[mgzNo];
			int Plset = GetStockNo(mgzNo);
			if (SlitNo < 1){		SlitNo = 1;}
			if (SlitNo > Plset){	SlitNo = Plset;}
			return (SlitNo);
		}
		double GetPusherLimit() {
			return(this->m_MD.MgzD.pusherLimitPos);
		}

		bool GetSlotMapMade(){
			return this->m_slotMapIsMade;
		}
		double GetMgzExchPos() {
			return(this->m_MD.MgzD.mgzExchgPos);
		}
		
		// Get elevator offset
		double GetElvOffSet(int mgzNo)
		{
			return(this->m_MD.MgzD.elvOffset[mgzNo]);
		}

		int GetStockNo(int mgzNo)
		{
			return(this->m_DD.stockNo[mgzNo]);
		}

		// Get pitch method
		double GetPitch()
		{
			return (this->m_DD.pitch);
		}

		double GetTopHeight()
		{
			return(this->m_DD.topHeight);
		}
	
		double GetEscLevel()
		{
			return(this->m_DD.EscLvl);
		}	
		
		double GetMgzWidth() 
		{
			return(this->m_DD.mgzWidth);
		}

		double GetMgzHeight()
		{
			return(this->m_DD.mgzHeight);
		}

		double GetFrmTopHeight()
		{
			return(this->m_DD.frmTopHeight);
		}

		double GetFrmStoreHeight()
		{
			return(this->m_DD.frmStoreHeight);
		}

		int GetCurrMgSlot(int mgzNo)
		{
//			return(this->m_MD.MgzD.currSlitNo);		// yk130508
			return(this->m_PD.currSlitNo[mgzNo]);
		}

		int GetCurrMgz()
		{
			return((this->m_MgzNumber == 2) ? this->m_PD.currMgzNo : 0);
		}

		int GetMgzNumber() {
			return this->m_MgzNumber;
		}
		// Get magazine cover close sensor status
		BOOL GetCoverCloseSts(bool& on) {
			return (this->m_snsCoverClose.IsDetected(on));
		}
		// Get magazine exist sensor status
		BOOL GetMgzExistSts(int mgzNo, bool& on) {
			return (this->m_snsMgzExist[mgzNo].IsDetected(on));
		}


};
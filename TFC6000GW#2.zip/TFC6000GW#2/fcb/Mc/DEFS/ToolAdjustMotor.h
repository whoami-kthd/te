// ToolAdjustMotor.h: ToolAdjustMotor �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TOOLADJUSTMOTOR_H__709E7724_C794_4BF7_B2F1_41A8A2E2CBED__INCLUDED_)
#define AFX_TOOLADJUSTMOTOR_H__709E7724_C794_4BF7_B2F1_41A8A2E2CBED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include	<Ulib.h>
#include	<SingleMtCtrl.h>

class ToolAdjustMotor  
{
public:
	ToolAdjustMotor();
	virtual ~ToolAdjustMotor();
	ToolAdjustMotor(CString name, int unitId, int idx);
private:
//*******************************************
//
//	private �ϐ�
//
//*******************************************
	CString name;							// �f�o�b�N�p
	double adjustPos;						// ���s�����ʒu
	double adjustBacklash;					// �o�b�N���b�V����
	double adjustAllowableLimit;			// ���s�����ʒu�̌덷���e�� 
	SingleMtCtrl	myMotor;				// �������[�^(�������g�̃��[�^)
	double adjustOffset;					// ���s���������P�ʗʓ������Ƃ���B'g�w�b�h�̃Y�����E��
	int isEnable;							// ���s�������̗L��
public:
//*******************************************
//
//	public getter
//
//*******************************************
	double GetAdjustPos(){
		return this->adjustPos;
	}
	double GetAdjustOffset(){
		return this->adjustOffset;
	}
	int GetEnable(){
		return this->isEnable;
	}
	double GetAdjustBacklash(){
		return this->adjustBacklash;
	}
	double GetAdjustAllowableLimit(){
		return this->adjustAllowableLimit;
	}
public:
//*******************************************
//
//	public setter
//
//*******************************************
	void SetAdjustPos(double pos){
		this->adjustPos = pos;
	}
	void SetAdjustOffset(double pos){
		this->adjustOffset = pos;
	}
	void SetEnable(int isEnable){
		this->isEnable = isEnable;
	}
	void SetAdjustBacklash(double adjustBacklash){
		this->adjustBacklash = adjustBacklash;
	}
	void SetAdjustAllowableLimit(double adjustAllowableLimit){
		this->adjustAllowableLimit = adjustAllowableLimit;
	}
public:
//*******************************************
//
//	public method
//
//*******************************************
	BOOL MoveSetPos(); 
public:
//*******************************************
//
//	error
//
//*******************************************
};

#endif // !defined(AFX_TOOLADJUSTMOTOR_H__709E7724_C794_4BF7_B2F1_41A8A2E2CBED__INCLUDED_)

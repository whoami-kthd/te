// XYMtCtrl.h: XYMtCtrl �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_XYMTCTRL_H__064CB3BB_7DF0_43F1_B9E0_7EBB31D897F3__INCLUDED_)
#define AFX_XYMTCTRL_H__064CB3BB_7DF0_43F1_B9E0_7EBB31D897F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include	<Ulib.h>
#include	<pos.h>

//*********************************
// ���[�^�̏�Ԏ擾�N���X
//*********************************

class XYMtStatus  
{
public:
	XYMtStatus();
	virtual ~XYMtStatus();

private:

protected:
	int class_id;
	int	mIdx1;
	int	mIdx2;
	static MCCtrl	*pMCC;		// MCC�N���X�ւ̃|�C���^

public:

//*******************************************
//
//	public method of XYMtStatus class
//
//*******************************************
static void		StdInitinstance(MCCtrl *pmcc){	pMCC=pmcc;	}
void	InitInstance(int class_id, int midx1, int midx2);
bool	GetOriginSensor(void);			// ���_�Z���T��Ԏ擾
BOOL	MotorPosition(R2Pos& p);		// ���݈ʒu�̎擾
};

class XYMtCtrl  : public XYMtStatus
{
public:
	XYMtCtrl();
	virtual ~XYMtCtrl();
private:
//	int class_id;
//	int	mIdx;
protected:
//	static MCCtrl	*pMCC;		// MCC�N���X�ւ̃|�C���^
//	SMtTBL			*pTBL;		// �z����`ð��قւ��߲��

public:

//*******************************************
//
//	public method of XYMtCtrl class
//
//*******************************************
	BOOL 	MotorMoveAbs(R2Pos p,double s=NULL,BOOL EWait=FALSE);	// ��΋쓮	p:���W(mm,rad) s:�쓮���x (mm/s,rad/s) 0�Œʏ푬�x
};

#endif // !defined(AFX_XYMTCTRL_H__064CB3BB_7DF0_43F1_B9E0_7EBB31D897F3__INCLUDED_)

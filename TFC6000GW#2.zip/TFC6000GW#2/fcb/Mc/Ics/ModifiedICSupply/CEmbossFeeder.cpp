// CEmbossFeeder.cpp: CEmbossFeeder �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include "CEmbossFeeder.h"
#include <io.h>
#include <fstream>
#include <string>
#include <iostream>
#include <sstream>
#include	"BCR_Input.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


#define EMBOSS_HEADER_MODE "Emboss Header Mode"
#define EMBOSS_HEADER_STRING "DIE No ,Bin No,Die Sn,Bin Remark"
//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CEmbossFeeder::CEmbossFeeder()
{
}

CEmbossFeeder::~CEmbossFeeder()
{
	if (this->GetEmbossMappingMode() && this->m_pMapdata[eTape1-1].size() > 0) {
		DeleteMapData(eTape1);
	}
	if (this->GetEmbossMappingMode() && this->m_pMapdata[eTape2-1].size() > 0) {
		DeleteMapData(eTape2);
	}
}
CEmbossFeeder::CEmbossFeeder(
							CString				name,			// �f�o�b�O�p���O
							int					class_id,		// �������g�̃N���X�h�c
							int					myErrorStart,	// ���̃G���[�X�^�[�g
							int					mapErrorStart,
							int					bcErrorStart,
							OrdinarySnsTBL*		pTape1SetSns,
							OrdinarySnsTBL*		pTape2SetSns,
							OrdinaryOutTBL*		pEmbossFeederOut1,
							OrdinaryOutTBL*		pEmbossFeederOut2,
							OrdinaryOutTBL*		pEmbossCutterOpen,	// #KI150702-01
							OrdinarySnsTBL*		pEmbossIonizNormal,	// 
// #MU160325-01(S)
///							OrdinarySnsTBL*		pEmbossFeederSns,	// EmbossFeeder exist
///							OrdinarySnsTBL*		pEmbossLockSns,		// UnitLock
							OrdinarySnsTBL*		pEmbossFeederCoverSns,// EmbossFeeder exist
							OrdinarySnsTBL*		pEmbossFeeder1Exist,// 
							OrdinarySnsTBL*		pEmbossFeeder2Exist,// 
// #MU160325-01(E)
							// #DongKD 20150113 Add 2D code (S)
							AirCylTBL*			p2DCodeLPos,		// 2D code reader left side cylinder	
							AirCylTBL*			p2DCodeReadPos		// 2D code read point
							// #DongKD 20150113 Add 2D code (E)
							)
{
	this->name			= name;												// �f�o�b�O�p���O
	this->TapeD.Sec		= this->TapeD.Sec;
	this->PD.Sec		= this->PD.Sec;
	this->Sec			= this->TapeD.Sec;
	this->err.Initinstance(class_id, myErrorStart);							// ���̃G���[�ԍ�
	this->snsTapeSet[0].Initinstance(class_id,	pTape1SetSns);
	this->snsTapeSet[1].Initinstance(class_id,	pTape2SetSns);
	this->outEmbossFeeder[0].Initinstance(class_id, pEmbossFeederOut1);
	this->outEmbossFeeder[1].Initinstance(class_id, pEmbossFeederOut2);
	this->outCutterClose.Initinstance(class_id, pEmbossCutterOpen);			// #KI150702-01
	this->snsIonizerNormal.Initinstance(class_id, pEmbossIonizNormal);
// #MU160325-01(S)
///	this->snsEmbossFeederExist.Initinstance(class_id, pEmbossFeederSns);
///	this->snsUnitLocked.Initinstance(class_id, pEmbossLockSns);
	this->snsEmbossFeederTapeCover.Initinstance(class_id, pEmbossFeederCoverSns);
	this->snsEmbossFeederExist[0].Initinstance(class_id, pEmbossFeeder1Exist);
	this->snsEmbossFeederExist[1].Initinstance(class_id, pEmbossFeeder2Exist);
// #MU160325-01(E)
	this->isAging2	= false;
	// #DongKD 20150113 Add 2D code (S)
	this->cy2DCodeLeftPos.Initinstance(class_id, p2DCodeLPos);
	this->cy2DCodeReadPos.Initinstance(class_id, p2DCodeReadPos);
	// #DongKD 20150113 Add 2D code (E)
	this->pPickupIsSafety	= NULL;		// #KI150124-03
	// DuyND SECS
	this->m_mapIsLoaded[0]	= 0;
	this->m_mapIsLoaded[1]	= 0;
	this->m_topWfSlotCnt	= 0;
	this->m_CurrTopDataIdx	= -1;
	this->m_SavedTopDataIdx	= -1;
	// #KI151215-07(S)
	this->m_LoadingCJ[0]	= false;
	this->m_LoadingCJ[1]	= false;
	// #KI151215-07(E)
	this->m_Tape_Ic_Ready[0]    = 0;
	this->m_Tape_Ic_Ready[1]	= 0;
	//#DucMV 160621 Barcode Reader (S)
	this->ebMapping[0].InitInstance(	name+":EmbossMapping1",
									class_id,
									mapErrorStart,
									bcErrorStart,
									"",
									"",
									0
									);
	this->ebMapping[1].InitInstance(	name+":EmbossMapping2",
									class_id,
									mapErrorStart,
									bcErrorStart,
									"",
									"",
									0
									);
	this->ebMapping[0].pMappingWD	= &this->MappingWD;
	this->ebMapping[1].pMappingWD	= &this->MappingWD;
	//#DucMV 160621 Barcode Reader (E)
	//#DMV160707 Add Barcode AutoRun (S)
	this->bReadEmbossMapSuccess[0]	= FALSE;
	this->bReadEmbossMapSuccess[1]	= FALSE;
	this->StsBarCode[0]				= FALSE;
	this->StsBarCode[1]				= FALSE;
	this->BarCode[0]				= "";
	this->BarCode[1]				= "";
	this->bReadMapEnable			= FALSE;
	this->TapeNo					= 0;
	//#DMV160707 Add Barcode AutoRun (E)
	this->pAddTraceSeqLog			= NULL;		// #KI160324-01

}
// #KI150702-01(S)
// �e�[�v���J�b�g����
BOOL	CEmbossFeeder::EmbossTapeCut(){
	int r = TRUE;
	// �܂��͊J��(�����炭�J���Ă���)
	if (r) {
		r = outCutterClose.Out(false);
		::Sleep(100);
	}
	// ����(�J�b�g)
	if (r) {
		r = outCutterClose.Out(true);
		::Sleep(this->GetCutTimer());
	}
	// �J��(���S�ɊJ���I���̂�҂K�v�͂Ȃ����A���̃e�[�v����̂Ƃ��ɂЂ�������Ȃ����x�ɂ͑҂�����)
	if (r) {
		r = outCutterClose.Out(false);
		::Sleep(this->GetOpenTimer());
	}
	this->PD.feedCount	= 0;
	return r;
}
// �Ƃ肠�����J���Ă���
BOOL	CEmbossFeeder::EmbossCutOpen(){
	int r = TRUE;
	if (r) {
		r = outCutterClose.Out(false);
	}
	return r;
}
// #KI150702-01(E)

// Emboss feed
BOOL	CEmbossFeeder::EmbossFeedOut(bool manu, int tapeNo, bool hasToCount){
	// TODO:
	//		1. Feed output
	//		2. Increase current ICs
	TRACE("+++++TSDV_%s::EmbossFeedOut - Start\n", name);
	int r = TRUE;
	int currentICNo;
	int tape;
	bool tapeExist = false;
	bool changeTape = false;
	bool ionizNormal = false;
	bool feederset = false;
	bool unitLocked = false;
	// #MU160407-01
	if (!manu && this->isAging2) {
//		return true;
	}
// #DDT 160601 Emboss IC check for Aging
#if GPDEBUG
	this->isAging2 = 1;
#endif
	// #KI150702-01(S)
	// �Ƃ肠�����J�b�^�[���J���Ă���(�J���Ă���͂��Ȃ̂ŁA�J���I���^�C�}�[�����Ă����̂�
	// �Ƃ肠������߂Ă���)
	if (r && !this->isAging2) {
		r = outCutterClose.Out(false);
	}
	// #KI150702-01(E)
	if (manu) {				// If manual mode
		tape = tapeNo;
	} else {
		tape = this->GetCurrentTape();
	}
	// Check request ic type
	if (r && !manu) {	// Autorun mode
		// Check mode
		if (this->GetTapeMode() == eTapeNone) {
			this->err.PutError(Err_TapeMode);
			r = FALSE;
		}
		if (this->icInfo[eRequested].icType != this->GetTapeICType()) {
			this->err.PutError(Err_WrongICType);
			r = FALSE;
		}
		if (r) {
			// Set IC_Ready for autorun
			*this->pIc_Ready = FALSE;
			SetCurrentTapeIcReady(this->GetCurrentTape(), FALSE);
		}
	}
	// Check feeder set
	// #MU160330-02
	if ((!this->isAging2)&&(!this->SnsChk_EmbossFeederTapeCover(feederset) || feederset)) {
		#if !GPDEBUG
		r = FALSE;
		this->err.PutError(Err_UnitIsNotSet);
		#endif
	}
	// Check feeder set
	if ((!this->isAging2)&&(!this->SnsChk_Ionizer(ionizNormal) || !ionizNormal)) {
		#if !GPDEBUG
		r = FALSE;
		this->err.PutError(Err_Ioniz);
		#endif
	}
	// Check Emboss Feeder
	// #MU160330-02
	if ((!this->isAging2)&&(!this->SnsChk_EmbossFeederExist(tapeNo, unitLocked) || !unitLocked)) {
		#if !GPDEBUG
		r = FALSE;
		// #MU160325-01
		this->err.PutError(tapeNo==1 ? Err_SnsEmbossFeeder1Exist : Err_SnsEmbossFeeder2Exist);
		#endif
	}
 	while (r) { 
		// Check tape exist
		if ((!this->isAging2)&&(!TapeExistSnsChk(tape, tapeExist) || !tapeExist)) {
			r = FALSE;
			this->err.PutError(Err_Tape1Sns + tape-1);	// #KI140809-02
		}
		currentICNo = this->GetCurrentICNumber(tape);
		// Check IC number
		if ((hasToCount)&&(currentICNo >= this->GetMaxICs(tape))) {		// Run out of IC in current tape
			// Tape run out of IC => re-write mapfile
			if (this->GetEmbossMappingMode()) {
				this->WriteMapFile(this->PD.barcode[tape - 1], tape);
			}
			if (changeTape || manu) {	// Change tape once 
				r = FALSE;
			}
			// If use both tape
			if (r && this->GetTapeMode() == eTapeBoth) {
				if (!(*pGetSecsGemComState)()) {
					if ((this->GetTapeBin(eTape1) == this->GetTapeBin(eTape2)) && (this->GetTapeBin(eTape1) != "")) {
						tape = eTape2 - this->GetCurrentTape() + 1;
						this->SetCurrentTape(tape);	// Change tape
						changeTape = true;
					} else {
						r = FALSE;	
					}
				} else {
					// Report end map
					if (pEmbossMapEndEvent) {
						(*pEmbossMapEndEvent)(this->GetCurrentTape());
					}
					// Online remote
					char *code;
					tapeNo = eTape2 - this->GetCurrentTape() + 1;
					// #DDT160703-01 Only get map if in mapping mode
					if (!this->GetMapIsLoaded(tapeNo) && this->GetEmbossMappingMode()) {
						code = (char*)(LPCSTR)(this->GetBarcode(tapeNo));
						r = (*this->pGetMIDByHost)(tapeNo, code);
						if (r) {
							r = this->ReadMapFile(this->GetBarcode(tapeNo), tapeNo);
						}
					}
					//#DucMV 20160714 Add change tape for online remote with same bin
					if ((this->GetTapeBin(eTape1) == this->GetTapeBin(eTape2)) && (this->GetTapeBin(eTape1) != "")) {
						tape = tapeNo;
						this->SetCurrentTape(tapeNo);	// Change tape
						changeTape = true;
					} else {
						r = FALSE;
					}
 
				}
			// If use single tape
			} else {
				r = FALSE;
			}
			if (!r) {
				this->err.PutError(Err_RunOutOfIC);
				break;
			}
		} else {
			break;
		}
	}
	
	// Out = 1 : Shutter close, feed 1 pitch
	// �e�[�v�`�F���W�����P���ڂ͑���Ȃ�(���̈ʒu��IC�����邩���j
	if (manu) {
		tape = tapeNo;
	} else {
		tape = this->GetCurrentTape();
	}
	// #DDT 160601 Update in case change tape
	if(/*!changeTape*/!GetCurrentTapeIcReady(tape)){
		if (r && !this->isAging2) {							// #DMV 160601 Add Emboss IC check for Aging
			r = outEmbossFeeder[tape - 1].Out(true);
			::Sleep(this->GetOutTimer());
		}
		if (r) {
			if(!this->isAging2){							// #DMV 160601 Add Emboss IC check for Aging
				// Out = 0 : Shutter open, IC ready
				r = outEmbossFeeder[tape - 1].Out(false);
			}
			::Sleep(this->GetFeedDelayTimer());		// #TT160602-01 �t�B�[�h����O��2D���[�h���s���Ă��܂����̑΍�
			if(hasToCount){
				this->SetCurrentICNumber(tape, currentICNo + 1);
				TRACE("+++++TSDV_%s:: Current tape: %d  Current IC %d/%d\n", name, tape, 
					this->GetCurrentICNumber(this->GetCurrentTape()), this->GetMaxICs(this->GetCurrentTape()));
			}
			// #KI150702-01(S)
			// �J�b�^�[�t�B�[�_�J�E���g�A�b�v
			// �J�E���^���c��ȕ��łȂ����Ƃ��F��
			this->PD.feedCount++;
			// #KI150702-01(E)
			// #DDT160518-01 (S)
			//if ((*pGetSecsGemComState)()) {
			//	(*this->pReportDie)(this->PD.feedCount, 0);		// y idx is not used
			//}
			// #DDT160518-01 (E)
		}
	}

	// #DongKD 20150116 Add 2D code (S)
	if (r && this->m_has2DCodeReader && this->TapeD.read2D && changeTape && !this->isAging2) {	// #DMV 160601 Add Emboss IC check for Aging
		if (this->GetCurrentTape() == 1) {
			r = this->cy2DCodeLeftPos.Act(true);
		} else {
			r = this->cy2DCodeLeftPos.Act(false);
		}
	}

	if (!r){
		// Put error
	}
	// #DongKD 20150116 Add 2D code (E)

	if (r /*&& !manu*/) {
		// Set IC_Ready for autorun
		*this->pIc_Ready = TRUE;
		SetCurrentTapeIcReady(tape, TRUE);								// #DDT 160601 Update in case change tape
	}
	// #KI150702-01(S)
	// 1��1�񂨂��Ƃ���(�O�Ŗ���j
	// manu = false�̏ꍇ�͂����Ő���A�����łȂ��ꍇ�͏�ʂŐ���
	if(r && manu && (this->PD.feedCount > this->PD.cutTiming) && !this->isAging2){	// #DMV 160601 Add Emboss IC check for Aging
		r = this->EmbossTapeCut();
	}
	// #KI150702-01(E)
	// Update prepare IC info
	if (r /*&& !manu*/) {
		CTime ctime = CTime::GetCurrentTime();
		this->icInfo[ePrepared] = this->icInfo[eRequested];
// #DDT160420-01 Update picx,pixy in emboss mode
		this->icInfo[ePrepared].picx = /*this->PD.feedCount*/PD.currentICNo[PD.currentTape - 1] - 1;
		this->icInfo[ePrepared].mID	= this->GetBarcode(this->GetCurrentTape());
		this->icInfo[ePrepared].timeStamp.Format("20%s00",ctime.Format("%y%m%d%H%M%S"));
		this->icInfo[ePrepared].picy = PD.currentICNo[PD.currentTape - 1];
		this->icInfo[ePrepared].icID = _T("");	// 2D�R�[�h�l�������āA���Ƃ�picx�֐U��ւ���
		// #KI151116-02(S)
		this->icInfo[ePrepared].binCode	= this->GetTapeBin(PD.currentTape);
		// #KI151116-02(E)
		// #DDT160518-01 (S)
		if ((*pGetSecsGemComState)()) {
			(*this->pReportDie)(PD.currentICNo[PD.currentTape - 1]-1, 0);		// y idx is not used
		}
		// #DDT160518-01 (E)
		TRACE("CEmbossFeeder::EmbossFeedOut Tape(%d) binCode=(%s)\n",
				PD.currentTape, this->GetTapeBin(PD.currentTape));
	}
	return r;
}

// Check tape set sensor
BOOL	CEmbossFeeder::TapeExistSnsChk(int tape, bool &isOn)
{
	if (tape <= 0 || tape >= 3) {
		CString msg;
		msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	return (this->snsTapeSet[tape - 1].IsDetected(isOn));
}

BOOL CEmbossFeeder::SnsChk_Ionizer(bool &isNormal)
{
	return snsIonizerNormal.IsDetected(isNormal);
}
// #MU160325-01(S)
///BOOL CEmbossFeeder::SnsChk_EmbossFeederExist(bool &on)
///{
///	return snsEmbossFeederExist.IsDetected(on);
///}
///BOOL CEmbossFeeder::SnsChk_UnitLocked(bool &isLocked)
///{
///	return snsUnitLocked.IsDetected(isLocked);
///}
BOOL CEmbossFeeder::SnsChk_EmbossFeederTapeCover(bool &on)
{
	return snsEmbossFeederTapeCover.IsDetected(on);
}
BOOL CEmbossFeeder::SnsChk_EmbossFeederExist(int tape, bool &isOn)
{
	if (tape <= 0 || tape >= 3) {
		CString msg;
		msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	return (this->snsEmbossFeederExist[tape - 1].IsDetected(isOn));
}
// #MU160325-01(E)

// #DongKD 20150116 Add 2D code (S)
BOOL	CEmbossFeeder::Code2DLeftSideAct(bool left)
{
	return (this->cy2DCodeLeftPos.Act(left));
}

BOOL	CEmbossFeeder::Code2DLeftSideSns(bool left, bool& onOff)
{
	return (this->cy2DCodeLeftPos.Sns(left, onOff));
}

BOOL	CEmbossFeeder::Code2DReadPosAct(bool readPos)
{
	// #KI150124-03(S)
	BOOL r = TRUE;
	// ���~����Ȃ�΃s�b�N�A�b�v�ʒu���`�F�b�N
	// �㏸����Ȃ�Ό���K�v�Ȃ��B
	if(readPos){
		if(this->pPickupIsSafety==NULL){
			r = true;
		}else{
			r = (*this->pPickupIsSafety)();
		}
	}
	if(r){
		r = this->cy2DCodeReadPos.Act(readPos);
	}else{
		this->err.PutError(Err_PickupUnitIsNotSafety);
	}
	return(r);
	// #KI150124-03(E)
}

BOOL	CEmbossFeeder::Code2DReadPosSns(bool read, bool &onOff)
{
	return (this->cy2DCodeReadPos.Sns(read, onOff));
}

// #DongKD 20150116 Add 2D code (E)

// DuyND Emboss Mapping mode
BOOL	CEmbossFeeder::ReadMapFile(CString barcode, int tapeNo)
{
	BOOL r = TRUE;
	int nullCnt = 0;
	BOOL headerMode = FALSE;
	BOOL headerString = FALSE;
	this->PD.tapeBin[tapeNo-1] = "";
	// #KI151115-02
	DeleteMapData(tapeNo);
	CString filePath = this->TapeD.mapFilePath;
	filePath += barcode;
	// Check file available
	if ((_access( filePath, 0 )) == -1) {
		r = FALSE;
	}
	if (r) {
		std::string line;
		std::ifstream mapFile(filePath);
		while(std::getline(mapFile, line)) {
			std::istringstream s(line);
			std::string field;
			if (line.find(EMBOSS_HEADER_MODE) != std::string::npos) {
				headerMode = TRUE;
				if (line.find("0") != std::string::npos) {
					this->PD.embossMapType[tapeNo-1] = e2DCodeMap;
				} else if (line.find("1") != std::string::npos) {
					this->PD.embossMapType[tapeNo-1] = eNoneCodeMap;
				} else {
					headerMode = FALSE;
				}
			} else if (line.find(EMBOSS_HEADER_STRING) != std::string::npos) {
				headerString = TRUE;
			} else {
				if (headerMode && headerString) {
					// Parse map data
					EmbossMap* pMap = new EmbossMap();
					std::getline(s, field, ',');	
					pMap->diaNo =	atoi(field.c_str());
					std::getline(s, field, ',');
					pMap->BinNo = field.c_str();
					if (pMap->BinNo == ".") {
						nullCnt++;
					}
					// If there is other bin in tape => put error
					if (this->PD.tapeBin[tapeNo-1] != "" && this->PD.tapeBin[tapeNo-1] != pMap->BinNo && pMap->BinNo != ".") {
						r = FALSE;
						break;
					}
					if (this->PD.tapeBin[tapeNo-1] == "" && pMap->BinNo != ".") {
						this->PD.tapeBin[tapeNo-1] = pMap->BinNo;
					}
					std::getline(s, field, ',');
					pMap->UPICode = field.c_str();
					std::getline(s, field, ',');
					pMap->binRemark = field.c_str();
					m_pMapdata[tapeNo-1].push_back(pMap);
				} else {
					r = FALSE;
					break;
				}
			}
		}
	}
	if (r == FALSE) {
		this->err.PutError(Err_MapReadError);
		DeleteMapData(tapeNo);
		this->m_mapIsLoaded[tapeNo-1]		= FALSE;
	}
	// #KI151117-02(S)
	if(r){
		this->TapeD.numberOfIC[tapeNo-1]	= this->m_pMapdata[tapeNo-1].size() - nullCnt;
		this->PD.currentICNo[tapeNo-1]		= 0;
		this->InitCode2DForDisp();
		this->m_mapIsLoaded[tapeNo-1]		= TRUE;
		// #TT160609-01(S) OnlineRemote����FeederCounter�̂�0�N���A����Ă�����̒����pLog�ǉ�
		CString msg;
		msg.Format("CEmbossFeeder::ReadMapFile() TapeD.numberOfIC[tapeNo-1]=%d, this->m_pMapdata[tapeNo-1].size()=%d, nullCnt=%d", TapeD.numberOfIC[tapeNo-1], m_pMapdata[tapeNo-1].size(), nullCnt);
		this->err.LogSaveNFL(msg);
		// #TT160609-01(E)
	}
	// #KI151117-02(E)
	bReadEmbossMapSuccess[tapeNo-1] = r; //tienbv barcode			//#DMV160707 Add Barcode AutoRun
	return r;
}

BOOL	CEmbossFeeder::WriteMapFile(CString barcode, int tapeNo)
{
	if(this->pAddTraceSeqLog){
		(*this->pAddTraceSeqLog)("J1;");	// #TT160624-02 ���R��~�����pLog�ǉ�
	}
	BOOL r = TRUE;
	if(this->m_pMapdata[tapeNo - 1].size()<=0){
		return TRUE;
	}
	if (this->m_mapIsLoaded[tapeNo - 1] != TRUE) {
		TRACE("Map file is not loaded succesfully => data erase => no rewrite map data\n");
		return r;
	}
	int mapSize = 0;
	CString filePath = this->TapeD.mapFilePath;
	filePath += barcode;
	// Check file available
	if ((_access( filePath, 0 )) == -1) {
		r = FALSE;
	}
	CString tempFile;
	tempFile.Format("%s_", filePath);
	CString mapBuf;
	if (r) {
		if(this->pAddTraceSeqLog){
			(*this->pAddTraceSeqLog)("J2;");	// #TT160624-02 ���R��~�����pLog�ǉ�
		}
		CStdioFile file;
		mapSize = this->m_pMapdata[tapeNo - 1].size();
		if(!file.Open(tempFile, CFile::modeCreate | CFile::modeNoTruncate | CFile::modeWrite | CFile::shareDenyNone | CFile::typeText) ) {
			OutputDebugString("File Open Error\n");
		} else {
			// Map type
			mapBuf.Format("%s = %d\n",EMBOSS_HEADER_MODE ,this->PD.embossMapType[tapeNo - 1]);
			// To end of file
			file.SeekToEnd();
			file.WriteString(mapBuf);
			mapBuf.Empty();
			// Header
			// To end of file
			file.SeekToEnd();
			mapBuf.Format("%s\n", EMBOSS_HEADER_STRING);
			file.WriteString(mapBuf);
			mapBuf.Empty();
			for (int i = 0; i < mapSize; i++) {
				mapBuf.Format("%d,%s,%s,%s\n",	this->m_pMapdata[tapeNo-1][i]->diaNo, 
												this->m_pMapdata[tapeNo-1][i]->picked ? "." : this->m_pMapdata[tapeNo-1][i]->BinNo, 
												// #DDT160817-02
												this->m_pMapdata[tapeNo-1][i]->picked ? this->m_pMapdata[tapeNo-1][i]->UPICode : "", 
												//this->m_pMapdata[tapeNo-1][i]->UPICode, 
												this->m_pMapdata[tapeNo-1][i]->binRemark);
				// To end of file
				file.SeekToEnd();
				// Write to file
				file.WriteString(mapBuf);
			}
			// #KI151116-05
			file.Close();
		}
		BOOL r2 = TRUE;
		//  remove old file, rename new file
		r2 = _unlink(filePath);
		TRACE("r2(%d) _unlink(%s)\n", r2, filePath);
		::Sleep(100);
		r2 = rename(tempFile, filePath);
		TRACE("r2(%d) rename(%s->%s)\n", r2, tempFile, filePath);
		if(r2){
			if(this->pAddTraceSeqLog){
				(*this->pAddTraceSeqLog)("J3;");	// #TT160624-02 ���R��~�����pLog�ǉ�
			}
		}
	}
	if(this->pAddTraceSeqLog){
		(*this->pAddTraceSeqLog)("J4;");	// #TT160624-02 ���R��~�����pLog�ǉ�
	}
	return r;
}

BOOL	CEmbossFeeder::Check2DCode(CString code, int& pos, int tapeNo, int& recerr)
{
	BOOL found = FALSE;
	BOOL matched = false;
	recerr	= false;
	int size = m_pMapdata[tapeNo-1].size();
	
	for (pos = 0; pos < size; pos++){
		if (m_pMapdata[tapeNo-1][pos]->UPICode == code) {
			found = TRUE;
			break;
		}
	}
	if(found){
		if(m_pMapdata[tapeNo-1][pos]->BinNo == this->PD.tapeBin[tapeNo-1]){
			matched = true;
			this->icInfo[ePrepared].picx = pos;
		}
	}else{
		recerr	= true;	// Map��Ɍ�����Ȃ�����
	}
	return (found && matched);
}

BOOL	CEmbossFeeder::UpdateMappingData(int pos, int tapeNo, CString bin, CString code)
{
	BOOL r = TRUE;
	if (pos > m_pMapdata[tapeNo-1].size()) {
		r = FALSE;
		AfxDebugBreak();
	} else {
		if (code != "") {
			m_pMapdata[tapeNo-1][pos]->UPICode = code;
		}
		if (bin != "") {
			m_pMapdata[tapeNo-1][pos]->BinNo = bin;
		}
	}
	
	return r;
}

//tienbv barcode(s)
BOOL CEmbossFeeder::Map_LoadMap(int para)
{
	BOOL r = TRUE;
	this->TapeNo = para;									//#DMV160707 Add Barcode AutoRun
	r = this->ebMapping[para-1].Map_LoadMapSubEmboss();
	return(r);
}
//tienbv barcode(e)

void	CEmbossFeeder::DeleteMapData(int tapeNo)
{
	// Get map size
	int size = m_pMapdata[tapeNo-1].size();
	for (int idx = 0; idx < size; idx++) {
		delete	m_pMapdata[tapeNo-1][idx];
	}
	m_pMapdata[tapeNo-1].clear();
	// Clear tape bin
	this->PD.tapeBin[tapeNo-1] = "";
	{
		CString msg;
		msg.Format("EmbossMapData(%d) Deleted", tapeNo);
		this->err.LogSaveNFL(msg);
	}
	return;
}

BOOL	CEmbossFeeder::UpdateBarcode(int tapeNo)
{
	BOOL r = TRUE;
#if 0
	CString BC = pBCR_INP->GetBarCode(true);
	// #KI151214-01(S)
	if(BC != _T("")){
		this->SetBarcode(tapeNo, BC);
	}
#endif
	char bchar[40];
	bchar[0] = 0;
	int	error = 0;
	this->ebMapping[tapeNo-1].barcode.BarCodeRead(bchar, &error);
	CString BC(bchar);
	// #KI151214-01(S)
	if((BC != _T("")) && (BC[0] >= 0x20)){
		this->SetBarcode(tapeNo, BC);
	} else {
		r = FALSE;
	}
	// #KI151214-01(E)
	return r;
}
BOOL	CEmbossFeeder::UpdateTopEmbossData(TopWfSlotData *pWfSlotData)
{
	BOOL			r = TRUE;
	bool			found = false;
	TopWfSlotData	*pCurrSlotData;
	// Check input parameters
	if (pWfSlotData == NULL) {
		return FALSE;
	}
	// Check data
	if ((pWfSlotData->ctrlJobId != "") && (this->m_topWfSlotCnt < eEmbossJobMax)) {
		for (int i = 0; i < CEmbossFeeder::eEmbossJobMax; i++) {
			pCurrSlotData = &this->m_TopWfSlotData[i];
			// If data is blank
			if (pCurrSlotData->ctrlJobId == "") {
				//Update Data
				pCurrSlotData->slotNo		= pWfSlotData->slotNo;
				pCurrSlotData->ctrlJobId	= pWfSlotData->ctrlJobId;
				pCurrSlotData->prJobId		= pWfSlotData->prJobId;
				pCurrSlotData->PPID			= pWfSlotData->PPID;
				pCurrSlotData->keyVal		= pWfSlotData->keyVal;
				pCurrSlotData->numOfBinVal	= pWfSlotData->numOfBinVal;
				pCurrSlotData->binVals		= pWfSlotData->binVals;
				// #DDT160515-04 (S)
				for (int j = 0; j < eBinValMax; j++) {
					pCurrSlotData->binCodeVal[j] = "";
					pCurrSlotData->binCodeCnt[j] = 0;
				}
				// #DDT160515-04 (E)
				for (j = 0; j < pWfSlotData->numOfBinVal; j++) {
					pCurrSlotData->binCodeVal[j] = pWfSlotData->binCodeVal[j];
					pCurrSlotData->binCodeCnt[j] = pWfSlotData->binCodeCnt[j];
				}
				found = true;
				this->m_topWfSlotCnt ++;
#if !RELEASE
				TRACE("[SECS_DEBUG] %s::UpdateTopWfSlotData(), TopWfSlotData[%d], TopWfSlotCnt[%d], slotNo = %d, ctrlJobId = %s, prJobId = %s, PPID = %s, keyVal = %s, binVal = %s, binNum = %d\n", 		
							this->name, i, this->m_topWfSlotCnt, pCurrSlotData->slotNo,
							pCurrSlotData->ctrlJobId, pCurrSlotData->prJobId, pCurrSlotData->PPID, pCurrSlotData->keyVal,
							pCurrSlotData->binVals, pCurrSlotData->numOfBinVal);
#endif
				break;
			}
		}

		if (!found) {
			r = FALSE;
		}
	}

	return r;
}
// Get Emboss tape bin
CString	CEmbossFeeder::GetTapeBin(int tapeNo)
{
	CString bin = "";
	if (!this->GetEmbossMappingMode()) {
		bin = this->TapeD.tapeBin[tapeNo - 1];
	} else {
		bin = this->PD.tapeBin[tapeNo - 1];
	}
	return bin;
}
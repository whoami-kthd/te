// #DDT(20140708): Add Emboss&Faceup function
//	CEmbossFeeder.h: CEmbossFeeder �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include	<Ulib.h>
#include	<SingleMtCtrl.h>
#include	<mcstd.h>
#include	<gwpp.h>
#include	"..\COM\PauseAndWait.h"
#include	"..\COM\CommonDef.h"
//#include	"RFIDCtrl.h"
#include	<..\COM\BasicCommData.h>
#include	<vector>
#include	"ModifiedWaferSupply.h"
#include	"DlgSG300.h"
#include	"..\..\COM\MappingCtrl.h" //tienbv barcode
// Tape no
enum {
	eTape1		= 1,
	eTape2		   ,
};

// Tape mode
enum {
	eTapeNone	= 0,
	eTape1Only	= 1,
	eTape2Only	= 2,
	eTapeBoth	= 3,
};

// Tape Width
enum {
	eTape16 = 16,
	eTape24 = 24,
	eTape32 = 32,
};
// IC info
enum {
	eRequested	= 0,
	ePrepared	= 1,
	eICInfoMax,
};

enum {
	e2DCodeMap	= 0,
	eNoneCodeMap,
};

typedef struct Emboss_Map{
	Emboss_Map() {
		diaNo = 0;
		BinNo = "";
		UPICode= "";
		binRemark = "";
		picked = 0;
	}
	int diaNo;
	CString BinNo;
	CString UPICode;
	CString binRemark;
	int picked;
}EmbossMap;

class CEmbossFeeder : public MCCStd  
{
public:
	CEmbossFeeder();
	virtual ~CEmbossFeeder();
	CEmbossFeeder(
		CString				name,			// �f�o�b�O�p���O
		int					class_id,		// �������g�̃N���X�h�c
		int					myErrorStart,	// ���̃G���[�X�^�[�g
		int					mapErrorStart,
		int					bcErrorStart,
		OrdinarySnsTBL*		pTapeSet1,
		OrdinarySnsTBL*		pTapeSet2,
		OrdinaryOutTBL*		pEmbossFeederOut1,
		OrdinaryOutTBL*		pEmbossFeederOut2,
		OrdinaryOutTBL*		pEmbossCutterClose,	// #KI150702-01
		OrdinarySnsTBL*		pEmbossIonizNormal,	// 
// #MU160325-01(S)
///		OrdinarySnsTBL*		pEmbossFeederSns,	// EmbossFeeder exist
///		OrdinarySnsTBL*		pEmbossLockSns,		// UnitLock
		OrdinarySnsTBL*		pEmbossFeederCoverSns,// EmbossFeeder exist
		OrdinarySnsTBL*		pEmbossFeeder1Exist,// 
		OrdinarySnsTBL*		pEmbossFeeder2Exist,// 
// #MU160325-01(E)
		// #DongKD 20150113 Add 2D code (S)
		AirCylTBL*			p2DCodeLPos,		// 2D code reader left side cylinder	
		AirCylTBL*			p2DCodeReadPos			// 2D code read point
		// #DongKD 20150113 Add 2D code (E)
	);

	CString			name;				// �f�o�b�O�p�����̖��O
	ErrorMediator	err;				// �G���[�o��(�Ȃ�ׂ����̃N���X��pMCC���Ăт����Ȃ�����)
	bool			isAging1;			// �G�[�W���O(�E�F�n�F��)
	bool			isAging2;			// �G�[�W���O(��������)
	OrdinaryOut		outEmbossFeeder[2];	
	OrdinaryOut		outCutterClose;		// �J�b�^�[����	
	OrdinarySensor	snsTapeSet[2];		
	OrdinarySensor	snsIonizerNormal;		// 
// #MU160325-01(S)
///	OrdinarySensor	snsEmbossFeederExist;	// Check emboss feeder exist
///	OrdinarySensor	snsUnitLocked;			// 
	OrdinarySensor	snsEmbossFeederTapeCover;	// Check emboss feeder exist
	OrdinarySensor	snsEmbossFeederExist[2];	// 
// #MU160325-01(E)
	CString			Sec;				// �ް�����ݖ�
	ICPickUpData	icInfo[eICInfoMax];				// 
	int*			pIc_Ready;
	std::vector<EmbossMap*>m_pMapdata[2];
	int				m_embossBinMode;
	int				m_mapIsLoaded[2];
	bool			m_hasACarrier[2];
	int				m_Tape_Ic_Ready[2];   //Set current Tape Ic Ready  ##THAIHV 20160425

	//tienbv barcode(s)
    CString         BarCode[2];
	BOOL            StsBarCode[2];
	int				TapeNo;
	BOOL            bReadEmbossMapSuccess[2];
	BOOL            bReadMapEnable;
	MappingCtrl		ebMapping[2];			//#DucMV 160621 Barcode Reader
    W_MapData		MappingWD;
	BOOL			Map_LoadMap(int);		//#DucMV 160621 Barcode Reader
    //tienbv barcode(e)
public:
	enum {
		eEmbossJobMax = 2,
	};

	TopWfSlotData	m_TopWfSlotData[eEmbossJobMax];
	int				m_topWfSlotCnt;
	int				m_CurrTopDataIdx;							// real time
	int				m_SavedTopDataIdx;							// from loading until unloading
	int				m_LoadingCJ[2];		// #KI151215-07
private:
	// #DongKD 20150113 Add 2D code (S)
	AirCylinderStd	cy2DCodeLeftPos;		// 2D code reader left side
	AirCylinderStd	cy2DCodeReadPos;		// 2D code read/evacuation point
	// #DongKD 20150113 Add 2D code (E)
private:
	// #DongKD 20150120 Add 2D code
	int				m_has2DCodeReader;	// Use 2D code reader?
public:

	struct PD_Data{
		PD_Data(){
			Sec = _T(":�G���{�X�t�B�[�_�[�ް�");
			currentICNo[0] = 0;
			currentICNo[1] = 0;
			currentTape = 1;
			barcode[0] = _T("");
			barcode[1] = _T("");
			feedCount		= 0;		// #KI1550702-01
			diaNo[0]		= 0;
			diaNo[1]		= 0;
			diaNo[2]		= 0;
			bin[0]			= "";
			bin[1]			= "";
			bin[2]			= "";
		}
		CString Sec;
		int		currentICNo[2];			// current IC number of tape 1&2
		int		currentTape;			// current active tape(1: tape 1, 2: tape 2)
		CString	barcode[2];				// barcode string of tape 1&2
		int		cutTiming;				// feed count per cut(Interval) // #KI150702-01
		int		feedCount;				// feed count for cut. no need DataRW// #KI1550702-01
		CString code2D[3];				// 2D code of each IC	#DongKD 20150119 Add 2D code
		int		diaNo[3];				// 
		CString	bin[3];					// ����p
		//
		int		embossMapType[2];
		int		mapICCnt;
		CString tapeBin[2];
		BOOL DataRW(BOOL Read, LPCTSTR FNam, CString PSec) {
			CString section = PSec + Sec;
			BOOL r = TRUE;
			// #OZ20150303 GWPP������
			GWPPfileStart( FNam );
// #DucMV 20160505 Add Key System (S)
//			GWPPfileData(FNam, section, "Current active tape",	Read, this->currentTape,	1);
			TGWPPfileData(SecsCom::V_CurrentTape,FNam, section, "Current active tape",	Read, this->currentTape,	1);
//			GWPPfileData(FNam, section, "Current IC of tape 1", Read, this->currentICNo[0],	0);
			TGWPPfileData(SecsCom::V_CurrentIC_Tape1,FNam, section, "Current IC of tape 1", Read, this->currentICNo[0],	0);
//			GWPPfileData(FNam, section, "Current IC of tape 2", Read, this->currentICNo[1],	0);
			TGWPPfileData(SecsCom::V_CurrentIC_Tape2,FNam, section, "Current IC of tape 2", Read, this->currentICNo[1],	0);
//			GWPPfileData(FNam, section, "Barcode of tape 1",	Read, this->barcode[0], _T(""));
			TGWPPfileData(SecsCom::V_Barcode_Tape1,FNam, section, "Barcode of tape 1",	Read, this->barcode[0], _T(""));
//			GWPPfileData(FNam, section, "Barcode of tape 2",	Read, this->barcode[1], _T(""));
			TGWPPfileData(SecsCom::V_Barcode_Tape2,FNam, section, "Barcode of tape 2",	Read, this->barcode[1], _T(""));
//			GWPPfileData(FNam, section, "Cut Timing(count)",	Read, this->cutTiming, 0);		// #KI150702-01
			TGWPPfileData(SecsCom::V_CutTiming,FNam, section, "Cut Timing(count)",	Read, this->cutTiming, 0);		// #KI150702-01
// #DucMV 20160505 Add Key System (E)
			GWPPfileData(FNam, section, "Emboss map type 1",		Read, this->embossMapType[0], 0);
			GWPPfileData(FNam, section, "Emboss map type 2",		Read, this->embossMapType[1], 0);
			GWPPfileData(FNam, section, "Emboss map IC count",	Read, this->mapICCnt, 0);
			GWPPfileData(FNam, section, "Curent IC bin of tape 1",Read, this->tapeBin[0], "1");
			GWPPfileData(FNam, section, "Curent IC bin of tape 2",Read, this->tapeBin[1], "1");
			// #OZ20150303 GWPP������
			GWPPfileFinish( FNam, Read );
			return r;
		}
	}PD;

	struct TAPE_Data{
		TAPE_Data(){
			Sec = _T(":�G���{�X�t�B�[�_�[�ް�");
		}
		CString Sec;
		int     faceMode;               // 0: Face Up, 1: Face Down
		int		tapeMode;				// 0: No use, 1: use only tape 1, 2: use only tape 2, 3: use both of tape
		int		numberOfIC[2];			// Max ICs of tape 1&2
		int		tapeWidth;				// Tape width of tape 1&2
		int		outTimer;				// Output timer
		int		retryTimer;				// Retry pick up timer
		int		embossICType;			// Emboss Feeder IC Type
		// #DongKD 20150116 Add 2D code
		int		numberOfskip2D;			// Number of ICs can be skipped when 2D code read false.
		int		read2D;					// this tape has 2D and read 2D. #KI150124-01
		int		cutTimer;				// �͂��ݎ��� #KI150702-01
		int		openTimer;				// �͂��݌�J������ #KI150702-01
		int		mappingMode;			// Mapping mode for emboss
		int		feedDelayTimer;			// Pitch�����f�B���C���� #TT160602-01
		CString GoodCode;
		CString	tapeBin[2];
		CString	mapFilePath;
		CString mapLogPath;
		BOOL DvDataRW(BOOL Read, LPCTSTR FNam, CString DSec) {
			CString section = DSec + Sec;
			BOOL r = TRUE;
			// #OZ20150303 GWPP������
			GWPPfileStart( FNam );
// #DucMV 20160505 Add Key System (S)
//			GWPPfileData(FNam, section, "TapeMode", Read, this->tapeMode,	0);
			TGWPPfileData(SecsCom::V_TapeMode,FNam, section, "TapeMode", Read, this->tapeMode,	0);
//			GWPPfileData(FNam, section, "TapeWidth(mm)", Read, this->tapeWidth,	0);
			TGWPPfileData(SecsCom::V_TapeWidth,FNam, section, "TapeWidth(mm)", Read, this->tapeWidth,	0);
//			GWPPfileData(FNam, section, "Max ICs on tape 1", Read, this->numberOfIC[0],	0);
			TGWPPfileData(SecsCom::V_numberOfIC,FNam, section, "Max ICs on tape 1", Read, this->numberOfIC[0],	0);
//			GWPPfileData(FNam, section, "Max ICs on tape 2", Read, this->numberOfIC[1],	0);
			TGWPPfileData(SecsCom::V_numberOfIC1,FNam, section, "Max ICs on tape 2", Read, this->numberOfIC[1],	0);
//			GWPPfileData(FNam, section, "Retry timer", Read, this->retryTimer,	100);
//			GWPPfileData(FNam, section, "Emboss Feeder IC Type",	Read, this->embossICType,	1);
			TGWPPfileData(SecsCom::V_embossICType,FNam, section, "Emboss Feeder IC Type",	Read, this->embossICType,	1);
//			GWPPfileData(FNam, section, "read 2D code",				Read, this->read2D,			0);		// #KI150124-01
			TGWPPfileData(SecsCom::V_read2D, FNam, section, "read 2D code",				Read, this->read2D,			0);
//			GWPPfileData(FNam, section, "2D code Number of skip",	Read, this->numberOfskip2D,	0);		// #DongKD 20150116 Add 2D code
			TGWPPfileData(SecsCom::V_numberOfskip2D, FNam, section, "2D code Number of skip",	Read, this->numberOfskip2D,	0);		// #DongKD 20150116 Add 2D code
//			GWPPfileData(FNam, section, "Emboss mapping mode",		Read, this->mappingMode,	0);
			TGWPPfileData(SecsCom::V_mappingMode, FNam, section, "Emboss mapping mode",		Read, this->mappingMode,	0);
//			GWPPfileData(FNam, section, "Curent IC bin of tape 1",	Read, this->tapeBin[0], "1");
			TGWPPfileData(SecsCom::V_tapeBin,FNam, section, "Curent IC bin of tape 1",	Read, this->tapeBin[0], "1");
//			GWPPfileData(FNam, section, "Curent IC bin of tape 2",	Read, this->tapeBin[1], "1");
			TGWPPfileData(SecsCom::V_tapeBin1,FNam, section, "Curent IC bin of tape 2",	Read, this->tapeBin[1], "1");
//			GWPPfileData(FNam, section, "�Ǖi�J�e�S��",				Read, this->GoodCode, "1");
			TGWPPfileData(SecsCom::V_EmbossGoodCode,FNam, section, "�Ǖi�J�e�S��",				Read, this->GoodCode, "1");
// #DucMV 20160505 Add Key System (E)
			GWPPfileData(FNam, section, "Face mode",				Read, this->faceMode,	0);
			// #OZ20150303 GWPP������
			GWPPfileFinish( FNam, Read );
			return r;
		}
		BOOL McDataRW(BOOL Read, LPCTSTR FNam, CString MSec) {
			CString section = MSec + Sec;
			BOOL r = TRUE;
			// #OZ20150303 GWPP������
			GWPPfileStart( FNam );
			GWPPfileData(FNam, section, "Output timer",		Read, this->outTimer,	1000);
			GWPPfileData(FNam, section, "Cut timer(ms)",	Read, this->cutTimer,	1000);	// #KI150701-01
			// ���S�ɊJ���̂�҂K�v�͂Ȃ�?
			GWPPfileData(FNam, section, "Open timer(ms)",	Read, this->openTimer,	500);	// #KI150701-01
			GWPPfileData(FNam, section, "Feed delay timer(ms)",	Read, this->feedDelayTimer,	300);	// #TT160602-01
			GWPPfileData(FNam, section, "Map file path",	Read, this->mapFilePath, CString("D:/TapeMap/"));
			GWPPfileData(FNam, section, "Map log file path",Read, this->mapLogPath, CString("D:/TapeMapLog/"));
			// #OZ20150303 GWPP������
			GWPPfileFinish( FNam, Read );
			return r;
		}
	}TapeD;
protected:
	/////////////////////////////////////////////////////////////////
	//
	// protected�ϐ�(���삷�邽�߂̃f�[�^)
	//
	//
public:
	/////////////////////////
	//
	//	DataRW�֐��i��ʌĂяo���p�j
	//
	/////////////////////////
	BOOL McDataRW(BOOL Read, LPCTSTR FNam, CString MSec) {
		CString section	= MSec + this->Sec;
		BOOL	r		= TRUE;
		if((! Read) && FNam[0] == 0){
			return	r;
		}
		r = this->TapeD.McDataRW(Read, FNam, MSec);
		CString sectionTape1 = section + "Tape1";						//#DucMV 160621 Barcode Reader
		CString sectionTape2 = section + "Tape2";						//#DucMV 160621 Barcode Reader
		ebMapping[0].barcode.BL600D.DataRW(Read, FNam, sectionTape1);	
		ebMapping[1].barcode.BL600D.DataRW(Read, FNam, sectionTape2);	//#DucMV 160621 Barcode Reader
		return r;
	}
	BOOL DvDataRW(BOOL Read, LPCTSTR FNam, CString DSec) {
		int r = TRUE;
		if((! Read) && FNam[0] == 0){
			return	r;
		}
		r = this->TapeD.DvDataRW(Read, FNam, DSec);
		return(r);
	}
	BOOL ProDataRW(BOOL Read, LPCTSTR FNam, CString PSec) {
		CString section = PSec + this->PD.Sec;
		int r = TRUE;
		if((!Read) && FNam[0] == 0){
			return	r;
		}
		r = this->PD.DataRW(Read, FNam, PSec);
		if(Read){
			this->icInfo[ePrepared].picy = PD.currentICNo[PD.currentTape - 1];
		}
		SetCurrentTape(this->PD.currentTape);
		return(r);
	}
public:
	/////////////////////////////////////////////////////////////////
	//
	// public �A�N�Z�T
	//
	//*******************************************
	// �擾accessor
	//*******************************************
// Tape data
	int GetOutTimer() {
		return TapeD.outTimer;
	}
	// #KI150702-01(S)
	// �؂鎞��
	int GetCutTimer() {
		return TapeD.cutTimer;
	}
	int GetOpenTimer() {
		return TapeD.openTimer;
	}
	// #KI150702-01(E)

	// #TT160602-01(S)
	// Pitch�����f�B���C����
	int GetFeedDelayTimer(){
		return this->TapeD.feedDelayTimer;
	}
	// #TT160602-01(E)
	int GetRetryTimer() {
		return TapeD.retryTimer;
	}

	int GetTapeMode() {
		return TapeD.tapeMode;
	}
	
	bool IsValidTapeNo(int no){
		// This Tape is selected or not
		bool isValid = ((this->TapeD.tapeMode & no)!=0) ? true:false;
		return isValid;
	}
	double GetTapeWidth() {
		return TapeD.tapeWidth;
	}

	int GetMaxICs(int tape) {
		if (tape <= 0 || tape >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		return TapeD.numberOfIC[tape - 1];
	}

	int GetTapeICType() {
		return this->TapeD.embossICType;
	}

	int GetMapIsLoaded(int tapeNo) {
		if (tapeNo <= 0 || tapeNo >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tapeNo);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		return this->m_mapIsLoaded[tapeNo - 1];
	}

	int GetHasACarrier(int tapeNo) {
		if (tapeNo <= 0 || tapeNo >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tapeNo);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		return this->m_hasACarrier[tapeNo - 1];
	}

	void SetTapeMode(int mode) {
		TapeD.tapeMode = mode;
	}

	void SetFaceMode (int mode){
		this->TapeD.faceMode = mode;
	}
	void SetTapeWidth(int width) {
		TapeD.tapeWidth = width;
	}

	void SetMaxICs(int tape, int icNum) {
		if (tape <= 0 || tape >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		TapeD.numberOfIC[tape - 1] = icNum;
	}
// Set current tape Ic Ready
	void SetCurrentTapeIcReady(int tape, int Icready){  
		this->m_Tape_Ic_Ready[tape-1] = Icready;
	}
// Product data
	int GetFaceMode(){
		return this->TapeD.faceMode;
	}

	int GetCurrentTape() {
		return PD.currentTape;
	}
// Get Current Tape Ic Ready
	int GetCurrentTapeIcReady(int curTape){     
		return m_Tape_Ic_Ready[curTape -1];
	}

	int GetCurrentICNumber(int tape) {
		if (tape <= 0 || tape >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		return PD.currentICNo[tape - 1];
	}

	CString GetBarcode(int tape) {
		if (tape <= 0 || tape >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		return PD.barcode[tape - 1];
	}

	void SetCurrentTape(int tape) {
		if (tape <= 0 || tape >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		PD.currentTape = tape;
	}

	void SetCurrentICNumber(int tape, int icNum) {
		if (tape <= 0 || tape >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}

		if (icNum < 0 || icNum > GetMaxICs(tape)) {
			CString msg;
			msg.Format("Error %s(%d) CurrentIC=%d", __FILE__, __LINE__, icNum);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}

		PD.currentICNo[tape - 1] = icNum;
	}

	void SetBarcode(int tape, CString barcode) {
		if (tape <= 0 || tape >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tape);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		PD.barcode[tape - 1] = barcode;
	}
	// #KI140809-03(S)
	void SetAging(bool isAging){
		this->isAging2	= isAging;
	}
	// #KI140809-03(E)
// IC info
	void SetRequestIcInfo_Emboss (ICPickUpData requestInfo) {
		this->icInfo[eRequested] = requestInfo;
	}

	ICPickUpData GetPreparedIcInfo_Emboss () {
		return this->icInfo[ePrepared];
	}

// #DongKD 20150122 Add 2D code (S)
	void	SetHas2DCodeReader(int has2DCodeReader) {
		this->m_has2DCodeReader = has2DCodeReader;
	}
	// #KI151114-01(S)
	bool	GetEmbossMappingMode(){
		return(this->m_embossBinMode && this->TapeD.mappingMode);
	}


	int		m_topBaseMode;		// #THAIHV 20160304 Top Die for Emboss mode
	void	SetTopBaseMode(int onOff) {
		this->m_topBaseMode = onOff;
	}
	// #KI151114-01(E)
// #DongKD 20150122 Add 2D code (E)
	void	SetEmbossBinMode(int mode) {
		this->m_embossBinMode = mode;
	}
	void	SetCode2DForDisp(int idx){// 0 - N-1
		int size = this->m_pMapdata[this->GetCurrentTape()-1].size() ;
		if(this->GetEmbossMappingMode() && size > 0){
			if(idx > 1){
				this->PD.code2D[0]	= this->m_pMapdata[this->GetCurrentTape()-1][idx-1]->UPICode;
				this->PD.diaNo[0]	= this->m_pMapdata[this->GetCurrentTape()-1][idx-1]->diaNo;
				this->PD.bin[0]	= this->m_pMapdata[this->GetCurrentTape()-1][idx-1]->BinNo;
			}
			if(idx <size){
				this->PD.code2D[1]	= this->m_pMapdata[this->GetCurrentTape()-1][idx]->UPICode;
				this->PD.diaNo[1]	= this->m_pMapdata[this->GetCurrentTape()-1][idx]->diaNo;
				this->PD.bin[1]	= this->m_pMapdata[this->GetCurrentTape()-1][idx]->BinNo;
			}
			if(idx+1 <size){
				this->PD.code2D[2]	= this->m_pMapdata[this->GetCurrentTape()-1][idx+1]->UPICode;
				this->PD.diaNo[2]	= this->m_pMapdata[this->GetCurrentTape()-1][idx+1]->diaNo;
				this->PD.bin[2]	= this->m_pMapdata[this->GetCurrentTape()-1][idx+1]->BinNo;
			}
		}
	}
	void	InitCode2DForDisp(){// 0 - N-1
		for(int i=0;i<3;i++){
			this->PD.code2D[i]	= "";
			this->PD.diaNo[i]	= 0;
			this->PD.bin[i]	= "";
		}
	}
	// #KI150124-03(S)
	/////////////////////////////////////////////////////////////////
	// �R�[���o�b�N
	//
	// 2D���j�b�g�����~������ɂ������Ĕ��]�ʒu�����S�����`�F�b�N
	// PickupIsSafety()�֐�
	bool (__cdecl *pPickupIsSafety)(void);
	// PickupIsSafety()�֐��̾��
	void SetPickupIsSafetyFunc(bool (__cdecl *pFunc)(void)) {
		pPickupIsSafety = pFunc;
	}
	// #KI150124-03(E)

	BOOL (__cdecl *pGetSecsGemComState)(void);
	void SetGetSecsGemComStateFunc(BOOL (__cdecl *pFunc)(void)) {
		pGetSecsGemComState = pFunc;
	}

	BOOL (__cdecl *pTopCtrJobExecute)(void);
	void SetTopCtrJobExecuteFunc(BOOL (__cdecl *pFunc)(void)) {
		pTopCtrJobExecute = pFunc;
	}

	BOOL (__cdecl *pEmbossMapEndEvent)(int);
	void SetEmbossMapEndEventFunc(BOOL (__cdecl *pFunc)(int)) {
		pEmbossMapEndEvent = pFunc;
	}
	

	// �}�b�v�t�@�C�����擾�̃R�[���o�b�N
	BOOL (__cdecl *pGetMIDByHost)(int tape, char *code);
	// �}�b�v�t�@�C�����擾�֐��̃Z�b�g
	void SetGetMIDByHostFunc(BOOL (__cdecl *pFunc)(int,char*)) {
		pGetMIDByHost = pFunc;
	}

	// �_�C�s�b�N�A�b�v(or�{���f�B���O)��
	BOOL (__cdecl *pReportDie)(int x, int y);
	// �_�C�s�b�N�A�b�v�֐��̃Z�b�g
	void SetReportDieFunc(BOOL (__cdecl *pFunc)(int, int)) {
		pReportDie = pFunc;
	}


	// #KI160324-01(S)
	// AddTraceSeqLog
	void (__cdecl *pAddTraceSeqLog) (CString);
	void SetAddTraceSeqLogFunc(void (__cdecl *pFunc)(CString)) {
		pAddTraceSeqLog = pFunc;
	}
	// #KI160324-01(E)


	void SetMapIsLoaded(int tapeNo, int loaded) {
		if (tapeNo <= 0 || tapeNo >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tapeNo);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		this->m_mapIsLoaded[tapeNo - 1] = loaded;
	}
	void SetHasACarrier(int tapeNo, bool hasACarrier) {
		if (tapeNo <= 0 || tapeNo >= 3) {
			CString msg;
			msg.Format("Error %s(%d) tape=%d", __FILE__, __LINE__, tapeNo);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		this->m_hasACarrier[tapeNo - 1] = hasACarrier;
	}
public:
	/////////////////////////////////////////////////////////////////
	//
	// public ���\�b�h
	//
	//
	BOOL	EmbossFeedOut(bool manu = false, int tapeNo = 1, bool hasToCount=true);
	BOOL	TapeExistSnsChk(int tape, bool &isOn);
	BOOL	SnsChk_Ionizer(bool &isNormal);
// #MU160325-01(S)
///	BOOL	SnsChk_EmbossFeederExist(bool &on);
///	BOOL	SnsChk_UnitLocked(bool &isLocked);
	BOOL	SnsChk_EmbossFeederTapeCover(bool &on);
	BOOL	SnsChk_EmbossFeederExist(int tape, bool &isOn);
// #MU160325-01(E)
	// #KI150702-01(S)
	BOOL	EmbossTapeCut();
	BOOL	EmbossCutOpen();
	// #KI150702-01(E)
	// #DongKD 20150116 Add 2D code (S)
	BOOL	Code2DLeftSideAct(bool left);
	BOOL	Code2DLeftSideSns(bool left, bool& onOff);
	BOOL	Code2DReadPosAct(bool readPos);
	BOOL	Code2DReadPosSns(bool readPos, bool& onOff);
	// #DongKD 20150116 Add 2D code (E)
	// DuyND Emboss Mapping mode
	BOOL	ReadMapFile(CString barcode, int tapeNo);
	BOOL	WriteMapFile(CString barcode, int tapeNo);
	BOOL	Check2DCode(CString code, int& pos, int tapeNo, int& recerr);
	BOOL	UpdateMappingData(int pos, int tapeNo, CString bin = "", CString code = "");
	void	DeleteMapData(int tapeNo);
	// DuyND Emboss SECS
	BOOL	UpdateBarcode(int tapeNo);
	BOOL	UpdateTopEmbossData(TopWfSlotData *pWfSlotData);
	// Get Emboss tape bin
	CString	GetTapeBin(int tapeNo);

protected:
//*******************************************
//
//	Error enum of PickUpUnit class
//
//*******************************************

	enum{
		Err_Tape1Sns		= 1,	// (+ 1) Tape 1 is not set
		Err_Tape2Sns,				// (+ 2) Tape 2 is not set
		Err_RunOutOfIC,				// (+ 3) Run out of IC 
		Err_WrongICType,			// (+ 4) Wrong IC type 
		Err_TapeMode,				// (+ 5) Tape mode error 
		Err_UnitIsNotSet,			// (+ 6) EmbossUnit is not set
		Err_Ioniz,					// (+ 7) Ionizer Error
		Err_UnitUnlocked,			// (+ 8) UnitUnlocked
		Err_PickupUnitIsNotSafety,	// (+ 9) PickupUnit is not safety
		Err_MapReadError,			// (+10) Map read error
		Err_RunOutOfICMap,			// (+11) RunOutOfIC(Map)
// #MU160325-01(S)
		Err_SnsEmbossFeeder1Exist,
		Err_SnsEmbossFeeder2Exist,
// #MU160325-01(E)
		// 20�܂Ŋm��
	};
};

#include	"mcc.h" 
#include	"opriodef.h"
#include	"oprctrl.h"
// #K0145 99-07-24 �ï��IC������6�̽ï�߂ɕ���
#include "tpc.h"
#include "tpctrl.h"
extern TPC		tpc;

OPRCtrl::OPRCtrl()
{
	pSWEvent = NULL;
	isigcount = iswcount = 0;
	isigtmo = 10;
	iswtmo = 1;
	bpushsw = boldsw = 0;
	BlinkStart = BlinkStop = BlinkReset = FALSE;	// �_���׸�
	evenodd = FALSE;								// SW�_���׸�
	bgetsw = 0;
#if GPDEBUG
	JoyStickFlag = SpdCtrlFlag = 0;
#endif
}

OPRCtrl::~OPRCtrl()
{
	pSWEvent = NULL;
	bpushsw = 0;
}
// OPRCtrl�����ݒ�
void OprInitInstance( void )
{
	// ����&�޻ް�@OFF

}
// ������Ăяo��
bool OPRCtrl::OprIntVal()
{
	BYTE	bnewsw;
	bool	r = true;
	CSingleLock	S(&MemSema,TRUE);	// ���ޱ�����̫

	// ������ܰ����
	if ( ++isigcount > isigtmo ) {
		isigcount = 0;
		if(BlinkStart){	
			r = pMCC->DIO_Output(IO_OpeSTON_OUT, evenodd) && r;
		}
		if(BlinkStop){
			r = pMCC->DIO_Output(IO_OpeSPON_OUT, evenodd) && r;
		}
		if(BlinkReset){
			r = pMCC->DIO_Output(IO_OpeRSON_OUT, evenodd) && r;
		}
		if(evenodd)	evenodd = false;
		else		evenodd = true;
	}
	// ���ڰ���SW�̽���
	if ( ++iswcount > iswtmo ) {
		iswcount = 0;
		bnewsw = 0;
//		bool start,stop,reset;
		bool start,stop,reset,reset2;	// #YT160422 ���u����p��[RESET]�\��
#if !GPDEBUG
		if (!pMCC->DIO_Input(IO_StartSw_IN, start)
		 || !pMCC->DIO_Input(IO_StopSw_IN, stop)
		 || !pMCC->DIO_Input(IO_ResetSw_IN, reset)
//		 || !pMCC->ButtonInput(2, reset)	// #YT160422 �n�[�hSw��������Ă���̂�ButtonInput()����reset��0�ɂ��Ă��܂��Ă�����̑΍�
		 || !pMCC->ButtonInput(2, reset2)
#else
		if (!pMCC->ButtonInput(0, start)
		 || !pMCC->ButtonInput(1, stop)
		 || !pMCC->ButtonInput(2, reset)
		 || !pMCC->ButtonInput(2, reset2)	// #YT160422 
#endif
		 ) {
			r = false;
		} else if (start) {
			bnewsw = 0xf0;
		}
		else if (stop) {
			bnewsw = 0xf1;
		}
		else if (reset || reset2) {
			bnewsw = 0xf2;
		}


if( bnewsw && 0 ){
	SYSTEMTIME	systime;
	GetLocalTime( &systime );
	TRACE( "#### OprIntVal bnewsw=%d %02d:%02d:%02d %03d\n", bnewsw, systime.wHour, systime.wMinute, systime.wSecond, systime.wMilliseconds );
}
		// SW�����m�F
		if ( bnewsw && ((bnewsw != boldsw) || (bnewsw != bgetsw)) ) {	
			bpushsw = bnewsw;
			//bgetsw = 0;
			if ( pSWEvent ) {				// �����ʒm����ľ��
				pSWEvent->SetEvent();
			}
if( 0 ){
	SYSTEMTIME	systime;
	GetLocalTime( &systime );
	TRACE( "#### OprIntVal bnewsw=%02X boldsw=%02X bpushsw=%02X bgetsw=%02X    %02d:%02d:%02d %03d\n", bnewsw, boldsw, bpushsw, bgetsw, systime.wHour, systime.wMinute, systime.wSecond, systime.wMilliseconds );
}
		}
		boldsw = bnewsw;
	}
	return r;
}
// ���ڰ���SW�e���߂̓_���A�����A�_��
bool OPRCtrl::OprStart( int onoff )
{
	CSingleLock	S(&MemSema,TRUE);	// ���ޱ�����̫
	bool r = true;
	if ( onoff == Off ) {
		BlinkStart = FALSE;
		r = pMCC->DIO_Output(IO_OpeSTON_OUT, false);
	}
	else if ( onoff == On ) {
		BlinkStart = FALSE;
		r = pMCC->DIO_Output(IO_OpeSTON_OUT, true);
	}
	else if ( onoff == Blink ) {
		BlinkStart = TRUE;
		r = pMCC->DIO_Output(IO_OpeSTON_OUT, true);
	}
	return r;
}

bool OPRCtrl::OprStop( int onoff )
{
	CSingleLock	S(&MemSema,TRUE);	// ���ޱ�����̫
	bool r = true;
	if ( onoff == Off ) {
		BlinkStop = FALSE;
		r = pMCC->DIO_Output(IO_OpeSPON_OUT, false);
	}
	else if ( onoff == On ) {
		BlinkStop = FALSE;
		r = pMCC->DIO_Output(IO_OpeSPON_OUT, true);
	}
	else if ( onoff == Blink ) {
		BlinkStop = TRUE;
		r = pMCC->DIO_Output(IO_OpeSPON_OUT, true);
	}
	return r;
}

bool OPRCtrl::OprReset( int onoff )
{
	CSingleLock	S(&MemSema,TRUE);	// ���ޱ�����̫
	bool r = true;
	if ( onoff == Off ) {
		BlinkReset = FALSE;
		r = pMCC->DIO_Output(IO_OpeRSON_OUT, false);
	}
	else if ( onoff == On ) {
		BlinkReset = FALSE;
		r = pMCC->DIO_Output(IO_OpeRSON_OUT, true);
	}
	else if ( onoff == Blink ) {
		BlinkReset = TRUE;
		r = pMCC->DIO_Output(IO_OpeRSON_OUT, true);
	}
	return r;
}

// ������ܰ�e���߂̓_���A�����A�_��
bool OPRCtrl::OprSigR( int onoff )
{
	bool r = true;
	if ( onoff == Off ) {
		r = pMCC->DIO_Output(IO_SigRBON_OUT, false);
		r = pMCC->DIO_Output(IO_SigRON_OUT, false) && r;
	} else if ( onoff == On ) {
		r = pMCC->DIO_Output(IO_SigRBON_OUT, false);
		r = pMCC->DIO_Output(IO_SigRON_OUT, true) && r;
	} else if ( onoff == Blink ) {
		r = pMCC->DIO_Output(IO_SigRON_OUT, false);
		r = pMCC->DIO_Output(IO_SigRBON_OUT, true) && r;
	}
	twrsts[0] = onoff;
	return r;
}
bool OPRCtrl::OprSigY( int onoff )
{
	bool r = true;
	if ( onoff == Off ) {
		r = pMCC->DIO_Output(IO_SigYBON_OUT, false);
		r = pMCC->DIO_Output(IO_SigYON_OUT, false) && r;
	} else if ( onoff == On ) {
		r = pMCC->DIO_Output(IO_SigYBON_OUT, false);
		r = pMCC->DIO_Output(IO_SigYON_OUT, true) && r;
	} else if ( onoff == Blink ) {
		r = pMCC->DIO_Output(IO_SigYON_OUT, false);
		r = pMCC->DIO_Output(IO_SigYBON_OUT, true) && r;
	}
	twrsts[1] = onoff;
	return r;
}
bool OPRCtrl::OprSigG( int onoff )
{
	bool r = true;
	if ( onoff == Off ) {
		r = pMCC->DIO_Output(IO_SigGBON_OUT, false);
		r = pMCC->DIO_Output(IO_SigGON_OUT, false) && r;
	} else if ( onoff == On ) {
		r = pMCC->DIO_Output(IO_SigGBON_OUT, false);
		r = pMCC->DIO_Output(IO_SigGON_OUT, true) && r;
	} else if ( onoff == Blink ) {
		r = pMCC->DIO_Output(IO_SigGON_OUT, false);
		r = pMCC->DIO_Output(IO_SigGBON_OUT, true) && r;
	}
	twrsts[2] = onoff;
	return r;
}
// #O0004	������ܰ��Ԏ擾
// #KS080620-01 �G���[���O���G���[�ƌx���ɕ�����
void	OPRCtrl::OprSigGet(int *pSig)
{
	twrsts_sv[0] = twrsts[0];
	twrsts_sv[1] = twrsts[1];
	twrsts_sv[2] = twrsts[2];
// #KS080620-01(S) �G���[���O���G���[�ƌx���ɕ�����
	if (pSig) {
		pSig[0] = twrsts_sv[0];
		pSig[1] = twrsts_sv[1];
		pSig[2] = twrsts_sv[2];
	}
// #KS080620-01(E)
}
// #O0004	������ܰ��ԕ��A
void	OPRCtrl::OprSigPut( void )
{
	OprSigR(twrsts_sv[0]);
	OprSigY(twrsts_sv[1]);
	OprSigG(twrsts_sv[2]);
}

// ���ڰ���SW�̓��̸͂ر
void	OPRCtrl::OprSwClesr( void )
{
	CSingleLock	S(&MemSema,TRUE);	// ���ޱ�����̫
	bpushsw = 0;
}
// ��ʂ��擾����SW�̒ʒm
void	OPRCtrl::OprSwNotice( int sw )
{
	CSingleLock	S(&MemSema,TRUE);	// ���ޱ�����̫
	bgetsw = sw;
}

// ���ڰ���SW�̉����ް��̓ǂݍ���
int	OPRCtrl::OprGetSw( void )
{
	CSingleLock	S(&MemSema,TRUE);	// ���ޱ�����̫
	int	bKey;
	bKey = bpushsw;
	bgetsw = bpushsw;
	bpushsw = 0;
if( 0 && bgetsw == 0 ){
	TRACE( "bpushsw = %02X bgetsw = %02X\n", bpushsw, bgetsw );
}
	return bKey;
}

// ���ڰ���SW�̓��Ͳ���Ă̓o�^
void	OPRCtrl::OprSetSwEvent( CEvent *pEv)
{
	CSingleLock	S(&MemSema,TRUE);	// ���ޱ�����̫
	pSWEvent = pEv;
}

// �x�� ON OFF
bool OPRCtrl::OprBzzA( int onoff )
{
	return (pMCC->DIO_Output(IO_BzzAON_OUT, (onoff == On) ? true : false));
}
bool OPRCtrl::OprBzzB( int onoff )
{
	return (pMCC->DIO_Output(IO_BzzBON_OUT, (onoff == On) ? true : false));
}
bool OPRCtrl::Joistick_Status(int &sts)
{
#if GPDEBUG
	sts=0;
	if (0x01 & JoyStickFlag) {
		sts |= X_Plus;
	}
	if (0x02 & JoyStickFlag) {
		sts |= X_Minus;
	}
	if (0x04 & JoyStickFlag) {
		sts |= Y_Plus;
	}
	if (0x08 & JoyStickFlag) {
		sts |= Y_Minus;
	}
	if (1 == SpdCtrlFlag) {
		sts |= Speed_Hi;
	}
	if (0 == SpdCtrlFlag) {
		sts |= Speed_Low;
	}
	if (2 == SpdCtrlFlag) {
		sts |= Pitch;
	}
	return true;
#else
	sts=0;
	bool r = true;
	bool On;
	if (!pMCC->DIO_Input(IO_X_Plus_IN, On)) {
		r = false;
	} else if (On) {
		sts |= X_Plus;
	}
	if (!pMCC->DIO_Input(IO_X_Minus_IN, On)) {
		r = false;
	} else if (On) {
		sts |= X_Minus;
	}
	if (!pMCC->DIO_Input(IO_Y_Plus_IN, On)) {
		r = false;
	} else if (On) {
		sts |= Y_Plus;
	}
	if (!pMCC->DIO_Input(IO_Y_Minus_IN, On)) {
		r = false;
	} else if (On) {
		sts |= Y_Minus;
	}
	if (!pMCC->DIO_Input(IO_Speed_Hi_IN, On)) {
		r = false;
	} else if (On) {
		sts |= Speed_Hi;
	} else {
		sts |= Speed_Low;
	}
	if (!pMCC->DIO_Input(IO_Speed_Pitch_IN, On)) {
		r = false;
	} else if (On) {
		sts |= Pitch;
	}
	return r;
#endif
}

bool OPRCtrl::GetStartSw(bool &On)
{
	bool r = true;
#if !GPDEBUG
	if (!pMCC->DIO_Input(IO_StartSw_IN, On)) {
#else
	if (!pMCC->ButtonInput(0, On)) {
#endif
		r = false;
	} else if (On) {
		tpc.GpBeep();
	}
	return r;
}

// #KS071110-03 ���]�G�[�W���O�e�X�g�@�\
bool OPRCtrl::ResetSwPushed(int EnableFlg)
{
	bool r = false;
	bool On;
#if !GPDEBUG
	//if (!pMCC->DIO_Input(IO_ResetSw_IN, On)) {
	if (!pMCC->DIO_Input(IO_ResetSw_IN, On) || !pMCC->ButtonInput(2, On)) {		// #YT160422 ���u����p��[RESET]�\��
#else
	if (!pMCC->ButtonInput(2, On)) {
#endif
		r = true;	// ���ُ͈�Ȃ̂ŉ����ꂽ���Ƃɂ���
	} else if (On && EnableFlg) {
		r = true;
		tpc.GpBeep();
	}
	return(r);
}

// OCRComm.cpp: OCRComm �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#ifdef	TEST
#include "stdafx.h"
#else
#include "stdafx.h"
#endif

#include "OCRComm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Constructor 
//////////////////////////////////////////////////////////////////////

OCRComm::OCRComm()
{
	eventAnswer.ResetEvent();
	this->m_errorID = 0;
	ocr_reply_q = OCR_ANSWER_Q();
	pRThread = AfxBeginThread(this->OCRCommRecv, this, THREAD_PRIORITY_NORMAL);
	if( !pRThread ){
		AfxMessageBox("Cannot create receive thread", MB_OK, 0);
	}
	m_hCommRThread = pRThread->m_hThread;
}

//////////////////////////////////////////////////////////////////////
// Destructor
//////////////////////////////////////////////////////////////////////

OCRComm::~OCRComm()
{

}

//////////////////////////////////////////////////////////////////////
// Set RS232 communication parameter 
//////////////////////////////////////////////////////////////////////

void	OCRComm::SetCommPara( CString ComPort, int boudrate, int databit, int stopbit, int parity, int evenodd )
{
	PortComm.SetCommOpenInfo( ComPort, boudrate, databit, stopbit, parity, evenodd );
}

//////////////////////////////////////////////////////////////////////
// Open communication
//////////////////////////////////////////////////////////////////////

BOOL	OCRComm::OpenComm()
{
	BOOL	r;
	r = PortComm.CommOpen();
	if( r ){
		CommSetting();
	}
	return r;
}

//////////////////////////////////////////////////////////////////////
// Close communication 
//////////////////////////////////////////////////////////////////////

BOOL	OCRComm::CloseComm()
{
	BOOL	r = TRUE;
//	r = PortComm.CommClose();
	if(PortComm.m_hComm && PortComm.m_hComm != INVALID_HANDLE_VALUE) {
		CloseHandle(PortComm.m_hComm);
		PortComm.m_hComm = 0;
	}

	return r;
}

//////////////////////////////////////////////////////////////////////
// Communication settings
//////////////////////////////////////////////////////////////////////
BOOL OCRComm::CommSetting()
{
	// get any early notifications
	SetCommMask( PortComm.m_hComm, EV_RXCHAR ) ;
	// setup device buffers 
	if( !SetupComm( PortComm.m_hComm, 4096, 4096 ) )
		return FALSE;
	// purge any information in the buffer
	PurgeComm( PortComm.m_hComm,	PURGE_TXABORT | PURGE_RXABORT |
						PURGE_TXCLEAR | PURGE_RXCLEAR ) ;

	// set up for overlapped I/O
	PortComm.m_CommTimeOuts.ReadIntervalTimeout =0xFFFFFFFF ;		//  Timeout
	PortComm.m_CommTimeOuts.ReadTotalTimeoutMultiplier = 0 ;
	PortComm.m_CommTimeOuts.ReadTotalTimeoutConstant = 100 ;		//  Timeout(ms)
	PortComm.m_CommTimeOuts.WriteTotalTimeoutMultiplier = 0 ;
	PortComm.m_CommTimeOuts.WriteTotalTimeoutConstant = 100 ;		//  Timeout(ms)
	if(!SetCommTimeouts(PortComm.m_hComm, &PortComm.m_CommTimeOuts))
		return FALSE;

	//*** COM Port Setup ***
		
	PortComm.m_Dcb.DCBlength = sizeof( DCB ) ;
	if(!GetCommState( PortComm.m_hComm, &PortComm.m_Dcb ))
		return FALSE;

	PortComm.m_Dcb.BaudRate = PortComm.m_BaudRate;	// �`�����x
	PortComm.m_Dcb.ByteSize = PortComm.m_ByteSize;	// �ް���(4�`8)
	PortComm.m_Dcb.StopBits = PortComm.m_StopBits;	// STOP�r�b�g 0=1�r�b�g 1=2�r�b�g
	PortComm.m_Dcb.fParity  = PortComm.m_fParity;	// ���è���� 0=���A1=�L
	if( PortComm.m_fParity == 0 )
		PortComm.m_Dcb.Parity   = NOPARITY;   // 0=no, 1=odd, 2=even
	else
		PortComm.m_Dcb.Parity = PortComm.m_Parity;

	// �ʐM�߰Ă̐ݒ��ύX���܂��B
	if(!SetCommState(PortComm.m_hComm, &PortComm.m_Dcb)){
		long we = GetLastError();
		return FALSE;
	}
	return TRUE;
}

void OCRComm::SetAnswerObject(CEvent* evOK, CEvent* evNG, OCR_ANSWERDATA *ansData)
{
	ocr_reply_q.pEventObjOK = evOK;
	ocr_reply_q.pEventObjNG = evNG;
	ocr_reply_q.ansData = ansData;
}

int		OCRComm::AnalizeReceiveData( CString rstr )
{
	int r;
	r = TRUE;

	if (r) {
		int count = 0;
		int dataLength = 0;
		int length = rstr.GetLength();
		char* replyData =  rstr.GetBuffer(length);
		char* pch;
		char* pPass;
		char* pData;
		pch = strtok (replyData,",");
		while (pch != NULL)
		{	
			if(count == 0){
				pData = pch;
			}
			if(count == 1){
				pPass = pch;
			}
			pch = strtok (NULL, ",");
			count++;
		}
		dataLength = strlen(pData);
		int passed;
		if(pPass != NULL && count == 2){
			passed = atoi(pPass);
		}else{
			passed = 0;
		}
		if( passed == 1){
			r = RcvANSWER;
			if (ocr_reply_q.ansData) {
				memset (ocr_reply_q.ansData->u_asdata.data,0,20);
				memcpy(ocr_reply_q.ansData->u_asdata.data, pData, dataLength);
			}
			if (ocr_reply_q.pEventObjOK) {
				TRACE("+++++REPLY-OCRComm-pEventObjOK is set\n");
				ocr_reply_q.pEventObjOK->SetEvent();
			}
		} else{
			r = RcvERROR;
			TRACE("+++++REPLY-OCRComm-pEventObjNG is set\n");
			if (ocr_reply_q.pEventObjNG) {
				ocr_reply_q.pEventObjNG->SetEvent();
			}
		}
	}
	return r;
}

void 	OCRComm::MakeReadCommand(char* CommandLine)
{
	sprintf(CommandLine, "READ");
	int lth = strlen(CommandLine);
	CommandLine[lth] = 0x0D;
}

int		OCRComm::Send(char* CommandLine)
{
	int		r = Err_None;
	BOOL	fWriteStat;
	DWORD	dwBytesWritten=0;
	int		len = strlen(CommandLine);
	
	PortComm.CommPurge();
	dwBytesWritten = 0;
	fWriteStat = WriteFile(PortComm.m_hComm, CommandLine, len, &dwBytesWritten, 0);
	TRACE("OCRCom Send(%s)\n",CommandLine);
	if(!fWriteStat || !dwBytesWritten) {
		r = Err_SendError;
	}
	
	return r;
}

int	OCRComm::WaitForAnswer()
{
	int r = Err_None;
	
	if (r) {
		CSyncObject *ppObjects[2] = {0};
		ppObjects[0] = ocr_reply_q.pEventObjOK;
		ppObjects[1] = ocr_reply_q.pEventObjNG;
		
		CMultiLock	M(ppObjects,2);
		int	m = M.Lock(OCR_REPLY_TIMEOUT,FALSE);
		if (m == WAIT_TIMEOUT) {
			r = Err_TimeOut;
		} else if (m == 0) {
			r = Err_None;
		} else {
			r = this->m_errorID;
		}
	}
	
	return r;
}


//////////////////////////////////////////////////////////////////////
// Receive thread 
//////////////////////////////////////////////////////////////////////

UINT	OCRComm::OCRCommRecv( LPVOID pParam )
{
	enum {
		IDLE = 0,		// Start
		WTCR = 1		// Wait for 0x0D
	};

	int		i, fReadStat;
	int		PStatus;
	unsigned long	dwLength = 0;
	char	rcvBuf[1000];
	CString		rstr;
	OCRComm	*pOCRPort = (OCRComm *)pParam;

	PStatus = IDLE;

	rstr.Empty();
	for(;;) {
		if( (pOCRPort->PortComm.m_hComm != (void *)0) && ((pOCRPort->PortComm.m_hComm != (void *)0xffffffff)) ){
			fReadStat = ReadFile( pOCRPort->PortComm.m_hComm, &rcvBuf, 1, &dwLength, 0 );

			if( fReadStat && dwLength ){
				for( i=0 ; i<(int)dwLength ; i++ ){
					switch( PStatus ){
					case	IDLE:		// Start reading
						if (rcvBuf[i] != OCRComm::NULLCHAR){
							rstr += rcvBuf[i];
							PStatus = WTCR;
						}
						break;
					case	WTCR:		// Wait for 0x0D
						if (rcvBuf[i] != OCRComm::TERMCHAR){
							rstr += rcvBuf[i];
						} else {		// 0x0D
							rstr += rcvBuf[i];
							int ae = pOCRPort->AnalizeReceiveData(rstr);		
							rstr.Empty();				// Reset string 
							PStatus = IDLE;				// Wait for next command
						}
						break;
					}
				}
			} else {
				Sleep( 10 );
			}
		} else {
			Sleep( 10 );
		}
	}
	return 0;
}


CString OCRComm::GetOCRID()
{
	int ret = Err_None;
	CString OCRID = "";
	char cmdLine[10] = {0};
	OCR_ANSWERDATA	answerD;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	EvAnswerOK.ResetEvent();
	EvAnswerNG.ResetEvent();
	MakeReadCommand(cmdLine);
	ret = Send(cmdLine);
	if (ret == Err_None) {
		// Set answer object event
		SetAnswerObject(&EvAnswerOK, &EvAnswerNG, &answerD);
		// Wait for answer from load port
		ret = WaitForAnswer();
	}
	if (ret == Err_None) {
		OCRID = CString(ocr_reply_q.ansData->u_asdata.data);
	}

	SetAnswerObject(NULL, NULL, NULL);
	TRACE("TSDV: OCR String : %s\n", OCRID);				// #DucMV 20151216 OCR function Check result data
	return OCRID;
}

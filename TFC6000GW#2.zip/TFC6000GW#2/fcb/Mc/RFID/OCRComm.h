// OCRComm.h: OCRComm �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include	<afxmt.h>
#include "PortComm.h"


class OCRComm  
{
public:
	OCRComm();
	virtual ~OCRComm();

	struct	OCR_ANSWERDATA {				// Answer data
		char	command;				// Command
		union ASDATA {
			char 	data[20];
		} u_asdata;
	}; // s_asData;

	enum	{
		RcvERROR	= 0,
		RcvANSWER	= 1
	};
	enum	{
		NULLCHAR	= 0x00,
		TERMCHAR	= 0x0D,
	};
private:
	// Comm port setting
	BOOL	CommSetting();		
	// Communication receive thread
	static	UINT	OCRCommRecv(LPVOID pParam);
	// Make command string function
	void	MakeReadCommand(char* CommandLine);
	void	MakeWriteCommand(char* CommandLine, char* sendData);
	// Parse reply message
	int		AnalizeReceiveData(CString recvD);
	// Send command to Load port and wait for reply 
	int		Send(char* CommandLine);
	int		WaitForAnswer();
	// Set answer object
	void	SetAnswerObject(CEvent* evOK, CEvent* evNG, OCR_ANSWERDATA *ansData);
	// Convert data to char
	CString dataConvertToChar(CString str);

	#define	OCR_ANSWER_QMAX	10	
	struct	OCR_ANSWER_Q	{
		CEvent*	pEventObjOK;
		CEvent*	pEventObjNG;
		struct OCR_ANSWERDATA* ansData;

		OCR_ANSWER_Q() {
			pEventObjOK = NULL;
			pEventObjNG = NULL;
			ansData = NULL;
		}
	} ocr_reply_q;
public:
	// End communication
	BOOL	CommEnd();
	// Set communication port parameter
	void	SetCommPara( CString ComPort, int boudrate, int databit, int stopbit, int parity, int evenodd );
	// Open communication port
	BOOL	OpenComm();				// Open Comm port
	// Close communication port
	BOOL	CloseComm();			// Close Comm port
	
	// Read OCR
	CString GetOCRID();

private:
	// Notify event when receive answer
	CEvent*	evANSWER;
	// Receive thread pointer 
	CWinThread	*pRThread;
	// Receive thread handle
	HANDLE	m_hCommRThread;
	
	int m_errorID;
	#define	OCR_REPLY_TIMEOUT	10000		// Timeout for reply (ACK, NAK)
	CEvent	eventAnswer;	
	
	struct OCR_ANSWERDATA *pAnswerData;
public:
	CPortComm PortComm;			// ����M�N���X�̐���

	enum OCRError	{
		Err_None		= '0',

		Err_SendError	= 0,
		Err_TimeOut	= 1,
		
	};


};

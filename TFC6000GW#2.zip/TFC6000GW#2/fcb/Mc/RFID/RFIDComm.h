// RFIDComm.h: RFIDComm �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include	<afxmt.h>
#include "PortComm.h"

class RFIDComm  
{
public:
	RFIDComm();
	virtual ~RFIDComm();

	struct	LP_ANSWERDATA {				// Answer data
		char	command;				// Command
		union ASDATA {
			char 	data[17];
		} u_asdata;
	}; // s_asData;

	enum	{
		RcvERROR	= 0,
		RcvANSWER	= 1
	};
	enum	{
		STARTCHAR	= 'S',
		TERMCHAR1	= 0x0D,
	};
private:
	// Comm port setting
	BOOL	CommSetting();		
	// Communication receive thread
	static	UINT	RFIDCommRecv(LPVOID pParam);
	// Make command string function
	void	MakeReadCommand(char* CommandLine, int pageNo);
	void	MakeWriteCommand(char* CommandLine, char* sendData);
	// Parse reply message
	int		AnalizeReceiveData(CString recvD);
	// Send command to Load port and wait for reply 
	int		Send(char* CommandLine);
	int		WaitForAnswer();
	// Set answer object
	void	SetAnswerObject(CEvent* evOK, CEvent* evNG, LP_ANSWERDATA *ansData);
	// Checksum calculator
	int 	SendChecksumCalculator(char* data, int length, char& CSH_ADD, char& CSI_ADD, char& CSH_XOR, char& CSI_XOR);
	// Convert data to char
	CString dataConvertToChar(CString str);

	#define	LP_ANSWER_QMAX	10	
	struct	LP_ANSWER_Q	{
		CEvent*	pEventObjOK;
		CEvent*	pEventObjNG;
		struct LP_ANSWERDATA* ansData;
		// #DDT151020-01 Default constructor for answer struct
		LP_ANSWER_Q() {
			pEventObjOK = NULL;
			pEventObjNG = NULL;
			ansData = NULL;
		}
	} lp_reply_q;
public:
	// End communication
	BOOL	CommEnd();
	// Set communication port parameter
	void	SetCommPara( CString ComPort, int boudrate, int databit, int stopbit, int parity, int evenodd );
	// Open communication port
	BOOL	OpenComm();				// Open Comm port
	// Close communication port
	BOOL	CloseComm();			// Close Comm port
	
	// Read RFID
	CString GetCarrierID();
	void 	SetReaderID(char readerID) {
		this->m_readerID = readerID;
	}
private:
	// Notify event when receive answer
	CEvent*	evANSWER;
	// Receive thread pointer 
	CWinThread	*pRThread;
	// Receive thread handle
	HANDLE	m_hCommRThread;
	// Reader ID
	char m_readerID;
	
	int m_errorID;
	#define	LP_REPLY_TIMEOUT	10000		// Timeout for reply (ACK, NAK)
	CEvent	eventAnswer;	
	
	struct LP_ANSWERDATA *pAnswerData;
public:
	CPortComm PortComm;			// ����M�N���X�̐���

	// RFID command
	enum RFIDCommand	{
		Cmd_Read			,	// X	Read data 								H->R
		Cmd_Write			,	// W	Write data                              H->R
		Cmd_AutoRead		,	// R	Automatic read                          R->H
		Cmd_ReqPara			,	// G	Request parameter value                 H->R
		Cmd_SetPara			,	// P	Set parameter                           H->R
		Cmd_Error			,	// E	Error message                           R->H
		Cmd_HeartBeat		,	// H	Heart beat                              H->R
		Cmd_QueryRev		, 	// V	Query software version                  H->R
		Cmd_LockPage		,	// L 	Lock a page of the transponder          H->R
		Cmd_SetTune			,	// I	Set tuning of the RF module             H->R
		Cmd_ReqTuneSett		,	// J	Request tuning settings of RF module    H->R
		Cmd_Sensor			,	// A	Sensor event                            H->R
		Cmd_Reset			,	// N	Reset                                   H->R
	};


	// RFID error
	enum RFIDError	{
		Err_None		= '0',
		Err_Fail		= '1',
		Err_ExFail		= '2',
		Err_WriteFail	= '3',
		Err_NoTag		= '4',
		Err_InvalidPara	= '5',
		Err_Unknown		= '6',
		Err_Unconfig	= '7',
		Err_Check		= '8',
		Err_VoidAck		= '9',
		Err_Lock		= 'A',
		Err_MsgLength	= ':',
		Err_InvalidCmd	= ';',
		Err_NoAck		= 'B',

		Err_SendError	= 0,
		Err_RTimeOut	= 1,
		
	};


};

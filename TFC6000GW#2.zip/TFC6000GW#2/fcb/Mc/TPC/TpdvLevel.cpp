/*---------------------------------------------------------------------
	������ى�ʊ֐��i�i���ް�:���x�����O�֘A�j
								1998 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_Leveling(int step,int page)
{
	int	r=OK_END;
	for(;;){
		if(step == 0){			
			if(page == 1)		r = DVd_Leveling1();
			else				r = Data1_END;
		}
		else{
			step = 0;
			r = Data1_END;
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		}
		else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}
/////////////////////////////////////////////////////////////////////////////
//----- �ް��ݒ�@�߰��1	
int TPCtrl::DVd_Leveling1()
{
	enum{
		Hy_SNo				= 1260,		// ���No.(���׏d��)
		Low_SNo				= 1261,		// ���No.(��׏d��)

		AttLevelingEx		= 200,		// ����ݸ� �L��
		//
		BgLevel					= 300,	// ����ݸ� B'g����(mm)
		SachLevel1				= 302,	// ����J�n����(mm)
		SachSpeed				= 304,	// �����߰��(mm/s)
		RetnLevel				= 306,	// ���݊J�n����(mm)
		RetnSpeed				= 308,	// ���ݽ�߰��(mm/s)
		BgForce					= 310,	// ����ݸމ׏d
		BgTime					= 312,	// ��������
		BgFUpTime				= 314,	// ����ݸމ׏d�����オ�莞��(sec)
		BgFDownTime				= 316,	// ����ݸމ׏d���������莞��(sec)
		SinkLevel				= 318,	// ���ݍ��ݗ�(mm)
	
		KeyLevelingEx			= 65,	// ����ݸ� �L��
		KeyLevelingNo			= 66,	
		KeyBgLevel				= 67,	// ����ݸ� B'g����(mm)
		KeySachLevel1			= 68,	// ����J�n����(mm)
		KeySachSpeed			= 69,	// �����߰��(mm/s)
		KeyRetnLevel			= 70,	// ���݊J�n����(mm)
		KeyRetnSpeed			= 71,	// ���ݽ�߰��(mm/s)
		KeyBgForce				= 72,	// ����ݸމ׏d
		KeyBgTime				= 73,	// ��������
		KeyBgFUpTime			= 74,	// ����ݸމ׏d�����オ�莞��(sec)
		KeyBgFDownTime			= 75,	// ����ݸމ׏d���������莞��(sec)
		KeySinkLevel			= 76,	// ���ݍ��ݗ�(mm)
// #YS110322-01 ���i��(�f�[�^�ݒ�)
		// �i��I��
		ICTypes				= 100,		// �i��I��(bit0:1 bit1:2 ...)
		Name				= 1200,		// �i�햼
		KeyICType1			= 230,		// IC�i��ԍ��P
		KeyICType2			= 231,		// IC�i��ԍ��Q
		KeyICType3			= 232,		// IC�i��ԍ��R
		KeyICType4			= 233,		// IC�i��ԍ��S

		KeyCancel				,	
		KeyHome			= '0'	,	
		KeyPrev					,	
		KeyTeach				,	
		KeyData					,	
		KeyData1				,	
		KeyData2				,	
		KeyData3				,	
		KeyData4				,	
	};
	int		r = false;
	BOOL	DataUpdate=FALSE;

	//--------------------------------
	// �׏d�\��Kgf�Ή�
	double	F_k = 10;	// �׏d����:������1�ʂ܂�
	double FUcnv = (!pMCC->MD.OptionD.ForceKgf) ? 1 : N_KGF;
	int FUnit_idx = (!pMCC->MD.OptionD.ForceKgf) ? 0 : 1;
	static const char *FUnit[] = { "N", "Kgf" };
	//--------------------------------
	// �\����ʂ̐ݒ�E�؂�ւ�
	bool	isLowForce = (pMCC->MD.OptionD.AirCylBgHead) ? true : false;
	tpc.GpScreenDisp(isLowForce ? Low_SNo : Hy_SNo);
	//--------------------------------
	//-----------------------------------------------------
	//--------------------------------
	// �ő�׏d�̎擾
	double	ForceMax;
	if(isLowForce){
// #YS121130-01 ���׏d�Ή�(�׏d�֌W�}�V���f�[�^��{��)
		ForceMax = pMCC->BND.MD.MinMaxInputD.dv_RegulatorForce[1][pMCC->MD.OptionD.bgHeadChange].Max;	// ������ގ���׏dͯ�ށF����ިݸޑ��ő�׏d(N)
	}else{
		ForceMax = pMCC->BND.MD.MinMaxInputD.dv_MotorCtrlForce.Max;		// ���׏dͯ�ށF����ިݸޑ��ő�׏d(N)
	}
	//--------------------------------
	// �ő�Level�̎擾
	double LevelMax = pMCC->BND.MD.MinMaxInputD.dv_BgLevel.Max;
	//--------------------------------
	//-----------------------------------------------------
	//--------------------------------
	// ����Ώ�ICNo�̓ǂݏo��
// #YS110322-01 ���i��(�f�[�^�ݒ�)
	int Update = 0;
	if (!pMCC->BND.frame.IcTypeIsValid(this->tpcNowIcType)) {
		this->tpcNowIcType	= pMCC->BND.frame.RegNoToIcType(this->tpcNowRegistNumber);
	}
	//--------------------------------
	// ���p�\��Ӱ��
	int		Lang = (pMCC->MD.OptionD.Language_mode) ?  1: 0;
	//--------------------------------

	for(;;){
		BOOL	End=FALSE;
// #YS110322-01 ���i��(�f�[�^�ݒ�)
		tpc.GpPut16(ICTypes, (0x01<<(this->tpcNowIcType-1)));	// IC�i��I�����
		char *name = "";
		name = pMCC->BND.frame.eachIcName[this->tpcNowIcType-1].GetBuffer(40);
		tpc.GpPutStrLen(Name, name, 40);				// IC�i�햼�\��
		//-----------------------------------------------
		// �ݒ�𔽉f
		tpc.GpPut16(AttLevelingEx,0);
		tpc.GpPut16(AttLevelingEx, pMCC->BND.bond.GetDoLeveling(this->tpcNowIcType)	? ATTR_B00 : ATTR_B01);		// ����ݸލs��/�s��Ȃ�
		//
		if(pMCC->BND.bond.GetLvlBgForce(this->tpcNowIcType) > ForceMax)	{pMCC->BND.bond.SetLvlBgForce(this->tpcNowIcType, ForceMax);}
		if(pMCC->BND.bond.GetLvlBgLevel(this->tpcNowIcType) > LevelMax)	{pMCC->BND.bond.SetLvlBgLevel(this->tpcNowIcType, LevelMax);}

		DataPut(BgForce,	pMCC->BND.bond.GetLvlBgForce(this->tpcNowIcType),		10);
		DataPut(BgLevel,	pMCC->BND.bond.GetLvlBgLevel(this->tpcNowIcType),		100);
		DataPut(SachSpeed,	pMCC->BND.bond.GetLvlSrchSpeed(this->tpcNowIcType),		10);
		DataPut(SachLevel1,	pMCC->BND.bond.GetLvlSrchLevel(this->tpcNowIcType),		10);
		DataPut(RetnSpeed,	pMCC->BND.bond.GetLvlRetnSpeed(this->tpcNowIcType),		10);
		DataPut(RetnLevel,	pMCC->BND.bond.GetLvlRetnLevel(this->tpcNowIcType),		10);
		DataPut(BgFUpTime,	pMCC->BND.bond.GetLvlBgFUpTime(this->tpcNowIcType),		100);
		DataPut(BgFDownTime,pMCC->BND.bond.GetLvlBgFDownTime(this->tpcNowIcType),	100);
		DataPut(BgTime,		pMCC->BND.bond.GetLvlBgTime(this->tpcNowIcType),		100);
		DataPut(SinkLevel,	pMCC->BND.bond.GetLvlSinkLevel(this->tpcNowIcType),		100);
		//-----------------------------------------------
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			// �z�X�g�ɂ���ă��b�N����Ă���ꍇ�́A�J�ڃ{�^���ȊO�͖����ɂ���B
			if(this->IsLockedByHost(key)){
				continue;
			}
			if(key)	tpc.GpBeep();
			switch(key){
				//----------------------------------------------
				// ����ݸޗL��
				//
				case KeyLevelingEx		:
				case KeyLevelingNo		:
					{
						int idx = KeyLevelingNo - key;
// #YS130517-01(S) �{���@�\�쐬
						int isFinalBond = false;
						if (key == KeyLevelingEx) {
							if(pMCC->BND.frame.GetObject() && pMCC->BND.frame.GetUseMultiStackMode()){
								int bgSites = pMCC->BND.frame.GetBgSiteNumbers();
								for (int i=1;i<bgSites+1;++i) {	// 
									// #KI160530-01
									int regNo = pMCC->BND.frame.GetBgSitesRegNo(i, eWafer);
									if (pMCC->BND.frame.RegNoToFinalBond(regNo)) {	// �{���Q�b�g
										isFinalBond = true;
										break;
									}
								}
							}
						}
						if (isFinalBond) {
							const char *msg[][2] = {
								{ "�{��ON��OFF���ɂ��ĉ�����", "" },
								{ "Please turn off Final Bond mode.", "" },
							};
							Warn(msg[Lang][0], msg[Lang][1]);
						}
// #YS130517-01(E)
						//-------------------------------
						// �ް��ݒ肪�s��ꂽ��
						if(idx != pMCC->BND.bond.GetDoLeveling(this->tpcNowIcType)){
							pMCC->BND.bond.SetDoLeveling(idx, this->tpcNowIcType);
							tpc.GpPut16(AttLevelingEx, pMCC->BND.bond.GetDoLeveling(this->tpcNowIcType) ? ATTR_B00 : ATTR_B01);
							DataUpdate = TRUE;
						}
						//-------------------------------
					}
					break;
				//----------------------------------------------
				// ����ݸމ׏d
				//
				case KeyBgForce		:
					{
						const char* msg[] = {
							"������",
							"Leveling Force",
						};
						const char* Ymsg[] = {
							"�_�~�[����ݸނł����H",
							"Dummy dipping motion?",
						};
						const char* Wmsg[] = {
							"����ݸ� ���ق� 5mm�ɐݒ肳��܂����B",
							"Dipping level program 5mm",
						};
						double bgforce = pMCC->BND.bond.GetLvlBgForce(this->tpcNowIcType) * FUcnv;
						double max = floor(ForceMax * FUcnv * F_k) / F_k;
						if (DataEdit(msg[Lang], FUnit[FUnit_idx], bgforce , 0, max, F_k)) {
							DataUpdate = TRUE;
							if (0 == bgforce) {
								if (YesNo(Ymsg[Lang])) {					//-- �m�F���
									pMCC->BND.bond.SetLvlBgForce(this->tpcNowIcType, bgforce / FUcnv);
									Warn(Wmsg[Lang]);						//-- �x�����
								} else {
									bgforce = pMCC->BND.bond.GetLvlBgForce(this->tpcNowIcType) * FUcnv;
								}
							} else {
								pMCC->BND.bond.SetLvlBgForce(this->tpcNowIcType, bgforce / FUcnv);
							}
							if(0 == pMCC->BND.bond.GetLvlBgForce(this->tpcNowIcType)) {
								pMCC->BND.bond.SetLvlBgLevel(this->tpcNowIcType, 5);
								DataPut(BgLevel,pMCC->BND.bond.GetLvlBgLevel(this->tpcNowIcType),100);
							}
							DataPut(BgForce, bgforce, F_k);
						}
					}
					break;
				//----------------------------------------------
				// ����ݸގ���
				//
				case KeyBgTime		:
					{
						const char *msg[] = {
							"��������",
							"Leveling Time",
						};
						double time = pMCC->BND.bond.GetLvlBgTime(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"sec",time,0,99.99,100)){
							DataPut(BgTime,time,100);
							pMCC->BND.bond.SetLvlBgTime(this->tpcNowIcType, time);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// �����߰��
				//
				case KeySachSpeed		:
					{
						const char *msg[] = {
							"�����߰��",
							"Search Speed",
						};
						//--------------------------
						// �ݒ�͈͎擾
						double max = pMCC->BND.MD.MinMaxInputD.dv_BgSearchSpeed.Max;
						double min = pMCC->BND.MD.MinMaxInputD.dv_BgSearchSpeed.Min;
						//--------------------------
						//
						double speed = pMCC->BND.bond.GetLvlSrchSpeed(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"mm/s", speed, min, max, 10)){
							DataPut(SachSpeed,speed,10);
							pMCC->BND.bond.SetLvlSrchSpeed(this->tpcNowIcType, speed);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// �������
				//
				case KeySachLevel1		:
					{
						const char *msg[] = {
							"�������",
							"Search Level",
						};
						//--------------------------
						// �ݒ�͈͎擾
						double max = pMCC->BND.MD.MinMaxInputD.dv_BgSachLevel.Max;
						double min = pMCC->BND.MD.MinMaxInputD.dv_BgSachLevel.Min;
						//--------------------------
						double level = pMCC->BND.bond.GetLvlSrchLevel(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"mm",level, min, max, 10)){
							DataPut(SachLevel1,level,10);
							pMCC->BND.bond.SetLvlSrchLevel(this->tpcNowIcType, level);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// ����
				//
				case KeyBgLevel		:
					{
						const char *msg[] = {
							"����ݸ� ����",
							"Leveling Level",
						};
						//--------------------------
						// �ݒ�͈͎擾
						double max = pMCC->BND.MD.MinMaxInputD.dv_BgLevel.Max;
						double min = pMCC->BND.MD.MinMaxInputD.dv_BgLevel.Min;
						//--------------------------
						double level = pMCC->BND.bond.GetLvlBgLevel(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"mm",level, min, max, 100)){
							DataPut(BgLevel,level,100);
							pMCC->BND.bond.SetLvlBgLevel(this->tpcNowIcType, level);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// ����Ď���
				//
				case KeyBgFUpTime		:
					{
						const char *msg[] = {
							"����Ď���",
							"Contact Time",
						};
						double time = pMCC->BND.bond.GetLvlBgFUpTime(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"sec",time,0,99.99,100)){
							DataPut(BgFUpTime,time,100);
							pMCC->BND.bond.SetLvlBgFUpTime(this->tpcNowIcType, time);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// ��������
				//
				case KeyBgFDownTime		:
					{
						const char *msg[] = {
							"��������",
							"Pressure Down Time",
						};
						double time = pMCC->BND.bond.GetLvlBgFDownTime(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"sec",time,0,99.99,100)){
							DataPut(BgFDownTime,time,100);
							pMCC->BND.bond.SetLvlBgFDownTime(this->tpcNowIcType, time);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// ���ݽ�߰��
				//
				case KeyRetnSpeed		:
					{
						const char *msg[] = {
							"���ݽ�߰��",
							"Return Speed",
						};
						//--------------------------
						// �ݒ�͈͎擾
						double max = pMCC->BND.MD.MinMaxInputD.dv_BgReturnSpeed.Max;
						double min = pMCC->BND.MD.MinMaxInputD.dv_BgReturnSpeed.Min;
						//--------------------------
						double speed = pMCC->BND.bond.GetLvlRetnSpeed(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"mm/s",speed,min,max,10)){
							DataPut(RetnSpeed,speed,10);
							pMCC->BND.bond.SetLvlRetnSpeed(this->tpcNowIcType, speed);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// ��������
				//
				case KeyRetnLevel		:
					{
						const char *msg[] = {
							"��������",
							"Return Level",
						};
						//--------------------------
						// �ݒ�͈͎擾
						double max = pMCC->BND.MD.MinMaxInputD.dv_BgReturnLevel.Max;
						double min = pMCC->BND.MD.MinMaxInputD.dv_BgReturnLevel.Min;
						//--------------------------
						double level = pMCC->BND.bond.GetLvlRetnLevel(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"mm/s",level, min, max,10)){
							DataPut(RetnLevel,level,10);
							pMCC->BND.bond.SetLvlRetnLevel(this->tpcNowIcType, level);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// ���ݍ��ݗ�
				//
				case KeySinkLevel		:
					{
						const char *msg[] = {
							"���ݍ��ݗ�",
//							"Sink Level",
							"Over travel",
						};
						//--------------------------
						// �ݒ�͈͎擾
						double max = pMCC->BND.MD.MinMaxInputD.dv_BgSinkLevel.Max;
						double min = pMCC->BND.MD.MinMaxInputD.dv_BgSinkLevel.Min;
						//--------------------------
						double level = pMCC->BND.bond.GetLvlSinkLevel(this->tpcNowIcType);
						if (DataEdit(msg[Lang],"mm",level, min, max,100)){
							DataPut(SinkLevel,level,100);
							pMCC->BND.bond.SetLvlSinkLevel(this->tpcNowIcType, level);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
// #YS110322-01 ���i��(�f�[�^�ݒ�)
				case KeyICType1:
				case KeyICType2:
				case KeyICType3:
				case KeyICType4:
					{
						int idx = key - KeyICType1;
						if (pMCC->BND.frame.IcTypeIsValid(idx + 1)) {	// �I�����ꂽictype���o�^����Ă��邩�`�F�b�N
							if (DataUpdate) {
								if(pMCC->MD.OptionF.DeviceDataSaveLater){
									// ���Ƃŕۑ�����B
									this->deviceDataNotSaved	= true;
								}
								Update |= (0x01<<( this->tpcNowIcType-1 ));
								pMCC->BND.bond.DataRW(pMCC->BND.frame.GetRegNumbers(), false, false,pMCC->BND.DD.FName,Update);
								DataUpdate = false;
								Update = 0;
							}
							this->tpcNowIcType = idx + 1;
							Restart = true;
						}
					}
					break;
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyCancel:	// �ް���۰��
					if(DataUpdate){
						DataUpdate = FALSE;
						Restart = TRUE;
					}
					break;
				case KeyTeach:
					End = TRUE;
					r = Teach1_END;	// è��ݸ��߰��1��
					break;
				case KeyData1:
				case KeyData2:
				case KeyData3:
				case KeyData4:
					End = TRUE;
					r = Data1_END+key-KeyData1;	// �ް��ݒ��߰�ނ�
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �ް�����
		if(pMCC->MD.OptionF.DeviceDataSaveLater){
			// ���Ƃŕۑ�����B
			this->deviceDataNotSaved	= true;
		}
		Update |= (0x01<<( this->tpcNowIcType-1 ));
		pMCC->BND.bond.DataRW(pMCC->BND.frame.GetRegNumbers(), false, false,pMCC->BND.DD.FName,Update);
	}
	return	r;
}

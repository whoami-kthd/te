// #MU140707-01
//--------------------------------------------------------------------
//	������ى�ʊ֐��i�i���ް�:Emboss�j
//--------------------------------------------------------------------

#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	"tpc.h"
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_EMBOSS(int step,int page)
{
	int	r=OK_END;
	for (;;) {
		if (step == 0) {
			if (page == 1){
				r = DVd_Emb1();
			}
			else {
				r = Data1_END;
			}
		} else {
			if(page == 1){
//				bool isOn;
				if (/*this->pMCC->ICS.pIcSupp[eRight]->EmbossFeederSnsChk(false) 
					&& ((this->pMCC->ICS.pIcSupp[eRight]->embossFeeder.TapeExistSnsChk(1, isOn) && isOn) || (this->pMCC->ICS.pIcSupp[eRight]->embossFeeder.TapeExistSnsChk(2, isOn) && isOn))*/true) 
				{
					r = DVt_Emb1();
				} else {
					Warn("Emboss tape has not setup.");
					if (r == Teach1_END) {
						r = Data1_END;
					} else {
						r = Prev_END;
					}
				}
			} else {
				r = Teach1_END;
			}
		}

		if (r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		}
		else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}
/////////////////////////////////////////////////////////////////////////////
//----- �ް��ݒ�@�߰��1 Pickup (R�̂�)
int TPCtrl::DVd_Emb1()
{
	enum{
		SNo						= 1035,	// ���No.
		//
		AttEmbON				= 200,	// Enboss�L
		AttEmbOFF				= 201,	// Enboss��
		AttTapeSel1				= 202,	// ð�ߎ��1
		AttTapeSel2				= 203,	// ð�ߎ��2
		AttTapeWidth16			= 205,
		AttTapeWidth24			= 206,
		AttTapeWidth32			= 207,
		// #KI150124-01(S)
		Att2DReadON				= 208,
		Att2DReadOFF			= 209,
		// #KI150124-01(E)
		// Emboss mapping (S)
		AttMappingON			= 210,
		AttMappingOFF			= 211,
		AttTape1Bin				= 214,
		AttTape2Bin				= 216,
		AttMappingEnable		= 501,
		AttMappingBinEnable		= 500,
		AttFaceUp				= 260,
		AttFaceDown				= 261,
		// Emboss mapping (E)
		//
		SearchLevel				= 302,	// �������
		SearchSpeed				= 304,	// �����߰��
		Delay					= 310,	// �ިڲ
		OverTravel				= 312,	// ���ݍ���
		VacOnTiming				= 314,	// �z��ON���ݸ�
		PickupLevel1			= 316,	// �߯��������� Tape1
		PickupLevel2			= 318,	// �߯��������� Tape2
		PickupRetry				= 320,	// �߯�������ײ��
		NumberOfSkip2D			= 322,	// 2D����ߐ�
		UTape1Limit				= 324,	// Tape1�㑤���~�b�g	// #T.Tachi151219-01
		DTape1Limit				= 326,	// Tape1�������~�b�g	// #T.Tachi151219-01
		UTape2Limit				= 328,	// Tape2�㑤���~�b�g	// #T.Tachi151219-01
		DTape2Limit				= 330,	// Tape2�������~�b�g	// #T.Tachi151219-01

		//
		KeyEmbON				= 65,	// Enboss�L
		KeyEmbOFF				= 66,	// Enboss��
		KeyTapeSel1				= 67,	// ð�ߎ��1
		KeyTapeSel2				= 68,	// ð�ߎ��2
		KeySearchLevel			= 70,	// �������
		KeySearchSpeed			= 71,	// �����߰��
		KeyDelay				= 74,	// �ިڲ
		KeyOverTravel			= 75,	// ���ݍ���
		KeyVacOnTiming			= 76,	// �z��ON���ݸ�
		KeyTapeWidth16			= 77,	// ð�ߕ� 16
		KeyTapeWidth24			= 78,	// ð�ߕ� 24
//		KeyTapeWidth32			= 79,	// ð�ߕ� 32
		KeyPickupLevel1			= 80,	// �߯��������� Tape1	// #MU140813-01
		KeyPickupLevel2			= 81,	// �߯��������� Tape2	// #MU140813-01
		KeyPickupRetry			= 82,	// �߯�������ײ��
		// #KI150124-01(S)
		Key2DReadON				= 83,	// 2DReadON
		Key2DReadOFF			= 84,	// 2DReadOFF
		KeyNumberOfSkip2D		= 85,	// 2D���޽���ߐ�

		// Emboss mapping (S)
		KeyMappingON			= 86,
		KeyMappingOFF			= 87,
		KeyTape1Bin				= 88,
		KeyTape2Bin				= 89,
		KeyUTape1Limit			= 90,	// Tape1�㑤���~�b�g	// #T.Tachi151219-01
		KeyDTape1Limit			= 91,	// Tape1�������~�b�g	// #T.Tachi151219-01
		KeyUTape2Limit			= 92,	// Tape2�㑤���~�b�g	// #T.Tachi151219-01
		KeyDTape2Limit			= 93,	// Tape2�������~�b�g	// #T.Tachi151219-01
		KeyFaceUp				= 94,
		KeyFaceDown				= 95,
		// Emboss mapping (E)
		// #KI150124-01(E)
		// �i��I��
		ICTypes					= 100,		// �i��I��(bit0:1 bit1:2 ...)
		Name					= 1200,		// �i�햼
		KeyICType1				= 230,		// IC�i��ԍ��P
		KeyICType2				= 231,		// IC�i��ԍ��Q
		KeyICType3				= 232,		// IC�i��ԍ��R
		KeyICType4				= 233,		// IC�i��ԍ��S										
		//
		KeyHome			= 48	,
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyData1				,
		KeyData2				,
		KeyData3				,
		KeyData4				,
		KeyData5				,
	};
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r = TRUE;
	BOOL	DataUpdate=FALSE;
	int Update = 0;
	int chkSelTape1 = 0;
	int chkSelTape2 = 0;
	int tapeWidthAttr = 0;
	CEmbossFeeder::TAPE_Data* pTapeD	= &pMCC->ICS.icSupply.embossFeeder.TapeD;
	CEmbossFeeder::PD_Data* pPD			= &pMCC->ICS.icSupply.embossFeeder.PD;
	//#DongKD 20140723 Add variable
	CModifiedPickup::s_PickupData* pPickD	= &pMCC->ICS.icSupply.pickup.pickupD;
	CModifiedPickup::s_HeightData* pHeightD		= &pMCC->ICS.icSupply.pickup.HeightD;
////////////////////////////////////
//
// #MU140708-xx:Please Variable Add
// Comment-out portion
// 

	//--------------------------------
	// �����\���l�ݒ�
	//
	tpc.GpPut16(AttEmbON,0);	
	tpc.GpPut16(AttEmbOFF,0);
	tpc.GpPut16(AttTapeSel1,0);	
	tpc.GpPut16(AttTapeSel2,0);
	
	tpc.GpPut16(AttTapeWidth16,0);	
	tpc.GpPut16(AttTapeWidth24,0);	
	tpc.GpPut16(AttTapeWidth32,0);
	// #KI150124-01(S)
	tpc.GpPut16(Att2DReadON,0);	
	tpc.GpPut16(Att2DReadOFF,0);
	// #KI150124-01(E)
	for(;;){

		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// ��ʐ؂�ւ�

		tpc.GpPut16(ICTypes, (0x01<<(this->tpcNowIcType-1)));					// IC�i��I�����
		char *name = "";														//				
		name = pMCC->BND.frame.eachIcName[this->tpcNowIcType-1].GetBuffer(40);	//				
		tpc.GpPutStrLen(Name, name, 40);										// IC�i�햼�\��	
			
		if (pMCC->DD.ModeD.EmbossMode & pMCC->MD.OptionD.EmbossFeeder) {
			tpc.GpPut16(AttEmbON,ATTR_SEL);
		} else {
			tpc.GpPut16(AttEmbOFF,ATTR_SEL);
		}
		// #KI150124-01(S)
		// 2D�R�[�h�n�m�^�n�e�e�I��ǉ�
		if (pMCC->MD.OptionD.has2DCodeReader && pMCC->ICS.icSupply.embossFeeder.TapeD.read2D) {
			tpc.GpPut16(Att2DReadON,ATTR_SEL);
		} else {
			tpc.GpPut16(Att2DReadOFF,ATTR_SEL);
		}
		DataPut(NumberOfSkip2D,	pMCC->ICS.icSupply.embossFeeder.TapeD.numberOfskip2D, 1);
		// #KI150124-01(E)
		switch (pTapeD->tapeWidth) {
		case eTape16:
			tapeWidthAttr = AttTapeWidth16;
			break;
		case eTape24:
			tapeWidthAttr = AttTapeWidth24;
		//	pTapeD->tapeMode &= 0x02;
			break;
		case eTape32:
			tapeWidthAttr = AttTapeWidth32;
		//	pTapeD->tapeMode &= 0x02;
			break;
		default:
			tapeWidthAttr = 0;
			break;
		}
		if (tapeWidthAttr != 0) {
			tpc.GpPut16(tapeWidthAttr, ATTR_SEL);
		}

		//#DongKD 20140725 Choose tape with tapeMode
		if (pTapeD->tapeMode == 0) {
			tpc.GpPut16(AttTapeSel1,0);
			tpc.GpPut16(AttTapeSel2,0);
			chkSelTape1 = 0;
			chkSelTape2 = 0;
		} else if (pTapeD->tapeMode == 1) {
			tpc.GpPut16(AttTapeSel1,ATTR_SEL);
			tpc.GpPut16(AttTapeSel2,0);
			chkSelTape1 = 1;
			chkSelTape2 = 0;
		} else if (pTapeD->tapeMode == 2) {
			tpc.GpPut16(AttTapeSel1,0);
			tpc.GpPut16(AttTapeSel2,ATTR_SEL);
			chkSelTape1 = 0;
			chkSelTape2 = 1;
		} else {
			tpc.GpPut16(AttTapeSel1,ATTR_SEL);
			tpc.GpPut16(AttTapeSel2,ATTR_SEL);
			chkSelTape1 = 1;
			chkSelTape2 = 1;
		}
	
		//#DongKD 20140723 Add variable
		DataPut(SearchLevel,	pPickD->IC[this->tpcNowIcType - 1].searchLevelEmboss, 100);
		DataPut(SearchSpeed,	pPickD->IC[this->tpcNowIcType - 1].searchSpeedEmboss, 10);
		DataPut(Delay,			pPickD->IC[this->tpcNowIcType - 1].vacDelayEmboss, 100);
		DataPut(OverTravel,		pPickD->IC[this->tpcNowIcType - 1].sinkLevelEmboss, 100);
		DataPut(VacOnTiming,	pPickD->IC[this->tpcNowIcType - 1].vacOnTimingEmboss, 100);
		DataPut(PickupLevel1,	pHeightD->IC[this->tpcNowIcType - 1].stdPickupHeightEmboss[0], 100);
		DataPut(PickupLevel2,	pHeightD->IC[this->tpcNowIcType - 1].stdPickupHeightEmboss[1], 100);
		DataPut(PickupRetry,	pPickD->pickupRetryEmboss, 1);
		
		// #T.Tachi151219-01(S)
		DataPut(UTape1Limit,	pHeightD->IC[this->tpcNowIcType - 1].UPickupHeightEmbossLimit[0], 100);
		DataPut(DTape1Limit,	pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[0], 100);
		DataPut(UTape2Limit,	pHeightD->IC[this->tpcNowIcType - 1].UPickupHeightEmbossLimit[1], 100);
		DataPut(DTape2Limit,	pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[1], 100);
		// #T.Tachi151219-01(E)

		// Emboss mapping (S)
		if (pMCC->MD.OptionD.EmbossMappingSys) {
			tpc.GpPut16(AttMappingEnable, 1);
			// Only enable bin setting when mapping mode is off
			if (!pMCC->ICS.icSupply.embossFeeder.TapeD.mappingMode) {
				tpc.GpPut16(AttMappingBinEnable, 1);
				tpc.GpPut16(AttMappingON, 0);
				tpc.GpPut16(AttMappingOFF, 1);
				tpc.GpPutStrLen(AttTape1Bin, pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[0],3);
				tpc.GpPutStrLen(AttTape2Bin, pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[1],3);
			} else {
				tpc.GpPut16(AttMappingBinEnable, 0);
				tpc.GpPut16(AttMappingON, 1);
				tpc.GpPut16(AttMappingOFF, 0);
			}
		} else {
			// Disable display
			tpc.GpPut16(AttMappingEnable, 0);
			tpc.GpPut16(AttMappingBinEnable, 0);
		}
		// Emboss mapping (E)

		// THAIHV 20160316  FaceMode (S)
		if(pMCC->ICS.icSupply.embossFeeder.GetFaceMode()){
			tpc.GpPut16(AttFaceUp, 0);
			tpc.GpPut16(AttFaceDown, 1);
		}else {
			tpc.GpPut16(AttFaceUp, 1);
			tpc.GpPut16(AttFaceDown, 0);
		}
		// THAIHV 20160316  FaceMode (E)
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			// �z�X�g�ɂ���ă��b�N����Ă���ꍇ�́A�J�ڃ{�^���ȊO�͖����ɂ���B
			if(this->IsLockedByHost(key)){
				continue;
			}
			if(key)	tpc.GpBeep();
			switch(key){
				case KeyFaceUp:
					pMCC->ICS.SetFaceMode(0);
		//			pMCC->ICS.icSupply.embossFeeder.TapeD.isFaceUp = 0;
					tpc.GpPut16(AttFaceUp,1);
					tpc.GpPut16(AttFaceDown,0);
					DataUpdate = TRUE;
					break;
				case KeyFaceDown:
					pMCC->ICS.SetFaceMode(1);
			//		pMCC->ICS.icSupply.embossFeeder.TapeD.isFaceUp = 1;
					tpc.GpPut16(AttFaceUp, 0);
					tpc.GpPut16(AttFaceDown, 1);
					DataUpdate = TRUE;
					break;
				case KeyEmbON:
					pMCC->DD.ModeD.EmbossMode = 1;
					pMCC->SetEmbossMode(pMCC->MD.OptionD.EmbossFeeder && pMCC->DD.ModeD.EmbossMode);
					// #DucMV 20160415 Emboss function (S) 
					// setup Emboss Bin Mode data when Emboss mode change
					pMCC->BND.SetEmbossBinMode(pMCC->MD.OptionD.EmbossFeeder && pMCC->DD.ModeD.EmbossMode && pMCC->MD.OptionD.EmbossMappingSys);
					pMCC->ICS.icSupply.SetEmbossBinMode(pMCC->MD.OptionD.EmbossFeeder && pMCC->DD.ModeD.EmbossMode && pMCC->MD.OptionD.EmbossMappingSys);
					// #DucMV 20160415 Emboss function (E)
					tpc.GpPut16(AttEmbON,ATTR_SEL);
					tpc.GpPut16(AttEmbOFF,0);
					DataUpdate = TRUE;
					break;
				case KeyEmbOFF:
					pMCC->DD.ModeD.EmbossMode = 0;
					pMCC->SetEmbossMode(pMCC->MD.OptionD.EmbossFeeder && pMCC->DD.ModeD.EmbossMode);
					// #DucMV 20160415 Emboss function (S)
					pMCC->BND.SetEmbossBinMode(pMCC->MD.OptionD.EmbossFeeder && pMCC->DD.ModeD.EmbossMode && pMCC->MD.OptionD.EmbossMappingSys);
					pMCC->ICS.icSupply.SetEmbossBinMode(pMCC->MD.OptionD.EmbossFeeder && pMCC->DD.ModeD.EmbossMode && pMCC->MD.OptionD.EmbossMappingSys);
					// #DucMV 20160415 Emboss function (E)
					tpc.GpPut16(AttEmbOFF,ATTR_SEL);
					tpc.GpPut16(AttEmbON,0);
					DataUpdate = TRUE;
					break;
				case KeyTapeSel1:
					{
						// Check tape width
						const char* msg_tape[] = {
							"�e�[�v���̂��߃e�[�v1���I���ł��܂���B",
							"Tape width is 24�o or 32�o.Cannot setup.",
						};
	//					if (pTapeD->tapeWidth == eTape24 || pTapeD->tapeWidth == eTape32) {
	//						Warn(msg_tape[Lang]);
	//						break;
	//					}
						if (chkSelTape1 == 0) {
							tpc.GpPut16(AttTapeSel1,ATTR_SEL);
							chkSelTape1 = 1;
						} else {
							tpc.GpPut16(AttTapeSel1,0);
							chkSelTape1 = 0;
							if(chkSelTape2 == 0){
								tpc.GpPut16(AttTapeSel2,1);
								chkSelTape2 = 1;
							}
						}
						// #KI151219-02(S)
						if(chkSelTape1 == 0 && chkSelTape2 == 0) {
							pTapeD->tapeMode = 0;
						} else if (chkSelTape1 == 1 && chkSelTape2 == 0) {
							pTapeD->tapeMode = 1;
							pPD->currentTape	= 1;
						} else if (chkSelTape1 == 0 && chkSelTape2 == 1) {
							pTapeD->tapeMode = 2;
							pPD->currentTape	= 2;
						} else if (chkSelTape1 == 1 && chkSelTape2 == 1) {
							pTapeD->tapeMode = 3;
						}
						// #KI151219-02(E)
//						Restart = TRUE;
						DataUpdate = TRUE;
						break;
					}
				case KeyTapeSel2:
					{
						if (chkSelTape2 == 0) {
							tpc.GpPut16(AttTapeSel2,ATTR_SEL);
							chkSelTape2 = 1;
						} else {
							tpc.GpPut16(AttTapeSel2,0);
							chkSelTape2 = 0;
							if(chkSelTape1 == 0){
								tpc.GpPut16(AttTapeSel1,1);
								chkSelTape1 = 1;
							}
						}
						// #KI151219-02(S)
						if(chkSelTape1 == 0 && chkSelTape2 == 0) {
							pTapeD->tapeMode = 0;
						} else if (chkSelTape1 == 1 && chkSelTape2 == 0) {
							pTapeD->tapeMode = 1;
							pPD->currentTape	= 1;
						} else if (chkSelTape1 == 0 && chkSelTape2 == 1) {
							pPD->currentTape	= 2;
						} else if (chkSelTape1 == 1 && chkSelTape2 == 1) {
							pTapeD->tapeMode = 3;
						}
						// #KI151219-02(E)
//						Restart = TRUE;
						DataUpdate = TRUE;
						break;
					}
				case KeySearchLevel:
					{
						const char* msg[] = {
							"�������",
							"Search Level",
						};
						//#DongKD 20140723 Add variable
						double searchLevel = pPickD->IC[this->tpcNowIcType - 1].searchLevelEmboss;
						if (DataEdit(msg[Lang], "mm", searchLevel, 0.0, 2.0, 100)) {
							DataPut(SearchLevel, searchLevel, 100);
					//		pPickD->IC[this->tpcNowIcType - 1].searchLevelEmboss = searchLevel;
							pPickD->IC[this->tpcNowIcType - 1].searchLevelEmboss = searchLevel;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeySearchSpeed:
					{
						const char* msg[] = {
							"�����߰��",
							"Search Speed",
						};
						//#DongKD 20140723 Add variable
						double searchSpeed = pPickD->IC[this->tpcNowIcType - 1].searchSpeedEmboss;
						if (DataEdit(msg[Lang], "mm/s", searchSpeed, 0.1, 20.0, 10)) {
							DataPut(SearchSpeed, searchSpeed, 10);
					//		pPickD->IC[this->tpcNowIcType - 1].searchSpeedEmboss = searchSpeed;
							pPickD->IC[this->tpcNowIcType - 1].searchSpeedEmboss = searchSpeed;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyTapeWidth16:
				case KeyTapeWidth24:
		//		case KeyTapeWidth32:
					{
						int attr = key - KeyTapeWidth16 + AttTapeWidth16;
						if (attr != tapeWidthAttr) {
							tpc.GpPut16(tapeWidthAttr, 0);
							tapeWidthAttr = attr;
							tpc.GpPut16(tapeWidthAttr, ATTR_SEL);
						}
						pTapeD->tapeWidth = 8 * (key - KeyTapeWidth16) + eTape16;
						Restart = TRUE;
						DataUpdate = TRUE;
					}
					break;
				
				case KeyDelay:
					{
						const char* msg[] = {
							"�ިڲ",
							"Delay",
						};
						//#DongKD 20140723 Add variable
						double delay = pPickD->IC[this->tpcNowIcType - 1].vacDelayEmboss;
						if (DataEdit(msg[Lang], "sec", delay, 0.0, 9.99, 100)) {
							DataPut(Delay, delay, 100);
				//			pPickD->IC[this->tpcNowIcType - 1].vacDelayEmboss = delay;
							pPickD->IC[this->tpcNowIcType - 1].vacDelayEmboss = delay;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyOverTravel:
					{
						const char* msg[] = {
							"���ݍ��ݗ�",
							"Over Travel",
						};
						//#DongKD 20140723 Add variable
						double overTravel = pPickD->IC[this->tpcNowIcType - 1].sinkLevelEmboss;
						if (DataEdit(msg[Lang], "mm", overTravel, -0.2, 1.0, 100)) {
							DataPut(OverTravel, overTravel, 100);
			//				pPickD->IC[this->tpcNowIcType - 1].sinkLevelEmboss = overTravel;
							pPickD->IC[this->tpcNowIcType - 1].sinkLevelEmboss = overTravel;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyVacOnTiming:
					{
						const char* msg[] = {
							"�ިڲ",
							"Vacuum On Timing",
						};
						//#DongKD 20140723 Add variable
						double vacOnTiming = pPickD->IC[this->tpcNowIcType - 1].vacOnTimingEmboss;
						if (DataEdit(msg[Lang], "sec", vacOnTiming, -9.99, 9.99, 100)) {
							DataPut(VacOnTiming, vacOnTiming, 100);
				//			pPickD->IC[this->tpcNowIcType - 1].vacOnTimingEmboss = vacOnTiming;
							pPickD->IC[this->tpcNowIcType - 1].vacOnTimingEmboss = vacOnTiming;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyPickupLevel1:
					{
						const char* msg[] = {
							"Tape1 �߯���������",
							"Tape1 Pickup Level",
						};
						double pickupLevel = pHeightD->IC[this->tpcNowIcType - 1].stdPickupHeightEmboss[0];
						double min = 0.0;
						double max = 76.0;
						if (DataEdit(msg[Lang], "mm", pickupLevel, min, max, 100)) {
							DataPut(PickupLevel1, pickupLevel, 100);
//							pHeightD->IC[this->tpcNowIcType - 1].stdPickupHeightEmboss[0] = pickupLevel;
							pHeightD->IC[this->tpcNowIcType - 1].stdPickupHeightEmboss[0] = pickupLevel;
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyPickupLevel2:
					{
						const char* msg[] = {
							"Tape2 �߯���������",
							"Tape2 Pickup Level",
						};
						double pickupLevel = pHeightD->IC[this->tpcNowIcType - 1].stdPickupHeightEmboss[1];
						double min = 0.0;
						double max = 76.0;
						if (DataEdit(msg[Lang], "mm", pickupLevel, min, max, 100)) {
							DataPut(PickupLevel2, pickupLevel, 100);
//							pHeightD->IC[this->tpcNowIcType - 1].stdPickupHeightEmboss[1] = pickupLevel;
							pHeightD->IC[this->tpcNowIcType - 1].stdPickupHeightEmboss[1] = pickupLevel;
							DataUpdate = TRUE;
						}
					}
					break;
				// #T.Tachi151219-01(S)
				case KeyUTape1Limit:
					{
						const char* msg[] = {
							"Tape1 �߯��������ُ㑤���~�b�g",
							"Tape1 Pickup Level Upper Limit",
						};
						double UPickupHeightEmbossLimit = pHeightD->IC[this->tpcNowIcType - 1].UPickupHeightEmbossLimit[0];
						double min = 0.0;
						double max = 76.5;
						if (DataEdit(msg[Lang], "mm", UPickupHeightEmbossLimit, min, max, 100)) {
							DataPut(UTape1Limit, UPickupHeightEmbossLimit, 100);
							pHeightD->IC[this->tpcNowIcType - 1].UPickupHeightEmbossLimit[0] = UPickupHeightEmbossLimit;
							DataUpdate = TRUE;
						}
					}
// #OZ20160418-09 [�ڐA]EmbossTape�߯��������ُ㉺���Я� (S)
					{
						const char* msg[] = {
							"Tape1 �߯��������ى������~�b�g",
							"Tape1 Pickup Level Lower Limit",
						};
						double DPickupHeightEmbossLimit = pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[0];
						double min = 0.0;
						double max = 76.5;
						if (DataEdit(msg[Lang], "mm", DPickupHeightEmbossLimit, min, max, 100)) {
							DataPut(DTape1Limit, DPickupHeightEmbossLimit, 100);
							pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[0] = DPickupHeightEmbossLimit;
							DataUpdate = TRUE;
						}
					}
// #OZ20160418-09 [�ڐA]EmbossTape�߯��������ُ㉺���Я� (E)
					break;	
				case KeyDTape1Limit:
					{
						const char* msg[] = {
							"Tape1 �߯��������ى������~�b�g",
							"Tape1 Pickup Level Lower Limit",
						};
						double DPickupHeightEmbossLimit = pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[0];
						double min = 0.0;
						double max = 76.5;
						if (DataEdit(msg[Lang], "mm", DPickupHeightEmbossLimit, min, max, 100)) {
							DataPut(DTape1Limit, DPickupHeightEmbossLimit, 100);
							pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[0] = DPickupHeightEmbossLimit;
							DataUpdate = TRUE;
						}
					}
					break;	
				case KeyUTape2Limit:
					{
						const char* msg[] = {
							"Tape2 �߯��������ُ㑤���~�b�g",
							"Tape2 Pickup Level Upper Limit",
						};
						double UPickupHeightEmbossLimit = pHeightD->IC[this->tpcNowIcType - 1].UPickupHeightEmbossLimit[1];
						double min = 0.0;
						double max = 76.5;
						if (DataEdit(msg[Lang], "mm", UPickupHeightEmbossLimit, min, max, 100)) {
							DataPut(UTape2Limit, UPickupHeightEmbossLimit, 100);
							pHeightD->IC[this->tpcNowIcType - 1].UPickupHeightEmbossLimit[1] = UPickupHeightEmbossLimit;
							DataUpdate = TRUE;
						}
					}
// #OZ20160418-09 [�ڐA]EmbossTape�߯��������ُ㉺���Я� (S)
					{
						const char* msg[] = {
							"Tape2 �߯��������ى������~�b�g",
							"Tape2 Pickup Level Lower Limit",
						};
						double DPickupHeightEmbossLimit = pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[1];
						double min = 0.0;
						double max = 76.5;
						if (DataEdit(msg[Lang], "mm", DPickupHeightEmbossLimit, min, max, 100)) {
							DataPut(DTape2Limit, DPickupHeightEmbossLimit, 100);
							pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[1] = DPickupHeightEmbossLimit;
							DataUpdate = TRUE;
						}
					}
// #OZ20160418-09 [�ڐA]EmbossTape�߯��������ُ㉺���Я� (E)
					break;	
				case KeyDTape2Limit:
					{
						const char* msg[] = {
							"Tape2 �߯��������ى������~�b�g",
							"Tape2 Pickup Level Lower Limit",
						};
						double DPickupHeightEmbossLimit = pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[1];
						double min = 0.0;
						double max = 76.5;
						if (DataEdit(msg[Lang], "mm", DPickupHeightEmbossLimit, min, max, 100)) {
							DataPut(DTape2Limit, DPickupHeightEmbossLimit, 100);
							pHeightD->IC[this->tpcNowIcType - 1].DPickupHeightEmbossLimit[1] = DPickupHeightEmbossLimit;
							DataUpdate = TRUE;
						}
					}
					break;	
				// #T.Tachi151219-01(E)
				case KeyPickupRetry:
					{
						const char* msg[] = {
							"�߯�������ײ��",
							"Pickup Retry",
						};
						int pickupRetry = pPickD->pickupRetryEmboss;
						int min = 0;
						int max = 999;
						if (DataEdit(msg[Lang], "", pickupRetry, min, max, 1)) {
							DataPut(PickupRetry, pickupRetry, 1);
//							pPickD->pickupRetryEmboss = pickupRetry;
							pPickD->pickupRetryEmboss = pickupRetry;
							DataUpdate = TRUE;
						}
					}
					break;
				// #KI150124-01(S)
				// 2D�R�[�h�n�m�ǉ�
				case Key2DReadON:
					if(pMCC->MD.OptionD.has2DCodeReader){
						pMCC->ICS.icSupply.embossFeeder.TapeD.read2D	= 1;
						tpc.GpPut16(Att2DReadON,ATTR_SEL);
						tpc.GpPut16(Att2DReadOFF,0);
						DataUpdate = TRUE;
					}
					break;
				// 2D�R�[�h�n�m�ǉ�
				case Key2DReadOFF:
					pMCC->ICS.icSupply.embossFeeder.TapeD.read2D	= 0;
					tpc.GpPut16(Att2DReadOFF,ATTR_SEL);
					tpc.GpPut16(Att2DReadON,0);
					DataUpdate = TRUE;
					break;
				// 2D�R�[�h�X�L�b�v�񐔒ǉ�
				case KeyNumberOfSkip2D:
					{
						const char* msg[] = {
							"Number of Skip 2D",
							"Number of Skip 2D",
						};
						int numberOfSkip = pMCC->ICS.icSupply.embossFeeder.TapeD.numberOfskip2D;
						int min = 0;
						int max = 999;
						if (DataEdit(msg[Lang], "", numberOfSkip, min, max, 1)) {
							DataPut(NumberOfSkip2D, numberOfSkip, 1);
							pMCC->ICS.icSupply.embossFeeder.TapeD.numberOfskip2D = numberOfSkip;
							DataUpdate = TRUE;
						}
					}
					break;
				// #KI150124-01(E)
				// ���i��(�f�[�^�ݒ�)																
				case KeyICType1:
				case KeyICType2:
				case KeyICType3:
				case KeyICType4:
					{
						int idx = key - KeyICType1;
						if (pMCC->BND.frame.IcTypeIsValid(idx + 1)) {	// �I�����ꂽictype���o�^����Ă��邩�`�F�b�N
							if (DataUpdate) {
								if(pMCC->MD.OptionF.DeviceDataSaveLater){
									// ���Ƃŕۑ�����B
									this->deviceDataNotSaved	= true;
								}
								Update |= (0x01<<( this->tpcNowIcType-1 ));
								pMCC->ICS.icSupply.wfSupply.WLoadD.DataRW(FALSE, pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec);		//	�m�F�v	12/10/26 N.Goto
								pMCC->ICS.icSupply.wfSupply.WLoadD.DataRW(FALSE, pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec);		//	�m�F�v	12/10/26 N.Goto
								DataUpdate = false;
								Update = 0;
							}
							this->tpcNowIcType = idx + 1;
							Restart = true;
						}
					}
					break;																				//							add 12/10/26 N.Goto ��
				//
				case KeyMappingON:
					{
						pMCC->ICS.icSupply.embossFeeder.TapeD.mappingMode = 1;
						DataUpdate = TRUE;
						Restart = true;
					}
					break;
				case KeyMappingOFF:
					{
						pMCC->ICS.icSupply.embossFeeder.TapeD.mappingMode = 0;
						DataUpdate = TRUE;
						Restart = true;
					}
					break;
				case KeyTape1Bin:
				case KeyTape2Bin:
					{
						const char* msg[] = {
							"Tape %d bin",
							"Tape %d bin",
						};
						CString title;
						// #KI151109-01(S)
						char name[41];
						name[41] = 0;
						CString topCat = (key == KeyTape1Bin) ? pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[0] : 
															pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[1];
						strncpy(name,  (LPCTSTR)topCat, 4);
						title.Format(msg[Lang], key - KeyTape1Bin + 1);
						if (DataEdit(title, name)) {
							tpc.GpPutStrLen((key == KeyTape1Bin) ? AttTape1Bin : AttTape2Bin, name, 3);
							if (key == KeyTape1Bin) {
								pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[0] = name;
								pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[0].TrimRight();
								// #KI151114-02
								pMCC->BND.frame.SetTopCategoryEmboss(eTape1, pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[0]);
							} else {
								pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[1] = name;
								pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[1].TrimRight();
								pMCC->BND.frame.SetTopCategoryEmboss(eTape2, pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[1]);
							}
							pMCC->ICS.icSupply.embossFeeder.TapeD.GoodCode = pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[0] 
																					+ pMCC->ICS.icSupply.embossFeeder.TapeD.tapeBin[1];

							DataUpdate = TRUE;
						}
						Restart = true;
						// #KI151109-01(E)
					}
					break;
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyTeach:
					End = TRUE;
					r = Teach1_END;	// è��ݸ��߰��1��
					break;
				case KeyData1: End = TRUE; r = Data1_END; break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	/////////////////////////
	//
	if(DataUpdate) {	// �ް�����
		if(chkSelTape1 == 0 && chkSelTape2 == 0) {
			pTapeD->tapeMode = 0;
		} else if (chkSelTape1 == 1 && chkSelTape2 == 0) {
			pTapeD->tapeMode = 1;
			pPD->currentTape	= 1;
		} else if (chkSelTape1 == 0 && chkSelTape2 == 1) {
			pTapeD->tapeMode = 2;
			pPD->currentTape	= 2;
		} else if (chkSelTape1 == 1 && chkSelTape2 == 1) {
			pTapeD->tapeMode = 3;
			pPD->currentTape	= 1;
		}
		if(pMCC->MD.OptionF.DeviceDataSaveLater){
			// ���Ƃŕۑ�����B
			this->deviceDataNotSaved	= true;
		}
//		pMCC->ICS.pIcSupp[eLeft]->embossFeeder.DvDataRW(FALSE, pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec);
		pMCC->ICS.icSupply.embossFeeder.DvDataRW(FALSE, pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec);
		//#DongKD 20140723 Add variable
		// Write current tape (KeyTapeSel1, KeyTapeSel2)
//		pMCC->ICS.pIcSupp[eLeft]->embossFeeder.ProDataRW(FALSE, pMCC->ICS.PD.FName, pMCC->ICS.PD.Sec);
		pMCC->ICS.icSupply.embossFeeder.ProDataRW(FALSE, pMCC->ICS.PD.FName, pMCC->ICS.PD.Sec);
		// Write values of pick up unit
		// ���ʃp���������̂ŁA�Z�b�g���Ȃ��Ƃ����Ȃ��H
	//	pMCC->ICS.pIcSupp[eLeft]->pickup.DvPicDataRW(FALSE,	pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec,Update);
		pMCC->ICS.icSupply.pickup.DvPicDataRW(FALSE, pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec,Update);
//		pMCC->MD.OptionD.DataRW(false, pMCC->MD.FName);
		pMCC->DD.ModeD.DataRW(FALSE,pMCC->DD.FName);	// �ް�����
	} 
	return	r;
}

////////////////////////////////////////////////////////////////////////////////////////////
//----- è��ݸށ@�߰��1 Pickup Height (R�̂�)
int TPCtrl::DVt_Emb1()
{
	enum{
		SNo					= 1036,	// ���No.
		//
		Msg					= 160	,	// ү���ޕ\��������
		//
		KeyTapeSel1			= 46	,	// ð�ߎ��1
		KeyTapeSel2			= 47	,	// ð�ߎ��2
		KeyEnter			= 65	,	// �o�^���s
		KeyCancel			= 66	,	// ��ݾ�
		KeyMove				= 70	,	// �ݒ�l�ړ�
		//
		AttTapeSel			= 99	,	// ð�ߎ�ޑI���i0:1�@1:2�j
		AttEnter			= 200	,	// �o�^���s
		AttCancel			= 201	,	// ��ݾ�
		AttWfSel			= 202	,	// è��ݸޑI���i0:��ʻ��ށ@1:IC���ށA�߯��j
		AttMove				= 205	,	// �ݒ�l�ړ�
		AttTouchSns			= 213	,	// ����ݻON/OFF
		// �i��I��
		ICTypes				= 100,		// �i��I��(bit0:1 bit1:2 ...)
		Name				= 1200,		// �i�햼
		KeyICType1			= 230,		// IC�i��ԍ��P
		KeyICType2			= 231,		// IC�i��ԍ��Q
		KeyICType3			= 232,		// IC�i��ԍ��R
		KeyICType4			= 233,		// IC�i��ԍ��S										
		//
		KeyHome				= '0'	,
		KeyPrev						,
		KeyTeach					,
		KeyData						,
		KeyTeach1					,
		KeyTeach2					,
		KeyTeach3					,
		KeyTeach4					,
		KeyTeach5					,
		//
//		maxStep				= 5		,
		//#DongKD 20140724	Excute steps for teaching
		maxStep				= 2		,
	};
	int		r = Prev_END;	// Return�l
	int		Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;	// �\������Ӱ�ސݒ�
	int		recerr = 0;
	int		Update = 0;
	CEmbossFeeder::TAPE_Data* pTapeD	= &pMCC->ICS.icSupply.embossFeeder.TapeD;
//	CEmbossFeeder::TAPE_Data* pTapeD_R= &pMCC->ICS.icSupply.embossFeeder.TapeD;

	//#DongKD 20140724	Excute steps for teaching
	const char*	Emsg[maxStep] =
		//	 1234567890123456789012345678901234567890
		{	"[�o�^���s] �������Ă��������B          ",
			"1/1 IC�߯�����-�G���{�X�e�[�v�Ԃ��������肵�܂�    ",
		};
	const char*	EmsgEng[maxStep] =	
		//	 1234567890123456789012345678901234567890
		{	"Please press [Set-up / Done]           ",
			"1/1 Auto Measure IC pick-up to Emboss.   ",
		};

	int		selTapeID = pMCC->ICS.icSupply.embossFeeder.PD.currentTape;	// 1: tape 1, 2: tape 2
//	bool	isOn;
//	if (this->pMCC->ICS.pIcSupp[eRight]->embossFeeder.TapeExistSnsChk(1, isOn) && isOn) {
//		selTapeID = 1;
//	} else if (this->pMCC->ICS.pIcSupp[eRight]->embossFeeder.TapeExistSnsChk(2, isOn) && isOn) {
//		selTapeID = 2;
//	}

	// Set temporary emboss mode
	int savedEmbossMode = pMCC->GetEmbossMode();
	pMCC->SetEmbossMode(1);
	int faceMode = pMCC->ICS.icSupply.GetProcessMode();
	// Preciser escape
//	pMCC->BND.FaceModeInit(faceMode);	//#TienBV 20160419
	bool bInitOneTime  = true;			//#TienBV 20160419
	BOOL DataUpdate = FALSE;
	// �J�����ؑ�
	pMCC->CameraSelect(BCCamNo);
	// �Ɩ��I��
	pMCC->BND.LightSelect(BCCamNo, BNDCtrl::WfSize_LightLevel);		// ��J�����A��F���ʒu�Ɠ����ײ�����
	BackGroundThread(true, eCmdEmbossT);	// ��ԕ\���گ�ނ��N������B
	for (;;) {
////////////////////////////////////
//
// #MU140708-xx:Please Variable Add
// Comment-out portion
// 
		BOOL End = FALSE;
		int ECnt = 0;											// è��ݸލ�ƶ����i�ï�ߐ��j
		tpc.GpScreenDisp(SNo);									// ��ʐ؂�ւ�
		tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[ECnt] : Emsg[ECnt], 40);				// ү���ޕ\��
		tpc.GpPut16(ICTypes, (0x01<<(this->tpcNowIcType-1)));					// IC�i��I�����
		char *name = "";														//				
		name = pMCC->BND.frame.eachIcName[this->tpcNowIcType-1].GetBuffer(40);	//				
		tpc.GpPutStrLen(Name, name, 40);										// IC�i�햼�\��	
		tpc.GpPut16(AttEnter		,0);	// 
		tpc.GpPut16(AttCancel		,0);	// 
		tpc.GpPut16(AttWfSel		,0);	// 
		tpc.GpPut16(AttMove			,0);	// 
		tpc.GpPut16(AttTapeSel		,0);	// 
		
		if (selTapeID == 1) {
			tpc.GpPut16(AttTapeSel		,ATTR_B00);	// ð�ߎ��1
		} else {
			tpc.GpPut16(AttTapeSel		,ATTR_B01);	// ð�ߎ��2
		}

		for (;;) {
			BOOL Restart = FALSE;
			// ��ʕ\����ԍX�V
			bool On;
			//#DongKD 20140729	check pick touch sensor
			if (pMCC->ICS.icSupply.pickup.GetPickupTouchSns(On)) {
				tpc.GpPut16(AttTouchSns, (!On) ? ATTR_S0 : ATTR_S1);
			}
			int Axis_Sw;
			
			Axis_Sw = (pMCC->ICS.MtSel(ICSCtrl::SXI)|pMCC->ICS.MtSel(ICSCtrl::SYI)|pMCC->ICS.MtSel(ICSCtrl::STI));
			
			int	key = KeyWait_Adjust_ICS(Axis_Sw);	//�@��ެ�ċ@�\�t��������(�쓮�Ώێ��̎w��͓����ōs��
			if(key)	tpc.GpBeep();
			//------------- �w�o�^���s�x���� --------------
			if(key == KeyEnter){				// �o�^���s
				//#TienBV 20160419 (S)
				if (ECnt == 0 && bInitOneTime  == true) {
					pMCC->BND.FaceModeInit(faceMode);
					bInitOneTime  = false;
				}
				//#TienBV 20160419 (E)
				MCC_Action_Call	A(pMCC);		// ����J�n���w��	�޽�׸��ŏI�����w��
				//////////////////////////////////////////////////////////////////////////////////////////////////////////
				//
				// PickZTeach_Emboss �e�B�[�`���O
				//
				if(r && pMCC->ICS.icSupply.PickZTeach_Emboss(ECnt, this->tpcNowIcType, selTapeID)){		// è��ݸ
					ECnt ++ ;			// è��ݸލ�ƶ������Z

					if (ECnt >= maxStep) {		// �I��
						tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
						ECnt = 0;
						DataUpdate = FALSE;
						if(pMCC->MD.OptionF.DeviceDataSaveLater){
							// ���Ƃŕۑ�����B
							this->deviceDataNotSaved	= true;
						}
//						pMCC->ICS.pIcSupp[eLeft]->pickup.DvDataRW(FALSE,pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec,Update);		//
						pMCC->ICS.icSupply.pickup.DvDataRW(FALSE,pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec,Update);
						Restart = TRUE;
					} else {
						DataUpdate = TRUE;
						tpc.GpPut16(AttEnter	,ATTR_SEL);		// �o�^���s�@�I�����
						CString teachingMsg = "";
						teachingMsg.Format(Lang ? EmsgEng[ECnt] : Emsg[ECnt], ECnt, maxStep);
						tpc.GpPutStrLen(Msg, teachingMsg, 40);	// ү���ޕ\��
					}
				}
			}
			//---------- �w�ݒ�l�ړ��x���� ----------
			else if (key == KeyMove && ( ECnt >= 1)) {
				MCC_Action_Call	A(pMCC);
				tpc.GpPut16(AttMove	,ATTR_SEL);			// �I�����
				if(ECnt == 1) {
					//#DongKD 20140725	Add set up point movement
					double posZPrev = pMCC->ICS.pPickup->GetPickupHeightEmboss(this->tpcNowIcType, selTapeID);
					r = pMCC->ICS.icSupply.pickup.PickUpMoveAbs1(PickUpUnit::IDX_PCKZ, posZPrev, true);
				}
				tpc.GpPut16(AttMove	,0);				// ��I�����
			}
			//---------- �w�L�����Z���x���� ----------
			else if (key == KeyCancel) {
				tpc.GpPut16(AttEnter	,0);	// �o�^���s�@��I�����
				if(DataUpdate) {
					BOOL ret = TRUE/*pMCC->BND.������(-1, tpc.select_side)*/;	// ��ݾ�	//##M.Iga chg 12/11/17
//					pMCC->ICS.pIcSupp[eLeft]->pickup.DvDataRW(FALSE,pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec,Update);		//
					pMCC->ICS.icSupply.pickup.DvDataRW(FALSE,pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec,Update);

					tpc.GpPutStrLen(Msg,(Lang) ? EmsgEng[0] : Emsg[0],40);			// ү���ޕ\��
					ECnt = 0;
				}
				DataUpdate = FALSE;
				Restart = TRUE;
			}
			else if ((ECnt == 0)&&(key >= KeyICType1)&&(key <= KeyICType4)){	// �o�^���s���ł͂Ȃ�
				int idx = key - KeyICType1;
				if (pMCC->BND.frame.IcTypeIsValid(idx + 1)) {	// �I�����ꂽictype���o�^����Ă��邩�`�F�b�N
					if (DataUpdate) {
						if(pMCC->MD.OptionF.DeviceDataSaveLater){
							// ���Ƃŕۑ�����B
							this->deviceDataNotSaved	= true;
						}
						Update |= (0x01<<( this->tpcNowIcType-1 ));
						pMCC->ICS.icSupply.pickup.DvDataRW(FALSE,pMCC->ICS.DD.FName, pMCC->ICS.DD.Sec,Update);	//			chg 12/10/26 N.Goto
						DataUpdate = false;
						Update = 0;
					}
					this->tpcNowIcType = idx + 1;
					Restart = true;
				}
			}
			//---------- �w �o�^���s���ł͂Ȃ��x���� ----------
			else if(ECnt == 0) {	// �o�^���s���ł͂Ȃ�
				if (key == KeyPrev) {
					End = TRUE;
					r = Prev_END;
				} else if (key == KeyHome) {
					End = TRUE;
					r = Home_END;
				} else if (key == KeyData) {
					End = TRUE;
					r = Data2_END;	// �ް��ݒ��߰��2��
				} else if (key == KeyTeach1) {
					End = TRUE;
					r = Teach1_END;	// è��ݸ��߰��1��
				} else if(key == KeyTapeSel1 && selTapeID != 1){
//					if (/*this->pMCC->ICS.pIcSupp[eRight]->embossFeeder.TapeExistSnsChk(1, isOn) && isOn*/true) {
					if (/*pMCC->ICS.icSupply.embossFeeder.TapeD.tapeWidth == eTape16*/true) {
						selTapeID = 1;
						Restart = TRUE;
//					} else {
//						Warn("Emboss tape 1 has not setup");
					}
				} else if(key == KeyTapeSel2 && selTapeID != 2){		
					if (/*this->pMCC->ICS.pIcSupp[eRight]->embossFeeder.TapeExistSnsChk(2, isOn) && isOn*/true) {
						selTapeID = 2;
						Restart = TRUE;	
//					} else {
//						Warn("Emboss tape 2 has not setup");
					}
				}
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	BackGroundThread(false, eCmdEmbossT);	// ��ԕ\���گ�ނ��N������B
	// Return current emboss mode
	pMCC->SetEmbossMode(savedEmbossMode);
	faceMode = pMCC->ICS.icSupply.GetProcessMode();
	// Preciser escape
	pMCC->BND.FaceModeInit(faceMode);
	return	r;
}


int TPCtrl::Mct_BackGroundEmbossT()
{
	enum{
		AttTouchSns		= 213,	// 										
	};
	int	r = TRUE;
	CSingleLock lock(&EvBackGroundFinishReq, false);	// �����ł̓X���[
	tpc.GpPut16(AttTouchSns,	0);	
	bool On;
	for(;;){
		if (pMCC->ICS.icSupply.pickup.GetPickupTouchSns(On)) {
			tpc.GpPut16(AttTouchSns, (!On) ? ATTR_S0 : ATTR_S1);
		}

		if(lock.Lock(1)){
			// ��ʂ���̏I���v��������
			EvBackGEnd.ResetEvent();
			// �펞�Ď��𔲂��Ċ���
			break;
		}else{
			// 0.2�b�Q��B
			::Sleep(200);
		}
	}
	return r;
}
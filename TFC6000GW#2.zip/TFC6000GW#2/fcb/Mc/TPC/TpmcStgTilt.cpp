/*---------------------------------------------------------------------
	�^�b�`�p�l����ʊ֐��i�}�V���f�[�^:�X�e�[�W�`���g�j
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
// �X�e�[�W�`���g
//
int TPCtrl::MC_StgTilt(int step,int page)
{
	int	r=OK_END;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	for(;;){
		/////////////////////////
		// �f�[�^�ݒ�
		if(step == 0){
			if(page == 1)			{r = MCd_StgTilt1();}
				else				{r = Data1_END;}
		}
		/////////////////////////
		// �e�B�[�`���O
		else {
									r = Prev_END;
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}
////////////////////////////////////////////////////////////
// �y�[�W�P �X�e�[�W�`���g�Z�b�e�B���O�@�f�[�^�ݒ�
//
int TPCtrl::MCd_StgTilt1(){
	enum{
		SNo			= 2400,					// ���No.
		//
		KeyHdmeasureHdPosZ		= 90,		// �w�b�h���莞�̃w�b�h�y�ʒu
		//
		HdmeasureHdPosZ			= 344,		// �w�b�h���莞�̃w�b�h�y�ʒu
// #MU140331-01
		KeyHeadTiltLimitX		= 65,		// �w�b�hX�����X�����E�l
		KeyHeadTiltLimitY		= 66,		// �w�b�hY�����X�����E�l
		//
		HeadTiltLimitX			= 300,		// �w�b�hX�����X�����E�l
		HeadTiltLimitY			= 302,		// �w�b�hY�����X�����E�l
		//
		KeyOriginOffsetZ1		= 70,		// ���_�I�t�Z�b�gZ1
		KeyOriginOffsetZ2		= 71,		// ���_�I�t�Z�b�gZ2
		KeyOriginOffsetZ3		= 72,		// ���_�I�t�Z�b�gZ3
		//
		OriginOffsetZ1			= 320,		// ���_�I�t�Z�b�gZ1
		OriginOffsetZ2			= 322,		// ���_�I�t�Z�b�gZ2
		OriginOffsetZ3			= 324,		// ���_�I�t�Z�b�gZ3
//	
		KeyHome			= '0'	,
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyData1				,
		KeyData2				,
		KeyData3				,
		KeyData4				,
		KeyData5				,
	};
	int	r = KeyPrev;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	BOOL	DataUpdate=FALSE;
	int T1IL = 20;
	int T2IL = 21;
	int T3IL = 22;
	for(;;){
		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		/////////////////////
		DataPut(HdmeasureHdPosZ,	pMCC->BND.tiltMeasure.GetHeadMeasureHeadZPos(),1000);
// #MU140331-01
		DataPut(HeadTiltLimitX,		pMCC->BND.tiltMeasure.GetHeadTiltLimitX() * RAD_DEG, 10000);
		DataPut(HeadTiltLimitY,		pMCC->BND.tiltMeasure.GetHeadTiltLimitY() * RAD_DEG, 10000);
		DataPut(OriginOffsetZ1,		pMCC->BND.MD.MtrD.OrgOffset[T1IL], 1000);
		DataPut(OriginOffsetZ2,		pMCC->BND.MD.MtrD.OrgOffset[T2IL], 1000);
		DataPut(OriginOffsetZ3,		pMCC->BND.MD.MtrD.OrgOffset[T3IL], 1000);
//
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			///////////////
			// �w�b�h���莞�̃w�b�h�y�ʒu
			if(KeyHdmeasureHdPosZ == key){
				const char *msg[] = {
					"�w�b�h���莞�̃w�b�h�y�ʒu",
					"Bg Head Z Position",
				};
				///////////////
				// �f�[�^�ҏW
				double val = pMCC->BND.tiltMeasure.GetHeadMeasureHeadZPos();	// �ݒ萔�Ǎ�
				if (DataEdit(msg[Lang], "mm", val, 0.0, 47.0)) {	// �ް��ҏW
					DataPut(HdmeasureHdPosZ, val);
					pMCC->BND.tiltMeasure.SetMeasureHeadZPos(val);
					DataUpdate = TRUE;
				}
			}
// #MU140331-01
			if(KeyHeadTiltLimitX == key){
				const char *msg[] = {
					"�w�b�hX�����X�����E�l",
					"Bg Head Tilt Limt X",
				};
				///////////////
				// �f�[�^�ҏW
				double val = pMCC->BND.tiltMeasure.GetHeadTiltLimitX() * RAD_DEG;	// �ݒ萔�Ǎ�
				double max = 0.1031;
				double min = -0.1031;
				if (DataEdit(msg[Lang], "mm", val, min, max, 10000)) {	// �ް��ҏW
					DataPut(HeadTiltLimitX, val);
					pMCC->BND.tiltMeasure.SetHeadTiltLimitX(val * DEG_RAD);
					DataUpdate = TRUE;
				}
			}
			if(KeyHeadTiltLimitY == key){
				const char *msg[] = {
					"�w�b�hY�����X�����E�l",
					"Bg Head Tilt Limt Y",
				};
				///////////////
				// �f�[�^�ҏW
				double val = pMCC->BND.tiltMeasure.GetHeadTiltLimitY() * RAD_DEG;	// �ݒ萔�Ǎ�
				double max = 0.1031;
				double min = -0.1031;
				if (DataEdit(msg[Lang], "mm", val, min, max, 10000)) {	// �ް��ҏW
					DataPut(HeadTiltLimitY, val);
					pMCC->BND.tiltMeasure.SetHeadTiltLimitY(val * DEG_RAD);
					DataUpdate = TRUE;
				}
			}
			if(KeyOriginOffsetZ1 == key){
				const char *msg[] = {
					"���_�␳�ʂy1",
					"Origin OffsetZ1",
				};
				///////////////
				// �f�[�^�ҏW
				double val = pMCC->BND.MD.MtrD.OrgOffset[T1IL];
				double max = 999.999;
				double min = -999.999;
				if (DataEdit(msg[Lang], "mm", val, min, max, 1000)) {	// �ް��ҏW
					DataPut(OriginOffsetZ1, val);
					pMCC->BND.MD.MtrD.OrgOffset[T1IL] = val;
					DataUpdate = TRUE;
				}
			}
			if(KeyOriginOffsetZ2 == key){
				const char *msg[] = {
					"���_�␳�ʂy2",
					"Origin OffsetZ2",
				};
				///////////////
				// �f�[�^�ҏW
				double val = pMCC->BND.MD.MtrD.OrgOffset[T2IL];
				double max = 999.999;
				double min = -999.999;
				if (DataEdit(msg[Lang], "mm", val, min, max, 1000)) {	// �ް��ҏW
					DataPut(OriginOffsetZ2, val);
					pMCC->BND.MD.MtrD.OrgOffset[T2IL] = val;
					DataUpdate = TRUE;
				}
			}
			if(KeyOriginOffsetZ3 == key){
				const char *msg[] = {
					"���_�␳�ʂy3",
					"Origin OffsetZ3",
				};
				///////////////
				// �f�[�^�ҏW
				double val = pMCC->BND.MD.MtrD.OrgOffset[T3IL];
				double max = 999.999;
				double min = -999.999;
				if (DataEdit(msg[Lang], "mm", val, min, max, 1000)) {	// �ް��ҏW
					DataPut(OriginOffsetZ3, val);
					pMCC->BND.MD.MtrD.OrgOffset[T3IL] = val;
					DataUpdate = TRUE;
				}
			}
//
			///////////////
			// etc
			else if(KeyPrev == key){
				End = TRUE;
				r =	Prev_END;
			}
			else if(KeyHome == key){
				End = TRUE;
				r = Home_END;
			}
			else if(KeyTeach == key){
				End = TRUE;
				r = Teach1_END;
			}
			else if(KeyData1 == key){
				End = TRUE;
				r = Data1_END;
			}
			else if(KeyData2 <= key && key <= KeyData5){
				End = TRUE;
				r = Data1_END + key - KeyData1;
			}
			if(DataUpdate || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.tiltMeasure.McDataRW(FALSE,  pMCC->BND.MD.FName, pMCC->BND.MD.Sec);
		pMCC->BND.MD.MtrD.DataRW(pMCC->BND,FALSE,pMCC->BND.MD.FName);
	}
	return r;
}

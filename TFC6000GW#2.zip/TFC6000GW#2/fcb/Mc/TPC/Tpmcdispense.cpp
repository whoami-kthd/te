/*---------------------------------------------------------------------
	������ى�ʊ֐��i�}�V���f�[�^�F�f�B�X�y���X�j
								2010 Toshiyuki.Takahashi / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>

#include	<mcc.h>
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::MC_Dispense(int step,int page){
	int	r=OK_END;

	for(;;){
		if(step == 0){
			if(page == 1)		r = MCd_Dispense1();
			else				r = Data1_END;
		}
		else{
			// ���Ȗ���
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		}
		else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;

}

/////////////////////////////////////////////////////////////////////////////
//----- �ް��ݒ�@�߰��1
int TPCtrl::MCd_Dispense1()
{
	enum{
		SNo			= 2231,		// ���No.

		//---------------------
		//
		NozzleCameraOffsetX		= 300,		// �m�Y���J�����I�t�Z�b�g�w
		NozzleCameraOffsetY		= 302,		// �m�Y���J�����I�t�Z�b�g�x
		LevelDetectDelayBalue	= 304,		// �m�Y���^�b�`���o�␳��
		// #KI150310-01(S)
		LeaveShotColumn			= 310,		// �̂đł���
		LeaveShotLine			= 312,		// �̂đł��s��(B'g�X�e�[�W��̂�)
		LeaveShotPitchX			= 314,		// �̂đł��s�b�`X
		LeaveShotPitchY			= 316,		// �̂đł��s�b�`Y(B'g�X�e�[�W��̂�)
		// #KI150310-01(E)
		//---------------------
		//
		KeyNozzleCameraOffsetX		= 65,	// 
		KeyNozzleCameraOffsetY		= 66,	// 
		KeyLevelDetectDelayBalue	= 67,	// 
		// #KI150310-01(S)
		KeyLeaveShotColLine			= 68,	// �̂đł��s��
		KeyLeaveShotPitch			= 69,	// �̂đł��s�b�`XY
		// ----------------------
		//
		//
		//
		AttLeaveShotPosYDisp		= 200,	// 0:�ˑ��=X�̂�, 1:B'g�ð�ޏ�=XY
		// #KI150310-01(E)
		//---------------------
		//
		KeyHome			= '0'	,
		KeyPrev					,
		KeyTeach				,
		KeyPage1		= '4'	,
		KeyPage2				,
		KeyPage3				,
		KeyPage4				,
		KeyPage5				,
	};
	//
	int	r;
	BOOL	DataUpdate=FALSE;
	int		Lang = (pMCC->MD.OptionD.Language_mode) ?  1: 0;
	// #KI150310-01(S)
	// B'g�ð�ޏ�Ȃ�Y&�s���\������B
	tpc.GpPut16(AttLeaveShotPosYDisp,	(pMCC->MD.OptionD.DisClnPosIsOnBgStg) ? 1 : 0);
	// #KI150310-01(E)
	for(;;){
		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		//---------------------------------------------------------------
		// �����ݒ�
		//
///		DataPut(NozzleCameraOffsetX,	pMCC->BND.MD.DisStgD.NeedleOffset.x,	1000);
///		DataPut(NozzleCameraOffsetY,	pMCC->BND.MD.DisStgD.NeedleOffset.y,	1000);
		R2Pos offset = pMCC->BND.GetDisMechanicalOffset();
		DataPut(NozzleCameraOffsetX,	offset.x,	1000);
		DataPut(NozzleCameraOffsetY,	offset.y,	1000);
		DataPut(LevelDetectDelayBalue,	pMCC->BND.dispenseHead.DispensD.NeedleTochOffset,	1000);
		// #KI150310-01(S)
		DataPut(LeaveShotColumn,	pMCC->BND.MD.DisStgD.CleaningColumn);
		DataPut(LeaveShotLine,		pMCC->BND.MD.DisStgD.CleaningLine);
		DataPut(LeaveShotPitchX,	pMCC->BND.MD.DisStgD.CleaningPitch.x,	100);
		DataPut(LeaveShotPitchY,	pMCC->BND.MD.DisStgD.CleaningPitch.y,	100);
		// #KI150310-01(E)
		//---------------------------------------------------------------
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			// �z�X�g�ɂ���ă��b�N����Ă���ꍇ�́A�J�ڃ{�^���ȊO�͖����ɂ���B
			if(this->IsLockedByHost(key)){
				continue;
			}
			if(key)	tpc.GpBeep();
			switch(key){
				//----------------------------------------------
				// �m�Y���J�����I�t�Z�b�g�w
				//
				case KeyNozzleCameraOffsetX:
					{
						const char* msgX[][2] = {
							{ "�m�Y���J�����I�t�Z�b�g�w", "mm" },
							{ "Nozzle Camera Offset X", "mm" },
						};
///						double position = pMCC->BND.MD.DisStgD.NeedleOffset.x;
						R2Pos position = pMCC->BND.GetDisMechanicalOffset();
//						if (DataEdit(msgX[Lang][0], msgX[Lang][1], position.x, 0.0, 50.0, 1000)){
						// #SS130225 ASE�f�o�b�O
						if (DataEdit(msgX[Lang][0], msgX[Lang][1], position.x, -50.0, 50.0, 1000)){
							DataPut(NozzleCameraOffsetX, position.x, 1000);
///							pMCC->BND.MD.DisStgD.NeedleOffset.x = position;
							pMCC->BND.dispenseHead.SetDisHd_DisCamDistance(position);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// �m�Y���J�����I�t�Z�b�g�x
				//
				case KeyNozzleCameraOffsetY:
					{
						const char* msgX[][2] = {
							{ "�m�Y���J�����I�t�Z�b�g�x", "mm" },
							{ "Nozzle Camera Offset Y", "mm" },
						};
///						double position = pMCC->BND.MD.DisStgD.NeedleOffset.y;
						R2Pos position = pMCC->BND.GetDisMechanicalOffset();
//						if (DataEdit(msgX[Lang][0], msgX[Lang][1], position.y, 0.0, 50.0, 1000)){
						// #SS130225 ASE�f�o�b�O
						if (DataEdit(msgX[Lang][0], msgX[Lang][1], position.y, -50.0, 50.0, 1000)){
							DataPut(NozzleCameraOffsetY, position.y, 1000);
///							pMCC->BND.MD.DisStgD.NeedleOffset.y = position;
							pMCC->BND.dispenseHead.SetDisHd_DisCamDistance(position);
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				// �m�Y���^�b�`���o�␳��
				//
				case KeyLevelDetectDelayBalue:
					{
						const char* msgX[][2] = {
							{ "�m�Y���^�b�`���o�␳��", "mm" },
							{ "Level Detect Delay Value", "mm" },
						};
						double position = pMCC->BND.dispenseHead.DispensD.NeedleTochOffset;
						if (DataEdit(msgX[Lang][0], msgX[Lang][1], position, 0.0, 5.0, 1000)){
							DataPut(LevelDetectDelayBalue, position, 1000);
							pMCC->BND.dispenseHead.DispensD.NeedleTochOffset = position;
							DataUpdate = TRUE;
						}
					}
					break;
				//----------------------------------------------
				//
				// #KI150310-01(S)
				case KeyLeaveShotColLine		:
					{
						const char *msgX[][2] = {
							{ "LeaveShotColumn", "" },
							{ "LeaveShotColumn", "" },
						};
						const char *msgY[][2] = {
							{ "LeaveShotLine", "" },
							{ "LeaveShotLine", "" },
						};
						if(DataEdit(msgX[Lang][0], msgX[Lang][1], pMCC->BND.MD.DisStgD.CleaningColumn, 1, 10)){	// �ް��ҏW
							DataPut(LeaveShotColumn, pMCC->BND.MD.DisStgD.CleaningColumn);
							DataUpdate = TRUE;
						}
						// �{���f�B���O�X�e�[�W��̂đł��Ȃ�΁A�s������
						if(pMCC->MD.OptionD.DisClnPosIsOnBgStg){
							if(DataEdit(msgY[Lang][0], msgY[Lang][1], pMCC->BND.MD.DisStgD.CleaningLine, 1, 10)){	// �ް��ҏW
								DataPut(LeaveShotLine, pMCC->BND.MD.DisStgD.CleaningLine);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				case KeyLeaveShotPitch			:	//�̂đł��s�b�`XY
					{
						const char *xmsg[][2] = {
							{ "LeaveShotPitchX", "mm"},
							{ "LeaveShotPitchX", "mm"},
						};
						const char *ymsg[][2] = {
							{ "LeaveShotPitchY", "mm"},
							{ "LeaveShotPitchY", "mm"},
						};
						R2Pos leaveShotPitch = pMCC->BND.MD.DisStgD.CleaningPitch;
						if (DataEdit(xmsg[Lang][0], "mm", pMCC->BND.MD.DisStgD.CleaningPitch.x, 0.0, 50.0, 100)) {
							DataPut(LeaveShotPitchX, pMCC->BND.MD.DisStgD.CleaningPitch.x, 100);
							DataUpdate = TRUE;
						}
						// �{���f�B���O�X�e�[�W��̂đł��Ȃ�΁AY������
						if(pMCC->MD.OptionD.DisClnPosIsOnBgStg){
							if (DataEdit(ymsg[Lang][0], "mm", pMCC->BND.MD.DisStgD.CleaningPitch.y, 0.0, 50.0, 100)) {
								DataPut(LeaveShotPitchY, pMCC->BND.MD.DisStgD.CleaningPitch.y, 100);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				// #KI150310-01(E)
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyTeach:
					//End = TRUE;
					//r = Teach3_END;	// è��ݸ��߰��1��
					break;
				case KeyPage1:
				case KeyPage2:
					End = TRUE;
					r = Data1_END + key - KeyPage1;	// è��ݸ��߰��1��
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �ް�����
		pMCC->BND.dispenseHead.McDataRW(FALSE,pMCC->BND.MD.FName, pMCC->BND.MD.Sec);
		pMCC->BND.dispenseHead.DispensD.DataRW(FALSE,pMCC->BND.MD.FName, pMCC->BND.MD.Sec);
		pMCC->BND.MD.DisStgD.DataRW(pMCC->BND, FALSE, pMCC->BND.MD.FName);
	}
	return	r;
}







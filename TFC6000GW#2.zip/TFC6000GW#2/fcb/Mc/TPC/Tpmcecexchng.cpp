/*---------------------------------------------------------------------
	������ى�ʊ֐�
								2012 Nobuyuki.Goto
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

////////////////////////////////////////////////////////////////////////////////-
//
int TPCtrl::MC_ECexchng(int step,	// �O�F�f�[�^�ݒ�@�P�F�e�B�[�`���O
					 int page)	// �y�[�W
{
	int	r = OK_END;
	for (;;) {
		if (0 == step) {	// �f�[�^�ݒ�
			switch (page) {
			case 1:  r = MC_ECexchng1();		break;		// Eject Exchanger
			case 2:  r = MC_ECexchng2();		break;		// Collette Exchanger
			default: r = Data1_END; break;
			}
		} else {			// �e�B�[�`���O
			switch (page) {
			case 1:  r = MC_ECexchng1();		break;		// Eject Exchanger
			case 2:  r = MC_ECexchng2();		break;		// Collette Exchanger
			default: r = Teach1_END; break;
			}
		}
		if (Home_END == r || Prev_END == r) {
			break;
		} else if (Data1_END <= r && r <= Data8_END) {
			page = r - Data1_END + 1;
			step = 0;
		} else if (Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return(r);
}

////////////////////////////////////////////////////////////////////////////////-
//----- �ް��ݒ�@�߰��1	�̾��
int TPCtrl::MC_ECexchng1()
{
	enum{
		SNo				= 2020,		// ���No.
//
		EJECT1			= 300,		// EJECT1
		EJECT2			= 302,		// EJECT2
		EJECT3			= 304,		// EJECT3
		EJECT4			= 306,		// EJECT4
//
		KeyEJECT1		= 70,		// EJECT1
		KeyEJECT2		= 71,		// EJECT2
		KeyEJECT3		= 72,		// EJECT3
		KeyEJECT4		= 73,		// EJECT4

		KeyHome			= 48,
		KeyPrev			= 49,
		KeyTeach		= 50,
		KeyData			= 51,
		KeyData1		= 52,
		KeyData2		= 53,
		KeyData3		= 54,
		KeyData4		= 55,
		KeyData5		= 56,
		KeyCancel		= 57,
	};

	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r;
	BOOL DataUpdate = FALSE;

	for (;;) {
		BOOL End = FALSE;
		for(int i=0; i<Eject_NumberMax ; i++){
			DataPut(EJECT1 + i*2,	pMCC->ICS.icSupply.pickup.EjectExchangeD.ejectExchPosY[i] );	// EJECT1 (L)
		}
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�

		for(;;){
			BOOL Restart = FALSE;
			int key = KeyWait();
			// �z�X�g�ɂ���ă��b�N����Ă���ꍇ�́A�J�ڃ{�^���ȊO�͖����ɂ���B
			if(this->IsLockedByHost(key)){
				continue;
			}
			if (key) tpc.GpBeep();
			switch (key ){
			case KeyEJECT1:
			case KeyEJECT2:
			case KeyEJECT3:
			case KeyEJECT4:
				{
					const char* msg[] = {
						"Eject�ʒu�@Y",
						"Eject Position Y"
					};
					int index = key - KeyEJECT1;
					double min	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::EYI][0];
					double max	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::EYI][1];
					if (DataEdit(msg[Lang], "mm", pMCC->ICS.icSupply.pickup.EjectExchangeD.ejectExchPosY[index] , min, max)) {
						DataPut(EJECT1 + index*2,	pMCC->ICS.icSupply.pickup.EjectExchangeD.ejectExchPosY[index]  );
						DataUpdate = TRUE;
					}
				}
				break;
			case KeyHome: End = TRUE; r = Home_END; break;		// ���[�h
			case KeyPrev: End = TRUE; r = Prev_END; break;		// �O���
			case KeyTeach: End = TRUE; r = Teach1_END; break;	// �e�B�[�`���O
			case KeyData1: End = TRUE; r = Data1_END; break;
			case KeyData2: End = TRUE; r = Data2_END; break;
			case KeyData3: End = TRUE; r = Data3_END; break;
			case KeyData4: End = TRUE; r = Data4_END; break;
			case KeyData5: End = TRUE; r = Data5_END; break;
			}
			if (Restart || End) break;
		}
		if (End) break;
	}
	if (DataUpdate)	{
		pMCC->ICS.icSupply.pickup.McDataRW(FALSE,pMCC->ICS.MD.FName, pMCC->ICS.MD.Sec);
	}
	return(r);
}

////////////////////////////////////////////////////////////////////////////////-
//----- �ް��ݒ�@�߰��2	�̾��
int TPCtrl::MC_ECexchng2()
{
	enum{
		SNo					= 2021,		// ���No.
//
		Exchange1px			= 300,		// Exchange1 pickupX�ʒu
		Exchange2px			= 302,		// Exchange2 pickupX�ʒu
		Exchange3px			= 304,		// Exchange3 pickupX�ʒu
		Exchange4px			= 306,		// Exchange4 pickupX�ʒu

		Exchange1pz			= 308,		// Exchange1 pickupZ�ʒu
		Exchange2pz			= 310,		// Exchange2 pickupZ�ʒu
		Exchange3pz			= 312,		// Exchange3 pickupZ�ʒu
		Exchange4pz			= 314,		// Exchange4 pickupZ�ʒu

		Exchange1sx			= 316,		// Exchange1 waferStageX�ʒu
		Exchange2sx			= 318,		// Exchange2 waferStageX�ʒu
		Exchange3sx			= 320,		// Exchange3 waferStageX�ʒu
		Exchange4sx			= 322,		// Exchange4 waferStageX�ʒu

		Exchange1sy			= 324,		// Exchange1 waferStageX�ʒu
		Exchange2sy			= 326,		// Exchange2 waferStageX�ʒu
		Exchange3sy			= 328,		// Exchange3 waferStageX�ʒu
		Exchange4sy			= 330,		// Exchange4 waferStageX�ʒu
//
		KeyExchange1pic		= 70,		// Exchange1 pickupX-Z�ʒu
		KeyExchange2pic		= 71,		// Exchange2 pickupX-Z�ʒu
		KeyExchange3pic		= 72,		// Exchange3 pickupX-Z�ʒu
		KeyExchange4pic		= 73,		// Exchange4 pickupX-Z�ʒu

		KeyExchange1stg		= 74,		// Exchange1 waferStageXY�ʒu
		KeyExchange2stg		= 75,		// Exchange2 waferStageXY�ʒu
		KeyExchange3stg		= 76,		// Exchange3 waferStageXY�ʒu
		KeyExchange4stg		= 77,		// Exchange4 waferStageXY�ʒu

		KeyHome				= 48,
		KeyPrev				= 49,
		KeyTeach			= 50,
		KeyData				= 51,
		KeyData1			= 52,
		KeyData2			= 53,
		KeyData3			= 54,
		KeyData4			= 55,
		KeyData5			= 56,
		KeyCancel			= 57,
	};

	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r;
	BOOL DataUpdate = FALSE;

	for (;;) {
		BOOL End = FALSE;

		for(int i=0; i<Eject_NumberMax ; i++){
			DataPut(Exchange1px + i*2,	pMCC->ICS.icSupply.pickup.ColletteExchangeD.colletteExchPosX[i] );
			DataPut(Exchange1pz + i*2,	pMCC->ICS.icSupply.pickup.ColletteExchangeD.colletteExchPosZ[i]);
			DataPut(Exchange1sx + i*2,	pMCC->ICS.icSupply.wfStage.WStgD.ColExchPos[i].X() );
			DataPut(Exchange1sy + i*2,	pMCC->ICS.icSupply.wfStage.WStgD.ColExchPos[i].Y() );
		}

		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�

		for(;;){
			BOOL Restart = FALSE;
			int key = KeyWait();
			// �z�X�g�ɂ���ă��b�N����Ă���ꍇ�́A�J�ڃ{�^���ȊO�͖����ɂ���B
			if(this->IsLockedByHost(key)){
				continue;
			}
			if (key) tpc.GpBeep();
			switch (key ){
			case KeyExchange1pic:
			case KeyExchange2pic:
			case KeyExchange3pic:
			case KeyExchange4pic:
				{
					const char* msg[] = {
						"Collette Exchange�ʒu�@X",
						"Collette Exchange Position X"
					};
					int index = key - KeyExchange1pic;
					double min	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::PXI][0];
					double max	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::PXI][1];
					if (DataEdit(msg[Lang], "mm", pMCC->ICS.icSupply.pickup.ColletteExchangeD.colletteExchPosX[index] , min, max)) {
						DataPut(Exchange1px + index*2,	pMCC->ICS.icSupply.pickup.ColletteExchangeD.colletteExchPosX[index]  );
						DataUpdate = TRUE;
					}
				}
				{
					const char* msg[] = {
						"Collette Exchange�ʒu�@Z",
						"Collette Exchange Position Z"
					};
					int index = key - KeyExchange1pic;
					double min	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::PZI][0];
					double max	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::PZI][1];
					if (DataEdit(msg[Lang], "mm", pMCC->ICS.icSupply.pickup.ColletteExchangeD.colletteExchPosZ[index], min, max)) {
						DataPut(Exchange1pz + index*2,	pMCC->ICS.icSupply.pickup.ColletteExchangeD.colletteExchPosZ[index]);
						DataUpdate = TRUE;
					}
				}
				break;
			case KeyExchange1stg:
			case KeyExchange2stg:
			case KeyExchange3stg:
			case KeyExchange4stg:
				{
					const char* msg[] = {
						"Collette Exchange�ʒu�@X",
						"Collette Exchange Position X"
					};
					int index = key - KeyExchange1stg;
					double min	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::SXI][0];
					double max	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::SXI][1];
					if (DataEdit(msg[Lang], "mm", pMCC->ICS.icSupply.wfStage.WStgD.ColExchPos[index].X() , min, max)) {
						DataPut(Exchange1sx + index*2,	pMCC->ICS.icSupply.wfStage.WStgD.ColExchPos[index].X()  );
						DataUpdate = TRUE;
					}
				}
				{
					const char* msg[] = {
						"Collette Exchange�ʒu�@Y",
						"Collette Exchange Position Y"
					};
					int index = key - KeyExchange1stg;
					double min	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::SYI][0];
					double max	= pMCC->ICS.MD.MtrD.Limit[ICSCtrl::SYI][1];
					if (DataEdit(msg[Lang], "mm", pMCC->ICS.icSupply.wfStage.WStgD.ColExchPos[index].Y() , min, max)) {
						DataPut(Exchange1sy + index*2,	pMCC->ICS.icSupply.wfStage.WStgD.ColExchPos[index].Y()  );
						DataUpdate = TRUE;
					}
				}
				break;
			case KeyHome: End = TRUE; r = Home_END; break;		// ���[�h
			case KeyPrev: End = TRUE; r = Prev_END; break;		// �O���
			case KeyTeach: End = TRUE; r = Teach1_END; break;	// �e�B�[�`���O
// #OZ20150701 ModifiedICS �� MultiSlot ColletChange EjectChange ���� �Ή�
//			case KeyData1: End = TRUE; r = Data1_END; break;
			case KeyData1:
				if(pMCC->SD.Component.ejectorExchange){
					End = TRUE;
					r = Data1_END;
				}
				else{
					Warn(OptionDisp[pMCC->MD.OptionD.Language_mode]);
				}
				break;
			case KeyData2: End = TRUE; r = Data2_END; break;
			case KeyData3: End = TRUE; r = Data3_END; break;
			case KeyData4: End = TRUE; r = Data4_END; break;
			case KeyData5: End = TRUE; r = Data5_END; break;
			}
			if (Restart || End) break;
		}
		if (End) break;
	}
	if (DataUpdate)	{
		pMCC->ICS.icSupply.wfStage.WStgD.DataRW(FALSE, pMCC->ICS.MD.FName, pMCC->ICS.MD.Sec);
		pMCC->ICS.icSupply.pickup.McDataRW(FALSE,pMCC->ICS.MD.FName, pMCC->ICS.MD.Sec);
	}
	return(r);
}


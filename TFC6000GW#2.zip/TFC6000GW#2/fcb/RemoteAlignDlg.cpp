// RemoteAlignDlg.cpp : implementation file
//

#include "stdafx.h"
#include "fcb.h"
#include "RemoteAlignDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRemoteAlignDlg dialog


CRemoteAlignDlg::CRemoteAlignDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRemoteAlignDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRemoteAlignDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CRemoteAlignDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRemoteAlignDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRemoteAlignDlg, CDialog)
	//{{AFX_MSG_MAP(CRemoteAlignDlg)
	ON_BN_CLICKED(IDC_BUTTON_CONFIRM, OnButtonConfirm)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, OnButtonCancel)
	ON_BN_CLICKED(IDC_BUTTON_TRACKBALL, OnButtonTrackball)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CRemoteAlignDlg::OnInitDialog()
{
	RECT workRect;
	CRect rect;
	SystemParametersInfo(SPI_GETWORKAREA, 0, &workRect, sizeof(workRect) );
	GetWindowRect(&rect);
	SetWindowPos(&wndTopMost, workRect.right - rect.Width(), workRect.bottom - rect.Height(), 0, 0, SWP_NOSIZE);
	return 0;
}
/////////////////////////////////////////////////////////////////////////////
// CRemoteAlignDlg message handlers

void CRemoteAlignDlg::OnButtonConfirm() 
{
	// TODO: Add your control notification handler code here
	// key 65
	// Only set event to notify to keywait 
	if (pEvRemoteAlignConfirm) {
		pEvRemoteAlignConfirm->SetEvent();
	}
}

void CRemoteAlignDlg::OnButtonCancel() 
{
	// TODO: Add your control notification handler code here
	// key 66
	if (pEvRemoteAlignCancel) {
		pEvRemoteAlignCancel->SetEvent();
	}
}

void CRemoteAlignDlg::OnButtonTrackball() 
{
	// TODO: Add your control notification handler code here
	// key 67
	if (pEvRemoteAlignCursor) {
		pEvRemoteAlignCursor->SetEvent();
	}
}

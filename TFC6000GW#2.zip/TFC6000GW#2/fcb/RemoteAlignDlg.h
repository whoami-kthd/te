#if !defined(AFX_REMOTEALIGNDLG_H__BCCB78CB_9F31_49F6_9E0A_227CA87FAD27__INCLUDED_)
#define AFX_REMOTEALIGNDLG_H__BCCB78CB_9F31_49F6_9E0A_227CA87FAD27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#pragma once
// RemoteAlignDlg.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CRemoteAlignDlg dialog
#include	<semaxx.h>

#define	RA_W	99
#define	RA_H	40

class CRemoteAlignDlg : public CDialog
{
// Construction
public:
	CRemoteAlignDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRemoteAlignDlg)
	enum { IDD = IDD_DIALOG_REMOTE_ALIGN };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRemoteAlignDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation
private:
	CEventX*	pEvRemoteAlignConfirm;
	CEventX*	pEvRemoteAlignCancel;
	CEventX*	pEvRemoteAlignCursor;
public:
	void SetEventRemoteDlg(CEventX* pEvConfirm, CEventX* pEvCancel, CEventX* pEvCursor) {
		pEvRemoteAlignConfirm = pEvConfirm;
		pEvRemoteAlignCancel = pEvCancel;
		pEvRemoteAlignCursor = pEvCursor;
	}
protected:

	// Generated message map functions
	//{{AFX_MSG(CRemoteAlignDlg)
	afx_msg void OnButtonConfirm();
	afx_msg void OnButtonCancel();
	afx_msg void OnButtonTrackball();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REMOTEALIGNDLG_H__BCCB78CB_9F31_49F6_9E0A_227CA87FAD27__INCLUDED_)

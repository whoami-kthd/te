// Microsoft Visual C++ �Ŏ����������ꂽ IDispatch ���b�v �N���X

// ����: ���̃t�@�C���̓��e��ҏW���Ȃ��ł��������B ���̃N���X���ēx
//  Microsoft Visual C++ �Ő������ꂽ�ꍇ�A�ύX���㏑�����܂��B


#include "stdafx.h"
#include "xcomsecs.h"

/////////////////////////////////////////////////////////////////////////////
// CXcomSecs

IMPLEMENT_DYNCREATE(CXcomSecs, CWnd)

/////////////////////////////////////////////////////////////////////////////
// CXcomSecs �v���p�e�B

VARIANT CXcomSecs::GetMhead()
{
	VARIANT result;
	GetProperty(0x1, VT_VARIANT, (void*)&result);
	return result;
}

void CXcomSecs::SetMhead(const VARIANT& propVal)
{
	SetProperty(0x1, VT_VARIANT, &propVal);
}

VARIANT CXcomSecs::GetRcvhead()
{
	VARIANT result;
	GetProperty(0x7, VT_VARIANT, (void*)&result);
	return result;
}

void CXcomSecs::SetRcvhead(const VARIANT& propVal)
{
	SetProperty(0x7, VT_VARIANT, &propVal);
}

long CXcomSecs::GetErrorStatus()
{
	long result;
	GetProperty(0xa, VT_I4, (void*)&result);
	return result;
}

void CXcomSecs::SetErrorStatus(long propVal)
{
	SetProperty(0xa, VT_I4, propVal);
}

CString CXcomSecs::GetErrorActionName()
{
	CString result;
	GetProperty(0xb, VT_BSTR, (void*)&result);
	return result;
}

void CXcomSecs::SetErrorActionName(LPCTSTR propVal)
{
	SetProperty(0xb, VT_BSTR, propVal);
}

short CXcomSecs::GetErrorCommand()
{
	short result;
	GetProperty(0xc, VT_I2, (void*)&result);
	return result;
}

void CXcomSecs::SetErrorCommand(short propVal)
{
	SetProperty(0xc, VT_I2, propVal);
}

short CXcomSecs::GetRunTimeFlag()
{
	short result;
	GetProperty(0xe, VT_I2, (void*)&result);
	return result;
}

void CXcomSecs::SetRunTimeFlag(short propVal)
{
	SetProperty(0xe, VT_I2, propVal);
}

long CXcomSecs::GetOpenMode()
{
	long result;
	GetProperty(0x1a, VT_I4, (void*)&result);
	return result;
}

void CXcomSecs::SetOpenMode(long propVal)
{
	SetProperty(0x1a, VT_I4, propVal);
}

long CXcomSecs::GetCloseMode()
{
	long result;
	GetProperty(0x1b, VT_I4, (void*)&result);
	return result;
}

void CXcomSecs::SetCloseMode(long propVal)
{
	SetProperty(0x1b, VT_I4, propVal);
}

long CXcomSecs::GetSelectState()
{
	long result;
	GetProperty(0x1c, VT_I4, (void*)&result);
	return result;
}

void CXcomSecs::SetSelectState(long propVal)
{
	SetProperty(0x1c, VT_I4, propVal);
}

long CXcomSecs::GetTermMBNotAllow()
{
	long result;
	GetProperty(0x19, VT_I4, (void*)&result);
	return result;
}

void CXcomSecs::SetTermMBNotAllow(long propVal)
{
	SetProperty(0x19, VT_I4, propVal);
}

long CXcomSecs::GetOSEventlog()
{
	long result;
	GetProperty(0x1d, VT_I4, (void*)&result);
	return result;
}

void CXcomSecs::SetOSEventlog(long propVal)
{
	SetProperty(0x1d, VT_I4, propVal);
}

long CXcomSecs::GetTcpConnectEvent()
{
	long result;
	GetProperty(0x37, VT_I4, (void*)&result);
	return result;
}

void CXcomSecs::SetTcpConnectEvent(long propVal)
{
	SetProperty(0x37, VT_I4, propVal);
}

/////////////////////////////////////////////////////////////////////////////
// CXcomSecs �I�y���[�V����

long CXcomSecs::OpenProject(LPCTSTR project_path, LPCTSTR project_name)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_BSTR;
	InvokeHelper(0x2, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		project_path, project_name);
	return result;
}

long CXcomSecs::CloseProject()
{
	long result;
	InvokeHelper(0x3, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CXcomSecs::PutSecsItem(LPCTSTR item_name, const VARIANT& value, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_VARIANT VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x4, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		item_name, &value, index_1, index_2, index_3, index_4);
	return result;
}

long CXcomSecs::PutSecsEvent(LPCTSTR event_name)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR;
	InvokeHelper(0x5, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		event_name);
	return result;
}

long CXcomSecs::PutExtendItem(LPCTSTR item_name, const VARIANT& value, short item_type, long element, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_VARIANT VTS_I2 VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x6, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		item_name, &value, item_type, element, index_1, index_2, index_3, index_4);
	return result;
}

long CXcomSecs::GetItemData(LPCTSTR item_name, VARIANT* value, short* item_type, long* element, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PVARIANT VTS_PI2 VTS_PI4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x8, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		item_name, value, item_type, element, index_1, index_2, index_3, index_4);
	return result;
}

long CXcomSecs::GetMsgSize(LPCTSTR msg_name, long* msg_size)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PI4;
	InvokeHelper(0x9, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		msg_name, msg_size);
	return result;
}

long CXcomSecs::WriteCurrentData()
{
	long result;
	InvokeHelper(0xd, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CXcomSecs::GetMsgBlk(LPCTSTR msg_name, VARIANT* msg_blk, long* msg_size)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PVARIANT VTS_PI4;
	InvokeHelper(0xf, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		msg_name, msg_blk, msg_size);
	return result;
}

long CXcomSecs::GetVID(LPCTSTR vid_name, short* vid_type, VARIANT* vid, VARIANT* vname, VARIANT* unit, VARIANT* v, VARIANT* vmax, VARIANT* vmin, VARIANT* vdef, VARIANT* item_name, short* v_fmt, long* v_elm)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PI2 VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PI2 VTS_PI4;
	InvokeHelper(0x12, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		vid_name, vid_type, vid, vname, unit, v, vmax, vmin, vdef, item_name, v_fmt, v_elm);
	return result;
}

long CXcomSecs::SetVID(LPCTSTR vid_name, const VARIANT& v, long rsv1, long rsv2)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_VARIANT VTS_I4 VTS_I4;
	InvokeHelper(0x13, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		vid_name, &v, rsv1, rsv2);
	return result;
}

long CXcomSecs::SndEvntInf(LPCTSTR ceid_name, short rsv)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I2;
	InvokeHelper(0x14, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ceid_name, rsv);
	return result;
}

long CXcomSecs::PutAlarmEvent(LPCTSTR alm_name, short flg)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I2;
	InvokeHelper(0x1e, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		alm_name, flg);
	return result;
}

long CXcomSecs::GetAlarm(LPCTSTR alm_name, VARIANT* alid, VARIANT* alcd, VARIANT* altx, VARIANT* aled)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT;
	InvokeHelper(0x1f, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		alm_name, alid, alcd, altx, aled);
	return result;
}

long CXcomSecs::PutClockEvent()
{
	long result;
	InvokeHelper(0x20, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CXcomSecs::GetTraceData(LPCTSTR trid_name, short* trid, long* dsper, long* totsmp, long* repgsz)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PI2 VTS_PI4 VTS_PI4 VTS_PI4;
	InvokeHelper(0x21, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		trid_name, trid, dsper, totsmp, repgsz);
	return result;
}

long CXcomSecs::ChangeCommunication(long enable_flag)
{
	long result;
	static BYTE parms[] =
		VTS_I4;
	InvokeHelper(0x22, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		enable_flag);
	return result;
}

long CXcomSecs::EnableAlarm(LPCTSTR alm_name, short flg)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I2;
	InvokeHelper(0x23, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		alm_name, flg);
	return result;
}

long CXcomSecs::EnableTraceData(LPCTSTR trid_name, short flg)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I2;
	InvokeHelper(0x24, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		trid_name, flg);
	return result;
}

long CXcomSecs::ChangeCR()
{
	long result;
	InvokeHelper(0x25, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CXcomSecs::ChangeOnline(short mode)
{
	long result;
	static BYTE parms[] =
		VTS_I2;
	InvokeHelper(0x26, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		mode);
	return result;
}

long CXcomSecs::ChangeOnlineSubState(short mode)
{
	long result;
	static BYTE parms[] =
		VTS_I2;
	InvokeHelper(0x27, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		mode);
	return result;
}

long CXcomSecs::EqProcessState(short mode)
{
	long result;
	static BYTE parms[] =
		VTS_I2;
	InvokeHelper(0x28, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		mode);
	return result;
}

long CXcomSecs::FindAlarmList()
{
	long result;
	InvokeHelper(0x29, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CXcomSecs::FindNextAlarmList(long handle, VARIANT* alm_name, VARIANT* alid, VARIANT* alcd, VARIANT* altx, VARIANT* aled)
{
	long result;
	static BYTE parms[] =
		VTS_I4 VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT;
	InvokeHelper(0x2a, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		handle, alm_name, alid, alcd, altx, aled);
	return result;
}

long CXcomSecs::FindNextTermText(long handle, VARIANT* text)
{
	long result;
	static BYTE parms[] =
		VTS_I4 VTS_PVARIANT;
	InvokeHelper(0x2b, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		handle, text);
	return result;
}

long CXcomSecs::SetAlarm(LPCTSTR alm_name, const VARIANT& alid, const VARIANT& alcd, const VARIANT& altx)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_VARIANT VTS_VARIANT VTS_VARIANT;
	InvokeHelper(0x2c, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		alm_name, &alid, &alcd, &altx);
	return result;
}

BOOL CXcomSecs::GetDATAID(VARIANT* value, short itmfmt, long elements)
{
	BOOL result;
	static BYTE parms[] =
		VTS_PVARIANT VTS_I2 VTS_I4;
	InvokeHelper(0x2d, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms,
		value, itmfmt, elements);
	return result;
}

long CXcomSecs::GetVIDVal(LPCTSTR vid_name, VARIANT* value, short* item_type, long* element, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PVARIANT VTS_PI2 VTS_PI4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x2e, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		vid_name, value, item_type, element, index_1, index_2, index_3, index_4);
	return result;
}

long CXcomSecs::SetVIDVal(LPCTSTR vid_name, const VARIANT& v, short item_type, long element, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_VARIANT VTS_I2 VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x2f, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		vid_name, &v, item_type, element, index_1, index_2, index_3, index_4);
	return result;
}

long CXcomSecs::CreateObject(const VARIANT& objtype, const VARIANT& objid)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT;
	InvokeHelper(0x30, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, &objid);
	return result;
}

long CXcomSecs::DeleteObject(const VARIANT& objtype, const VARIANT& objid)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT;
	InvokeHelper(0x31, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, &objid);
	return result;
}

long CXcomSecs::GetAttrData(const VARIANT& objtype, const VARIANT& objid, LPCTSTR attr_name, VARIANT* v, short* item_type, long* element, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT VTS_BSTR VTS_PVARIANT VTS_PI2 VTS_PI4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x32, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, &objid, attr_name, v, item_type, element, index_1, index_2, index_3, index_4);
	return result;
}

long CXcomSecs::PutAttrData(const VARIANT& objtype, const VARIANT& objid, LPCTSTR attr_name, const VARIANT& v, short item_type, long element, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT VTS_BSTR VTS_VARIANT VTS_I2 VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x33, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, &objid, attr_name, &v, item_type, element, index_1, index_2, index_3, index_4);
	return result;
}

long CXcomSecs::GetAttr(const VARIANT& objtype, LPCTSTR attr_name, short* item_type, long* element, VARIANT* attrid, VARIANT* max, VARIANT* min, VARIANT* def, short* flag)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_BSTR VTS_PI2 VTS_PI4 VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PI2;
	InvokeHelper(0x34, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, attr_name, item_type, element, attrid, max, min, def, flag);
	return result;
}

long CXcomSecs::SetAttr(const VARIANT& objtype, LPCTSTR attr_name, const VARIANT& v, short item_type, long element, short flag)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_BSTR VTS_VARIANT VTS_I2 VTS_I4 VTS_I2;
	InvokeHelper(0x35, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, attr_name, &v, item_type, element, flag);
	return result;
}

long CXcomSecs::GetXComLinkStatus(long* status, short flg)
{
	long result;
	static BYTE parms[] =
		VTS_PI4 VTS_I2;
	InvokeHelper(0x36, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		status, flg);
	return result;
}

long CXcomSecs::GetGEM300Error(long errorid, VARIANT* errcode, short* fmterrcode, long* elmerrcode, VARIANT* errtext, short* fmterrtext, long* elmerrtext)
{
	long result;
	static BYTE parms[] =
		VTS_I4 VTS_PVARIANT VTS_PI2 VTS_PI4 VTS_PVARIANT VTS_PI2 VTS_PI4;
	InvokeHelper(0x38, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		errorid, errcode, fmterrcode, elmerrcode, errtext, fmterrtext, elmerrtext);
	return result;
}

long CXcomSecs::SetCEIDDelete(LPCTSTR ceid_name, short flg)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_I2;
	InvokeHelper(0x39, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ceid_name, flg);
	return result;
}

long CXcomSecs::GetCEIDInfo(LPCTSTR ceid_name, VARIANT* ceid, VARIANT* rptidname_list, VARIANT* rptid_list, long* count, short* flg)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PI4 VTS_PI2;
	InvokeHelper(0x3a, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ceid_name, ceid, rptidname_list, rptid_list, count, flg);
	return result;
}

long CXcomSecs::GetRPTIDInfo2(LPCTSTR rptid_name, VARIANT* rptid, VARIANT* vidname_list, VARIANT* vid_list, long* count)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PI4;
	InvokeHelper(0x3b, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		rptid_name, rptid, vidname_list, vid_list, count);
	return result;
}

long CXcomSecs::GetCEIDList(VARIANT* ceid_list, long* count)
{
	long result;
	static BYTE parms[] =
		VTS_PVARIANT VTS_PI4;
	InvokeHelper(0x3c, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ceid_list, count);
	return result;
}

long CXcomSecs::GetRPTIDList(VARIANT* rptid_list, long* count)
{
	long result;
	static BYTE parms[] =
		VTS_PVARIANT VTS_PI4;
	InvokeHelper(0x3d, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		rptid_list, count);
	return result;
}

void CXcomSecs::AboutBox()
{
	InvokeHelper(0xfffffdd8, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

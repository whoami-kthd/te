// CMV_EditJump.cpp : implementation file
//

#include "stdafx.h"
#include "cmv.h"
#include "CMV_EditJump.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_EditJump dialog


CMV_EditJump::CMV_EditJump(CWnd* pParent /*=NULL*/)
	: CDialog(CMV_EditJump::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMV_EditJump)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMV_EditJump::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMV_EditJump)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMV_EditJump, CDialog)
	//{{AFX_MSG_MAP(CMV_EditJump)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_EditJump message handlers

BOOL CMV_EditJump::OnInitDialog() 
{
	CDialog::OnInitDialog();

	return TRUE;
}

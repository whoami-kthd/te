// CMV_InputMap.cpp : implementation file
//

#include "stdafx.h"
#include "cmv.h"
#include "CMV_InputMap.h"
#include "CMV_Doc.h"
#include "CMVDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_InputMap dialog


CMV_InputMap::CMV_InputMap(CWnd* pParent /*=NULL*/)
	: CDialog(CMV_InputMap::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMV_InputMap)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMV_InputMap::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMV_InputMap)
	DDX_Control(pDX, IDC_EDIT_MAPNAME, m_EditMapName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMV_InputMap, CDialog)
	//{{AFX_MSG_MAP(CMV_InputMap)
	ON_BN_CLICKED(IDC_BTN_OK, OnBtnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_InputMap message handlers

void CMV_InputMap::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}

void CMV_InputMap::SetInfoMapDisp(CCMVDlg* pMapDlg)
{
	m_pCMVDlg = pMapDlg;
}


BOOL CMV_InputMap::OnInitDialog() 
{
	CDialog::OnInitDialog();

	return TRUE;
}


void CMV_InputMap::OnBtnOk()						// OK button
{
	LoadMapEvent();
}

BOOL CMV_InputMap::PreTranslateMessage(MSG* pMsg) 
{
	if ((GetKeyState(0x0D) & 0x8000) ) {			// Enter key
		LoadMapEvent();
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CMV_InputMap::LoadMapEvent(void)
{
	m_pDoc->m_PathFile = _T("D:\\WaferMap\\");
	m_EditMapName.GetWindowText(m_pDoc->m_LoadFile);
	m_pDoc->m_PathFile += m_pDoc->m_LoadFile;

	/* Check file name is existed or not*/
	CFileFind finder;
	BOOL bWorking = finder.FindFile(m_pDoc->m_PathFile);
	if (bWorking == TRUE) {
		m_pCMVDlg->LoadMapFile(m_pDoc->m_PathFile);
	}
	else {
		MessageBox(_T("The file requested is not a valid"), _T("Error"), MB_ICONERROR | MB_OK);
	}
}

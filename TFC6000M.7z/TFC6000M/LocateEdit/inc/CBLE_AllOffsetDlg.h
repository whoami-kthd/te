///////////////////////////////////////////////////////////
//  CBLE_AllOffsetDlg.h
//  Implementation of the Class CBLE_AllOffsetDlg
//  Created on:      16-Thg7-2013 1:30:54 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_B272A77D_6F43_48af_AF92_AC4532912626__INCLUDED_)
#define EA_B272A77D_6F43_48af_AF92_AC4532912626__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_GridCtrl.h"
#include "CBLE_NumKeyWnd.h"

// CBLE_AllOffsetDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_AllOffsetDlg dialog

class CBLE_AllOffsetDlg : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CBLE_GridCtrl* m_pGridCtrl;
	CBLE_NumKeyWnd m_KeyWnd;

	CString m_OffsetX;
	CString m_OffsetY;
	CString m_OffsetAng;
	CString originalData; //use to handle save changes until press Enter

// Construction
public:
	void GetAllOffset(CString& offX, CString& offY, CString& offAng);
	void SetDocument(CBLE_Doc* pDoc);
	CBLE_AllOffsetDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_AllOffsetDlg();
	enum { IDD = IDD_ALLOFFSET_DLG };

	// For undo function
	void OnRestoreState();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnCancel();
	virtual void OnOK();
	virtual void OnClose();
	virtual BOOL OnInitDialog();

	virtual BOOL PreTranslateMessage(MSG* pMsg);
// Implementation
protected:
	afx_msg LRESULT OnUpdateGrid(WPARAM wParam, LPARAM lParam); // Response when press a key
	DECLARE_MESSAGE_MAP()
};
#endif // !defined(EA_B272A77D_6F43_48af_AF92_AC4532912626__INCLUDED_)


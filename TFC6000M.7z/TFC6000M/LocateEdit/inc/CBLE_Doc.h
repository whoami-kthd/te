///////////////////////////////////////////////////////////
//  CBLE_Doc.h
//  Implementation of the Class CBLE_Doc
//  Created on:      16-Thg7-2013 9:40:09 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_E1142681_5DCA_41e4_B528_1255E6DBD78B__INCLUDED_)
#define EA_E1142681_5DCA_41e4_B528_1255E6DBD78B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "CBLE_Model.h"

// Message
#define WM_UPDATE_VIEW				(WM_APP + 3500)
#define WM_UPDATE_ZOOM				(WM_UPDATE_VIEW + 1)
#define WM_UPDATE_SELECTED			(WM_UPDATE_VIEW + 2)
#define WM_UPDATE_KEY				(WM_UPDATE_VIEW + 3)
#define WM_UPDATE_FULLKEY			(WM_UPDATE_VIEW + 4)
#define WM_UPDATE_REGNO				(WM_UPDATE_VIEW + 5)
#define WM_FINISH_CHECK				(WM_UPDATE_VIEW + 6)
#define WM_UPDATE_CELL				(WM_UPDATE_VIEW + 7)
#define WM_STOP_SAVE				(WM_UPDATE_VIEW + 8)
#define WM_UPDATE_REVWND			(WM_UPDATE_VIEW + 9)
#define WM_START_INSTANCE			(WM_UPDATE_VIEW + 10)
#define WM_COLOR_CHANGE				(WM_UPDATE_VIEW + 11)
#define WM_DISPLAY_FOCUSIC			(WM_UPDATE_VIEW + 12)
#define WM_INIT_COMPLETE			(WM_UPDATE_VIEW + 13)
#define WM_CURROPEN_COMPLETE		(WM_UPDATE_VIEW + 14)
#define WM_UPDATE_OPTION			(WM_UPDATE_VIEW + 15)

// Register message
//static UINT WM_AUTORUN		= RegisterWindowMessage(WM_AUTORUN_MES);				
//static UINT WM_AUTORUN_ANS	= RegisterWindowMessage(WM_AUTORUN_ANS_MES);

#define DBLE_ZOOM_IN				0
#define DBLE_ZOOM_OUT				1

class CBLE_Doc : public CDocument
{
protected: // create from serialization only
	CBLE_Doc();
	DECLARE_DYNCREATE(CBLE_Doc)

// Attributes
public:
	DBLE_USER	m_User;
	CString		m_Password;
	vector<int> m_vZoom;
	CString		m_LanguageItem[DBLE_MAX_DLGITEM_SIZE][DBLE_MAX_DLGITEM_SIZE];
	TBLE_Language m_DialogItems[DBLE_LANGUAGE_ITEMS];
	bool		m_TFCRespond;
	CString		m_FilePath;
	
private:
	CBLE_Model m_Data;
	CString m_DeviceName;				
	int m_Mode;					// 0: Edit mode, 1: SubInfo mode
	int m_Count;
	HANDLE m_Handle[2];			// handle for event

	bool m_bIsSaving;

	CWinThread*		m_pInitDataThread;
	HANDLE m_InitHandle[2];			// handle for init event

	CWinThread*		m_pCurrentOpenThread;
	HANDLE m_CurrentOpenHandle[2];	// handle for current open thread

	static UINT InitDataThread(LPVOID pParam);

	static UINT CurrentOpenDataThread(LPVOID pParam);

// Operations
public:
	void InitDoc();
	void SetMode(int mode);
	void OnProcessAns(WPARAM wParam, LPARAM lParam);
	void GetLanguageString(CString filePath);
	bool SaveData();
	int GetMode();
	void SetSetting(int isCheckReflect); // 0 is reflect only, 1 is check and reflect
	int GetSetting();

// Overrides
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual BOOL CanCloseFrame(CFrameWnd* pFrame);
	virtual void OnCloseDocument();
	
	bool IsSavingData();

	void InitDocThread();
	void SubInfoCurrentOpen();
	void CurrentOpenData();

	void InitDocData();
// Implementation
public:
	virtual ~CBLE_Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	CBLE_Model* GetData();
	CString GetDeviceName();
	bool BrowseFolder(CString &result);
	static int CALLBACK BrowseCallbackProc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM lpData);
	CString GetDeviceNameFromPath(CString filePath);

// Generated message map functions
protected:
	// Generated message map functions
	//{{AFX_MSG(CBLE_Doc)
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnCurrentOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(EA_E1142681_5DCA_41e4_B528_1255E6DBD78B__INCLUDED_)

///////////////////////////////////////////////////////////
//  CBLE_ExpandView.h
//  Implementation of the Class CBLE_ExpandView
//  Created on:      16-Thg7-2013 1:51:31 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_39702274_3649_4572_B4D5_3830C41106AC__INCLUDED_)
#define EA_39702274_3649_4572_B4D5_3830C41106AC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"

// CBLE_ExpandView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_ExpandView view

class CBLE_ExpandView : public CScrollView
{
private:
	CBLE_Doc* m_pDoc;
	// Vector of all selected ICs
	vector<CBLE_IC*> m_vIC;
	TBLE_RegIC* m_pReg;
	// Vector of all N value
	vector<int> m_vN;
	// Use temporary memoryDC
	CDC m_MemDC;
	CBitmap m_MemBmp;
	//CFont m_Font;
	// index
	int m_MinX;
	int m_MaxX;
	int m_MinY;
	int m_MaxY;
	int m_MaxN;
	// Size for drawing
	double m_SizeX;
	double m_SizeY;

	// Center IC
	float m_CenX;
	float m_CenY;

public:
	CBLE_ExpandView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CBLE_ExpandView)
	void SetDocument(CBLE_Doc* pDoc);
	void ExpandICs(int Nstart, int Nend, double dX, double dY);
	int GetMaxN();
	void SetNVector(vector<int> vN);
	void FindCenterIC();		// find index of center IC
private:
	void SetScale();
	void InitData();
	CBLE_IC* FindIC(int idxX, int idxY);
	void DrawICText(CDC* pDC, CBLE_IC* pIC, double scale);
	int  FindNValue(CBLE_IC* pIC);
	void FindNICs(int N, vector<CBLE_IC*>& vIC);
	void DrawNFrame(CDC* pDC, int N, double offsetX, double offsetY, double scale);
	

// Overrides
protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	// Draw to memory DC
	void DrawToMemDC();

// Implementation
protected:
	virtual ~CBLE_ExpandView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Create event
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	// Draw event
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	// Mouse event
	afx_msg virtual int OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message);
	DECLARE_MESSAGE_MAP()
};
#endif // !defined(EA_39702274_3649_4572_B4D5_3830C41106AC__INCLUDED_)

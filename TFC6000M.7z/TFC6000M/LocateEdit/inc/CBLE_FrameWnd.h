///////////////////////////////////////////////////////////
//  CBLE_FrameWnd.h
//  Implementation of the Class CBLE_FrameWnd
//  Created on:      16-Thg7-2013 10:25:07 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_B6562A96_D799_49d6_9D3D_DD400472957A__INCLUDED_)
#define EA_B6562A96_D799_49d6_9D3D_DD400472957A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_LocateEditWnd.h"
#include "CBLE_AdjustWnd.h"
#include "CBLE_MappingWnd.h"
#include "CBLE_PassWordWnd.h"
#include "CBLE_SubInfoWnd.h"
#include "CBLE_OptCheckReflect.h"

// Window size
#define DBLE_MAINWND_SIZEX							600
#define DBLE_MAINWND_SIZEY							500
#define DBLE_MAINWND_SIZEX_SUBINFO					620
#define DBLE_MAINWND_SIZEY_SUBINFO					450

class CBLE_FrameWnd : public CFrameWnd
{
	
protected: // create from serialization only
	CBLE_FrameWnd();
	DECLARE_DYNCREATE(CBLE_FrameWnd)

// Attributes
private:
	CBLE_LocateEditWnd		m_LocateEditWnd;
	CBLE_AdjustWnd			m_AdjustWnd;
	CBLE_MappingWnd			m_MappingWnd;
	CBLE_PassWordWnd		m_PassWordWnd;
	CBLE_SubInfoWnd			m_SubInfoLWnd;
	CBLE_SubInfoWnd			m_SubInfoRWnd;
	CBLE_OptCheckReflect	m_OptCheckReflect;					
//	CWinThread*				m_pProgThread;
//	HANDLE					m_StopThread;
//	DWORD					m_ThreadID;

// Operations
public:
	bool SaveDataProgressBar(); // display progress bar for save
	bool OpenFileProgressBar(CString folderPath); // display progress bar for open
// Overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	afx_msg void OnStartSubWnd(int nID);
	afx_msg void OnArrangeWnd();   //THAIHV 20151123 (E)
	void UpdateDataFromFile();
	virtual BOOL DestroyWindow();
	virtual void OnClose();
	void ChangeMenuLanguage();
	void UpdateSetting();
	void CloseWnd();          //THAIHV 20151123 (C)
	
	// For undo function
	afx_msg void OnRestoreState();
// Implementation
public:
	virtual ~CBLE_FrameWnd();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	
	afx_msg void OnUpdateSubWndCmd(CCmdUI *pCmdUI);
	afx_msg void OnUpdateFileCmd(CCmdUI *pCmdUI);
	afx_msg void OnStartInstance(WPARAM wParam, LPARAM lParam);
	afx_msg void OnColorChange(WPARAM wParam, LPARAM lParam);
	afx_msg void OnInitComplete(WPARAM wParam, LPARAM lParam);
	afx_msg void OnCurrentOpenComplete(WPARAM wParam, LPARAM lParam);
	// Handler for message from TFC
	afx_msg LRESULT OnSubInfoCtrl(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnUpdateOption(WPARAM wParam, LPARAM lParam); // Update window when option data was changed
	
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(EA_B6562A96_D799_49d6_9D3D_DD400472957A__INCLUDED_)

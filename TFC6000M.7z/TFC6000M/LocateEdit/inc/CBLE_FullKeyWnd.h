///////////////////////////////////////////////////////////
//  CBLE_FullKeyWnd.h
//  Implementation of the Class CBLE_FullKeyWnd
//  Created on:      16-Thg7-2013 1:57:46 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_F35E767D_016E_4eba_985A_853A521D96E3__INCLUDED_)
#define EA_F35E767D_016E_4eba_985A_853A521D96E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CBLE_FullKeyWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_FullKeyWnd dialog

class CBLE_FullKeyWnd : public CDialog
{
private:
	// The window to receive key
	CWnd* m_pRevWnd;

// Construction
public:
	CBLE_FullKeyWnd(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_FullKeyWnd();

	enum { IDD = IDD_FKEY_DLG };
	BOOL Create(CWnd* pRevWnd, UINT nIDTemplate, CWnd* pParentWnd = NULL);


// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnCancel();
	virtual void OnOK();

// Implementation
protected:
	afx_msg void OnKey(UINT nID);
	DECLARE_MESSAGE_MAP()
};
#endif // !defined(EA_F35E767D_016E_4eba_985A_853A521D96E3__INCLUDED_)

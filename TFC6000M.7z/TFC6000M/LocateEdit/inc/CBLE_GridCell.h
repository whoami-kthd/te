///////////////////////////////////////////////////////////
//  CBLE_GridCell.h
//  Implementation of the Class CBLE_IC
//  Created on:      12-Thg7-2013 1:52:09 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#pragma once
#include "CBLE_DEF.h"


enum DBLE_CellType
{
	DBLE_CELL_STRING = 0,
	DBLE_CELL_INT,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_TEXT
};


class CBLE_GridCell
{
private:
	DBLE_CellType m_Type;
	int m_Row;
	int m_Col;
	bool m_Header;
	bool m_Merged;
	bool m_Visible;
	//COLORREF m_BkClr;
	COLORREF m_TextClr;
	CString m_Text;
	CString m_OldText;
	CRect m_Region;
	
	// For undo function
	bool m_IsMark;

public:
// Operator
	CBLE_GridCell(int row = -1, int col = -1);
	virtual ~CBLE_GridCell();
	
	// Draw cell
	void Draw(CDC* pDC);
	// Merge cell
	bool Merge(CBLE_GridCell* pCell);
	// Set the region
	void SetRegion(CRect rect);
	// Get the region
	CRect GetRegion();
	// Set cell to the header or normal
	void SetHeader(bool header);
	// Set text
	void SetText(CString text, bool restore = true);
	void RestoreText();
	void SetColor(COLORREF color);
	// Get text
	CString GetText();
	CString GetOldText();

	// Set visible
	void SetVisible(bool visible);

	int GetRow();
	int GetCol();
	bool IsEnable();

	void SetType(DBLE_CellType type);

	// For undo function
	void SetMarkCell(bool mark);
	bool GetMarkCell();
};


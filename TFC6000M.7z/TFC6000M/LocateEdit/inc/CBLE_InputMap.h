//#NhamNV-170825: Add Input Map Name(S)
#if !defined(AFX_BLE_INPUTMAP_H__FD7AF90F_957B_4634_8055_D91E9E04BCB8__INCLUDED_)
#define AFX_BLE_INPUTMAP_H__FD7AF90F_957B_4634_8055_D91E9E04BCB8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_InputMap.h : header file
//

#include "CBLE_Doc.h"

/////////////////////////////////////////////////////////////////////////////
// CMV_InputMap dialog

//class CCMVDlg;
class CBLE_InputMap : public CDialog
{
// Construction
public:
	CBLE_InputMap(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMV_InputMap)
	enum { IDD = IDD_DIALOG_INPUT_MAP };
	CEdit	m_EditMapName;
	//}}AFX_DATA
public:
	CBLE_Doc*	m_pDoc;
	//CCMVDlg*	m_pCMVDlg;
private:
	CString m_strInputMap;

public:
	void SetDocument(CBLE_Doc* pDoc);
	//void SetInfoMapDisp(CCMVDlg* pMapDispDlg);
	//void LoadMapEvent();
	CString GetMapName();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_InputMap)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMV_InputMap)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_INPUTMAP_H__FD7AF90F_957B_4634_8055_D91E9E04BCB8__INCLUDED_)
//#NhamNV-170825: Add Input Map Name (E)
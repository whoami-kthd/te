///////////////////////////////////////////////////////////
//  CBLE_LayoutWnd.h
//  Implementation of the Class CBLE_LayoutWnd
//  Created on:      16-Thg7-2013 1:03:28 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_EDE44FB2_1C4A_45e2_82A7_AE00FED7C554__INCLUDED_)
#define EA_EDE44FB2_1C4A_45e2_82A7_AE00FED7C554__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CBLE_LayoutWnd.h : header file
//

#include "CBLE_Doc.h"

/////////////////////////////////////////////////////////////////////////////
// CBLE_LayoutWnd view

class CBLE_LayoutWnd : public CScrollView
{
public:
	CBLE_LayoutWnd();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CBLE_LayoutWnd)

// Attributes
private:
	CBLE_Doc* m_pDoc;
	int m_RegNo;
	DBLE_MODE m_Mode;
	CRect m_SelectRect;
	bool m_Dragging;
	CPoint m_ClickPnt;
	CPoint m_ScrollPnt;

	// Try to use temporary memoryDC
	CDC m_MemDC;
	CBitmap m_MemBmp;
	double m_Scale;
	int m_SubInfoDir;			// subinfo L or R
	int m_IndexDisplay;			// Display index or not

// Operations
protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	// Draw to memory DC
	void DrawToMemDC();

	// For undo function
	//virtual BOOL PreTranslateMessage(MSG* pMsg);

// Implementation
protected:
	virtual ~CBLE_LayoutWnd();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Create event
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	// Draw event
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	// Mouse event
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg virtual void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg virtual void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg virtual void OnMButtonDown(UINT nFlags, CPoint point);
	afx_msg virtual void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg virtual void OnCaptureChanged(CWnd *pWnd);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnVScroll( UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);//#NhamNV-170830 Handle scroll of layoutWnd
	DECLARE_MESSAGE_MAP()

public:
	void SetDocument(CBLE_Doc* pDoc);
	void SetScale(double scale, bool isZoom);
	void SetMode(DBLE_MODE mode);
	void SetRegNo(int RegNo);
	double GetDrawScale();
	DBLE_MODE GetMode();
	void SetSubInfoDir(int dir);
	int GetIndexDisplay();
	void SetIndexDisplay(int indexDisplay);
	void SetScroll(CBLE_IC *ic);

private:
	CPoint GetRootPoint();
	CRect GetSubstrateRect();
	// Get the center for zooming
	CPoint GetZoomPoint(bool& hasSel, bool isZoom = false);

	// For undo function
	//void OnRestoreState();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(EA_EDE44FB2_1C4A_45e2_82A7_AE00FED7C554__INCLUDED_)

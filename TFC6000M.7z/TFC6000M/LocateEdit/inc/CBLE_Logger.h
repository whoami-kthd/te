///////////////////////////////////////////////////////////
//  CBLE_Logger.h
//  Implementation of the Class CBLE_Logger
///////////////////////////////////////////////////////////
#pragma once

#include "CBLE_DEF.h"
#include "pos.h"

class CBLE_Logger
{
//Attributes declaration
private:
	static CBLE_Logger *m_Logger;

public:
	CWinThread*					m_pProgThread;
	HANDLE						m_ThreadEvent[2];
	CString						m_FileName;
	CString						m_FilePath;
	int							m_Serial;
	vector<CString>				m_vLogText;
	CString						m_Mode;

//Function declaration
private:
	CBLE_Logger();
public:
	static CBLE_Logger* GetInstance();
	void SetLogFormat(CString action, CString type, CString first, CString second);
	void SetLogFormat(CString text);
	static UINT WriteDataToFile(LPVOID pParam);
	CString GetFileName();
	void SetFilePath(CString filePath);
	virtual ~CBLE_Logger();
};

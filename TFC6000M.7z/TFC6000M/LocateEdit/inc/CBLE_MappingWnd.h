///////////////////////////////////////////////////////////
//  CBLE_MappingWnd.h
//  Implementation of the Class CBLE_MappingWnd
//  Created on:      16-Thg7-2013 10:25:37 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_4C28ECD4_1C98_4730_AA65_4038166F23A3__INCLUDED_)
#define EA_4C28ECD4_1C98_4730_AA65_4038166F23A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_FullKeyWnd.h"
#include "CBLE_EditCtrl.h"

#define DBLE_MAPPING_FONT_SIZE			80
#define DBLE_MAPPING_FONT_NAME			_T("MS Sans Serif")
#define DBLE_MAPPING_EDIT_NO			6
// CBLE_MappingWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_MappingWnd dialog

class CBLE_MappingWnd : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CBLE_FullKeyWnd m_KeyWnd;

	int m_BarCodeRead;
	int m_Orientation;
	int m_RefDie;
	int m_Focus;

	// For undo function
	int m_Mark;
	// Edit box
	CBLE_EditCtrl m_Edit;

// Construction
public:
	CBLE_MappingWnd(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_MappingWnd();
	enum { IDD = IDD_MAPPING_DLG };

	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	virtual void OnClose();

	void SetDocument(CBLE_Doc* pDoc);
	void InitView();
	void UpdateView();
	void ChangeLanguage();

	// For undo function
	void RestoreState();
	// function close windows
	void CloseWnd();   //THAIHV 20151124 (C)

// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	afx_msg void OnMappingCancel();
	afx_msg void OnCheckReflect();
	afx_msg virtual void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg virtual void OnPaint();
	LRESULT OnUpdateValue(WPARAM wParam, LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);

// Implementation
protected:

	DECLARE_MESSAGE_MAP()

};
#endif // !defined(EA_4C28ECD4_1C98_4730_AA65_4038166F23A3__INCLUDED_)


#if !defined(AFX_CBLE_PASSWORDCHANGEDLG_H__DF3AEB31_414A_4EA1_AB50_10BC0C3BA6E4__INCLUDED_)
#define AFX_CBLE_PASSWORDCHANGEDLG_H__DF3AEB31_414A_4EA1_AB50_10BC0C3BA6E4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CBLE_PassWordChangeDlg.h : header file
//
#include "CBLE_Doc.h"
#include "CBLE_NumKeyWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CBLE_PassWordChangeDlg dialog

class CBLE_PassWordChangeDlg : public CDialog
{
// Construction
public:
	CBLE_PassWordChangeDlg(CWnd* pParent = NULL);   // standard constructor
	virtual BOOL OnInitDialog();
	void DisplayPasswordLevel();
	void DisplayWarningMessage();
	void PressNumKey(CString& text, UINT key, bool isInteger);
	void ChangeLanguage();
// Dialog Data
	//{{AFX_DATA(CBLE_PassWordChangeDlg)
	enum { IDD = IDD_CHANGEPASSWORD_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
private:
	CBLE_Doc* m_pDoc;
	CBLE_NumKeyWnd m_KeyWnd;
	int m_ID;

public:
	void SetDocument(CBLE_Doc* pDoc);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBLE_PassWordChangeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBLE_PassWordChangeDlg)
	afx_msg void OnChangepasswordExecute();
	afx_msg void OnChangepasswordCancel();
	afx_msg LRESULT OnPressKey(WPARAM wParam, LPARAM lParam); // Response when press a key
	afx_msg void OnSetfocusChangepasswordEnterpass();
	afx_msg void OnSetfocusChangepasswordReentrypass();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CBLE_PASSWORDCHANGEDLG_H__DF3AEB31_414A_4EA1_AB50_10BC0C3BA6E4__INCLUDED_)

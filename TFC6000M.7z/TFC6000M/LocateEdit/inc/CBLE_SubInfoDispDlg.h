///////////////////////////////////////////////////////////
//  CBLE_SubInfoDispDlg.h
//  Implementation of the Class CBLE_SubInfoDispDlg
//  Created on:      2013/09/19
//  Original author: DucDT
///////////////////////////////////////////////////////////
#pragma once

#include "CBLE_DEF.h"
#include "CDialog.h"
#include "CBLE_Doc.h"

#define DBLE_COLORDLG_COLOR_CHOOSE_MES			"Choose color"
#define DBLE_COLORDLG_WIDTH						220
#define DBLE_COLORDLG_HEIGHT					330

class CBLE_SubInfoDispDlg : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CWnd *m_pParentWnd;
	bool	m_bLedMode; //#NhamNV-170830
public:
	CBLE_SubInfoDispDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_SubInfoDispDlg();
	void InitView();
	void SetDocument(CBLE_Doc* pDoc);
	CBLE_Doc* GetDocument();
	void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnChangeDisplayMode(UINT nID);
	afx_msg void OnLedDisplaySts(); //#NhamNV-170830
	DECLARE_MESSAGE_MAP()

// Construction
public:
	enum { IDD = IDD_SUBINFO_DISPLAY_DLG };
	virtual void OnCancel();
	void SetParentWindow(CWnd *parent);
	CStatic m_ledTextSts; //#NhamNV-170830
	
// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	
	
	virtual void OnOK();
	
public:
	void CheckBtnState();
};

/////////////////////////////////////////////////////////////////////////////
// CBLE_ColorDlg dialog

class CBLE_ColorDlg: public CColorDialog
{
private:
	CRect m_Position;

public:
	enum { IDD = IDD_SUBINFO_COLOR_DLG };
	CBLE_ColorDlg(CWnd* pParent = NULL);
	virtual ~CBLE_ColorDlg();
	void SetPosition(int left, int top, int width, int height);
	DECLARE_MESSAGE_MAP()
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	
};
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_DEF.h"

class CBLE_Util
{

public:

	// Rotate a point arround a another point
	static void RotatePoint(double& pX, double& pY, double centerX, double centerY, double angle);

	// Round a float number
	static int Round(double number);

	// Scale a point
	static CPoint ScalePoint(CPoint point, double scale);

	static R2Pos ScaleR2Point(CPoint point, double scale);

	// Scale a size
	static CSize ScaleSize(CSize size, double scale);

	// Scale a rectangle
	static void ScaleR2Rect(CRect rect, double scale, vector<R2Pos> &rectPoint);

	// Check overlapped for 2 polygons
	static bool CheckOverlap(vector<R2Pos> vPnt1, vector<R2Pos> vPnt2);

	// Check intersect of 2 lines
	// Line1: p1, p2
	// Line2: p3, p4
	static bool CheckIntersect(R2Pos p1, R2Pos p2, R2Pos p3, R2Pos p4);

	// Check a point is in the region of a polygon or not
	static bool PointInPolygon(R2Pos point, vector<R2Pos> &vPoly);

	// Compare two double numbers.
	static bool DoubleComparison(double a, double b);

	// Calculate triangle area
	static double TriangleArea(double a, double b, double c);

	// Calculate length of a line segment
	static double SegmentLength(R2Pos point1, R2Pos point2);

	// Convert from R2Pos to CPoint
	static void R2PosToCPoint(vector<R2Pos> point1, vector<CPoint> &point2);

	// Change coordinate of the layout window
	static void ChangeCoordinate(vector<R2Pos> &vPoint);
	
	// Save window place
	static void SaveWindowPlace(CWnd* pWnd, CString appName, CString dialogName);

	// Get window place
	static bool GetWindowPlace(CWnd* pWnd, CString appName, CString dialogName);
};

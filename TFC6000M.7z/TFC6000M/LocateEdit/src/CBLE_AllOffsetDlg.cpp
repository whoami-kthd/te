///////////////////////////////////////////////////////////
//  CBLE_AllOffsetDlg.cpp
//  Implementation of the Class CBLE_AllOffsetDlg
//  Created on:      16-Thg7-2013 1:30:54 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////


#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_AllOffsetDlg.h"
#include "CBLE_Util.h"
#include "CBLE_CareTaker.h"


// Defined for column width of grid control
static long m_arrAllOffColWidth[] = {
	85, 85, 85
};

static DBLE_CellType m_arrAllOffsetColType[] = {
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE
};

enum {
	COLUMN_OFFSET_X = 0,
	COLUMN_OFFSET_Y,
	COLUMN_OFFSET_T,
};

// Define warning message
//#define WARNING_MESSAGE_OUTOFRANGE			_T("Your input is out of limit range! \n Do you want to re-input?")

#define DBLE_ALLOFF_CELL_HEIGHT		22

/////////////////////////////////////////////////////////////////////////////
// Define message text for Japanese and English
//
CString OutOfRange[] =	{							
							_T("���͂������͈͊O�ł��B�ē��͂��܂����H"),
							_T("Your input is out of limit range! \n Do you want to re-input?"),
						};


/////////////////////////////////////////////////////////////////////////////
// CBLE_AllOffsetDlg dialog


CBLE_AllOffsetDlg::CBLE_AllOffsetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_AllOffsetDlg::IDD, pParent)
{
	m_pDoc = NULL;
	m_pGridCtrl = NULL;
	m_OffsetX = _T("");
	m_OffsetY = _T("");
	m_OffsetAng = _T("");
}

CBLE_AllOffsetDlg::~CBLE_AllOffsetDlg()
{

}


void CBLE_AllOffsetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBLE_AllOffsetDlg, CDialog)
	ON_WM_CLOSE()
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateGrid)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_AllOffsetDlg message handlers

void CBLE_AllOffsetDlg::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}


BOOL CBLE_AllOffsetDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect rect;

	// Create grid control
	GetDlgItem(IDC_ALLOFF_GRID)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_pGridCtrl = new CBLE_GridCtrl(2, 3);
	//m_pGridCtrl->SetDocument(m_pDoc);
	m_pGridCtrl->Create(rect, this, m_pDoc);

	// Create key window
	GetDlgItem(IDC_ALLOFF_NUM_KEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(m_pGridCtrl->GetEditWnd(), IDD_NKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);

	// Init grid control
	// Set language for grid cell
	m_pGridCtrl->SetLanguage(m_pDoc->GetData()->m_Init.m_Language);

	// Set width for all cols
	for(UINT idx = 0; idx < ARRAY_LENGTH(m_arrAllOffColWidth); idx ++){
		m_pGridCtrl->SetColWidth(idx, m_arrAllOffColWidth[idx]);
	}
	// Set height for all row
	for(idx = 0; idx < m_pGridCtrl->GetRows(); idx ++){
		m_pGridCtrl->SetRowHeight(idx, DBLE_ALLOFF_CELL_HEIGHT);
	}

	for(idx = 0; idx < ARRAY_LENGTH(m_arrAllOffsetColType); idx ++){
		m_pGridCtrl->SetColType(idx, m_arrAllOffsetColType[idx]);
	}

	// Set header
	m_pGridCtrl->SetRowHeader(0);
	m_pGridCtrl->SetCellText(0, 0, _T("X [mm]"));
	m_pGridCtrl->SetCellText(0, 1, _T("Y [mm]"));
	m_pGridCtrl->SetCellText(0, 2, _T("T [deg]"));
	
	CString strTmp;
	// Offset X
	strTmp.Format(_T("%.4f"), 0);
	m_pGridCtrl->SetCellText(1, 0, strTmp);
	// Offset Y
	strTmp.Format(_T("%.4f"), 0);
	m_pGridCtrl->SetCellText(1, 1, strTmp);
	// IC Angle
	strTmp.Format(_T("%.4f"), 0);
	m_pGridCtrl->SetCellText(1, 2, strTmp);

	return TRUE;
}

void CBLE_AllOffsetDlg::OnClose()
{
	CDialog::OnClose();
}


void CBLE_AllOffsetDlg::OnCancel()
{

	// Reset restore buffer, delete all state of all offset dialog
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore(IDD_ALLOFFSET_DLG);

	CDialog::OnCancel();
}

void CBLE_AllOffsetDlg::OnOK()
{
	// Reset restore buffer, delete all state of all offset dialog
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore(IDD_ALLOFFSET_DLG);

	// Update modified flag
	m_pDoc->SetModifiedFlag(1);
	m_OffsetX = m_pGridCtrl->GetCellText(1, 0);
	m_OffsetY = m_pGridCtrl->GetCellText(1, 1);
	m_OffsetAng = m_pGridCtrl->GetCellText(1, 2);

	// Write log
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_CHECKREFELCT, DBLE_LOGFILE_ALLOFFSET, "");

	CDialog::OnOK();
}

LRESULT CBLE_AllOffsetDlg::OnUpdateGrid(WPARAM wParam, LPARAM lParam)
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	long rowSel = m_pGridCtrl->GetRowSel();
	long colSel = m_pGridCtrl->GetColSel();
	CString tmpText = m_pGridCtrl->GetCellText(rowSel, colSel);
	CString oldText = m_pGridCtrl->GetCell(rowSel, colSel)->GetOldText();

	if (tmpText.Compare(oldText) != 0) {
		
		double value = atof (tmpText);
		// Check input value for offset
		if (colSel == COLUMN_OFFSET_X || colSel == COLUMN_OFFSET_Y) {
			if (value > 9.9 || value < -9.9) {

				//int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
				int nType = theApp.CBTMessageBox(this->m_hWnd, OutOfRange[language], MB_YESNO, language);		// Message: input is not correct

				// Write log file: Input error
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, OutOfRange[language], "", "");

				if (nType == IDYES) {								// Re-input
					m_pGridCtrl->SetCellText(rowSel, colSel, oldText);
					m_pGridCtrl->ShowEditBox();
					return 0;
				} else {
					tmpText = oldText;
				}
			} else {
				// For undo function
				// Store state
				CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
				CBLE_GridStore grid(rowSel, colSel, oldText, IDD_ALLOFFSET_DLG, GRID_TYPE);
				pCareTaker->SetMemento(grid);
			}
		}
		if (colSel == COLUMN_OFFSET_T) {
			if (value < -360 || value > 360) {

				//int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
				int nType = theApp.CBTMessageBox(this->m_hWnd, OutOfRange[language], MB_YESNO, language);
				// Write log file: missing value
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, OutOfRange[language], "", "");

				if (nType == IDYES) {								// Re-input
					//m_pGridCtrl->SetCellText(row, col, oldText);
					// Set cell to blank but doesn't change old text
					m_pGridCtrl->SetCellText(rowSel, colSel, oldText);
					m_pGridCtrl->ShowEditBox();
					return 0;
				} else {
					tmpText = oldText;
				}
			} else {
				// For undo function
				// Store state
				CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
				CBLE_GridStore grid(rowSel, colSel, oldText, IDD_ALLOFFSET_DLG, GRID_TYPE);
				pCareTaker->SetMemento(grid);
			}
		}
		m_pGridCtrl->SetCellText(rowSel, colSel, tmpText/*, wParam == IDC_NKEY_ENT*/);
		
	}
	//m_pGridCtrl->Deselect();
	// #DucDT131108: Move to next cell
	// Move to next collumn

	// Focus on AllOffset dialog
	SetFocus();
	if (colSel + 1 < m_pGridCtrl->GetCols()) {
		m_pGridCtrl->SetCellSel(rowSel, colSel + 1);
	} else {
		m_pGridCtrl->Deselect();
		
	}
	Invalidate();
	return 0;
}

void CBLE_AllOffsetDlg::GetAllOffset(CString& offX, CString& offY, CString& offAng)
{
	offX.Format(_T("%.4f"), atof(m_OffsetX));
	offY.Format(_T("%.4f"), atof(m_OffsetY));
	offAng.Format(_T("%.4f"), atof(m_OffsetAng));
}

/**
* Restore function
*/
void CBLE_AllOffsetDlg::OnRestoreState()
{
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	if (!pCareTaker->Restoreable() || pCareTaker->GetLastKind() != IDD_ALLOFFSET_DLG) {
		return;
	}
	CBLE_Memento mem = pCareTaker->GetMemento();
	void* tmp = mem.GetState();
	vector<TBLE_GridData> *v_Grid = static_cast<vector<TBLE_GridData> *>(tmp);
	TBLE_GridData grid = v_Grid->at(0);
	CString resVal = m_pGridCtrl->GetCellText(grid.row, grid.col);
	m_pGridCtrl->SetCellText(grid.row, grid.col, grid.val);
	
	// Clear marked cells
	m_pGridCtrl->ResetMarkCells();
	// Mark cell
	m_pGridCtrl->SetMarkCell(grid.row, grid.col);
	// Move scroll
	m_pGridCtrl->MoveScrollCell(grid.row, grid.col);

	Invalidate();
	delete v_Grid;
}

/**
* Catch Ctrl + Z to restore
*/
BOOL CBLE_AllOffsetDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN /*&& pMsg->wParam == VK_CONTROL*/){
		if ((GetKeyState(0x5A) & 0x8000) && (GetKeyState(VK_CONTROL) & 0x8000)) {
			OnRestoreState();
		}
    }		
    return CDialog::PreTranslateMessage(pMsg);
}
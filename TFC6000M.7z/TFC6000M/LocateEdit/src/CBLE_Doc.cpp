///////////////////////////////////////////////////////////
//  CBLE_Doc.cpp
//  Implementation of the Class CBLE_Doc
//  Created on:      16-Thg7-2013 9:40:09 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////
#include "stdafx.h"
#include "..\\BLE.h"
#include "swatch.h"

#include "CBLE_Doc.h"
#include "CBLE_View.h"
#include "CBLE_FrameWnd.h"
#include "CBLE_FileOpenDlg.h"
//#include "CBLE_MessageDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define DBLE_DOC_TIMEOUT						10000
 
/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString ComplexInvalid[] =		{							
									_T("���uTP��SubstIndex��Subject��Complex�ɂȂ��Ă��܂���."),
									_T("Subject of SubstIndex is not Complex in TP equipment"),
								};

CString SaveInvalid[] =			{							
									_T("�ҏW����Data���ۑ�����Ă��܂���,���s���܂���?"),
									_T("Data is not saved, do you want to continue?"),
								};

CString EditININotFound[] =		{
									_T("EditMode.ini�t�@�C���͌�����܂���B\n�f�t�H���g�̒l�Ŏ��s���܂����H"),
									_T("EditMode.ini is not found. Do you want to run with default value setting?"),
								};

CString SubInfoININotFound[] =	{
									_T("SubInfo.ini�t�@�C���͌�����܂���B\n�f�t�H���g�̒l�Ŏ��s���܂����H"),
									_T("Your input is out of limit range! \n Do you want to re-input?"),
								};

CString SaveMessage[] =			{
									_T("�i��[%s]�������݂܂���?"),
									_T("Is the device [%s] written?"),
								};

CString CurrentOpen[] =			{
									_T("�i��[%s]��Ǎ��݂܂���?"),
									_T("Is the device [%s] read?"),
								};

CString MachineRunning[] =		{
									_T("�}�V�������s���Ă��܂��I"),
									_T("Machine is running"),
								};

CString TimeOut[] =				{
									_T("�^�C���A�E�g�I"),
									_T("Time out!"),
								};

CString SaveNotDone[] =			{
									_T("�f�[�^�̕ۑ����������Ă��܂���B������x��蒼���Ă�������"),
									_T("Saving data is not completed. Please try again."),
								};

CString SaveRequest[] =			{
									_T("�f�[�^�𑶍݂��܂����H"),
									_T("Do you want to save data?"),
								};
CString MissingLangFile[] =		{
									_T("LocateEdit.japan�t�@�C���͌�����܂���B\n�f�t�H���g���ꂪ�g���܂��B"),
									_T("File LocateEdit.japan is not found! Default language will be used!"),
								};
CString BrowseForFolder[] =		{
									_T("�t�H���_�̎Q��"),
									_T("Browse For Folder"),
								};
CString SelectAFolder[]=		{
									_T("�t�H���_��I��"),
									_T("Select a folder"),
								};
CString CancelButton[]=			{
									_T("�L�����Z��"),
									_T("Cancel"),
								};

CString CannotOpen[] =			{
									_T("BIN�^�œǂݍ��݂ł��܂���B"),
									_T("Can not open binary file!"),
								};
CString CannotSave[] =			{
									_T("BIN�^�ŏ������݂ł��܂���B"),
									_T("Can not save binary file!"),
								};
CString CannotInitSubInfo[] =	{							
									_T("�f�[�^���[�h�ł��܂���B�J�����g�J���ōă��[�h���Ă��������B"),
									_T("Cannot open this data. Reload data again with CurrentOpen"),
								};
CString BinaryError[] =			{							
									_T("�o�C�i���t�@�C���̓G���[������܂��B"),
									_T("Error when read binary file."),
								};
/////////////////////////////////////////////////////////////////////////////
// CBLE_Doc

IMPLEMENT_DYNCREATE(CBLE_Doc, CDocument)

BEGIN_MESSAGE_MAP(CBLE_Doc, CDocument)
	//{{AFX_MSG_MAP(CBLE_Doc)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_CURRENTOPEN, OnCurrentOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_Doc construction/destruction

CBLE_Doc::CBLE_Doc()
{
	m_Mode = 0;
	m_Count = 0;
	m_User = DBLE_USER_LEVEL2;

	m_pInitDataThread	= NULL;
	m_pCurrentOpenThread = NULL;
	m_bIsSaving			= false;

	m_Handle[0]			= CreateEvent(NULL, false, false, "OK");
	m_Handle[1]			= CreateEvent(NULL, false, false, "NG");

	m_InitHandle[0]		= CreateEvent(NULL, false, false, "Init-OK");
	m_InitHandle[1]		= CreateEvent(NULL, false, false, "Init-NG");

	m_CurrentOpenHandle[0]		= CreateEvent(NULL, false, false, "CurrentOpen-OK");
	m_CurrentOpenHandle[1]		= CreateEvent(NULL, false, false, "CurrentOpen-NG");

	m_TFCRespond		= false;
	m_FilePath			= "";

	m_DialogItems[0]		=	TBLE_Language(IDC_COMM_DEVNAME,						"IDC_COMM_DEVNAME",							"");
	m_DialogItems[1]		=	TBLE_Language(IDC_COMM_BTN_CHECK,					"IDC_COMM_BTN_CHECK",						"");
	m_DialogItems[2]		=	TBLE_Language(IDC_COMM_STATICSHAPE,					"IDC_COMM_STATICSHAPE",						"");
	m_DialogItems[3]		=	TBLE_Language(IDC_COMM_LBL_TITLE,					"IDC_COMM_LBL_TITLE",						"");
	m_DialogItems[4]		=	TBLE_Language(IDC_LEDIT_DEL_BTN,					"IDC_LEDIT_DEL_BTN",						"");
	m_DialogItems[5]		=	TBLE_Language(IDC_LEDIT_REST_BTN,					"IDC_LEDIT_REST_BTN",						"");
	m_DialogItems[6]		=	TBLE_Language(IDC_LEDIT_LBL_DISP,					"IDC_LEDIT_LBL_DISP",						"");
	m_DialogItems[7]		=	TBLE_Language(IDC_LEDIT_DISP_BTN,					"IDC_LEDIT_DISP_BTN",						"");
	m_DialogItems[8]		=	TBLE_Language(IDC_LEDIT_CHECK_BTN,					"IDC_LEDIT_CHECK_BTN",						"");
	m_DialogItems[9]		=	TBLE_Language(IDC_LEDIT_STATICZOOM,					"IDC_LEDIT_STATICZOOM",						"");
	m_DialogItems[10]		=	TBLE_Language(IDC_LEDIT_LBL_TOOLS,					"IDC_LEDIT_LBL_TOOLS",						"");
	m_DialogItems[11]		=	TBLE_Language(IDC_LEDIT_LBL_OPERATION,				"IDC_LEDIT_LBL_OPERATION",					"");
	m_DialogItems[12]		=	TBLE_Language(IDC_LEDIT_ALLRESTORE,					"IDC_LEDIT_ALLRESTORE",						"");
	m_DialogItems[13]		=	TBLE_Language(IDC_LEDIT_LBL_LOCATEEDIT,				"IDC_LEDIT_LBL_LOCATEEDIT",					"");
	m_DialogItems[14]		=	TBLE_Language(IDC_ADJ_MOVE_BTN,						"IDC_ADJ_MOVE_BTN",							"");
	m_DialogItems[15]		=	TBLE_Language(IDC_ADJ_EXPAND_BTN,					"IDC_ADJ_EXPAND_BTN",						"");
	m_DialogItems[16]		=	TBLE_Language(IDC_ADJ_STATICZOOM,					"IDC_ADJ_STATICZOOM",						"");
	m_DialogItems[17]		=	TBLE_Language(IDC_ADJ_LBL_TOOLS,					"IDC_ADJ_LBL_TOOLS",						"");
	m_DialogItems[18]		=	TBLE_Language(IDC_ADJ_LBL_OPERATION,				"IDC_ADJ_LBL_OPERATION",					"");
	m_DialogItems[19]		=	TBLE_Language(IDC_ADJ_CLEAR_OFFSET,					"IDC_ADJ_CLEAR_OFFSET",						"");
	m_DialogItems[20]		=	TBLE_Language(IDC_ADJ_INDEX_DISPLAY_BTN,			"IDC_ADJ_INDEX_DISPLAY_BTN",				"");
	m_DialogItems[21]		=	TBLE_Language(IDC_OFFSET_ALL,						"IDC_OFFSET_ALL",							"");
	m_DialogItems[22]		=	TBLE_Language(IDC_CHANGEPASSWORD_STATICENTERPASS,	"IDC_CHANGEPASSWORD_STATICENTERPASS",		"");
	m_DialogItems[23]		=	TBLE_Language(IDC_CHANGEPASSWORD_STATICREENTRYPASS,	"IDC_CHANGEPASSWORD_STATICREENTRYPASS",		"");
	m_DialogItems[24]		=	TBLE_Language(IDC_CHANGEPASSWORD_EXECUTE,			"IDC_CHANGEPASSWORD_EXECUTE",				"");
	m_DialogItems[25]		=	TBLE_Language(IDC_CHANGEPASSWORD_LEVEL1,			"IDC_CHANGEPASSWORD_LEVEL1",				"");
	m_DialogItems[26]		=	TBLE_Language(IDC_CHANGEPASSWORD_LEVEL2,			"IDC_CHANGEPASSWORD_LEVEL2",				"");
	m_DialogItems[27]		=	TBLE_Language(IDC_CHANGEPASSWORD_LEVEL3,			"IDC_CHANGEPASSWORD_LEVEL3",				"");
	m_DialogItems[28]		=	TBLE_Language(IDC_CHANGEPASSWORD_CANCEL,			"IDC_CHANGEPASSWORD_CANCEL",				"");
	m_DialogItems[29]		=	TBLE_Language(IDC_INFO_INDEX_JUMP,					"IDC_INFO_INDEX_JUMP",						"");
	m_DialogItems[30]		=	TBLE_Language(IDC_INFO_LBL_TITLE,					"IDC_INFO_LBL_TITLE",						"");
	m_DialogItems[31]		=	TBLE_Language(IDC_PASSWORD_STATICPASS,				"IDC_PASSWORD_STATICPASS",					"");
	m_DialogItems[32]		=	TBLE_Language(IDC_PASSWORD_LEVELDOWN,				"IDC_PASSWORD_LEVELDOWN",					"");
	m_DialogItems[33]		=	TBLE_Language(IDC_PASSWORD_CHANGEPASSWORD,			"IDC_PASSWORD_CHANGEPASSWORD",				"");
	m_DialogItems[34]		=	TBLE_Language(IDC_PASSWORD_LEVEL1,					"IDC_PASSWORD_LEVEL1",						"");
	m_DialogItems[35]		=	TBLE_Language(IDC_PASSWORD_LEVEL2,					"IDC_PASSWORD_LEVEL2",						"");
	m_DialogItems[36]		=	TBLE_Language(IDC_PASSWORD_LEVEL3,					"IDC_PASSWORD_LEVEL3",						"");
	m_DialogItems[37]		=	TBLE_Language(IDC_MAPP_REF_GROUP,					"IDC_MAPP_REF_GROUP",						"");
	m_DialogItems[38]		=	TBLE_Language(IDC_MAPPING_CANCEL_BTN,				"IDC_MAPPING_CANCEL_BTN",					"");
	m_DialogItems[39]		=	TBLE_Language(IDC_INFO_INDEX_SENDTFC,				"IDC_INFO_INDEX_SENDTFC",					"");
}

CBLE_Doc::~CBLE_Doc()
{
	::CloseHandle(m_Handle[0]);
	::CloseHandle(m_Handle[1]);

	::CloseHandle(m_InitHandle[0]);
	::CloseHandle(m_InitHandle[1]);
	if (m_pInitDataThread != NULL){
		::WaitForSingleObject(m_pInitDataThread->m_hThread, INFINITE);
		delete m_pInitDataThread;
	}

	::CloseHandle(m_CurrentOpenHandle[0]);
	::CloseHandle(m_CurrentOpenHandle[1]);
	if (m_pCurrentOpenThread != NULL){
		::WaitForSingleObject(m_pCurrentOpenThread->m_hThread, INFINITE);
		delete m_pCurrentOpenThread;
	}

}


// Initialize document thread
void CBLE_Doc::InitDoc()
{
	m_pInitDataThread = AfxBeginThread(
		InitDataThread,					// worker thread
		this,							// param
		THREAD_PRIORITY_NORMAL,			// priority: normal
		0,								// stack size: same as creating thread
		CREATE_SUSPENDED,				// create flag: don't start immediately
		NULL							// security: same as creating thread
		);
	if (m_pInitDataThread) {
		// Don't auto delete after thread terminated
		m_pInitDataThread->m_bAutoDelete = FALSE;
		// Start thread
		m_pInitDataThread->ResumeThread();
	}
}

UINT CBLE_Doc::InitDataThread(LPVOID pParam)
{
	CBLE_Doc *pDoc = (CBLE_Doc*)pParam;
	pDoc->InitDocThread();
	return 0;
}

void CBLE_Doc::InitDocThread()
{
	// Get path of Application
	char buf[BUFSIZ];
	GetModuleFileName(NULL, buf, BUFSIZ - 1);	
	CString filePath = buf;
	CString AppName(AfxGetAppName());
#if _DEBUG
	filePath.Replace("Debug\\", "");
#endif
	AppName += ".exe";
	filePath.Replace(AppName, "");
	
	GetLanguageString(filePath);

	// Set file path for log file
	theApp.p_Logger->SetFilePath(filePath);

	// Edit mode setting file path
	CString strEditIniFilePath		= filePath + EDIT_INI_NAME;
	// Check file exist
	while (GetFileAttributes(strEditIniFilePath) == 0xFFFFFFFF) {
		// Write log file: missing EditMode.ini
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, EditININotFound[DBLE_LANGUAGE_JAPANESE/*default is japanese*/], "", "");

		//if (AfxMessageBox(DBLE_DOC_EDITINI_NOTFOUND_MESS_ENG, MB_OKCANCEL) == IDCANCEL) {
		if (theApp.CBTMessageBox(NULL, EditININotFound[DBLE_LANGUAGE_JAPANESE/*default is japanese*/], MB_OKCANCEL, GetData()->m_Init.m_Language) == IDCANCEL) {
			//CFileDialog open(true, NULL, NULL);
			CBLE_FileOpenDlg open(true, NULL, NULL);
			open.m_Language = GetData()->m_Init.m_Language;
			int iRet = open.DoModal();
			if (iRet == IDOK) {
				strEditIniFilePath = open.GetPathName();
			}
		} else {
			break;
		}
	}

	// Set setting path (EditMode.ini) file
	m_Data.SetLocateEditIniFilePath(strEditIniFilePath);

	// Initialize edit mode setting
	m_Data.InitEditModeSetting();

	HWND editInstance, subInfoInstance;
	editInstance = FindWindow(NULL, DBLE_FRAMENAME_EDITMODE);
	subInfoInstance = FindWindow(NULL, DBLE_FRAMENAME_SUBINFOMODE);

	// Initialize document for edit mode
	if (m_Mode == DBLE_EDIT_MODE) {

		// Set data file path as same in current file path
		m_Data.SetDataFilePath(m_Data.m_Init.m_CurrentOpen);
		
	} else if (m_Mode == DBLE_SUBINFO_MODE) {	// initialize document for subinfo mode
		// SubInfo mode setting file path
		CString strSubInfoIniFilePath	= filePath + SUBINFO_INI_NAME;
		while (GetFileAttributes(strSubInfoIniFilePath) == 0xFFFFFFFF) {
			
			// Write log file: missing ini
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, SubInfoININotFound[DBLE_LANGUAGE_JAPANESE/*default is japanese*/], "", "");
			
			//if (AfxMessageBox(DBLE_DOC_SUBINFOINI_NOTFOUND_MESS_ENG, MB_OKCANCEL) == IDCANCEL) {
			if (theApp.CBTMessageBox(NULL, SubInfoININotFound[DBLE_LANGUAGE_JAPANESE/*default is japanese*/], MB_OKCANCEL, GetData()->m_Init.m_Language) == IDCANCEL) {
				
				//CFileDialog open(true, NULL, NULL);
				CBLE_FileOpenDlg open(true, NULL, NULL);
				open.m_Language = GetData()->m_Init.m_Language;
				int iRet = open.DoModal();
				if (iRet == IDOK) {
					strSubInfoIniFilePath = open.GetPathName();
				}
			} else {
				break;
			}
		}

		// Set setting file path (SubInfo.ini)
		m_Data.SetSubInfoIniFilePath(strSubInfoIniFilePath);

		// Initialize subinfo mode setting
		m_Data.InitSubInfoModeSetting();

		// Set data file path as same in FCB.ini
		m_Data.SetDataFilePath();

		if (m_Data.GetDataFilePath().Compare(m_Data.m_Init.m_CurrentOpen) != 0 || editInstance == NULL) {
			// Can initialize subInfo mode
			// Nothing to do

		} else {		// Ask EditMode is saving or not?

			// Reset event before send message
			ResetEvent(m_InitHandle[0]);
			ResetEvent(m_InitHandle[1]);

			// Post message to EditMode
			PostMessage(editInstance, BLE_CTRL, BLE_SUBINFO_INIT, ++m_Count);
			// Wait response from EditMode
			DWORD result = WaitForMultipleObjects(2, &m_InitHandle[0], false, DBLE_DOC_TIMEOUT);
			
			// Handle answer from EditMode
			// If message response is OK
			if (result == WAIT_OBJECT_0) {
				m_bIsSaving = false;
			} else if (result == WAIT_OBJECT_0 + 1) {
				// NG
				m_bIsSaving = true;
			} else {
				// Time out
				m_bIsSaving = true;
			} 
		}
	}

	// Set machine file path
	m_Data.SetMachineFilePath();

	// Check machine data file path
	m_Data.FileNotFound(m_Data.GetMachineFilePath());

	// Ask main thread refresh layout
	if ((m_Mode == DBLE_SUBINFO_MODE) && (subInfoInstance != NULL)) {
		PostMessage(subInfoInstance, WM_INIT_COMPLETE, 0, 0);
	} else if ((m_Mode == DBLE_EDIT_MODE) && (editInstance != NULL)) {
		PostMessage(editInstance, WM_INIT_COMPLETE, 0, 0);
	}
}

void CBLE_Doc::InitDocData()
{
	if (!m_bIsSaving) {

		// Open with 191 file
		m_FilePath = m_Data.GetDataFilePath() + "\\" + DBLE_BINARY_FILE;
		if (GetFileAttributes(m_FilePath) == 0xFFFFFFFF) {	
			POSITION pos = GetFirstViewPosition();
			CBLE_View* view = (CBLE_View*) this->GetNextView(pos);
			CBLE_FrameWnd *frame = (CBLE_FrameWnd *)view->GetParentFrame();
			frame->OpenFileProgressBar(m_Data.GetDataFilePath());
		} else {
			// Read from binary file
			CFile bleFile;
			if (!bleFile.Open(m_FilePath, CFile::modeRead)) {
				theApp.CBTMessageBox(NULL, CannotOpen[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
				return;
			}
			CArchive ar(&bleFile, CArchive::load);
			Serialize(ar);
			ar.Close();
			bleFile.Close();
		}
	} else {
		theApp.CBTMessageBox(NULL, CannotInitSubInfo[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
	}
	// Warning user current folder is not in complex mode
	if (!m_Data.GetSubComplexMode()) {
		//AfxMessageBox(DBLE_DOC_COMPLEX_INVALID_ENG, MB_OK);
		theApp.CBTMessageBox(NULL, ComplexInvalid[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
		// Write log file: invalid complex
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ComplexInvalid[GetData()->m_Init.m_Language], "", "");
	}
	m_vZoom.clear();
	int numZoom = this->m_Data.m_Init.m_numberOfZoom;
	for(UINT idx = 0; idx < numZoom; idx ++){
		m_vZoom.push_back(this->m_Data.m_Init.m_ZoomRatio[idx]);
	}
	m_DeviceName = GetDeviceNameFromPath(m_Data.GetDataFilePath());
	m_User = DBLE_USER_LEVEL2;
	m_Password = this->m_Data.m_Init.m_PassLevel2;
}

BOOL CBLE_Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	
	SetTitle(DBLE_DIALOGNAME_APPNAME);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_Doc serialization

void CBLE_Doc::Serialize(CArchive& ar)
{
	/*
	if (ar.IsStoring())
	{
		m_Data.Serialize(ar);
	}
	else
	{
		m_Data.Serialize(ar);
	}*/
// #DUCDT131122: Add handle when binary file has error.
	TRY{
		m_Data.Serialize(ar);
	} CATCH(CArchiveException, ex) {
		// Warning user
		theApp.CBTMessageBox(NULL, BinaryError[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
		// Write log file: binary error
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, BinaryError[GetData()->m_Init.m_Language], "", "");

		// If loading data
		if (ar.IsLoading()) {
			// Reset data
			GetData()->m_vRegIC.clear();
			GetData()->GetSubstrate()->ResetData();

			// Re-load data with dv_.*90 file
			POSITION pos = GetFirstViewPosition();
			CBLE_View* view = (CBLE_View*) this->GetNextView(pos);
			CBLE_FrameWnd *frame = (CBLE_FrameWnd *)view->GetParentFrame();
			frame->OpenFileProgressBar(m_Data.GetDataFilePath());
		}
	}
	END_CATCH
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_Doc diagnostics

#ifdef _DEBUG
void CBLE_Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CBLE_Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBLE_Doc commands

BOOL CBLE_Doc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	// TODO: Add your specialized creation code here
	
	return TRUE;
}

BOOL CBLE_Doc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDocument::OnSaveDocument(lpszPathName);
}

void CBLE_Doc::OnCloseDocument() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CDocument::OnCloseDocument();
}

CBLE_Model* CBLE_Doc::GetData()
{
	return &m_Data;
}


CString CBLE_Doc::GetDeviceName()
{
	return m_DeviceName;
}

bool CBLE_Doc::IsSavingData()
{
	return m_bIsSaving;
}

void CBLE_Doc::OnFileOpen() 
{
	// Check data is saved?
	if (IsModified()) {
		CString mes;
		mes.Format(SaveInvalid[GetData()->m_Init.m_Language], m_DeviceName);
		//if (AfxMessageBox(mes, MB_YESNO) == IDNO) {
		if (theApp.CBTMessageBox(NULL, mes, MB_YESNO, GetData()->m_Init.m_Language) == IDNO) {
			return;
		}
	}

	StopWatch	swOpen;swOpen.Start(TRUE);
	TRACE("[MENU][File][Open]\n");
	POSITION pos = GetFirstViewPosition();
	CBLE_View* view = (CBLE_View*) this->GetNextView(pos);
	CBLE_FrameWnd *frame = (CBLE_FrameWnd *)view->GetParentFrame();
	
	CString szPath;

	// Browse folder to open
	if (BrowseFolder(szPath)) {

		// Check subComplex mode
		int isSubComplex = 0;
		GetData()->GWPPfileData(szPath + "\\" + DBLE_MODEL_DV100_NAME, "FC����� �i���ް�(����ިݸ��Ư�)����ިݸ��Ư�:�ڰѐ����ް�_L", "SubstComplex(0:Simple 1:Complex)", true, isSubComplex, 1);
		if (isSubComplex == 0) {
			//AfxMessageBox(DBLE_DOC_COMPLEX_INVALID_ENG, MB_OK);
			theApp.CBTMessageBox(NULL, ComplexInvalid[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
			// Write log file: invalid complex
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ComplexInvalid[GetData()->m_Init.m_Language], "", "");
			return;
		} 

		// Set data path: Write file path to EditMode.ini for next open
		GetData()->SetDataFilePath(szPath);

		// Get device name
		m_DeviceName = GetDeviceNameFromPath(szPath);

		// Get file path of file .191
		m_FilePath = szPath + "\\" + DBLE_BINARY_FILE;

		if (GetFileAttributes(m_FilePath) == 0xFFFFFFFF) {	
			// Display progress bar when open file
			frame->OpenFileProgressBar(szPath); // display progress bar
			
		} else {
			// Read data from binary file
			CFile bleFile;
			if (!bleFile.Open(m_FilePath, CFile::modeRead)) {
				theApp.CBTMessageBox(NULL, CannotOpen[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
				return;
			}
			CArchive ar(&bleFile, CArchive::load);
			Serialize(ar);
			ar.Close();
			bleFile.Close();
		}
		//Ask current window to display new data
		frame->UpdateDataFromFile();
		// Reset modify flag
		SetModifiedFlag(0);
	}

	// Write log: Load
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_LOAD, GetDeviceName(), "");
	TRACE("[Open]  CBLE_ Doc::On FileOpen()check time=%dm:%ds(%d)\n",swOpen.readMin(),swOpen.readSec(),swOpen.Read()/1000);
}

void CBLE_Doc::OnCurrentOpen()
{
	m_pCurrentOpenThread = AfxBeginThread(
		CurrentOpenDataThread,			// worker thread
		this,							// param
		THREAD_PRIORITY_NORMAL,			// priority: normal
		0,								// stack size: same as creating thread
		CREATE_SUSPENDED,				// create flag: don't start immediately
		NULL							// security: same as creating thread
		);
	if (m_pCurrentOpenThread) {
		// Don't auto delete after thread terminated
		m_pCurrentOpenThread->m_bAutoDelete = FALSE;
		// Start thread
		m_pCurrentOpenThread->ResumeThread();
	}
	
}

UINT CBLE_Doc::CurrentOpenDataThread(LPVOID pParam)
{
	CBLE_Doc *pDoc = (CBLE_Doc*)pParam;
	pDoc->SubInfoCurrentOpen();
	return 0;
}

void CBLE_Doc::SubInfoCurrentOpen()
{
	
	TRACE("[MENU][File][CrrentOpen]\n");

// #DUCDT131114: Need to ask BLE-Edit if current is SubInfo mode
	HWND editInstance, subInfoInstance;
	editInstance = FindWindow(NULL, DBLE_FRAMENAME_EDITMODE);
	subInfoInstance = FindWindow(NULL, DBLE_FRAMENAME_SUBINFOMODE);
	
	if (m_Mode == DBLE_SUBINFO_MODE) {
		if (m_Data.GetDataFilePath().Compare(m_Data.m_Init.m_CurrentOpen) != 0 || editInstance == NULL) {
			// Can open subInfo mode
			m_bIsSaving = false;
		} else {		// Ask EditMode is saving or not?

			// Reset event before send message
			ResetEvent(m_CurrentOpenHandle[0]);
			ResetEvent(m_CurrentOpenHandle[1]);

			// Post message to EditMode
			PostMessage(editInstance, BLE_CTRL, BLE_SUBINFO_CUROPEN, ++m_Count);

			// Wait response from EditMode
			DWORD result = WaitForMultipleObjects(2, &m_CurrentOpenHandle[0], false, DBLE_DOC_TIMEOUT);

			// If message response is OK
			if (result == WAIT_OBJECT_0) {
				TRACE("Current open thread succeed to open\n");
				m_bIsSaving = false;
			} else if (result == WAIT_OBJECT_0 + 1) {
				// NG
				TRACE("Current open thread failt to open\n");
				m_bIsSaving = true;
			} else {
				// Time out
				TRACE("Current open thread time out\n");
				m_bIsSaving = true;
			}
		}
	}

	// Ask main thread refresh layout
	if ((m_Mode == DBLE_SUBINFO_MODE) && (subInfoInstance != NULL)) {
		PostMessage(subInfoInstance, WM_CURROPEN_COMPLETE, 0, 0);
	} else if ((m_Mode == DBLE_EDIT_MODE) && (editInstance != NULL)) {
		PostMessage(editInstance, WM_CURROPEN_COMPLETE, 0, 0);
	}

}

void CBLE_Doc::OnFileSave() 
{
// #DUCDT131122: Check complex mode before save data
	int isSubComplex = GetData()->GetSubComplexMode();
	if (isSubComplex == 0) {
		//AfxMessageBox(DBLE_DOC_COMPLEX_INVALID_ENG, MB_OK);
		theApp.CBTMessageBox(NULL, ComplexInvalid[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
		// Write log file: invalid complex
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ComplexInvalid[GetData()->m_Init.m_Language], "", "");
		return;
	}
	m_bIsSaving = true;

	m_FilePath = GetData()->GetDataFilePath() + "\\" + DBLE_BINARY_FILE;
// #DUCDT131122: Only save data to file after get write permission from TFC
/*
	CFile bleFile;
	if (bleFile.Open(m_FilePath, CFile::modeCreate | CFile::modeWrite)) {
		CArchive ar(&bleFile, CArchive::store);
		Serialize(ar);
		ar.Close();
		bleFile.Close();
	} else {
		theApp.CBTMessageBox(NULL, CannotSave[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
	}
*/	
	// Write log
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_SAVE, GetDeviceName(), "");
	
	//Ask frame window to display progress bar and save data
	POSITION pos = GetFirstViewPosition();
	CBLE_View* view = (CBLE_View*) this->GetNextView(pos);
	CBLE_FrameWnd *frame = (CBLE_FrameWnd *)view->GetParentFrame();
	bool r = frame->SaveDataProgressBar(); // display progress bar

	if (!r) {
		//AfxMessageBox("Saving data is not completed. Please try again.");
		theApp.CBTMessageBox(NULL, SaveNotDone[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
		// Write log file:
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, SaveNotDone[GetData()->m_Init.m_Language], "", "");
	}
	return;
}

bool CBLE_Doc::SaveData()
{
	StopWatch	swSave;swSave.Start(TRUE);
	TRACE("[MENU][File][Save]\n");
	bool r = true;
	CString tfcFilePath;
	// Get data file path of TFC
	m_Data.GWPPfileData(FCB_INIT_FILE_PATH, "FCB���ް�", "�i���ް��߽��", true, tfcFilePath, CString(""));
	// Get data file path of LocateEdit
	CString filePath = m_Data.GetDataFilePath();
	// Compare 2 data file path
	// If equal, find TFC window to check it in autorun mode or not
	HWND tfcInstance;
	// Find TFC window
	tfcInstance = FindWindow(NULL, TFC_FRAMENAME);

	if (tfcFilePath.Compare(filePath) == 0) {
		// If exist
		if (tfcInstance != (HWND)NULL) {
			// Reset event before send message
			ResetEvent(m_Handle[0]);
			ResetEvent(m_Handle[1]);
			// Send message to TFC to get state of TFC
			PostMessage(tfcInstance, WM_TFC_CTRL, BLE_CAN_SAVE_FILE, ++m_Count);
			DWORD result = WaitForMultipleObjects(2, &m_Handle[0], false, DBLE_DOC_TIMEOUT);
			m_TFCRespond = true;
			// If event is OK
			if (result == WAIT_OBJECT_0) {
				r = true;
			} else if (result == WAIT_OBJECT_0 + 1) {	// Not good reply message
				//AfxMessageBox(DBLE_DOC_MACHINE_RUNNING_MESS, MB_OK);
				theApp.CBTMessageBox(NULL, MachineRunning[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
				r = false;
				
			} else if (result == WAIT_TIMEOUT) {	// time out
				//AfxMessageBox(DBLE_DOC_TIMEOUT_MESS, MB_OK);
				theApp.CBTMessageBox(NULL, TimeOut[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
				r = false;
			}
		}
	}
	
	// Update title for progress bar
	m_TFCRespond = true;

	if (r) {
		CString mes;
		mes.Format(SaveMessage[GetData()->m_Init.m_Language], m_DeviceName);
		//if (AfxMessageBox(mes, MB_YESNO) == IDNO) {
		if (theApp.CBTMessageBox(NULL, mes, MB_YESNO, GetData()->m_Init.m_Language) == IDNO) {
			r = false;
		} else {
// #DUCDT131122: Write binary file
			CFile bleFile;
			if (bleFile.Open(m_FilePath, CFile::modeCreate | CFile::modeWrite)) {
				CArchive ar(&bleFile, CArchive::store);
				Serialize(ar);
				ar.Close();
				bleFile.Close();
			} else {
				theApp.CBTMessageBox(NULL, CannotSave[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
			}

			// Write dv_.*90 file
			r = GetData()->SaveDataToFile();

			// Data is saved
			SetModifiedFlag(0);

			// Announce finish save data to TFC
			if (tfcFilePath.Compare(filePath) == 0 && tfcInstance != (HWND)NULL) {
				PostMessage(tfcInstance, WM_TFC_CTRL, BLE_SAVE_FILE_DONE, 0);
			}
		}
	}

	m_bIsSaving = false;
	m_TFCRespond = false; // reset

	TRACE("[Save]  CBLE_ Doc::On FileSave()check time=%dm:%ds(%d)\n",swSave.readMin(),swSave.readSec(),swSave.Read()/1000);

	return r;
}

void CBLE_Doc::OnProcessAns(WPARAM wParam, LPARAM lParam)
{

	HWND subInfoInstance;
	switch (wParam) {
		case BLE_SAVE_FILE_OK:
			if (lParam == m_Count) {
				SetEvent(m_Handle[0]);
			}
			break;
		case BLE_SAVE_FILE_NG:
			if (lParam == m_Count) {
				SetEvent(m_Handle[1]);
			}
			break;

		case BLE_INIT_SUBINFO_OK:
			if (lParam == m_Count) {
				TRACE("SubInfo-Init succeed\n");
				SetEvent(m_InitHandle[0]);
			}
			break;
		case BLE_INIT_SUBINFO_NG:
			if (lParam == m_Count) {
				TRACE("SubInfo-Init fail\n");
				SetEvent(m_InitHandle[1]);
			}
			break;
		case BLE_CUROPEN_SUBINFO_OK:
			if (lParam == m_Count) {
				TRACE("SubInfo-CurrentOpen succeed\n");
				SetEvent(m_CurrentOpenHandle[0]);
			}
			break;
		case BLE_CUROPEN_SUBINFO_NG:
			if (lParam == m_Count) {
				TRACE("SubInfo-CurrentOpen fail\n");
				SetEvent(m_CurrentOpenHandle[1]);
			}
			break;
		case BLE_SUBINFO_INIT:
			subInfoInstance = FindWindow(NULL, DBLE_FRAMENAME_SUBINFOMODE);
			if (m_bIsSaving == false) {
				if (subInfoInstance != NULL) {
					TRACE("Can Init\n");
					PostMessage(subInfoInstance, BLE_CTRL, BLE_INIT_SUBINFO_OK, lParam);
				}
			} else {
				if (subInfoInstance != NULL) {
					TRACE("Cannot Init\n");
					PostMessage(subInfoInstance, BLE_CTRL, BLE_INIT_SUBINFO_NG, lParam);
				}
			}
			break;
		case BLE_SUBINFO_CUROPEN:
			subInfoInstance = FindWindow(NULL, DBLE_FRAMENAME_SUBINFOMODE);
			if (m_bIsSaving == false) {
				if (subInfoInstance != NULL) {
					TRACE("Can current open\n");
					PostMessage(subInfoInstance, BLE_CTRL, BLE_CUROPEN_SUBINFO_OK, lParam);
				}
			} else {
				if (subInfoInstance != NULL) {
					TRACE("Cannot Current open\n");
					PostMessage(subInfoInstance, BLE_CTRL, BLE_CUROPEN_SUBINFO_NG, lParam);
				}
			}
			break;
		default:
			break;
	}
	return;
}

// Set mode for Doc
void CBLE_Doc::SetMode(int mode)
{
	m_Mode = mode;
}

bool CBLE_Doc::BrowseFolder(CString &result)
{
	
    BROWSEINFO brwinfo = { 0 };
    brwinfo.lpszTitle = SelectAFolder[GetData()->m_Init.m_Language];
	brwinfo.lParam = (long)this;
	brwinfo.lpfn = BrowseCallbackProc;
    LPITEMIDLIST pitemidl = SHBrowseForFolder(&brwinfo);
    if (pitemidl == 0) {
        return false;
	}
    // get the full path of the folder
    TCHAR path[MAX_PATH];
    if (SHGetPathFromIDList(pitemidl, path)) {
        result = path;
    }
    IMalloc *pMalloc = 0;
    if (SUCCEEDED(SHGetMalloc(&pMalloc))) {
        pMalloc->Free ( pitemidl );
        pMalloc->Release ( );
    }
    return true;
}

int CALLBACK CBLE_Doc::BrowseCallbackProc(HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
    // Look for BFFM_INITIALIZED
    if (uMsg == BFFM_INITIALIZED) {
		CBLE_Doc* pThis = (CBLE_Doc*) lpData;
		//Change text base on language
		SetWindowText(hWnd, BrowseForFolder[pThis->GetData()->m_Init.m_Language]);
		//GetDlgItem(hWnd, IDCANCEL)->SetWindowText(hWnd, CancelButton[pThis->GetData()->m_Init.m_LanguageEdit]);
		SetDlgItemText(hWnd, IDCANCEL, CancelButton[pThis->GetData()->m_Init.m_Language]);

		// Get file path from current open folder
		CString filePath; 
		filePath = pThis->GetData()->GetDataFilePath();
		//pThis->GetData()->GWPPfileData(FCB_INIT_FILE_PATH, "FCB���ް�", "�i���ް��߽��", true, filePath, CString(""));
		LPCTSTR pDir= (LPCTSTR)filePath;
		// Set file path
        SendMessage(hWnd, BFFM_SETSELECTION, TRUE, (LPARAM)pDir);
    }
    return 0;
}

// Get device name from path
CString CBLE_Doc::GetDeviceNameFromPath(CString filePath)
{
	int id = filePath.ReverseFind('\\');
	CString deviceName = (id == -1) ? filePath.Mid(id) : filePath.Mid(id + 1);
	return deviceName;
}

// Return working mode
int CBLE_Doc::GetMode()
{
	return m_Mode;
}

// Set setting to check and reflect or reflect only
void CBLE_Doc::SetSetting(int isCheckReflect)
{
	m_Data.m_Init.m_CheckReflect = isCheckReflect;
	// Save Check&Reflect setting to editmode.ini file
	m_Data.GWPPfileData(m_Data.GetLocateEditIniFilePath(), DBLE_SECTION_EDIT_CONFIG, DBLE_KEY_EDIT_CHKREF, false, isCheckReflect, 1);
}

// Get setting to check and reflect or reflect only
int CBLE_Doc::GetSetting()
{
	return m_Data.m_Init.m_CheckReflect;
}

// Overide function to check if document has been modified before close
BOOL CBLE_Doc::CanCloseFrame(CFrameWnd* pFrame)
{
	if (IsModified()) {
		CString mes;
		mes.Format(SaveInvalid[GetData()->m_Init.m_Language], m_DeviceName);
		//if (AfxMessageBox(mes, MB_YESNO) == IDYES) {
		if (theApp.CBTMessageBox(NULL, mes, MB_YESNO, GetData()->m_Init.m_Language) == IDYES) {
			return true;
		}
		//if (AfxMessageBox(_T("Do you want to save data?"), MB_YESNO) == IDYES) {
		if (theApp.CBTMessageBox(NULL, SaveRequest[GetData()->m_Init.m_Language], MB_YESNO, GetData()->m_Init.m_Language) == IDYES) {
			bool result = SaveData();
			if (!result) {
				//AfxMessageBox(DBLE_DOC_SAVE_NOTDONE);
				theApp.CBTMessageBox(NULL, SaveNotDone[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);

				// Write log file:
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, SaveNotDone[GetData()->m_Init.m_Language], "", "");
			}
		}
		return false;
	}
	return true;
}

void CBLE_Doc::GetLanguageString(CString filePath)
{
	CStdioFile langFile;
	CFileException e;
	CString fileName = filePath + "LocateEdit.japan";
	if (langFile.Open(fileName, CFile::modeRead, &e)) {
		CString text;
		int i = -1;
		int j = 0;
		while(langFile.ReadString(text)) {
			if (text.Find("[") != -1) {
				i ++;
				j = 0;
				continue;
			}
			m_LanguageItem[i][j] = text.Mid(text.Find(":", 0) + 1);
			CString idName = text.Mid(0, text.GetLength() - m_LanguageItem[i][j].GetLength() - 1);
			
			for (int id = 0; id < DBLE_LANGUAGE_ITEMS; id ++) {
				if (idName == m_DialogItems[id].m_IDName) {
					m_DialogItems[id].m_Name = m_LanguageItem[i][j];
					break;
				}
			}

			j ++;
		}
	} else {
		theApp.CBTMessageBox(NULL, MissingLangFile[GetData()->m_Init.m_Language], MB_OK,  GetData()->m_Init.m_Language);
		return;
	}
}

/**
* Current open
*/
void CBLE_Doc::CurrentOpenData()
{
	if (!m_bIsSaving) {
		CString mes;
		// Check data is saved?
		if (IsModified()) {
			mes.Format(SaveInvalid[GetData()->m_Init.m_Language], m_DeviceName);
			//if (AfxMessageBox(mes, MB_YESNO) == IDNO) {
			if (theApp.CBTMessageBox(NULL, mes, MB_YESNO, GetData()->m_Init.m_Language) == IDNO) {
				return;
			}
		}
		// #DUCDT131114: Get main frame
		
		POSITION pos = GetFirstViewPosition();
		CBLE_View* view = (CBLE_View*) this->GetNextView(pos);
		CBLE_FrameWnd *frame = (CBLE_FrameWnd *)view->GetParentFrame();
		
		CString filePath;
		m_Data.GWPPfileData(FCB_INIT_FILE_PATH, "FCB���ް�", "�i���ް��߽��", true, filePath, CString(""));
		// Get device name
		CString deviceName = GetDeviceNameFromPath(filePath);
		mes.Format(CurrentOpen[GetData()->m_Init.m_Language], deviceName);
		//if (AfxMessageBox(mes, MB_YESNO) == IDNO) {
		if (theApp.CBTMessageBox(NULL, mes, MB_YESNO, GetData()->m_Init.m_Language) == IDNO) {
			return;
		}

// #DUCDT131114: Add current open progress bar
		int isSubComplex = 0;
		GetData()->GWPPfileData(filePath + "\\" + DBLE_MODEL_DV100_NAME, "FC����� �i���ް�(����ިݸ��Ư�)����ިݸ��Ư�:�ڰѐ����ް�_L", "SubstComplex(0:Simple 1:Complex)", true, isSubComplex, 1);
		if (isSubComplex == 0) {
			//AfxMessageBox(DBLE_DOC_COMPLEX_INVALID_ENG, MB_OK);
			theApp.CBTMessageBox(NULL, ComplexInvalid[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
			// Write log file: invalid complex
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ComplexInvalid[GetData()->m_Init.m_Language], "", "");
			return;
		} 
		// Set data path : if in EditMode, write data path to EditMode.ini for next open
		if (m_Mode == DBLE_EDIT_MODE) {
			GetData()->SetDataFilePath(filePath);
		} else if (m_Mode == DBLE_SUBINFO_MODE) {
			GetData()->SetDataFilePath();
		}
		// Get device name
		m_DeviceName = GetDeviceNameFromPath(filePath);

		// Get file path of file .191
		m_FilePath = filePath + "\\" + DBLE_BINARY_FILE;
		
		// If don't have binary file
		if (GetFileAttributes(m_FilePath) == 0xFFFFFFFF) {	

			frame->OpenFileProgressBar(filePath); // display progress bar
			
		} else {
			// Read from binary file
			CFile bleFile;
			if (!bleFile.Open(m_FilePath, CFile::modeRead)) {
				theApp.CBTMessageBox(NULL, CannotOpen[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
				return;
			}
			CArchive ar(&bleFile, CArchive::load);
			Serialize(ar);
			ar.Close();
			bleFile.Close();
			
		}
		//Ask current window to display new data
		frame->UpdateDataFromFile();
		
		// Reset modify flag
		SetModifiedFlag(0);

		// Write log
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_CURRENTLOAD, GetDeviceName(), "");
	} else {
		// Warning for user cannot open subinfo because of EditMode is saving
		theApp.CBTMessageBox(NULL, CannotInitSubInfo[GetData()->m_Init.m_Language], MB_OK, GetData()->m_Init.m_Language);
	}
	return;

}
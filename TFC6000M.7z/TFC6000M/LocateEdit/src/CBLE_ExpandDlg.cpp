///////////////////////////////////////////////////////////
//  CBLE_ExpandDlg.cpp
//  Implementation of the Class CBLE_ExpandDlg
//  Created on:      16-Thg7-2013 1:41:03 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_ExpandDlg.h"
#include "CBLE_OffsetDlg.h"
#include "CBLE_Util.h"
#include "CBLE_CareTaker.h"

// Defined for column width of grid control
static long m_arrExpColWidth[] = {
	40, 50, 20, 50, 73, 73
};

// Defined for column number type of grid control
static DBLE_CellType m_arrComColType[] = {
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_TEXT,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
};

// Define warning message
//#define WARNING_MESSAGE_OUTOFRANGE			_T("Your input is out of limit range! \n Do you want to re-input?")

/////////////////////////////////////////////////////////////////////////////
// Define message text for Japanese and English
//
CString OutOfRangeExp[] =  {							
								_T("���͂������͈͊O�ł��B�ē��͂��܂����H"),
								_T("Your input is out of limit range! \n Do you want to re-input?"),
							};


/////////////////////////////////////////////////////////////////////////////
// CBLE_ExpandDlg dialog


CBLE_ExpandDlg::CBLE_ExpandDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_ExpandDlg::IDD, pParent)
{
	m_pDoc = NULL;
	m_View = NULL;
	m_GridCtrl = NULL;
}

CBLE_ExpandDlg::~CBLE_ExpandDlg()
{

}


void CBLE_ExpandDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBLE_ExpandDlg, CDialog)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_EXPD_OFFSET, OnOffsetExpand)
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateGrid)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_ExpandDlg message handlers
void CBLE_ExpandDlg::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}


BOOL CBLE_ExpandDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect rect;

	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;
	// Create the expand view window
	GetDlgItem(IDC_EXPD_VIEW)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_View = new CBLE_ExpandView();
	m_View->SetDocument(m_pDoc);
	m_View->Create(NULL, NULL,
		WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_EXPD_VIEW, pContext);

	// Create grid control
	GetDlgItem(IDC_EXPD_GRID)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_GridCtrl = new CBLE_GridCtrl(12, 6);
	//m_GridCtrl->SetDocument(m_pDoc);
	m_GridCtrl->Create(rect, this, m_pDoc);

	// Create key window
	GetDlgItem(IDC_EXPD_NUM_KEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(m_GridCtrl->GetEditWnd(), IDD_NKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);

	// Init grid
	InitGridCtrl();
	AddGridData();

	// Delete pointer
	delete pContext;

	return TRUE;
}


void CBLE_ExpandDlg::OnClose()
{
	// Clear all offset
	m_pDoc->GetData()->GetSubstrate()->ClearSelICOffset();

	CDialog::OnClose();
}


void CBLE_ExpandDlg::OnCancel()
{
	// Refresh buffer restore
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore(IDD_EXPAND_DLG);

	// Clear all offset
	m_pDoc->GetData()->GetSubstrate()->ClearSelICOffset();

	CDialog::OnCancel();
}

void CBLE_ExpandDlg::OnOK()
{
	CDialog::OnOK();
}


void CBLE_ExpandDlg::OnOffsetExpand()
{
	// Write log
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_CHECKREFELCT, DBLE_LOGFILE_EXPAND, "");

	m_View->FindCenterIC();
	CBLE_OffsetDlg offsetDlg(DBLE_OFFSET_DLG_MODE_EXPAND);
	// Expand all ICs
	vector<TBLE_Expand> vExpand;
	GetExpandVector(vExpand);
	int expandSize = vExpand.size();
	for(UINT idx = 0; idx < expandSize; idx ++){
		m_View->ExpandICs(
			vExpand[idx].Nstart, vExpand[idx].Nend,
			vExpand[idx].dX, vExpand[idx].dY);
	}
	offsetDlg.SetDocument(m_pDoc);
	if(offsetDlg.DoModal() != IDOK) {
		/* If cancel expand, need to get old Offset 
		vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
		int icSize = vIC.size();
		for(UINT idx = 0; idx < icSize; idx ++){
			vIC[idx]->m_OffsetX = vIC[idx]->m_TargetBgPosX - vIC[idx]->m_BgPosX;
			vIC[idx]->m_OffsetY = vIC[idx]->m_TargetBgPosY - vIC[idx]->m_BgPosY;
		}*/
		Invalidate();
		return;
	}

	OnOK();
}


void CBLE_ExpandDlg::InitGridCtrl()
{
	// Set language
	m_GridCtrl->SetLanguage(m_pDoc->GetData()->m_Init.m_Language);

	// Set type for all cols
	for(UINT idx = 0; idx < ARRAY_LENGTH(m_arrComColType); idx ++){
		m_GridCtrl->SetColType(idx, m_arrComColType[idx]);
	}

	// Set width for all cols
	for(idx = 0; idx < ARRAY_LENGTH(m_arrExpColWidth); idx ++){
		m_GridCtrl->SetColWidth(idx, m_arrExpColWidth[idx]);
	}
	// Set header
	m_GridCtrl->SetColHeader(0);
	m_GridCtrl->SetColHeader(1);
	m_GridCtrl->SetColHeader(2);
	m_GridCtrl->SetRowHeader(0);
	m_GridCtrl->SetRowHeader(1);
	// Set merge for some rows an cols
	m_GridCtrl->MergeCell(0, 0, 1, 0);
	m_GridCtrl->MergeCell(0, 1, 0, 2);
	m_GridCtrl->MergeCell(0, 1, 0, 3);
	m_GridCtrl->MergeCell(0, 4, 0, 5);

	// Set header
	int rowNum = m_GridCtrl->GetRows();
	for(long row = 1; row < rowNum; row ++){
		m_GridCtrl->SetCellText(row, 2, _T("~"));
		CString strTmp;
		strTmp.Format(_T("%d"), row - 1);
		m_GridCtrl->SetCellText(row, 0, strTmp);
	}

	m_GridCtrl->SetCellText(0, 0, _T("Table"));
	m_GridCtrl->SetCellText(1, 0, _T("Table"));

	m_GridCtrl->SetCellText(0, 1, _T("N"));
	m_GridCtrl->SetCellText(0, 2, _T("N"));
	m_GridCtrl->SetCellText(0, 3, _T("N"));

	m_GridCtrl->SetCellText(1, 1, _T("Start"));
	m_GridCtrl->SetCellText(1, 3, _T("End"));

	m_GridCtrl->SetCellText(0, 4, _T("Pitch Expand"));
	m_GridCtrl->SetCellText(0, 5, _T("Pitch Expand"));

	m_GridCtrl->SetCellText(1, 4, _T("dX [mm]"));
	m_GridCtrl->SetCellText(1, 5, _T("dY [mm]"));
}

void CBLE_ExpandDlg::AddGridData()
{
	m_GridCtrl->SetCellText(2, 1, _T("N"));	
}

LRESULT CBLE_ExpandDlg::OnUpdateGrid(WPARAM wParam, LPARAM lParam)
{
	long rowSel = m_GridCtrl->GetRowSel();
	long colSel = m_GridCtrl->GetColSel();
	CString oldText = m_GridCtrl->GetCell(rowSel, colSel)->GetOldText();
	
	long maxRow = m_GridCtrl->GetRows();
	long maxCol = m_GridCtrl->GetCols();
	// Check the start N
	CString tmpText = m_GridCtrl->GetCellText(rowSel, 1);
	if(tmpText != _T("")){
		tmpText = m_GridCtrl->GetCellText(rowSel, colSel);
				
		//if(colSel == 3) tmpText = _T("");
		//m_GridCtrl->SetCellText(rowSel, colSel, tmpText/*, wParam == IDC_NKEY_ENT*/);
		// Validate data
		ValidateData(rowSel);
		// Redraw frame
		if(colSel == 3) {
			tmpText = m_GridCtrl->GetCellText(rowSel, colSel);
			if (tmpText == _T("")) {
				for (int idx = rowSel;idx < maxRow; idx ++) {
					for (int idx1 = colSel; idx1 < maxCol; idx1 ++) {
						if (idx == rowSel && idx1 == colSel) {
							continue;
						}
						m_GridCtrl->GetCell(idx, idx1)->SetHeader(true);
					}
				}
			} else {
				// Compare old value with new value
				if (tmpText.Compare(oldText) != 0) {
					for (int idx = rowSel;idx < maxRow; idx ++) {
						for (int idx1 = colSel; idx1 < maxCol; idx1 ++) {
							if (idx == rowSel && idx1 == colSel) {
								continue;
							}
							m_GridCtrl->GetCell(idx, idx1)->SetHeader(false);
						}
					}
					DrawFrame();
					// Restore
					CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
					CBLE_GridStore grid(rowSel, colSel, oldText, IDD_EXPAND_DLG, GRID_TYPE);
					pCareTaker->SetMemento(grid);
				}
			}
		}
		// Check input value for expand
		if (colSel == 4 || colSel == 5) {
			double value = atof(tmpText);
			if (value > 9.9 || value < -9.9) {
				//int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
				int nType = theApp.CBTMessageBox(this->m_hWnd, OutOfRangeExp[m_pDoc->GetData()->m_Init.m_Language], MB_YESNO, m_pDoc->GetData()->m_Init.m_Language);
				// Write log file: missing value
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, OutOfRangeExp[m_pDoc->GetData()->m_Init.m_Language], "", "");
				
				if (nType == IDYES) {								// Re-input
					m_GridCtrl->SetCellText(rowSel, colSel, /*_T("")*/oldText);
					m_GridCtrl->ShowEditBox();
					return 0;
				} else {
					// #DUCDT131111: Re-input with old value
					//tmpText = _T("0");
					tmpText = oldText;
				}	
			} else {
				// Compare old value with new value
				if (tmpText.Compare(oldText) != 0) {
					// Restore
					CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
					CBLE_GridStore grid(rowSel, colSel, oldText, IDD_EXPAND_DLG, GRID_TYPE);
					pCareTaker->SetMemento(grid);
				}
			}
		}
	}
	m_GridCtrl->SetCellText(rowSel, colSel, tmpText);
	// Focus on Expand dialog
	SetFocus();
	// Move to next collumn
	if (colSel + 1 < m_GridCtrl->GetCols()) {
		m_GridCtrl->SetCellSel(rowSel, colSel + 1);
	} else if (rowSel + 1 < m_GridCtrl->GetRows()){ // if collumn is maximum then return;
		// #DucDT131108: Move to next row, column is End
		m_GridCtrl->SetCellSel(rowSel + 1, /*IC_TYPE*/3/*Index of EndExpand column*/);
	} else {
		m_GridCtrl->Deselect();
		
	}

	//m_GridCtrl->Deselect();
	Invalidate();
	return 0;
}

void CBLE_ExpandDlg::GetExpandVector(vector<TBLE_Expand>& vExpand)
{
	CString tmpStr;						// Get input string to convert to value
	//int maxN = 0;
	int maxRow = m_GridCtrl->GetRows();

	// Get input data on each row of Expand table
	for(long row = 2; row < maxRow; row ++){
		// Start N
		tmpStr = m_GridCtrl->GetCellText(row, 1);
		if(tmpStr == _T("")) {
			break;
		}
		// Push new value
		TBLE_Expand expand;
		// Start N
		tmpStr = tmpStr.Mid(1, tmpStr.GetLength());
		expand.Nstart = atoi(tmpStr);

		// End N
		tmpStr = m_GridCtrl->GetCellText(row, 3);
		if(tmpStr == _T("")) {
			break;
		}
		tmpStr = tmpStr.Mid(1, tmpStr.GetLength());
		expand.Nend = atoi(tmpStr);
		//maxN = expand.Nend;

		// Get dX
		tmpStr = m_GridCtrl->GetCellText(row, 4);
		expand.dX = atof(tmpStr);

		// Get dY
		tmpStr = m_GridCtrl->GetCellText(row, 5);
		expand.dY = atof(tmpStr);

		vExpand.push_back(expand); 
	}
}


void CBLE_ExpandDlg::ValidateData(long row)
{
	// Start N
	CString tmp = m_GridCtrl->GetCellText(row, 1);
	if(tmp == _T("")) return;
	tmp = tmp.Mid(1, tmp.GetLength());
	int Nstart = atoi(tmp);
	// End N
	tmp = m_GridCtrl->GetCellText(row, 3);
	if(tmp == _T("")) return;
	if(tmp.GetAt(0) == 'N'){
		tmp = tmp.Mid(1, tmp.GetLength());
	}
	int Nend = atoi(tmp);
	long rowNum = m_GridCtrl->GetRows();
	if((Nend <= Nstart) || (Nend > m_View->GetMaxN())){
		m_GridCtrl->SetCellText(row, 3, _T(""));
		for(long idx = row + 1; idx < rowNum; idx ++){
			m_GridCtrl->SetCellText(idx, 1, _T(""));
			m_GridCtrl->SetCellText(idx, 3, _T(""));
		}
		return;
	}
	tmp.Format(_T("%d"), Nend);
	m_GridCtrl->SetCellText(row, 3, _T("N") + tmp);
	//m_GridCtrl->SetCellText(row, 3, tmp);
	// Set next row
	if(Nend == m_View->GetMaxN()){
		for(long idx = row + 1; idx < rowNum; idx ++){
			m_GridCtrl->SetCellText(idx, 1, _T(""));
			m_GridCtrl->SetCellText(idx, 3, _T(""));
		}
		return;
	}
	if(row == (m_GridCtrl->GetRows() - 1)) return;
	m_GridCtrl->SetCellText(row + 1, 1, _T("N") + tmp);
}

void CBLE_ExpandDlg::DrawFrame()
{
	vector<int> vN;
	vN.push_back(0);

	long rowNum = m_GridCtrl->GetRows();
	for(long row = 2; row < rowNum; row ++){
		CString tmp = m_GridCtrl->GetCellText(row, 3);
		if(tmp == _T("")) break;
		tmp = tmp.Mid(1, tmp.GetLength());
		vN.push_back(atoi(tmp));
	}

	m_View->SetNVector(vN);
	m_View->Invalidate();
}


/**
* Restore function
*/
void CBLE_ExpandDlg::OnRestoreState()
{
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	if (!pCareTaker->Restoreable() || pCareTaker->GetLastKind() != IDD_EXPAND_DLG ) {
		return;
	}
	CBLE_Memento mem = pCareTaker->GetMemento();
	void* tmp = mem.GetState();
	vector<TBLE_GridData> *v_Grid = static_cast<vector<TBLE_GridData> *>(tmp);
	TBLE_GridData grid = v_Grid->at(0);
	// Reset marked cells
	m_GridCtrl->ResetMarkCells();
	// Mark cell
	m_GridCtrl->SetMarkCell(grid.row, grid.col);
	// Move scroll
	m_GridCtrl->MoveScrollCell(grid.row, grid.col);
	// Restore old value
	m_GridCtrl->SetCellText(grid.row, grid.col, grid.val);

	// Validate restore data
	ValidateData(grid.row);

	// Re-draw frame
	DrawFrame();
	delete v_Grid;
}

/**
* Catch Ctrl + Z to restore
*/
BOOL CBLE_ExpandDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN /*&& pMsg->wParam == VK_CONTROL*/){
		if ((GetKeyState(0x5A) & 0x8000) && (GetKeyState(VK_CONTROL) & 0x8000)) {
			OnRestoreState();
		}
    }	
    return CDialog::PreTranslateMessage(pMsg);
}

// CMV_InputMap.cpp : implementation file
////#NhamNV-170825: Add Input Map Name(S)

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_InputMap.h"
#include "CBLE_Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_InputMap dialog


CBLE_InputMap::CBLE_InputMap(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_InputMap::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMV_InputMap)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CBLE_InputMap::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMV_InputMap)
	DDX_Control(pDX, IDC_EDIT_INPUT_BARCODE, m_EditMapName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBLE_InputMap, CDialog)
	//{{AFX_MSG_MAP(CMV_InputMap)
	ON_BN_CLICKED(IDOK, OnBtnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_InputMap message handlers

void CBLE_InputMap::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

BOOL CBLE_InputMap::OnInitDialog() 
{
	CDialog::OnInitDialog();

	return TRUE;
}


void CBLE_InputMap::OnBtnOk()						// OK button
{
	m_EditMapName.GetWindowText(m_strInputMap);
	CDialog::OnOK();
}

BOOL CBLE_InputMap::PreTranslateMessage(MSG* pMsg) 
{
	if ((GetKeyState(0x0D) & 0x8000) ) {			// Enter key
		m_EditMapName.GetWindowText(m_strInputMap);
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}
CString CBLE_InputMap::GetMapName()
{
	return m_strInputMap;
}

//#NhamNV-170825: Add Input Map Name (E)
///////////////////////////////////////////////////////////
//  CBLE_Logger.cpp
//  Implementation of the Class CBLE_Logger
///////////////////////////////////////////////////////////

#include "CBLE_Logger.h"
#include "CBLE_Util.h"

#define DBLE_LOGEDIT_LENGTH			19 // define length to get LOG directory for Edit
#define DBLE_LOGSUBINFO_LENGTH		22 // define length to get LOG directory for SubInfo

///////////////////////////////////////////
///////
CBLE_Logger* CBLE_Logger::m_Logger;

CBLE_Logger::CBLE_Logger()
{
	m_pProgThread		= NULL;
	m_ThreadEvent[1]	= CreateEvent(0, true, false, 0); // Stop thread
	m_ThreadEvent[0]	= CreateEvent(0, true, false, 0); // Start thread
	m_Serial			= 1;
	m_FileName			= "";
	m_FilePath			= "";
	m_Mode				= "Edit";
	m_vLogText.clear();
}

CBLE_Logger::~CBLE_Logger()
{
	SetEvent(m_ThreadEvent[1]);	// set event for stop writting
	WaitForSingleObject(m_pProgThread->m_hThread, INFINITE);
	CloseHandle(m_ThreadEvent[0]);
	CloseHandle(m_ThreadEvent[1]);
}

CBLE_Logger* CBLE_Logger::GetInstance() 
{
	if (m_Logger == NULL) {
		m_Logger = new CBLE_Logger();
	}
	return m_Logger;
}

// Set log string
void CBLE_Logger::SetLogFormat(CString type, CString action, CString first, CString second)
{
	// Get time
	CTime t = CTime::GetCurrentTime();
	CString day, month, year, hour, min, sec;
	t.GetDay() < 10 ? day.Format(_T("0%d"), t.GetDay()) : day.Format(_T("%d"), t.GetDay());
	t.GetMonth() < 10 ? month.Format(_T("0%d"), t.GetMonth()) : month.Format(_T("%d"), t.GetMonth());
	year.Format(_T("%d"), t.GetYear());
	t.GetHour() < 10 ? hour.Format(_T("0%d"), t.GetHour()) : hour.Format(_T("%d"), t.GetHour());
	t.GetMinute() < 10 ? min.Format(_T("0%d"), t.GetMinute()) : min.Format(_T("%d"), t.GetMinute());
	t.GetSecond() < 10 ? sec.Format(_T("0%d"), t.GetSecond()) : sec.Format(_T("%d"), t.GetSecond());

	// Remove character \n in error message
	action.Replace("\n", "");

	// Format time
	CString time = year + "/" + month + "/" + day + "," + hour + ":" + min + ":" + sec + ",";

	// Format log text
	CString log = time + type + "," + action + "," + first + "," + second + "," + "\n";

	// Store log text in vector
	m_vLogText.push_back(log);

	// Set event to write
	SetEvent(m_ThreadEvent[0]);

	TRACE("          [Log]%s",log);
}

// Set log string
void CBLE_Logger::SetLogFormat(CString text)
{
	// Get time
	CTime t = CTime::GetCurrentTime();
	CString day, month, year, hour, min, sec;
	t.GetDay() < 10 ? day.Format(_T("0%d"), t.GetDay()) : day.Format(_T("%d"), t.GetDay());
	t.GetMonth() < 10 ? month.Format(_T("0%d"), t.GetMonth()) : month.Format(_T("%d"), t.GetMonth());
	year.Format(_T("%d"), t.GetYear());
	t.GetHour() < 10 ? hour.Format(_T("0%d"), t.GetHour()) : hour.Format(_T("%d"), t.GetHour());
	t.GetMinute() < 10 ? min.Format(_T("0%d"), t.GetMinute()) : min.Format(_T("%d"), t.GetMinute());
	t.GetSecond() < 10 ? sec.Format(_T("0%d"), t.GetSecond()) : sec.Format(_T("%d"), t.GetSecond());

	// Remove character \n in error message
	text.Replace("\n", "");

	// Format time
	CString time = year + "/" + month + "/" + day + "," + hour + ":" + min + ":" + sec + ",";

	// Format log text
	CString log = time + text + "\n";

	// Store log text in vector
	m_vLogText.push_back(log);

	// Set event to write
	SetEvent(m_ThreadEvent[0]);
}

// Get file name
CString CBLE_Logger::GetFileName()
{
	// Get date for file name
	CTime t = CTime::GetCurrentTime();
	CString day, month, year;
	t.GetDay() < 10 ? day.Format(_T("0%d"), t.GetDay()) : day.Format(_T("%d"), t.GetDay());
	t.GetMonth() < 10 ? month.Format(_T("0%d"), t.GetMonth()) : month.Format(_T("%d"), t.GetMonth());
	year.Format(_T("%d"), t.GetYear());

	// Set serial for file name
	CString serial;
	serial.Format(_T("%d"), m_Serial);

	return m_FilePath + m_Mode + year+ month + day + "00" + serial +".csv";
}

// Set file path
void CBLE_Logger::SetFilePath(CString filePath)
{
	// Get current directory
	m_FilePath			= filePath + "LOG\\";
	// Writting thread
	if (m_pProgThread == NULL) { // check if thread has been created before
		m_pProgThread	= AfxBeginThread(WriteDataToFile, this);
	}
}

UINT CBLE_Logger::WriteDataToFile(LPVOID pParam)
{
	CBLE_Logger* pLogger = (CBLE_Logger*) pParam;
	// Get file name
	CString fileName = pLogger->GetFileName();

	// Create directory \LOG
	CString dirLog;
	if (pLogger->m_Mode == "SubInfo") {
		dirLog = fileName.Mid(0, fileName.GetLength() - DBLE_LOGSUBINFO_LENGTH);
	} else {
		dirLog = fileName.Mid(0, fileName.GetLength() - DBLE_LOGEDIT_LENGTH);
	}
	//CString dirLog = fileName.Mid(0, fileName.GetLength() - DBLE_LOGFOLDER_LENGTH);
	int logResult = CreateDirectory(dirLog, NULL);

	CStdioFile logFile;

	long fileLength = 0; // number of lines in file
    
	int  lastDay = 0; //#TIENBV20151120 
    int  currDay = 0; //#TIENBV20151120 
    CString strCurrFilePath = "";//#TIENBV20151120 

	while(true) {
		DWORD dwEvent;
		dwEvent = WaitForMultipleObjects(2, pLogger->m_ThreadEvent, false, INFINITE); // waiting for begin to write or stop thread
		
		// Event to write
		if (dwEvent == WAIT_OBJECT_0 + 0) {
			// Reset event Write to file
			ResetEvent(pLogger->m_ThreadEvent[0]);

			CString text; // temp variable to store text from file

			// Check size of vector contains log
			int size = pLogger->m_vLogText.size();
			if (size > 0) {
				CTime t = CTime::GetCurrentTime();	
				currDay = t.GetDay(); //#TIENBV20151120 get current day
                if(currDay != lastDay)  //#TIENBV20151120 compare current day with day of latest log file name
				{				    
				    // close old file
					if(logFile.m_pStream != NULL) {
				        logFile.Close();
					}	
					fileLength = 0;
					pLogger->m_Serial = 1;
				}
				//

				if (fileLength == 0) { // new open file
					lastDay = t.GetDay(); //#TIENBV20151120 save day when create a new log file
					CFileException e;
					CString fileName = pLogger->GetFileName();
					strCurrFilePath = fileName; //#TIENBV20151120 save the current file path working 
					if (!logFile.Open(fileName, CFile::modeReadWrite | CFile::shareExclusive | CFile::modeCreate | CFile::modeNoTruncate, &e)) {
						return 0;
					}
					
					//Get lines number of file
					CString text;
					logFile.SeekToBegin(); // read from begin of file
					while (logFile.ReadString(text)) { // use temp variable to count lines number
						fileLength ++; // get number of line in file when open
					}
				}
				
				if (fileLength == 0) {
					// Write file header
					CString logFileName;
					if (pLogger->m_Mode == "SubInfo") {
						logFileName = fileName.Mid(fileName.GetLength() - DBLE_LOGSUBINFO_LENGTH);
					} else {
						logFileName = fileName.Mid(fileName.GetLength() - DBLE_LOGEDIT_LENGTH);
					}
                    logFileName += "\n";
                    logFile.WriteString(logFileName);
					logFile.WriteString(_T("Date,Time,Type,Action,1,2,RegNo,idX,idY,Size,\n"));					
					fileLength = fileLength + 2;
				} else {
                    //#TIENBV20151120 open the current log file 
					CFileException e;	
					if (logFile.m_pStream == NULL) {
						if (!logFile.Open(strCurrFilePath, CFile::modeReadWrite | CFile::shareExclusive | CFile::modeCreate | CFile::modeNoTruncate, &e)) {
							return 0;
						}
					}
					//

					//Writting
					logFile.SeekToEnd();
					vector<CString>::iterator it = pLogger->m_vLogText.begin();
					while (it != pLogger->m_vLogText.end()) {
						if (fileLength >= 5000) { // Check if file length is over 5000
							logFile.Close(); // close old file
							fileLength = 0;
							pLogger->m_Serial ++;
							break;
						}
						// If file length is less than 5000, write
						logFile.WriteString(*it);
						it = pLogger->m_vLogText.erase(it);
						fileLength++;
					}
					if(logFile.m_pStream != NULL) {
						logFile.Close();//#TIENBV20151120  close file after write 
					}
				}
				if(logFile.m_pStream != NULL) {
					logFile.Close();//#TIENBV20151120  close file after write 
				}
			}
		} else if (dwEvent == WAIT_OBJECT_0 + 1) {// Event to stop thread 
			ResetEvent(pLogger->m_ThreadEvent[1]);
			break;
		} else {
			// do nothing
		}
	}
	return 0;
}
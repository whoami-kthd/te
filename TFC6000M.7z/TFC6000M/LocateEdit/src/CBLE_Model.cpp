///////////////////////////////////////////////////////////
//  CBLE_Model.cpp
//  Implementation of the Class CBLE_Model
//  Created on:      07-12-2013 2:56:05 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////
#include <io.h>
#include "CBLE_Model.h"
#include "CBLE_CareTaker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Define for default value of common setting
#define DBLE_MODEL_ELEMENT_LINE						100
#define DBLE_MODEL_BUFFER_MINLENGTH					20
#define DBLE_MODEL_BUFFER_MAXLENGTH					1024
#define DBLE_MODEL_SUBSTRATE_SIZE_DEFAULT			300
#define DBLE_MODEL_SUBSTRATE_NAME_DEFAULT			"Square 300x300mm"
#define DBLE_MODEL_ICSIZE_MAX_DEFAULT				R2Pos(20, 20)
#define DBLE_MODEL_ICSIZE_MIN_DEFAULT				R2Pos(0.5, 0.5)
#define DBLE_MODEL_REGNO_MAX_DEFAULT				5
#define DBLE_MODEL_ICTYPE_MAX_DEFAULT				4
#define DBLE_MODEL_NUMBER_MAXX_DEFAULT				300
#define DBLE_MODEL_NUMBER_MAXY_DEFAULT				300
#define DBLE_MODEL_TOTAL_DEFAULT					450000
#define DBLE_MODEL_BGHEAD_TOOL_MAX_DEFAULT			4
#define DBLE_MODEL_PICKUP_COLLETTE_MAX_DEFAULT		1
#define DBLE_MODEL_WAFER_EJECT_MAX_DEFAULT			1

#define DBLE_MODEL_PICKUP_COLLETTE_DEFAULT			1
#define DBLE_MODEL_WAFER_EJECT_DEFAULT				1
// Offset, expand max/min value
#define DBLE_MODEL_OFFSET_MAX_DEFAULT				R2Pos(9.9, 9.9)
#define DBLE_MODEL_OFFSET_MIN_DEFAULT				R2Pos(-9.9, -9.9)
#define DBLE_MODEL_EXPAND_MAX_DEFAULT				R2Pos(9.9, 9.9)
#define DBLE_MODEL_EXPAND_MIN_DEFAULT				R2Pos(-9.9, -9.9)

#define DBLE_MODEL_EXPAND_TABLE_MAX_DEFAULT			10
#define DBLE_MODEL_IC_OFFSETXY_DEFAULT				R2Pos(0,0)
#define DBLE_MODEL_IC_OFFSETT_DEFAULT				0
#define DBLE_MODEL_IC_VALID_DEFAULT					0

// Define string for default password
#define DBLE_MODEL_PASS1_DEFAULT					"0001"
#define DBLE_MODEL_PASS2_DEFAULT					"0002"
#define DBLE_MODEL_PASS3_DEFAULT					"0003"

// Define message for log file
#define DBLE_MODEL_SHAPE_ERROR						_T("Get shape error")
#define DBLE_MODEL_SHAPE_SQUARE_ERROR				_T("Get square error")
#define DBLE_MODEL_SHAPE_ROUND_ERROR				_T("Get round error")


// Define message
#define DBLE_MODEL_NOTFOUND_MESS_ENG		" is not found. Default value will be used!"

// Max length of a line in data file, for read/write data function
#define MAX_LINE_LENGTH						4000
/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString ShapeError[] =				{
										_T("��`�̃G���["),
										_T("Get shape error"),
									};

CString ShapeSquareError[] =		{
										_T("Square�̃G���["),
										_T("Get square error"),
									};

CString ShapeRoundError[] =			{
										_T("Round�̃G���["),
										_T("Get round error"),
									};

CString NotFound[] =				{
										_T("��������܂���ł����B�f�t�H���g�l���g���܂�"),
										_T(" is not found. Default value will be used!"),
									};

// Implement serialize
IMPLEMENT_SERIAL(CBLE_Model, CObject, 1)

/////////////////////////////////////////////////////////////////////

CBLE_Model::CBLE_Model()
{
	m_vRegIC.clear();
	m_vShape.clear();
	m_Substrate.ResetData();
	m_isSubComplex = 0;
	m_strLocateEditIniFilePath = "";
	m_strSubInfoIniFilePath = "";
	m_strDataFilePath = "";
	m_strMachineFilePath = "";
	m_ProcessIndex = 0;
	m_bStartProgress = false;
	m_StopThread	= CreateEvent(0, true, false, 0); // stop thread
	m_frameDir[0] = DBLE_SUBINFO_FRMDIR_LEFT;
	m_frameDir[1] = DBLE_SUBINFO_FRMDIR_LEFT;
	m_BCEQU = "";
}

/**
* Default destructor
*/
CBLE_Model::~CBLE_Model()
{

}

/**
* Get substrate property
*/
CBLE_Substrate* CBLE_Model::GetSubstrate()
{
	return  &m_Substrate;
}

/**
*Set file path of LocateEdit.ini
*/
void CBLE_Model::SetLocateEditIniFilePath(CString filePath)
{
	m_strLocateEditIniFilePath = filePath;
}

/**
* Get file path of LocateEdit.ini
*/
CString CBLE_Model::GetLocateEditIniFilePath()
{
	return m_strLocateEditIniFilePath;
}

/**
* Set file path of SubInfo.ini
*/
void CBLE_Model::SetSubInfoIniFilePath(CString filePath)
{
	m_strSubInfoIniFilePath = filePath;
} 

/**
* Set data file path EditMode
*/
void CBLE_Model::SetDataFilePath(CString filePath)
{
		m_strDataFilePath = filePath;

		//Write current data path into file Editmode.ini for next open
		GWPPfileData(m_strLocateEditIniFilePath, DBLE_SECTION_EDIT_PRODUCT, DBLE_KEY_EDIT_CURRENTOPEN, false, m_strDataFilePath, CString(""));
}

/**
* Get data file path
*/
CString CBLE_Model::GetDataFilePath()
{
	return m_strDataFilePath;
}


/**
* Read  FCB.ini to get data file path
*/
void CBLE_Model::SetDataFilePath()
{
	GWPPfileData(FCB_INIT_FILE_PATH, "FCB���ް�", "�i���ް��߽��", true, m_strDataFilePath, CString("\\"));
}


/**
* Read  FCB.ini to get machine file path
*/
void CBLE_Model::SetMachineFilePath()
{
	GWPPfileData(FCB_INIT_FILE_PATH, "FCB���ް�", "ϼ��ް��߽��", true, m_strMachineFilePath, CString("\\"));
}

/**
*Set machine file path
*/
void CBLE_Model::SetMachineFilePath(CString filePath)
{
		m_strMachineFilePath = filePath;
}

/**
*Get machine file path
*/
CString CBLE_Model::GetMachineFilePath()
{
		return m_strMachineFilePath;
}

/**
*Release data in order to avoid memory leak
*/
void CBLE_Model::ReleaseData()
{
	m_Substrate.ResetData(false);
}

/**
* Read SubComplex mode from dv_.100 file
*/
int CBLE_Model::GetSubComplexMode()
{
	GWPPfileData(m_strDataFilePath + "\\" + DBLE_MODEL_DV100_NAME, "FC����� �i���ް�(����ިݸ��Ư�)����ިݸ��Ư�:�ڰѐ����ް�_L", "SubstComplex(0:Simple 1:Complex)", true, m_isSubComplex, 1);
	return m_isSubComplex;
}

/**
*Add all ICs to substrate
*/
void CBLE_Model::CreateAllIC(vector<TBLE_RegIC> vOldRegIC)
{
	for(UINT idx = 0; idx < m_vRegIC.size(); idx ++){
		m_Substrate.AddRegNo(&m_vRegIC[idx], (idx < vOldRegIC.size()) ? &vOldRegIC[idx] : NULL);
	}
	m_Substrate.EraseNotNeedOldIC();
}


void CBLE_Model::UpdateRegNo(vector<TBLE_RegIC> vRegIC, bool isChangeShape)
{
	if (vRegIC.size() == 0) {
		// TODO: add code for this case
		TRACE("[Edit]%s(%d):Vector RegIC is null!", __FILE__, __LINE__);
	} else {
		int lessSize = m_vRegIC.size();
		if (lessSize > vRegIC.size()) {
			lessSize = vRegIC.size();
		}
		for (int i = 0; i < lessSize; i++) {
			// If array number not be changed, set m_Changed of regIC become false
			// and not need to create new ICs for this regNo
// #MH130926-01: Not need to change status if shape change
			if (/*!isChangeShape && */(m_vRegIC[i].m_NumberX == vRegIC[i].m_NumberX) && (m_vRegIC[i].m_NumberY == vRegIC[i].m_NumberY)) {
				vRegIC[i].m_Changed = false;
			}
		}
	}
	vector<TBLE_RegIC> tmp;
	tmp = m_vRegIC;
	m_vRegIC.clear();
	m_vRegIC = vRegIC;

	// Clear the current data
	ReleaseData();

	// Create new data
	CreateAllIC(tmp);
	
	//m_Substrate.SetRegionAllICs();
}

/**
*Get data from file with file path define as a parameter
*/
void CBLE_Model::GetDataFromFile(CString filePath190,				// filePath+name of dv_.190
								 CString filePath290,				// filePath+name of dv_.290
								 CString filePath390)				// filePath+name of dv_.390
{
	// Load data from dv_.190 to buffer
	CFile file;
	char* buff = NULL;
	if (file.Open(filePath190, CFile::modeRead | CFile::shareDenyWrite)) { // Denies write access to all others.
		// Get file size to allocate buffer
		long fileLength = (long)file.GetLength();
		buff = new char[fileLength + 1 +1];

		// Read all file into buffer
		file.ReadHuge(buff, fileLength);
		// Add new line character
		buff[fileLength] = '\n';
		// Add a terminal character
		buff[fileLength + 1] = '\0';

		// Close file after read data to buffet
		file.Close();
		// Now, others can read/write file
	}

	// Read RegNo information
	SubstrateShapeDataRW(true, filePath190, buff);
	RegNoDataRW(true, filePath190, buff);
//	IcsDataRW(true, filePath390);
	CreateAllIC(m_vRegIC);

	m_bStartProgress = true; // start progress bar

	// Read offset & valid info for each IC
	OffsetXYDataRW(true, filePath190, buff);
	OffsetTDataRW(true, filePath190, buff);
	LocateValidDataRW(true, filePath190, buff);

	// Read mapping data file
//	MappingDataRW(true, filePath290);

	delete[] buff;
	m_bStartProgress = false; //reset 
	ResetEvent(m_StopThread); //reset event
}

/**
*Get data from folder with folder path define as a parameter
*/
bool CBLE_Model::GetDataFromFolder(CString folderPath)
{
	// Check complex mode
	int isSubComplex = 0;
//	CString file100 = folderPath + "\\" + DBLE_MODEL_DV100_NAME;
//	FileNotFound(file100);
//	GWPPfileData(folderPath + "\\" + DBLE_MODEL_DV100_NAME, "FC����� �i���ް�(����ިݸ��Ư�)����ިݸ��Ư�:�ڰѐ����ް�_L", "SubstComplex(0:Simple 1:Complex)", true, isSubComplex, 1);
//	if (isSubComplex == 0) {
//		return false;
//	}
	isSubComplex = 1;
	m_isSubComplex = isSubComplex;

	// Clear RegNo
	m_vRegIC.clear();
	// Reset data
	m_Substrate.ResetData();

	// Read data from dv_.190 dv_.290 dv_.390
	CString fullFilePath190 = folderPath + "\\" + DBLE_MODEL_DV190_NAME;
	CString fullFilePath290 = folderPath + "\\" + DBLE_MODEL_DV290_NAME;
	CString fullFilePath390 = folderPath + "\\" + DBLE_MODEL_DV390_NAME;
	
	// Warning user if can't find file 190
	FileNotFound(fullFilePath190);
	// Warning user if can't find file 290
//	FileNotFound(fullFilePath290);
	// Warning user if can't find file 390
//	FileNotFound(fullFilePath390);

	// Read data from file 190, 290, 390. In case of file not found or reading get error, default value will be used
	GetDataFromFile(fullFilePath190, fullFilePath290, fullFilePath390);

	// Set region for all ICs
	m_Substrate.SetRegionAllICs();

	// Reset progress bar
	m_ProcessIndex = 0;

	return true;
}

/**
*Save data to file with file path define as a parameter
*/
bool CBLE_Model::SaveDataToFile()
{
	// Check complex mode
	if (GetSubComplexMode() == 0) {
		return false;
	}

	// Data file path
	CString dataFile190 = m_strDataFilePath + "\\" + DBLE_MODEL_DV190_NAME;
	CString dataFile290 = m_strDataFilePath + "\\" + DBLE_MODEL_DV290_NAME;
	CString dataFile390 = m_strDataFilePath + "\\" + DBLE_MODEL_DV390_NAME;

	// Delete section BgLocateICLocation
	GWPPfileDataDelete(dataFile190, DBLE_SECTION_EDIT_REGNO);

	// Write section BgLocateICLocation
	RegNoDataRW(false, dataFile190);
	SubstrateShapeDataRW(false, dataFile190);

	// Delete section angle / Collette / Eject
//	GWPPfileDataDelete(dataFile390, DBLE_SECTION_EDIT_ACE_L);
//	GWPPfileDataDelete(dataFile390, DBLE_SECTION_EDIT_ACE_R);

	// Write data angle / Collette / Eject
//	IcsDataRW(false, dataFile390);
	
	// Delete section BgLocateOffsetXY
	GWPPfileDataDelete(dataFile190, DBLE_SECTION_EDIT_OFFSET_XY);

	// Write section BgLocateOffsetXY
	m_ProcessIndex = 0; // restart process index
	OffsetXYDataRW(false, dataFile190);

	// Delete section BgLocateOffsetT
	GWPPfileDataDelete(dataFile190, DBLE_SECTION_EDIT_OFFSET_T);

	// Write section BgLocateOffsetT
	OffsetTDataRW(false, dataFile190);

	// Delete section BgLocateValid
	GWPPfileDataDelete(dataFile190, DBLE_SECTION_EDIT_ICVALID);

	// Write section BgLocateValid
	LocateValidDataRW(false, dataFile190);

	// Write data mapping file
//	MappingDataRW(false, dataFile290);

	//Reset progress bar
	m_ProcessIndex = 0;

	return true;
}

/**
*Init Edit mode setting
*/
void CBLE_Model::InitEditModeSetting()
{
	CString fileName = m_strLocateEditIniFilePath;
	bool read = true;
	CString section = DBLE_SECTION_EDIT_CONFIG;

	// Language
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_LANGUAGE, read, m_Init.m_Language, DBLE_LANGUAGE_JAPANESE);
	if (m_Init.m_Language != DBLE_LANGUAGE_JAPANESE && m_Init.m_Language != DBLE_LANGUAGE_ENGLISH) {
		m_Init.m_Language = DBLE_LANGUAGE_JAPANESE;	
	}

	// Check&Reflect
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_CHKREF, read, m_Init.m_CheckReflect, 1);

	// Password
	CString pass;
	pass.Format(DBLE_KEY_EDIT_PASSWORD, 1);
	GWPPfileData(fileName, section, pass, read, m_Init.m_PassLevel1, DBLE_MODEL_PASS1_DEFAULT);						// password level 1
	pass.Format(DBLE_KEY_EDIT_PASSWORD, 2);
	GWPPfileData(fileName, section, pass, read, m_Init.m_PassLevel2, DBLE_MODEL_PASS2_DEFAULT);						// password level 2
	pass.Format(DBLE_KEY_EDIT_PASSWORD, 3);			
	GWPPfileData(fileName, section, pass, read, m_Init.m_PassLevel3, DBLE_MODEL_PASS3_DEFAULT);						// password level 3
	
	// Max number of RegNo
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_REGNOMAX, read, m_Init.m_RegNoMax, DBLE_MODEL_REGNO_MAX_DEFAULT);	
	if (m_Init.m_RegNoMax <= 0 || m_Init.m_RegNoMax > DBLE_MODEL_REGNO_MAX_DEFAULT) {
		m_Init.m_RegNoMax = DBLE_MODEL_REGNO_MAX_DEFAULT;
	}
	
	// Max number of IC type
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_ICTYPEMAX, read, m_Init.m_IcTypeMax, DBLE_MODEL_ICTYPE_MAX_DEFAULT);
	if (m_Init.m_IcTypeMax <= 0 || m_Init.m_IcTypeMax > DBLE_MODEL_ICTYPE_MAX_DEFAULT) {
		m_Init.m_IcTypeMax = DBLE_MODEL_ICTYPE_MAX_DEFAULT;
	}
	
	// Bg head tool max
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_BGHEADTOOLMAX, read, m_Init.m_BgHeadToolMax, DBLE_MODEL_BGHEAD_TOOL_MAX_DEFAULT);
	if (m_Init.m_BgHeadToolMax <= 0) {
		m_Init.m_BgHeadToolMax = DBLE_MODEL_BGHEAD_TOOL_MAX_DEFAULT;
	}

	// Pickup Collette max
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLLETTEMAX, read, m_Init.m_PickupColletteMax, DBLE_MODEL_PICKUP_COLLETTE_MAX_DEFAULT);
	if (m_Init.m_PickupColletteMax <= 0) {
		m_Init.m_PickupColletteMax = DBLE_MODEL_PICKUP_COLLETTE_MAX_DEFAULT;
	}

	// Wafer Eject max
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_EJECTMAX, read, m_Init.m_WaferEjectMax, DBLE_MODEL_WAFER_EJECT_MAX_DEFAULT);
	if (m_Init.m_WaferEjectMax <= 0) {
		m_Init.m_WaferEjectMax = DBLE_MODEL_WAFER_EJECT_MAX_DEFAULT;
	}

	// Max number X
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_MAXNUMBERX, read, m_Init.m_ArrayNumberMaxX, DBLE_MODEL_NUMBER_MAXX_DEFAULT);
	if (m_Init.m_ArrayNumberMaxX <= 0) {
		m_Init.m_ArrayNumberMaxX = DBLE_MODEL_NUMBER_MAXX_DEFAULT;
	}

	// Max number Y
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_MAXNUMBERY, read, m_Init.m_ArrayNumberMaxY, DBLE_MODEL_NUMBER_MAXY_DEFAULT);
	if (m_Init.m_ArrayNumberMaxY <= 0) {
		m_Init.m_ArrayNumberMaxY = DBLE_MODEL_NUMBER_MAXY_DEFAULT;
	}

	// Max total IC
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_TOTALMAX, read, m_Init.m_ArrayTotalMax, DBLE_MODEL_TOTAL_DEFAULT);
	if (m_Init.m_ArrayTotalMax <= 0) {
		m_Init.m_ArrayTotalMax = DBLE_MODEL_TOTAL_DEFAULT;
	}

	// Expand table max
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_EXPANDTABMAX, read, m_Init.m_ExpandTableMax, DBLE_MODEL_EXPAND_TABLE_MAX_DEFAULT);
	if (m_Init.m_ExpandTableMax <= 0) {
		m_Init.m_ExpandTableMax = DBLE_MODEL_EXPAND_TABLE_MAX_DEFAULT;
	}

	// IC size min
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_ICSIZEMIN, read, m_Init.m_IcSizeMin, DBLE_MODEL_ICSIZE_MIN_DEFAULT, 2);

	// IC size max
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_ICSIZEMAX, read, m_Init.m_IcSizeMax, DBLE_MODEL_ICSIZE_MAX_DEFAULT, 2);
	
	// Offset value max
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_OFFSETMAX, read, m_Init.m_OffsetValueMax, DBLE_MODEL_OFFSET_MAX_DEFAULT, 2);
	
	// Offset value min
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_OFFSETMIN, read, m_Init.m_OffsetValueMin, DBLE_MODEL_OFFSET_MIN_DEFAULT, 2);
	
	// Expand value max
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_EXPANDMAX, read, m_Init.m_ExpandValueMax, DBLE_MODEL_EXPAND_MAX_DEFAULT, 2);
	
	// Offset value min
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_EXPANDMIN, read, m_Init.m_ExpandValueMin, DBLE_MODEL_EXPAND_MIN_DEFAULT, 2);
	
	// Array of zoom ratio
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_ZOOMRATIO, read, m_Init.m_numberOfZoom, 1);							// read number of zoom ratio
	// Check number of zoom
	if (m_Init.m_numberOfZoom <= 0 || m_Init.m_numberOfZoom > NUMBER_ZOOM_MAX) {
		m_Init.m_numberOfZoom = 1;
	} 
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_ZOOMRATIO, read, m_Init.m_ZoomRatio, m_Init.m_numberOfZoom, 1);		// read array of zoom ratio
	
	// Array of shape name
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_SHAPENAME, read, m_Init.m_numberOfShape, 0);	// read number of shape name
	// Check number of shape
	if (m_Init.m_numberOfShape <= 0 || m_Init.m_numberOfShape > NUMBER_SHAPE_MAX) {
		m_Init.m_numberOfShape = 1;
	}
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_SHAPENAME, read, m_Init.m_ShapeName, m_Init.m_numberOfShape, CString(""));
	InitShapeName();
	
	// Time out
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_TIMEOUT, read, m_Init.m_TimeOutEdit, 1);

	GWPPfileData(fileName, section, DBLE_KEY_EDIT_NEIGHBORLMT, read, m_Init.m_NeighborLimit, 1);
	m_Substrate.SetNeighborLimit(m_Init.m_NeighborLimit);

	// Section product data
	section = DBLE_SECTION_EDIT_PRODUCT;
	
	// Current open device
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_CURRENTOPEN, read, m_Init.m_CurrentOpen, "");
	
	// Is subcomplex mode: default value is complex mode
//	GWPPfileData(m_Init.m_CurrentOpen + "\\" + DBLE_MODEL_DV100_NAME, "FC����� �i���ް�(����ިݸ��Ư�)����ިݸ��Ư�:�ڰѐ����ް�_L", "SubstComplex(0:Simple 1:Complex)", true, m_isSubComplex, 1);
	m_isSubComplex = 1;
// #DDT140116: Setting color
	section = DBLE_SECTION_EDIT_COLOR;
	int color[3];
	// Cursor color
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_CURSOR, read, color, 3, 0);
	m_StatusColor.m_Cursor = RGB(color[0], color[1], color[2]);
	
	// Focus color
	GWPPfileData(fileName, section,DBLE_KEY_EDIT_COLOR_FOCUS, read, color, 3, 0);
	m_StatusColor.m_Focus = RGB(color[0], color[1], color[2]);
	
	// Valid display color
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_VALID, read, color, 3, 0);
	m_StatusColor.m_ValidDisp = RGB(color[0], color[1], color[2]);
	
	// Overlap color
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_OVERLAP, read, color, 3, 0);
	m_StatusColor.m_OverlapDisp = RGB(color[0], color[1], color[2]);
	
	// Regno color
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_REGNO, read, color, 3, 0);
	m_StatusColor.m_Regno = RGB(color[0], color[1], color[2]);
	
	// Centerline color
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_CENTERLINE, read, color, 3, 0);
	m_StatusColor.m_CenterLine = RGB(color[0], color[1], color[2]);
	
	// Index color
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_INDEX, read, color, 3, 0);
	m_StatusColor.m_IndexDisp = RGB(color[0], color[1], color[2]);
	
	// Shape color
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_SHAPE, read, color, 3, 0);
	m_StatusColor.m_Shape = RGB(color[0], color[1], color[2]);
}

/**
*Init SubInfo mode setting
*/
void CBLE_Model::InitSubInfoModeSetting()
{
	CString fileName = m_strSubInfoIniFilePath;
	bool read = true;

	// Configuration section
	CString section = DBLE_SECTION_INFO_CONFIG;

	// Language
	GWPPfileData(fileName, section, DBLE_KEY_INFO_LANGUAGE, read, m_Init.m_Language, DBLE_LANGUAGE_JAPANESE);
	if (m_Init.m_Language != DBLE_LANGUAGE_JAPANESE && m_Init.m_Language != DBLE_LANGUAGE_ENGLISH) {
		m_Init.m_Language = DBLE_LANGUAGE_JAPANESE;
	}

	int color[3];
	
	// Unknow color
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRUNKNOW, read, color, 3, 0);
	m_StatusColor.m_UnknownClr = RGB(color[0], color[1], color[2]);
	
	// Bad color
	GWPPfileData(fileName, section,DBLE_KEY_INFO_CLRBAD, read, color, 3, 0);
	m_StatusColor.m_BadClr = RGB(color[0], color[1], color[2]);
	
	// Good color
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRGOOD, read, color, 3, 0);
	m_StatusColor.m_GoodClr = RGB(color[0], color[1], color[2]);
	
	// Not done color
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRNOTDONE, read, color, 3, 0);
	m_StatusColor.m_NotDoneClr = RGB(color[0], color[1], color[2]);
	
	// Fail color
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRFAIL, read, color, 3, 0);
	m_StatusColor.m_FailClr = RGB(color[0], color[1], color[2]);
	
	// Done color
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRDONE, read, color, 3, 0);
	m_StatusColor.m_DoneClr = RGB(color[0], color[1], color[2]);
	
	// Stack color
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRSTACK, read, color, 3, 0);
	m_StatusColor.m_StackClr = RGB(color[0], color[1], color[2]);
	
	// Don't need color
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRDONTNEED, read, color, 3, 0);
	m_StatusColor.m_NoNeedClr= RGB(color[0], color[1], color[2]);
	
	// Time out
	GWPPfileData(fileName, section, DBLE_KEY_INFO_TIMEOUT, read, m_Init.m_TimeOutSubInfo, 1);
	
	
	// SubstMap section
	section = DBLE_SECTION_INFO_DESTPATH;

	// destination path 
	GWPPfileData(fileName, section, DBLE_KEY_INFO_DESTPATH, read, m_Init.m_DestPath, "");
}

/**
*Get AutoToolchange
*/
int CBLE_Model::GetAutoToolChange()
{
	CString fileName = m_strMachineFilePath + "\\" +DBLE_MODEL_MC000_NAME;
	int ret;
	GWPPfileData(fileName, "FC����� ϼ��ް�:���u�I�v�V����", "����°ٌ����i0:�� 2~�L�̎��͍ő�°ِ���ݒ�)", true, ret, 0);
	return ret;
}

/**
*Get collettte number
*/
int CBLE_Model::GetColletteNumber()
{
	int ret;
	GWPPfileData(FCB_PD300_FILE_PATH, "FC����� ���Y�Ǘ��ް�(IC�����Ư�):�߯������Ư��ް�_L", "Number of collette", true, ret, 0);
	return ret;
}

/**
*Get ejector number
*/
int CBLE_Model::GetEjectorNumber()
{
	int ret;
	GWPPfileData(FCB_PD300_FILE_PATH, "FC����� ���Y�Ǘ��ް�(IC�����Ư�):�߯������Ư��ް�_L", "Number of ejector", true, ret, 1);
	return ret;
}

/**
* Get Mapping method in file dv_.100
*/
int CBLE_Model::GetMappMethod()
{
	int ret;
	GWPPfileData(m_strDataFilePath + "\\" + DBLE_MODEL_DV100_NAME, "FC����� �i���ް�(����ިݸ��Ư�)����ިݸ��Ư�:�ڰѐ����ް�_L", "ϯ�ߗL��(0:����, 1:�Ȉ�ϯ��, 2:ϯ��ݸ�)", true, ret, 1);
	return ret;
}

/**
*Create all RegNo: read from dv_.190
*/
bool CBLE_Model::RegNoDataRW(bool read, LPCTSTR lpFileName, char* buff)
{
	bool		ret = true;
	int			numberOfRegNo = 0;											// number of RegNo
	int			regNoArr[DBLE_MODEL_REGNO_MAX_DEFAULT];						// array of IC type
	int			toolL[DBLE_MODEL_REGNO_MAX_DEFAULT];						// array of IC type
	int			toolR[DBLE_MODEL_REGNO_MAX_DEFAULT];						// array of IC type
	int			regNo;														// regNo index
	R2Pos		pos;
	CString		secRegNo = DBLE_SECTION_EDIT_REGNO;
	CString		secToolL = DBLE_SECTION_EDIT_TOOL_L;
	CString		secToolR = DBLE_SECTION_EDIT_TOOL_R;
	CString		key;
	CString		tmp;

	// Initialize value
	for (int id = 0; id < DBLE_MODEL_REGNO_MAX_DEFAULT; id++) {
		toolL[id] = 1;
		toolR[id] = 1;
		regNoArr[id] = 0;
	}

	// Invalid data for IC size, pitch, start position
	R2Pos		invalidIcSize = m_Init.m_IcSizeMax;			
	R2Pos		invalidPitch = m_Init.m_IcSizeMax;
	R2Pos		invalidStartPos(0, 0);
	int			defaultNumberXY = 1;

	// RegNo
	TBLE_RegIC	regIC;
	if (read) {
		long secIdx = 0;

		// Find index of regno section in buffer
		if (buff != NULL) {
			secIdx = GetSectionIndex(secRegNo, buff);
		}

		GWPPfileData(lpFileName, secRegNo, DBLE_KEY_BGSITE_ICTYPE, read, numberOfRegNo, 0, buff, secIdx);
		// Invalid number of RegNo
		if (numberOfRegNo <= 0 || numberOfRegNo > m_Init.m_RegNoMax) {
			numberOfRegNo = 1;
		}
		GWPPfileData(lpFileName, secRegNo, DBLE_KEY_BGSITE_ICTYPE, read, regNoArr, numberOfRegNo, 1, false, buff, secIdx);
		// Check value/number of IC type
		GetNumberOfElement(regNoArr, numberOfRegNo, m_Init.m_IcTypeMax);

		// Read ToolL
		// Find index of secToolL in buffer
		if (buff != NULL) {
			secIdx = GetSectionIndex(secToolL, buff);
		}

		GWPPfileData(lpFileName, secToolL, DBLE_KEY_BGSITE_TOOL, read, toolL, numberOfRegNo, 1, false, buff, secIdx);
		// Check value/number of tool L
		GetNumberOfElement(toolL, numberOfRegNo, m_Init.m_BgHeadToolMax);
		
		// Find index of secToolR in buffer
		if (buff != NULL) {
			secIdx = GetSectionIndex(secToolR, buff);
		}
		GWPPfileData(lpFileName, secToolR, DBLE_KEY_BGSITE_TOOL, read, toolR, numberOfRegNo, 1, false, buff, secIdx);
		// Check value/number of tool R
		GetNumberOfElement(toolR, numberOfRegNo, m_Init.m_BgHeadToolMax);

		// Create vector RegNo
		// Find index of regno section in buffer
		if (buff != NULL) {
			secIdx = GetSectionIndex(secRegNo, buff);
		}
		for (int i = 0; i < numberOfRegNo; i++) {
			regNo = i + 1;
			regIC.m_RegNo = regNo;
			regIC.m_Type = regNoArr[i];
			
			// Max number X
			key.Format(DBLE_KEY_BGSITE_NUMBERX, regNo);
			GWPPfileData(lpFileName, secRegNo, key, read, regIC.m_NumberX, 0, buff, secIdx);
			// Check number X in range
			regIC.m_NumberX = (regIC.m_NumberX > m_Init.m_ArrayNumberMaxX || regIC.m_NumberX < 1) ? /*m_Init.m_ArrayNumberMaxX*/defaultNumberXY : regIC.m_NumberX;
			
			// Max number Y
			key.Format(DBLE_KEY_BGSITE_NUMBERY, regNo);
			GWPPfileData(lpFileName, secRegNo, key, read, regIC.m_NumberY, 0, buff, secIdx);
			// Check number Y in range
			regIC.m_NumberY = (regIC.m_NumberY > m_Init.m_ArrayNumberMaxY || regIC.m_NumberY < 1) ? /*m_Init.m_ArrayNumberMaxY*/defaultNumberXY : regIC.m_NumberY;
			
			regIC.m_ToolL = toolL[i];
			regIC.m_ToolR = toolR[i];
			
			// IC size
			key.Format(DBLE_KEY_BGSITE_ICSIZE, regNo);
			GWPPfileData(lpFileName, secRegNo, key, read, pos, invalidIcSize, 2, buff, secIdx);
			// Check ic size in range
			if (pos >> m_Init.m_IcSizeMax) {
				pos = m_Init.m_IcSizeMax;
			} else if (pos << m_Init.m_IcSizeMin) {
				pos = m_Init.m_IcSizeMin;
			}
			regIC.m_SizeX = pos.X();
			regIC.m_SizeY = pos.Y();
			
			// IC pitch
			key.Format(DBLE_KEY_BGSITE_PITCH, regNo);
			GWPPfileData(lpFileName, secRegNo, key, read, pos, invalidPitch, 2, buff, secIdx);
			// Check pitch?
			if (pos <<= R2Pos(regIC.m_SizeX, regIC.m_SizeY)) {
				pos = invalidPitch;
			}
			regIC.m_PitchX = pos.X();
			regIC.m_PitchY = pos.Y();
			
			// Start position
			key.Format(DBLE_KEY_BGSITE_STARTPOS, regNo);
			GWPPfileData(lpFileName, secRegNo, key, read, pos, invalidStartPos, 2, buff, secIdx);
			regIC.m_StartPosX = pos.X();
			regIC.m_StartPosY = pos.Y();
			// Push regIC to vector regIC
			m_vRegIC.push_back(regIC);
		}
	} else {
		numberOfRegNo = m_vRegIC.size();
		// Create vector RegNo
		for (int i = 0; i < numberOfRegNo; i++) {
			
			regNoArr[i] = m_vRegIC[i].m_Type;
			regNo = m_vRegIC[i].m_RegNo;
			regIC =  m_vRegIC[i];
			
			// Max number X
			key.Format(DBLE_KEY_BGSITE_NUMBERX, regNo);
			GWPPfileData(lpFileName, secRegNo, key, read, regIC.m_NumberX, 0);
			
			// Max number Y
			key.Format(DBLE_KEY_BGSITE_NUMBERY, regNo);
			GWPPfileData(lpFileName, secRegNo, key, read, regIC.m_NumberY, 0);
			
			// Tool L&R
			toolL[i] = regIC.m_ToolL;
			toolR[i] = regIC.m_ToolR;
			
			// IC size
			key.Format(DBLE_KEY_BGSITE_ICSIZE, regNo);
			pos.X() = regIC.m_SizeX;
			pos.Y() = regIC.m_SizeY;
			GWPPfileData(lpFileName, secRegNo, key, read, pos, invalidIcSize, 2);
			
			// IC pitch
			key.Format(DBLE_KEY_BGSITE_PITCH, regNo);
			pos.X() = regIC.m_PitchX;
			pos.Y() = regIC.m_PitchY;
			GWPPfileData(lpFileName, secRegNo, key, read, pos, invalidPitch, 2);
			
			// Start position
			key.Format(DBLE_KEY_BGSITE_STARTPOS, regNo);
			pos.X() = regIC.m_StartPosX;
			pos.Y() = regIC.m_StartPosY;
			GWPPfileData(lpFileName, secRegNo, key, read, pos, invalidStartPos, 2);
			
			// Bgsite name
			key.Format(DBLE_KEY_BGSITE_NAME, regNo);
			tmp.Format("R%d", regNo);
			GWPPfileData(lpFileName, secRegNo, key, read, tmp, CString(""));
		}

		// Write tool L&R
		GWPPfileData(lpFileName, secToolL, DBLE_KEY_BGSITE_TOOL, read, toolL, m_Init.m_RegNoMax, 1);
		GWPPfileData(lpFileName, secToolR, DBLE_KEY_BGSITE_TOOL, read, toolR, m_Init.m_RegNoMax, 1);

		// Write IC type array
		key = DBLE_KEY_BGSITE_ICTYPE;
		GWPPfileData(lpFileName, secRegNo, key, read, regNoArr, numberOfRegNo, 0);
	}
	return ret;
}

/**
*Read/Write data substrate shape
*/

bool CBLE_Model::SubstrateShapeDataRW(bool read, LPCTSTR lpFileName, char* buff)
{
	// BgLocation section
	char *sec = DBLE_SECTION_EDIT_REGNO;
	long secIdx = 0;

	if (buff != NULL) {
		secIdx = GetSectionIndex(sec, buff);
	}
	bool ret = true;
	
	if (read) {
		int shapeID;

		// Read substrate shape
		GWPPfileData(lpFileName, sec, DBLE_KEY_SUBTSHAPE, read, shapeID, 1, buff, secIdx);
		
		if (shapeID <= 0 || shapeID > m_vShape.size()) {
			shapeID = 1;
		}

		// Set substrate shape 
		m_Substrate.SetShape(shapeID, m_vShape[shapeID - 1].shape, m_vShape[shapeID - 1].sizeX, m_vShape[shapeID - 1].sizeY);

	} else {

		// Write substrate shape
		GWPPfileData(lpFileName, sec, DBLE_KEY_SUBTSHAPE, read, m_Substrate.m_ShapeID, 1);
	}

	return ret;
}

/**
* Read data from dv_.290
*/
bool CBLE_Model::MappingDataRW(bool read, LPCTSTR lpFileName) {
	// Section
	CString sec = DBLE_SECTION_EDIT_MAPP;

	GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_BCREAD, read, m_MapData.m_BCRead, 0);
	GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_REFND, read, m_MapData.m_RefND, 0);
	GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_FNLOC, read, m_MapData.m_OriFlat, 0);
	GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_RPSEL, read, m_MapData.m_RefDie, 0);
	GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_REFPX, read, m_MapData.m_RefDieX, 0);
	GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_REFPY, read, m_MapData.m_RefDieY, 0);
	GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_PRDCT, read, m_MapData.m_ProcessDie, 0);
	GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_MLCL, read, m_MapData.m_MessLength, 0);
	//GWPPfileData(lpFileName, sec, "STRPX", read, m_MapData.m_StartDieX, 0);
	//GWPPfileData(lpFileName, sec, "STRPY", read, m_MapData.m_StartDieY, 0);
	// Read data string
	if (read) {
		//GWPPfileData(lpFileName, sec, "MID", read, m_MapData.m_SubsID, CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_FID, read, m_MapData.m_FID, CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_DUTMS, read, m_MapData.m_DiePoint, CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_BCEQU, read, m_MapData.m_GoodBin, CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_NULBC, read, m_MapData.m_NullBin, CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_BCPAS, read, m_MapData.m_PassBin, CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_BCBND, read, m_MapData.m_BondedBin, CString(""));
	} else {
		// Write data string
		//GWPPfileData(lpFileName, sec, "MID", read, _T("'") + m_MapData.m_SubsID + _T("'"), CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_FID, read, _T("'") + m_MapData.m_FID + _T("'"), CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_DUTMS, read, _T("'") + m_MapData.m_DiePoint + _T("'"), CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_BCEQU, read, _T("'") + m_MapData.m_GoodBin + _T("'"), CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_NULBC, read, _T("'") + m_MapData.m_NullBin + _T("'"), CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_BCPAS, read, _T("'") + m_MapData.m_PassBin + _T("'"), CString(""));
		GWPPfileData(lpFileName, sec, DBLE_KEY_MAPP_BCBND, read, _T("'") + m_MapData.m_BondedBin + _T("'"), CString(""));
	}

	return true;
}

/**
* Read data from dv_.390
*/
bool CBLE_Model::IcsDataRW(bool read, LPCTSTR lpFileName) {
	bool		ret = true;
	int			numberOfRegNo = 0;											// number of RegNo
	int			regNo;														// regNo index
	int			icType;														// IC type
	R2Pos		pos;
	CString		secL = DBLE_SECTION_EDIT_ACE_L;
	CString		secR = DBLE_SECTION_EDIT_ACE_R;
	CString		key;

	// RegNo
	TBLE_RegIC	regIC;
	numberOfRegNo = m_vRegIC.size();

	// Update vector RegNo
	for (int i = 0; i < numberOfRegNo; i++) {
		regNo = m_vRegIC[i].m_RegNo;
		icType = m_vRegIC[i].m_Type;

		// Angle
		key.Format(DBLE_KEY_ICANGLE, regNo);
		// Convert rad->deg/deg->rad
		if (read) {								
			GWPPfileData(lpFileName, secL, key, read, m_vRegIC[i].m_Angle, DBLE_MODEL_IC_OFFSETT_DEFAULT, 0/*2*/);			// Read 10 digits after point
			// Check value of angle value
			if (m_vRegIC[i].m_Angle < -(2 * PI) || m_vRegIC[i].m_Angle > (2 * PI)) {
				m_vRegIC[i].m_Angle = 0;
			}
			m_vRegIC[i].m_Angle = RAD_TO_DEG(m_vRegIC[i].m_Angle);
		} else {
			// Keep Reg Angle in degree, only written data in radian
			double tmp = DEG_TO_RAD(m_vRegIC[i].m_Angle);
			GWPPfileData(lpFileName, secL, key, read, tmp, DBLE_MODEL_IC_OFFSETT_DEFAULT, 0/*2*/);			// Write 10 digits after point for left side
			GWPPfileData(lpFileName, secR, key, read, tmp, DBLE_MODEL_IC_OFFSETT_DEFAULT, 0/*2*/);			// Write 10 digits after point for right side
		}
		//GWPPfileData(lpFileName, secR, key, read, m_vRegIC[i].m_Angle, DBLE_MODEL_IC_OFFSETT_DEFAULT, 2);

		// Collette L&R
		key.Format(DBLE_KEY_ICCOLLETTE, icType);	
		GWPPfileData(lpFileName, secL, key, read, m_vRegIC[i].m_ColletteL, 1);
		GWPPfileData(lpFileName, secR, key, read, m_vRegIC[i].m_ColletteR, 1);

		// Check value of collette after read from file
		if (read) {

			// Left side
			if (m_vRegIC[i].m_ColletteL <= 0 || m_vRegIC[i].m_ColletteL > m_Init.m_PickupColletteMax) {
				m_vRegIC[i].m_ColletteL = DBLE_MODEL_PICKUP_COLLETTE_DEFAULT;
			}

			// Right side
			if (m_vRegIC[i].m_ColletteR <= 0 || m_vRegIC[i].m_ColletteR > m_Init.m_PickupColletteMax) {
				m_vRegIC[i].m_ColletteR = DBLE_MODEL_PICKUP_COLLETTE_DEFAULT;
			}
		}

		// Eject L&R
		key.Format(DBLE_KEY_ICEJECTOR, icType);
		GWPPfileData(lpFileName, secL, key, read, m_vRegIC[i].m_EjectL, 1);
		GWPPfileData(lpFileName, secR, key, read, m_vRegIC[i].m_EjectR, 1);

		// Check value of ejector after read from file
		if (read) {

			// Left side
			if (m_vRegIC[i].m_EjectL <= 0 || m_vRegIC[i].m_EjectL > m_Init.m_WaferEjectMax) {
				m_vRegIC[i].m_EjectL = DBLE_MODEL_WAFER_EJECT_DEFAULT;
			}
			
			// Right side
			if (m_vRegIC[i].m_EjectR <= 0 || m_vRegIC[i].m_EjectR > m_Init.m_WaferEjectMax) {
				m_vRegIC[i].m_EjectR = DBLE_MODEL_WAFER_EJECT_DEFAULT;
			}
		}
	}

	return ret;
}

/**
* Read/Write offset XY data
*/
bool CBLE_Model::OffsetXYDataRW(bool read, LPCTSTR lpFileName, char* buff)
{
	// Locate offset XY section
	char *OffsetXYSec = DBLE_SECTION_EDIT_OFFSET_XY;
	long OffsetXYSecIdx = 0;

	if (buff != NULL) {
		OffsetXYSecIdx = GetSectionIndex(OffsetXYSec, buff);
	}

	bool ret = true;
	// Number of RegNo
	int numberOfRegNo = m_vRegIC.size(); 
	// RegNo value
	int regNo;
	// Max value axis X, Y
	int maxX, maxY;
	// Key to read/write
	CString key;
	// Array of XY offset data
	R2Pos data[DBLE_MODEL_ELEMENT_LINE];
	// Vector of IC
	vector<CBLE_IC*> vIC = m_Substrate.m_vIC;	

	int gap = 0, line = 0, count = 0, index = 0;
	for (int i = 0; i < numberOfRegNo; i++) {

		// Number of IC (axis X)
		maxX = m_vRegIC[i].m_NumberX;

		// Number of IC (axis Y)
		maxY = m_vRegIC[i].m_NumberY;

		// RegNo
		regNo = m_vRegIC[i].m_RegNo;
		if(i != 0) {
			gap += m_vRegIC[i-1].m_NumberX * m_vRegIC[i-1].m_NumberY;
		}

		// Number of lines
		line = ((maxX % DBLE_MODEL_ELEMENT_LINE) == 0) ? (maxX / DBLE_MODEL_ELEMENT_LINE) : (maxX / DBLE_MODEL_ELEMENT_LINE) + 1;
		
		// Loop row
		if (read) {
			for (int j = 0; j < maxY; j++) {
				if (::WaitForSingleObject(m_StopThread, 0) == WAIT_OBJECT_0) {
					return false;
				}
				count = 0;
				for (int k = 0; k < line; k++) {
					
					count = (maxX >= DBLE_MODEL_ELEMENT_LINE * (k + 1)) ? DBLE_MODEL_ELEMENT_LINE : (maxX - DBLE_MODEL_ELEMENT_LINE * k);
					
					// Read offset XY section
					key.Format(DBLE_KEY_OFFSET_XY, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
					GWPPfileData(lpFileName, OffsetXYSec, key, read, data, count, DBLE_MODEL_IC_OFFSETXY_DEFAULT, 2, false, buff, OffsetXYSecIdx);
					
					// Update IC
					for (int m = 0; m < count; m++) {
						index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;

						// Check value range of offset
						if (data[m] << m_Init.m_OffsetValueMin) {
							data[m] = m_Init.m_OffsetValueMin;
						} else if (data[m] >> m_Init.m_OffsetValueMax) {
							data[m] = m_Init.m_OffsetValueMax;
						}

						vIC[index]->m_OffsetX = data[m].X();
						vIC[index]->m_OffsetY = data[m].Y();
					}

					m_ProcessIndex = index / 3; //update process
				}	
			}
		} else {
			for (int j = 0; j < maxY; j++) {
				count = 0;
				for (int k = 0; k < line; k++) {
					count = (maxX >= DBLE_MODEL_ELEMENT_LINE * (k + 1)) ? DBLE_MODEL_ELEMENT_LINE : (maxX - DBLE_MODEL_ELEMENT_LINE * k);
					for (int m = 0; m < count; m++) {
						index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
						data[m].X() = vIC[index]->m_OffsetX;
						data[m].Y() = vIC[index]->m_OffsetY;
					}
					// Write offset XY section
					key.Format(DBLE_KEY_OFFSET_XY, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
					GWPPfileData(lpFileName, OffsetXYSec, key, read, data, count, DBLE_MODEL_IC_OFFSETXY_DEFAULT, 2, true);

					m_ProcessIndex = index / 3; //update process index
				}
			}
		}
		
	}
	return ret;
}

/**
*Read/Write offset T data
*/
bool CBLE_Model::OffsetTDataRW(bool read, LPCTSTR lpFileName, char* buff)
{
	int size = GetSubstrate()->m_vIC.size() / 3; // for progress bar only

	// Locate offset T section
	char *OffsetTSec = DBLE_SECTION_EDIT_OFFSET_T;
	long OffsetTSecIdx = 0;

	if (buff != NULL) {
		OffsetTSecIdx = GetSectionIndex(OffsetTSec, buff);
	}

	bool ret = true;
	
	// Number of RegNo
	int numberOfRegNo = m_vRegIC.size(); 
	
	// RegNo value
	int regNo;
	
	// Max value axis X, Y
	int maxX, maxY;
	
	// Key to read/write
	CString key;
	
	// Array of T offset data
	double data[DBLE_MODEL_ELEMENT_LINE];
	// Vector of IC
	vector<CBLE_IC*> vIC = m_Substrate.m_vIC;	

	int gap = 0, line = 0, count = 0, index = 0;
	for (int i = 0; i < numberOfRegNo; i++) {
		
		// Number of IC (axis X)
		maxX = m_vRegIC[i].m_NumberX;
		
		// Number of IC (axis Y)
		maxY = m_vRegIC[i].m_NumberY;
		
		// RegNo
		regNo = m_vRegIC[i].m_RegNo;
		if(i != 0) {
			gap += m_vRegIC[i-1].m_NumberX * m_vRegIC[i-1].m_NumberY;
		}

		// Number of lines
		line = ((maxX % DBLE_MODEL_ELEMENT_LINE) == 0) ? (maxX / DBLE_MODEL_ELEMENT_LINE) : (maxX / DBLE_MODEL_ELEMENT_LINE) + 1;
		
		// Loop row
		if (read) {
			for (int j = 0; j < maxY; j++) {
				if (::WaitForSingleObject(m_StopThread, 0) == WAIT_OBJECT_0) {
					return false;
				}
				count = 0;
				for (int k = 0; k < line; k++) {
					
					count = (maxX >= DBLE_MODEL_ELEMENT_LINE * (k + 1)) ? DBLE_MODEL_ELEMENT_LINE : (maxX - DBLE_MODEL_ELEMENT_LINE * k);
					
					// Read offset T section
					key.Format(DBLE_KEY_OFFSET_T, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
					GWPPfileData(lpFileName, OffsetTSec, key, read, data, count,DBLE_MODEL_IC_OFFSETT_DEFAULT, 0 /*2*/, false, buff, OffsetTSecIdx);
					
					// Update IC
					for (int m = 0; m < count; m++) {

						index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;

						// Check range of offsetT
						if (data[m] < -(2 * PI) || data[m] > (2 * PI)) {
							data[m] = 0;
						}

						vIC[index]->m_OffsetT = RAD_TO_DEG(data[m]);
					}

					m_ProcessIndex = size + index / 3; //update process
				}	
			}
		} else {
			for (int j = 0; j < maxY; j++) {
				count = 0;
				for (int k = 0; k < line; k++) {
					count = (maxX >= DBLE_MODEL_ELEMENT_LINE * (k + 1)) ? DBLE_MODEL_ELEMENT_LINE : (maxX - DBLE_MODEL_ELEMENT_LINE * k);
					for (int m = 0; m < count; m++) {
						index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
						data[m] = DEG_TO_RAD(vIC[index]->m_OffsetT);
					}

					// Write offset T section
					key.Format(DBLE_KEY_OFFSET_T, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
					GWPPfileData(lpFileName, OffsetTSec, key, read, data, count, DBLE_MODEL_IC_OFFSETT_DEFAULT, 0/*2*/, true);
					
					m_ProcessIndex = size + index / 3; //update process
				}	
			}
		}

	}
	return ret;
}

/**
* Save password
*/
void CBLE_Model::SavePassword(CString newPass, int level)
{
	CString section = DBLE_SECTION_EDIT_CONFIG;
	CString pass;
	if (level == DBLE_USER_LEVEL1) {
		pass.Format(DBLE_KEY_EDIT_PASSWORD, 1);
		GWPPfileData(m_strLocateEditIniFilePath, section, pass, false, m_Init.m_PassLevel1, CString("0001"));						// password level 1
	} else if (level == DBLE_USER_LEVEL2) {
		pass.Format(DBLE_KEY_EDIT_PASSWORD, 2);
		GWPPfileData(m_strLocateEditIniFilePath, section, pass, false, m_Init.m_PassLevel2, CString("0002"));						// password level 2
	} else if (level == DBLE_USER_LEVEL3) {
		pass.Format(DBLE_KEY_EDIT_PASSWORD, 3);
		GWPPfileData(m_strLocateEditIniFilePath, section, pass, false, m_Init.m_PassLevel3, CString("0003"));						// password level 3
	}
}

/**
* Load/Save status
*/
bool CBLE_Model::StatusRW(bool read, LPCTSTR lpFileName, DBLE_SUBINFO_TYPE lrMode, int bdMode)
{
	bool ret = true;
	
	// Number of RegNo
	int numberOfRegNo = m_vRegIC.size(); 
	
	// RegNo value
	int regNo;
	
	// Max value axis X, Y
	int maxX, maxY;
	
	// Key to read/write
	CString key;
	CString sectionBond = DBLE_SECTION_STATUSRW_BOND;
	CString sectionDetect = DBLE_SECTION_STATUSRW_DETECT;
	
	// Array of data
	int data[DBLE_MODEL_ELEMENT_LINE];
	
	// Vector of IC
	vector<CBLE_IC*> vIC = m_Substrate.m_vIC;	
	CString fileName = m_strDataFilePath + "\\" + lpFileName;
	int gap = 0, line = 0, count = 0, index = 0;
	for (int i = 0; i < numberOfRegNo; i++) {
		
		// Number of IC (axis X)
		maxX = m_vRegIC[i].m_NumberX;
		
		// Number of IC (axis Y)
		maxY = m_vRegIC[i].m_NumberY;
		
		// RegNo
		regNo = m_vRegIC[i].m_RegNo;
		if(i != 0) {
			gap += m_vRegIC[i-1].m_NumberX * m_vRegIC[i-1].m_NumberY;
		}
		// Number of lines
		line = ((maxX % DBLE_MODEL_ELEMENT_LINE) == 0) ? (maxX / DBLE_MODEL_ELEMENT_LINE) : (maxX / DBLE_MODEL_ELEMENT_LINE) + 1;
		
		if (read) {
			
			// Read file to buffer
			CFile file;
			char* buff = NULL;
			long offset = 0;
			if (file.Open(fileName, CFile::modeRead | CFile::shareDenyWrite)) { // Denies write access to all others.
				
				// Get file size to allocate buffer
				long fileLength = file.GetLength();
				buff = new char[fileLength + 1];

				// Read all file into buffer
				file.ReadHuge(buff, fileLength);

				// Close file after read data to buffer
				file.Close();
				// Now, others can read/write file
			}
			
			// Offset
			if (buff != NULL) {
				if(lrMode == DBLE_SUBINFO_TYPE_L && bdMode == DBLE_SUBINFO_BOND_MODE) {
					offset = GetSectionIndex(sectionBond + "Left", buff);
				}
				if(lrMode == DBLE_SUBINFO_TYPE_R && bdMode == DBLE_SUBINFO_BOND_MODE) {
					offset = GetSectionIndex(sectionBond + "Right", buff);
				}
				if(lrMode == DBLE_SUBINFO_TYPE_L && bdMode == DBLE_SUBINFO_DETECT_MODE) {
					offset = GetSectionIndex(sectionDetect + "Left", buff);
				}
				if(lrMode == DBLE_SUBINFO_TYPE_R && bdMode == DBLE_SUBINFO_DETECT_MODE) {
					offset = GetSectionIndex(sectionDetect + "Right", buff);
				}
			}

			// Loop row
			for (int j = 0; j < maxY; j++) {
				count = 0;
				for (int k = 0; k < line; k++) {
					count = (maxX >= DBLE_MODEL_ELEMENT_LINE * (k + 1)) ? DBLE_MODEL_ELEMENT_LINE : (maxX - DBLE_MODEL_ELEMENT_LINE * k);
					
					// Read data
					if (lrMode == DBLE_SUBINFO_TYPE_L) {
						if (bdMode == DBLE_SUBINFO_BOND_MODE) {				// Bond left
							
							key.Format(DBLE_KEY_STATUSRW_BOND, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));					
							GWPPfileData(fileName, sectionBond + "Left", key, read, data, count, DBLE_BOND_NOTDONE, false, buff, offset);
							
							// Update IC
							for (int m = 0; m < count; m++) {
								index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
								vIC[index]->m_BondingL = (DBLE_BondState)data[m];
							}

						} else if (bdMode == DBLE_SUBINFO_DETECT_MODE) {	// Detect left
							
							key.Format(DBLE_KEY_STATUSRW_DETECT, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));					
							GWPPfileData(fileName, sectionDetect + "Left", key, read, data, count,DBLE_DETECT_UNKNOWN, false, buff, offset);
							
							// Update IC
							for (int m = 0; m < count; m++) {
								index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
								vIC[index]->m_DetectL = (DBLE_DetectState)data[m];
							}
						}

					} else if (lrMode == DBLE_SUBINFO_TYPE_R) {
						if (bdMode == DBLE_SUBINFO_BOND_MODE) {				// Bond right
							
							key.Format(DBLE_KEY_STATUSRW_BOND, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));					
							GWPPfileData(fileName, sectionBond + "Right", key, read, data, count, DBLE_BOND_NOTDONE, false, buff, offset);
							
							// Update IC
							for (int m = 0; m < count; m++) {
								index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
								vIC[index]->m_BondingR = (DBLE_BondState)data[m];
							}

						} else if (bdMode == DBLE_SUBINFO_DETECT_MODE) {	// Detect right
							
							key.Format(DBLE_KEY_STATUSRW_DETECT, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));					
							GWPPfileData(fileName, sectionDetect + "Right", key, read, data, count, DBLE_DETECT_UNKNOWN, false, buff, offset);
							
							// Update IC
							for (int m = 0; m < count; m++) {
								index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
								vIC[index]->m_DetectR = (DBLE_DetectState)data[m];
							}
						}
						
					}
				}	
			}
			
			// Release bufer
			delete[] buff;

		} else {
			for (int j = 0; j < maxY; j++) {
				count = 0;
				for (int k = 0; k < line; k++) {
					
					count = (maxX >= DBLE_MODEL_ELEMENT_LINE * (k + 1)) ? DBLE_MODEL_ELEMENT_LINE : (maxX - DBLE_MODEL_ELEMENT_LINE * k);
					
					if (lrMode == DBLE_SUBINFO_TYPE_L) {
						if (bdMode == DBLE_SUBINFO_BOND_MODE) {	
							
							for (int m = 0; m < count; m++) {
								index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
								data[m] = vIC[index]->m_BondingL;
							}
							
							// Write bond section
							key.Format(DBLE_KEY_STATUSRW_BOND, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
							GWPPfileData(fileName, sectionBond + "Left", key, read, data, count, DBLE_BOND_NOTDONE, true);
						
						} else if (bdMode == DBLE_SUBINFO_DETECT_MODE) {	
							
							for (int m = 0; m < count; m++) {
								index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
								data[m] = vIC[index]->m_DetectL;
							}
							
							// Write detect section
							key.Format(DBLE_KEY_STATUSRW_DETECT, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
							GWPPfileData(fileName, sectionDetect + "Left", key, read, data, count, DBLE_DETECT_UNKNOWN, true);

						}
					} else if (lrMode == DBLE_SUBINFO_TYPE_R) {
						if (bdMode == DBLE_SUBINFO_BOND_MODE) {	
							
							for (int m = 0; m < count; m++) {
								index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
								data[m] = vIC[index]->m_BondingR;
							}
							
							// Write bond section
							key.Format(DBLE_KEY_STATUSRW_BOND, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
							GWPPfileData(fileName, sectionBond + "Right", key, read, data, count, DBLE_BOND_NOTDONE, true);

						} else if (bdMode == DBLE_SUBINFO_DETECT_MODE) {	
							
							for (int m = 0; m < count; m++) {
								index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
								data[m] = vIC[index]->m_DetectR;
							}
							
							// Write detect section
							key.Format(DBLE_KEY_STATUSRW_DETECT, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
							GWPPfileData(fileName, sectionDetect + "Right", key, read, data, count, DBLE_DETECT_UNKNOWN, true);

						}
					}
				}	
			}
		}
		
	}
	return ret;
}


/**
* Save color in Subinfo mode
*/
void CBLE_Model::SaveColor()
{
	CString fileName = m_strSubInfoIniFilePath;
	// Configuration section
	CString section = DBLE_SECTION_INFO_CONFIG;
	int color[3];
	// Unknow color
	ConvertRGBColor(m_StatusColor.m_UnknownClr, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRUNKNOW, false, color, 3, 0);
	// Bad color
	ConvertRGBColor(m_StatusColor.m_BadClr, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRBAD, false, color, 3, 0);
	// Good color
	ConvertRGBColor(m_StatusColor.m_GoodClr, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRGOOD, false, color, 3, 0);
	// Not done color
	ConvertRGBColor(m_StatusColor.m_NotDoneClr, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRNOTDONE, false, color, 3, 0);
	// Fail color
	ConvertRGBColor(m_StatusColor.m_FailClr, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRFAIL, false, color, 3, 0);
	// Done color
	ConvertRGBColor(m_StatusColor.m_DoneClr, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRDONE, false, color, 3, 0);
	// Stack color
	ConvertRGBColor(m_StatusColor.m_StackClr, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRSTACK, false, color, 3, 0);
	// Don't need color
	ConvertRGBColor(m_StatusColor.m_NoNeedClr, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_INFO_CLRDONTNEED, false, color, 3, 0);
}

// #DDT140116: Save setting color to Editmode configuration file.
/**
* Save setting color
*/
void CBLE_Model::SaveSettingColor()
{
	CString fileName = m_strLocateEditIniFilePath;
	// Configuration section
	CString section = DBLE_SECTION_EDIT_COLOR;
	int color[3];
	// Cursor color
	ConvertRGBColor(m_StatusColor.m_Cursor, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_CURSOR, false, color, 3, 0);
	// Focus color
	ConvertRGBColor(m_StatusColor.m_Focus, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_FOCUS, false, color, 3, 0);
	// Valid color
	ConvertRGBColor(m_StatusColor.m_ValidDisp, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_VALID, false, color, 3, 0);
	// Overlap color
	ConvertRGBColor(m_StatusColor.m_OverlapDisp, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_OVERLAP, false, color, 3, 0);
	// Regno border color
	ConvertRGBColor(m_StatusColor.m_Regno, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_REGNO, false, color, 3, 0);
	// Centerline color
	ConvertRGBColor(m_StatusColor.m_CenterLine, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_CENTERLINE, false, color, 3, 0);
	// Index display color
	ConvertRGBColor(m_StatusColor.m_IndexDisp, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_INDEX, false, color, 3, 0);
	// Shape border color
	ConvertRGBColor(m_StatusColor.m_Shape, color[0], color[1], color[2]);
	GWPPfileData(fileName, section, DBLE_KEY_EDIT_COLOR_SHAPE, false, color, 3, 0);
}

/**
* Convert color to RGB index
*/
void CBLE_Model::ConvertRGBColor(COLORREF color, int &r, int &g, int &b)
{
	r = GetRValue(color);
	g = GetGValue(color);
	b = GetBValue(color);
	return;
}

/**
* Read/Write display mode in Subinfo mode
*/
void CBLE_Model::DisplayModeRW(bool read, int subMode, int &displayMode)
{
	if (subMode == DBLE_SUBINFO_TYPE_L) {
		GWPPfileData(m_strSubInfoIniFilePath, DBLE_SECTION_INFO_CONFIG, DBLE_KEY_INFO_DISLEFT, read, displayMode, 0);
	} else {
		GWPPfileData(m_strSubInfoIniFilePath, DBLE_SECTION_INFO_CONFIG, DBLE_KEY_INFO_DISRIGHT, read, displayMode, 0);
	}
	return;
}

/**
* Init shape vector
*/
void CBLE_Model::InitShapeName()
{
	CString shapeName;
	char buff[DBLE_MODEL_BUFFER_MINLENGTH];
	int x = 0, y = 0;
	TBLE_Subs_Shape shape;
	m_vShape.clear();
	for (int i = 0; i < m_Init.m_numberOfShape; i++) {
		shapeName = m_Init.m_ShapeName[i];
		if (sscanf(shapeName, "%s", buff) != 1) {
			// Error
			// Write log file: Error
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ShapeError[m_Init.m_Language], "", "");
			break;
		} else {
			CString tmp = buff;
			if (tmp.CompareNoCase("square") == 0) {
				if (sscanf(shapeName, "%s %dx%d", buff, &x, &y) != 3) {
					// Error
					// Write log file: Error
					theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ShapeSquareError[m_Init.m_Language], "", "");
					break;
				} else {
					shape.shape = DBLE_SHAPE_SQUARE;
					shape.sizeX = x;
					shape.sizeY = y;
					m_vShape.push_back(shape);
				}
			} else if (tmp.CompareNoCase("round") == 0){
				if (sscanf(shapeName, "%s %d", buff, &x) != 2) {
					// Error
					// Write log file: Error
					theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ShapeRoundError[m_Init.m_Language], "", "");
					break;
				} else {
					shape.shape = DBLE_SHAPE_ROUND;
					shape.sizeX = x;
					shape.sizeY = x;
					m_vShape.push_back(shape);
				}
			} else {
				// Error
				// Write log file: Error
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ShapeError[m_Init.m_Language], "", "");
				break;
			}
		}
	
	}
	if (m_vShape.empty()) {
		
		// Init default shape value
		shape.shape = DBLE_SHAPE_SQUARE;
		shape.sizeX = DBLE_MODEL_SUBSTRATE_SIZE_DEFAULT;
		shape.sizeY = DBLE_MODEL_SUBSTRATE_SIZE_DEFAULT;
		m_vShape.push_back(shape);
		
		// Update shape name
		m_Init.m_ShapeName[0] = DBLE_MODEL_SUBSTRATE_NAME_DEFAULT;
	}
	
	// Update number of shape
	m_Init.m_numberOfShape = m_vShape.size();
}

/**
*Read/Write locate valid data
*/
bool CBLE_Model::LocateValidDataRW(bool read, LPCTSTR lpFileName, char* buff)
{
	int size = 2 * GetSubstrate()->m_vIC.size() / 3; // for progress bar only

	// Locate offset T section
	char *validSec = DBLE_SECTION_EDIT_ICVALID;
	long validSecIdx = 0;

	if (buff != NULL) {
		validSecIdx = GetSectionIndex(validSec, buff);
	}

	bool ret = true;
	// Number of RegNo
	int numberOfRegNo = m_vRegIC.size(); 
	// RegNo value
	int regNo;
	// Max value axis X, Y
	int maxX, maxY;
	// Key to read/write
	CString key;
	// Array of XY offset data
	int data[DBLE_MODEL_ELEMENT_LINE];
	// Vector of IC
	vector<CBLE_IC*> vIC = m_Substrate.m_vIC;	

	int gap = 0, line = 0, count = 0, index = 0;
	for (int i = 0; i < numberOfRegNo; i++) {
		
		// Number of IC (axis X)
		maxX = m_vRegIC[i].m_NumberX;
		
		// Number of IC (axis Y)
		maxY = m_vRegIC[i].m_NumberY;
		
		// RegNo
		regNo = m_vRegIC[i].m_RegNo;
		if(i != 0) {
			gap += m_vRegIC[i-1].m_NumberX * m_vRegIC[i-1].m_NumberY;
		}
		
		// Number of lines
		line = ((maxX % DBLE_MODEL_ELEMENT_LINE) == 0) ? (maxX / DBLE_MODEL_ELEMENT_LINE) : (maxX / DBLE_MODEL_ELEMENT_LINE) + 1;
		
		// Loop row
		if (read) {
			if (::WaitForSingleObject(m_StopThread, 0) == WAIT_OBJECT_0) {
				return false;
			}
			for (int j = 0; j < maxY; j++) {
				count = 0;
				for (int k = 0; k < line; k++) {
					count = (maxX >= DBLE_MODEL_ELEMENT_LINE * (k + 1)) ? DBLE_MODEL_ELEMENT_LINE : (maxX - DBLE_MODEL_ELEMENT_LINE * k);
				
					// Read locate valid section
					key.Format(DBLE_KEY_VALID, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
					GWPPfileData(lpFileName, validSec, key, read, data, count, DBLE_MODEL_IC_VALID_DEFAULT, true, buff, validSecIdx);
					
					// Update IC
					for (int m = 0; m < count; m++) {
						index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
						vIC[index]->m_Deleted = !data[m];
					}
					
					m_ProcessIndex = size + index / 3;
				}	
			}
		} else {
			for (int j = 0; j < maxY; j++) {
				count = 0;
				for (int k = 0; k < line; k++) {
					
					count = (maxX >= DBLE_MODEL_ELEMENT_LINE * (k + 1)) ? DBLE_MODEL_ELEMENT_LINE : (maxX - DBLE_MODEL_ELEMENT_LINE * k);
					
					for (int m = 0; m < count; m++) {
						index = gap + j * maxX + DBLE_MODEL_ELEMENT_LINE * k + m;
						data[m] = !vIC[index]->m_Deleted;
					}
					
					// Write locate valid section
					key.Format(DBLE_KEY_VALID, regNo, j+1, DBLE_MODEL_ELEMENT_LINE * k + 1, DBLE_MODEL_ELEMENT_LINE * (k + 1));
					GWPPfileData(lpFileName, validSec, key, read, data, count, DBLE_MODEL_IC_VALID_DEFAULT, true, buff, validSecIdx);

					m_ProcessIndex = size + index / 3;
				}	
			}
		}
	}
	return ret;
}

/**
* Get real number of element in array
*/
void CBLE_Model::GetNumberOfElement(int arr[], int &numb, int max)
{
	int total = 0;
	for (int i = 0; i < numb; i++) {
		bool check = true;
		if (arr[i] <= 0 || arr[i] > max) {
			break;
		}
		total++;
	}
	if (total == 0) {
		total++;
		arr[0] = 1;
	}
	numb = total;
	return;
}

/**
*Read/Write array of double elements
*/
bool CBLE_Model::GWPPfileData(
			LPCTSTR lpFileName,		// file name
			LPCTSTR lpszSection,	// section
			LPCTSTR lpszKey,		// key
			bool read,				// true is read, false is write
			double data[],			//array of data 
			int numb,				//number of elements read/write
			double dataD,			//default value
			int kmode,				//mode to write data
									//(1: 4 digits after point, 2: 5 digits after point)
			bool hasToAdd,			// false: write number of real elements
			char* srcBuff,			//
			long startSecIdx		//
			) 
{
	bool r = true;
	//Read data
	if (read) {
		char inBuff[DBLE_MODEL_BUFFER_MINLENGTH];
		int i = 0, n = 0;
		//Get number of elements
		int	ret = 0;
		if (startSecIdx && (srcBuff != NULL)) {
			ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		} else {
			ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, lpFileName);
		}
		
		//Get successful
		if (ret) {
			if (sscanf(inBuff, "%d", &n) == 1 && (n > 0)) {
				int length = 15 * (n * 2) + 1;
				char *buff = new char[length];
				
				if (startSecIdx && (srcBuff != NULL)) {
					ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, buff, length, startSecIdx, srcBuff);
				} else {
					ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, buff, length, lpFileName);
				}

				if (ret) {
					char *bp = buff;
					//Skip first number
					bp = strchr(bp, ',');
					if (bp) {
						bp++;
						for (i = 0; (i < n) && (i< numb); i++) {
							if (sscanf(bp, "%lf", &data[i]) != 1) {
								break;
							} 
							bp = strchr(bp, ',');
							if (bp) {
								bp++;
							} else {
								i++;
								break;
							}
						}
					}
				}
				delete[] buff;
			}
		}
		r = (i == numb);
		for (; i < numb; i++) {
			data[i] = dataD;
		}
	} else {	//Write data
		CString strA, strB;
		int i;
		strA.Format("%d", hasToAdd ? DBLE_MODEL_ELEMENT_LINE : numb);
		for (i = 0; i < numb; i++) {
			switch(kmode) {
			case 1:
				strB.Format(",%.4lf", data[i]);
				break;
			case 2: 
				strB.Format(",%.5lf", data[i]);
				break;
			default:
				strB.Format(",%.10lf", data[i]);
			}
			strA += strB;
		}
		if (hasToAdd) {
			for (i; i< DBLE_MODEL_ELEMENT_LINE; i++) {
				strA += ",";
			}
		}
		//Write data to specific section key
		r = WritePrivateProfileString(lpszSection, lpszKey, strA, lpFileName) ? true : false;
	}
	return r;
}

/**
*Read/Write array of R2Pos elements
*/
bool CBLE_Model::GWPPfileData(
			LPCTSTR lpFileName,		// file name
			LPCTSTR lpszSection,	// section
			LPCTSTR lpszKey,		// key
			bool read,				// true is read, false is write
			R2Pos data[],			// array of data 
			int numb,				// number of elements read/write
			R2Pos dataD,			// default value
			int kmode,				// mode to write data
									// (1: 4 digits after point, 2: 5 digits after point)
			bool hasToAdd,			// false: write number of real elements
			char* srcBuff,			//
			long startSecIdx		//
			) 
{
	bool r = true;
	//Read data
	if (read) {
		char inBuff[DBLE_MODEL_BUFFER_MINLENGTH];
		int i = 0, n = 0;
		//Get number of elements
		int	ret = 0;
		if (startSecIdx && (srcBuff != NULL)) {
			ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		} else {
			ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, lpFileName);
		}
		
		//Get successful
		if (ret) {
			if (sscanf(inBuff, "%d", &n) == 1 && (n > 0)) {
				int length = 15 * (n * 2) + 1;
				char *buff = new char[length];
				if (startSecIdx && (srcBuff != NULL)) {
					ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, buff, length, startSecIdx, srcBuff);
				} else {
					ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, buff, length, lpFileName);
				}
				
				if (ret) {
					char *bp = buff;
					//Skip first number
					bp = strchr(bp, ',');
					if (bp) {
						bp++;
						for (i = 0; (i < n) && (i< numb); i++) {
							double x, y;
							if (sscanf(bp, "%lf,%lf", &x, &y) != 2) {
								break;
							} 
							data[i].X() = x;
							data[i].Y() = y;
							bp = strchr(bp, ',');
							bp++;
							bp = strchr(bp, ',');
							if (bp) {
								bp++;
							} else {
								i++;
								break;
							}
						}
					}
				}
				delete[] buff;
			}
		}
		r = (i == numb);
		for (; i < numb; i++) {
			data[i] = dataD;
		}
	} else {	//Write data
		CString strA, strB;
		int i;
		strA.Format("%d", hasToAdd ? DBLE_MODEL_ELEMENT_LINE : numb);
		for (i = 0; i < numb; i++) {
			switch (kmode) {
			case 1:
				strB.Format(",%.4lf,%.4lf", data[i].X(), data[i].Y());
				break;
			case 2: 
				strB.Format(",%.5lf,%.5lf", data[i].X(), data[i].Y());
				break;
			default:
				strB.Format(",%.10lf,%.10lf", data[i].X(), data[i].Y());
			}
			strA += strB;
		}
		if (hasToAdd) {
			for (; i< DBLE_MODEL_ELEMENT_LINE; i++) {
				strA += ",,";
			}
		}
		//Write data to specific section key
		r = WritePrivateProfileString(lpszSection, lpszKey, strA, lpFileName) ? true : false;
	}
	return r;
}

/**
*Read/Write array of integer elements
*/
bool CBLE_Model::GWPPfileData(
			LPCTSTR lpFileName,		// file name
			LPCTSTR lpszSection,	// section
			LPCTSTR lpszKey,		// key
			bool read,				// true is read, false is write
			int data[],				// array of data 
			int numb,				// number of elements read/write
			int dataD,				// default value
			bool hasToAdd,			// false: write number of real elements
			char* srcBuff,			//
			long startSecIdx		//
			) 
{
	bool r = true;
	// Read data
	if (read) {
		char inBuff[DBLE_MODEL_BUFFER_MINLENGTH];
		int i = 0, n = 0;
		// Get number of elements
		int	ret;
		if (startSecIdx && (srcBuff != NULL)) {
			ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		} else {
			ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, lpFileName);
		}
		// Get successful
		if (ret) {
			if (sscanf(inBuff, "%d", &n) == 1 && (n > 0)) {
				int length = 15 * (n * 2) + 1;
				char *buff = new char[length];
					
				if (startSecIdx && (srcBuff != NULL)) {
					// Read from buffer
					ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, buff, length, startSecIdx, srcBuff);
				} else {
					// Read from file
					ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, buff, length, lpFileName);
				}
				
				if (ret) {
					char *bp = buff;
					// Skip first number
					bp = strchr(bp, ',');
					if (bp) {
						bp++;
						for (i = 0; (i < n) && (i< numb); i++) {
							if (sscanf(bp, "%d", &data[i]) != 1) {
								break;
							} else {
								bp = strchr(bp, ',');
								if(bp) {
									bp++;
								} else {
									i++;
									break;
								}
							}
						}
					}
				}
				delete[] buff;
			}
		}
		r = (i == numb);
		for (; i < numb; i++) {
			data[i] = dataD;
		}
	} else {	//Write data
		CString strA, strB;
		strA.Format("%d", hasToAdd ? DBLE_MODEL_ELEMENT_LINE : numb);
		for(int i = 0; i < numb; i++) {
			strB.Format(",%d", data[i]);
			strA += strB;
		}
		if (hasToAdd) {
			for(; i< DBLE_MODEL_ELEMENT_LINE; i++) {
				strA += ",";
			}
		}
		//Write data to specific section key
		r = WritePrivateProfileString(lpszSection, lpszKey, strA, lpFileName) ? true :false;
	}
	return r;
}

/**
*Read/Write integer data
*/
bool CBLE_Model::GWPPfileData(
			LPCTSTR lpFileName,		// file name
			LPCTSTR lpszSection,	// section
			LPCTSTR lpszKey,		// key
			bool read,				// true is read, false is write
			int &data,				// array of data 
			int dataD,				// default value
			char* srcBuff,			//
			long startSecIdx		//
			) 
{
	bool r = true;
	// Read data
	if (read) {
		int ret = 0;
		char inBuff[DBLE_MODEL_BUFFER_MINLENGTH];
		if (startSecIdx && (srcBuff != NULL)) {
			ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		} else {
			ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, lpFileName);
		}
		//ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		// Get successful
		if (ret) {
			if (sscanf(inBuff, "%d", &data) != 1) {
				data = dataD;
				r = false;
			}
		} else {
			data = dataD;
			r = false;
		}
	} else {	//Write data
		CString str;
		str.Format("%d", data);
		r = WritePrivateProfileString(lpszSection, lpszKey, str, lpFileName) ? true : false;
	}
	return r;
}

/**
*Read/Write double data
*/
bool CBLE_Model::GWPPfileData(
			LPCTSTR lpFileName,		// file name
			LPCTSTR lpszSection,	// section
			LPCTSTR lpszKey,		// key
			bool read,				// true is read, false is write
			double &data,			// array of data 
			double dataD,			// default value
			int kmode,				// mode to write data
									// (1: 4 digits after point, 2: 5 digits after point)
			char* srcBuff,			//
			long startSecIdx		//
			) 
{
	bool r = true;
	
	// Read data
	if (read) {
		int ret = 0;
		char inBuff[DBLE_MODEL_BUFFER_MINLENGTH];
		ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, lpFileName);
		//ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		// Get successful
		if (ret) {
			if (sscanf(inBuff, "%lf", &data) != 1) {
				data = dataD;
				r = false;
			}
		} else {
			data = dataD;
			r = false;
		}
	} else {	//Write data
		CString str;
		switch (kmode) {
		case 1 :
			str.Format("%.4lf", data);
			break;
		case 2:
			str.Format("%.5lf", data);
			break;
		default:
			str.Format("%.10lf", data);
		}
		r = WritePrivateProfileString(lpszSection, lpszKey, str, lpFileName) ? true : false;
	}
	return r;
}

/**
*Read/Write R2Pos data
*/
bool CBLE_Model::GWPPfileData(
			LPCTSTR lpFileName,		// file name
			LPCTSTR lpszSection,	// section
			LPCTSTR lpszKey,		// key
			bool read,				// true is read, false is write
			R2Pos &data,			// array of data 
			R2Pos dataD,			// default value
			int kmode,				// mode to write data
									// (1: 4 digits after point, 2: 5 digits after point)
			char* srcBuff,			//
			long startSecIdx		//
			) 
{
	bool r = true;
	
	// Read data
	if (read) {
		int ret = 0;
		char inBuff[DBLE_MODEL_BUFFER_MINLENGTH];
		if (startSecIdx && srcBuff != NULL) {
			ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		} else {
			ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, lpFileName);
		}
		// Get successful
		if (ret) {
			double x, y;
			if (sscanf(inBuff, "%lf,%lf", &x, &y) != 2) {
				data = dataD;
				r = false;
			} else {
				data.X() = x;
				data.Y() = y;
			}
		} else {
			data = dataD;
			r = false;
		}
	} else {	//Write data
		CString str;
		switch (kmode) {
		case 1 :
			str.Format("%.4lf,%.4lf", data.X(), data.Y());
			break;
		case 2:
			str.Format("%.5lf,%.5lf", data.X(), data.Y());
			break;
		default:
			str.Format("%.10lf,%.10lf", data.X(), data.Y());
		}
		r = WritePrivateProfileString(lpszSection, lpszKey, str, lpFileName) ? true : false;
	}
	return r;
}

/**
*Read/Write string data
*/
bool CBLE_Model::GWPPfileData(
			LPCTSTR lpFileName,		// file name
			LPCTSTR lpszSection,	// section
			LPCTSTR lpszKey,		// key
			bool read,				// true is read, false is write
			CString &data,			// string data
			CString dataD,			// default value
			char* srcBuff,			//
			long startSecIdx		//
			) 
{
	bool r = true;
	int ret = 0;
	// Read data
	if (read) {
		LPTSTR temp = data.GetBuffer(DBLE_MODEL_BUFFER_MAXLENGTH);
		ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, temp, DBLE_MODEL_BUFFER_MAXLENGTH, lpFileName);
		//ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		// Get successful
		if (ret) {
			temp[DBLE_MODEL_BUFFER_MAXLENGTH - 1] = 0;
			data.ReleaseBuffer();
		} else {
			temp[0] = 0;
			data = dataD;
			r = false;
		}
	} else {	//Write data
		r = WritePrivateProfileString(lpszSection, lpszKey, data, lpFileName) ? true : false;
	}
	return r;
}

/**
*Read/Write array of string elements
*/
bool CBLE_Model::GWPPfileData(
			LPCTSTR lpFileName,		// file name
			LPCTSTR lpszSection,	// section
			LPCTSTR lpszKey,		// key
			bool read,				// true is read, false is write
			CString data[],			// array of data 
			int numb,				// number of elements read/write
			CString dataD,			// default value
			char* srcBuff,			//
			long startSecIdx		//
			) 
{
	bool r = true;
	// Read data
	if (read) {
		char inBuff[DBLE_MODEL_BUFFER_MINLENGTH];
		int i = 0, n = 0;
		// Get number of elements
		int	ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, lpFileName);
		//int ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, inBuff, DBLE_MODEL_BUFFER_MINLENGTH, startSecIdx, srcBuff);
		// Get successful
		if (ret) {
			if (sscanf(inBuff, "%d", &n) == 1 && (n > 0)) {
				char *buff = new char[DBLE_MODEL_BUFFER_MAXLENGTH];
				ret = GetPrivateProfileString(lpszSection, lpszKey, NULL, buff, DBLE_MODEL_BUFFER_MAXLENGTH, lpFileName);
				//ret = GetPrivateProfileStringFromBuff(lpszKey, NULL, buff, DBLE_MODEL_BUFFER_MAXLENGTH, startSecIdx, srcBuff);
				if (ret) {
					char *token = strtok(buff, ",");
					// Skip first number
					while (token) {
						if (i != 0) {
							if (i > n || i > numb) {
								break;
							} else {
								data[i - 1] = token;
							}
						}
						token = strtok(NULL, ",");
						i++;
					}	
					i--;
				}
				delete[] buff;
			} else {
				// DO NOTHING
			}
		}

		// Calculate return value 
		r = (i == numb) ? true : false;

		// Assign default value for remain values
		for (; i < numb; i++) {
			data[i] = dataD;
		}
		
	} else {	//Write data
		CString strA, strB;
		int i;
		strA.Format("%d", numb);
		for(i = 0; i < numb; i++) {
			strB.Format(",%s", data[i]);
			strA += strB;
		}
		//Write data to specific section key
		r = WritePrivateProfileString(lpszSection, lpszKey, strA, lpFileName) ? true : false;
	}

	return r;
}

/**
*Delete data
*/
bool CBLE_Model::GWPPfileDataDelete(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey)
{
	return WritePrivateProfileString(lpszSection, lpszKey, NULL, lpFileName) ? true : false;
}


/**
* After reading all data into buffer, we can use this function to xxtract data 
* from buffer instead of reading from file many times
*/
int CBLE_Model::GetPrivateProfileStringFromBuff(const char *entry,				// the name of the entry to find the value
												const char *def,				// default string in the event of a failed read
												char *buffer,					// a pointer to the buffer to copy output into
												int buffer_len,					// the max number of characters to copy
												long startIdx,					// start idx in buff to search entry
												char* sourceBuff)				// source buff to read from
{
	if ((entry == NULL) || (sourceBuff == NULL)) {
		return 0;
	}
	
	char buff[MAX_LINE_LENGTH];
	long sourceBuffIdx = startIdx;
	int buffIdx = 0;

	int entryLength = strlen(entry);
	char* fullEntry = new char[entryLength + 1 + 1];		// "entry="
	sprintf(fullEntry,"%s=",entry);							// Format the section name

	int maxLength = strlen(sourceBuff);

	// Look for entry
	while (sourceBuffIdx < maxLength) {
		buffIdx = 0;
		// Reset buffer
		memset(buff, 0, MAX_LINE_LENGTH);
		do {
			// End of line
			if (sourceBuff[sourceBuffIdx] == '\n') {
				sourceBuffIdx++;
				break;
			}
			buff[buffIdx] = sourceBuff[sourceBuffIdx];
			buffIdx++;
			sourceBuffIdx++;
		} while ((buffIdx < MAX_LINE_LENGTH - 1) && (sourceBuffIdx < maxLength));
		// Finish reading a line

		// If this is line of needed entry
		if (IsMatchedString(fullEntry, buff)) {
			break;
		}
	}

	// If find
	if (sourceBuffIdx < maxLength) {
		char *ep;
		ep = strchr(buff,'=');  // find the first character '='
		if (ep == NULL) {
			strncpy(buffer, def, buffer_len);
			return(strlen(buffer));
		}
		ep++;

		// Remove leading spaces
		while (*ep && (isspace(*ep) || *ep == 10)) {
			ep++;
		}
		if (ep == NULL) {
			strncpy(buffer, def, buffer_len);
			return(strlen(buffer));
		}
	
		// Remove trailing spaces
		char *ptr = ep;
		while (*ptr) {				// go to the end, point to a NULL
			ptr++;
		}
		ptr--;
		while (ptr > ep) {			// backup and put in nulls if there is a space
			if (isspace(*ptr) || *ep == 10) {
				*ptr = 0;
				ptr--;
			} else {
				break;
			}
		}

		// Copy up to buffer_len chars to buffer
		strncpy(buffer,ep,buffer_len - 1);
		buffer[buffer_len - 1] = '\0';

	} else {
		buffer[0] = '\0';
	}

	delete[] fullEntry;

	return (strlen(buffer));
}

/**
* Get index of section in buffer
*/
long CBLE_Model::GetSectionIndex(const char *section,
								const char *sourceBuff)
{
	char buff[MAX_LINE_LENGTH];
	long sourceBuffIdx = 0;
	int buffIdx = 0;

	int secLength = strlen(section);
	char* sec = new char[secLength+2+1];			// "[section]"
	sprintf(sec,"[%s]",section);					// Format the section name

	int maxLength = strlen(sourceBuff);

	// Look for index of section in sourceBuff
	while (sourceBuffIdx < maxLength) {
		buffIdx = 0;
		do {
			// End of line
			if (sourceBuff[sourceBuffIdx] == '\n') {
				sourceBuffIdx++;
				break;
			}
			buff[buffIdx] = sourceBuff[sourceBuffIdx];
			buffIdx++;
			sourceBuffIdx++;
		} while ((buffIdx < MAX_LINE_LENGTH - 1) && (sourceBuffIdx < maxLength));
		// Finish reading a line

		// If this is line of needed section
		if (IsMatchedString(sec, buff)) {
			break;
		}
	}
	if (sourceBuffIdx >= maxLength) {
		sourceBuffIdx = maxLength;
	}
	delete[] sec;
	
	return sourceBuffIdx;
}

/**
* Check if desStr is subString that start of srcStr
* This function is used to find an entry in buffer
*/
bool CBLE_Model::IsMatchedString(const char *desStr, const char *srcStr)
{
	bool r;		// return value
	int desLength = strlen(desStr);
	int srcLength = strlen(srcStr);

	if ((desStr == NULL) || (srcStr == NULL) || (desLength > srcLength)) {
		r =  false;
	} else {
		for (int i = 0; i < desLength; i++) {
			if (desStr[i] != srcStr[i]) {
				break;
			}
		}
		if (i < desLength) {
			r = false;
		} else {
			r = true;
		}
	}

	return r;
}

// Display warning message when file not found
bool CBLE_Model::FileNotFound(CString filePath)
{
	if (GetFileAttributes(filePath) == 0xFFFFFFFF) {
		//AfxMessageBox(filePath + DBLE_MODEL_NOTFOUND_MESS_ENG, MB_OK);
		theApp.CBTMessageBox(NULL, filePath + NotFound[m_Init.m_Language], MB_OK, m_Init.m_Language);
		// Write log file: missing value
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, filePath + NotFound[m_Init.m_Language], "", "");
		return false;
	}
	return true;
}

// Serialize function
void CBLE_Model::Serialize(CArchive &archive)
{
	CObject::Serialize(archive);

	int size = m_vRegIC.size();
	DWORD changed;
	if (archive.IsStoring()) {
		archive << size;
		for (int idx = 0; idx < size; idx ++) {
			if (m_vRegIC[idx].m_Changed) {
				changed = 1;
			} else {
				changed = 0;
			}
			//changed = m_vRegIC[idx].m_Changed;
			archive << m_vRegIC[idx].m_Angle << changed << m_vRegIC[idx].m_ColletteL << m_vRegIC[idx].m_ColletteR << m_vRegIC[idx].m_EjectL
					<< m_vRegIC[idx].m_EjectR << m_vRegIC[idx].m_NumberX << m_vRegIC[idx].m_NumberY << m_vRegIC[idx].m_PitchX << m_vRegIC[idx].m_PitchY
					<< m_vRegIC[idx].m_RegNo << m_vRegIC[idx].m_SizeX << m_vRegIC[idx].m_SizeY << m_vRegIC[idx].m_StartPosX << m_vRegIC[idx].m_StartPosY
					<< m_vRegIC[idx].m_ToolL << m_vRegIC[idx].m_ToolR << m_vRegIC[idx].m_Type;
		}
		m_Substrate.Serialize(archive, &m_vRegIC);
		// Write Mapping data
		archive << m_MapData.m_BCRead << m_MapData.m_BondedBin << m_MapData.m_DiePoint
				<< m_MapData.m_FID << m_MapData.m_GoodBin << m_MapData.m_MessLength
				<< m_MapData.m_NullBin << m_MapData.m_OriFlat << m_MapData.m_PassBin
				<< m_MapData.m_ProcessDie << m_MapData.m_RefDie << m_MapData.m_RefDieX
				<< m_MapData.m_RefDieY << m_MapData.m_RefND;
	} else {
		m_vRegIC.clear();
		GetSubstrate()->ResetData();
		archive >> size;
		for (int idx = 0; idx < size; idx ++) {
			TBLE_RegIC regIC;
			archive >> regIC.m_Angle >> changed >> regIC.m_ColletteL >> regIC.m_ColletteR >> regIC.m_EjectL
				>> regIC.m_EjectR >> regIC.m_NumberX >> regIC.m_NumberY >> regIC.m_PitchX >> regIC.m_PitchY
				>> regIC.m_RegNo >> regIC.m_SizeX >> regIC.m_SizeY >> regIC.m_StartPosX >> regIC.m_StartPosY
				>> regIC.m_ToolL >> regIC.m_ToolR >> regIC.m_Type;
			if (changed == 1) {
				regIC.m_Changed = true;
			} else {
				regIC.m_Changed = false;
			}
			m_vRegIC.push_back(regIC);
		}
		m_Substrate.Serialize(archive, &m_vRegIC);
		
		// Read Mapping data
		archive >> m_MapData.m_BCRead >> m_MapData.m_BondedBin >> m_MapData.m_DiePoint
			>> m_MapData.m_FID >> m_MapData.m_GoodBin >> m_MapData.m_MessLength
			>> m_MapData.m_NullBin >> m_MapData.m_OriFlat >> m_MapData.m_PassBin
			>> m_MapData.m_ProcessDie >> m_MapData.m_RefDie >> m_MapData.m_RefDieX
			>> m_MapData.m_RefDieY >> m_MapData.m_RefND;
	}
}

// For undo function

/**
* Create Memento: Store old data state
*/
CBLE_Memento CBLE_Model::CreateMemento(int kind, bool all, int regNo)
{
	vector<CBLE_IC*> vIC = all ? GetSubstrate()->m_vIC : GetSubstrate()->m_vSelIC; 
	CBLE_DataStore dataStore(vIC, kind, DATA_TYPE, all, regNo);
	return dataStore;
}

/**
* Restore last state
*/
void CBLE_Model::RestoreState()
{
	CBLE_CareTaker* pCareTaker = CBLE_CareTaker::CreateInstance();
	if (!pCareTaker->Restoreable()) {
		return;
	}
	CBLE_Memento memento = pCareTaker->GetMemento();
	void *tmp = memento.GetState();
	vector<CBLE_IC> *vIC = static_cast<vector<CBLE_IC> *> (tmp);

	// Deselect all IC 
	GetSubstrate()->DeselectAll();
	
	// Vector all IC
	vector<CBLE_IC*> vpIC = GetSubstrate()->m_vIC;
	
	// Vector select
	vector<CBLE_IC*> vSelIC;

	int length = vIC->size();
	for (int idx = 0; idx < length; idx++) {
		vpIC[CalIndex(vIC->at(idx))]->CopyData(vIC->at(idx));
		vSelIC.push_back(vpIC[CalIndex(vIC->at(idx))]);
	}
	// Assign all IC restore to vector select in substrate
	GetSubstrate()->m_vSelIC = vSelIC;

	delete vIC;
}

/**
* Calculate index of IC
*/
int CBLE_Model::CalIndex(CBLE_IC ic)
{
	int regNo = ic.m_pRegIC->m_RegNo;
	int idx = ic.m_indexX + 1;
	int idy = ic.m_indexY + 1;
	int index = 0;
	for (int i = 1; i <= regNo; i++) {
		if (i == regNo) {
			index += idx + m_vRegIC[i - 1].m_NumberX * (idy - 1);
		} else {
			index += m_vRegIC[i - 1].m_NumberX * m_vRegIC[i - 1].m_NumberY;
		}
	}
	return index - 1;
}

// #DDT(20140624): Add read barcode
CString CBLE_Model::GetBarcode(int lr)
{
	CString barcode;
	if (lr == DBLE_SUBINFO_TYPE_L) {
		GWPPfileData(DBLE_LOADMAP_BARCODE_FILEPATH, DBLE_LOADMAP_BARCODE_SECTION_L,"�o�[�R�[�h", 1/*Read*/, barcode, CString(""));
	} else if (lr == DBLE_SUBINFO_TYPE_R) {
		GWPPfileData(DBLE_LOADMAP_BARCODE_FILEPATH, DBLE_LOADMAP_BARCODE_SECTION_R,"�o�[�R�[�h", 1/*Read*/, barcode, CString(""));
	}
	return barcode;
}

BOOL CBLE_Model::LoadMapData(CString barcode, int lr, vector<CBLE_IC> &vIC)
{
	BOOL r = FALSE;

	CString BINLT;
	CString BCEQU;
	CString NULBC;
	CString BCBND;

	int ROWCT;
	int COLCT;

	CString buffer;
	CString identity;
	bool Read = true;
	CString key;
	if (lr == DBLE_SUBINFO_TYPE_L) {
		identity = "_L_";
	} else {
		identity = "_R_";
	}
	if(GetSubstrate()->m_vBinList.size() !=0){//#NhamNV-170825
		GetSubstrate()->m_vBinList.clear();
	}
	for (int regNo = 0; regNo < m_vRegIC.size(); regNo++) {
		CString fileName = DBLE_LOADMAP_DATAPATH + barcode;//+ identity + "Reg" + CString(regNo + 49);

		if (!_access(fileName, 04)){
			// Get Row/Col
			GWPPfileData(fileName, DBLE_LOADMAP_SECTION, "ROWCT", Read, ROWCT, 0);
			GWPPfileData(fileName, DBLE_LOADMAP_SECTION, "COLCT", Read, COLCT, 0);
			if (ROWCT != m_vRegIC[regNo].m_NumberY || COLCT != m_vRegIC[regNo].m_NumberX) {
				r = FALSE;
				break;	
			}
			GWPPfileData(fileName, DBLE_LOADMAP_SECTION, "BCEQU", Read, BCEQU, CString(""));
			GWPPfileData(fileName, DBLE_LOADMAP_SECTION, "NULBC", Read, NULBC, CString(""));
			GWPPfileData(fileName, DBLE_LOADMAP_SECTION, "BCBND", Read, BCBND, CString(""));
			m_BCEQU = BCEQU;
			CString temp;
			for (int rdx = 0; rdx < ROWCT+1; rdx++) {
				key.Format("BINLT(%3d)", rdx);
				GWPPfileData(fileName, DBLE_LOADMAP_SECTION, key, Read, temp, CString(""));
				BINLT += temp;
			}
			CBLE_IC IC;
			if (lr == DBLE_SUBINFO_TYPE_L) {
				for (int idx = 0; idx < BINLT.GetLength(); idx++) {
					if (idx >= GetSubstrate()->m_vIC.size()) { 
						break;
					}
					//#NhamNV-170825 (S)
					bool bSame = false;
					TBLE_IC_Bin	binList;
					GetSubstrate()->m_vIC[idx]->m_textIC = BINLT.GetAt(idx);
					GetSubstrate()->m_vIC[idx]->m_ColorIC = RGB(255,255,255);
					IC.CopyData(*(GetSubstrate()->m_vIC.at(idx)));
					binList.m_bin =  GetSubstrate()->m_vIC[idx]->m_textIC;
					binList.m_ColorIC = GetSubstrate()->m_vIC[idx]->m_ColorIC;
					if(GetSubstrate()->m_vBinList.size() == 0){
						GetSubstrate()->m_vBinList.push_back(binList);
					}else{
						for(int cnt =0; cnt <GetSubstrate()->m_vBinList.size(); cnt++ ){
							if(binList.m_bin == GetSubstrate()->m_vBinList.at(cnt).m_bin){
								bSame = true;
								break;
							}
						}
						if(!bSame){
							GetSubstrate()->m_vBinList.push_back(binList);
						}
					}
					//#NhamNV-170825 (E)
					//#NhamNV-170828 Check BCBND field is empty or not (S)
					if(BCBND.IsEmpty()){
						IC.m_BondingL = DBLE_BOND_NOTDONE;
						vIC.push_back(IC);
					}else{
						if (BINLT.GetAt(idx) == BCBND[0]) {
							IC.m_BondingL = DBLE_BOND_DONE;
							vIC.push_back(IC);
						} else if (BINLT.GetAt(idx) == BCEQU[0]) {
							IC.m_BondingL = DBLE_BOND_NOTDONE;
							vIC.push_back(IC);
						} else {
							// TODO
						}//#NhamNV-170828 Check BCBND field is empty or not (E)
					}
				}
			} else if (lr == DBLE_SUBINFO_TYPE_R) {
				for (int idx = 0; idx < BINLT.GetLength(); idx++) {
					if (idx >= GetSubstrate()->m_vIC.size()) { 
						break;
					}
					IC.CopyData(*(GetSubstrate()->m_vIC.at(idx)));
					if (BINLT.GetAt(idx) == BCBND[0]) {
						IC.m_BondingR = DBLE_BOND_DONE;
						vIC.push_back(IC);
					} else if (BINLT.GetAt(idx) == BCEQU[0]) {
						IC.m_BondingR= DBLE_BOND_NOTDONE;
						vIC.push_back(IC);
					} else {
						// TODO
					}
				}
			}
			r = TRUE;
		}	
	}
	return r;
}
int	 CBLE_Model::GetFrmDir(int side)
{
	return m_frameDir[side];
}

void CBLE_Model::SetFrmDir(int side, int dir)
{
	m_frameDir[side] = dir;
}
///////////////////////////////////////////////////////////
//  CBLE_OffsetDlg.cpp
//  Implementation of the Class CBLE_OffsetDlg
//  Created on:      16-Thg7-2013 1:30:47 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////
#include "swatch.h"
#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_OffsetDlg.h"
#include "CBLE_AllOffsetDlg.h"
#include "CBLE_Util.h"
#include "CBLE_ProgressBar.h"
#include "CBLE_CareTaker.h"

// Defined for column width of grid control
static long m_arrOffsetColWidth[] = {
//	35, 25, 25, 30, 70, 70, 70, 70, 70
	5, 25, 25, 0, 70, 70, 70, 70, 70
};

// Define warning message
//#define WARNING_MESSAGE_OUTOFRANGE			_T("Your input is out of limit range! \n Do you want to re-input?")
/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
CString OutOfRangeOff[] =	{
								_T("���͂������͈͊O�ł��B�ē��͂��܂����H"),
								_T("Your input is out of limit range! \n Do you want to re-input?"),
							};
// Defined for column number type of grid control
// true = int, false = double

static DBLE_CellType m_arrOffsetColType[] = {
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE
};

enum {
	COLUMN_REGNO = 0,
	COLUMN_INDEX_X,
	COLUMN_INDEX_Y,
	COLUMN_ICTYPE,
	COLUMN_TARGET_X,
	COLUMN_TARGET_Y,
	COLUMN_OFFSET_X,
	COLUMN_OFFSET_Y,
	COLUMN_OFFSET_T,
};

/////////////////////////////////////////////////////////////////////////////
// CBLE_OffsetDlg dialog


CBLE_OffsetDlg::CBLE_OffsetDlg(DBLE_OFFSET_DLG_MODE mode, CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_OffsetDlg::IDD, pParent)
{
	m_pDoc = NULL;
	m_Mode = mode;
	m_pGridCtrl = NULL;
}

CBLE_OffsetDlg::~CBLE_OffsetDlg()
{

}


void CBLE_OffsetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	// Grid control
	//DDX_Control(pDX, IDC_OFFSET_GRID, m_pGridCtrl);
}


BEGIN_MESSAGE_MAP(CBLE_OffsetDlg, CDialog)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_OFFSET_ALL, OnAllOffset)
	ON_BN_CLICKED(IDC_OFFSET_FORCE_OK, OnForceOk)
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateGrid)

	ON_COMMAND(ID_EDIT_UNDO, OnRestoreState)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_OffsetDlg message handlers

void CBLE_OffsetDlg::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}


BOOL CBLE_OffsetDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect rect;

	// Create grid control
	GetDlgItem(IDC_OFFSET_GRID)->GetWindowRect(rect);
	ScreenToClient(&rect);
	int size = m_pDoc->GetData()->GetSubstrate()->m_vSelIC.size()/* + 2*/;
// #MH131118 - Skip deleted ICs in OFFSET mode
	if (m_Mode == DBLE_OFFSET_DLG_MODE_OFFSET) {
		int realSize = size; // number of NOT deleted ICs
		for (int i = 0; i < size; i++) {
			if (m_pDoc->GetData()->GetSubstrate()->m_vSelIC[i]->m_Deleted) {
				realSize--;
			}
		}
		size = realSize;
	}
	size += 2;				// 2 row for titles of collumns
	m_pGridCtrl = new CBLE_GridCtrl(size, 9);
	//m_pGridCtrl->SetDocument(m_pDoc);
	m_pGridCtrl->Create(rect, this, m_pDoc);

	// Create key window
	GetDlgItem(IDC_OFFSET_NUM_KEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(m_pGridCtrl->GetEditWnd(), IDD_NKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);

	// Init grid
	InitGridCtrl();
	AddGridData();

	// Show/Hide "All Offset" button
	CRect rect1;
	GetDlgItem(IDC_OFFSET_ALL)->GetWindowRect(rect1);
	ScreenToClient(&rect1);
	GetDlgItem(IDC_OFFSET_ALL)->ShowWindow((m_Mode == DBLE_OFFSET_DLG_MODE_EXPAND) ? SW_HIDE : SW_SHOW);

	// Show/Hide "Force OK" button
	GetDlgItem(IDC_OFFSET_FORCE_OK)->ShowWindow((m_Mode == DBLE_OFFSET_DLG_MODE_EXPAND) ? SW_SHOW : SW_HIDE);
	if (m_Mode == DBLE_OFFSET_DLG_MODE_EXPAND) { // move button force ok to all offset button's position
		GetDlgItem(IDC_OFFSET_FORCE_OK)->MoveWindow(rect1, true);
	}

	// Change language
	ChangeLanguage();

	return TRUE;
}


void CBLE_OffsetDlg::OnClose()
{
	m_pDoc->GetData()->GetSubstrate()->ClearSelICOffset(); // Restore offset of ICs
	
	// Re-draw parent window
	GetParent()->Invalidate();

	CDialog::OnClose();
}

void CBLE_OffsetDlg::OnForceOk()
{
	// Refresh buffer restore
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore();

	CDialog::OnOK();
}

void CBLE_OffsetDlg::OnCancel()
{
	// Refresh buffer, delete all state of offset dialog
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore(IDD_OFFSET_DLG);

	m_pDoc->GetData()->GetSubstrate()->ClearSelICOffset(); // Restore offset of ICs
	
	// Re-draw
	GetParent()->Invalidate();

	CDialog::OnCancel();
}

void CBLE_OffsetDlg::OnOK()
{
	// Refresh buffer restore
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore();

	// Write log
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_CHECKREFELCT, DBLE_LOGFILE_OFFSET, "");

	// Update modified flag
	m_pDoc->SetModifiedFlag(1);
	// Get all selected ICs
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	// Update offset for all selected ICs
	long row = 2;
	int size = (int)vIC.size();
// #MH131118 - Skip deleted ICs in OFFSET mode
	CString strTmp;
	for(int idx = (size - 1); idx >= 0; idx --){
		if ((m_Mode == DBLE_OFFSET_DLG_MODE_OFFSET) && (vIC[idx]->m_Deleted)) {
			continue;
		}
		// Offset X
		vIC[idx]->m_OffsetX = atof(m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_X));
		// Offset Y
		vIC[idx]->m_OffsetY = atof(m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_Y));
		// IC Offset T
		vIC[idx]->m_OffsetT = atof(m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_T));

		// Update target position
		//vIC[idx]->m_TargetBgPosX = vIC[idx]->m_BgPosX + vIC[idx]->m_OffsetX;
		//vIC[idx]->m_TargetBgPosY = vIC[idx]->m_BgPosY + vIC[idx]->m_OffsetY;
		row ++;
	}
	int setting = m_pDoc->GetSetting(); // Check setting
	if (setting == 1) { //Only check and reflect if setting = 1
		// Check in substrate
		CBLE_ProgressBar progressDlg;
		progressDlg.SetDocument(m_pDoc);
		progressDlg.m_Type = DBLE_PROGRESSBAR_CHCK_SELECT_ONLY;
		progressDlg.m_bDisplay = m_pDoc->GetData()->GetSubstrate()->PerformanceChecking();
		
		progressDlg.DoModal();
	}
	if (!m_pDoc->GetData()->GetSubstrate()->CheckSelIC()) { //close dialog if no selected IC is overlapped
		for(int idx = ((int)vIC.size() - 1); idx >= 0; idx --){
			// Update target position if no IC overlapped
			vIC[idx]->m_TargetBgPosX = vIC[idx]->m_BgPosX + vIC[idx]->m_OffsetX;
			vIC[idx]->m_TargetBgPosY = vIC[idx]->m_BgPosY + vIC[idx]->m_OffsetY;
			vIC[idx]->m_TargetTheta = vIC[idx]->m_pRegIC->m_Angle + vIC[idx]->m_OffsetT;
		}
		CDialog::OnOK();	
	} else {
		GetParent()->Invalidate();
		AddGridData(); //update new data for display
		Invalidate();
	}
}


void CBLE_OffsetDlg::OnAllOffset()
{
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	CBLE_AllOffsetDlg AlloffDlg;
	AlloffDlg.SetDocument(m_pDoc);
	if(AlloffDlg.DoModal() != IDOK) return;
	// Set offset for all
	CString strX, strY, strAng; 
	AlloffDlg.GetAllOffset(strX, strY, strAng);

	// Vector of old offset value
	int rowNumber = m_pGridCtrl->GetRows();
	vector<TBLE_GridData> *v_Grid = new vector<TBLE_GridData>;
	for(long row = 2; row < rowNumber; row ++){
		TBLE_GridData gridData(row, COLUMN_OFFSET_X, m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_X));
		v_Grid->push_back(gridData);
		gridData = TBLE_GridData(row, COLUMN_TARGET_X, m_pGridCtrl->GetCellText(row, COLUMN_TARGET_X));
		v_Grid->push_back(gridData);
		gridData = TBLE_GridData(row, COLUMN_OFFSET_Y, m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_Y));
		v_Grid->push_back(gridData);
		gridData = TBLE_GridData(row, COLUMN_TARGET_Y, m_pGridCtrl->GetCellText(row, COLUMN_TARGET_Y));
		v_Grid->push_back(gridData);
		gridData = TBLE_GridData(row, COLUMN_OFFSET_T, m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_T));
		v_Grid->push_back(gridData);
	}

	// Store state
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	CBLE_GridStore grid(v_Grid, IDD_OFFSET_DLG, GRID_TYPE);
	pCareTaker->SetMemento(grid);

	//Add all offset set value to offset value of each IC and update target position
	for(row = 2; row < rowNumber; row ++){
		CString strTmp;
		// Offset X
		strTmp.Format(_T("%.4f"), atof(m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_X)) + atof(strX));
		m_pGridCtrl->SetCellText(row, COLUMN_OFFSET_X, strTmp);
		// Target position X
		strTmp.Format(_T("%.4f"), atof(m_pGridCtrl->GetCellText(row, COLUMN_TARGET_X)) + atof(strX));
		m_pGridCtrl->SetCellText(row, COLUMN_TARGET_X, strTmp);

		// Offset Y
		strTmp.Format(_T("%.4f"), atof(m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_Y)) + atof(strY));
		m_pGridCtrl->SetCellText(row, COLUMN_OFFSET_Y, strTmp);
		// Target position Y
		strTmp.Format(_T("%.4f"), atof(m_pGridCtrl->GetCellText(row, COLUMN_TARGET_Y)) + atof(strY));
		m_pGridCtrl->SetCellText(row, COLUMN_TARGET_Y, strTmp);
		// IC Angle
		strTmp.Format(_T("%.4f"), atof(m_pGridCtrl->GetCellText(row, COLUMN_OFFSET_T)) + atof(strAng));
		m_pGridCtrl->SetCellText(row, COLUMN_OFFSET_T, strTmp);
	}
}


void CBLE_OffsetDlg::InitGridCtrl()
{
	// Set language
	m_pGridCtrl->SetLanguage(m_pDoc->GetData()->m_Init.m_Language);

	// Set width for all cols
	for(UINT idx = 0; idx < ARRAY_LENGTH(m_arrOffsetColWidth); idx ++){
		m_pGridCtrl->SetColWidth(idx, m_arrOffsetColWidth[idx]);
	}

	for(idx = 0; idx < ARRAY_LENGTH(m_arrOffsetColType); idx ++){
		m_pGridCtrl->SetColType(idx, m_arrOffsetColType[idx]);
	}

	// Set header
	for (int id = 0; id < 6; id++) {
		m_pGridCtrl->SetColHeader(id);
	}
	m_pGridCtrl->SetRowHeader(0);
	m_pGridCtrl->SetRowHeader(1);

		// Set merge for some rows and cols
	m_pGridCtrl->MergeCell(0, 0, 1, 0);
	m_pGridCtrl->MergeCell(0, 1, 0, 2);
	m_pGridCtrl->MergeCell(0, 3, 1, 3);
	m_pGridCtrl->MergeCell(0, 4, 0, 5);
	m_pGridCtrl->MergeCell(0, 6, 0, 7);
	m_pGridCtrl->MergeCell(0, 6, 0, 8);
	m_pGridCtrl->SetColInvisible(0);
	m_pGridCtrl->SetColInvisible(3);
	// Set header
	m_pGridCtrl->SetCellText(0, 0, _T("Reg No"));

	m_pGridCtrl->SetCellText(0, 1, _T("Index"));
	m_pGridCtrl->SetCellText(1, 1, _T("X"));
	m_pGridCtrl->SetCellText(1, 2, _T("Y"));

	m_pGridCtrl->SetCellText(0, 3, _T("IC Type"));

	m_pGridCtrl->SetCellText(0, 4, _T("Target BgPos"));
	m_pGridCtrl->SetCellText(1, 4, _T("X [mm]"));
	m_pGridCtrl->SetCellText(1, 5, _T("Y [mm]"));
	
	m_pGridCtrl->SetCellText(0, 6, _T("Offset"));
	m_pGridCtrl->SetCellText(1, 6, _T("X [mm]"));
	m_pGridCtrl->SetCellText(1, 7, _T("Y [mm]"));
	m_pGridCtrl->SetCellText(1, 8, _T("T [deg]"));

}

void CBLE_OffsetDlg::AddGridData()
{
	StopWatch	addGridData;addGridData.Start(TRUE);
	// Get all selected ICs
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	// Set the number of row
	//int startRow = 2;

	// Set content for all rows
	int row = 2;		// start row is 2 because of 2 first rows are header.
	CString strTmp;
// #MH131118: Skip deleted ICs in OFFSET mode
	int selectSize = (int)vIC.size();
	for(int idx = (selectSize - 1); idx >= 0; idx --){
		if ((m_Mode == DBLE_OFFSET_DLG_MODE_OFFSET) && (vIC[idx]->m_Deleted)) {
			continue;
		}
		if (vIC[idx]->m_Overlapped) {
			m_pGridCtrl->SetCellColor(row, true);
		} else {
			m_pGridCtrl->SetCellColor(row, false);
		}
		// RegNo
		strTmp.Format(_T("%d"), vIC[idx]->m_pRegIC->m_RegNo);
		m_pGridCtrl->SetCellText(row, 0, strTmp);
		// IC number X
		strTmp.Format(_T("%d"), vIC[idx]->m_indexX + 1);
		m_pGridCtrl->SetCellText(row, 1, strTmp);
		// IC number Y
		strTmp.Format(_T("%d"), vIC[idx]->m_indexY + 1);
		m_pGridCtrl->SetCellText(row, 2, strTmp);
		// IC type
		strTmp.Format(_T("%d"), vIC[idx]->m_pRegIC->m_Type);
		m_pGridCtrl->SetCellText(row, 3, strTmp);
		// IC startpos X, startpos Y
		if(m_Mode == DBLE_OFFSET_DLG_MODE_OFFSET){
			// IC startpos X
			strTmp.Format(_T("%.4f"), vIC[idx]->GetPosX());
			m_pGridCtrl->SetCellText(row, 4, strTmp);
			// IC startpos Y
			strTmp.Format(_T("%.4f"), vIC[idx]->GetPosY());
			m_pGridCtrl->SetCellText(row, 5, strTmp);
			// Offset X
			strTmp.Format(_T("%.4f"), vIC[idx]->m_OffsetX);
			m_pGridCtrl->SetCellText(row, 6, strTmp);
			// Offset Y
			strTmp.Format(_T("%.4f"), vIC[idx]->m_OffsetY);
			m_pGridCtrl->SetCellText(row, 7, strTmp);
			// Offset T
			strTmp.Format(_T("%.4f"), vIC[idx]->m_OffsetT);
			m_pGridCtrl->SetCellText(row, 8, strTmp);
		}else if(m_Mode == DBLE_OFFSET_DLG_MODE_EXPAND){
			// IC startpos X
			strTmp.Format(_T("%.4f"), vIC[idx]->GetPosX());
			m_pGridCtrl->SetCellText(row, 4, strTmp);
			// IC startpos Y
			strTmp.Format(_T("%.4f"), vIC[idx]->GetPosY());
			m_pGridCtrl->SetCellText(row, 5, strTmp);

			// Offset X
			strTmp.Format(_T("%.4f"), vIC[idx]->m_OffsetX);
			m_pGridCtrl->SetCellText(row, 6, strTmp);
			// Offset Y
			strTmp.Format(_T("%.4f"), vIC[idx]->m_OffsetY);
			m_pGridCtrl->SetCellText(row, 7, strTmp);

			// Offset T
			strTmp.Format(_T("%.4f"), vIC[idx]->m_OffsetT);
			m_pGridCtrl->SetCellText(row, 8, strTmp);
		}

		row ++;
	}
	TRACE("[Edit]CBLE_ OffsetDlg::AddGridData() Size=%d time=%dm:%ds(%d)\n",vIC.size(), addGridData.readMin(),addGridData.readSec(),addGridData.Read()/1000);
}

LRESULT CBLE_OffsetDlg::OnUpdateGrid(WPARAM wParam, LPARAM lParam)
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	long row = m_pGridCtrl->GetRowSel();
	long col = m_pGridCtrl->GetColSel();
	CString tmpText = m_pGridCtrl->GetCellText(row, col);
	CString oldText = m_pGridCtrl->GetCell(row, col)->GetOldText();

	if (tmpText.Compare(oldText) != 0) {
		
		double value = atof (tmpText);
		// Check input value for offset
		if (col == COLUMN_OFFSET_X || col == COLUMN_OFFSET_Y) {
			if (value > 9.9 || value < -9.9) {

				//int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
				int nType = theApp.CBTMessageBox(this->m_hWnd, OutOfRangeOff[language], MB_YESNO, language);
				// Write log file: missing value
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, OutOfRangeOff[language], "", "");

				if (nType == IDYES) {								// Re-input
					m_pGridCtrl->SetCellText(row, col, oldText);
					m_pGridCtrl->ShowEditBox();
					return 0;
				} else {
					//m_pGridCtrl->RestoreText(row, col);
					tmpText = oldText;
				}
			} else {
				// Store state
				CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
				CBLE_GridStore grid(row, col, oldText, IDD_OFFSET_DLG, GRID_TYPE);
				pCareTaker->SetMemento(grid);
			}
		} else if (col == COLUMN_OFFSET_T) {
			if (value < -360 || value > 360) {

				//int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
				int nType = theApp.CBTMessageBox(this->m_hWnd, OutOfRangeOff[language], MB_YESNO, language);
				// Write log file: missing value
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, OutOfRangeOff[language], "", "");

				if (nType == IDYES) {								// Re-input
					//m_pGridCtrl->SetCellText(row, col, oldText);
					// Set cell to blank but doesn't change old text
					m_pGridCtrl->SetCellText(row, col, oldText);
					m_pGridCtrl->ShowEditBox();
					return 0;
				} else {
					//m_pGridCtrl->RestoreText(row, col);
					tmpText = oldText;
				}
			} else {
				// Store state
				CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
				CBLE_GridStore grid(row, col, oldText, IDD_OFFSET_DLG, GRID_TYPE);
				pCareTaker->SetMemento(grid);
			}
		} else {
			// Nothing
		}
		m_pGridCtrl->SetCellText(row, col, tmpText);
	}
//	delete pCareTaker;
	//m_pGridCtrl->SetCellText(row, col, tmpText);

	// Set focus on Offset dialog
	SetFocus();
	// Move to next collumn
	if (col + 1 < m_pGridCtrl->GetCols()) {
		m_pGridCtrl->SetCellSel(row, col + 1);
	} else if (row + 1 < m_pGridCtrl->GetRows()){ // if collumn is maximum then return;
		// #DucDT131108: Move to next row, column is offsetX
		m_pGridCtrl->SetCellSel(row + 1, /*IC_TYPE*/COLUMN_OFFSET_X);
	} else {
		m_pGridCtrl->Deselect();
	}
	//m_pGridCtrl->Deselect();

	// Update target position
	// Get old value
	if ((col == COLUMN_OFFSET_X) || (col == COLUMN_OFFSET_Y)) {
		int targetColumn = col - COLUMN_OFFSET_X + COLUMN_TARGET_X;
		CString strTargetPos = m_pGridCtrl->GetCellText(row, targetColumn);

		// Update new value
		double newTargetX = atof(strTargetPos) + atof(tmpText) - atof(oldText);
		strTargetPos.Format(_T("%4f"), newTargetX);
		m_pGridCtrl->SetCellText(row, targetColumn, strTargetPos);
	}

	Invalidate();
	return 0;
}

/*
* Change language
*/
void CBLE_OffsetDlg::ChangeLanguage()
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	for (UINT id = IDC_OFFSET_NUM_KEY; id <= IDC_OFFSET_ALL; id ++) {
		for (int idx = 0; idx < DBLE_LANGUAGE_ITEMS; idx ++) {
			if ((id == m_pDoc->m_DialogItems[idx].m_ID) && (m_pDoc->m_DialogItems[idx].m_Name.Compare("") != 0)) {
				GetDlgItem(id)->SetWindowText(m_pDoc->m_DialogItems[idx].m_Name);
				break;
			}
		}
	}
}

/**
* Restore last state
*/
void CBLE_OffsetDlg::OnRestoreState()
{
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	if (!pCareTaker->Restoreable() || pCareTaker->GetLastKind() != IDD_OFFSET_DLG ) {
//		delete pCareTaker;
		return;
	}
	CBLE_Memento mem = pCareTaker->GetMemento();
	void* tmp = mem.GetState();
	vector<TBLE_GridData> *v_Grid = static_cast<vector<TBLE_GridData> *>(tmp);

	// Reset marked cells
	m_pGridCtrl->ResetMarkCells();

	int size = v_Grid->size();
	if (size > 1) {
		int size = v_Grid->size();
		for (int idx = 0; idx < size; idx++) {
			TBLE_GridData grid = v_Grid->at(idx);
			m_pGridCtrl->SetCellText(grid.row, grid.col, grid.val);
			if (grid.col != COLUMN_TARGET_X && grid.col != COLUMN_TARGET_Y) {
				// Mark cell
				m_pGridCtrl->SetMarkCell(grid.row, grid.col);
			}
			if (grid.row == 2 /*first restore row*/ && grid.col == COLUMN_OFFSET_T) {
				// Move scroll
				m_pGridCtrl->MoveScrollCell(grid.row, grid.col);
			}
		}
	} else {
		TBLE_GridData grid = v_Grid->at(0);
		//m_GridCtrl->SetCellSel(grid.row, grid.col);
		CString resVal = m_pGridCtrl->GetCellText(grid.row, grid.col);
		m_pGridCtrl->SetCellText(grid.row, grid.col, grid.val);
		
		// Mark cell
		m_pGridCtrl->SetMarkCell(grid.row, grid.col);
		// Move scroll to mark cell
		m_pGridCtrl->MoveScrollCell(grid.row, grid.col);

		if ((grid.col == COLUMN_OFFSET_X) || (grid.col == COLUMN_OFFSET_Y)) {
			int targetColumn = grid.col - COLUMN_OFFSET_X + COLUMN_TARGET_X;
			CString strTargetPos = m_pGridCtrl->GetCellText(grid.row, targetColumn);
			// Update new value
			double newTargetX = atof(strTargetPos) - atof(resVal) + atof(grid.val);
			strTargetPos.Format(_T("%4f"), newTargetX);
			m_pGridCtrl->SetCellText(grid.row, targetColumn, strTargetPos);
		}
	}
	Invalidate();
	delete v_Grid;
}

/**
* Catch Ctrl + Z to restore
*/
BOOL CBLE_OffsetDlg::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN /*&& pMsg->wParam == VK_CONTROL*/){
		if ((GetKeyState(0x5A) & 0x8000) && (GetKeyState(VK_CONTROL) & 0x8000)) {
			OnRestoreState();
		}
    }	
    return CDialog::PreTranslateMessage(pMsg);
}

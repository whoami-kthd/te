///////////////////////////////////////////////////////////
//  CBLE_OptCheckReflect.cpp
//  Implementation of the Class CBLE_OptCheckReflect
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_OptCheckReflect.h"
#include "CBLE_FrameWnd.h"

#define DBLE_COLORDLG_WIDTH						220
#define DBLE_COLORDLG_HEIGHT					330

/////////////////////////////////////////////////////////////////////////////
// CBLE_OptCheckReflect dialog


CBLE_OptCheckReflect::CBLE_OptCheckReflect(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_OptCheckReflect::IDD, pParent)
{
	m_pDoc = NULL;
	m_Check = 1;
}

CBLE_OptCheckReflect::~CBLE_OptCheckReflect()
{

}


void CBLE_OptCheckReflect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBLE_OptCheckReflect, CDialog)
	// Messages
	ON_BN_CLICKED(IDC_OPT_CHCK_RADIO_CHCK, OnCheckReflect)
	ON_BN_CLICKED(IDC_OPT_CHCK_RADIO_REFLECT, OnReflectOnly)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_OptCheckReflect message handlers

void CBLE_OptCheckReflect::OnCancel()
{
	CDialog::OnCancel();
}

void CBLE_OptCheckReflect::OnOK()
{
	// Change setting for check reflect
	m_pDoc->SetSetting(m_Check);

	// Change color setting
	TBLE_StatusColor* dispColor = &(m_pDoc->GetData()->m_StatusColor);
	dispColor->m_Cursor = m_DispColor.m_Cursor;
	dispColor->m_Focus = m_DispColor.m_Focus;
	dispColor->m_IndexDisp = m_DispColor.m_IndexDisp;
	dispColor->m_OverlapDisp = m_DispColor.m_OverlapDisp;
	dispColor->m_Regno = m_DispColor.m_Regno;
	dispColor->m_Shape = m_DispColor.m_Shape;
	dispColor->m_CenterLine = m_DispColor.m_CenterLine;
	dispColor->m_ValidDisp = m_DispColor.m_ValidDisp;

// #DDT140116: Save setting color to edit mode configuration file
	m_pDoc->GetData()->SaveSettingColor();

	// Send message to frame to ask other side change color
	CBLE_FrameWnd *frame = (CBLE_FrameWnd*)GetParentFrame();
	frame->PostMessage(WM_UPDATE_OPTION, 0, 0);

	CDialog::OnOK();
}

BOOL CBLE_OptCheckReflect::OnInitDialog()
{
	CDialog::OnInitDialog();

	CRect rect;
	GetDlgItem(IDC_OPT_CHCK_FULLKEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(m_Edit.GetEditWnd(), IDD_FKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);

	InitView();
	UpdateData(FALSE);
	return TRUE;
}

void CBLE_OptCheckReflect::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

void CBLE_OptCheckReflect::InitView()
{
	CButton* checkReflect;
	// Get setting from ini file
	m_Check = m_pDoc->GetSetting();

	// Get color
	m_DispColor = m_pDoc->GetData()->m_StatusColor;

	// Set checked for button
	checkReflect = (CButton*) GetDlgItem(IDC_OPT_CHCK_RADIO_CHCK);
	checkReflect->SetCheck(m_Check == 1);
	checkReflect = (CButton*) GetDlgItem(IDC_OPT_CHCK_RADIO_REFLECT);
	checkReflect->SetCheck(m_Check == 0);

	ShowWindow(SW_SHOW);
}

// Set setting to check and reflect
void CBLE_OptCheckReflect::OnCheckReflect()
{
	m_Check = 1;
}

// Set setting to reflect only
void CBLE_OptCheckReflect::OnReflectOnly()
{
	m_Check = 0;
}

// Draw color picker
void CBLE_OptCheckReflect::OnPaint()
{
	CDialog::OnPaint();
	CClientDC dc(this);
	CRect rect;
	CPen pen;
	pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	CPen* pOldPen = dc.SelectObject(&pen);
	// Store brush
	CBrush* pOlBrush = dc.GetCurrentBrush();
	CBrush brush;

	// Draw color
	CWnd* pWnd = GetDlgItem(IDC_OPT_COLOR_CURSOR);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		CBrush brush(m_DispColor.m_Cursor);
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}

	pWnd = GetDlgItem(IDC_OPT_COLOR_VALID_DISP);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		CBrush brush(m_DispColor.m_ValidDisp);
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}

	pWnd = GetDlgItem(IDC_OPT_COLOR_OVERLAP_DISP);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		brush.CreateSolidBrush(m_DispColor.m_OverlapDisp);
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}

	pWnd = GetDlgItem(IDC_OPT_COLOR_REGNO);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		CBrush brush(m_DispColor.m_Regno);
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}

	pWnd = GetDlgItem(IDC_OPT_COLOR_CENTER_LINE);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		CBrush brush(m_DispColor.m_CenterLine);
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}

	pWnd = GetDlgItem(IDC_OPT_COLOR_INDEX_DISP);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		CBrush brush(m_DispColor.m_IndexDisp);
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}

	pWnd = GetDlgItem(IDC_OPT_COLOR_SHAPE);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		CBrush brush(m_DispColor.m_Shape);
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}

	pWnd = GetDlgItem(IDC_OPT_COLOR_FOCUS);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		CBrush brush(m_DispColor.m_Focus);
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}

	dc.SelectObject(pOlBrush);
	dc.SelectObject(pOldPen);
	return;
}

// Check if click on corlor picker
void CBLE_OptCheckReflect::OnLButtonDown(UINT nFlags, CPoint point)
{
	CRect rect;
	for (int idx = IDC_OPT_COLOR_CURSOR; idx <= IDC_OPT_COLOR_FOCUS; idx++) {
		GetDlgItem(idx)->GetWindowRect(rect);
		ScreenToClient(&rect);
		if (PtInRect(&rect, point)) {
			CBLE_ColorDlg dlg;
			ClientToScreen(&rect);

			// Set choose color dialog position
			int width = GetSystemMetrics(SM_CXFULLSCREEN);
			int height = GetSystemMetrics(SM_CYFULLSCREEN);	
			if (rect.bottom + DBLE_COLORDLG_HEIGHT < height) {
				if (rect.left + DBLE_COLORDLG_WIDTH < width) {
					// LeftBottom
					dlg.SetPosition(rect.left, rect.bottom, DBLE_COLORDLG_WIDTH, DBLE_COLORDLG_HEIGHT);
				} else {
					// RightBottom
					dlg.SetPosition(rect.right - DBLE_COLORDLG_WIDTH, rect.bottom, DBLE_COLORDLG_WIDTH, DBLE_COLORDLG_HEIGHT);
				}
			} else {
				if (rect.left + DBLE_COLORDLG_WIDTH < width) {
					// LeftTop
					dlg.SetPosition(rect.left, rect.top - DBLE_COLORDLG_HEIGHT, DBLE_COLORDLG_WIDTH, DBLE_COLORDLG_HEIGHT);
				} else {
					// RightTop
					dlg.SetPosition(rect.right - DBLE_COLORDLG_WIDTH, rect.top - DBLE_COLORDLG_HEIGHT, DBLE_COLORDLG_WIDTH, DBLE_COLORDLG_HEIGHT);
				}
			}
			if (dlg.DoModal() == IDOK) 
			{ 			
				// Change color
				COLORREF color = dlg.GetColor();
				switch (idx){
				case IDC_OPT_COLOR_CURSOR:
					m_DispColor.m_Cursor = color;
					break;
				case IDC_OPT_COLOR_VALID_DISP:
					m_DispColor.m_ValidDisp = color;
					break;
				case IDC_OPT_COLOR_OVERLAP_DISP:
					m_DispColor.m_OverlapDisp = color;
					break;
				case IDC_OPT_COLOR_REGNO:
					m_DispColor.m_Regno = color;
					break;
				case IDC_OPT_COLOR_CENTER_LINE:
					m_DispColor.m_CenterLine = color;
					break;
				case IDC_OPT_COLOR_INDEX_DISP:
					m_DispColor.m_IndexDisp = color;
					break;
				case IDC_OPT_COLOR_SHAPE:
					m_DispColor.m_Shape = color;
					break;
				case IDC_OPT_COLOR_FOCUS:
					m_DispColor.m_Focus = color;
					break;
				default:
					break;
				}
				Invalidate();
			}
			break;
		}
	}
}
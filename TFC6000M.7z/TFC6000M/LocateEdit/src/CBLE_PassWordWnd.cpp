// CBLE_PassWordWnd.cpp : implementation file
//

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_PassWordWnd.h"
#include "CBLE_PassWordChangeDlg.h"

//#define WARNING_MESSAGE		_T("Your password is not correct")
/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString PassNotCorrect[] =	{							
								_T("�p�X���[�h���Ԉ���Ă��܂��B"),
								_T("Your password is not correct"),
							};

/////////////////////////////////////////////////////////////////////////////
// CBLE_PassWordWnd dialog


CBLE_PassWordWnd::CBLE_PassWordWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_PassWordWnd::IDD, pParent)
{
	m_pDoc = NULL;
}

CBLE_PassWordWnd::~CBLE_PassWordWnd()
{

}


void CBLE_PassWordWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBLE_PassWordWnd, CDialog)
	//{{AFX_MSG_MAP(CBLE_PassWordWnd)
	ON_BN_CLICKED(IDC_PASSWORD_CANCEL, OnPasswordCancel)
	ON_BN_CLICKED(IDC_PASSWORD_CHANGEPASSWORD, OnPasswordChangepassword)
	ON_BN_CLICKED(IDC_PASSWORD_LEVELDOWN, OnPasswordLeveldown)
	ON_MESSAGE(WM_UPDATE_KEY, OnPressKey)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_MappingWnd message handlers


BOOL CBLE_PassWordWnd::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Create key window
	CRect rect;
	GetDlgItem(IDC_PASSWORD_NUM_KEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(this, IDD_NKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);

	//Display password level
	DisplayPasswordLevel();

	InitView();
	UpdateData(FALSE);
	return TRUE;
}


void CBLE_PassWordWnd::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

void CBLE_PassWordWnd::InitView()
{
	ShowWindow(SW_SHOW);
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_PassWordWnd message handlers

void CBLE_PassWordWnd::OnPasswordCancel() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnCancel();
	
}

void CBLE_PassWordWnd::OnPasswordChangepassword() 
{
	// TODO: Add your control notification handler code here
	CBLE_PassWordChangeDlg passwordChangeDlg;
	passwordChangeDlg.SetDocument(m_pDoc);
	passwordChangeDlg.DoModal();
}

void CBLE_PassWordWnd::OnPasswordLeveldown() 
{
	if(m_pDoc->m_User == DBLE_USER_LEVEL1) return;
	int user = (int)m_pDoc->m_User - 1;
	m_pDoc->m_User = (DBLE_USER)user;
	//Display password level
	DisplayPasswordLevel();
}

void CBLE_PassWordWnd::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	CDialog::OnClose();
}

LRESULT CBLE_PassWordWnd::OnPressKey(WPARAM wParam, LPARAM lParam)
{
	CString temp;
	GetDlgItem(IDC_PASSWORD_ENTERPASS)->GetWindowText(temp);
	
	// Check password when user press enter key on keypad
	if (UINT(wParam) == IDC_NKEY_ENT) {
		GetDlgItem(IDC_PASSWORD_ENTERPASS)->GetWindowText(temp);
		if (!strcmp(m_pDoc->GetData()->m_Init.m_PassLevel1, temp)) {
			m_pDoc->m_User = DBLE_USER_LEVEL1;
		} else if (!strcmp(m_pDoc->GetData()->m_Init.m_PassLevel2, temp)) {
			m_pDoc->m_User = DBLE_USER_LEVEL2;
		} else if (!strcmp(m_pDoc->GetData()->m_Init.m_PassLevel3, temp)) {
			m_pDoc->m_User = DBLE_USER_LEVEL3;
		} else {
			//AfxMessageBox(WARNING_MESSAGE);
			theApp.CBTMessageBox(this->m_hWnd, PassNotCorrect[m_pDoc->GetData()->m_Init.m_Language], MB_OK, m_pDoc->GetData()->m_Init.m_Language);
			// Write log file: pass in use
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, PassNotCorrect[m_pDoc->GetData()->m_Init.m_Language], "", "");
		}
	} else {
		//In normal cases, keypad only allow integer or double, in this case we need to
		//store password as text, so program need to avoid it.
		PressNumKey(temp, UINT(wParam), false);
	}

	GetDlgItem(IDC_PASSWORD_ENTERPASS)->SetWindowText(temp);
	DisplayPasswordLevel();

	return 0;
}

void CBLE_PassWordWnd::DisplayPasswordLevel()
{
	GetDlgItem(IDC_PASSWORD_LEVEL1)->EnableWindow(m_pDoc->m_User == DBLE_USER_LEVEL1);
	GetDlgItem(IDC_PASSWORD_LEVEL2)->EnableWindow(m_pDoc->m_User == DBLE_USER_LEVEL2);
	GetDlgItem(IDC_PASSWORD_LEVEL3)->EnableWindow(m_pDoc->m_User == DBLE_USER_LEVEL3);
}

// Change a text when press a numkey
void CBLE_PassWordWnd::PressNumKey(CString& text, UINT key, bool isInteger)
{
	switch(key){
	case IDC_NKEY_0:
	case IDC_NKEY_1:
	case IDC_NKEY_2:
	case IDC_NKEY_3:
	case IDC_NKEY_4:
	case IDC_NKEY_5:
	case IDC_NKEY_6:
	case IDC_NKEY_7:
	case IDC_NKEY_8:
	case IDC_NKEY_9:
		{
			CString strNum;
			strNum.Format(_T("%d"), key - IDC_NKEY_0);
			text += strNum;
		}
		break;
	case IDC_NKEY_DEL:
		text = text.Mid(0, text.GetLength() - 1);
		break;
	case IDC_NKEY_DOT:
		text += _T(".");
		break;
	case IDC_NKEY_CLR:
		text = _T("");
		break;
	case IDC_NKEY_MINUS:
		text += _T("-");
		break;
	case IDC_NKEY_ENT:
		if(isInteger){
			text.Format(_T("%d"), atoi(text));
		}else{
			text.Format(_T("%.4f"), atof(text));
		}
		break;
	default:
		break;
	}
}

/*
*
*/
void CBLE_PassWordWnd::ChangeLanguage()
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	for (UINT id = IDC_PASSWORD_ENTERPASS; id <= IDC_PASSWORD_LEVEL3; id ++) {
		for (int idx = 0; idx < DBLE_LANGUAGE_ITEMS; idx ++) {
			if ((id == m_pDoc->m_DialogItems[idx].m_ID) && (m_pDoc->m_DialogItems[idx].m_Name.Compare("") != 0)) {
				GetDlgItem(id)->SetWindowText(m_pDoc->m_DialogItems[idx].m_Name);
				break;
			}
		}
	}
}
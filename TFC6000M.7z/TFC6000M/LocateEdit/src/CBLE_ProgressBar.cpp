// CBLE_ProgressBar.cpp : implementation file
//

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_ProgressBar.h"
#include "CBLE_IC.h"
#include "CBLE_Util.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define PROGRESS_TIMER			1000
#define PROGRESS_BAR_MAX_RANGE	100
#define PROGRESS_BAR_MIN_RANGE	0

/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString SaveNotDoneProg[] =		{
									_T("�f�[�^�̕ۑ����������Ă��܂���B������x��蒼���Ă�������"),
									_T("Saving data is not completed. Please try again."),
								};
CString Saving[] =				{
									_T("�f�[�^�����ݒ�..."),
									_T("Data is saving..."),
								};

CString Waiting[] =				{
									_T("TFC�̎���..."),
									_T("Waiting for TFC..."),
								};

CString Openning[] =			{
									_T("�f�[�^�����[�h��..."),
									_T("Data is loading..."),
								};

/////////////////////////////////////////////////////////////////////////////
// CBLE_ProgressBar dialog


CBLE_ProgressBar::CBLE_ProgressBar(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_ProgressBar::IDD, pParent)
{
	m_pDoc				= NULL;
	m_pProgThread		= NULL;
	m_StopThread		= CreateEvent(0, false, false, 0); // stop thread
	m_StopUpdate		= CreateEvent(0, true, false, 0); // stop update progress bar and kill timer
	m_Type				= DBLE_PROGRESSBAR_CHCK;
	m_bDisplay			= true;
	m_bResult			= true;
	m_FolderPath		= "";	// this parametter will be used to open data from folder
	m_OpenTimerID		= NULL;
}

CBLE_ProgressBar::~CBLE_ProgressBar()
{
	if (m_pProgThread != NULL){
		::WaitForSingleObject(m_pProgThread->m_hThread, INFINITE);
		delete m_pProgThread;
	}
	::CloseHandle(m_StopThread);
	::CloseHandle(m_StopUpdate);
}

void CBLE_ProgressBar::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBLE_ProgressBar)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BOOL CBLE_ProgressBar::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	UpdateData(false);
	switch(m_Type) {
	case DBLE_PROGRESSBAR_CHCK:
		m_pProgThread = AfxBeginThread(
			CheckReflectProc,				// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
		break;
	case DBLE_PROGRESSBAR_CHCK_SELECT_ONLY:
		m_pProgThread = AfxBeginThread(
			CheckReflectSelectOnly,			// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
		break;
	case DBLE_PROGRESSBAR_SAVE_DATA:
		m_pProgThread = AfxBeginThread(
			SaveDataThread,			// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
		break;
	case DBLE_PROGRESSBAR_OPEN_DATA:
		m_pProgThread = AfxBeginThread(
			OpenDataThread,					// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
		break;
	default:
		m_pProgThread = NULL;
		break;
	}
	if (m_pProgThread) {
		// Don't auto delete after thread terminated
		m_pProgThread->m_bAutoDelete = FALSE;
		// Start thread
		m_pProgThread->ResumeThread();
	}
	/* If number of IC is smaller than 10000, hide progress bar
	if (m_bDisplay == false) {
		MoveWindow(0, 0, 0, 0);
	}*/
	return TRUE;
}

void CBLE_ProgressBar::SetDocument(CBLE_Doc* p_Doc)
{
	m_pDoc = p_Doc;
}

BEGIN_MESSAGE_MAP(CBLE_ProgressBar, CDialog)
	//{{AFX_MSG_MAP(CBLE_ProgressBar)
	ON_MESSAGE(WM_FINISH_CHECK, OnAutoClose)
	ON_WM_TIMER()
	ON_WM_WINDOWPOSCHANGING()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_ProgressBar message handlers

void CBLE_ProgressBar::OnOK() 
{
	if (m_Type == DBLE_PROGRESSBAR_OPEN_DATA) {
		::SetEvent(m_pDoc->GetData()->m_StopThread);
		return;
	}
	// Set event to stop thread
	::SetEvent(m_StopThread);
	// Write log
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_CHECKREFELCT, DBLE_LOGFILE_FORCEOK, "");
}

/////////////////////////////////////////////////////////////////////////////
// Auto close dialog after finished checking
LRESULT CBLE_ProgressBar::OnAutoClose(WPARAM wParam,LPARAM lParam)
{
	CDialog::OnOK();
	return 0;
}

// Hide modal dialog
void CBLE_ProgressBar::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos)
{
	if(!m_bDisplay) {
        lpwndpos->flags &= ~SWP_SHOWWINDOW;
	}

    CDialog::OnWindowPosChanging(lpwndpos);
}

void CBLE_ProgressBar::OnCancel() 
{
	// TODO: Add extra cleanup here
	// Don't allow close progressbar with escape key
	//CDialog::OnCancel();
}

// Auto update progress bar after an amount of time
void CBLE_ProgressBar::OnTimer(UINT nIDEvent)
{
	if (WaitForSingleObject(m_StopUpdate, 0) == WAIT_OBJECT_0) { // close progress bar event
		
		BOOL r = KillTimer(m_OpenTimerID);
		if (!r) {
			CString tmp;
			tmp.Format("Kill Timer %d:%d", m_OpenTimerID, GetLastError());
			AfxMessageBox(tmp);
		}
		return;
	}

	CProgressCtrl* p_ProgressBar = (CProgressCtrl*) GetDlgItem(IDC_PROGRESSBAR_PROGRESS);
	if (m_Type == DBLE_PROGRESSBAR_OPEN_DATA) {
		if (m_pDoc->GetData()->m_bStartProgress) {
			int size = m_pDoc->GetData()->GetSubstrate()->m_vIC.size(); // Set size for open file after create all IC
			CString maxSize;
			maxSize.Format(_T("%d"), size);
			GetDlgItem(IDC_PROGRESSBAR_IC_FINISH)->SetWindowText(maxSize);
			p_ProgressBar->SetRange32(0, size);
		}
	}
	if (m_Type == DBLE_PROGRESSBAR_SAVE_DATA) {
		if (m_pDoc->m_TFCRespond) {
			GetDlgItem(IDC_PROGRESSBAR_CHECK)->SetWindowText(Saving[m_pDoc->GetData()->m_Init.m_Language]);
		}
	}
	
	int pos = m_pDoc->GetData()->m_ProcessIndex; //get process index
	CString currentPos;
	currentPos.Format(_T("%d"), pos);
	GetDlgItem(IDC_PROGRESSBAR_IC_START)->SetWindowText(currentPos);
	p_ProgressBar->SetPos(pos);
}

// Check and reflect
UINT CBLE_ProgressBar::CheckReflectProc( LPVOID pParam ) {
	CBLE_ProgressBar* dialog = (CBLE_ProgressBar*) pParam;
	CProgressCtrl* p_ProgressBar = (CProgressCtrl*) (dialog->GetDlgItem(IDC_PROGRESSBAR_PROGRESS));
	CBLE_Doc* p_Doc = ((CBLE_ProgressBar*) pParam)->m_pDoc;
	vector<CBLE_IC*> pIC;
	if (p_Doc != NULL) {
		pIC = p_Doc->GetData()->GetSubstrate()->m_vIC;
		//p_Doc->GetData()->GetSubstrate()->CheckReflect();
	}
	// Check if IC is in substrate
	int size = pIC.size();
	CString total;
	total.Format(_T("%d"), size);
	dialog->GetDlgItem(IDC_PROGRESSBAR_IC_FINISH)->SetWindowText(total);

	CBLE_IC* temp;
	for(int idx = 0; idx < size; idx ++){
		temp = pIC[idx];
		// Reset overlapped status
		temp->m_Overlapped = false;
		// Check if IC is in substrate
		if(temp->m_Deleted || p_Doc->GetData()->GetSubstrate()->ICInSubstrate(temp)) continue;
		temp->m_Overlapped = true;
	}

	// Check overlap
	CBLE_IC* pIC1 = NULL;
	CBLE_IC* pIC2 = NULL;
	
	for(int idx1 = 0; idx1 < (size - 1); idx1 ++){
		if (::WaitForSingleObject(dialog->m_StopThread, 0) == WAIT_OBJECT_0) {
			break;
		}
		pIC1 = pIC[idx1];
		if(pIC1->m_Deleted) {
			continue;
		}
		for(int idx2 = idx1 + 1; idx2 < size; idx2 ++) {
			pIC2 = pIC[idx2];
			if(pIC2->m_Deleted) {
				continue;
			}

			// Determine if IC need to be checked or not
			double distance = CBLE_Util::SegmentLength(R2Pos(pIC1->GetPosX(), pIC1->GetPosY()), R2Pos(pIC2->GetPosX(), pIC2->GetPosY()));

			// Calculate radius of IC1's circle
			double sizeXIC1 = pIC1->m_pRegIC->m_SizeX;
			double sizeYIC1 = pIC1->m_pRegIC->m_SizeY;
			double r1 = sqrt(sizeXIC1 * sizeXIC1 + sizeYIC1* sizeYIC1) / 2;
			
			// Calculate radius of IC2's circle
			double sizeXIC2 = pIC2->m_pRegIC->m_SizeX;
			double sizeYIC2 = pIC2->m_pRegIC->m_SizeY;
			double r2 = sqrt(sizeXIC2 * sizeXIC2 + sizeYIC2* sizeYIC2) / 2;
			
			if (distance > (r1 + r2)) { // if distance from two center is larger than sum of two radius then skip
				continue;
			}
			
			if(!pIC1->CheckOverlap(pIC2)) {
				continue;
			}
			pIC1->m_Overlapped = true;
			pIC2->m_Overlapped = true;
		}
		CString pos;
		pos.Format(_T("%d"), idx1);
		p_ProgressBar->SetRange32(0, size + 1);
		p_ProgressBar->SetPos(idx1);
		((CBLE_ProgressBar*) pParam)->GetDlgItem(IDC_PROGRESSBAR_IC_START)->SetWindowText(pos);
	}
	::PostMessage(((CBLE_ProgressBar*) pParam)->m_hWnd, WM_FINISH_CHECK, 0, 0);
	Sleep(10);
	TRACE("[Edit]CBLE_ ProgressBar::Check ReflectProc()Running\n");
	return 0;
}

// Create region for all IC
UINT CBLE_ProgressBar::CheckReflectSelectOnly(LPVOID pParam)
{
	CBLE_ProgressBar* dialog = (CBLE_ProgressBar*) pParam;
	CProgressCtrl* p_ProgressBar = (CProgressCtrl*) (dialog->GetDlgItem(IDC_PROGRESSBAR_PROGRESS));
	CBLE_Doc* p_Doc = ((CBLE_ProgressBar*) pParam)->m_pDoc;
	vector<CBLE_IC*> pAllIC;
	vector<CBLE_IC*> pSelIC;
	if (p_Doc != NULL) {
		pAllIC = p_Doc->GetData()->GetSubstrate()->m_vIC;
		pSelIC = p_Doc->GetData()->GetSubstrate()->m_vSelIC;
	}
	// Check if IC is in substrate
	int size2 = pAllIC.size();
	int size1 = pSelIC.size();
	CString total;
	total.Format(_T("%d"), size1);
	dialog->GetDlgItem(IDC_PROGRESSBAR_IC_FINISH)->SetWindowText(total);

	CBLE_IC* temp;
	for(int idx = 0; idx < size1; idx ++){
		temp = pSelIC[idx];
		// Reset overlapped status
		temp->m_Overlapped = false;
		// Check if IC is in substrate
		if(temp->m_Deleted || p_Doc->GetData()->GetSubstrate()->ICInSubstrate(temp)) continue;
		temp->m_Overlapped = true;
	}

	// Check overlap
	CBLE_IC* pIC1 = NULL;
	CBLE_IC* pIC2 = NULL;
	
	for(int idx1 = 0; idx1 < size1; idx1 ++){
		if (::WaitForSingleObject(dialog->m_StopThread, 0) == WAIT_OBJECT_0) {
			break;
		}
		pIC1 = pSelIC[idx1]; // IC in selected IC vector
		if(pIC1->m_Deleted) {
			continue;
		}
		for(int idx2 = 0; idx2 < size2; idx2 ++) {
			pIC2 = pAllIC[idx2]; // IC in all IC vector
			if(pIC2->m_Deleted) {
				continue;
			}
			
			// Handle if IC1 and IC2 is the same
			if (pIC1 == pIC2) {
				continue;
			}

			// Determine if IC need to be checked or not
			double distance = CBLE_Util::SegmentLength(R2Pos(pIC1->GetPosX(), pIC1->GetPosY()), R2Pos(pIC2->GetPosX(), pIC2->GetPosY()));

			// Calculate radius of IC1's circle
			double sizeXIC1 = pIC1->m_pRegIC->m_SizeX;
			double sizeYIC1 = pIC1->m_pRegIC->m_SizeY;
			double r1 = sqrt(sizeXIC1 * sizeXIC1 + sizeYIC1* sizeYIC1) / 2;
			
			// Calculate radius of IC2's circle
			double sizeXIC2 = pIC2->m_pRegIC->m_SizeX;
			double sizeYIC2 = pIC2->m_pRegIC->m_SizeY;
			double r2 = sqrt(sizeXIC2 * sizeXIC2 + sizeYIC2* sizeYIC2) / 2;
			
			if (distance > (r1 + r2)) { // if distance from two center is larger than sum of two radius then skip
				continue;
			}
			
			if(!pIC1->CheckOverlap(pIC2)) {
				continue;
			}
			pIC1->m_Overlapped = true;
			pIC2->m_Overlapped = true;
		}
		CString pos;
		pos.Format(_T("%d"), idx1);
		p_ProgressBar->SetRange32(0, size1 + 1);
		p_ProgressBar->SetPos(idx1);
		((CBLE_ProgressBar*) pParam)->GetDlgItem(IDC_PROGRESSBAR_IC_START)->SetWindowText(pos);
	}
	::PostMessage(((CBLE_ProgressBar*) pParam)->m_hWnd, WM_FINISH_CHECK, 0, 0);
	Sleep(10);
	return 0;
}

// Save data thread
UINT CBLE_ProgressBar::SaveDataThread(LPVOID pParam)
{
	CBLE_ProgressBar* dialog = (CBLE_ProgressBar*) pParam;
	CBLE_Doc* pDoc = dialog->m_pDoc;
	int size = pDoc->GetData()->GetSubstrate()->m_vIC.size(); //get number of IC

	// Set title for progress bar
	//dialog->GetDlgItem(IDC_PROGRESSBAR_CHECK)->SetWindowText(Saving[pDoc->GetData()->m_Init.m_Language]);
	dialog->GetDlgItem(IDC_PROGRESSBAR_CHECK)->SetWindowText(Waiting[pDoc->GetData()->m_Init.m_Language]);

	// Set maximum number of IC
	CString maxSize;
	maxSize.Format(_T("%d"), size);
	dialog->GetDlgItem(IDC_PROGRESSBAR_IC_FINISH)->SetWindowText(maxSize);

	// Disable and hide Force OK button
	dialog->GetDlgItem(IDOK)->EnableWindow(false);
	dialog->GetDlgItem(IDOK)->ShowWindow(SW_HIDE);
	
	CProgressCtrl* p_ProgressBar = (CProgressCtrl*) (dialog->GetDlgItem(IDC_PROGRESSBAR_PROGRESS));
	p_ProgressBar->SetRange32(0, size);
	p_ProgressBar->SetPos(0);

	dialog->m_OpenTimerID = dialog->SetTimer(PROGRESS_TIMER, 10, 0); //update progress bar
	dialog->m_bResult = pDoc->SaveData(); // call function to save data to file
	
	::SetEvent(dialog->m_StopUpdate); // stop update progress bar and kill timer
	::PostMessage(((CBLE_ProgressBar*) pParam)->m_hWnd, WM_FINISH_CHECK, 0, 0); // close dialog
	Sleep(10);
	return 0;
}

// Open data thread
UINT CBLE_ProgressBar::OpenDataThread(LPVOID pParam)
{
	CBLE_ProgressBar* dialog = (CBLE_ProgressBar*) pParam;
	CBLE_Doc* pDoc = dialog->m_pDoc;
	
	dialog->GetDlgItem(IDC_PROGRESSBAR_IC_START)->SetWindowText(_T("")); //reset progress bar
	dialog->GetDlgItem(IDC_PROGRESSBAR_CHECK)->SetWindowText(Openning[pDoc->GetData()->m_Init.m_Language]);

	// Disable and hide Force OK button
	//dialog->GetDlgItem(IDOK)->EnableWindow(false);
	//dialog->GetDlgItem(IDOK)->ShowWindow(SW_HIDE);
	dialog->GetDlgItem(IDOK)->SetWindowText("Cancel");

	dialog->m_OpenTimerID = dialog->SetTimer(PROGRESS_TIMER, 10, 0); //update progress bar
	
	dialog->m_bResult = pDoc->GetData()->GetDataFromFolder(dialog->m_FolderPath); // call function to get data from folder

	::SetEvent(dialog->m_StopUpdate);
	::PostMessage(((CBLE_ProgressBar*) pParam)->m_hWnd, WM_FINISH_CHECK, 0, 0);
	Sleep(10);
	return 0;
}

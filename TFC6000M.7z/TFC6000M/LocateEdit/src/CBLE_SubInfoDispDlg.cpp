///////////////////////////////////////////////////////////
//  CBLE_SubInfoDispDlg.cpp
//  Implementation of the Class CBLE_SubInfoDispDlg
//  Created on:      15-8-2013 14:11:08
//  Original author: DucDT
///////////////////////////////////////////////////////////
#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_SubInfoDispDlg.h"
#include "CBLE_Util.h"
#include "CBLE_Doc.h"
#include "CBLE_SubInfoWnd.h"

CBLE_SubInfoDispDlg::CBLE_SubInfoDispDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_SubInfoDispDlg::IDD, pParent)
{
	m_pDoc = NULL;
	m_pParentWnd = NULL;
	m_bLedMode = false; //#NhamNV-170830
}

CBLE_SubInfoDispDlg::~CBLE_SubInfoDispDlg()
{

}

void CBLE_SubInfoDispDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LED_LBL_DISP, m_ledTextSts); //#NhamNV-170830
}

BEGIN_MESSAGE_MAP(CBLE_SubInfoDispDlg, CDialog)

	ON_COMMAND_RANGE(IDC_SUBINFO_DISPLAY_DETECT_BTN, IDC_SUBINFO_DISPLAY_STACK_BTN, OnChangeDisplayMode)	

	ON_WM_LBUTTONDOWN()
	ON_COMMAND(IDC_LED_DISP_BTN,OnLedDisplaySts) //#NhamNV-170830

	ON_WM_PAINT()

END_MESSAGE_MAP()


BOOL CBLE_SubInfoDispDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;

	// Init view
	InitView();
	// Delete pointer
	delete pContext;

	return TRUE;
}

void CBLE_SubInfoDispDlg::InitView()
{
	CheckBtnState();
	ShowWindow(SW_SHOW);
}

void CBLE_SubInfoDispDlg::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

CBLE_Doc* CBLE_SubInfoDispDlg::GetDocument()
{
	return m_pDoc;
}

void CBLE_SubInfoDispDlg::OnOK()
{
	// do nothing
}

void CBLE_SubInfoDispDlg::OnCancel()
{
	// do nothing
	CDialog::OnCancel();
}

void CBLE_SubInfoDispDlg::OnPaint()
{
	TBLE_StatusColor color = m_pDoc->GetData()->m_StatusColor;
	CDialog::OnPaint();
	CClientDC dc(this);
	CRect rect;
	CPen pen;
	pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
	CPen* pOldPen = dc.SelectObject(&pen);
	// Store brush
	CBrush* pOlBrush = dc.GetCurrentBrush();
	CBrush brush;
	CWnd* pWnd = GetDlgItem(IDC_SUBINFO_DISPLAY_UNKNOW_COLOR);
	//#NhamNV-170830 Draw SubInfo Display Dialog when display Led status (S)
	if(pWnd != NULL) {
		CBrush brush;
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		if(m_bLedMode){
			brush.CreateSolidBrush(RGB(255,255,255));//WHITE
		}else{
			brush.CreateSolidBrush(color.m_UnknownClr);
		}
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}
	pWnd = GetDlgItem(IDC_SUBINFO_DISPLAY_BAD_COLOR);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		CBrush brush;
		ScreenToClient(&rect);
		if(m_bLedMode){
			brush.CreateSolidBrush(RGB(255,0,0));//RED
		}else{
			brush.CreateSolidBrush(color.m_BadClr);
		}
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}
	pWnd = GetDlgItem(IDC_SUBINFO_DISPLAY_GOOD_COLOR);
	if(pWnd != NULL) {
		pWnd->GetWindowRect(rect);
		ScreenToClient(&rect);
		if(m_bLedMode){
			brush.CreateSolidBrush(RGB(0,255,0));//GREEN
		}else{
			brush.CreateSolidBrush(color.m_GoodClr);
		}
		dc.SelectObject(&brush);
		dc.Rectangle(rect);
	}
	pWnd = GetDlgItem(IDC_SUBINFO_DISPLAY_FAIL_COLOR);
	if(pWnd != NULL) {
		if(m_bLedMode){
			pWnd->ShowWindow(SW_HIDE);
		}else{
			pWnd->GetWindowRect(rect);
			ScreenToClient(&rect);
			CBrush brush(color.m_FailClr);
			dc.SelectObject(&brush);
			dc.Rectangle(rect);
		}
	}
	pWnd = GetDlgItem(IDC_SUBINFO_DISPLAY_DONE_COLOR);
	if(pWnd != NULL) {
		if(m_bLedMode){
			pWnd->ShowWindow(SW_HIDE);
		}else{
			pWnd->GetWindowRect(rect);
			ScreenToClient(&rect);
			CBrush brush(color.m_DoneClr);
			dc.SelectObject(&brush);
			dc.Rectangle(rect);
		}
	}
	pWnd = GetDlgItem(IDC_SUBINFO_DISPLAY_NOTDONE_COLOR);
	if(pWnd != NULL) {
		if(m_bLedMode){
			pWnd->ShowWindow(SW_HIDE);
		}else{
			pWnd->GetWindowRect(rect);
			ScreenToClient(&rect);
			CBrush brush(color.m_NotDoneClr);
			dc.SelectObject(&brush);
			dc.Rectangle(rect);
		}
	}
	pWnd = GetDlgItem(IDC_SUBINFO_DISPLAY_STACK_COLOR);
	if(pWnd != NULL) {
		if(m_bLedMode){
			pWnd->ShowWindow(SW_HIDE);
		}else{
			pWnd->GetWindowRect(rect);
			ScreenToClient(&rect);
			CBrush brush(color.m_StackClr);
			dc.SelectObject(&brush);
			dc.Rectangle(rect);
		}
	}
	pWnd = GetDlgItem(IDC_SUBINFO_DISPLAY_DONTNEED_COLOR);
	if(pWnd != NULL) {
		if(m_bLedMode){
			pWnd->ShowWindow(SW_HIDE);
		}else{
			pWnd->GetWindowRect(rect);
			ScreenToClient(&rect);
			CBrush brush(color.m_NoNeedClr);
			dc.SelectObject(&brush);
			dc.Rectangle(rect);
		}
	}
	//#NhamNV-170830 Draw SubInfo Display Dialog when display Led status (E)
	dc.SelectObject(pOlBrush);
	dc.SelectObject(pOldPen);
	return;
}

/**
* Left button click to change color
*/
void CBLE_SubInfoDispDlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	if(m_bLedMode){
		return; //#NhamNV-170830 Don't change color in Led display status mode
	}
	CRect rect;
	for (int idx = 0; idx <7; idx++) {
		GetDlgItem(IDC_SUBINFO_DISPLAY_UNKNOW_COLOR + idx)->GetWindowRect(rect);
		ScreenToClient(&rect);
		if (PtInRect(&rect, point)) {
			CBLE_ColorDlg dlg;
			ClientToScreen(&rect);

			// Set choose color dialog position
			int width = GetSystemMetrics(SM_CXFULLSCREEN);
			int height = GetSystemMetrics(SM_CYFULLSCREEN);	
			if (rect.bottom + DBLE_COLORDLG_HEIGHT < height) {
				if (rect.left + DBLE_COLORDLG_WIDTH < width) {
					// LeftBottom
					dlg.SetPosition(rect.left, rect.bottom, DBLE_COLORDLG_WIDTH, DBLE_COLORDLG_HEIGHT);
				} else {
					// RightBottom
					dlg.SetPosition(rect.right - DBLE_COLORDLG_WIDTH, rect.bottom, DBLE_COLORDLG_WIDTH, DBLE_COLORDLG_HEIGHT);
				}
			} else {
				
				if (rect.left + DBLE_COLORDLG_WIDTH < width) {
					// LeftTop
					dlg.SetPosition(rect.left, rect.top - DBLE_COLORDLG_HEIGHT, DBLE_COLORDLG_WIDTH, DBLE_COLORDLG_HEIGHT);
				} else {
					// RightTop
					dlg.SetPosition(rect.right - DBLE_COLORDLG_WIDTH, rect.top - DBLE_COLORDLG_HEIGHT, DBLE_COLORDLG_WIDTH, DBLE_COLORDLG_HEIGHT);
				}
			}
			if (dlg.DoModal() == IDOK) 
			{ 			
				COLORREF color = dlg.GetColor();
				//CBLE_SubInfoWnd *parent = (CBLE_SubInfoWnd *)m_pParentWnd;
				((CBLE_SubInfoWnd *)m_pParentWnd)->OnChangeColor(IDC_SUBINFO_DISPLAY_UNKNOW_COLOR + idx, color);
				OnPaint();
			}
			break;
		}
	}
}

void CBLE_SubInfoDispDlg::SetParentWindow(CWnd *parent)
{
	m_pParentWnd = parent;
}

void CBLE_SubInfoDispDlg::OnChangeDisplayMode(UINT nID)
{
	((CBLE_SubInfoWnd *)m_pParentWnd)->OnChangeDisplayMode(nID);
	CheckBtnState();
}

void CBLE_SubInfoDispDlg::CheckBtnState()
{
	// Check display buttons
	DBLE_MODE mode = ((CBLE_SubInfoWnd *)m_pParentWnd)->GetDisplayMode();
	GetDlgItem(IDC_SUBINFO_DISPLAY_DETECT_BTN)->EnableWindow(mode != DBLE_MODE_SUB_INFO_DETECT);
	GetDlgItem(IDC_SUBINFO_DISPLAY_BOND_BTN)->EnableWindow(mode != DBLE_MODE_SUB_INFO_BOND);
//	GetDlgItem(IDC_SUBINFO_DISPLAY_STACK_BTN)->EnableWindow(mode != DBLE_MODE_SUB_INFO_STACK);
	return;
}
//#NhamNV-170830(S)
void CBLE_SubInfoDispDlg::OnLedDisplaySts()
{
	//GetDlgItem(IDC_LED_LBL_DISP)->
	CString curText;
	m_ledTextSts.GetWindowText(curText);
	((CBLE_SubInfoWnd *)m_pParentWnd)->OnLedDisplaySts(m_bLedMode);
	if(m_bLedMode){
		m_ledTextSts.SetWindowText(_T("On"));
		GetDlgItem(IDC_SUBINFO_DISPLAY_DONTNEED_LB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SUBINFO_DISPLAY_NOTDONE_LB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SUBINFO_DISPLAY_FAIL_LB)->ShowWindow(SW_HIDE);
		GetDlgItem(IDC_SUBINFO_DISPLAY_DONE_LB)->ShowWindow(SW_HIDE);
	}else{
		m_ledTextSts.SetWindowText(_T("Off"));
		GetDlgItem(IDC_SUBINFO_DISPLAY_DONTNEED_LB)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SUBINFO_DISPLAY_NOTDONE_LB)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SUBINFO_DISPLAY_FAIL_LB)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_SUBINFO_DISPLAY_DONE_LB)->ShowWindow(SW_SHOW);
	}
	this->Invalidate();
	this->UpdateWindow();
	return;
}
//#NhamNV-170830(E)
// Color dialog

CBLE_ColorDlg::CBLE_ColorDlg(CWnd *pParent)
	: CColorDialog(RGB(0, 0, 0), CC_ANYCOLOR, pParent)
{
	m_Position.SetRect(0, 0, 0, 0);
}


CBLE_ColorDlg::~CBLE_ColorDlg()
{
	// Nothing
}

void CBLE_ColorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CBLE_ColorDlg, CColorDialog)
	// TODO
END_MESSAGE_MAP()

BOOL CBLE_ColorDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set window style
	if (m_hWnd != NULL) {
		LONG lStyle = GetWindowLong(m_hWnd, GWL_STYLE);
		lStyle &= ~WS_SYSMENU;
		//lStyle &= ~WS_CAPTION;
		lStyle &= ~WS_TILED;
		SetWindowLong(m_hWnd, GWL_STYLE, lStyle);
	}

	// Set window position
	SetWindowPos(&CWnd::wndBottom,
		m_Position.left, m_Position.top, m_Position.Width(), m_Position.Height(), SWP_NOZORDER);
	
	// Set window title
	SetWindowText(DBLE_COLORDLG_COLOR_CHOOSE_MES);
	return 0;
}

void CBLE_ColorDlg::SetPosition(int left, int top, int width, int height)
{
	m_Position.SetRect(left, top, left + width, top + height);
}

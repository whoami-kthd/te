#include "CBLE_Util.h"
#include "math.h"

#define DECISION 0.001

// FUNTIONS

// Rotate a point arround a another point
void CBLE_Util::RotatePoint(double& pX, double& pY, double centerX, double centerY, double angle)
{
	if(angle == 0.0) {
		return;
	}

	double r = angle * (PI / 180);
	double ct = cos(r);
	double st = sin(r);
	double tempX = (ct * (pX - centerX) - st * (pY - centerY)) + centerX;
	double tempY = (st * (pX - centerX) + ct * (pY - centerY)) + centerY;

	pX = tempX;
	pY = tempY;
}


// Round a float number
int CBLE_Util::Round(double number)
{
	return int(number + 0.5);
}

// Scale a point
CPoint CBLE_Util::ScalePoint(CPoint point, double scale)
{
	return CPoint(Round(point.x*scale), Round(point.y*scale));
}

R2Pos CBLE_Util::ScaleR2Point(CPoint point, double scale)
{
	return R2Pos(point.x*scale, point.y*scale);
}

// Scale a size
CSize CBLE_Util::ScaleSize(CSize size, double scale)
{
	return CSize(Round(size.cx*scale), Round(size.cy*scale));
}

// Scale a rectangle
void CBLE_Util::ScaleR2Rect(CRect rect, double scale, vector<R2Pos> &rectPoint)
{
	R2Pos temp = ScaleR2Point(rect.TopLeft(), scale);
	rectPoint.push_back(temp);

	temp = ScaleR2Point(CPoint(rect.TopLeft().x+rect.Width(), rect.TopLeft().y), scale);
	rectPoint.push_back(temp);

	temp = ScaleR2Point(rect.BottomRight(), scale);
	rectPoint.push_back(temp);

	temp = ScaleR2Point(CPoint(rect.BottomRight().x - rect.Width(), rect.BottomRight().y), scale);
	rectPoint.push_back(temp);
}

// Check overlap for 2 polygons
bool CBLE_Util::CheckOverlap(vector<R2Pos> vPnt1, vector<R2Pos> vPnt2)
{
	// Check all points of polygon 1
	int pnt1Size = vPnt1.size();
	for(UINT idx = 0; idx < pnt1Size; idx ++){
		if(!PointInPolygon(vPnt1[idx], vPnt2)) continue;
		return true;
	}
	int pnt2Size = vPnt2.size();
	// Check all points of polygon 2
	for(idx = 0; idx < pnt2Size; idx ++){
		if(!PointInPolygon(vPnt2[idx], vPnt1)) continue;
		return true;
	}

	// Check all edges of 2 polygons
	vPnt1.push_back(vPnt1[0]);
	vPnt2.push_back(vPnt2[0]);
	for(UINT idx1 = 0; idx1 < 4; idx1 ++){
		for(UINT idx2 = 0; idx2 < 4; idx2 ++){
			if(CheckIntersect(vPnt1[idx1], vPnt1[idx1 + 1], vPnt2[idx], vPnt2[idx2 + 1])) 
				return true;
		}
	}

	return false;
}

// Check intersect of 2 lines
// Line1: p1, p2
// Line2: p3, p4
bool CBLE_Util::CheckIntersect(R2Pos p1, R2Pos p2, R2Pos p3, R2Pos p4)
{
	double x1 = p1.x, x2 = p2.x, x3 = p3.x, x4 = p4.x;
    double y1 = p1.y, y2 = p2.y, y3 = p3.y, y4 = p4.y;

	//This is the determinant to calculate intersect point of two line
	double d = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);

	//if d == 0 then two lines are parallel
	if (d == 0) {
		return false;
	}
	//Calculate the intersect point only if d!= 0
	double pre = (x1 * y2 - y1 * x2), pos = (x3 * y4 - y3 * x4);
	double x = ( pre * (x3 - x4) - (x1 - x2) * pos ) / d;
	double y = ( pre * (y3 - y4) - (y1 - y2) * pos ) / d;

    // Check if the x and y coordinates are within both lines
    if ( x < min(x1, x2) || x > max(x1, x2) ||
			x < min(x3, x4) || x > max(x3, x4) ) {
		return false;
	}

    if ( y < min(y1, y2) || y > max(y1, y2) ||
            y < min(y3, y4) || y > max(y3, y4) ) {
		return false;
	}
	
	return true;
}


// Check a point is in the region of a polygon or not
bool CBLE_Util:: PointInPolygon(R2Pos point, vector<R2Pos> &vPoly)
{
	//Calculate area of four triangles and polygon
	// 1st triangle
	double triangle1 = TriangleArea(SegmentLength(point, vPoly[0]), SegmentLength(point, vPoly[1]), SegmentLength(vPoly[0], vPoly[1]));

	// 2nd triangle
	double triangle2 = TriangleArea(SegmentLength(point, vPoly[1]), SegmentLength(point, vPoly[2]), SegmentLength(vPoly[1], vPoly[2]));

	// 3rd triangle
	double triangle3 = TriangleArea(SegmentLength(point, vPoly[2]), SegmentLength(point, vPoly[3]), SegmentLength(vPoly[2], vPoly[3]));

	// 4th triangle
	double triangle4 = TriangleArea(SegmentLength(point, vPoly[3]), SegmentLength(point, vPoly[0]), SegmentLength(vPoly[0], vPoly[3]));

	// Polygon
	double polygon = TriangleArea(SegmentLength(vPoly[0], vPoly[1]), SegmentLength(vPoly[2], vPoly[1]), SegmentLength(vPoly[0], vPoly[2])) + 
					 TriangleArea(SegmentLength(vPoly[0], vPoly[2]), SegmentLength(vPoly[2], vPoly[3]), SegmentLength(vPoly[0], vPoly[3]));
	if (DoubleComparison(triangle1 + triangle2 + triangle3 + triangle4, polygon)) {
		return true;
	} else {
		return false;
	}
}

// Compare two double number
bool CBLE_Util::DoubleComparison(double a, double b)
{
	double diff = a - b;
	if (fabs(diff) < DECISION) {
		return true;
	} else {
		return false;
	}
}

// Calculate triangle area
double CBLE_Util::TriangleArea(double a, double b, double c)
{
	if (((a + b) > c) && ((c + b) > a) && ((a + c) > b)) {
		double p = (a+b+c) / 2;
		return sqrt(p * (p-a) * (p-b) * (p-c));
	} else {
		return 0;
	}
}

// Calculate length of line segment
double CBLE_Util::SegmentLength(R2Pos point1, R2Pos point2)
{
	return sqrt((point1.x - point2.x) * (point1.x - point2.x) + (point1.y - point2.y) * (point1.y - point2.y));
}

// Convert from R2Pos to CPoint
void CBLE_Util::R2PosToCPoint(vector<R2Pos> point1, vector<CPoint> &point2)
{
	int size =  point1.size();
	for (UINT idx = 0; idx < size; idx++) {
		point2.push_back( CPoint(CBLE_Util::Round(point1[idx].x), CBLE_Util::Round(point1[idx].y)));
	}
}

// Change coordinate of the layout window
void CBLE_Util::ChangeCoordinate(vector<R2Pos> &vPoint)
{
	int size =  vPoint.size();
	for (UINT idx = 0; idx < size; idx ++) {
		//vPoint[idx].x = vPoint[idx].x * (-1);
		vPoint[idx].y = vPoint[idx].y * (-1);
	}
}

void CBLE_Util::SaveWindowPlace(CWnd* pWnd, CString appName, CString dialogName)
{
	WINDOWPLACEMENT wp;
    pWnd->GetWindowPlacement(&wp);
    AfxGetApp()->WriteProfileBinary(appName, dialogName, (LPBYTE)&wp, sizeof(wp));
}

// Get window 
bool CBLE_Util::GetWindowPlace(CWnd* pWnd, CString appName, CString dialogName)
{
	WINDOWPLACEMENT *lwp;
    UINT nl;
	bool r = false;
    if(AfxGetApp()->GetProfileBinary(appName, dialogName, (LPBYTE*)&lwp, &nl))
    {
		pWnd->SetWindowPlacement(lwp);
		delete [] lwp;
		r = true;
	} 
	return r;
}
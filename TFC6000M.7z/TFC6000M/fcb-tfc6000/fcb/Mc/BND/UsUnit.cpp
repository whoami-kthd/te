// UsUnit.cpp: UsUnit �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include "MC\DEFS\UsUnit.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

UsUnit::UsUnit()
{

}

UsUnit::~UsUnit()
{

}

UsUnit::UsUnit(		CString name, 							// �f�o�b�O�p���O
					OrdinaryDAOutTBL* pVoltage,				// DA�o��
					int errId								// �G���[�h�c
					)
{
	this->name = name;

	if(pVoltage->output_no >=0){
		this->daoutVoltage.Initinstance(errId, pVoltage);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ������
BOOL UsUnit::Init()
{
	BOOL r = TRUE;
	CSingleLock	S(&MemSema, TRUE);
	{
		if(r){r = this->daoutVoltage.DAOut(0);}
	}
	return(r);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �d���w�ߒl�̎擾(CmdDASts)
double UsUnit::GetCmdVoltage()
{
	BOOL r = TRUE;
	double volt = 0.0;
	int pulse = 0;
	static CSemaphoreX Sema;
	CSingleLock S(&Sema, TRUE);

	r = this->daoutVoltage.CmdDAOutSts(pulse);
	this->US_PtoV(pulse, &volt);

	return(volt);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �d���̏o��
bool UsUnit::SetVoltage(int pulse)
{
	bool r = TRUE;
	static CSemaphoreX Sema;
	CSingleLock S(&Sema, TRUE);

	r = this->daoutVoltage.DAOut(pulse);
	if(pUsDispFunc){
		(*pUsDispFunc)(pulse);
	}

	return(r);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �d���\��
bool UsUnit::SetUsDispFunc(bool (__cdecl *pFunc)(int))
{
	pUsDispFunc = pFunc;
	return(true);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool UsUnit::US_VtoP(double volt,  int *pulse)
{
	double p = DA_MAX_COUNT / DA_MAX_VOLT;
//	if(this->voltageMax < volt){
	if(DA_MAX_VOLT < volt){
		volt = DA_MAX_VOLT;
	}
	*(pulse) = (int)(p * volt);
	return(true);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool UsUnit::US_PtoV(int pulse, double *volt)
{
	double v = DA_MAX_VOLT / DA_MAX_COUNT;
	*(volt) = v * pulse;
	return(true);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
bool UsUnit::US_DAOutFunc(double out,int step,double timeA,double timeB,int mode,bool finish)
//		out		�o�͓d���l�A�܂��̓p���X��
//		step�@�@�X�e�b�v�ԍ�	�P�`�l�����@�@�O�F�X�e�b�v�I��
//		timeA	�X�e�b�v�ݒ莞��
//		timeB	�X�e�b�v�o�ߎ���
//		mode	���[�h
//		finish	�X�e�b�v�I���t���O
//				false	������
//				true	�I��
{
	bool	r=true;
	int		Pulse=0;
	bool	Out=false;

	if (!finish) {
		if (out < 0) out = 0;
		this->US_VtoP(out, &Pulse);					// �d�����p���X���ɕϊ�
		Out = (out) ? true : false;
	}
	if (this->SetVoltage(Pulse)) {
		r = false;
	}

	return r;
}



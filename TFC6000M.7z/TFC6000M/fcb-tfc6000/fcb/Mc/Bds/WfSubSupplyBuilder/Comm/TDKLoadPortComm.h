// TDKLoadPortComm.h: interface for the TDKLoadPortComm class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TDKLOADPORTCOMM_H__730990C7_60F1_48A8_BC4B_CD5CBD3AF0B5__INCLUDED_)
#define AFX_TDKLOADPORTCOMM_H__730990C7_60F1_48A8_BC4B_CD5CBD3AF0B5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "PortComm.h"

class TDKLoadPortComm  
{
public:
	TDKLoadPortComm();
	virtual ~TDKLoadPortComm();
	
	#define	LP_SLOT_MAX					25		// Load port max slot number
	#define LP_TDK_RECEIVE_MIN_SIZE		16
	struct	LP_EVENTDATA {				// Event data (INF, ABS)
		long	kind;					// Event kind
		char	command[5];				// Command
		char	parameter[5];			// Parameter
	}; // s_evData;
	
	struct	LP_ANSWERDATA {				// Answer data (ACK, NAK)
		long	kind;					// Kind of answer
		char	command[5];				// Command
		char	error[11];				// Error (extend error /AAAAA/BBBBB)
		union ASDATA {
			char	version[12];		// GET:VERSN answer
			int 	ledStatus[13];		// GET:LEDST answer
			char	stateLP[20];		// GET:STATE answer
			int 	mapInfo[25];		// GET:MAPDT answer
			int 	mapInfoR[25];		// GET:MAPRD answer
			int		waferNo;			// GET:WFCNT answer
			char	NAKError[11];		// NAK parameter
		} u_asdata;
	}; // s_asData;
	
	enum LoadPortCommand {
		Cmd_SET_RESET	 = 1,
		Cmd_SET_INITL,
		Cmd_SET_LPLOD,
		Cmd_SET_BLLOD,
		Cmd_SET_LOLOD,
		Cmd_SET_LPULD,
		Cmd_SET_BLULD,
		Cmd_SET_LOULD,
		Cmd_SET_LPMSW,
		Cmd_SET_BLMSW,
		Cmd_SET_LOMSW,
		Cmd_SET_LPCON,
		Cmd_SET_BLCON,
		Cmd_SET_LOCON,
		Cmd_SET_LPCST,
		Cmd_SET_BLCST,
		Cmd_SET_LOCST,
		Cmd_SET_LON07,
		Cmd_SET_LBL07,
		Cmd_SET_LOF07,
		Cmd_SET_LON08,
		Cmd_SET_LBL08,
		Cmd_SET_LOF08,
		
		Cmd_MOD_ONMGV,
		Cmd_MOD_MENTE,
		Cmd_MOD_TEACH,
		
		Cmd_GET_STATE,
		Cmd_GET_VERSN,
		Cmd_GET_LEDST,
		Cmd_GET_MAPDT,
		Cmd_GET_MAPRD,
		Cmd_GET_WFCNT,
		
		Cmd_MOV_ORGSH,
		Cmd_MOV_ABORG,
		Cmd_MOV_CLOAD,
		Cmd_MOV_CLDDK,
		Cmd_MOV_CLDYD,
		Cmd_MOV_CLDOP,
		Cmd_MOV_CLDMP,
		Cmd_MOV_CLMPO,
		Cmd_MOV_CULOD,
		Cmd_MOV_CULDK,
		Cmd_MOV_CUDCL,
		Cmd_MOV_CUDNC,
		Cmd_MOV_CULYD,
		Cmd_MOV_CULFC,
		Cmd_MOV_CUDMP,
		Cmd_MOV_CUMDK,
		Cmd_MOV_CUMFC,
		Cmd_MOV_MAPDO,
		Cmd_MOV_REMAP,
		             
		Cmd_MOV_PODOP,
		Cmd_MOV_PODCL,
		Cmd_MOV_VACON,
		Cmd_MOV_VACOF,
		Cmd_MOV_DOROP,
		Cmd_MOV_DORCL,
		Cmd_MOV_MAPOP,
		Cmd_MOV_MAPCL,
		Cmd_MOV_ZDRUP,
		Cmd_MOV_ZDRDW,
		Cmd_MOV_ZDRMP,
		Cmd_MOV_ZMPST,
		Cmd_MOV_ZMPED,
		Cmd_MOV_MSTON,
		Cmd_MOV_MSTOF,
		Cmd_MOV_YWAIT,
		Cmd_MOV_YDOOR,
		Cmd_MOV_DORBK,
		Cmd_MOV_DORFW,
		             
		Cmd_MOV_RETRY,
		Cmd_MOV_STOP_,
		Cmd_MOV_PAUSE,
		Cmd_MOV_ABORT,
		Cmd_MOV_RESUM,
	};
	
	enum LoadPortEvent {
		Event_SET_RESET		= 1,
		Event_SET_INITL,
		Event_SET_LPLOD,
		Event_SET_BLLOD,
		Event_SET_LOLOD,
		Event_SET_LPULD,
		Event_SET_BLULD,
		Event_SET_LOULD,
		Event_SET_LPMSW,
		Event_SET_BLMSW,
		Event_SET_LOMSW,
		Event_SET_LPCON,
		Event_SET_BLCON,
		Event_SET_LOCON,
		Event_SET_LPCST,
		Event_SET_BLCST,
		Event_SET_LOCST,
		Event_SET_LON07,
		Event_SET_LBL07,
		Event_SET_LOF07,
		Event_SET_LON08,
		Event_SET_LBL08,
		Event_SET_LOF08,
		            
		Event_MOV_ORGSH		= 33,
		Event_MOV_ABORG,
		Event_MOV_CLOAD,
		Event_MOV_CLDDK,
		Event_MOV_CLDYD,
		Event_MOV_CLDOP,
		Event_MOV_CLDMP,
		Event_MOV_CLMPO,
		Event_MOV_CULOD,
		Event_MOV_CULDK,
		Event_MOV_CUDCL,
		Event_MOV_CUDNC,
		Event_MOV_CULYD,
		Event_MOV_CULFC,
		Event_MOV_CUDMP,
		Event_MOV_CUMDK,
		Event_MOV_CUMFC,
		Event_MOV_MAPDO,
		Event_MOV_REMAP,
		               
		Event_MOV_PODOP,
		Event_MOV_PODCL,
		Event_MOV_VACON,
		Event_MOV_VACOF,
		Event_MOV_DOROP,
		Event_MOV_DORCL,
		Event_MOV_MAPOP,
		Event_MOV_MAPCL,
		Event_MOV_ZDRUP,
		Event_MOV_ZDRDW,
		Event_MOV_ZDRMP,
		Event_MOV_ZMPST,
		Event_MOV_ZMPED,
		Event_MOV_MSTON,
		Event_MOV_MSTOF,
		Event_MOV_YWAIT,
		Event_MOV_YDOOR,
		Event_MOV_DORBK,
		Event_MOV_DORFW,
		               
		Event_MOV_RETRY,
		Event_MOV_STOP_,
		Event_MOV_PAUSE,
		Event_MOV_ABORT,
		Event_MOV_RESUM,
		
		Event_PODON,
		Event_PODOF,
		Event_SMTON,
		Event_ABNST,
		           
		Event_MANSW,
		Event_MA2SW,
		           
		Event_MANOF,
		Event_MA2OF,
		           
		Event_POWON,
		           
		Event_FANST,
		           
		Event_ITLON,
		           
		Event_ITLOF,
		           
		Event_AIRSN,
		Event_AIRSR,
		           
		Event_PRSIN,
		Event_PRSCL,
		           
		Event_OTOON,
		Event_OTOOF,
		           
		Event_TVAON,
		Event_TVAOF,
		           
		Event_POWLO,
	};
	
	enum LoadPortNAK {
		NAK_CKSUM,
		NAK_CMDER,
		NAK_SFSER,
		NAK_INTER,
		NAK_INTER_CKSUM,
		NAK_INTER_CMDER,
		NAK_INTER_SFSER,
		NAK_INTER_CBUSY,
		NAK_INTER_FPILG,
		NAK_INTER_LATCH,
		NAK_INTER_FPCLP,
		NAK_INTER_YPOSI,
		NAK_INTER_DOCPO,
		NAK_INTER_DPOSI,
		NAK_INTER_PROTS,
		NAK_INTER_MPARM,
		NAK_INTER_ZPOSI,
		NAK_INTER_MPSTP,
		NAK_INTER_DVACM,
		NAK_INTER_ERROR,
		NAK_INTER_ORGYT,
		NAK_INTER_CLDDK,
		NAK_INTER_CULDK,
		NAK_INTER_CLOAD,
		NAK_INTER_RMPOS
	};
	

private:
	// Comm port setting
	BOOL	CommSetting();		
	// Communication receive thread
	static	UINT	CommRecv(LPVOID pParam);
	// Make command string function
	int		MakeCommandString(int CmdCode, char* CommandLine, bool retry);
	// Parse reply message
	int		AnalizeReceiveData(char* recvD, int length);
	// Send command to Load port and wait for reply 
	int		Send(char* CommandLine);
	
	int		WaitForAnswer(int cmdNo);
	
	int		WaitForEvent(int eventNo);
	// De-queue the event when finish
	void	DequeueFromAnswerQueue(int cmdNo);
	void	DequeueFromEventQueue(int eventNo);
	// Set answer object
	bool	SetAnswerObject(int cmdNo, CEvent* evOK, CEvent* evNG, LP_ANSWERDATA *ansData);
	// Set event object 
	bool	SetEventObject(int eventNo, CEvent* evOK, CEvent* evNG, LP_EVENTDATA *evData);
	// Check sum calculator
	bool 	RecvChecksumCalculator(char* data, int length, bool hasToCheck);
	bool 	SendChecksumCalculator(CString data, char& CSH, char& CSI);
	
	// Get the error code
	int 	GetErrorCode(bool event, int cmdNo = -1);
	
	// Load port max event queue
	#define	LP_EVENT_QMAX	10
	#define	LP_ANSWER_QMAX	10
	struct	LP_EVENT_QUEUE	{
		int EventNum;
		CEvent*	pEventObjOK;
		CEvent*	pEventObjNG;
		struct LP_EVENTDATA* eventData;
	} lp_event_q[LP_EVENT_QMAX];
	
	struct	LP_ANSWER_QUEUE	{
		int CmdNum;
		CEvent*	pEventObjOK;
		CEvent*	pEventObjNG;
		struct LP_ANSWERDATA* ansData;
	} lp_reply_q[LP_ANSWER_QMAX];
public:
	// End communication
	BOOL	CommEnd();
	// Set communication port parameter
	void	SetCommPara( CString ComPort, int boudrate, int databit, int stopbit, int parity, int evenodd );
	// Open communication port
	BOOL	OpenComm();				// Open Comm port
	// Close communication port
	BOOL	CloseComm();			// Close Comm port
		
	bool	SetEventEventObject( CEvent *evObj, struct LP_EVENTDATA *evData );
private:
	// Notify event when receive answer
	CEvent*	evANSWER;
	// Notify event when receive event
	CEvent*	evEVENT;
	// Receive thread pointer 
	CWinThread	*pRThread;
	// Receive thread handle
	HANDLE	m_hCommRThread;
	
	#define	LP_EVENT_TIMEOUT	30000		// Timeout for event 
	CEvent	eventFINISH;					// Event finish command
	#define	LP_REPLY_TIMEOUT	10000		// Timeout for reply (ACK, NAK)
	CEvent	eventAnswer;	
	
	struct LP_EVENTDATA *pEventData;
	struct LP_ANSWERDATA *pAnswerData;
	
	enum	{
		STARTHEADER = 0x01,
		STARTCHAR1	= 'A',
		STARTCHAR2	= 'I',
		STARTCHAR3	= 'N',
		STARTCHAR4	= 'R',
		TERMCHAR1	= 0x0D,
		TERMCHAR2	= 0x0A,
		TERMCHAR3	= 0x03
	};
	
	enum	{
		RcvERROR	= 0,
		RcvANSWER	= 1,
		RcvEVENT	= 2
	};	
public:
	// Communication port object
	CPortComm PortComm;			
	
	// Set command 
	int SendLoadPort_SET_RESET();
	int SendLoadPort_SET_INITL();
	int SendLoadPort_SET_LPLOD();
	int SendLoadPort_SET_BLLOD();
	int SendLoadPort_SET_LOLOD();
	int SendLoadPort_SET_LPULD();
	int SendLoadPort_SET_BLULD();
	int SendLoadPort_SET_LOULD();
	int SendLoadPort_SET_LPMSW();
	int SendLoadPort_SET_BLMSW();
	int SendLoadPort_SET_LOMSW();
	int SendLoadPort_SET_LPCON();
	int SendLoadPort_SET_BLCON();
	int SendLoadPort_SET_LOCON();
	int SendLoadPort_SET_LPCST();
	int SendLoadPort_SET_BLCST();
	int SendLoadPort_SET_LOCST();
	int SendLoadPort_SET_LON07();
	int SendLoadPort_SET_LBL07();
	int SendLoadPort_SET_LOF07();
	int SendLoadPort_SET_LON08();
	int SendLoadPort_SET_LBL08();
	int SendLoadPort_SET_LOF08();	
	
	// Mode command
	int SendLoadPort_MOD_ONMGV();
	int SendLoadPort_MOD_MENTE();
	int SendLoadPort_MOD_TEACH();
	
	// Get command
	int SendLoadPort_GET_STATE(LP_ANSWERDATA* ansData);
	int SendLoadPort_GET_VERSN();
	int SendLoadPort_GET_LEDST();
	int SendLoadPort_GET_MAPDT(LP_ANSWERDATA* ansData);
	int SendLoadPort_GET_MAPRD(LP_ANSWERDATA* ansData);
	int SendLoadPort_GET_WFCNT();
	
	// Move command
	// Complex command
	int SendLoadPort_MOV_ORGSH();
	int SendLoadPort_MOV_ABORG();
	int SendLoadPort_MOV_CLOAD();
	int SendLoadPort_MOV_CLDDK();
	int SendLoadPort_MOV_CLDYD();
	int SendLoadPort_MOV_CLDOP();
	int SendLoadPort_MOV_CLDMP();
	int SendLoadPort_MOV_CLMPO();
	int SendLoadPort_MOV_CULOD();
	int SendLoadPort_MOV_CULDK();
	int SendLoadPort_MOV_CUDCL();
	int SendLoadPort_MOV_CUDNC();
	int SendLoadPort_MOV_CULYD();
	int SendLoadPort_MOV_CULFC();
	int SendLoadPort_MOV_CUDMP();
	int SendLoadPort_MOV_CUMDK();
	int SendLoadPort_MOV_CUMFC();
	int SendLoadPort_MOV_MAPDO();
	int SendLoadPort_MOV_REMAP();
	// Simplex command
	int SendLoadPort_MOV_PODOP();
	int SendLoadPort_MOV_PODCL();
	int SendLoadPort_MOV_VACON();
	int SendLoadPort_MOV_VACOF();
	int SendLoadPort_MOV_DOROP();
	int SendLoadPort_MOV_DORCL();
	int SendLoadPort_MOV_MAPOP();
	int SendLoadPort_MOV_MAPCL();
	int SendLoadPort_MOV_ZDRUP();
	int SendLoadPort_MOV_ZDRDW();
	int SendLoadPort_MOV_ZDRMP();
	int SendLoadPort_MOV_ZMPST();
	int SendLoadPort_MOV_YWAIT();
	int SendLoadPort_MOV_YDOOR();
	int SendLoadPort_MOV_DORBK();
	int SendLoadPort_MOV_DORFW();
	// Control command
	int SendLoadPort_MOV_RETRY();
	int SendLoadPort_MOV_STOP_();
	int SendLoadPort_MOV_PAUSE();
	int SendLoadPort_MOV_ABORT();
	int SendLoadPort_MOV_RESUM();

	enum LoadPortError	{
		Err_None		= 0x0001,		// �����G���[�R�[�h�F����
		Err_InvalidCmd	= 0xffff,		// �����G���[�R�[�h�F�s���ȃR�}���h
		Err_RTimeOut	= 0xfffd,		// �����G���[�R�[�h�F�����^�C���A�E�g
		Err_ETimeOut	= 0xfffc,		// �����G���[�R�[�h�F���슮���^�C���A�E�g
		Err_SendError	= 0xfffb,		// �����G���[�R�[�h�F���M�G���[

		Err0x02			= 0x02,			// Z axis failure (down)
		Err0x04			= 0x04,			
		Err0x07			= 0x07,
		Err0x08			= 0x08,
		Err0x09			= 0x09,
		Err0x12			= 0x12,
		Err0x21			= 0x21,
		Err0x22			= 0x22,
		Err0x23			= 0x23,
		Err0x24			= 0x24,
		Err0x25			= 0x25,
		Err0x26			= 0x26,
		Err0x27			= 0x27,
		Err0xA1			= 0xA1,
		Err0xA2			= 0xA2,
		Err0xA3			= 0xA3,
		Err0xA4			= 0xA4,
		Err0xEE			= 0xEE,
		Err0xFD			= 0xFD,
		Err0xFE			= 0xFE,
		Err0xFF			= 0xFF,
		Err0xFC			= 0xFC,
		Err0xEF			= 0xEF,
		Err0x31			= 0x31,
		Err0xF1			= 0xF1,
		Err0x42			= 0x42,
		Err0x44			= 0x44,
		Err0x47			= 0x47,
		Err0x48			= 0x48,
		Err0x49			= 0x49,

		Err_CKSUM		= 0x0100,
		Err_CMDER		= 0x0200,
		Err_SFSER		= 0x0300,
		Err_INTER		= 0x0400,

		Err_INTER_CKSUM	= 0x0500,
		Err_INTER_CMDER	= 0x0600,
		Err_INTER_SFSER	= 0x0700,
		Err_INTER_CBUSY	= 0x0800,
		Err_INTER_FPILG	= 0x0900,
		Err_INTER_LATCH	= 0x0A00,
		Err_INTER_FPCLP	= 0x0B00,
		Err_INTER_YPOSI	= 0x0C00,
		Err_INTER_DOCPO	= 0x0D00,
		Err_INTER_DPOSI	= 0x0E00,
		Err_INTER_PROTS	= 0x0F00,
		Err_INTER_MPARM	= 0x1000,
		Err_INTER_ZPOSI	= 0x2000,
		Err_INTER_MPSTP	= 0x3000,
		Err_INTER_DVACM	= 0x4000,
		Err_INTER_ERROR	= 0x5000,
		Err_INTER_ORGYT	= 0x6000,
		Err_INTER_CLDDK	= 0x7000,
		Err_INTER_CULDK	= 0x8000,
		Err_INTER_CLOAD	= 0x9000,
		Err_INTER_RMPOS	= 0xA000,
	};
};

#endif // !defined(AFX_TDKLOADPORTCOMM_H__730990C7_60F1_48A8_BC4B_CD5CBD3AF0B5__INCLUDED_)




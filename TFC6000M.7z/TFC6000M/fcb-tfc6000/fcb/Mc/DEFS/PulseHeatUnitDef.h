/*---------------------------------------------------------------------
	PulseHeatUnit I/O ��`
								2009.09.25 Toshiyuki Takahashi
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
//***************************************************************************
//	�Z���T�A�h���X�֘A
//***************************************************************************

//todo DINTBL_DummyA�����͌�ɐ������l�����蓖�Ă邱�ƁB

//***************************************************************************
//	�q�[�^�֘A
//***************************************************************************
#define	IO_HeaterAuto_OUT						DOUTTBL_96			// Auto/Manual(ON:Manual OFF:Auto)
#define	IO_HeaterPID2_ON_OUT					DOUTTBL_97			// PID�M��2
#define	IO_HeaterRun_OUT						DOUTTBL_98			// Ready/Run(ON:Ready OFF:Run�j
#define	IO_HeaterRemote_OUT						DOUTTBL_99			// Remote/Local(ON:Remote OFF:Local)
#define	IO_HeaterPID3_ON_OUT					DOUTTBL_100			// PID�M��3
#define	IO_HeaterPID1_ON_OUT					DOUTTBL_101			// PID�M��1

#define	IO_HeaterToolCoolBlow_ON_OUT			DINTBL_DummyA		// Heater ToolCoolBlow ON �o��

#define	IO_Heater_Breakage_SNS_IN				DINTBL_112			// ˰��f��
#define	IO_Heater_Controller_Defect_SNS_IN		DINTBL_113			// ������ُ�
#define	IO_HeaterRun_SNS_IN						DINTBL_114			// Ready/Run(ON:Ready OFF:Run�j
#define	IO_Heater_Defect_SNS_IN					DINTBL_115			// ���x�ُ�
#define	IO_HeaterRemote_SNS_IN					DINTBL_116			// Local/Remote(ON:Remote OFF:Local)
#define	IO_HeaterAuto_SNS_IN					DINTBL_117			// Manual(ON:Manual OFF:Auto)


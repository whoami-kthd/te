%% ConvertCANData
% �T�v�Fcsv��CAN�f�[�^����ݒ�t�@�C���ɂ���͂��s��
%      ��͂�����̃f�[�^�͑S��10�i���ŒP�ʂ�ϊ��������̂Ƃ���
%      �f�[�^�������ꍇ�A100���s���Ə���������A�����������̌��ʂ��o�͂���B
%                       ���̏ꍇ�̃t�@�C�����͘A�ԂƂ���B
% �ݒ�t�@�C���FConvertCANPacketSetting.xlsx
%�@�@�@�@�@�@�@ ���O�ύX���Ȃ��ł��������B
%              �ŏ���CAN�p�P�b�g�͕K��ff7c�Ƃ��Ă��������B
% �p�����[�^�F
%           file_full_name�F���̓t�@�C���p�X + �t�@�C����
%                           Matlab�̌��݃J�����g�f�B���N�g���ɂ���΁A�t�@�C�����݂̂ŗǂ��B
%           out_file_name�F�o�̓t�@�C����
%                           �g���q�𔲂��ē��͂��Ă��������B
%           Data_is_Dec�F
%                  �E1: csv�̃f�[�^��10�i���̏ꍇ
%                  �E0: csv�̃f�[�^��16�i���̏ꍇ
% �߂�l�F�Ȃ�
function ConvertCANData(file_full_name, out_file_name, Data_is_Dec)
global bar;

% �e�X�g�p
%     file_full_name = '2018-03-07_13-35-28.csv';
%     out_file_name = 'Output_2018-03-07_13-35-28';
%     Data_is_Dec = 0;
    %% �w�肳�ꂽ�o�̓t�@�C���������̏ꍇ�A�폜
    delete([out_file_name '*' '.xlsx']);

    %% �ێ����Ă����ő发�����ݍs�����w��
    MaxKeepRows = 100000;
    
    %% �ϊ�����CAN�p�P�b�g�����擾����B
    [~,~,setting_info] = xlsread('ConvertCANPacketSetting.xlsx', 'Setting');
    % �ϊ�����CAN�p�P�b�g��񂪕s���̏ꍇ�A������~
    if size(setting_info, 1) < 2 || size(setting_info, 2) < 9
        msgbox('�ϊ�����CAN�p�P�b�g��񂪕s��');
        return;
    end
    write_sheet_name_lst = setting_info(2:end,1);
    write_sheet_name_lst = unique(write_sheet_name_lst, 'stable');
    
    signal_PGN_lst = setting_info(2:end,3);
    for i = length(signal_PGN_lst):-1:1
        try
            if isnumeric(signal_PGN_lst{i})
                signal_PGN_lst{i} = num2str(signal_PGN_lst{i});
                setting_info{i+1, 3} = num2str(signal_PGN_lst{i});
            end
        catch
            % �G���[��������ꍇ�A�v�f���폜����B
            signal_PGN_lst(i) = [];
            setting_info(i+1, :) = [];
        end
    end
    signal_PGN_lst = unique(signal_PGN_lst, 'stable');
    if Data_is_Dec == 1
        signal_PGN_lst = hex2dec(signal_PGN_lst);
        signal_PGN_lst = num2cell(signal_PGN_lst);
    end
    %% �ϐ������������܂��B
    delimiter = ',';

    %% �f�[�^�̗�𕶎���Ƃ��ēǂݎ��:
    % �ڍׂ� TEXTSCAN �̃h�L�������e�[�V�������Q�Ƃ��Ă��������B
    formatSpec = '%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%[^\n\r]';

    %% ���̓t�@�C�����J���܂��B
    fileID = fopen(file_full_name,'r');
    try
        k = 0;
        header_length = 9;
        write_excel_count = 0;
        read_cnt = 0;
        write_cnt = zeros(size(signal_PGN_lst));
        MaxReadRows = 50000;
        all_data_result = {};
        signal_row = zeros(size(signal_PGN_lst));
       %% ���̓t�@�C����MaxReadRows�s���ƂɃf�[�^�ǂݍ���ŁACAN�p�P�b�g��͂��s��
        while ~feof(fileID)
            k = k + 1;
            read_cnt = read_cnt + 1;
            if k == 1
                ProcessBar('Processing Start', 0, 1, 0);
            end
            if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                delete(bar);
                fclose(fileID);
              %% �r���ɏ������f���A��͂����f�[�^��ۑ����邩�ǂ����m�F���A�ۑ�����B
                if k > 1 && ~isempty(all_data_result)
                    selectButton = questdlg('Do you want to write processed info at current?', 'QUESTION', 'Yes', 'No', 'Yes');
                    if ~isempty(selectButton) && strcmp(selectButton, 'Yes')
                        WriteInfo(write_sheet_name_lst, all_data_result, write_excel_count, out_file_name);
                    end
                end
                return;
            end
            percent = (k-1)/k;                
           %% �f�[�^�̗������������ɏ]���ēǂݎ��܂��B
            % ���̌Ăяo���́A���̃R�[�h�̐����Ɏg�p���ꂽ�t�@�C���̍\���Ɋ�Â��Ă��܂��B�ʂ̃t�@�C���ŃG���[����������ꍇ�́A�C���|�[�g
            % �c�[������R�[�h�̍Đ��������݂Ă��������B
            org_data = textscan(fileID, formatSpec, MaxReadRows, 'Delimiter', delimiter,  'ReturnOnError', false);
            %org_data = textscan(fileID, formatSpec, endRow-startRow+1, 'Delimiter', delimiter, 'HeaderLines', startRow-1, 'ReturnOnError', false);
            % CAN�f�[�^���s��(��< 16 OR �s�� < 9)�̏ꍇ�A������~
            if k == 1
                if size(org_data, 2) < 16 || size(org_data{1}, 1) < header_length
                    msgbox('CAN�f�[�^���s��(��< 16 OR �s�� < %d)�̏ꍇ�A������~',header_length);
                    return;
                end
            end

            if k == 1
                start_index = header_length;
            else
                start_index = 1;
            end

            % org_data{1}:Time
            org_data_Time = org_data{1};
            org_data_Time = org_data_Time(start_index:end,:);

            ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', (k-1) * MaxReadRows, length(org_data_Time) + (k-1) * MaxReadRows), percent, 0, 0);
            
            % org_data{3}:PGN
            org_data_PGN = org_data{3};
            org_data_PGN = org_data_PGN(start_index:end,:);

            % org_data{6}:Data0
            org_data_Data0 = org_data{6};
            org_data_Data0 = org_data_Data0(start_index:end,:);

            % org_data{7}:Data1
            org_data_Data1 = org_data{7};
            org_data_Data1 = org_data_Data1(start_index:end,:);

            % org_data{8}:Data2
            org_data_Data2 = org_data{8};
            org_data_Data2 = org_data_Data2(start_index:end,:);

            % org_data{9}:Data3
            org_data_Data3 = org_data{9};
            org_data_Data3 = org_data_Data3(start_index:end,:);

            % org_data{10}:Data4
            org_data_Data4 = org_data{10};
            org_data_Data4 = org_data_Data4(start_index:end,:);

            % org_data{11}:Data5
            org_data_Data5 = org_data{11};
            org_data_Data5 = org_data_Data5(start_index:end,:);

            % org_data{12}:Data6
            org_data_Data6 = org_data{12};
            org_data_Data6 = org_data_Data6(start_index:end,:);

            % org_data{13}:Data7
            org_data_Data7 = org_data{13};
            org_data_Data7 = org_data_Data7(start_index:end,:);
            
            org_data_DLC = org_data{5};
            org_data_DLC = org_data_DLC(start_index:end,:);

            processed_data_pgn_count = 0;
            
            for i = 1: size(signal_PGN_lst, 1)
                if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                    delete(bar);
                    fclose(fileID);
                  %% �r���ɏ������f���A��͂����f�[�^��ۑ����邩�ǂ����m�F���A�ۑ�����B
                    if k > 1 && ~isempty(all_data_result)
                        selectButton = questdlg('Do you want to write processed info at current?', 'QUESTION', 'Yes', 'No', 'Yes');
                        if ~isempty(selectButton) && strcmp(selectButton, 'Yes')
                            WriteInfo(write_sheet_name_lst, all_data_result, write_excel_count, out_file_name);
                        end
                    end
                    return;
                end
                
                %% �o�̓t�@�C���ɐV�K�V�[�g���쐬
                if read_cnt == 1
                    if write_excel_count == 0
                        xlswrite([ out_file_name '.xlsx'], cellstr('No Data'), write_sheet_name_lst{i});
                    else
                        xlswrite([ out_file_name sprintf('_%2d', write_excel_count+1) '.xlsx'], cellstr('No Data'), write_sheet_name_lst{i}); 
                    end
                end
                
                header_data = {};
                signal_data_list = {};
                if Data_is_Dec == 1
                    PGN_Index = find(strcmp(lower(dec2hex(signal_PGN_lst{i})), setting_info(:,3)));
                    % find data index
                    data_index = find(strcmp(num2str(signal_PGN_lst{i}), org_data_PGN));
                else
                    PGN_Index = find(strcmp(signal_PGN_lst{i}, setting_info(:,3)));
                    % find data index
                    data_index = find(strcmp(signal_PGN_lst{i}, org_data_PGN));
                end
                
                try
                    processed_data_pgn_count = processed_data_pgn_count + length(data_index);
                    ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', ...
                              (k-1) * MaxReadRows + processed_data_pgn_count, length(org_data_Time) + (k-1) * MaxReadRows), percent, 0, 0);
                catch
                end
                if isempty(data_index)
                    if read_cnt == 1
                        all_data_result{i} = {};
                    end
                    if  i == size(signal_PGN_lst, 1)
                        clear('org_data_PGN');
                        clear('org_data_Data0');
                        clear('org_data_Data1');
                        clear('org_data_Data2');
                        clear('org_data_Data3');
                        clear('org_data_Data4');
                        clear('org_data_Data5');
                        clear('org_data_Data6');
                        clear('org_data_Data7');
                    end
                    continue;
                end
                try
                    org_data_DLC_num = org_data_DLC{data_index(1)};
                catch
                    sprintf('Test');
                end
                try
                    org_data_DLC_num = str2num(org_data_DLC_num);
                catch
                    org_data_DLC_num = 0;
                end
                if org_data_DLC_num == 0
                    if read_cnt == 1
                        all_data_result{i} = {};
                    end
                    if  i == size(signal_PGN_lst, 1)
                        clear('org_data_PGN');
                        clear('org_data_Data0');
                        clear('org_data_Data1');
                        clear('org_data_Data2');
                        clear('org_data_Data3');
                        clear('org_data_Data4');
                        clear('org_data_Data5');
                        clear('org_data_Data6');
                        clear('org_data_Data7');
                    end
                    continue;
                end
                % Data0�`Data7
                if Data_is_Dec == 1
                    if org_data_DLC_num >= 1
                        bin_org_data_Data0 = dec2bin(str2double(org_data_Data0(data_index)), 8);
                    else
                        bin_org_data_Data0 = dec2bin(zeros(length(data_index), 1), 8);
                    end
                    if org_data_DLC_num >= 2
                        bin_org_data_Data1 = dec2bin(str2double(org_data_Data1(data_index)), 8);
                    else
                        bin_org_data_Data1 = dec2bin(zeros(length(data_index), 1), 8);
                    end
                    if org_data_DLC_num >= 3
                        bin_org_data_Data2 = dec2bin(str2double(org_data_Data2(data_index)), 8);
                    else
                        bin_org_data_Data2 = dec2bin(zeros(length(data_index), 1), 8);
                    end
                    if org_data_DLC_num >= 4
                        bin_org_data_Data3 = dec2bin(str2double(org_data_Data3(data_index)), 8);
                    else
                        bin_org_data_Data3 = dec2bin(zeros(length(data_index), 1), 8);
                    end
                    if org_data_DLC_num >= 5
                        bin_org_data_Data4 = dec2bin(str2double(org_data_Data4(data_index)), 8);
                    else
                        bin_org_data_Data4 = dec2bin(zeros(length(data_index), 1), 8);
                    end
                    if org_data_DLC_num >= 6
                        bin_org_data_Data5 = dec2bin(str2double(org_data_Data5(data_index)), 8);
                    else
                        bin_org_data_Data5 = dec2bin(zeros(length(data_index), 1), 8);
                    end
                    if org_data_DLC_num >= 7
                        bin_org_data_Data6 = dec2bin(str2double(org_data_Data6(data_index)), 8);
                    else
                        bin_org_data_Data6 = dec2bin(zeros(length(data_index), 1), 8);
                    end
                    if org_data_DLC_num >= 8
                        bin_org_data_Data7 = dec2bin(str2double(org_data_Data7(data_index)), 8);
                    else
                        bin_org_data_Data7 = dec2bin(zeros(length(data_index), 1), 8);
                    end
                    signal_all_bit_data = strcat(bin_org_data_Data7, ...
                                                 bin_org_data_Data6, ...
                                                 bin_org_data_Data5, ...
                                                 bin_org_data_Data4, ...
                                                 bin_org_data_Data3, ...
                                                 bin_org_data_Data2, ...
                                                 bin_org_data_Data1, ...
                                                 bin_org_data_Data0 ...
                                                );
                else
                    signal_all_bit_data = strcat(dec2bin(hex2dec(org_data_Data7(data_index)), 8), ...
                                                dec2bin(hex2dec(org_data_Data6(data_index)), 8), ...
                                                dec2bin(hex2dec(org_data_Data5(data_index)), 8), ...
                                                dec2bin(hex2dec(org_data_Data4(data_index)), 8), ...
                                                dec2bin(hex2dec(org_data_Data3(data_index)), 8), ...
                                                dec2bin(hex2dec(org_data_Data2(data_index)), 8), ...
                                                dec2bin(hex2dec(org_data_Data1(data_index)), 8), ...
                                                dec2bin(hex2dec(org_data_Data0(data_index)), 8) ...
                                              );
                end
                if  i == size(signal_PGN_lst, 1)
                    clear('org_data_PGN');
                    clear('org_data_Data0');
                    clear('org_data_Data1');
                    clear('org_data_Data2');
                    clear('org_data_Data3');
                    clear('org_data_Data4');
                    clear('org_data_Data5');
                    clear('org_data_Data6');
                    clear('org_data_Data7');
                end
                % Time
                time_data = org_data_Time(data_index);
                for j = 1: length(PGN_Index)
                   if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                        delete(bar);
                        fclose(fileID);
                     %% �r���ɏ������f���A��͂����f�[�^��ۑ����邩�ǂ����m�F���A�ۑ�����B
                        if k > 1 && ~isempty(all_data_result)
                            selectButton = questdlg('Do you want to write processed info at current?', 'QUESTION', 'Yes', 'No', 'Yes');
                            if ~isempty(selectButton) && strcmp(selectButton, 'Yes')
                                WriteInfo(write_sheet_name_lst, all_data_result, write_excel_count, out_file_name);
                            end
                        end
                        return;
                   end
                   % �M����
                   signal_unit = setting_info{PGN_Index(j), 9};
                   if j == 1
                       header_data{end + 1, 1} = 'Time';
                       header_data{end, j + 1} = [ setting_info{PGN_Index(j), 2} '(' signal_unit ')'];

                   else
                       header_data{1, j + 1} = [ setting_info{PGN_Index(j), 2} '(' signal_unit ')'];
                   end

                   signal_startbit = setting_info{PGN_Index(j), 4};
                   signal_length = setting_info{PGN_Index(j), 5};
                   signal_sign = setting_info{PGN_Index(j), 6};
                   try
                        signal_bit_data = signal_all_bit_data(:, size(signal_all_bit_data, 2) - signal_length - signal_startbit + 1:size(signal_all_bit_data, 2) - signal_startbit);
                   catch ex
                       msgbox(ex.message);
                       return;
                   end
                   signal_data = convert_bin2dec(signal_bit_data, signal_sign);
                   try
                       if ischar(setting_info{PGN_Index(j), 7})
                           signal_offset = num2str(setting_info{PGN_Index(j), 7});
                       else
                           signal_offset = setting_info{PGN_Index(j), 7};
                       end
                   catch
                       signal_offset = 0;
                   end
                   try
                       if ischar(setting_info{PGN_Index(j), 8})
                           signal_factor = num2str(setting_info{PGN_Index(j), 8});
                       else
                           signal_factor = setting_info{PGN_Index(j), 8};
                       end
                   catch
                       signal_factor = 1;
                   end
                   if iscell(signal_data)
                       signal_data = cell2mat(signal_data);
                   end
                   signal_data = signal_data - signal_offset; 
                   signal_data = signal_data * signal_factor;
                   signal_data = num2cell(signal_data);
                   if j == 1
                        signal_data_list = time_data;
                   end
                   try
                       signal_data_list = [signal_data_list';signal_data'];
                   catch ex
                       msgbox(ex.message);
                       return;
                   end
                   signal_data_list = signal_data_list';
                end
                if read_cnt == 1 || (signal_row(i)==0 && write_cnt(i) == 0)
                    write_excel_signal_data_list = header_data;
                    write_excel_signal_data_list = [write_excel_signal_data_list;signal_data_list];
                    all_data_result{i} = write_excel_signal_data_list;
                else
                    write_excel_signal_data_list = all_data_result{i};
                    write_excel_signal_data_list = [write_excel_signal_data_list;signal_data_list];
                    all_data_result{i} = write_excel_signal_data_list;
                end
                
                signal_row(i) = size(all_data_result{i},1);
                
                clear('write_excel_signal_data_list');
                clear('signal_data_list');
                clear('signal_bit_data');
                    
                %% ��͂����f�[�^��Excel�ɏ�������(���s���̃f�[�^�����܂����珑������)
                if signal_row(i) >= MaxKeepRows
                    if length(all_data_result) ~= length(signal_PGN_lst)
                        ProcessBar('Processing�FClosing.', 1, 0, 1);
                      %% csv�t�@�C�������
                        try
                            fclose(fileID);
                        catch
                        end
                        msgbox('CAN�f�[�^�𒊏o�ł��܂���ł����B');
                        return;
                    end

                    if ~isempty(all_data_result{i})
                        try
                            if write_excel_count == 0
                                xlswrite([ out_file_name '.xlsx'], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                            else
                                %write_excel_count = write_excel_count + 1;
                                xlswrite([ out_file_name sprintf('_%2d', write_excel_count+1) '.xlsx'], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                            end
                        catch
                            if write_excel_count == 0
                                xlswrite([ out_file_name datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                            else
                                %write_excel_count = write_excel_count + 1;
                                xlswrite([ out_file_name sprintf('_%2d', write_excel_count+1) datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                            end
                        end

                        write_cnt(i) = write_cnt(i) + signal_row(i);
                        signal_row(i) = 0;
                        all_data_result{i} = {};
                    end
                end
            end
                
            %% 100���s�𒴂���\��������ꍇ�A�ʃt�@�C���ɏo�͂���
            if max(write_cnt) >= 200000 - MaxKeepRows
               %�e�V�[�g�̖�����Time�����낦�邽�߁A�ێ����̑S�Ẵf�[�^���Ƀt�@�C���o�͂���
                for i = 1: size(signal_PGN_lst, 1)
                   if ~isempty(all_data_result{i})
                        try
                            if write_excel_count == 0
                                xlswrite([ out_file_name '.xlsx'], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                            else
                                %write_excel_count = write_excel_count + 1;
                                xlswrite([ out_file_name sprintf('_%2d', write_excel_count+1) '.xlsx'], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                            end
                        catch
                            if write_excel_count == 0
                                xlswrite([ out_file_name datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                            else
                                %write_excel_count = write_excel_count + 1;
                                xlswrite([ out_file_name sprintf('_%2d', write_excel_count+1) datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                            end
                        end

                        signal_row(i) = 0;
                        all_data_result{i} = {};
                    end 
                end
                read_cnt = 0;
                write_cnt = zeros(size(signal_PGN_lst));
                write_excel_count = write_excel_count + 1;
            end
        end
        ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', ...
                              (k-1) * MaxReadRows + processed_data_pgn_count, length(org_data_Time) + (k-1) * MaxReadRows), 1, 0, 0);
        ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', ...
                              (k-1) * MaxReadRows + processed_data_pgn_count, length(org_data_Time) + (k-1) * MaxReadRows), 1, 0, 1);
        %% ���̓t�@�C������܂��B
        try
            fclose(fileID);
        catch
        end
        if length(all_data_result) ~= length(signal_PGN_lst)
            msgbox('CAN�f�[�^���o�ł��܂���ł����B');
            return;
        end
        NotHaveDataPGN = {};
       %% ��͂����f�[�^���o�̓t�@�C���ɏ�������
         %(���s���̃f�[�^�����܂�O��EOF�����o���ꂽ�ꍇ,�c��̃f�[�^����������)
        for i = 1:length(write_sheet_name_lst)
           if ~isempty(all_data_result{i})
             try
                 if write_excel_count == 0
                    xlswrite([ out_file_name '.xlsx'], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                 else
                     %write_excel_count = write_excel_count + 1;
                     xlswrite([ out_file_name sprintf('_%2d', write_excel_count+1) '.xlsx'], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                 end
             catch
                 if write_excel_count == 0
                     xlswrite([ out_file_name datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                 else
                     %write_excel_count = write_excel_count + 1;
                     xlswrite([ out_file_name sprintf('_%2d', write_excel_count+1) datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], all_data_result{i}, write_sheet_name_lst{i},['A',num2str(write_cnt(i)+1)]); 
                 end
             end
           end
        end
         %�t�@�C���𕪊������ꍇ�A1�ڂ̃t�@�C�������l�[������
        if write_excel_count ~= 0
           movefile([out_file_name,'.xlsx'],[out_file_name,'_ 1','.xlsx']);
        end
        
    catch ex
       %% �e�L�X�g �t�@�C������܂��B
        try
            fclose(fileID);
        catch
        end
        ProcessBar('Processing�FClosing.', 1, 0, 1);
        msgbox(ex.message);
    end
end

%% �v���Z�X�o�[�̏���
function ProcessBar(message, percent, open, close)
    global bar;
    try
        %% �@ �v���Z�X�o�[�̏�����
        if open == 1
            % �@ (1) waitbar�̊֐��ŏ��������s��
            bar = waitbar(0, message, 'CreateCancelBtn', 'setappdata(gcbf,''canceling'',1)');
       %% �A ���Ƀv���Z�X�o�[���쐬���ꂽ�ꍇ�A�v���Z�X�X�V���s��
        else
            if ishandle(bar)
                % �A (1) waitbar�̊֐��Ńp�[�Z���g�ƕ\��������e���X�V����
                waitbar(percent, bar, sprintf('%s', message));
            end
        end
        %% �B �N���[�Y�t���O��1�̏ꍇ�A�v���Z�X�o�[�����
        if close == 1
            delete(bar);
        end
    catch
        if ishandle(bar)
            delete(bar);
        end
    end
end

%% �o�̓t�@�C���Ƀf�[�^����������
function WriteInfo(write_sheet_name_lst, all_data_result, write_excel_count, out_file_name)
    try
        for i = 1:length(write_sheet_name_lst)
             if isempty(all_data_result{i})
                 continue;
             end
             try
                 if write_excel_count == 0
                    xlswrite([ out_file_name '.xlsx'], all_data_result{i}, write_sheet_name_lst{i}); 
                 else
                     write_excel_count = write_excel_count + 1;
                     xlswrite([ out_file_name sprintf('_%2d', write_excel_count) '.xlsx'], all_data_result{i}, write_sheet_name_lst{i}); 
                 end
             catch
                 if write_excel_count == 0
                     xlswrite([ out_file_name datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], all_data_result{i}, write_sheet_name_lst{i}); 
                 else
                     write_excel_count = write_excel_count + 1;
                     xlswrite([ out_file_name sprintf('_%2d', write_excel_count) datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], all_data_result{i}, write_sheet_name_lst{i}); 
                 end
             end
        end
    catch
        msgbox('CAN�f�[�^���o�ł��܂���ł����B');
    end
end
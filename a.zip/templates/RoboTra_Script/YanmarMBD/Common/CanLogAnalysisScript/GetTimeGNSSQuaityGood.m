%% GetTimeGNSSQuaityGood
% �T�v�Fcsv��CAN�p�P�b�g�̃f�[�^����GNSS�ʒu���m�肷��܂ł̎��ԂƁA
%   �@�@���̃^�C�~���O�̈ʒu���A��n�ǃ��[�h�𒊏o����B
% �p�����[�^�F
%           file_full_name�F���̓t�@�C���p�X + �t�@�C����
%                           Matlab�̌��݃J�����g�f�B���N�g���ɂ���΁A�t�@�C�����݂̂ŗǂ��B
%           out_file_name�F�o�̓t�@�C����
%                          �g���q�𔲂��ē��͂��Ă��������B
%           Data_is_Dec�F
%                  �E1: csv�̃f�[�^��10�i���̏ꍇ
%                  �E0: csv�̃f�[�^��16�i���̏ꍇ
% �߂�l�F�Ȃ�
function GetTimeGNSSQuaityGood(file_full_name, out_file_name, Data_is_Dec)
global bar;

% �e�X�g�p
%     file_full_name = 'Test_02_2018_03_07_13_35_28.csv';
%     out_file_name = 'Output_GetTimeGNSSQuaityGood';
%     Data_is_Dec = 0;  
    
    %% �`�F�b�N�p��CAN�p�P�b�g��PGN
    GNSS_Quality_PGN = 'ffd9';
    Base_Station_Mode_PGN = '1ff07';
    GNSS_Pos_PGN = '1f801';
    if Data_is_Dec == 1
        GNSS_Quality_PGN = hex2dec(GNSS_Quality_PGN);
        Base_Station_Mode_PGN = hex2dec(Base_Station_Mode_PGN);
        GNSS_Pos_PGN = hex2dec(GNSS_Pos_PGN);
    end
    %   �f�[�^�擾���           StartBit Length Sign Offset Factor
    GNSS_Quality_Info      =  [   8        4     0      0     1       ];
    Base_Station_Mode_Info =  [   0        1     0      0     1       ];
    Longtitude_Info        =  [   0        32    1      0     10^-7   ];
    Latitude_Info          =  [   32       32    1      0     10^-7   ];
    
    GNSS_Quality_1_starttime = -1;
    GNSS_Quality_5_starttime = -1;
    GNSS_Quality_4_starttime = -1;
    GNSS_Quality_1_5_time = -1;
    GNSS_Quality_5_4_time = -1;
    % �o�͕ϐ��̏����l
    Longtitude = 0;
    Latitude = 0;
    Base_Station_Mode = -1;
    
    Longtitude_Time = -1;
    Latitude_Time = -1;
    Base_Station_Mode_Time = -1;
    %% �ϐ������������܂��B
    delimiter = ',';

    %% �f�[�^�̗�𕶎���Ƃ��ēǂݎ��:
    % �ڍׂ� TEXTSCAN �̃h�L�������e�[�V�������Q�Ƃ��Ă��������B
    formatSpec = '%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%[^\n\r]';

    %% ���̓t�@�C�����J���܂��B
    fileID = fopen(file_full_name,'r');
    try
        k = 0;
        count_1000man_row = 0;
        MaxReadRows = 100000;
       %% ���̓t�@�C����MaxReadRows�s���ƂɃf�[�^�ǂݍ���ŁACAN�p�P�b�g��͂��s��
        while ~feof(fileID)
            k = k + 1;
            count_1000man_row = count_1000man_row + 1;
            if k == 1
                ProcessBar('Processing Start', 0, 1, 0);
            end
            if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                delete(bar);
                fclose(fileID);
                return;
            end
            percent = (k-1)/k;
           %% �f�[�^�̗������������ɏ]���ēǂݎ��܂��B
            % ���̌Ăяo���́A���̃R�[�h�̐����Ɏg�p���ꂽ�t�@�C���̍\���Ɋ�Â��Ă��܂��B�ʂ̃t�@�C���ŃG���[����������ꍇ�́A�C���|�[�g
            % �c�[������R�[�h�̍Đ��������݂Ă��������B
            org_data = textscan(fileID, formatSpec, MaxReadRows, 'Delimiter', delimiter,  'ReturnOnError', false);
            %org_data = textscan(fileID, formatSpec, endRow-startRow+1, 'Delimiter', delimiter, 'HeaderLines', startRow-1, 'ReturnOnError', false);
            % CAN�f�[�^���s��(��< 16 OR �s�� < 9)�̏ꍇ�A������~
            if k == 1
                if size(org_data, 2) < 16 || size(org_data{1}, 1) < 9
                    msgbox('CAN�f�[�^���s��(��< 16 OR �s�� < 9)�̏ꍇ�A������~');
                    return;
                end
            end

            if k == 1
                start_index = 9;
            else
                start_index = 1;
            end

            % org_data{1}:Time
            org_data_Time = org_data{1};
            org_data_Time = org_data_Time(start_index:end,:);

            ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', (k-1) * MaxReadRows, length(org_data_Time) + (k-1) * MaxReadRows), percent, 0, 0);
            
            % org_data{3}:PGN
            org_data_PGN = org_data{3};
            org_data_PGN = org_data_PGN(start_index:end,:);

            % org_data{6}:Data0
            org_data_Data0 = org_data{6};
            org_data_Data0 = org_data_Data0(start_index:end,:);

            % org_data{7}:Data1
            org_data_Data1 = org_data{7};
            org_data_Data1 = org_data_Data1(start_index:end,:);

            % org_data{8}:Data2
            org_data_Data2 = org_data{8};
            org_data_Data2 = org_data_Data2(start_index:end,:);

            % org_data{9}:Data3
            org_data_Data3 = org_data{9};
            org_data_Data3 = org_data_Data3(start_index:end,:);

            % org_data{10}:Data4
            org_data_Data4 = org_data{10};
            org_data_Data4 = org_data_Data4(start_index:end,:);

            % org_data{11}:Data5
            org_data_Data5 = org_data{11};
            org_data_Data5 = org_data_Data5(start_index:end,:);

            % org_data{12}:Data6
            org_data_Data6 = org_data{12};
            org_data_Data6 = org_data_Data6(start_index:end,:);

            % org_data{13}:Data7
            org_data_Data7 = org_data{13};
            org_data_Data7 = org_data_Data7(start_index:end,:);
            
            org_data_DLC = org_data{5};
            org_data_DLC = org_data_DLC(start_index:end,:);
            
            processed_data_pgn_count = 0;
            
           %% �`�F�b�N�p�̑S�ăf�[�^���̃C���f�b�N�X�擾
            if Data_is_Dec == 1
                GNSS_Quality_data_index = find(strcmp(num2str(GNSS_Quality_PGN), org_data_PGN));
            else
                GNSS_Quality_data_index = find(strcmp(GNSS_Quality_PGN, org_data_PGN));
            end
            org_data_DLC_num = 0;
            if ~isempty(GNSS_Quality_data_index)
                org_data_DLC_num = org_data_DLC{GNSS_Quality_data_index(1)};
            end
            GNSS_Quality_data = GetSignalData(Data_is_Dec, GNSS_Quality_data_index, GNSS_Quality_Info, org_data_Time, org_data_DLC_num, ...
                                                           org_data_Data0, org_data_Data1, org_data_Data2, org_data_Data3, ...
                                                           org_data_Data4, org_data_Data5, org_data_Data6, org_data_Data7);
            if isempty(GNSS_Quality_data)
                continue;
            end
            GNSS_Quality_1_index = find(cell2mat(GNSS_Quality_data(:,2)) == 1);
            if ~isempty(GNSS_Quality_1_index) && GNSS_Quality_1_starttime == -1
                GNSS_Quality_1_index = GNSS_Quality_1_index(1);
                GNSS_Quality_1_starttime = str2double(GNSS_Quality_data{GNSS_Quality_1_index(1), 1});
            end
            GNSS_Quality_5_index = find(cell2mat(GNSS_Quality_data(:,2)) == 5);
            if ~isempty(GNSS_Quality_5_index) && GNSS_Quality_5_starttime == -1
                GNSS_Quality_5_index = GNSS_Quality_5_index(1);
                GNSS_Quality_5_starttime = str2double(GNSS_Quality_data{GNSS_Quality_5_index(1), 1});
            end
            GNSS_Quality_4_index = find(cell2mat(GNSS_Quality_data(:,2)) == 4);
            if ~isempty(GNSS_Quality_4_index)
                GNSS_Quality_4_index = GNSS_Quality_4_index(1);
                GNSS_Quality_4_starttime = str2double(GNSS_Quality_data{GNSS_Quality_4_index(1), 1});
                if GNSS_Quality_1_starttime == -1 && GNSS_Quality_5_starttime == -1
                    GNSS_Quality_1_starttime = GNSS_Quality_4_starttime;
                    GNSS_Quality_5_starttime = GNSS_Quality_4_starttime;
                elseif GNSS_Quality_1_starttime == -1 && GNSS_Quality_5_starttime ~= -1
                    GNSS_Quality_1_starttime = GNSS_Quality_5_starttime;
                elseif GNSS_Quality_1_starttime ~= -1 && GNSS_Quality_5_starttime == -1
                    GNSS_Quality_5_starttime = GNSS_Quality_4_starttime;
                else
                    % nothing
                    % GNSS_Quality_1_starttime ~= -1 && ~GNSS_Quality_5_starttime == -1�̏ꍇ
                    % ���Ɋi�[�����l�����̂܂܂ɂ���B
                end
                
                GNSS_Quality_1_5_time = GNSS_Quality_5_starttime - GNSS_Quality_1_starttime;
                GNSS_Quality_5_4_time = GNSS_Quality_4_starttime - GNSS_Quality_5_starttime;
                
                clear('org_data_PGN');
                clear('org_data_Data0');
                clear('org_data_Data1');
                clear('org_data_Data2');
                clear('org_data_Data3');
                clear('org_data_Data4');
                clear('org_data_Data5');
                clear('org_data_Data6');
                clear('org_data_Data7');
                break;
            end                                                                    
            clear('org_data_PGN');        
        end
       
        ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', ...
                              (k-1) * MaxReadRows + processed_data_pgn_count, length(org_data_Time) + (k-1) * MaxReadRows), 1, 0, 0);
        ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', ...
                              (k-1) * MaxReadRows + processed_data_pgn_count, length(org_data_Time) + (k-1) * MaxReadRows), 1, 0, 1);
       %% ���̓t�@�C������܂��B
        try
            fclose(fileID);
        catch
            % nothing
        end
        ProcessBar('Processing�FClosing.', 1, 0, 1);
    catch ex
       %% ���̓t�@�C������܂��B
        try
            fclose(fileID);
        catch
        end
        ProcessBar('Processing�FClosing.', 1, 0, 1);
        msgbox(ex.message);
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    if GNSS_Quality_4_starttime == -1
        result = SetResultValue (GNSS_Quality_1_starttime, GNSS_Quality_5_starttime, GNSS_Quality_4_starttime, ...
                                  GNSS_Quality_1_5_time, GNSS_Quality_5_4_time, Longtitude, Latitude, Base_Station_Mode, ...
                                  Longtitude_Time, Latitude_Time, Base_Station_Mode_Time);

       %% ���ʏo��
        try
            xlswrite([ out_file_name '.xlsx' ], result, 'GetTimeGNSSQuaityGood');
        catch
            xlswrite([ out_file_name '_' datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], result, 'GetTimeGNSSQuaityGood');
        end
        
        return;
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    iswritedata = 0;
    %% ���̓t�@�C�����J���܂��B
    fileID = fopen(file_full_name,'r');
    try
        k = 0;
        count_1000man_row = 0;
        MaxReadRows = 100000;
       %% ���̓t�@�C����MaxReadRows�s���ƂɃf�[�^�ǂݍ���ŁACAN�p�P�b�g��͂��s��
        while ~feof(fileID)
            k = k + 1;
            count_1000man_row = count_1000man_row + 1;
            if k == 1
                ProcessBar('Processing Start', 0, 1, 0);
            end
            if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                delete(bar);
                fclose(fileID);
                return;
            end
            percent = (k-1)/k;
            %% �f�[�^�̗������������ɏ]���ēǂݎ��܂��B
            % ���̌Ăяo���́A���̃R�[�h�̐����Ɏg�p���ꂽ�t�@�C���̍\���Ɋ�Â��Ă��܂��B�ʂ̃t�@�C���ŃG���[����������ꍇ�́A�C���|�[�g
            % �c�[������R�[�h�̍Đ��������݂Ă��������B
            org_data = textscan(fileID, formatSpec, MaxReadRows, 'Delimiter', delimiter,  'ReturnOnError', false);
            %org_data = textscan(fileID, formatSpec, endRow-startRow+1, 'Delimiter', delimiter, 'HeaderLines', startRow-1, 'ReturnOnError', false);
            % CAN�f�[�^���s��(��< 16 OR �s�� < 9)�̏ꍇ�A������~
            if k == 1
                if size(org_data, 2) < 16 || size(org_data{1}, 1) < 9
                    msgbox('CAN�f�[�^���s��(��< 16 OR �s�� < 9)�̏ꍇ�A������~');
                    return;
                end
            end

            if k == 1
                start_index = 9;
            else
                start_index = 1;
            end

            % org_data{1}:Time
            org_data_Time = org_data{1};
            org_data_Time = org_data_Time(start_index:end,:);

            ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', (k-1) * MaxReadRows, length(org_data_Time) + (k-1) * MaxReadRows), percent, 0, 0);
            
            % org_data{3}:PGN
            org_data_PGN = org_data{3};
            org_data_PGN = org_data_PGN(start_index:end,:);

            % org_data{6}:Data0
            org_data_Data0 = org_data{6};
            org_data_Data0 = org_data_Data0(start_index:end,:);

            % org_data{7}:Data1
            org_data_Data1 = org_data{7};
            org_data_Data1 = org_data_Data1(start_index:end,:);

            % org_data{8}:Data2
            org_data_Data2 = org_data{8};
            org_data_Data2 = org_data_Data2(start_index:end,:);

            % org_data{9}:Data3
            org_data_Data3 = org_data{9};
            org_data_Data3 = org_data_Data3(start_index:end,:);

            % org_data{10}:Data4
            org_data_Data4 = org_data{10};
            org_data_Data4 = org_data_Data4(start_index:end,:);

            % org_data{11}:Data5
            org_data_Data5 = org_data{11};
            org_data_Data5 = org_data_Data5(start_index:end,:);

            % org_data{12}:Data6
            org_data_Data6 = org_data{12};
            org_data_Data6 = org_data_Data6(start_index:end,:);

            % org_data{13}:Data7
            org_data_Data7 = org_data{13};
            org_data_Data7 = org_data_Data7(start_index:end,:);
            
            org_data_DLC = org_data{5};
            org_data_DLC = org_data_DLC(start_index:end,:);
            
            processed_data_pgn_count = 0;
            
           %% �`�F�b�N�p�̑S�ăf�[�^���̃C���f�b�N�X�擾
            if Data_is_Dec == 1
                Base_Station_Mode_data_index = find(strcmp(num2str(Base_Station_Mode_PGN), org_data_PGN));
                GNSS_Pos_data_index = find(strcmp(num2str(GNSS_Pos_PGN), org_data_PGN));
            else
                Base_Station_Mode_data_index = find(strcmp(Base_Station_Mode_PGN, org_data_PGN));
                GNSS_Pos_data_index = find(strcmp(GNSS_Pos_PGN, org_data_PGN));
            end
            org_data_DLC_num = 0;
            if ~isempty(Base_Station_Mode_data_index)
                org_data_DLC_num = org_data_DLC{GNSS_Quality_data_index(1)};
            end
            if Base_Station_Mode_Time == -1
                Base_Station_Mode_data = GetSignalData(Data_is_Dec, Base_Station_Mode_data_index, Base_Station_Mode_Info, org_data_Time, org_data_DLC_num, ...
                                                           org_data_Data0, org_data_Data1, org_data_Data2, org_data_Data3, ...
                                                           org_data_Data4, org_data_Data5, org_data_Data6, org_data_Data7);
                if ~isempty(Base_Station_Mode_data)                                
                    Base_Station_Mode_check = str2double(cellstr(Base_Station_Mode_data(:,1))) - GNSS_Quality_4_starttime;
                    find_trigger_index_1 = find(Base_Station_Mode_check <= 0);
                    find_trigger_index_2 = find(Base_Station_Mode_check > 0 );

                    if ~isempty(find_trigger_index_1) || ~isempty(find_trigger_index_2)
                        if isempty(find_trigger_index_2)
                            find_trigger_index = find_trigger_index_1(end);
                        elseif isempty(find_trigger_index_1)
                            find_trigger_index = find_trigger_index_2(1);
                        else
                            find_trigger_index = find_trigger_index_1(end);
                        end
                        Base_Station_Mode = Base_Station_Mode_data{find_trigger_index, 2};
                        Base_Station_Mode_Time = Base_Station_Mode_data{find_trigger_index, 1};
                    end
                end
            end
            if Longtitude_Time == -1
                Longtitude_data = GetSignalData(Data_is_Dec, GNSS_Pos_data_index, Longtitude_Info, org_data_Time, org_data_DLC_num, ...
                                                             org_data_Data0, org_data_Data1, org_data_Data2, org_data_Data3, ...
                                                             org_data_Data4, org_data_Data5, org_data_Data6, org_data_Data7);
                if ~isempty(Longtitude_data)                                
                    Longtitude_data_check = str2double(cellstr(Longtitude_data(:,1))) - GNSS_Quality_4_starttime;
                    find_trigger_index_1 = find(Longtitude_data_check <= 0);
                    find_trigger_index_2 = find(Longtitude_data_check > 0 );

                    if ~isempty(find_trigger_index_1) || ~isempty(find_trigger_index_2)
                        if isempty(find_trigger_index_2)
                            find_trigger_index = find_trigger_index_1(end);
                        elseif isempty(find_trigger_index_1)
                            find_trigger_index = find_trigger_index_2(1);
                        else
                            find_trigger_index = find_trigger_index_1(end);
                        end
                        Longtitude = Longtitude_data{find_trigger_index, 2};
                        Longtitude_Time = Longtitude_data{find_trigger_index, 1};
                        Latitude_data = GetSignalData(Data_is_Dec, GNSS_Pos_data_index, Latitude_Info, org_data_Time, org_data_DLC_num, ...
                                                               org_data_Data0, org_data_Data1, org_data_Data2, org_data_Data3, ...
                                                               org_data_Data4, org_data_Data5, org_data_Data6, org_data_Data7);
                        Latitude = Latitude_data{find_trigger_index, 2};
                        Latitude_Time = Latitude_data{find_trigger_index, 1};
                    end
                end
            end
            
            if str2double(Base_Station_Mode_Time) ~= -1 && str2double(Longtitude_Time) ~= -1 && str2double(Latitude_Time) ~= -1

                result = SetResultValue (GNSS_Quality_1_starttime, GNSS_Quality_5_starttime, GNSS_Quality_4_starttime, ...
                                          GNSS_Quality_1_5_time, GNSS_Quality_5_4_time, Longtitude, Latitude, Base_Station_Mode, ...
                                          Longtitude_Time, Latitude_Time, Base_Station_Mode_Time);
                
              %% ���ʏo��
                try
                    xlswrite([ out_file_name '.xlsx' ], result, 'GetTimeGNSSQuaityGood');
                catch
                    xlswrite([ out_file_name '_' datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], result, 'GetTimeGNSSQuaityGood');
                end
                
                clear('org_data_PGN');
                clear('org_data_Data0');
                clear('org_data_Data1');
                clear('org_data_Data2');
                clear('org_data_Data3');
                clear('org_data_Data4');
                clear('org_data_Data5');
                clear('org_data_Data6');
                clear('org_data_Data7');
                iswritedata = 1;
                break;       
            end
        end
       
        
        ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', ...
                              (k-1) * MaxReadRows + processed_data_pgn_count, length(org_data_Time) + (k-1) * MaxReadRows), 1, 0, 0);
        ProcessBar(sprintf('Processing�F%d�s/%d�s data items.', ...
                              (k-1) * MaxReadRows + processed_data_pgn_count, length(org_data_Time) + (k-1) * MaxReadRows), 1, 0, 1);
       %% ���̓t�@�C������܂��B
        try
            fclose(fileID);
        catch
            % nothing
        end
        if iswritedata == 0
            result = SetResultValue (GNSS_Quality_1_starttime, GNSS_Quality_5_starttime, GNSS_Quality_4_starttime, ...
                                      GNSS_Quality_1_5_time, GNSS_Quality_5_4_time, Longtitude, Latitude, Base_Station_Mode, ...
                                      Longtitude_Time, Latitude_Time, Base_Station_Mode_Time);

          %% ���ʏo��
            try
                xlswrite([ out_file_name '.xlsx' ], result, 'GetTimeGNSSQuaityGood');
            catch
                xlswrite([ out_file_name '_' datestr(now, 'yyyymmdd_hhMMss') '.xlsx' ], result, 'GetTimeGNSSQuaityGood');
            end
        end
        ProcessBar('Processing�FClosing.', 1, 0, 1);
    catch ex
       %% ���̓t�@�C������܂��B
        try
            fclose(fileID);
        catch
        end
        ProcessBar('Processing�FClosing.', 1, 0, 1);
        msgbox(ex.message);
    end
end

%% �v���Z�X�o�[�̏���
function ProcessBar(message, percent, open, close)
    global bar;
    try
        %% �@ �v���Z�X�o�[�̏�����
        if open == 1
            % �@ (1) waitbar�̊֐��ŏ��������s��
            bar = waitbar(0, message, 'CreateCancelBtn', 'setappdata(gcbf,''canceling'',1)');
       %% �A ���Ƀv���Z�X�o�[���쐬���ꂽ�ꍇ�A�v���Z�X�X�V���s��
        else
            if ishandle(bar)
                % �A (1) waitbar�̊֐��Ńp�[�Z���g�ƕ\��������e���X�V����
                waitbar(percent, bar, sprintf('%s', message));
            end
        end
        %% �B �N���[�Y�t���O��1�̏ꍇ�A�v���Z�X�o�[�����
        if close == 1
            delete(bar);
        end
    catch
        if ishandle(bar)
            delete(bar);
        end
    end
end

%% �eCAN�p�P�b�g�̐M���f�[�^�擾
%  �擾�����f�[�^�͒P�ʕϊ���̃f�[�^�Ƃ���
function signal_data = GetSignalData(Data_is_Dec, GNSS_Quality_data_index, GNSS_Quality_Info, org_data_Time, org_data_DLC_num, ...
                                                        org_data_Data0, org_data_Data1, org_data_Data2, org_data_Data3, ...
                                                        org_data_Data4, org_data_Data5, org_data_Data6, org_data_Data7)
        signal_data = {};
        GNSS_Quality_PGN_bit_data = GetSignalBitData(Data_is_Dec, GNSS_Quality_data_index, org_data_DLC_num, ...
                                                            org_data_Data0, org_data_Data1, org_data_Data2, org_data_Data3, ...
                                                            org_data_Data4, org_data_Data5, org_data_Data6, org_data_Data7);
        if isempty(GNSS_Quality_PGN_bit_data)
            return;
        end
        GNSS_Quality_bit_data = GNSS_Quality_PGN_bit_data(:, size(GNSS_Quality_PGN_bit_data, 2) - GNSS_Quality_Info(2) - GNSS_Quality_Info(1) + 1: ...
                                                             size(GNSS_Quality_PGN_bit_data, 2) - GNSS_Quality_Info(1));
        if isempty(GNSS_Quality_bit_data)
            return;
        end
        GNSS_Quality_time_data = org_data_Time(GNSS_Quality_data_index);                                                 
        signal_data = Convert2Decimal(GNSS_Quality_time_data, GNSS_Quality_bit_data, ...
                                            GNSS_Quality_Info(3), GNSS_Quality_Info(4), GNSS_Quality_Info(5));
end

%% �eCAN�p�P�b�g�̐M����Bit�f�[�^�擾
function signal_all_bit_data = GetSignalBitData(Data_is_Dec, data_index, org_data_DLC_num, org_data_Data0, org_data_Data1, org_data_Data2, org_data_Data3, ...
                                                                         org_data_Data4, org_data_Data5, org_data_Data6, org_data_Data7)
    try
        signal_all_bit_data = {};
        % Data0�`Data7
        if Data_is_Dec == 1
            if org_data_DLC_num >= 1
                bin_org_data_Data0 = dec2bin(str2double(org_data_Data0(data_index)), 8);
            else
                bin_org_data_Data0 = dec2bin(zeros(length(data_index), 1), 8);
            end
            if org_data_DLC_num >= 2
                bin_org_data_Data1 = dec2bin(str2double(org_data_Data1(data_index)), 8);
            else
                bin_org_data_Data1 = dec2bin(zeros(length(data_index), 1), 8);
            end
            if org_data_DLC_num >= 3
                bin_org_data_Data2 = dec2bin(str2double(org_data_Data2(data_index)), 8);
            else
                bin_org_data_Data2 = dec2bin(zeros(length(data_index), 1), 8);
            end
            if org_data_DLC_num >= 4
                bin_org_data_Data3 = dec2bin(str2double(org_data_Data3(data_index)), 8);
            else
                bin_org_data_Data3 = dec2bin(zeros(length(data_index), 1), 8);
            end
            if org_data_DLC_num >= 5
                bin_org_data_Data4 = dec2bin(str2double(org_data_Data4(data_index)), 8);
            else
                bin_org_data_Data4 = dec2bin(zeros(length(data_index), 1), 8);
            end
            if org_data_DLC_num >= 6
                bin_org_data_Data5 = dec2bin(str2double(org_data_Data5(data_index)), 8);
            else
                bin_org_data_Data5 = dec2bin(zeros(length(data_index), 1), 8);
            end
            if org_data_DLC_num >= 7
                bin_org_data_Data6 = dec2bin(str2double(org_data_Data6(data_index)), 8);
            else
                bin_org_data_Data6 = dec2bin(zeros(length(data_index), 1), 8);
            end
            if org_data_DLC_num >= 8
                bin_org_data_Data7 = dec2bin(str2double(org_data_Data7(data_index)), 8);
            else
                bin_org_data_Data7 = dec2bin(zeros(length(data_index), 1), 8);
            end
            signal_all_bit_data = strcat(bin_org_data_Data7, ...
                                         bin_org_data_Data6, ...
                                         bin_org_data_Data5, ...
                                         bin_org_data_Data4, ...
                                         bin_org_data_Data3, ...
                                         bin_org_data_Data2, ...
                                         bin_org_data_Data1, ...
                                         bin_org_data_Data0 ...
                                        );
        else
            signal_all_bit_data = strcat(dec2bin(hex2dec(org_data_Data7(data_index)), 8), ...
                                        dec2bin(hex2dec(org_data_Data6(data_index)), 8), ...
                                        dec2bin(hex2dec(org_data_Data5(data_index)), 8), ...
                                        dec2bin(hex2dec(org_data_Data4(data_index)), 8), ...
                                        dec2bin(hex2dec(org_data_Data3(data_index)), 8), ...
                                        dec2bin(hex2dec(org_data_Data2(data_index)), 8), ...
                                        dec2bin(hex2dec(org_data_Data1(data_index)), 8), ...
                                        dec2bin(hex2dec(org_data_Data0(data_index)), 8) ...
                                      );
        end
    catch ex
        disp(ex.message);
    end
end

%% �eCAN�p�P�b�g�̐M����Bit�f�[�^����Decimal�ɕϊ����Ă���A�܂��P�ʕϊ����s��
function signal_data_rs = Convert2Decimal(time_data, signal_bit_data, signal_sign, signal_offset, signal_factor) 
       signal_data_rs = {};
       signal_data = convert_bin2dec(signal_bit_data, signal_sign);
       if iscell(signal_data)
           signal_data = cell2mat(signal_data);
       end
       signal_data = signal_data - signal_offset; 
       signal_data = signal_data * signal_factor;
       signal_data = num2cell(signal_data);
       try
           signal_data_rs = time_data;
           signal_data_rs = [signal_data_rs';signal_data'];
       catch ex
           disp(ex.message);
           return;
       end
       signal_data_rs = signal_data_rs';
end

%% �o�̓f�[�^�ݒ�
function result = SetResultValue (GNSS_Quality_1_starttime, GNSS_Quality_5_starttime, GNSS_Quality_4_starttime, ...
                                  GNSS_Quality_1_5_time, GNSS_Quality_5_4_time, Longtitude, Latitude, Base_Station_Mode, ...
                                  Longtitude_Time, Latitude_Time, Base_Station_Mode_Time)
    result = { ''; 'GNSS�����P�ɂȂ�^�C�~���O'; 'GNSS�����T�ɂȂ�^�C�~���O'; 'GNSS�����S�ɂȂ�^�C�~���O'; ...
              'GNSS�����P����T�ɂȂ�܂ł̎���'; 'GNSS�����T����S�ɂȂ�܂ł̎���'; '�o�x'; '�ܓx'; '��n�ǃ��[�h'};

    result{1, 1} = '';
    result{1, 2} = '�l';
    result{1, 3} = '�l�̎�����^�C�~���O';

    if GNSS_Quality_1_starttime ~= -1
        result{2, 2} = GNSS_Quality_1_starttime;
    end
    if GNSS_Quality_5_starttime ~= -1
        result{3, 2} = GNSS_Quality_5_starttime;
    end
    if GNSS_Quality_4_starttime ~= -1
        result{4, 2} = GNSS_Quality_4_starttime;
    end

    if GNSS_Quality_1_5_time ~= -1
        result{5, 2} = GNSS_Quality_1_5_time;
    end
    if GNSS_Quality_5_4_time ~= -1
        result{6, 2} = GNSS_Quality_5_4_time;
    end
    if Longtitude ~= 0
        result{7, 2} = Longtitude;
    end
    if Latitude ~= 0
        result{8, 2} = Latitude;
    end
    if Base_Station_Mode ~= -1
        result{9, 2} = Base_Station_Mode;
    end
    if Longtitude_Time ~= -1
        result{7, 3} = Longtitude_Time;
    end
    if Latitude_Time ~= -1
        result{8, 3} = Latitude_Time;
    end
    if Base_Station_Mode_Time ~= -1
        result{9, 3} = Base_Station_Mode_Time;
    end
end
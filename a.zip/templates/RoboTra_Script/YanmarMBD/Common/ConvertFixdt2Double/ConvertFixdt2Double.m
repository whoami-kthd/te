%% �֐����FConvertFixdt2Double
%  �T�v�F
%       SLDD�A���f���̃u���b�N�̏o�̓f�[�^�^�p�����[�^�A�X�e�[�g�t���[�̃f�[�^�̃f�[�^�^��
%       fixdt��double�ɕϊ�����
%  �p�����[�^�F 
%        input_info(���f�������́ASLDD��)
%  �߂��l�F�@�Ȃ�
%  �쐬�ҁF LOC
%  �쐬���F 2017/07/05
function ConvertFixdt2Double(input_info)
global bar;
try
    try
        get_param(input_info, 'handle');
        % input_flag = 1�F�����̓��f�����Ɣ���
        input_flag = 1;
    catch
        % input_flag = 0�F������SLDD���Ɣ���
        input_flag = 0;
    end
    % ���f�����̏ꍇ
    if input_flag == 1
        sldd_name = get_param(input_info, 'DataDictionary');
        model_name = input_info;
    % SLDD���̏ꍇ
    else
        if isempty(regexp(input_info, '.sldd$', 'match'))
            sldd_name = [ input_info '.sldd' ];
        else
            sldd_name = input_info;
        end
        model_name = '';
    end
    fixed_var_list = {};
    fixed_var_list{end + 1, 1} = '�ύX�Ώ�';
    fixed_var_list{end, 2} = '�^�C�v';
    fixed_var_list{end, 3} = '�ύX�O�̃f�[�^�^';
    fixed_var_list{end, 4} = '�ύX��̃f�[�^�^';
    start = 1;
    error_index = [];
    if ~isempty(sldd_name)
        if start == 1
            ProcessBar('Processing Start', 0, 1, 0);
        end
        if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
            delete(bar);
            return;
        end
        ProcessBar('Processing�F Check SLDD Variables DataType.', 0.3, 0, 0);
       %% �@ SLDD�̕ϐ��ƒ萔�̃f�[�^�^�`�F�b�N
        try
            myDictionaryObj = Simulink.data.dictionary.open(sldd_name);
            slddSection = myDictionaryObj.getSection('Design Data');
        catch
            warndlg('Can not load SLDD file. Please make sure SLDD file is added in matlab path.', 'WARNING', 'modal');
            if ishandle(bar)
                delete(bar);
                return;
            end
            return;
        end
        sldd_data = slddSection.find;
        flag_edit = 0;
        for i = 1: length(sldd_data)
            if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                delete(bar);
                return;
            end
            ProcessBar('Processing�F Check SLDD Variables DataType.', 0.3, 0, 0);
            sldd_data_info = sldd_data(i).getValue;
            switch(class(sldd_data_info))
              %% Simulink.Signal�Ampt.Signal�^�C�v�̏ꍇ
              %% Simulink.Parameter�Ampt.Parameter�^�C�v�̏ꍇ
                case {'Simulink.Signal', 'mpt.Signal', 'Simulink.Parameter', 'mpt.Parameter' }
                    if ~isempty(regexp(sldd_data_info.DataType, 'fixdt(', 'match'))
                        fixed_var_list{end + 1, 1} = sldd_data(i).Name;
                        fixed_var_list{end, 2} = 'SLDD �ϐ���';
                        fixed_var_list{end, 3} = sldd_data_info.DataType;
                        try
                            fixed_var_list{end, 4} = 'double';
                            sldd_data_info.DataType = 'double';
                            
                            sldd_data(i).setValue(sldd_data_info);
                            
                            flag_edit = 1;
                        catch
                            fixed_var_list{end, 4} = 'ERROR';
                            error_index(end + 1) = size(fixed_var_list, 1);
                        end
                    end
                otherwise
                    % nothing
            end
        end
        start = 0;
        if flag_edit == 1
            % ���b�Z�[�W���e�F�uDo you want to save SLDD info?�v
            ButtonName = questdlg('Do you want to save SLDD info?','Question','Yes','No','Yes');
            % No�A�~��I�����ꍇ�A������~
            if strcmp(ButtonName, 'Yes') || isempty(ButtonName)
                myDictionaryObj.saveChanges();
            end
        end
    end
    % ���f�����̏ꍇ
    if input_flag == 1
        if start == 1
            ProcessBar('Processing Start', 0, 1, 0);
        end
        if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
            delete(bar);
            return;
        end
        ProcessBar('Processing�F Check DataType Prameter of Block.', 0.5, 0, 0);
        %% �A ���f���̃u���b�N�̏o�̓f�[�^�^�`�F�b�N
        find_blks = find_system(model_name, 'FindAll', 'on', 'LookUnderMasks', 'all', 'type', 'block');
        if ~isempty(find_blks)
            for i = 1:length(find_blks)
                if strcmp(get_param(find_blks(i), 'MaskType'), 'MaskMonitor')
                    sprintf('Test');
                end
                if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                    delete(bar);
                    return;
                end
                ProcessBar('Processing�F Check DataType Prameter of Block.', 0.5, 0, 0);
                dialogParameter = get(find_blks(i), 'DialogParameter');
                if isempty(dialogParameter)
                    continue;
                end
                parameterNames = fieldnames(dialogParameter);
                if isempty(parameterNames)
                    continue;
                end
               % �E (3) ���͉\�p�����[�^�����X�g�̃p�����[�^�l���Ƃ̃`�F�b�N
               for j = 1: length(parameterNames)
                   % �E (3.1) �p�����[�^�^�C�v�擾
                   parameterType = eval('base', ['dialogParameter.' parameterNames{j} '.Type']);
                   % �E (3.2) �p�����[�^�_�C�����O�ɕ\�������擾
                   if ~strcmp(parameterType, 'string')
                       continue;
                   end
                   % DataTypeStr�̃p�����[�^�̏ꍇ
                   if ~isempty(regexp(parameterNames{j}, '\w*DataTypeStr\w*', 'match')) || ...
                      ~isempty(regexp(parameterNames{j}, '\w*DataType\w*', 'match'))     
                        paramValue = get_param(find_blks(i), parameterNames{j});
                        if ~isempty(regexp(paramValue, 'fixdt(', 'match'))
                            fixed_var_list{end + 1, 1} = MakePathBlock(find_blks(i));
                            fixed_var_list{end, 2} = 'Block Path';
                            fixed_var_list{end, 3} = paramValue;
                            try
                                fixed_var_list{end, 4} = 'double';

                                set_param(find_blks(i), parameterNames{j}, 'double');
                            catch
                                fixed_var_list{end, 4} = 'ERROR';
                                error_index(end + 1) = size(fixed_var_list, 1);
                            end
                        end                       
                   end
               end
            end
            start = 0;
        end
       %% �B Stateflow.Data�̃f�[�^�^�`�F�b�N
        if start == 1
            ProcessBar('Processing Start', 0, 1, 0);
        end
        if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
            delete(bar);
            return;
        end
        ProcessBar('Processing�F Check DataType Prameter of Stateflow Data.', 0.8, 0, 0);
        
        rt = sfroot;
        model = rt.find('Name', model_name, 'Parent', '');
        sf_data = model.find('-isa', 'Stateflow.Data');
        if ~isempty(sf_data)
            for i = 1: length(sf_data)
                if ~isempty(regexp(sf_data(i).DataType, 'fixdt(', 'match'))
                    fixed_var_list{end + 1, 1} = MakePathBlock(sf_data(i));
                    fixed_var_list{end, 2} = 'Stateflow Data';
                    fixed_var_list{end, 3} = sf_data(i).DataType;
                    try
                        fixed_var_list{end, 4} = 'double';

                        sf_data(i).DataType = 'double';
                    catch
                        fixed_var_list{end, 5} = 'ERROR';
                        error_index(end + 1) = size(fixed_var_list, 1);
                    end
                end  
            end
        end
    end
    if size(fixed_var_list, 1) > 1
        ProcessBar('Processing�F Waiting.', 1.0, 0, 0);
        % ���b�Z�[�W���e�F�uDo you want to export change info of DataType to excel?�v
        ButtonName = questdlg('Do you want to export change info of DataType to excel?','Question','Yes','No','Yes');
        % No�A�~��I�����ꍇ�A������~
        if strcmp(ButtonName, 'No') || isempty(ButtonName)
            ProcessBar('Processing�F Closing.', 1, 0, 1); 
            return;
        end
        ProcessBar('Processing�F Write Info to Excel.', 1, 0, 0);
        run_time = datestr(now, 'yyyy_mm_dd_HH_MM_ss');
        [file_name, file_path] = uiputfile('*.xlsx','Save file name');
        if isnumeric(file_name) && file_name == 0 
            ProcessBar('Processing�F Closing.', 1, 0, 1); 
            return;
        end
        xlswrite([ file_path '\' file_name ], fixed_var_list, run_time);
        e = actxserver('Excel.Application');
        eWorkbooks = e.Workbooks;
        exlFile = eWorkbooks.Open([ file_path '\' file_name ]);
        change_info_Sheet = exlFile.Sheets.Item(run_time);
        used_range = change_info_Sheet.UsedRange;
        for i = 1: length(error_index)
            try
                used_range.Rows.Item(error_index(i)).Font.ColorIndex = 3;
            catch
            end
        end
        used_range.Borders.LineStyle = 1;

        exlFile.Save;
        Quit(e);
        delete(e);
    end
    ProcessBar('Processing�F Closing.', 1, 0, 1); 
catch ex
    errordlg(ex.getReport, 'Error');
    if ishandle(bar)
        delete(bar);
        return;
    end
end
end

%% �u���b�N�p�X�A�X�e�[�g�t���[�̃p�X�쐬
function return_path = MakePathBlock(block_info)
    try
        if ishandle(block_info)
            try
                block_path = get(block_info, 'Parent');
            catch
                block_path = get(block_info, 'Path');
            end
            block_path = regexprep(block_path, '\n', ' ');
            block_name = get(block_info, 'Name');
            block_name = regexprep(block_name, '\n', ' ');
            return_path = [ block_path '/' block_name ];
            
        elseif isstruct(block_info)
            block_path = block_info.Parent;
            block_path = regexprep(block_path, '\n', ' ');
            block_name = block_info.Name;
            block_name = regexprep(block_name, '\n', ' ');
            return_path = [ block_path '/' block_name ];
        else
            return_path = block_info;
        end
    catch
        return_path = block_info;
    end
end

%% �v���Z�X�o�[�̏���
function ProcessBar(message, percent, open, close)
    global bar;
    try
       %% �@ �v���Z�X�o�[�̏�����
        if open == 1
            % �@ (1) waitbar�̊֐��ŏ��������s��
            bar = waitbar(0, message, 'CreateCancelBtn', 'setappdata(gcbf,''canceling'',1)');
       %% �A ���Ƀv���Z�X�o�[���쐬���ꂽ�ꍇ�A�v���Z�X�X�V���s��
        else
            if ishandle(bar)
                % �A (1) waitbar�̊֐��Ńp�[�Z���g�ƕ\��������e���X�V����
                waitbar(percent, bar, sprintf('%s', message));
            end
        end
       %% �B �N���[�Y�t���O��1�̏ꍇ�A�v���Z�X�o�[�����
        if close == 1
            delete(bar);
        end
    catch
        if ishandle(bar)
            delete(bar);
        end
    end
end
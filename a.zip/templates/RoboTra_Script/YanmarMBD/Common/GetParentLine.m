%% �e���C���n���h�����擾����
function parent_line = GetParentLine(line_handle)
    parent_line = [];
    get_parent_line = get_param(line_handle, 'LineParent');
    if size(get_parent_line, 1) == 1  && get_parent_line < 0
        parent_line = line_handle;
        return;
    end
    if iscell(get_parent_line)
        for i = 1:length(get_parent_line)
            if ishandle(get_parent_line{i}) && get_parent_line{i} > 0
                parent_line = GetParentLine(get_parent_line{i});
                if ~isempty(parent_line)
                    return;
                end
            end
        end
    else
        for i = 1:length(get_parent_line)
            if ishandle(get_parent_line(i)) && get_parent_line(i) > 0
                parent_line = GetParentLine(get_parent_line(i));
                if ~isempty(parent_line)
                    return;
                end
            end
        end
    end
end
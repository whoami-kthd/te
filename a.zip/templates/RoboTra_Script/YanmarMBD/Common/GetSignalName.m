function line_name = GetSignalName(line_handle)
    line_SrcBlock = get(line_handle, 'SrcBlockHandle');
    line_SrcPort = get(line_handle, 'SrcPortHandle');
    SignalPropagation = get(line_handle, 'SignalPropagation');
    if strcmp(SignalPropagation, 'on')
        line_name = get(line_SrcPort, 'PropagatedSignals');
        if isempty(line_name)
            line_name = '<>';
        end
    else
        line_name = get(line_handle, 'Name');
    end
end
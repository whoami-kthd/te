%% �`�F�b�N���ʂ����ʂ�uitable�ɕ\�����A�n�C�p�[�����N��t���邽�߁Ahtml�^�O��ǉ�����
function tb_result = MakeCheckResultDataToView(Check_ID, array_result)    
        if strcmp(Check_ID , 'ym_0003')
            tb_result = MakeResultData_0003(array_result);
        elseif strcmp(Check_ID , 'ym_0006')
            tb_result = MakeResultData_0006(array_result);
        elseif strcmp(Check_ID , 'ym_1006')
            tb_result = MakeResultData_1006_1007(array_result);
        elseif strcmp(Check_ID , 'ym_1007')    
            tb_result = MakeResultData_1006_1007(array_result);
        elseif strcmp(Check_ID , 'ym_1008')
            tb_result = MakeResultData_1008_1009(array_result);
        elseif strcmp(Check_ID , 'ym_1009')
            tb_result = MakeResultData_1008_1009(array_result);
        elseif strcmp(Check_ID , 'ym_1012')  
            tb_result = MakeResultData_1012(array_result);
        elseif strcmp(Check_ID , 'ym_1022')  
            tb_result = MakeResultData_Handle(array_result);
        elseif strcmp(Check_ID , 'ym_2004')  
            tb_result = MakeResultData_2004(array_result);
        elseif strcmp(Check_ID , 'ym_2005')  
            tb_result = MakeResultData_2005(array_result);
        elseif strcmp(Check_ID , 'ym_2008')  
            tb_result = MakeResultData_2008(array_result);       
        elseif strcmp(Check_ID , 'db_0043') || ...
           strcmp(Check_ID , 'jc_0008') || ...
           strcmp(Check_ID , 'jc_0009') || ...
           strcmp(Check_ID , 'jc_0245') || ...
           strcmp(Check_ID , 'jc_0251') || ...
           strcmp(Check_ID , 'jc_0602')
            tb_result = MakeResultData_Handle(array_result);
            
        elseif strcmp(Check_ID , 'jc_0061')
            
            tb_result = MakeResultData_jc_0061(array_result);
        elseif strcmp(Check_ID , 'jc_0232') || ...
               strcmp(Check_ID , 'jc_0246')
           
            tb_result = MakeResultData_jc_0232_0246_0251(array_result);
            
        elseif strcmp(Check_ID , 'jc_0701') || ...
               strcmp(Check_ID , 'jc_0712')
            tb_result = MakeResultData_jc_0701_0712(array_result);
            
        elseif strcmp(Check_ID , 'jc_0730') || ...
               strcmp(Check_ID , 'jc_0732')
            tb_result = MakeResultData_jc_0730_0732(array_result);
            
        elseif strcmp(Check_ID , 'jc_0735')
            tb_result = MakeResultData_jc_0735(array_result);
            
        elseif strcmp(Check_ID , 'jc_0751')
            tb_result = MakeResultData_jc_0751(array_result);
            
        elseif strcmp(Check_ID , 'jc_0772')
            tb_result = MakeResultData_jc_0772(array_result);
            
        elseif strcmp(Check_ID , 'na_0004')
            tb_result = MakeResultData_na_0004(array_result);
            
        elseif strcmp(Check_ID , 'jc_0723')
            tb_result = MakeResultData_jc_0723(array_result);
            
        elseif strcmp(Check_ID , 'jc_0801')
            tb_result = MakeResultData_jc_0801(array_result);
            
        else
            tb_result = MakeResultData(array_result);
        end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% �`�F�b�N���ʍ쐬 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function result = MakeResultData_0003(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            try
                if isempty(error_block{i, 3}.Name)
                    try
                        msg_path = [ error_block{i, 3}.Path '/(SSID =' num2str(error_block{i, 5}) ')' ];
                    catch
                        msg_path = [ error_block{i, 3}.Path '/Stateflow.Box' ];
                    end
                else
                    msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
                end
            catch
                try
                    msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Type '(SSID =' num2str(error_block{i, 5}) ')' ];
                catch
                    msg_path = [ error_block{i, 3}.Path '/Transition(SSID =' num2str(error_block{i, 5}) ')'  ];
                end
            end
            try
                address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"',...
                                    error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
            catch
                address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"',...
                                    error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5}.Id);
            end
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_2005(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path = error_block{i, 1};
        address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end


function result = MakeResultData_jc_0723(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path_1 = error_block{i, 1};
        msg_path_2 = error_block{i, 2};
        
        path_split =  strsplit(error_block{i, 3}, '/');
        model_name = path_split{1};
        address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', model_name, error_block{i, 3}, error_block{i, 4});        
                
        result{end + 1, 1} = sethyperlink(address, msg_path_1);
        result{end, 2} = sethyperlink(address, msg_path_2);  
    end
end

function result = MakeResultData_jc_0801(error_block)
   result = {};
    if isempty(error_block)
        return;
    end
    
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        result{end + 1} = error_block{i, 1};
    end
    result = result';
end

function result = MakeResultData_0006(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path = error_block{i, 1};
        address = sprintf('"hilite_line(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}, error_block{i, 4});
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_1006_1007(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path_1 = error_block{i, 1};
        msg_path_2 = error_block{i, 3};
        address = sprintf('"hilite_2block(''%s'', ''%s'')"', error_block{i, 1}, error_block{i, 3});
        result{end + 1, 1} = sethyperlink(address, msg_path_1);
        result{end, 2} = sethyperlink(address, msg_path_2);
    end
end

function result = MakeResultData_1008_1009(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    mask_list = {
        'Unit Delay With Preview Enabled'
        'Unit Delay With Preview Enabled Resettable'
        'Unit Delay With Preview Enabled Resettable External RV'
        'Unit Delay With Preview Resettable'
        'Unit Delay With Preview Resettable External RV'
    };
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path = error_block{i, 1};
        mask_type = get_param(error_block{i, 1}, 'MaskType');
        if strcmp(get_param(error_block{i, 1}, 'BlockType'), 'Inport')
            address = sprintf('"hilite_line(''%s'', ''%s'', 1)"', error_block{i, 1}, 'in');
        elseif strcmp(get_param(error_block{i, 1}, 'BlockType'), 'Outport')
            address = sprintf('"hilite_line(''%s'', ''%s'', 1)"', error_block{i, 1}, 'out');
        else
            if ismember(mask_type, mask_list)
                address = sprintf('"hilite_line(''%s'', ''%s'', 2)"', error_block{i, 1}, 'in');
            else
                address = sprintf('"hilite_line(''%s'', ''%s'', 1)"', error_block{i, 1}, 'in');
            end
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_1012(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            if isempty(error_block{i, 3}.Name)
                msg_path = [ error_block{i, 3}.Path '/EMFunction(SSID =' num2str(error_block{i, 5}) ')' ];
            else
                msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
            end
            address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_2004(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            if isempty(error_block{i, 3}.Name)
                msg_path = [ error_block{i, 3}.Path '/Event(SSID =' num2str(error_block{i, 5}) ')' ];
            else
                msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
            end
            address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_2008(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            if isempty(error_block{i, 3}.Name)
                msg_path = [ error_block{i, 3}.Path '/Parameter(SSID =' num2str(error_block{i, 5}) ')' ];
            else
                msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
            end
            address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_Handle(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    %(mdl_name, type, errblock, blkHandle_SSID), ...
     %           error_block(2:end, 1), error_block(2:end, 2), error_block(2:end, 3), error_block(2:end, 5));
     error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path = error_block{i, 1};
        address = sprintf('"hilite_block(%10.30f)"', error_block{i, 2});
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_jc_0232_0246_0251(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    %(mdl_name, type, errblock, blkHandle_SSID), ...
     %           error_block(2:end, 1), error_block(2:end, 2), error_block(2:end, 3), error_block(2:end, 5));
     error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path = error_block{i, 1};
        address = sprintf('"hilite_block(''%s'')"', MakePathBlock(error_block{i, 2}));
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_jc_0701_0712(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            if isempty(error_block{i, 3}.Name)
                msg_path = [ error_block{i, 3}.Path '/Data(SSID =' num2str(error_block{i, 5}) ')' ];
            else
                msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
            end
            address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_jc_0730_0732(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            if isempty(error_block{i, 3}.Name)
                msg_path = [ error_block{i, 3}.Path '/State(SSID =' num2str(error_block{i, 5}) ')' ];
            else
                msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
            end
            address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_jc_0735(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            try
                if isempty(error_block{i, 3}.Name)
                    msg_path = [ error_block{i, 3}.Path '/State(SSID =' num2str(error_block{i, 5}) ')' ];
                else
                    msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
                end
            catch
                msg_path = [ error_block{i, 3}.Path '/Transition(SSID =' num2str(error_block{i, 5}) ')' ];
            end
            
            address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_jc_0751(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            try
                if isempty(error_block{i, 3}.Name)
                    msg_path = [ error_block{i, 3}.Path '/Junction(SSID =' num2str(error_block{i, 5}) ')' ];
                else
                    msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
                end
            catch
                msg_path = [ error_block{i, 3}.Path '/Junction(SSID =' num2str(error_block{i, 5}) ')' ];
            end
            address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_jc_0772(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i, 2}, 'Simulink')
            msg_path = error_block{i, 3};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 3});
        else
            try
                if isempty(error_block{i, 3}.Name)
                    msg_path = [ error_block{i, 3}.Path '/State(SSID =' num2str(error_block{i, 5}) ')' ];
                else
                    msg_path = [ error_block{i, 3}.Path '/' error_block{i, 3}.Name ];
                end
            catch
                msg_path = [ error_block{i, 3}.Path '/Junction(SSID =' num2str(error_block{i, 5}) ')' ];
            end
            address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %d)"', error_block{i, 1}, error_block{i, 3}.Path, error_block{i, 5});
        end
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end

function result = MakeResultData_jc_0061(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    colorgen = @(color,text) ['<html><table border=0 width=400 bgcolor=',color,'><TR><TD>',text,'</TD></TR> </table></html>'];
    %(mdl_name, type, errblock, blkHandle_SSID), ...
     %           error_block(2:end, 1), error_block(2:end, 2), error_block(2:end, 3), error_block(2:end, 5));
     error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(error_block{i,1}, '�ȉ��̃u���b�N�����\�����Ă��܂���') || ...
            strcmp(error_block{i,1}, '�ȉ��̃u���b�N�͐����I�Ȗ��O�������Ă��܂����A���O�͔�\���ł�') || ...
            strcmp(error_block{i,1}, '�ȉ��̃u���b�N�͕\������閼�O�������Ă��܂����A���O�͐����I�ł͂���܂���')
            msg_path = error_block{i, 1};
            result{end + 1} = colorgen('#55FFFF', msg_path);
        elseif strcmp(error_block{i,1}, '�p�X')
            msg_path = error_block{i, 1};
            result{end + 1} = msg_path;
        else
            msg_path = error_block{i, 1};
            address = sprintf('"hilite_block(''%s'')"', error_block{i, 1});
            result{end + 1} = sethyperlink(address, msg_path);
        end
    end
    result = result';
end

function result = MakeResultData_na_0004(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path = error_block{i, 1};
        address = sprintf('"hilite_block(''%s'')"', error_block{i, 1});
        result{end + 1, 1} = sethyperlink(address, msg_path);
        result{end, 2} = error_block{i, 3};
        result{end, 3} = error_block{i, 5};
        result{end, 4} = error_block{i, 6};
    end
    result = result;
end

function result = MakeResultData(error_block)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    %(mdl_name, type, errblock, blkHandle_SSID), ...
     %           error_block(2:end, 1), error_block(2:end, 2), error_block(2:end, 3), error_block(2:end, 5));
     error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        msg_path = error_block{i, 1};
        address = sprintf('"hilite_block(''%s'')"', error_block{i, 1});
        result{end + 1} = sethyperlink(address, msg_path);
    end
    result = result';
end
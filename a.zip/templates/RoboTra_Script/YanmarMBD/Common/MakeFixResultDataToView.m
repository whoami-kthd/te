%% �C�����ʂ����ʂ�uitable�ɕ\�����A�n�C�p�[�����N��t���邽�߁Ahtml�^�O��ǉ�����
function result = MakeFixResultDataToView(error_block, check_id)
    result = {};
    if isempty(error_block)
        return;
    end
    sethyperlink = @(hyperlink,text) ['<html><table border=0 width=400 <a href=',hyperlink,'>',text,'</a></table></html>'];
    
    error_block = error_block(2:end, 1:end);
    for i = 1: size(error_block, 1)
        if strcmp(check_id, 'ym_2008')
            msg_path = error_block{i, 1};
            try
                address = sprintf('"hilite_stateflow_object(''%s'', ''%s'', %10.30f)"', error_block{i, 5}, error_block{i, 6}, error_block{i, 7});
            catch
                address = '';
            end
        elseif strcmp(check_id, 'ym_0007') || strcmp(check_id, 'ym_1022')
            if ~ishandle(error_block{i, 1})
                msg_path = error_block{i, 1};
                try
                    address = sprintf('"hilite_block(%10.30f)"', get_param(error_block{i, 1}, 'handle'));
                catch
                    address = '';
                end
            else
                error_name = get(error_block{i, 1}, 'Name');
                try
                    error_path = get(error_block{i, 1}, 'Parent');
                catch
                    error_path = '';
                end
                if ~isempty(error_path)
                    msg_path = [ error_path '/' error_name ];
                else
                    msg_path = error_name;
                end
                address = sprintf('"hilite_block(%10.30f)"', error_block{i, 1});
            end
        else
            msg_path = error_block{i, 1};
            if isnumeric(error_block{i, 1})
                address = sprintf('"hilite_block(''%s'')"', MakePathBlock(error_block{i, 1}));
            else
                address = sprintf('"hilite_block(''%s'')"', error_block{i, 1});
            end
        end
        result{end + 1, 1} = sethyperlink(address, msg_path);
        for j = 2:size(error_block, 2)
            result{end, j} = error_block{i, j};
        end
    end
    if strcmp(check_id, 'ym_2008')
        result(:,7) = [];
        result(:,6) = [];
        result(:,5) = [];
    end
end
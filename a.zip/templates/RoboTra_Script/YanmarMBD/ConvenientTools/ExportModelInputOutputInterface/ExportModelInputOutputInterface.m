%% �֐����FExportModelInputOutputInterface
%  �T�v�F
%       SLDD���烂�f���̓��o�̓C���^�[�t�F�[�X��Excel�t�@�C���ɏo�͂���
%  �p�����[�^�F 
%        model_info: 
%           [1] Model Handle
%           [2] Model Name
%           [3] Is Top Layer
%           [4] SLDD Name
%           [5] Is Load
%       isRunFromRunAcg�FRunAcg������s����ꍇ��1�A����ȊO��0
%  �߂��l�F�@
%        result�F
%           0�F�ُ�I��
%           1�F����I��
%           2�F���[�U�[�ɂ��I��
%  �쐬�ҁF LOC
%  �쐬���F 2017/05/15
function result = ExportModelInputOutputInterface(model_info, isRunFromRunAcg, hasCheckNonUsedVariables, ModelInterfaceFile)
    global bar;
    global child_parent_sldd_info;
    result = 1;
    child_parent_sldd_info = {};
    if nargin <= 2
        hasCheckNonUsedVariables = 0;
    end
    %% �@ Excel�t�@�C�����o�͂�����I������_�C�����O��\������
    %     �u�L�����Z���v�A�u�~�v�{�^����I������ꍇ�A������~
    %     �u�ۑ��v�{�^����I������ꍇ�A�I�������t�H���_�ƃt�@�C�������擾����
    if isRunFromRunAcg == 1 && nargin >= 4 && length(ModelInterfaceFile) == 2
        file_path = ModelInterfaceFile{1};
        file_name = ModelInterfaceFile{2};
    else
        [file_name, file_path] = uiputfile('*.xlsx;*.xlsm','Save file name');
        if isnumeric(file_name) && file_name == 0 
            result = 2;
            return;
        end
    end
    %% �A ����[1]����ASLDD���̃��X�g�쐬
    if ischar(model_info(1:end, 4))
        sldd_filename_lst = { model_info(1:end, 4) };
        model_handle_lst = model_info(1:end, 1);
        model_name_lst = model_info(1:end, 2);
    else
        sldd_filename_lst = model_info(1:end, 4);
        model_handle_lst = model_info(1:end, 1);
        model_name_lst = model_info(1:end, 2);
    end
    %% �B SLDD���烂�f���̓��o�̓C���^�[�t�F�[�X��Excel�t�@�C���ɏo�͂���z��f�[�^�̍\���쐬
    [ in_out_signal_info, parameter_info, aliastype_info, enum_info, notExportDataName ] = MakeStructureOutputOfModelInterface();
    enum_info_temp = {};
    enum_info_temp{end + 1, 1} = ''; 
    enum_info_temp{end, 2} = '';
    enum_info_temp{end, 3} = '';
    enum_info_temp{end, 4} = '';
    enum_info_temp{end + 1, 1} = '';
    %% �C ����Enum�ϐ����̏�񂪈Ⴄ�����`�F�b�N���邽�߂̔z��쐬
    enum_info_check_diff = enum_info_temp;
    enum_info_check_diff{1, 1} = 'Confidential';
    enum_info_check_diff{2, 1} = 'Name';
    enum_info_check_diff{2, 2} = 'Enumerals';
    enum_info_check_diff{2, 3} = 'DefaultValue';
    enum_info_check_diff{2, 4} = 'StorageType';
    enum_info_check_diff{2, 5} = 'DataScope';
    enum_info_check_diff{2, 6} = 'HeaderFile';
    enum_info_check_diff{2, 7} = 'AddClassNameToEnumNames';
    enum_info_check_diff{2, 8} = 'Description';
    enum_info_check_diff{2, 9} = 'DataSource';
    run_time = datestr(now, 'yyyy/mm/dd HH:MM:ss');
    %% �D SLDD���̃��X�g��SLDD�����ƂɈȉ��̏������s��
    for i = 1:length(sldd_filename_lst)
        %% �D (1)���f����SLDD��t���Ȃ��ꍇ�A�������΂�
        if isempty(sldd_filename_lst{i})
            continue;
        end
        %% �D (2) ���ɏ�������SLDD�͏������Ȃ�
        if i > 1
            if (i == 2 && strcmp(sldd_filename_lst{1}, sldd_filename_lst{2})) || ...
               ismember(sldd_filename_lst{i}, sldd_filename_lst(1:i-1))
               continue;
            end
        end
        %% �D (3) SLDD�t�@�C������SLDD���擾
        try
            child_parent_sldd_info_temp = {};
            myDictionaryObj = Simulink.data.dictionary.open(sldd_filename_lst{i});
            slddSection = myDictionaryObj.getSection('Design Data');
            child_parent_sldd_info_temp{end +1, end + 1} = sldd_filename_lst{i};
            for j = 1:length(myDictionaryObj.DataSources)
                child_parent_sldd_info_temp{end +1, end} = myDictionaryObj.DataSources{j};
            end
        catch
            warndlg('Can not load SLDD file. Please make sure SLDD file is added in matlab path.', 'WARNING', 'modal');
            result = 0;
            return;
        end
        child_parent_sldd_info{end +1} = child_parent_sldd_info_temp;
        %% �D (4) SLDD���擾��SLDD�̑S�ăf�[�^���擾
        sldd_data = slddSection.find;
        %% �D (5) �f�[�^�����Ƃ�SLDD���擾�Ńf�[�^�����擾���AExcel�t�@�C���ɏo�͂���z��f�[�^�쐬
        for j = 1: length(sldd_data)
            try
               %% ProcessBar�X�V��------------------------------------------------��
                if j == 1
                    ProcessBar('Processing Start', 0, 1, 0);
                end
                if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                    delete(bar);
                    result = 2;
                    return;
                end
                percent = j/length(sldd_data);
                ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(regexprep(sldd_filename_lst{i}, '_', ' '), '_', ' ')), percent, 0, 0);
               %% ProcessBar�X�V��------------------------------------------------��
               %% �ڍ׏��擾
                sldd_data_info = sldd_data(j).getValue;
                hasData = 0;
                switch(class(sldd_data(j).getValue))
                  %% Simulink.Signal�^�C�v�̏ꍇ
                  %% mpt.Signal�^�C�v�̏ꍇ
                    case {'Simulink.Signal', 'mpt.Signal' }
                        % ���Ƀf�[�^�������݂���ꍇ�ADataSource�������ł���΁A�o�͏��ɒǉ����Ȃ�
                        if size(in_out_signal_info, 1) > 2 && ...
                           ismember(sldd_data(j).Name, in_out_signal_info(3:end, 3))
                       
                           isContinute = 0;
                           [search_index] = find(strcmp(sldd_data(j).Name, in_out_signal_info(3:end, 3)));
                           if length(search_index) == 1
                                index = search_index + 2;
                                if strcmp(sldd_data(j).DataSource, in_out_signal_info{index, 26})
                                    isContinute = 1;
                                end
                                hasData = 1; 
                           else
                                for k = 1: length(search_index)
                                    index = search_index(k) + 2;
                                    if strcmp(sldd_data(j).DataSource, in_out_signal_info{index, 26})
                                        isContinute = 1;
                                        break;
                                    end
                                    hasData = 1;
                                end
                           end
                           if isContinute == 1
                            %% ProcessBar�X�V��------------------------------------------------��
                                if j == length(sldd_data)
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                end
                            %% ProcessBar�X�V��------------------------------------------------��
                                continue;
                           end
                        end
                        
                        % �ǉ�����
                        in_out_signal_info{end + 1, 1} = run_time; 
                        % �X�V����
                        in_out_signal_info{end, 2} = ''; 
                        % Name
                        in_out_signal_info{end, 3} = sldd_data(j).Name;
                     %% Inport/Outport
                        if ishandle(model_info{i,1}) && model_info{i, 3} == 1
                            find_blks = find_system(model_info{i,1}, 'SearchDepth', '1', 'FindAll', 'on', ...
                                    'RegExp', 'on', 'Type', 'Block', 'BlockType', 'Inport|Outport', 'Name', sldd_data(j).Name);
                            if ~isempty(find_blks)
                                hasBlock = 0;
                                for k = 1: length(find_blks)
                                    if strcmp(get(find_blks(k), 'Name'), sldd_data(j).Name) && ...
                                       (strcmp(get(find_blks(k), 'BlockType'), 'Inport')|| ...
                                        strcmp(get(find_blks(k), 'BlockType'), 'Outport'))
                                    
                                        in_out_signal_info{end, 4} = get_param(find_blks(k), 'BlockType');
                                        hasBlock = 1;
                                        break;
                                    end
                                end
                                if hasBlock == 0
                                    in_out_signal_info{end, 4} = '';
                                end
                            else
                                in_out_signal_info{end, 4} = '';
                            end
                        else
                            in_out_signal_info{end, 4} = '';
                        end
                     %%
                        % Class 
                        in_out_signal_info{end, 5} = class(sldd_data(j).getValue);
                        % StorageClass
                        in_out_signal_info{end, 6} = sldd_data_info.CoderInfo.StorageClass;
                        % Alias
                        in_out_signal_info{end, 7} = sldd_data_info.CoderInfo.Alias;
                        % Alignment
                        in_out_signal_info{end, 8} = sldd_data_info.CoderInfo.Alignment;
                        % CustomStorageClass
                        in_out_signal_info{end, 9} = sldd_data_info.CoderInfo.CustomStorageClass;
                        % CustomAttributes.MemorySection
                        in_out_signal_info{end, 10} = GetCustomAttributesPropertyValue(sldd_data_info, 'MemorySection');
                        % CustomAttributes.HeaderFile
                        in_out_signal_info{end, 11} = GetCustomAttributesPropertyValue(sldd_data_info, 'HeaderFile');
                        % CustomAttributes.Owner
                        in_out_signal_info{end, 12} = GetCustomAttributesPropertyValue(sldd_data_info, 'Owner');
                        % CustomAttributes.DefinitionFile
                        in_out_signal_info{end, 13} = GetCustomAttributesPropertyValue(sldd_data_info, 'DefinitionFile');
                        % CustomAttributes.ConcurrentAccess
                        in_out_signal_info{end, 14} = GetCustomAttributesPropertyValue(sldd_data_info, 'ConcurrentAccess');
                        % CustomAttributes.PersistenceLevel
                        in_out_signal_info{end, 15} = GetCustomAttributesPropertyValue(sldd_data_info, 'PersistenceLevel');
                        % Description
                        in_out_signal_info{end, 16} = sldd_data_info.Description;
                        % DataType
                        in_out_signal_info{end, 17} = sldd_data_info.DataType;
                        % Min
                        in_out_signal_info{end, 18} = sldd_data_info.Min;
                        % Max
                        in_out_signal_info{end, 19} = sldd_data_info.Max;
                        % DocUnits
                        in_out_signal_info{end, 20} = sldd_data_info.DocUnits;
                        % Dimensions
                        in_out_signal_info{end, 21} = sldd_data_info.Dimensions;
                        % DimensionsMode
                        in_out_signal_info{end, 22} = sldd_data_info.DimensionsMode;
                        % Complexity
                        in_out_signal_info{end, 23} = sldd_data_info.Complexity;
                        % SampleTime
                        in_out_signal_info{end, 24} = sldd_data_info.SampleTime;
                        % SamplingMode
                        in_out_signal_info{end, 25} = sldd_data_info.SamplingMode;
                        % InitialValue
                        in_out_signal_info{end, 26} = sldd_data_info.InitialValue;
                        % DataSource
                        in_out_signal_info{end, 27} = sldd_data(j).DataSource;
                     %% Check Diff Variable
                        if hasData == 1
                            for k = 1: length(search_index)
                                index = search_index(k) + 2;
                                if ~isequal(in_out_signal_info{end, 5} , in_out_signal_info{index, 5}) || ...
                                    ~isequal(in_out_signal_info(end, 7:8) , in_out_signal_info(index, 7:8)) || ...
                                   ~isequal(in_out_signal_info(end, 17:26) , in_out_signal_info(index, 17:26))
                                   %~isequal(in_out_signal_info(end, 10:15) , in_out_signal_info(index, 10:15)) || ...
                                    error_file_name = [ 'diffvariable_error_' datestr(now, 'yyyy_mm_dd_HH_MM_ss') '.xlsx' ];
                                    warndlg(sprintf(['Contents of the same variable names is difference. Process is stopped.\n' ...
                                                    'Please check these variables info in �u%s�vand try again:\n' ...
                                                    '[Var 1] Name:%s. DataSource:%s\n'...
                                                    '[Var 2] Name:%s. DataSource:%s'], ...
                                                    error_file_name, ...
                                                    in_out_signal_info{index, 3}, in_out_signal_info{index, 27}, ...
                                                    in_out_signal_info{end, 3}, in_out_signal_info{end, 27} ...
                                                    ))
                                     diff_info = in_out_signal_info(1:2, 1:end);
                                     diff_info(end + 1, 1:end) =  in_out_signal_info(index, 1:end);
                                     diff_info(end + 1, 1:end) =  in_out_signal_info(end, 1:end);
                                     for l = 1: 2
                                         for h = 4:size(diff_info, 2)
                                             if isnumeric(diff_info{l + 2, h}) || islogical(diff_info{l + 2, h})
                                                 diff_info{l + 2, h} = num2str(diff_info{l + 2, h});
                                             end
                                         end
                                     end
                                     diff_index = [];           
                                     if ~isequal(diff_info{3, 5} , diff_info{4, 5})
                                         diff_index(end + 1) = 5;
                                     end
                                     if ~isequal(diff_info(3, 7:8) , diff_info(4, 7:8))
                                         for l = 1: length(diff_info(4, 7:8))
                                             if ~ismember(diff_info{3, l + 6}, diff_info(4, 7:8))
                                                 diff_index(end + 1) = l + 6;
                                             end
                                         end
                                     end
%                                      if ~isequal(diff_info(3, 10:15) , diff_info(4, 10:15))
%                                          for l = 1: length(diff_info(3, 10:15))
%                                              if ~ismember(diff_info{3, l + 9}, diff_info(4, 10:15))
%                                                  diff_index(end + 1) = l + 9;
%                                              end
%                                          end
%                                      end
                                     if ~isequal(diff_info(3, 17:26) , diff_info(4, 17:26))
                                         for l = 1: length(diff_info(4, 17:26))
                                             if ~ismember(diff_info{3, l + 16}, diff_info(4, 17:26))
                                                 diff_index(end + 1) = l + 16;
                                             end
                                         end
                                     end
                                     xlswrite([ file_path '\' error_file_name ], diff_info);
                                     e = actxserver('Excel.Application');
                                     eWorkbooks = e.Workbooks;
                                     exlFile = eWorkbooks.Open([ file_path '\' error_file_name ]);
                                     diff_info_Sheet = exlFile.Sheets.Item('Sheet1');
                                     for l = 1: length(diff_index)
                                         diff_info_range = diff_info_Sheet.Range([ GetColumnName(diff_index(l)) '3:' GetColumnName(diff_index(l)) '4']);
                                         diff_info_range.Font.ColorIndex = 3;
                                     end
                                     diff_info_range = diff_info_Sheet.UsedRange;
                                     diff_info_range.WrapText = 0;
                                     exlFile.Save;
                                     Quit(e);
                                     delete(e);
                                     e = [];
                                %% ProcessBar�X�V��------------------------------------------------��
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                %% ProcessBar�X�V��------------------------------------------------��            
                                    result = 0;
                                    return;
                                end
                            end
                        end
               %% Simulink.Parameter�Ampt.Parameter�^�C�v�̏ꍇ
                case { 'Simulink.Parameter', 'mpt.Parameter' }
                        % ���Ƀf�[�^�������݂���ꍇ�ADataSource�������ł���΁A�o�͏��ɒǉ����Ȃ�
                        if size(parameter_info, 1) > 2 && ...
                           ismember(sldd_data(j).Name, parameter_info(3:end, 3))
                       
                           isContinute = 0;
                           [search_index] = find(strcmp(sldd_data(j).Name, parameter_info(3:end, 3)));
                           if length(search_index) == 1
                                index = search_index + 2;
                                if strcmp(sldd_data(j).DataSource, parameter_info{index, 15})
                                    isContinute = 1;
                                end
                                hasData = 1;
                           else
                                for k = 1: length(search_index)
                                    index = search_index(k) + 2;
                                    if strcmp(sldd_data(j).DataSource, parameter_info{index, 15})
                                        isContinute = 1;
                                        break;
                                    end
                                    hasData = 1;
                                end
                           end
                           if isContinute == 1
                            %% ProcessBar�X�V��------------------------------------------------��
                                if j == length(sldd_data)
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                end
                            %% ProcessBar�X�V��------------------------------------------------��
                                continue;
                           end
                        end
                        % �ǉ�����
                        parameter_info{end + 1, 1} = run_time; 
                        % �X�V����
                        parameter_info{end, 2} = ''; 
                        % Name
                        parameter_info{end, 3} = sldd_data(j).Name;
                        % Value
                        parameter_info{end, 4} = sldd_data_info.Value;
                        % Class
                        parameter_info{end, 5} = class(sldd_data(j).getValue);
                        % CoderInfo.StorageClass
                        parameter_info{end, 6} = sldd_data_info.CoderInfo.StorageClass;
                        % CoderInfo.Alias
                        parameter_info{end, 7} = sldd_data_info.CoderInfo.Alias;
                        % CoderInfo.Alignment
                        parameter_info{end, 8} = sldd_data_info.CoderInfo.Alignment;
                        % CoderInfo.CustomStorageClass
                        parameter_info{end, 9} = sldd_data_info.CoderInfo.CustomStorageClass;
%                         % CoderInfo.CustomAttributes.ConcurrentAccess
%                         parameter_info{end, 10} = GetCustomAttributesPropertyValue(sldd_data_info, 'ConcurrentAccess');
                        % CustomAttributes.MemorySection
                        parameter_info{end, 10} = GetCustomAttributesPropertyValue(sldd_data_info, 'MemorySection');
                        % CustomAttributes.HeaderFile
                        parameter_info{end, 11} = GetCustomAttributesPropertyValue(sldd_data_info, 'HeaderFile');
                        % CustomAttributes.Owner
                        parameter_info{end, 12} = GetCustomAttributesPropertyValue(sldd_data_info, 'Owner');
                        % CustomAttributes.DefinitionFile
                        parameter_info{end, 13} = GetCustomAttributesPropertyValue(sldd_data_info, 'DefinitionFile');
                        % CustomAttributes.ConcurrentAccess
                        parameter_info{end, 14} = GetCustomAttributesPropertyValue(sldd_data_info, 'ConcurrentAccess');
                        % CustomAttributes.PersistenceLevel
                        parameter_info{end, 15} = GetCustomAttributesPropertyValue(sldd_data_info, 'PersistenceLevel');
                        % Description
                        parameter_info{end, 16} = sldd_data_info.Description;
                        % DataType
                        parameter_info{end, 17} = sldd_data_info.DataType;
                        % Min
                        parameter_info{end, 18} = sldd_data_info.Min;
                        % Max
                        parameter_info{end, 19} = sldd_data_info.Max;
                        % DocUnits
                        parameter_info{end, 20} = sldd_data_info.DocUnits;
                        % DataSource
                        parameter_info{end, 21} = sldd_data(j).DataSource;
                     %% Check Diff Variable
                        if hasData == 1
%                             for k = 1: length(search_index)
%                                  index = search_index(k) + 2;
%                                  diff_info = parameter_info(1:2, 1:end);
%                                  diff_info(end + 1, 1:end) =  parameter_info(index, 1:end);
%                                  diff_info(end + 1, 1:end) =  parameter_info(end, 1:end);
%                             end
%                             diff_index = 3;
%                             error_file_name = [ 'diffvariable_error_' datestr(now, 'yyyy_mm_dd_HH_MM_ss') '.xlsx' ];
% 
%                             warndlg(sprintf(['Parameters are defined with duplicate in SLDD. Process is stopped.\n' ...
%                                             'Please check Parameters info in �u%s�vand try again\n' ], ...
%                                             error_file_name ...
%                                             )); 
%                              xlswrite([ file_path '\' error_file_name ], diff_info);
%                              e = actxserver('Excel.Application');
%                              eWorkbooks = e.Workbooks;
%                              exlFile = eWorkbooks.Open([ file_path '\' error_file_name ]);
%                              diff_info_Sheet = exlFile.Sheets.Item('Sheet1');
%                              for l = 1: length(diff_index)
%                                  diff_info_range = diff_info_Sheet.Range([ GetColumnName(diff_index(l)) '3:' GetColumnName(diff_index(l)) '4']);
%                                  diff_info_range.Font.ColorIndex = 3;
%                              end
%                              diff_info_range = diff_info_Sheet.UsedRange;
%                              diff_info_range.WrapText = 0;
%                              exlFile.Save;
%                              Quit(e);
%                              delete(e);
%                         %% ProcessBar�X�V��------------------------------------------------��
%                              ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
%                         %% ProcessBar�X�V��------------------------------------------------��            
%                             result = 0;
%                             return;
                            for k = 1: length(search_index)
                                index = search_index(k) + 2;
                                if ~isequal(parameter_info(end, 4:5) , parameter_info(index, 4:5)) || ...
                                    ~isequal(parameter_info(end, 7:8) , parameter_info(index, 7:8)) || ...
                                    ~isequal(parameter_info(end, 17:20) , parameter_info(index, 17:20))
                                    %~isequal(parameter_info{end, 10} , parameter_info{index, 10}) || ...
                                        
                                    error_file_name = [ 'diffvariable_error_' datestr(now, 'yyyy_mm_dd_HH_MM_ss') '.xlsx' ];
                                    warndlg(sprintf(['Contents of the same variable names is difference. Process is stopped.\n' ...
                                                    'Please check these variables info in �u%s�vand try again:\n' ...
                                                    '[Var 1] Name:%s. DataSource:%s\n'...
                                                    '[Var 2] Name:%s. DataSource:%s'], ...
                                                    error_file_name, ...
                                                    parameter_info{index, 3}, parameter_info{index, 21}, ...
                                                    parameter_info{end, 3}, parameter_info{end, 21} ...
                                                    ));
                                     diff_info = parameter_info(1:2, 1:end);
                                     diff_info(end + 1, 1:end) =  parameter_info(index, 1:end);
                                     diff_info(end + 1, 1:end) =  parameter_info(end, 1:end);
                                     for l = 1: 2
                                         for h = 4:size(diff_info, 2)
                                             if isnumeric(diff_info{l + 2, h}) || islogical(diff_info{l + 2, h})
                                                 diff_info{l + 2, h} = num2str(diff_info{l + 2, h});
                                             end
                                         end
                                     end
                                     diff_index = [];           
                                     if ~isequal(diff_info{3, 4} , diff_info{4, 4}) 
                                         diff_index(end + 1) = 4;
                                     end
                                     if ~isequal(diff_info{3, 5} , diff_info{4, 5}) 
                                         diff_index(end + 1) = 5;
                                     end
                                     if ~isequal(diff_info(3, 7:8) , diff_info(4, 7:8)) 
                                         for l = 1: length(diff_info(3, 7:8))
                                             if ~ismember(diff_info{3, l + 6}, diff_info(4, 7:8))
                                                 diff_index(end + 1) = l + 6;
                                             end
                                         end
                                     end
%                                      if ~isequal(diff_info{3, 10} , diff_info{4, 10}) 
%                                          diff_index(end + 1) = 10;
%                                      end
                                     if ~isequal(diff_info(3, 17:20) , diff_info(4, 17:20))
                                         for l = 1: length(diff_info(4, 17:20))
                                             if ~ismember(diff_info{3, l + 16}, diff_info(4, 17:20))
                                                 diff_index(end + 1) = l + 16;
                                             end
                                         end
                                     end
                                     xlswrite([ file_path '\' error_file_name ], diff_info);
                                     e = actxserver('Excel.Application');
                                     eWorkbooks = e.Workbooks;
                                     exlFile = eWorkbooks.Open([ file_path '\' error_file_name ]);
                                     diff_info_Sheet = exlFile.Sheets.Item('Sheet1');
                                     for l = 1: length(diff_index)
                                         diff_info_range = diff_info_Sheet.Range([ GetColumnName(diff_index(l)) '3:' GetColumnName(diff_index(l)) '4']);
                                         diff_info_range.Font.ColorIndex = 3;
                                     end
                                     diff_info_range = diff_info_Sheet.UsedRange;
                                     diff_info_range.WrapText = 0;
                                     exlFile.Save;
                                     Quit(e);
                                     delete(e);
                                     e = [];
                                %% ProcessBar�X�V��------------------------------------------------��
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                %% ProcessBar�X�V��------------------------------------------------��            
                                    result = 0;
                                    return;
                                end
                            end
                        end
                  %% Simulink.AliasType�^�C�v�̏ꍇ
                    case 'Simulink.AliasType'
                        % ���Ƀf�[�^�������݂���ꍇ�ADataSource�������ł���΁A�o�͏��ɒǉ����Ȃ�
                        if size(aliastype_info, 1) > 2 && ...
                           ismember(sldd_data(j).Name, aliastype_info(3:end, 3))
                       
                           isContinute = 0;
                           [search_index] = find(strcmp(sldd_data(j).Name, aliastype_info(3:end, 3)));
                           if length(search_index) == 1
                                index = search_index + 2;
                                if strcmp(sldd_data(j).DataSource, aliastype_info{index, 8})
                                    isContinute = 1;
                                end
                                hasData = 1;
                           else
                                for k = 1: length(search_index)
                                    index = search_index(k) + 2;
                                    if strcmp(sldd_data(j).DataSource, aliastype_info{index, 8})
                                        isContinute = 1;
                                        break;
                                    end
                                    hasData = 1;
                                end
                           end
                           if isContinute == 1
                            %% ProcessBar�X�V��------------------------------------------------��
                                if j == length(sldd_data)
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                end
                            %% ProcessBar�X�V��------------------------------------------------��
                                continue;
                           end
                        end
                        % �ǉ�����
                        aliastype_info{end + 1, 1} = run_time; 
                        % �X�V����
                        aliastype_info{end, 2} = ''; 
                        % Name
                        aliastype_info{end, 3} = sldd_data(j).Name;
                        % Description
                        aliastype_info{end, 4} = sldd_data_info.Description;
                        % DataScope
                        aliastype_info{end, 5} = sldd_data_info.DataScope;
                        % HeaderFile
                        aliastype_info{end, 6} = sldd_data_info.HeaderFile;
                        % BaseType
                        aliastype_info{end, 7} = sldd_data_info.BaseType;
                        % DataSource
                        aliastype_info{end, 8} = sldd_data(j).DataSource;     
                     %% Check Diff Variable
                        if hasData == 1
                            for k = 1: length(search_index)
                                index = search_index(k) + 2;
                                if ~isequal(aliastype_info(end, 5:7) , aliastype_info(index, 5:7))
                                    error_file_name = [ 'diffvariable_error_' datestr(now, 'yyyy_mm_dd_HH_MM_ss') '.xlsx' ];
                                    warndlg(sprintf(['Contents of the same variable names is difference. Process is stopped.\n' ...
                                                    'Please check these variables info in �u%s�vand try again:\n' ...
                                                    '[Var 1] Name:%s. DataSource:%s\n'...
                                                    '[Var 2] Name:%s. DataSource:%s'], ...
                                                    error_file_name, ...
                                                    aliastype_info{index, 3}, aliastype_info{index, 8}, ...
                                                    aliastype_info{end, 3}, aliastype_info{end, 8} ...
                                                    ))
                                     diff_info = aliastype_info(1:2, 1:end);
                                     diff_info(end + 1, 1:end) =  aliastype_info(index, 1:end);
                                     diff_info(end + 1, 1:end) =  aliastype_info(end, 1:end);
                                     for l = 1: 2
                                         for h = 4:size(diff_info, 2)
                                             if isnumeric(diff_info{l + 2, h}) || islogical(diff_info{l + 2, h})
                                                 diff_info{l + 2, h} = num2str(diff_info{l + 2, h});
                                             end
                                         end
                                     end
                                     diff_index = [];           
                                     for l = 1: length(diff_info(4, 5:7))
                                         if ~ismember(diff_info{3, l + 4}, diff_info(4, 5:7))
                                             diff_index(end + 1) = l + 4;
                                         end
                                     end
                                     xlswrite([ file_path '\' error_file_name ], diff_info);
                                     e = actxserver('Excel.Application');
                                     eWorkbooks = e.Workbooks;
                                     exlFile = eWorkbooks.Open([ file_path '\' error_file_name ]);
                                     diff_info_Sheet = exlFile.Sheets.Item('Sheet1');
                                     for l = 1: length(diff_index)
                                         diff_info_range = diff_info_Sheet.Range([ GetColumnName(diff_index(l)) '3:' GetColumnName(diff_index(l)) '4']);
                                         diff_info_range.Font.ColorIndex = 3;
                                     end
                                     diff_info_range = diff_info_Sheet.UsedRange;
                                     diff_info_range.WrapText = 0;
                                     exlFile.Save;
                                     Quit(e);
                                     delete(e);
                                %% ProcessBar�X�V��------------------------------------------------��
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                %% ProcessBar�X�V��------------------------------------------------��            
                                    result = 0;
                                    return;
                                end
                            end
                        end
                        
                   %% Simulink.data.dictionary.EnumTypeDefinition�̏ꍇ    
                    case 'Simulink.data.dictionary.EnumTypeDefinition'
                        % ���Ƀf�[�^�������݂���ꍇ�ADataSource�������ł���΁A�o�͏��ɒǉ����Ȃ�
                        if strcmp(sldd_data(j).Name, 'D_Autonomous_Mode_Enum')
                            sprintf('Test');
                        end
                        if size(enum_info, 1) > 2 && ...
                           ismember(sldd_data(j).Name, enum_info(3:end, 3))
                       
                           isContinute = 0;
                           for k = 1:size(enum_info_temp(3:end, 1:end), 1)
                                if strcmp(sldd_data(j).Name, enum_info_temp{k + 2, 1}) && ...
                                   strcmp(sldd_data(j).DataSource, enum_info_temp{k + 2, 3})
                                    isContinute = 1;
                                    break;
                                end 
                                hasData = 1;
                           end

                           if isContinute == 1
                            %% ProcessBar�X�V��------------------------------------------------��
                                if j == length(sldd_data)
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                end
                            %% ProcessBar�X�V��------------------------------------------------��
                                continue;
                           end                            
                        end
                        % �ǉ�����
                        enum_info{end + 1, 1} = run_time; 
                        % �X�V����
                        enum_info{end, 2} = ''; 
                        
                        Enumerals = sldd_data_info.Enumerals;
                     %% ���������p
                        enum_info_temp{end + 1, 1} = sldd_data(j).Name;   
                        enum_info_check_diff{end + 1, 1} = sldd_data(j).Name;   
                        if length(Enumerals) == 1
                            Enumerals = struct2cell(Enumerals);
                            Enumerals = Enumerals';
                        else
                            Enumerals = table2cell(struct2table(Enumerals));
                        end
                        Enumerals{1, end + 1} = [];
                        enum_info_temp{end, 2} = Enumerals;
                        enum_info_temp{end, 3} = sldd_data(j).DataSource;
                        enum_info_check_diff{end, 2} = Enumerals;
                        enum_info_check_diff{end, 9} = sldd_data(j).DataSource;
                        for k = 1: size(Enumerals, 1)
                            if k == 1
                                % Name
                                enum_info{end, 3} = sldd_data(j).Name;    
                                % Enumerals_Name
                                enum_info{end, 4} = sldd_data_info.Enumerals(k).Name;
                                % Enumerals_Value
                                enum_info{end, 5} = sldd_data_info.Enumerals(k).Value;
                                % Enumerals_Description
                                enum_info{end, 6} = sldd_data_info.Enumerals(k).Description;
                                % DefaultValue
                                enum_info{end, 7} = sldd_data_info.DefaultValue;
                                enum_info_check_diff{end, 4} = sldd_data_info.DefaultValue;
                                % StorageType
                                enum_info{end, 8} = sldd_data_info.StorageType;
                                enum_info_check_diff{end, 5} = sldd_data_info.StorageType;
                                % DataScope
                                enum_info{end, 9} = sldd_data_info.DataScope;
                                enum_info_check_diff{end, 6} = sldd_data_info.DataScope;
                                % HeaderFile
                                enum_info{end, 10} = sldd_data_info.HeaderFile;
                                enum_info_check_diff{end, 7} = sldd_data_info.HeaderFile;
                                % AddClassNameToEnumNames
                                enum_info{end, 11} = sldd_data_info.AddClassNameToEnumNames;
                                enum_info_check_diff{end, 8} = sldd_data_info.AddClassNameToEnumNames;
                                % Description
                                enum_info{end, 12} = sldd_data_info.Description;
                                % DataSource
                                enum_info{end, 13} = sldd_data(j).DataSource;
                            else
                                % �ǉ�����
                                enum_info{end + 1, 1} = '';
                                % �X�V����
                                enum_info{end, 2} = '';
                                % Name
                                enum_info{end, 3} = sldd_data(j).Name;
                                % Enumerals_Name
                                enum_info{end, 4} = sldd_data_info.Enumerals(k).Name;
                                % Enumerals_Value
                                enum_info{end, 5} = sldd_data_info.Enumerals(k).Value;
                                % Enumerals_Description
                                enum_info{end, 6} = sldd_data_info.Enumerals(k).Description;
                                % DefaultValue
                                enum_info{end, 7} = '';
                                % StorageType
                                enum_info{end, 8} = '';
                                % DataScope
                                enum_info{end, 9} = '';
                                % HeaderFile
                                enum_info{end, 10} = '';
                                % AddClassNameToEnumNames
                                enum_info{end, 11} = '';
                                % Description
                                enum_info{end, 12} = '';
                                % DataSource
                                enum_info{end, 13} = sldd_data(j).DataSource;
                            end
                        end
                     %% Check Diff Variable
                        if hasData == 1
                            [search_index] = find(strcmp(sldd_data(j).Name , enum_info_check_diff(3:end-1, 1)));
                            for k = 1: length(search_index)
                                index = search_index(k) + 2;
                                if ~isequal(enum_info_check_diff(end, 2:8) , enum_info_check_diff(index, 2:8))
                                    error_file_name = [ 'diffvariable_error_' datestr(now, 'yyyy_mm_dd_HH_MM_ss') '.xlsx' ];
                                    warndlg(sprintf(['Contents of the same variable names is difference. Process is stopped.\n' ...
                                                    'Please check these variables info in �u%s�vand try again:\n' ...
                                                    '[Var 1] Name:%s. DataSource:%s\n'...
                                                    '[Var 2] Name:%s. DataSource:%s'], ...
                                                    error_file_name, ...
                                                    enum_info_check_diff{index, 1}, enum_info_check_diff{index, 9}, ...
                                                    enum_info_check_diff{end, 1}, enum_info_check_diff{end, 9} ...
                                                    ))
                                     diff_info = enum_info_check_diff(1:2, 1:end);
                                     diff_info(end + 1, 1:end) =  enum_info_check_diff(index, 1:end);
                                     diff_info(end + 1, 1:end) =  enum_info_check_diff(end, 1:end);
                                     cell_data = {};
                                     cell_data{end + 1} = {};
                                     cell_data{end + 1} = {};
                                     for l = 1: 2
                                         for h = 2:size(diff_info, 2)
                                             if isnumeric(diff_info{l + 2, h}) || islogical(diff_info{l + 2, h})
                                                 diff_info{l + 2, h} = num2str(diff_info{l + 2, h});
                                             end
                                             if iscell(diff_info{l + 2, h})
                                                 cell_data{l} = diff_info{l + 2, h};
                                                 diff_info{l + 2, h} = [ '�uEnumerals_' num2str(l) '�v�V�[�g�Q��'];       
                                             end
                                         end
                                     end
                                     diff_index = [];           
                                     for l = 1: length(diff_info(4, 2:8))                                         
                                         if ~ismember(diff_info{3, l + 1}, diff_info(4, 2:8))
                                             if l + 1 == 2
                                                 if ~isequal(cell_data{1}, cell_data{2})
                                                     diff_index(end + 1) = l + 1;
                                                 end
                                             else
                                                diff_index(end + 1) = l + 1;
                                             end
                                         end
                                     end
                                     xlswrite([ file_path '\' error_file_name ], diff_info);
                                     e = actxserver('Excel.Application');
                                     eWorkbooks = e.Workbooks;
                                     exlFile = eWorkbooks.Open([ file_path '\' error_file_name ]);
                                     diff_info_Sheet = exlFile.Sheets.Item('Sheet1');
                                     for l = 1: length(diff_index)
                                         diff_info_range = diff_info_Sheet.Range([ GetColumnName(diff_index(l)) '3:' GetColumnName(diff_index(l)) '4']);
                                         diff_info_range.Font.ColorIndex = 3;
                                     end
                                     diff_info_range = diff_info_Sheet.UsedRange;
                                     diff_info_range.WrapText = 0;
                                     exlFile.Save;
                                     Quit(e);
                                     delete(e);
                                     e = [];
                                     xlswrite([ file_path '\' error_file_name ], cell_data{1}, 'Enumerals_1');
                                     xlswrite([ file_path '\' error_file_name ], cell_data{2}, 'Enumerals_2');
                                     if ~isequal(cell_data{1}, cell_data{2})
                                         Enumerals_1 = cell_data{1};
                                         Enumerals_2 = cell_data{2};
                                         e = actxserver('Excel.Application');
                                         eWorkbooks = e.Workbooks;
                                         exlFile = eWorkbooks.Open([ file_path '\' error_file_name ]);
                                         diff_info_Enumerals_1 = exlFile.Sheets.Item('Enumerals_1');
                                         diff_info_Enumerals_2 = exlFile.Sheets.Item('Enumerals_2');
                                         
                                         for l = 1: size(Enumerals_1, 1)
                                             if l <= size(Enumerals_2, 1)
                                                 if ~isequal(Enumerals_1(l, 1:end), Enumerals_2(l, 1:end))
                                                    diff_info_range = diff_info_Enumerals_1.Range([ 'A' num2str(l) ':C' num2str(l)]);
                                                    diff_info_range.Font.ColorIndex = 3;
                                                    diff_info_range = diff_info_Enumerals_2.Range([ 'A' num2str(l) ':C' num2str(l)]);
                                                    diff_info_range.Font.ColorIndex = 3;
                                                 end
                                             else
                                                   diff_info_range = diff_info_Enumerals_1.Range([ 'A' num2str(l) ':C' num2str(l)]);
                                                   diff_info_range.Font.ColorIndex = 3;
                                                   diff_info_range = diff_info_Enumerals_2.Range([ 'A' num2str(l) ':C' num2str(l)]);
                                                   diff_info_range.Font.ColorIndex = 3;
                                             end
                                         end
                                         for l = 1: size(Enumerals_2, 1)
                                             if l <= size(Enumerals_1, 1)
                                                 if ~isequal(Enumerals_2(l, 1:end), Enumerals_1(l, 1:end))
                                                    diff_info_range = diff_info_Enumerals_1.Range([ 'A' num2str(l) ':C' num2str(l)]);
                                                    diff_info_range.Font.ColorIndex = 3;
                                                    diff_info_range = diff_info_Enumerals_2.Range([ 'A' num2str(l) ':C' num2str(l)]);
                                                    diff_info_range.Font.ColorIndex = 3;
                                                 end
                                             else
                                                   diff_info_range = diff_info_Enumerals_1.Range([ 'A' num2str(l) ':C' num2str(l)]);
                                                   diff_info_range.Font.ColorIndex = 3;
                                                   diff_info_range = diff_info_Enumerals_2.Range([ 'A' num2str(l) ':C' num2str(l)]);
                                                   diff_info_range.Font.ColorIndex = 3;
                                             end
                                         end
                                         exlFile.Save;
                                         Quit(e);
                                         delete(e);
                                         e = [];
                                     end
                                %% ProcessBar�X�V��------------------------------------------------��
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                %% ProcessBar�X�V��------------------------------------------------��            
                                    result = 0;
                                    return;
                                end
                            end
                        end
                    otherwise
                        % ���Ƀf�[�^�������݂���ꍇ�ADataSource�������ł���΁A�o�͏��ɒǉ����Ȃ�
                        if size(notExportDataName, 1) > 2 && ...
                           ismember(sldd_data(j).Name, notExportDataName(3:end, 5))
                       
                           isContinute = 0;
                           [search_index] = find(strcmp(sldd_data(j).Name, notExportDataName(3:end, 5)));
                           if length(search_index) == 1
                                index = search_index + 2;
                                if ~strcmp(sldd_data(j).DataSource, notExportDataName{index, 5})
                                    isContinute = 1;
                                end
                           else
                                for k = 1: length(search_index)
                                    index = search_index(k) + 2;
                                    if strcmp(sldd_data(j).DataSource, notExportDataName{index, 5})
                                        isContinute = 1;
                                        break;
                                    end
                                end
                           end
                           if isContinute == 1
                            %% ProcessBar�X�V��------------------------------------------------��
                                if j == length(sldd_data)
                                     ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                                end
                            %% ProcessBar�X�V��------------------------------------------------��
                                continue;
                           end
                        end
                        % �ǉ�����
                        notExportDataName{end + 1, 1} = run_time;
                        % �X�V����
                        notExportDataName{end, 2} = '';
                        notExportDataName{end, 3} = class(sldd_data(j).getValue);
                        notExportDataName{end, 4} = sldd_data(j).Name;
                        notExportDataName{end, 5} = sldd_data(j).DataSource;
                end
              %% ProcessBar�X�V��------------------------------------------------��
                if j == length(sldd_data)
                    ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                end
              %% ProcessBar�X�V��------------------------------------------------��
            catch ex
                errordlg(sprintf([ex.message ' .\nLine: ' num2str(ex.stack(1).line)]));
               %% ProcessBar�X�V��------------------------------------------------��
                ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
                %% ProcessBar�X�V��------------------------------------------------��            
                result = 0;
                return;
            end
        end
       %% ProcessBar�X�V��------------------------------------------------��
        %if i == length(sldd_filename_lst)
        ProcessBar(sprintf('Processing�F%d/%d data item of %s.', j, length(sldd_data), regexprep(sldd_filename_lst{i}, '_', ' ')), percent, 0, 1);
        %end
       %% ProcessBar�X�V��------------------------------------------------��
    end
    %% �E �D�ō쐬�������X�g���f�[�^���Ń\�[�g���s��
     if size(in_out_signal_info, 1) > 2
        in_out_signal_info(3:end, 1:end) = sortrows(in_out_signal_info(3:end, 1:end), 3);
    end
    if size(parameter_info, 1) > 2
        parameter_info(3:end, 1:end) = sortrows(parameter_info(3:end, 1:end), 3);
    end
    if size(aliastype_info, 1) > 2
        aliastype_info(3:end, 1:end) = sortrows(aliastype_info(3:end, 1:end), 3);
    end
    if size(enum_info, 1) > 2
        enum_info(3:end, 1:end) = sortrows(enum_info(3:end, 1:end), 3);
        enum_info_temp(3:end, 1:end) = sortrows(enum_info_temp(3:end, 1:end), 1);
    end
    if size(notExportDataName, 1) > 1
        notExportDataName(2:end, 1:end) = sortrows(notExportDataName(2:end, 1:end), 3);
        run_step = 5;
    else
        run_step = 4;
    end
    %% �F �o�̓t�@�C���A����Temp�t�@�C���t���p�X�쐬
    % �t�H���_�F�@�őI�������t�H���_
    % �o�̓t�@�C�����F�@�őI�������t�@�C����
    % ����Temp�t�@�C���� = �o�̓t�@�C���� + ����_mm_dd_HH_MM_ss
    % ����_mm_dd_HH_MM_ss�F���s����
    final_excel_file = [ file_path '' file_name ];
    [~, file_name_nothasext , ext] = fileparts(final_excel_file);
    excel_file = [ file_path '\' file_name_nothasext '_' datestr(now, 'yyyy_mm_dd_HH_MM_ss') ext ];
    used_variables_info_file = [ file_path '\' file_name_nothasext '_UsedVariablesInfo_' datestr(now, 'yyyy_mm_dd_HH_MM_ss') ext ];
    e = [];
    try
        %% �G �o�̓t�@�C�����܂����݂��Ȃ��ꍇ�A	
        % 	�o�̓t�@�C���F�V�K�t�@�C���쐬
        % �@�@	����Temp�t�@�C���F�V�K�t�@�C���쐬
        %     �o�̓t�@�C�������ɑ��݂���ꍇ�A	
        % 	�o�̓t�@�C�����R�s�[���A����Temp�t�@�C�����쐬����
        if exist(final_excel_file) ~= 2
            xlswrite(final_excel_file, {''});
            xlswrite(excel_file, {''});
            isCreateNew = 1;
        else
            copyfile(final_excel_file, excel_file, 'f');
            isCreateNew = 0;
        end
        %% �H ����Temp�t�@�C���Ɂusignal�v�A�uparameter�v�A�ualias�v�A�uenum�v�V�[�g�����݂��Ȃ��ꍇ	
    	%   �y�f�[�^�\���z�ɒ�`���Ă���\���ŁA�V�[�g�쐬���s��
        [ in_out_signal_info_default, parameter_info_default, ...
                aliastype_info_default, enum_info_default, ~ ] = MakeStructureOutputOfModelInterface();
        for i = 1: run_step
            sheet_name = GetSheetName(i);
            if isempty(e)
                e = actxserver('Excel.Application');
                eWorkbooks = e.Workbooks;
                exlFile = eWorkbooks.Open(excel_file);
            end
            try
               exlFile.Sheets.Item(sheet_name);
            catch
                if ~isempty(e)
                    exlFile.Save;
                    Quit(e);
                    delete(e);
                    e = [];
                end
                default_data = [];
                switch(i)
                    case 1
                        default_data = in_out_signal_info_default;
                    case 2
                        default_data = parameter_info_default;
                    case 3
                        default_data = aliastype_info_default;
                    case 4
                        default_data = enum_info_default;
                    otherwise
                        % nothing
                end
                if ~isempty(default_data)
                    xlswrite(excel_file, default_data, sheet_name);
                end
                if isempty(e)
                    e = actxserver('Excel.Application');
                    eWorkbooks = e.Workbooks;
                    exlFile = eWorkbooks.Open(excel_file); 
                    
                    if isCreateNew == 1
                        try
                            % �]�v�ȁhSheet1�h���폜���邽��
                            Sheet1 = exlFile.Sheets.Item('Sheet1');
                            Sheet1.Delete;
                            isCreateNew = 0;
                        catch
                        end
                    end
                end
            end
        end
       %% �I �usignal�v�A�uparameter�v�A�ualias�v�A�uenum�v�̏��ԂŁA�f�[�^���X�V�A�ǉ��A�폜�̂ǂꂩ�𔻒f���A����Temp�t�@�C���Ƀf�[�^��ҏW����
       UpdateSheetName = {};
        for i = 1: run_step
           %% ProcessBar�X�V��------------------------------------------------��
            if i == 1
              ProcessBar('Processing Write Excel File. Please Wait.', 0, 1, 0);
            end
            if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                delete(bar);
                if ~isempty(e)
                    try
                        exlFile.Close(false);
                        Quit(e);
                        delete(e);
                        delete(excel_file);
                    catch
                    end
                end
                result = 0;
                return;
            end
            percent = i/run_step;
            ProcessBar(sprintf('Processing�F%d/%d Sheet.', i, run_step), percent, 0, 0);
           %% ProcessBar�X�V��------------------------------------------------��
            sheet_name = GetSheetName(i);
           %% ProcessBar�X�V��------------------------------------------------��
             ProcessBar(sprintf('Processing�F%d/%d "%s" Sheet.', i, run_step, regexprep(sheet_name, '_', ' ')), percent, 0, 0);
           %% ProcessBar�X�V��------------------------------------------------��
            if exist(excel_file) == 2
                if isempty(e)
                    e = actxserver('Excel.Application');
                    eWorkbooks = e.Workbooks;
                    exlFile = eWorkbooks.Open(excel_file);
                end
                try
                   sheet_data = exlFile.Sheets.Item(sheet_name);
                catch
                    sheet_data = [];
                end
                if ~isempty(sheet_data)
                 %% Update Data 
                    switch(i)
                        case 1
                            Update_Data = in_out_signal_info;
                            D_S_Index = 27;
                        case 2
                            Update_Data = parameter_info;
                            D_S_Index = 21;
                        case 3
                            Update_Data = aliastype_info;
                            D_S_Index = 8;
                        case 4
                            Update_Data = enum_info;
                            D_S_Index = 13;
                        otherwise
                            Update_Data = notExportDataName;
                            D_S_Index = 5;
                    end

                  %% �I (1) ���ɃV�[�g�Ƀf�[�^������Cells���擾����
                    %   �擾����Cells�̃t�H�[�}�b�g�ƃR�����g���N���A����
                    UsedRange = sheet_data.UsedRange;
                    UsedRangeValue = UsedRange.Value;
                    %UsedRange.ClearComments;
                    UsedRange.Font.ColorIndex = 0;
%                     %
                     delete_rows = {};
                    try
                     %% �I (2) �f�[�^������Cells������ꍇ�A	
                        % �@	�f�[�^�����D�ō쐬�������X�g�ɑ��݂��Ȃ��ꍇ�ADELETE�f�[�^�Ɣ��f����
                        % 	�f�[�^�����D�ō쐬�������X�g�ɑ��݂���ꍇ�A�ύX�����邩�ǂ����`�F�b�N����
                        % 	�ύX������ꍇ�A�V�����l��Cell�̒l��u��������
                        % 	�@�@�@�@�@�@�@�@�܂��A�e�L�X�g�̐F�͐Ԃ��F�Őݒ�A�O��̒l��Cell�̃R�����g���쐬����
                        % 	               �O��̍X�V�l�F"�O��̒l"
                        %                  �u�X�V�����v��Ɏ��s�������Z�b�g����
                    %% �X�V�����쐬
                        try
                            Updated_sheet_data = exlFile.Sheets.Item([ sheet_name '_�X�V����' ]);
                            Updated_sheet_data.Visible = 1;
                            Updated_sheet_data.UsedRange.Font.ColorIndex = 0;
                            Updated_sheet_data.UsedRange.Interior.ColorIndex = 15;
                            Updated_sheet_data.UsedRange.Rows.Item(1).Interior.ColorIndex = 2;
                            Updated_sheet_data.UsedRange.Rows.Item(2).Interior.ColorIndex = 2;
                            isCreateNewUpdateSheet = 0;
                        catch
                            Updated_sheet_data = exlFile.Sheets.Add;
                            Updated_sheet_data.Name = [ sheet_name '_�X�V����' ];
                            exlFile.Sheets.Item([ sheet_name '_�X�V����' ]).Move(exlFile.Sheets.Item(exlFile.Sheets.Count));
                            for j = 1: size(UsedRangeValue, 2)
                                if j <= 2
                                    Updated_sheet_data.Rows.Item(1).Columns.Item(j).Value = UsedRangeValue{1, j};
                                    Updated_sheet_data.Rows.Item(2).Columns.Item(j).Value = UsedRangeValue{2, j};
                                else
                                    Updated_sheet_data.Rows.Item(1).Columns.Item(j+1).Value = UsedRangeValue{1, j};
                                    Updated_sheet_data.Rows.Item(2).Columns.Item(j+1).Value = UsedRangeValue{2, j};
                                end
                            end
                            isCreateNewUpdateSheet = 1;
                        end
                        UpdateSheetName{end + 1} = Updated_sheet_data.Name;
                        Updated_sheet_data.Rows.Item(2).Columns.Item(2).Value = '�X�V����';
                        Updated_sheet_data.Rows.Item(2).Columns.Item(3).Value = '�폜����';
                        Updated_sheet_data_UsedRange = Updated_sheet_data.UsedRange;
                        insert_index_Updated_sheet = Updated_sheet_data_UsedRange.Rows.Count;
                        if size(UsedRangeValue, 1) > 2
                            [ ref, NullRowIndex ]= GetNullRowIndex(UsedRange, sheet_name);
                            if ref == 0
                                result = 2;
                                return;
                            end
                            if NullRowIndex > 0
                                new_range = regexprep(UsedRange.AddressLocal, '\d+$', num2str(NullRowIndex - 1));
                                UsedRange = sheet_data.Range(new_range);
                                UsedRangeValue = UsedRange.Value;
                            end
                        %% Enum�^�C�v�ȊO�̏ꍇ
                            if i ~= 4
                                %UsedRangeValue(3:end, 1:end) = sortrows(UsedRangeValue(3:end, 1:end), 3);
                                UsedRange_AddressLocal = UsedRange.AddressLocal;
                                SortRangeAddress = regexprep(UsedRange_AddressLocal, '\$A\$1\:', '\$A\$3\:');
                                SortColumn = regexprep(SortRangeAddress, '\$\w+\$', '\$C\$');
                                SortRange = sheet_data.Range(SortRangeAddress);
                                invoke(SortRange, 'Sort', sheet_data.Range(SortColumn), 1);
                                exlFile.Save;
                                UsedRangeValue = UsedRange.Value;
                            end
                            %UsedRange.ClearComments;
                            UsedRange.Font.ColorIndex = 1;
                          %% ���̃f�[�^���`�F�b�N����
                            enum_info_temp_idx = 0;
                            not_check_index_lst = [];
                            
                            for j = 3: size(UsedRangeValue, 1)
                            %% ProcessBar�X�V��------------------------------------------------��
                                if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                                    delete(bar);
                                    if ~isempty(e)
                                        try
                                            exlFile.Close(false);
                                            Quit(e);
                                            delete(e);
                                            delete(excel_file);
                                        catch
                                        end
                                    end
                                    result = 2;
                                    return;
                                end
                            %% ProcessBar�X�V��------------------------------------------------��
                                if ismember(j, not_check_index_lst )
                                    continue;
                                end
                                updated_flag = 0;
                                row_j = UsedRange.Rows.Item(j);
                                check_data_name = UsedRangeValue{j, 3};
                                has_data_name = 0;
                                if isnan(check_data_name) ~= 1
                                    try
                                        check_data_name = regexprep(check_data_name, ' ', '');
                                    catch
                                        check_data_name = '';
                                    end
                                else
                                    check_data_name= '';
                                end
                                if i == 4
                                    if isempty(check_data_name)
                                        for k = j: -1: 1
                                            if ~isempty(UsedRangeValue{k, 3})
                                                if isnan(UsedRangeValue{k, 3}) ~= 1
                                                    check_data_name = UsedRangeValue{k, 3};
                                                    break;
                                                end
                                            end
                                        end
                                    else
                                        has_data_name = 1;
                                    end
                                end
                                if i ~= 4 || has_data_name == 1
                                    row_j.Columns.Item(3).Value = check_data_name;
                                end
                                if isempty(check_data_name)
                                    continue;
                                end
                                % Delete�̏ꍇ�͖{�V�[�g�̃f�[�^���폜���ADeleted_xxxx�V�[�g�ɒǉ�����
                                if ~ismember(check_data_name, Update_Data(3:end, 3))
                                    if i ~= 4
                                         % �{�V�[�g�̃f�[�^���폜����
                                        delete_rows{end + 1} = row_j;
                                   %% �폜�̏ꍇ�A�X�V�����V�[�g�Ƀf�[�ǉ�
                                        insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                        updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                        updated_deleted_row_add.Value{1} = row_j.Value{1};
                                        updated_deleted_row_add.Value{2} = row_j.Value{2};
                                        updated_deleted_row_add.Value{3} = run_time;
                                        updated_deleted_row_add.Value{3 + 1} = row_j.Value{3};

                                        for k = 4: size(UsedRangeValue, 2)
                                            if ~isempty(row_j.Columns.Item(k).Comment)
                                                updated_deleted_row_add.Columns.Item(k + 1).AddComment(row_j.Columns.Item(k).Comment.Text);
                                            end
                                            updated_deleted_row_add.Value{k + 1} = row_j.Value{k};
                                        end
                                        updated_deleted_row_add.Columns.Item(3).Font.ColorIndex = 3;
                                    else
                                   %% Enum
                                        start_delete = j;
                                        for k = start_delete: size(UsedRangeValue, 1)
                                            if k > start_delete
                                                if isnan(UsedRangeValue{k, 3}) ~= 1
                                                    if ischar(UsedRangeValue{k, 3}) && ...
                                                       ~isempty(regexprep(UsedRangeValue{k, 3}, ' ', ''))
                                                        break;
                                                    end
                                                end
                                            end
                                            row_k = UsedRange.Rows.Item(k);
                                             % �{�V�[�g�̃f�[�^���폜����
                                            delete_rows{end + 1} = row_k;                                              
                                            not_check_index_lst(end + 1) = k;
                                            
                                       %% �폜�̏ꍇ�A�X�V�����V�[�g�Ƀf�[�ǉ�
                                            insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                            updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                            updated_deleted_row_add.Value{1} = row_j.Value{1};
                                            updated_deleted_row_add.Value{2} = row_j.Value{2};
                                            updated_deleted_row_add.Value{3} = run_time;

                                            for l = 3: size(UsedRangeValue, 2)
                                                if ~isempty(row_k.Columns.Item(l).Comment)
                                                    updated_deleted_row_add.Columns.Item(l + 1).AddComment(row_k.Columns.Item(l).Comment.Text);
                                                end
                                                updated_deleted_row_add.Value{l + 1} = row_k.Value{l};
                                            end
                                            updated_deleted_row_add.Columns.Item(3).Font.ColorIndex = 3;
                                        end
                                    end
                                % �f�[�^���ق�����ꍇ�͖{�V�[�g�̃f�[�^���X�V����
                                else
                                    [search_index] = find(strcmp(check_data_name, Update_Data(3:end, 3)));
                                    if i == 4
                                        [search_index_temp] = find(strcmp(check_data_name, enum_info_temp(3:end, 1)));
                                        if ~isempty(search_index_temp) && search_index_temp(1) + 2 > enum_info_temp_idx
                                            enum_info_temp_idx = search_index_temp(1) + 2;
                                        end
                                    end
                                    index = search_index(1) + 2;
                                    check_datasource = '';
                                    if strcmp(UsedRangeValue{2, D_S_Index}, 'DataSource')
                                        if isnan(UsedRangeValue{j, D_S_Index}) ~= 1
                                            check_datasource = UsedRangeValue{j, D_S_Index};
                                        else
                                            UsedRangeValue{j, D_S_Index} = '';
                                        end 
                                    end
                                    if ~isempty(check_datasource)
                                        if i == 4
                                            if ~isempty(search_index_temp)
                                                if length(search_index_temp)== 1
                                                    enum_info_temp_idx = search_index_temp(1) + 2;
                                                else
                                                    for k = 1: length(search_index_temp)
                                                        enum_info_temp_idx = search_index_temp(k) + 2;
                                                        if strcmp(enum_info_temp{enum_info_temp_idx, 3}, check_datasource)
                                                            enum_info_temp_idx = search_index_temp(k) + 2;
                                                            break;
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                        if length(search_index) == 1
                                            index = search_index + 2;
                                            if ~strcmp(check_datasource, Update_Data{index, D_S_Index}) && ...
                                               ~IsChildParentRelationSLDD(Update_Data{index, D_S_Index}, check_datasource)
                                                start_delete = j;
                                                for k = start_delete: size(UsedRangeValue, 1)
                                                    if k > start_delete
                                                        if isnan(UsedRangeValue{k, 3}) ~= 1
                                                            if ischar(UsedRangeValue{k, 3}) && ...
                                                               ~isempty(regexprep(UsedRangeValue{k, 3}, ' ', ''))
                                                                break;
                                                            end
                                                        end
                                                    end
                                                    row_k = UsedRange.Rows.Item(k);

                                                    % �{�V�[�g�̃f�[�^���폜����
                                                    delete_rows{end + 1} = row_k;                                                      
                                                    not_check_index_lst(end + 1) = k;
                                              %% �폜�̏ꍇ�A�X�V�����V�[�g�Ƀf�[�ǉ�
                                                    insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                                    updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                                    updated_deleted_row_add.Value{1} = row_j.Value{1};
                                                    updated_deleted_row_add.Value{2} = row_j.Value{2};
                                                    updated_deleted_row_add.Value{3} = run_time;

                                                    for l = 3: size(UsedRangeValue, 2)
                                                        if ~isempty(row_k.Columns.Item(l).Comment)
                                                            updated_deleted_row_add.Columns.Item(l + 1).AddComment(row_k.Columns.Item(l).Comment.Text);
                                                        end
                                                        updated_deleted_row_add.Value{l + 1} = row_k.Value{l};
                                                    end
                                                    updated_deleted_row_add.Columns.Item(3).Font.ColorIndex = 3;
                                                end
                                                continue;
                                            end
                                        else
                                            hasData = 0;
                                            for k = 1: length(search_index)
                                                index = search_index(k) + 2;
                                                if strcmp(Update_Data{index, D_S_Index}, check_datasource) || ...
                                                   IsChildParentRelationSLDD(Update_Data{index, D_S_Index}, check_datasource)
                                                    index = search_index(k) + 2;
                                                    hasData = 1;
                                                    break;
                                                end
                                            end
                                            if hasData == 0
                                                start_delete = j;
                                                for k = start_delete: size(UsedRangeValue, 1)
                                                    if k > start_delete
                                                        if isnan(UsedRangeValue{k, 3}) ~= 1
                                                            if ischar(UsedRangeValue{k, 3}) && ...
                                                               ~isempty(regexprep(UsedRangeValue{k, 3}, ' ', ''))
                                                                break;
                                                            end
                                                        end
                                                    end
                                                    row_k = UsedRange.Rows.Item(k);

                                                     % �{�V�[�g�̃f�[�^���폜����
                                                    delete_rows{end + 1} = row_k; 
                                                    not_check_index_lst(end + 1) = k;
                                                    
                                              %% �폜�̏ꍇ�A�X�V�����V�[�g�Ƀf�[�ǉ�
                                                    insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                                    updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                                    updated_deleted_row_add.Value{1} = row_j.Value{1};
                                                    updated_deleted_row_add.Value{2} = row_j.Value{2};
                                                    updated_deleted_row_add.Value{3} = run_time;

                                                    for l = 3: size(UsedRangeValue, 2)
                                                        if ~isempty(row_k.Columns.Item(l).Comment)
                                                            updated_deleted_row_add.Columns.Item(l + 1).AddComment(row_k.Columns.Item(l).Comment.Text);
                                                        end
                                                        updated_deleted_row_add.Value{l + 1} = row_k.Value{l};
                                                    end
                                                    updated_deleted_row_add.Columns.Item(3).Font.ColorIndex = 3;
                                                end
                                                continue;
                                            end
                                        end
                                    end
                                %% Enum�^�C�v�̏���(Enum Name, Enum Value, Enum Description�̃`�F�b�N)
                                    if i == 4
                                        if has_data_name
                                            enum_info_temp{enum_info_temp_idx, end} = j;
                                        end
                                        [ diff_flag, diff_col_arr, diff_type, update_value, EnumData_new_update ] = CompareEnumData(UsedRangeValue{j, 4}, ...
                                                            UsedRangeValue{j, 5}, UsedRangeValue{j, 6}, enum_info_temp{enum_info_temp_idx, 2});
                                        enum_info_temp{enum_info_temp_idx, 2} = EnumData_new_update;
                                        if diff_flag == 1
                                       %% Enum �X�V
                                            if diff_type == 1
                                          %% �X�V�̏ꍇ�A�X�V�����V�[�g�Ƀf�[�^�ǉ�
                                                insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                                updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                                updated_deleted_row_add.Value{1} = row_j.Value{1};
                                                updated_deleted_row_add.Value{2} = row_j.Value{2};
                                                updated_deleted_row_add.Value{3 + 1} = enum_info_temp{enum_info_temp_idx, 1};
                                                
                                                row_j.Columns.Item(2).Value = run_time;
                                                row_j.Columns.Item(2).Font.ColorIndex = 3;
                                                for k = 1: length(diff_col_arr)
                                                    diff_col_arr{k} = diff_col_arr{k} + 3;

                                                    row_j.Columns.Item(diff_col_arr{k}).Value = update_value{k};
                                                    row_j.Columns.Item(diff_col_arr{k}).Font.ColorIndex = 3;
                                                    row_j_item = row_j.Columns.Item(diff_col_arr{k});
                                                    try
                                                        if isnumeric(UsedRangeValue{j, diff_col_arr{k}})
                                                            comment_text = num2str(UsedRangeValue{j, diff_col_arr{k}});
                                                        else
                                                            comment_text = UsedRangeValue{j, diff_col_arr{k}};
                                                        end
                                                    catch
                                                        comment_text = '';
                                                    end
                                                    try
                                                        row_j_item.AddComment([ '�O��̍X�V�l�F"' comment_text '"']);
                                                    catch
                                                        if ~isempty(row_j_item.Comment)
                                                            row_j_item.Comment.Delete;
                                                            row_j_item.AddComment([ '�O��̍X�V�l�F"' comment_text '"']);
                                                        end
                                                    end
                                                end
                                                for l = 1:length(row_j.Columns.Value)
                                                    if ~isempty(row_j.Columns.Item(l).Comment) && row_j.Columns.Item(l).Font.ColorIndex~= 3
                                                        row_j.Columns.Item(l).Comment.Delete;
                                                    end
                                                end
                                           %% �X�V������̍X�V
                                                updated_deleted_row_add.Columns.Item(2).Value = run_time;
                                                updated_deleted_row_add.Columns.Item(2).Font.ColorIndex = 3;
                                                for k = 4: size(UsedRangeValue, 2)
                                                    if ~isempty(row_j.Columns.Item(k).Comment)
                                                        updated_deleted_row_add.Columns.Item(k + 1).AddComment(row_j.Columns.Item(k).Comment.Text);
                                                    end
                                                    updated_deleted_row_add.Columns.Item(k + 1).Value = row_j.Columns.Item(k).Value;
                                                    updated_deleted_row_add.Columns.Item(k + 1).Font.ColorIndex = row_j.Columns.Item(k).Font.ColorIndex;
                                                end
                                                updated_deleted_row_add.Value{size(UsedRangeValue, 2) + 1} = enum_info_temp{enum_info_temp_idx, 3};
                                                exlFile.Save;
                                                continue;
                                       %% Enum �폜
                                            elseif diff_type == 2
                                                % �{�V�[�g�̃f�[�^���폜����
                                                delete_rows{end + 1} = row_j;
                                          %% �X�V�����V�[�g�ɍ폜�f�[�ǉ�
                                                insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                                updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                                updated_deleted_row_add.Value{1} = row_j.Value{1};
                                                updated_deleted_row_add.Value{2} = row_j.Value{2};
                                                updated_deleted_row_add.Value{3} = run_time;
                                                updated_deleted_row_add.Columns.Item(3).Font.ColorIndex = 3;
                                                updated_deleted_row_add.Value{3 + 1} = enum_info_temp{enum_info_temp_idx, 1};
                    
                                                for k = 4: size(UsedRangeValue, 2)
                                                    if ~isempty(row_j.Columns.Item(k).Comment)
                                                        updated_deleted_row_add.Columns.Item(k + 1).AddComment(row_j.Columns.Item(k).Comment.Text);
                                                    end
                                                    updated_deleted_row_add.Value{k + 1} = row_j.Value{k};
                                                end
                                                updated_deleted_row_add.Value{size(UsedRangeValue, 2) + 1} = enum_info_temp{enum_info_temp_idx, 3};
                                                continue;
                                            else
                                                % nothing
                                            end
                                        else
                                            sprintf('Test');
                                        end
                                    end
                                    % �X�V����
                                    if isempty(Update_Data{index, 2})
                                        Update_Data{index, 2} = run_time;
                                    end
                                    insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                    updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                    updated_deleted_row_add.Value{1} = row_j.Value{1};
                                    updated_deleted_row_add.Value{2} = row_j.Value{2};
                                    updated_deleted_row_add.Value{3 + 1} = row_j.Value{3};
                                    
                                    for k = 4: size(UsedRangeValue, 2)
                                        updated_deleted_row_add.Value{k + 1} = row_j.Value{k};
                                   %% ProcessBar�X�V��------------------------------------------------��
                                        ProcessBar(sprintf('Processing�F%d/%d "%s" Sheet.�X�V�F %d/%d �s %d/%d ��', i, run_step, regexprep(sheet_name, '_', ' '), ...
                                                            j , size(UsedRangeValue, 1), k, size(UsedRangeValue, 2)), percent, 0, 0);
                                        if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                                            delete(bar);
                                            if ~isempty(e)
                                                try
                                                    exlFile.Close(false);
                                                    Quit(e);
                                                    delete(e);
                                                    delete(excel_file);
                                                catch
                                                end
                                            end
                                            result = 2;
                                            return;
                                        end
                                        if i == 4 && (has_data_name == 0 || k <= 6)
                                            if has_data_name == 0 && k > 6 && k < D_S_Index
                                                if (isnumeric(UsedRangeValue{j, k}) && isnan(UsedRangeValue{j, k}) ~= 1) || ...
                                                   (ischar(UsedRangeValue{j, k}) && ~isempty(UsedRangeValue{j, k}))
                                                    if isnan(UsedRangeValue{j, k}) == 1
                                                        check_string = '';
                                                    elseif isnumeric(UsedRangeValue{j, k}) == 1
                                                        check_string = num2str(UsedRangeValue{j, k});
                                                    elseif islogical(UsedRangeValue{j, k}) == 1
                                                        if UsedRangeValue{j, k} == 1
                                                            check_string = 'TRUE';
                                                        else
                                                            check_string = 'FALSE';
                                                        end
                                                    else
                                                        check_string = UsedRangeValue{j, k};
                                                    end
                                                    row_j.Columns.Item(2).Value = run_time;
                                                    row_j.Columns.Item(2).Font.ColorIndex = 3;
                                                    
                                                    row_j.Columns.Item(k).Value = '';
                                                    row_j.Columns.Item(k).Font.ColorIndex = 3;
                                                    row_j_item = row_j.Columns.Item(k);
                                                    try
                                                        row_j_item.AddComment([ '�O��̍X�V�l�F"' check_string '"']);
                                                    catch
                                                        if ~isempty(row_j_item.Comment)
                                                            row_j_item.Comment.Delete;
                                                            row_j_item.AddComment([ '�O��̍X�V�l�F"' check_string '"']);
                                                        end
                                                    end
                                                    updated_flag = 1;
                                                end
                                            end
                                            continue;
                                        end
                                   %% ProcessBar�X�V ��------------------------------------------------��
                                        %if k <= size(Update_Data, 2)
                                        if k <= D_S_Index
                                            if isnan(UsedRangeValue{j, k}) == 1
                                                UsedRangeValue{j, k} = '';
                                            end
                                            if isnumeric(Update_Data{index, k})
                                                if isnumeric(UsedRangeValue{j, k})
                                                    if length(Update_Data{index, k}) == 1 && ...
                                                        strcmp(class(Update_Data{index, k}), 'double') && ...
                                                        length(UsedRangeValue{j, k}) == 1 && ...
                                                        strcmp(class(UsedRangeValue{j, k}), 'double')
                                                        
                                                        if strcmp(sprintf('%.12f', UsedRangeValue{j, k}), sprintf('%.12f', Update_Data{index, k}))
                                                            continue;
                                                        end
                                                    end
                                                    if UsedRangeValue{j, k} ~= Update_Data{index, k}
                                                        row_j.Columns.Item(2).Value = run_time;
                                                        row_j.Columns.Item(2).Font.ColorIndex = 3;
                                                        if length(Update_Data{index, k}) > 1
                                                            try
                                                                row_j.Columns.Item(k).Value = [ '[' num2str(Update_Data{index, k}) ']' ];
                                                            catch
                                                                tempVal = Update_Data{index, k};
                                                                add_string = '';
                                                                for x = 1: size(tempVal, 1)
                                                                    if x == 1
                                                                        add_string = sprintf('[\n%s\n', num2str(tempVal(x,:)));
                                                                    elseif x == size(tempVal, 1)
                                                                        add_string = [ add_string sprintf('%s\n]', num2str(tempVal(x,:))) ];
                                                                    else
                                                                        add_string = [ add_string sprintf('%s\n', num2str(tempVal(x,:))) ];
                                                                    end
                                                                end
                                                                row_j.Columns.Item(k).Value = add_string;
                                                            end
                                                        else
                                                            if isempty(num2str(Update_Data{index, k}))
                                                                row_j.Columns.Item(k).Value = '[]';
                                                            else
                                                                row_j.Columns.Item(k).Value = num2str(Update_Data{index, k}, 16);
                                                            end
                                                        end
                                                        row_j.Columns.Item(k).Font.ColorIndex = 3;
                                                        row_j_item = row_j.Columns.Item(k);
                                                        try
                                                            row_j_item.AddComment([ '�O��̍X�V�l�F"' num2str(UsedRangeValue{j, k}) '"']);
                                                        catch
                                                            if ~isempty(row_j_item.Comment)
                                                                row_j_item.Comment.Delete;
                                                                row_j_item.AddComment([ '�O��̍X�V�l�F"' num2str(UsedRangeValue{j, k}) '"']);
                                                            end
                                                        end
                                                        updated_flag = 1;
                                                    end
                                                else
                                                    if length(Update_Data{index, k}) > 1
                                                        try
                                                            check_string = [ '[' num2str(Update_Data{index, k}) ']' ];
                                                        catch
                                                            tempVal = Update_Data{index, k};
                                                            check_string = '';
                                                            for x = 1: size(tempVal, 1)
                                                                if x == 1
                                                                    check_string = sprintf('[\n%s\n', num2str(tempVal(x,:)));
                                                                elseif x == size(tempVal, 1)
                                                                    check_string = [ check_string sprintf('%s\n]', num2str(tempVal(x,:))) ];
                                                                else
                                                                    check_string = [ check_string sprintf('%s\n', num2str(tempVal(x,:))) ];
                                                                end
                                                            end
                                                        end
                                                    else
                                                        if isempty(num2str(Update_Data{index, k}))
                                                            check_string = '[]';
                                                        else
                                                            check_string  = num2str(Update_Data{index, k});
                                                        end
                                                    end
                                                    if ~strcmp(UsedRangeValue{j, k}, check_string)
                                                        row_j.Columns.Item(2).Value = run_time;
                                                        row_j.Columns.Item(2).Font.ColorIndex = 3;
                                                        
                                                        row_j.Columns.Item(k).Value = check_string;
                                                        row_j.Columns.Item(k).Font.ColorIndex = 3;
                                                        row_j_item = row_j.Columns.Item(k);
                                                        try
                                                            row_j_item.AddComment([ '�O��̍X�V�l�F"' UsedRangeValue{j, k} '"']);
                                                        catch
                                                            if ~isempty(row_j_item.Comment)
                                                                row_j_item.Comment.Delete;
                                                                row_j_item.AddComment([ '�O��̍X�V�l�F"' UsedRangeValue{j, k} '"']);
                                                            end
                                                        end
                                                        updated_flag = 1;
                                                    end
                                                end
                                            else
                                                if isnan(UsedRangeValue{j, k}) == 1
                                                    check_string = '';
                                                elseif isnumeric(UsedRangeValue{j, k}) == 1
                                                    check_string = num2str(UsedRangeValue{j, k});
                                                elseif islogical(UsedRangeValue{j, k}) == 1
                                                    if UsedRangeValue{j, k} == 1
                                                        check_string = 'TRUE';
                                                    else
                                                        check_string = 'FALSE';
                                                    end
                                                else
                                                    check_string = UsedRangeValue{j, k};
                                                end
                                                if islogical(Update_Data{index, k})
                                                    if Update_Data{index, k} == 1
                                                        Update_Data{index, k} = 'TRUE';
                                                    else
                                                        Update_Data{index, k} = 'FALSE';
                                                    end
                                                end
                                                if ~strcmp(check_string, Update_Data{index, k})
                                                    row_j.Columns.Item(2).Value = run_time;
                                                    row_j.Columns.Item(2).Font.ColorIndex = 3;
                                                    
                                                    row_j.Columns.Item(k).Value = Update_Data{index, k};
                                                    row_j.Columns.Item(k).Font.ColorIndex = 3;
                                                    row_j_item = row_j.Columns.Item(k);
                                                    try
                                                        row_j_item.AddComment([ '�O��̍X�V�l�F"' check_string '"']);
                                                    catch
                                                        if ~isempty(row_j_item.Comment)
                                                            row_j_item.Comment.Delete;
                                                            row_j_item.AddComment([ '�O��̍X�V�l�F"' check_string '"']);
                                                        end
                                                    end
                                                    updated_flag = 1;
                                                end
                                            end
                                        end
                                    end
                                    % �s�ɍX�V���Ȃ��ꍇ
                                    if updated_flag == 0
                                        updated_deleted_row_add.Delete();
                                        insert_index_Updated_sheet = insert_index_Updated_sheet -1;
                                    else
                                   %% �ǉ��̏ꍇ�A�X�V�����V�[�g�Ƀf�[�^�ҏW
                                        if i == 4 && isnumeric(updated_deleted_row_add.Value{4}) == 1 && isnan(updated_deleted_row_add.Value{4}) == 1
                                            updated_deleted_row_add.Value{3} = enum_info_temp{enum_info_temp_idx, 1};
                                            updated_deleted_row_add.Value{13} = enum_info_temp{enum_info_temp_idx, 3};
                                        end
                                        for l = 1:length(row_j.Columns.Value)
                                            if ~isempty(row_j.Columns.Item(l).Comment) && row_j.Columns.Item(l).Font.ColorIndex~= 3
                                                row_j.Columns.Item(l).Comment.Delete;
                                            end
                                        end
                                        updated_deleted_row_add.Columns.Item(2).Value = run_time;
                                        updated_deleted_row_add.Columns.Item(2).Font.ColorIndex = 3;
                                        for k = 4: size(UsedRangeValue, 2)
                                            if ~isempty(row_j.Columns.Item(k).Comment)
                                                updated_deleted_row_add.Columns.Item(k + 1).AddComment(row_j.Columns.Item(k).Comment.Text);
                                            end
                                            updated_deleted_row_add.Columns.Item(k + 1).Value = row_j.Columns.Item(k).Value;
                                            updated_deleted_row_add.Columns.Item(k + 1).Font.ColorIndex = row_j.Columns.Item(k).Font.ColorIndex;
                                        end
                                    end
                                end
                            end
                        end
                    catch ex
                        errordlg([ex.message ' '  num2str(ex.stack(1).line)], 'Error', 'modal');
                        if ~isempty(e)
                            try
                                exlFile.Close(false);
                                Quit(e);
                                delete(e);
                                delete(excel_file);
                            catch
                            end
                        end
                        if ishandle(bar)
                           delete(bar);
                        end
                        result = 0;
                        return; 
                    end
                  %% �I (3) �D�ō쐬�������X�g�̃f�[�^�����I (1)�Ŏ擾�������X�g�ɑ��݂��Ȃ��ꍇ�A�ǉ��f�[�^�Ƃ��āA�V�[�g�ɒǉ�����B	
                	% �������A�����f�[�^���i�Ⴄ�f�[�^�\�[�X�j������ꍇ�A���̃f�[�^��������s�ɍs��}�����A�f�[�^��ǉ�����
                    %�u�ǉ������v��Ɏ��s�������Z�b�g����
                    % �e�L�X�g�̐F�͐Ԃ��F�Őݒ肷��
                    if i == 4 
                       for j = 1: size(enum_info_temp, 1)
                           if ~isempty(enum_info_temp{j, 1}) && isempty(enum_info_temp{j, 4})
                               enum_info_temp{j, 4} = 0;
                           end
                       end
                       enum_info_temp(3:end, :) = sortrows(enum_info_temp(3:end, :), 4);
                       if size(enum_info_temp, 1) > 2
                           for j = 3: size(enum_info_temp, 1)
                                check_array = enum_info_temp{j, 2};
                                if ~isempty(enum_info_temp{j, end}) && enum_info_temp{j, end} == 0
                                    enum_data = GetEnumData(enum_info_temp{j, 1}, enum_info_temp{j, 3}, run_time);
                                    if isempty(enum_data)
                                        continue;
                                    end
                                    find_index = find(strcmp(enum_info_temp{j, 1}, UsedRange.Value(3:end,3)));
                                    if ~isempty(find_index)
                                        insert_index = find_index(end) + 2;
                                        enum_data_exist = GetEnumData(enum_info_temp{j, 1}, UsedRange.Value{insert_index, D_S_Index}, run_time);
                                        insert_index = size(enum_data_exist, 1) + insert_index;
                                    else
                                        insert_index = UsedRange.Rows.Count + 1;
                                    end
                                    for k = 1: size(enum_data, 1)
                                        UsedRange.Rows.Item(insert_index).Insert;
                                        row_j = UsedRange.Rows.Item(insert_index);
                                        for l = 1:size(enum_data, 2)
                                            row_j.Columns.Item(l).Value = enum_data{k, l};
                                        end
                                        row_j.Font.ColorIndex = 3;
                                        insert_index = insert_index + 1;
                                   %% �ǉ��̏ꍇ�A�X�V�����V�[�g�Ƀf�[�^�ǉ�
                                        insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                        updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                        for l = 3: size(Update_Data, 2)
                                            updated_deleted_row_add.Columns.Item(l + 1).Value = row_j.Columns.Item(l).Value;
                                        end
                                        updated_deleted_row_add.Columns.Item(1).Value = run_time;
                                        updated_deleted_row_add.Columns.Item(1).Font.ColorIndex = 3;
                                    end
                                    UsedRange = sheet_data.UsedRange;
                                    [ ref, NullRowIndex ]= GetNullRowIndex(UsedRange, sheet_name);
                                    if ref == 0
                                        result = 2;
                                        return;
                                    end
                                    if NullRowIndex > 0
                                        new_range = regexprep(UsedRange.AddressLocal, '\d+$', num2str(NullRowIndex - 1));
                                        UsedRange = sheet_data.Range(new_range);
                                    end
                                    continue;
                                end
                                for k = 1: size(check_array, 1)
                                    if strcmp(check_array{k, 4}, '*')
                                        continue;
                                    end
                                    if k == 1
                                        insert_index = enum_info_temp{j, end} + k - 1;
                                    else
                                        start = enum_info_temp{j, end};
                                        find_index = 0;
                                        for l = start: UsedRange.Rows.Count
                                            if strcmp(UsedRange.Value{l,4}, check_array{k-1, 1})
                                                find_index = l- start + 1;
                                                break
                                            end
                                        end
                                        insert_index = enum_info_temp{j, end} + find_index;
                                    end
                                    if isempty(insert_index)
                                        continue;
                                    end
                                    UsedRange.Rows.Item(insert_index).Insert;
                                    row_j = UsedRange.Rows.Item(insert_index);
                                    row_j.Columns.Item(1).Value = run_time;
                                    row_j.Font.ColorIndex = 3; 
                                    row_j.Columns.Item(4).Value = check_array{k, 1};
                                    row_j.Columns.Item(5).Value = check_array{k, 2};
                                    row_j.Columns.Item(6).Value = check_array{k, 3};
                                    if k == 1
                                        old_row = UsedRange.Rows.Item(insert_index + 1);
                                        row_j.Columns.Item(3).Value = old_row.Columns.Item(3).Value ;
                                        old_row.Columns.Item(3).Value = '';
                                        
                                        for l = 7: D_S_Index
                                            row_j.Columns.Item(l).Value = old_row.Columns.Item(l).Value ;
                                            old_row.Columns.Item(l).Value = '';
                                        end
                                    end
                                %% �ǉ��̏ꍇ�A�X�V�����V�[�g�Ƀf�[�^�ǉ�
                                    insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                                    updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                                    for l = 3: size(Update_Data, 2)
                                        updated_deleted_row_add.Columns.Item(l + 1).Value = row_j.Columns.Item(l).Value;
                                    end
                                    updated_deleted_row_add.Columns.Item(1).Value = run_time;
                                    updated_deleted_row_add.Columns.Item(1).Font.ColorIndex = 3;
                                end
                                UsedRange = sheet_data.UsedRange;
                                [ ref, NullRowIndex ]= GetNullRowIndex(UsedRange, sheet_name);
                                if ref == 0
                                    result = 2;
                                    return;
                                end
                                if NullRowIndex > 0
                                    new_range = regexprep(UsedRange.AddressLocal, '\d+$', num2str(NullRowIndex - 1));
                                    UsedRange = sheet_data.Range(new_range);
                                end
                                enum_info_temp = UpdateIndex(enum_info_temp, UsedRange.Value);
                           end
                       end
                    end
                    add_count = 0;
                    if size(Update_Data, 1) > 2 && i ~= 4
                        start_row_index = UsedRange.Rows.Count + 1;
                        count = find(strcmp('', Update_Data(3:end, 2)));
                        count = length(count);
                        for j = 3: size(Update_Data, 1)
                            UsedRangeValue = UsedRange.Value;
                            if ~isempty(Update_Data{j, 2})
                                continue;
                            end
                        %% ProcessBar�X�V ��------------------------------------------------��
                            add_count = add_count + 1;
                            ProcessBar(sprintf('Processing�F%d/%d "%s" Sheet.�ǉ��F %d/%d �s', i, run_step, regexprep(sheet_name, '_', ' '), ...
                                                add_count , count), percent, 0, 0);
                            if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                                delete(bar);
                                if ~isempty(e)
                                    try
                                        exlFile.Close(false);
                                        Quit(e);
                                        delete(e);
                                        delete(excel_file);
                                    catch
                                    end
                                end
                                result = 2;
                                return;
                            end
                         %% ProcessBar�X�V ��------------------------------------------------��
                            [search_index] = find(strcmp(Update_Data{j, 3}, UsedRangeValue(3:end, 3)));
                            if ~isempty(search_index)
                                index = search_index(end) + 2;
                                UsedRange.Rows.Item(index).Insert;
                                row_j = UsedRange.Rows.Item(index);
                            else
                                row_j = UsedRange.Rows.Item(start_row_index);
                            end
                            for k = 1: size(Update_Data, 2)
                                if isnumeric(Update_Data{j, k})
                                    if length(Update_Data{j, k}) > 1
                                        try
                                            add_string = [ '[' num2str(Update_Data{j, k}) ']' ];
                                        catch
                                            tempVal = Update_Data{j, k};
                                            add_string = '';
                                            for x = 1: size(tempVal, 1)
                                                if x == 1
                                                    add_string = sprintf('[\n%s\n', num2str(tempVal(x,:)));
                                                elseif x == size(tempVal, 1)
                                                    add_string = [ add_string sprintf('%s\n]', num2str(tempVal(x,:))) ];
                                                else
                                                    add_string = [ add_string sprintf('%s\n', num2str(tempVal(x,:))) ];
                                                end
                                            end
                                        end
                                    else
                                        if isempty(num2str(Update_Data{j, k}))
                                            add_string = '[]';
                                        else
                                            add_string  = num2str(Update_Data{j, k}, 16);
                                        end
                                    end
                                else
                                    add_string  = Update_Data{j, k};
                                end
                                row_j.Columns.Item(k).Value = add_string;
                            end
                            row_j.Font.ColorIndex = 3;
                         %% �ǉ��̏ꍇ�A�X�V�����V�[�g�Ƀf�[�^�ǉ�
                            insert_index_Updated_sheet = insert_index_Updated_sheet + 1;
                            updated_deleted_row_add = Updated_sheet_data.Rows.Item(insert_index_Updated_sheet);
                            for k = 3: size(Update_Data, 2)
                                updated_deleted_row_add.Columns.Item(k + 1).Value = row_j.Columns.Item(k).Value;
                            end
                            updated_deleted_row_add.Columns.Item(1).Value = run_time;
                            updated_deleted_row_add.Columns.Item(1).Font.ColorIndex = 3;
                            
                            start_row_index = start_row_index + 1;
                            UsedRange = sheet_data.UsedRange;
                            [ ref, NullRowIndex ]= GetNullRowIndex(UsedRange, sheet_name);
                            if ref == 0
                                result = 2;
                                return;
                            end
                            if NullRowIndex > 0
                                new_range = regexprep(UsedRange.AddressLocal, '\d+$', num2str(NullRowIndex - 1));
                                UsedRange = sheet_data.Range(new_range);
                            end
                        end
                    end
                    if ~isempty(delete_rows)
                        for j = 1: length(delete_rows)
                        %% ProcessBar�X�V ��------------------------------------------------��
                            ProcessBar(sprintf('Processing�F%d/%d "%s" Sheet.�폜�F %d/%d �s', i, run_step, regexprep(sheet_name, '_', ' '), ...
                                                j , length(delete_rows)), percent, 0, 0);
                            if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                                delete(bar);
                                if ~isempty(e)
                                    try
                                        exlFile.Close(false);
                                        Quit(e);
                                        delete(e);
                                        delete(excel_file);
                                    catch
                                    end
                                end
                                result = 2;
                                return;
                            end
                         %% ProcessBar�X�V ��------------------------------------------------��
                            if ischar(delete_rows{j}.Columns.Item(3).Value) && ~isempty(delete_rows{j}.Columns.Item(3).Value)
                                delete_row_index = delete_rows{j}.Row;
                                next_row = UsedRange.Rows.Item(delete_row_index + 1);
                                if (isnumeric(next_row.Columns.Item(3).Value) && isnan(next_row.Columns.Item(3).Value)) ||  ...
                                    (ischar(next_row.Columns.Item(3).Value) && isempty(next_row.Columns.Item(3).Value))
                                    next_row.Value(1:3) = delete_rows{j}.Value(1:3);
                                    next_row.Columns.Item(2).Value = '';
                                    next_row.Value(7:D_S_Index) = delete_rows{j}.Value(7:D_S_Index);
                                end
                            end
                            delete_rows{j}.Delete;
                            if j == length(delete_rows)
                                UsedRange.Rows.Item(UsedRange.Rows.Count + 1).Delete;
                            end
                        end
                    end
                    continue;
                end
                % �V�[�g�����݂��Ȃ��ꍇ�A���L�ɐV�K�V�[�g�쐬
            end
            if ~isempty(e)
                exlFile.Save;
                Quit(e);
                delete(e);
                e = [];
            end
            switch(i)
                case 1
                    if size(in_out_signal_info, 1) > 2
                        xlswrite(excel_file, in_out_signal_info, 'signal');
                    end
                case 2
                    if size(parameter_info, 1) > 2
                        xlswrite(excel_file, parameter_info, 'parameter');
                    end
                case 3
                    if size(aliastype_info, 1) > 2
                        xlswrite(excel_file, aliastype_info, 'alias'); 
                    end
                case 4
                    if size(enum_info, 1) > 2
                        if size(enum_info, 1) > 3
                            for j = size(enum_info, 1): -1:4
                                 if strcmp(enum_info{j, 3}, enum_info{j - 1, 3}) && ...  
                                    strcmp(enum_info{j, 13}, enum_info{j - 1, 13})     
                                    enum_info{j, 3} = '';
                                    enum_info{j, 13} = '';
                                end
                           end
                        end
                        xlswrite(excel_file, enum_info, 'enum'); 
                    end
                otherwise
                  %% �J �D��Class�𔻒f�ł��Ȃ����̂́unot_export_list�v�V�[�g�ɏ�������
                    if size(notExportDataName, 1) > 1
                        xlswrite(excel_file, notExportDataName, 'not_export_list'); 
                    end
            end
        end
       %% ProcessBar�X�V��------------------------------------------------��
        percent = 1;
        ProcessBar(sprintf('Processing�FClosing.'), percent, 0, 1);
       %% ProcessBar�X�V��------------------------------------------------��
        if exist(excel_file) == 2
            if isempty(e)
                e = actxserver('Excel.Application');
                eWorkbooks = e.Workbooks;
                exlFile = eWorkbooks.Open(excel_file);
            end
        end
       %% 	�K �uConfidential�v�iA1 Cell)�̐F�͐Ԃ��Ƃ���
        %     �S��Cells��WrapText = false ��ݒ肷��
        %     �S��Cells��Border���i�q�Őݒ肷��
        try
            signal_Sheet = exlFile.Sheets.Item('signal');
            signal_A1 = signal_Sheet.Range('A1');
            signal_A1.Font.ColorIndex = 3;
            used_range = signal_Sheet.UsedRange;
            used_range.WrapText = 0;
            borderDrawRangeAddress = regexprep(used_range.AddressLocal, '$A$1', '$A$2');
            borderDrawRange = signal_Sheet.Range(borderDrawRangeAddress);
            borderDrawRange.Borders.LineStyle = 1;
        catch
        end
        try
            parameter_Sheet = exlFile.Sheets.Item('parameter');
            parameter_A1 = parameter_Sheet.Range('A1');
            parameter_A1.Font.ColorIndex = 3;
            used_range = parameter_Sheet.UsedRange;
            used_range.WrapText = 0;
            borderDrawRangeAddress = regexprep(used_range.AddressLocal, '$A$1', '$A$2');
            borderDrawRange = parameter_Sheet.Range(borderDrawRangeAddress);
            borderDrawRange.Borders.LineStyle = 1;
        catch
        end
        try
            alias_Sheet = exlFile.Sheets.Item('alias');
            alias_A1 = alias_Sheet.Range('A1');
            alias_A1.Font.ColorIndex = 3;
            used_range = alias_Sheet.UsedRange;
            used_range.WrapText = 0;
            borderDrawRangeAddress = regexprep(used_range.AddressLocal, '$A$1', '$A$2');
            borderDrawRange = alias_Sheet.Range(borderDrawRangeAddress);
            borderDrawRange.Borders.LineStyle = 1;
        catch
        end
        try
            enum_Sheet = exlFile.Sheets.Item('enum');
            enum_A1 = enum_Sheet.Range('A1');
            enum_A1.Font.ColorIndex = 3;
            used_range = enum_Sheet.UsedRange;
            used_range.WrapText = 0;
            used_range.Borders.LineStyle = 1;
            borderDrawRangeAddress = regexprep(used_range.AddressLocal, '$A$1', '$A$2');
            borderDrawRange = enum_Sheet.Range(borderDrawRangeAddress);
            borderDrawRange.Borders.LineStyle = 1;
        catch
        end
        
        for i = 1: length(UpdateSheetName)
            try
                UpdateSheetName_i = exlFile.Sheets.Item(UpdateSheetName{i});
                enum_A1 = UpdateSheetName_i.Range('A1');
                enum_A1.Font.ColorIndex = 3;
                used_range = UpdateSheetName_i.UsedRange;
                if used_range.Rows.Count <= 2
                    exlFile.Sheets.Item(UpdateSheetName{i}).Visible = 0;
                    continue;
                end
                used_range.WrapText = 0;
                borderDrawRangeAddress = regexprep(used_range.AddressLocal, '$A$1', '$A$2');
                borderDrawRange = UpdateSheetName_i.Range(borderDrawRangeAddress);
                borderDrawRange.Borders.LineStyle = 1;
            catch
                continue;
            end
        end
    catch ex
        errordlg([ex.message ' '  num2str(ex.stack(1).line)], 'Error', 'modal');
        if ~isempty(e)
            try
                exlFile.Close(false);
                Quit(e);
                delete(e);
                delete(excel_file);
            catch
            end
        end
        if ishandle(bar)
           delete(bar);
        end
        result = 0;
        return;
    end
%     if ~isempty(e)
%         exlFile.Save;
%         Quit(e);
%         delete(e);
%         e = [];
%     end
    try
%         check_flag = 1;
%         if isRunFromRunAcg == 1
%             selectButton = questdlg('Do you want check used variables?', 'QUESTION', 'Yes', 'No', 'Yes');
%             if isempty(selectButton) || strcmp(selectButton, 'No')
%                 check_flag = 0;
%             end
%         end
%        if hasCheckNonUsedVariables == 1 && check_flag == 1
        if hasCheckNonUsedVariables == 1
            write_info_flag = 1;
            variables_use_info_in = {};
            variables_use_info_in{end+1, 1} = '�ϐ���'; 
            variables_use_info_in{end, 2} = '�g�p���f����';
            variables_use_info_in{end, 3} = 'SLDD��';
            null_var_name = {};
            if length(model_handle_lst)>= 2
                for i = 2: length(model_handle_lst)
                    try
                        close_system(model_handle_lst{i});
                    catch
                        if isRunFromRunAcg == 1
                            warndlg(sprintf('Can not close model that not save. Please make sure %s model is saved and try again.', get(model_handle_lst{i}, 'Name')), 'WARNING');                        
                        else
                            warndlg(sprintf('Can not close model that not save. Please make sure %s model is saved and try again.', get(model_handle_lst{i}, 'Name')), 'WARNING', 'modal');
                        end
                        result = 0;
                        if ~isempty(e)
                            exlFile.Save;
                            Quit(e);
                            delete(e);
                            e = [];
                        end
                        write_info_flag = 0;
                        break;
                    end
                end
            end
            if write_info_flag == 1
            %% SLDD���̃��X�g��SLDD�����ƂɈȉ��̏������s��
                for i = 1:length(sldd_filename_lst)
                    if write_info_flag == 0
                        ProcessBar('Processing End', 0, 1, 1);
                        break;
                    end
                   %% ProcessBar�X�V��------------------------------------------------��
                    if i == 1
                        ProcessBar('Processing Start', 0, 1, 0);
                    end
                    if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                        delete(bar);
                        result = 2;
                        if ~isempty(e)
                            exlFile.Save;
                            Quit(e);
                            delete(e);
                            e = [];
                        end
                        write_info_flag = 0;
                        break;
                    end
                    percent = i/length(sldd_filename_lst);
                    ProcessBar(sprintf('Processing: Check Used Variables of SLDD�F%s.', regexprep(regexprep(sldd_filename_lst{i}, '_', ' '), '_', ' ')), percent, 0, 0);
                   %% ProcessBar�X�V��------------------------------------------------��
                  %% ���f����SLDD��t���Ȃ��ꍇ�A�������΂�
                    if isempty(sldd_filename_lst{i})
                        continue;
                    end
                  %% ���f�����[�h
                    model_handle = load_system(model_name_lst{i});
                  %% SLDD�t�@�C������SLDD���擾
                    try
                        myDictionaryObj = Simulink.data.dictionary.open(sldd_filename_lst{i});
                        slddSection = myDictionaryObj.getSection('Design Data');
                    catch
                        if isRunFromRunAcg == 1
                            warndlg(sprintf('Can not load SLDD file. Please make sure %s SLDD file is added in matlab path.', sldd_filename_lst{i}), 'WARNING');
                        else
                            warndlg(sprintf('Can not load SLDD file. Please make sure %s SLDD file is added in matlab path.', sldd_filename_lst{i}), 'WARNING', 'modal');
                        end
                        if ishandle(bar)
                            delete(bar);
                        end
                        result = 0;
                        if ~isempty(e)
                            exlFile.Save;
                            Quit(e);
                            delete(e);
                            e = [];
                        end
                        write_info_flag = 0;
                        break;
                    end
                   %% �M���A�p�����[�^���g�p���Ă��Ȃ����`�F�b�N
                     sldd_data = slddSection.find;
                     [ result_flag, variables_use_info, null_var_name, model_ref_blks ] = CheckNonUsedVariables(sldd_data, model_handle, variables_use_info_in, null_var_name);
                     if result_flag == 0
                        if ishandle(bar)
                           delete(bar);
                        end
                        if ~isempty(e)
                            exlFile.Save;
                            Quit(e);
                            delete(e);
                            e = [];
                        end
                        write_info_flag = 0;
                        break;
                     end
                    if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
                        delete(bar);
                        result = 2;
                        if ~isempty(e)
                            exlFile.Save;
                            Quit(e);
                            delete(e);
                            e = [];
                        end
                        write_info_flag = 0;
                        break;
                    end
                     variables_use_info_in = variables_use_info;
                     for j = 1: length(model_ref_blks)
                         try
                             % ���f�����J���Ă��邩�`�F�b�N
                             try
                                get_param(model_ref_blks(j), 'handle');
                             catch
                                 continue;
                             end
                             % ���f�������
                             close_system(model_ref_blks(j));
                         catch
                             if isRunFromRunAcg == 1
                                warndlg(sprintf('Can not close model that not save. Please make sure %s model is saved and try again.', get(model_ref_blks(j), 'Name')), 'WARNING');
                             else
                                warndlg(sprintf('Can not close model that not save. Please make sure %s model is saved and try again.', get(model_ref_blks(j), 'Name')), 'WARNING', 'modal');
                             end
                             if ishandle(bar) 
                                 delete(bar);
                             end      
                             result = 2;
                            if ~isempty(e)
                                exlFile.Save;
                                Quit(e);
                                delete(e);
                                e = [];
                            end
                             write_info_flag = 0;
                             break;
                         end
                     end
                end
                ProcessBar('Processing: write Info of Used Variables to excel file', percent, 0, 1);
            end
            if write_info_flag == 1
                try
                    signal_Sheet = exlFile.Sheets.Item('signal');
                    parameter_Sheet = exlFile.Sheets.Item('parameter');
                catch
                    write_info_flag = 0;
                end
                
                if write_info_flag == 1
                    used_range = signal_Sheet.UsedRange;
                    used_range.Interior.ColorIndex = 2;
                    for i = 3: size(used_range.Value, 1)
                        if isnumeric(used_range.Value{i, 3})
                            continue;
                        end
                        var_name = used_range.Value{i, 3};
                        sldd_name = used_range.Value{i, 27};
                        set_flag = 0;
                        if ismember(var_name, variables_use_info(1:end, 1))                    
                            var_index = find(strcmp(var_name, variables_use_info(1:end, 1)));
                            for j = 1: length(var_index)
                                if Check_SLDD(sldd_name, variables_use_info{var_index(j), 3}) == 1
                                    used_range.Rows.Item(i).Columns.Item(28).Value = variables_use_info{var_index(j), 2};
                                    if isempty(variables_use_info{var_index(j), 2})
                                        used_range.Rows.Item(i).Columns.Item(28).Value = 'Not in model';	            
                                        used_range.Rows.Item(i).Interior.ColorIndex = 6;
                                    end
                                    set_flag = 1;
                                    break;
                                end
                            end
                            if set_flag == 0
                                used_range.Rows.Item(i).Columns.Item(28).Value = 'Not in model';	 
                                used_range.Rows.Item(i).Interior.ColorIndex = 6;
                            end
                        else
                             used_range.Rows.Item(i).Columns.Item(28).Value = 'Not in model';	 
                             used_range.Rows.Item(i).Interior.ColorIndex = 6;
                        end
                    end
                    exlFile.Save;
                    used_range = parameter_Sheet.UsedRange;
                    used_range.Interior.ColorIndex = 2;
                    for i = 3: size(used_range.Value, 1)
                        if isnumeric(used_range.Value{i, 3})
                            continue;
                        end
                        var_name = used_range.Value{i, 3};
                        sldd_name = used_range.Value{i, 21};
                        set_flag = 0;
                        if ismember(var_name, variables_use_info(1:end, 1))
                            var_index = find(strcmp(var_name, variables_use_info(1:end, 1)));
                            for j = 1: length(var_index)
                                if Check_SLDD(sldd_name, variables_use_info{var_index(j), 3}) == 1
                                    used_range.Rows.Item(i).Columns.Item(22).Value = variables_use_info{var_index(j), 2};
                                    if isempty(variables_use_info{var_index(j), 2})
                                        used_range.Rows.Item(i).Columns.Item(22).Value = 'Not in model';	  
                                        used_range.Rows.Item(i).Interior.ColorIndex = 6;
                                    end
                                    set_flag = 1;
                                    break;
                                end
                            end
                            if set_flag == 0
                                used_range.Rows.Item(i).Columns.Item(22).Value = 'Not in model';	    
                                used_range.Rows.Item(i).Interior.ColorIndex = 6;
                            end
                        else
                             used_range.Rows.Item(i).Columns.Item(22).Value = 'Not in model';	 
                             used_range.Rows.Item(i).Interior.ColorIndex = 6;
                        end
                    end
                end
            else
                try
                    e = actxserver('Excel.Application');
                    eWorkbooks = e.Workbooks;
                    exlFile = eWorkbooks.Open(excel_file);
                    signal_Sheet = exlFile.Sheets.Item('signal');
                    parameter_Sheet = exlFile.Sheets.Item('parameter');
                    used_range = signal_Sheet.UsedRange;
                    used_range.Interior.ColorIndex = 2;
                    for i = 3: size(used_range.Value, 1)
                        if isnumeric(used_range.Value{i, 3})
                            continue;
                        end
                        used_range.Rows.Item(i).Columns.Item(28).Value = '[]';
                    end
                    exlFile.Save;
                    used_range = parameter_Sheet.UsedRange;
                    used_range.Interior.ColorIndex = 2;
                    for i = 3: size(used_range.Value, 1)
                        if isnumeric(used_range.Value{i, 3})
                            continue;
                        end
                        used_range.Rows.Item(i).Columns.Item(22).Value = '[]';
                    end
                catch
                    % nothing
                end
            end
        else
            used_range = signal_Sheet.UsedRange;
            used_range.Interior.ColorIndex = 2;
            for i = 3: size(used_range.Value, 1)
                if isnumeric(used_range.Value{i, 3})
                    continue;
                end
                used_range.Rows.Item(i).Columns.Item(28).Value = 'Unchecked';
            end
            exlFile.Save;
            used_range = parameter_Sheet.UsedRange;
            used_range.Interior.ColorIndex = 2;
            for i = 3: size(used_range.Value, 1)
                if isnumeric(used_range.Value{i, 3})
                    continue;
                end
                used_range.Rows.Item(i).Columns.Item(22).Value = 'Unchecked';
            end
        end
        if ~isempty(e)
            exlFile.Save;
            Quit(e);
            delete(e);
        end
       %% �L ����Temp�t�@�C�����o�̓t�@�C���ɃR�s�[����
        waitfor(copyfile(excel_file, final_excel_file, 'f'));
       %% �M ����Temp�t�@�C�����폜����
        delete(excel_file);
        %% �N RunAcg����N���̏ꍇ�A���[�h�������f�������
        if isRunFromRunAcg == 1
            for i = 1: size(model_info, 1)
                if model_info{i, 5} == 1
                    try
                        close_system(model_info{i, 1});
                    catch
                        continue;
                    end
                end
            end
        else
            waitfor(msgbox('SLDD info is exported completely into excel file.', 'Info', 'modal'));
        end
    catch ex
        if ishandle(bar)
           delete(bar);
        end
        errordlg([ex.message ' '  num2str(ex.stack(1).line)], 'Error', 'modal');
    end
end

%% SLDD���烂�f���̓��o�̓C���^�[�t�F�[�X��Excel�t�@�C���ɏo�͂���z��f�[�^�̍\���쐬
function [ in_out_signal_info, parameter_info, aliastype_info, enum_info, notExportDataName ] = MakeStructureOutputOfModelInterface()
    %% Simulink.Signal�Ampt.Signal�^�C�v
    in_out_signal_info = {};
    in_out_signal_info{end + 1, 1} = 'Confidential'; 
    
    in_out_signal_info{end + 1, 1} = '�ǉ�����'; 
    in_out_signal_info{end, 2} = '�ŏI�X�V����'; 
    in_out_signal_info{end, 3} = 'Name';
    in_out_signal_info{end, 4} = 'Inport/Outport';
    in_out_signal_info{end, 5} = 'Class';
    in_out_signal_info{end, 6} = 'StorageClass';
    in_out_signal_info{end, 7} = 'Alias';
    in_out_signal_info{end, 8} = 'Alignment';
    in_out_signal_info{end, 9} = 'CustomStorageClass';
    in_out_signal_info{end, 10} = 'CustomAttributes.MemorySection';
    in_out_signal_info{end, 11} = 'CustomAttributes.HeaderFile';
    in_out_signal_info{end, 12} = 'CustomAttributes.Owner';
    in_out_signal_info{end, 13} = 'CustomAttributes.DefinitionFile';
    in_out_signal_info{end, 14} = 'CustomAttributes.ConcurrentAccess';
    in_out_signal_info{end, 15} = 'CustomAttributes.PersistenceLevel';
    in_out_signal_info{end, 16} = 'Description';
    in_out_signal_info{end, 17} = 'DataType';
    in_out_signal_info{end, 18} = 'Min';
    in_out_signal_info{end, 19} = 'Max';
    in_out_signal_info{end, 20} = 'DocUnits';
    in_out_signal_info{end, 21} = 'Dimensions';
    in_out_signal_info{end, 22} = 'DimensionsMode';
    in_out_signal_info{end, 23} = 'Complexity';
    in_out_signal_info{end, 24} = 'SampleTime';
    in_out_signal_info{end, 25} = 'SamplingMode';
    in_out_signal_info{end, 26} = 'InitialValue';
    in_out_signal_info{end, 27} = 'DataSource';
    in_out_signal_info{end, 28} = 'UsedInModel';
    
    %% Simulink.Parameter�Ampt.Parameter�^�C�v
    parameter_info = {};
    parameter_info{end + 1, 1} = 'Confidential'; 
    
    parameter_info{end + 1, 1} = '�ǉ�����'; 
    parameter_info{end, 2} = '�ŏI����'; 
    parameter_info{end, 3} = 'Name';
    parameter_info{end, 4} = 'Value';
    parameter_info{end, 5} = 'Class';
    parameter_info{end, 6} = 'CoderInfo.StorageClass';
    parameter_info{end, 7} = 'CoderInfo.Alias';
    parameter_info{end, 8} = 'CoderInfo.Alignment';
    parameter_info{end, 9} = 'CoderInfo.CustomStorageClass';
    parameter_info{end, 10} = 'CustomAttributes.MemorySection';
    parameter_info{end, 11} = 'CustomAttributes.HeaderFile';
    parameter_info{end, 12} = 'CustomAttributes.Owner';
    parameter_info{end, 13} = 'CustomAttributes.DefinitionFile';
    parameter_info{end, 14} = 'CustomAttributes.ConcurrentAccess';
    parameter_info{end, 15} = 'CustomAttributes.PersistenceLevel';
    parameter_info{end, 16} = 'Description';
    parameter_info{end, 17} = 'DataType';
    parameter_info{end, 18} = 'Min';
    parameter_info{end, 19} = 'Max';
    parameter_info{end, 20} = 'DocUnits';
    parameter_info{end, 21} = 'DataSource';
    parameter_info{end, 22} = 'UsedInModel';
    
    %% Simulink.AliasType�^�C�v
    aliastype_info = {};
    aliastype_info{end + 1, 1} = 'Confidential'; 
    
    aliastype_info{end + 1, 1} = '�ǉ�����'; 
    aliastype_info{end, 2} = '�ŏI����'; 
    aliastype_info{end, 3} = 'Name';
    aliastype_info{end, 4} = 'Description';
    aliastype_info{end, 5} = 'DataScope';
    aliastype_info{end, 6} = 'HeaderFile';
    aliastype_info{end, 7} = 'BaseType';
    aliastype_info{end, 8} = 'DataSource';
    
    %% Simulink.data.dictionary.EnumTypeDefinition�^�C�v
    enum_info = {};
    enum_info{end + 1, 1} = 'Confidential'; 
    
    enum_info{end + 1, 1} = '�ǉ�����'; 
    enum_info{end, 2} = '�ŏI����'; 
    enum_info{end, 3} = 'Name';
    enum_info{end, 4} = 'Enumerals_Name';
    enum_info{end, 5} = 'Enumerals_Value';
    enum_info{end, 6} = 'Enumerals_Description';
    enum_info{end, 7} = 'DefaultValue';    
    enum_info{end, 8} = 'StorageType';
    enum_info{end, 9} = 'DataScope';
    enum_info{end, 10} = 'HeaderFile';
    enum_info{end, 11} = 'AddClassNameToEnumNames';
    enum_info{end, 12} = 'Description';
    enum_info{end, 13} = 'DataSource';

    %% �����ʂ���f�[�^��
    notExportDataName = {};
    notExportDataName{end + 1, 1} = '�ǉ�����'; 
    notExportDataName{end, 2} = '�ŏI�X�V����'; 
    notExportDataName{end, 3} = 'Type';
    notExportDataName{end, 4} = 'Name';
    notExportDataName{end, 5} = 'DataSource';
end

%% CoderInfo.CustomAttributes�̑������ɂ��l���擾����
function value = GetCustomAttributesPropertyValue(sldd_data_info_in, PropertyName)
    try
        sldd_data_info = sldd_data_info_in;
        % CustomAttributes�̑������ɂ��l���擾����
        value = eval([ 'sldd_data_info.CoderInfo.CustomAttributes.' PropertyName ]);
    catch
        % �������ꍇ�A�G���[���o�邪�A�������ċ󔒂�Ԃ�
        value = '';
    end
end

%% �v���Z�X�o�[�̏���
function ProcessBar(message, percent, open, close)
    global bar;
    try
        %% �@ �v���Z�X�o�[�̏�����
        if open == 1
            % �@ (1) waitbar�̊֐��ŏ��������s��
            bar = waitbar(0, message, 'CreateCancelBtn', 'setappdata(gcbf,''canceling'',1)');
       %% �A ���Ƀv���Z�X�o�[���쐬���ꂽ�ꍇ�A�v���Z�X�X�V���s��
        else
            if ishandle(bar)
                % �A (1) waitbar�̊֐��Ńp�[�Z���g�ƕ\��������e���X�V����
                waitbar(percent, bar, sprintf('%s', message));
            end
        end
        %% �B �N���[�Y�t���O��1�̏ꍇ�A�v���Z�X�o�[�����
        if close == 1
            delete(bar);
        end
    catch
        if ishandle(bar)
            delete(bar);
        end
    end
end

%% ���s�����ɂ��A�V�[�g���擾
function sheet_name = GetSheetName(index)
    switch(index)
        case 1
            sheet_name = 'signal';
        case 2
            sheet_name = 'parameter';
        case 3
            sheet_name = 'alias';
        case 4
            sheet_name = 'enum';
        otherwise
            sheet_name = 'not_export_list';
    end
end

%% �V�[�g��Null�s�̃C���f�b�N�X���擾����
function [ ref, NullRowIndex ] = GetNullRowIndex(UsedRange, sheet_name)
    ref = 1;
    NullRowIndex = 0;
    for j = 3: UsedRange.Rows.Count
        row_j = UsedRange.Rows.Item(j);
        if ~isempty(regexp(sheet_name, 'enum$', 'match'))
            if length(row_j.Columns.Item(3).Value) == 1 && isnan(row_j.Columns.Item(3).Value) == 1 && ...
               length(row_j.Columns.Item(4).Value) == 1 && isnan(row_j.Columns.Item(4).Value) == 1
                NullRowIndex = j;
                return;
            end
        else
            if isnan(row_j.Columns.Item(3).Value) == 1
                NullRowIndex = j;
                return;
            end
        end
%         elseif ~isempty(regexp(sheet_name, 'enum_�X�V����$', 'match'))
%             if length(row_j.Columns.Item(3).Value) == 1 && isnan(row_j.Columns.Item(3).Value) == 1 && ...
%                length(row_j.Columns.Item(4).Value) == 1 && isnan(row_j.Columns.Item(4).Value) == 1
%                 NullRowIndex = j;
%                 return;
%             end
%         elseif ~isempty(regexp(sheet_name, '�X�V����$', 'match'))
%             if isnan(row_j.Columns.Item(4).Value) == 1
%                 NullRowIndex = j;
%                 return;
%             end            
%         else
% 
%         end
    end
end

%% Enum�f�[�^��Enumarals���r����
function [ diff_flag, diff_col_arr, diff_type, update_value, EnumData_new_update ] = CompareEnumData(Enum_Name, Enum_Value, Enum_Description, EnumData_new)
    diff_flag = 0;
    diff_col_arr = {};
    update_value = {};
    diff_type = 0;
    EnumData_new_update = EnumData_new;
    %% ���݂���ꍇ
    if  ischar(Enum_Name) && ...
        ismember(Enum_Name, EnumData_new(1:end, 1))
        [~, index] = ismember(Enum_Name, EnumData_new(1:end, 1));
        EnumData_new_update{index, end} = '*';
        if Enum_Value ~= str2num(EnumData_new{index, 2})
            diff_flag = 1;
            diff_type = 1;
            diff_col_arr{end + 1} = 2;
            update_value{end + 1} = EnumData_new{index, 2};
        end
        if isnan(Enum_Description) == 1
            Enum_Description = '';
        end
        if isnumeric(Enum_Description)
           Enum_Description = num2str(Enum_Description); 
        end
        if ~strcmp(Enum_Description, EnumData_new{index, 3})
            diff_flag = 1;
            diff_type = 1;
            diff_col_arr{end + 1} = 3;
            update_value{end + 1} = EnumData_new{index, 3};
        end
    %% ���݂��Ȃ��ꍇ    
    else
        diff_flag = 1;
        diff_type = 2;
    end
end

%% �f�[�^����Enum�����擾����
function enum_data = GetEnumData(data_name, data_source, run_time)
    enum_data = {};
    try
        myDictionaryObj = Simulink.data.dictionary.open(data_source);
        slddSection = myDictionaryObj.getSection('Design Data');
        sldd_data = slddSection.getEntry(data_name);
    catch
        return;
    end
    if isempty(sldd_data)
        return;
    end
    sldd_data_info = sldd_data.getValue;
    if isempty(sldd_data_info)
        return;
    end
    % �ǉ�����
    enum_data{end + 1, 1} = run_time; 
    % �X�V����
    enum_data{end, 2} = ''; 

    Enumerals = sldd_data_info.Enumerals;
   %% ���������p
    if length(Enumerals) == 1
        Enumerals = struct2cell(Enumerals);
        Enumerals = Enumerals';
    else
        Enumerals = table2cell(struct2table(Enumerals));
    end
    for k = 1: size(Enumerals, 1)
        if k == 1
            % Name
            enum_data{end, 3} = data_name;    
            % Enumerals_Name
            enum_data{end, 4} = sldd_data_info.Enumerals(k).Name;
            % Enumerals_Value
            enum_data{end, 5} = sldd_data_info.Enumerals(k).Value;
            % Enumerals_Description
            enum_data{end, 6} = sldd_data_info.Enumerals(k).Description;
            % DefaultValue
            enum_data{end, 7} = sldd_data_info.DefaultValue;
            % StorageType
            enum_data{end, 8} = sldd_data_info.StorageType;
            % DataScope
            enum_data{end, 9} = sldd_data_info.DataScope;
            % HeaderFile
            enum_data{end, 10} = sldd_data_info.HeaderFile;
            % AddClassNameToEnumNames
            enum_data{end, 11} = sldd_data_info.AddClassNameToEnumNames;
            % Description
            enum_data{end, 12} = sldd_data_info.Description;
            % DataSource
            enum_data{end, 13} = data_source;
        else
            % �ǉ�����
            enum_data{end + 1, 1} = run_time;
            % �X�V����
            enum_data{end, 2} = '';
            % Name
            enum_data{end, 3} = '';
            % Enumerals_Name
            enum_data{end, 4} = sldd_data_info.Enumerals(k).Name;
            % Enumerals_Value
            enum_data{end, 5} = sldd_data_info.Enumerals(k).Value;
            % Enumerals_Description
            enum_data{end, 6} = sldd_data_info.Enumerals(k).Description;
            % DefaultValue
            enum_data{end, 7} = '';
            % StorageType
            enum_data{end, 8} = '';
            % DataScope
            enum_data{end, 9} = '';
            % HeaderFile
            enum_data{end, 10} = '';
            % AddClassNameToEnumNames
            enum_data{end, 11} = '';
            % Description
            enum_data{end, 12} = '';
            % DataSource
            enum_data{end, 13} = '';
        end
    end
end

%% Excel��ColumnIndex��ColumnName�ɕϊ�
function column_name = GetColumnName(index)
    if index <= 26
        column_name = sprintf('%s', 64 + index);
    else
        if mod(index, 26) == 0
            column_name = sprintf('%s%s', 64 + floor(index/26) - 1, 64 + 26);
        else
            column_name = sprintf('%s%s', 64 + floor(index/26), 64 + mod(index, 26));
        end
    end
end

%% �s��ǉ�������ɁATemp�̔z��Ɋi�[���Ă���C���f�b�N�X���X�V����
function result_array = UpdateIndex(enum_info_temp, UsedRange)
    result_array = enum_info_temp;
    if size(result_array, 1) <= 2 || size(UsedRange, 1) <= 2
        return;
    end
    for i = 3: size(UsedRange, 1)
        if (isnumeric(UsedRange{i, 3}) && isnan(UsedRange{i, 3}) == 1) || ...
            (ischar(UsedRange{i, 3}) && isempty(UsedRange{i, 3}) == 1)    
            continue;
        end
        for j = 3: size(result_array, 1)
            if ischar(UsedRange{i, 3}) && ischar(result_array{j, 1}) && ...
               strcmp(UsedRange{i, 3}, result_array{j, 1})
                result_array{j, 4} = i;
            end
        end
    end
end

function [ result_flag, variables_use_info, null_var_name, model_ref_blks ] = CheckNonUsedVariables(sldd_data, model_handle, variables_use_info_in, null_var_name_in)
    result_flag = 1;
    variables_use_info = variables_use_info_in;
    [ model_ref_blks, model_ref_blk_names ] = Find_Model_Ref_Blks(model_handle, model_handle, { get_param(model_handle, 'Name') });
    model_ref_var_lst{length(model_ref_blks)} = {};
    null_var_name = null_var_name_in;
    for i = length(model_ref_blks): -1:1
        try
            try
                model_ref_var_lst{i} = GetModelVarList(model_ref_blk_names{i});
            catch
                open_system(model_ref_blk_names{i});
                model_ref_var_lst{i} = GetModelVarList(model_ref_blk_names{i});
            end
        catch
            warndlg(sprintf('Can not build model. Please make sure %s model can build and try again.', model_ref_blk_names{i}), 'WARNING', 'modal');
            result_flag = 0;
            return;            
        end
    end
    for i = 1: length(sldd_data)
        switch(class(sldd_data(i).getValue))
          %% Simulink.Signal�Ampt.Signal�^�C�v�̏ꍇ
          %% Simulink.Parameter�Ampt.Parameter�^�C�v�̏ꍇ
            case {'Simulink.Signal', 'mpt.Signal', 'Simulink.Parameter', 'mpt.Parameter' }
                use_model_name = '';
                for j = 1: length(model_ref_blks)
                    try
                        model_name = get_param(model_ref_blks(j), 'Name');
                    catch
                        continue;
                    end
                    try
                        if ismember(sldd_data(i).Name, model_ref_var_lst{j})
                            if isempty( regexp(use_model_name, model_name, 'match'))
                                if isempty(use_model_name)
                                    use_model_name = sprintf(model_name);
                                else
                                    use_model_name = sprintf([ use_model_name '\n' model_name]);
                                end
                            end
                        end
                    catch
                        
                    end
                end
                memberflag = 0;
                if ~isempty(variables_use_info)
                    [memberflag, memberindex] = ismember(sldd_data(i).Name, variables_use_info(1:end, 1));
                end
                if memberflag == 0
                    variables_use_info{end + 1, 1} = sldd_data(i).Name;
                    variables_use_info{end, 2} = use_model_name;
                    if isempty(use_model_name) == 1
                        null_var_name{end + 1} = sldd_data(i).Name;
                    end
                    variables_use_info{end, 3} = sldd_data(i).DataSource;
                else
                    hasAdded = 0;
                    for l = 1: length(memberindex)
                        if strcmp(sldd_data(i).DataSource, variables_use_info{memberindex(l), 3})
                            hasAdded = 1;
                            break;
                        end
                    end
                    if hasAdded == 0
                        variables_use_info{end + 1, 1} = sldd_data(i).Name;
                        variables_use_info{end, 2} = use_model_name;
                        if isempty(use_model_name) == 1
                            null_var_name{end + 1} = sldd_data(i).Name;
                        end
                        variables_use_info{end, 3} = sldd_data(i).DataSource;
                    else
                        if ~isempty(use_model_name)
                            use_model_name_split = regexp(use_model_name, '\n', 'split');
                            for l = 1: length(use_model_name_split)
                                if ~isempty(regexp(variables_use_info{memberindex, 2}, use_model_name_split{l}, 'match'))
                                    continue;
                                end
                                if isempty(variables_use_info{memberindex, 2})
                                    variables_use_info{memberindex, 2} = sprintf(use_model_name);
                                else
                                    variables_use_info{memberindex, 2} = sprintf([variables_use_info{memberindex, 2} '\n' use_model_name ]);
                                end
                            end
                        else
                            null_var_name{end + 1} = sldd_data(i).Name;
                        end
                    end
                end
            otherwise
                % nothing
        end
    end
end

function [ model_ref_blks, model_ref_blk_names ] = Find_Model_Ref_Blks(model_handle, model_ref_blks_in, model_ref_blk_names_in)
    model_ref_blks = model_ref_blks_in;
    model_ref_blk_names = model_ref_blk_names_in;
    find_model_ref_blks = find_system(model_handle, 'FindAll', 'on', 'BlockType', 'ModelReference');
    if isempty(find_model_ref_blks)
        return;
    end
    for i = 1:length(find_model_ref_blks)
        ref_model_name = get(find_model_ref_blks(i), 'ModelName');
        try
            ref_model_handle = get_param(ref_model_name, 'handle');
        catch
            try
                ref_model_handle = load_system(ref_model_name);
            catch
                continue;
            end
        end
        if length(model_ref_blks) == 1
            if model_ref_blks ~= ref_model_handle
                model_ref_blks(end + 1) = ref_model_handle;
                model_ref_blk_names{end +1} = get_param(ref_model_handle, 'Name');
            end
        else
            if ~ismember(ref_model_handle, model_ref_blks)
                model_ref_blks(end + 1) = ref_model_handle;
                model_ref_blk_names{end +1} = get_param(ref_model_handle, 'Name');
            end
        end
        [ model_ref_blks, model_ref_blk_names] = Find_Model_Ref_Blks(ref_model_handle, model_ref_blks, model_ref_blk_names);
    end
end

function result_flag = Check_SLDD(sldd_name_1, sldd_name_2)
    result_flag = 0;
    if strcmp(sldd_name_1, sldd_name_2)
        result_flag = 1;
    else
       %% SLDD�t�@�C������SLDD���擾
        try
            sldd_1_myDictionaryObj = Simulink.data.dictionary.open(sldd_name_1);
        catch
            sldd_1_myDictionaryObj = {};
        end 
        try
            sldd_2_myDictionaryObj = Simulink.data.dictionary.open(sldd_name_2);
        catch
            sldd_2_myDictionaryObj = {};
        end 
        if ~isempty(sldd_1_myDictionaryObj)
            if ismember(sldd_name_2, sldd_1_myDictionaryObj.DataSources)
                result_flag = 1;
            end
        end
        if ~isempty(sldd_2_myDictionaryObj)
            if ismember(sldd_name_1, sldd_2_myDictionaryObj.DataSources)
                result_flag = 1;
            end
        end
    end
end

%% �`�F�b�N���Ă���SLDD�͎q�e�֌W�ł��邩�`�F�b�N���s��
% resultFlag = true�F�q�e�֌W�ł���
% resultFlag = false�F�q�e�֌W�łȂ�
function resultFlag = IsChildParentRelationSLDD(check_datasource_1, check_datasource_2)
global child_parent_sldd_info;
    resultFlag = false;
    for i = 1: length(child_parent_sldd_info)
        if ismember(check_datasource_1, child_parent_sldd_info{i}) && ...
            ismember(check_datasource_2, child_parent_sldd_info{i})     
            resultFlag = true;
            break;
        end
    end
end
function ExportModelLayer(~)
    try
       %% �@ �����ݒ�
        search_handle = get_param(gcs, 'handle');
        start_column_index = 2;
        start_row_index = 2;
        export_array = {};
        export_array{end + 1, 1} = 'SearchTopLayer';
        export_array{end + 1, 1} = get_param(search_handle, 'Name');
       %% �A ���[�v�őS�ă��C���[����
        export_array = SearchLayer(search_handle, start_row_index, start_column_index, export_array); 
       %% �B �G�N�X�|�[�g�t�@�C��������
        % ���͂��Ȃ��ꍇ�́A�������C���[���Ƃ���B
        export_file_name = get_param(search_handle, 'Name');
        export_file_name = [ export_file_name '_Layers' ];
        input_result = inputdlg('Input Export File Name','Input File Name', [ 1 50 ], { export_file_name });
        if ~isempty(input_result)
            export_file_name = input_result{1};
        end
        export_file_name = [ export_file_name '.xlsx' ];
       %% �C �G�N�X�|�[�g�t�@�C��������
        final_excel_file = [ cd '\' export_file_name ];
        temp_excel_file = [ regexprep(mfilename('fullpath'), [ mfilename('filename') '$'], '') '\ExportModelLayer_Template.xlsx'];
        temp_excel_file = regexprep(temp_excel_file, 'RoboTra_Script\\ToolsMenu\\ExportModelLayer', 'RoboTra_Script\\Script_Run_ParameterFile\\ExportModelLayer');
        copyfile(temp_excel_file, final_excel_file, 'f');
       %% �D �G�N�Z���t�@�C���ɃG�N�X�|�[�g
        xlswrite(final_excel_file, export_array);   
       %% �E Excel�̕\���ҏW
        ExcelApp = actxserver('Excel.Application');
        eWorkbooks = ExcelApp.Workbooks;
        exlFile = eWorkbooks.Open(final_excel_file);
        ModelLayer_Sheet = exlFile.Sheets.Item('ModelLayer');
        UsedRangeValue = ModelLayer_Sheet.UsedRange.Value;
        % �e���f���A�T�u�V�X�e���ɂ����āA�q���f�����̓T�u�V�X�e��������΁A�}�[�W���s��
        for i = 1: size(UsedRangeValue, 2)
            for j = 2: size(UsedRangeValue, 1)
                if ~isnan(UsedRangeValue{j,i})
                     start_merge_cell_idx = j;
                     end_merge_cell_idx = j;
                     has_data = 0;
                     for k = j + 1:size(UsedRangeValue, 1)
                         if ~ischar(UsedRangeValue{k,i}) || ~strcmp(UsedRangeValue{j,i}, UsedRangeValue{k,i})
                            end_merge_cell_idx = k - 1;                             
                            has_data = 1;
                            break;
                         end
                     end
                     if end_merge_cell_idx == j && has_data == 0
                         end_merge_cell_idx = size(UsedRangeValue, 1);
                     end
                     for k = start_merge_cell_idx + 1:end_merge_cell_idx
                         UsedRangeValue{k, i} = NaN;
                     end
                     Range = [ GetColumnName(i) num2str(start_merge_cell_idx) ':' GetColumnName(i) num2str(end_merge_cell_idx) ];
                     if end_merge_cell_idx > start_merge_cell_idx
                         ClearRange = ModelLayer_Sheet.Range([ GetColumnName(i) num2str(start_merge_cell_idx + 1) ':' GetColumnName(i) num2str(end_merge_cell_idx) ]);
                         ClearRange.ClearContents();
                     end
                     Merge_Range = ModelLayer_Sheet.Range(Range);
                     Merge_Range.MergeCells = 1;
                end
            end
        end
        % �S�̃f�[�^��Border��`����
        ModelLayer_Sheet.UsedRange.Borders.LineStyle = 1;
        exlFile.Save();
        exlFile.Close(false);
        Quit(ExcelApp);
        delete(ExcelApp);
       %% �F �����I���̒ʒm���b�Z�[�W�\��
        msgbox(sprintf('Model Layers are exported to %s in current folder of matlab:\n%s', export_file_name, final_excel_file));
    catch ex
        errordlg(ex.getReport);
        try
            exlFile.Close(false);
            Quit(ExcelApp);
            delete(ExcelApp);
        catch
        end
    end
end

function export_array = SearchLayer(search_handle, start_row_index, start_column_index, export_array_in)
    export_array = export_array_in;
    %% 2.1 ���f���Q�ƃu���b�N����
    RefModelBlks = find_system(search_handle, 'FindAll', 'on', 'SearchDepth', '1', ...
                                             'BlockType', 'ModelReference', 'Commented', 'off');  % �R�����g���ꂽ�u���b�N������
    %% 2.2 �T�u�V�X�e���A�`���[�g�A�^���l�\�u���b�N����
    SubSystemBlks = find_system(search_handle, 'FindAll', 'on', 'SearchDepth', '1', 'BlockType', 'SubSystem', ...
                                               'ReferenceBlock', '', 'Mask', 'off', 'Commented', 'off'); % ���C�u�����A�}�X�N�A�R�����g���ꂽ�u���b�N������
    for i = length(SubSystemBlks):-1:1
        if SubSystemBlks(i) == search_handle
            SubSystemBlks(i) = [];
        end
    end
    %% 2.3 ������~����
    if isempty(RefModelBlks) && isempty(SubSystemBlks)
        return;
    end
    %% 2.4 ���C���[���ƂɍČ������{
    export_array{1, start_column_index } = [ 'Layer_' num2str(start_column_index - 1) ];
    if ~isempty(RefModelBlks)
        RefModelNames = get(RefModelBlks, 'ModelName');
        if length(RefModelBlks) == 1
            RefModelNames = { RefModelNames };
        end
        %% 2.4.1 �Q�ƃ��f���̃��C���[�Č������{
        for i = 1:length(RefModelNames)
            try
                search_handle = load_system(RefModelNames{i});
                if i == 1
                    export_array{end, start_column_index} = RefModelNames{i};
                else
                    export_array{end + 1, start_column_index} = RefModelNames{i};
                    for k = start_row_index: size(export_array, 1)
                        for l = 1:start_column_index - 1
                            export_array{k, l} = export_array{start_row_index, l};
                        end
                    end
                end
                export_array = SearchLayer(search_handle, size(export_array, 1), start_column_index + 1, export_array);
            catch
                if i == 1
                    export_array{end, start_column_index} = RefModelNames{i};
                else
                    export_array{end + 1, start_column_index} = RefModelNames{i};
                    for k = start_row_index: size(export_array, 1)
                        for l = 1:start_column_index - 1
                            export_array{k, l} = export_array{start_row_index, l};
                        end
                    end
                end
            end
        end
    end
    if ~isempty(SubSystemBlks)
       %% 2.4.2 �T�u�V�X�e���A�`���[�g�A�^���l�\�̃��C���[�Č������{
        for i = 1:length(SubSystemBlks)
            search_handle = SubSystemBlks(i);
            if i == 1 && isempty(RefModelBlks)
                export_array{end, start_column_index} = get_param(SubSystemBlks(i), 'Name');
            else
                export_array{end + 1, start_column_index} = get_param(SubSystemBlks(i), 'Name');
                for k = start_row_index: size(export_array, 1)
                    for l = 1:start_column_index - 1
                        export_array{k, l} = export_array{start_row_index, l};
                    end
                end
            end
            export_array = SearchLayer(search_handle, size(export_array, 1), start_column_index + 1, export_array);
        end
    end
end

%% Excel��ColumnIndex��ColumnName�ɕϊ�
function column_name = GetColumnName(index)
    if index <= 26
        column_name = sprintf('%s', 64 + index);
    else
        if mod(index, 26) == 0
            column_name = sprintf('%s%s', 64 + floor(index/26) - 1, 64 + 26);
        else
            column_name = sprintf('%s%s', 64 + floor(index/26), 64 + mod(index, 26));
        end
    end
end
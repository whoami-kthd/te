function [ SourceBlock, SourceBlockName, SourceLineHandle, SourceLineName ] = FindSourceBlock_WithMatlabFunc(line_handle, TopLayerName)
    SourceBlock = [];
    SourceBlockName = '';
    SourceLineHandle = [];
    SourceLineName = '';
    TraceSourceOutputPorts = get(line_handle, 'TraceSourceOutputPorts');
    for i = 1: length(TraceSourceOutputPorts)
        port_parent = get(TraceSourceOutputPorts(i), 'Parent');
        parent_block_type = get_param(port_parent, 'BlockType');
        parent_block_layer = get_param(port_parent, 'Parent');
        try
            % ���C�u�������̓`�F�b�N���Ȃ�
            if ~isempty(get_param(parent_block_layer, 'ReferenceBlock'))
                continue;
            end
        catch
            % ReferenceBlock�p�����[�^���Ȃ��u���b�N��OK�Ƃ���
        end
        if strcmp(parent_block_layer, TopLayerName) && strcmp(parent_block_type, 'Inport')
            SourceBlock = get_param(port_parent, 'handle');
            SourceBlockName = get_param(port_parent, 'Name');
            line_from_port = get(TraceSourceOutputPorts(i), 'Line');
            SourceLineHandle = line_from_port;
            SourceLineName = get(line_from_port, 'Name');
            break;
        elseif ~strcmp(parent_block_type, 'ModelReference') && ...
                (~strcmp(parent_block_type, 'SubSystem') || ...
                strcmp(get_param(port_parent, 'Mask'), 'on'))
            line_from_port = get(TraceSourceOutputPorts(i), 'Line');
            DstBlockHandle = get(line_from_port, 'DstBlockHandle');
            isBreak = 0;
            for k = 1: length(DstBlockHandle)
                if DstBlockHandle(k) <= 0 || ~ishandle(DstBlockHandle(k))
                    continue;
                end
                if strcmp(get(DstBlockHandle(k), 'BlockType'), 'Outport')
                    SourceBlock = DstBlockHandle(k);
                    SourceBlockName = get(DstBlockHandle(k), 'Name');
                    SourceLineHandle = line_from_port;
                    SourceLineName = get(line_from_port, 'Name');
                    isBreak = 1;
                    break;
                end
            end
            if isBreak == 1
                break;
            end
            if ~isempty(get(line_from_port, 'Name'))
                SourceBlock = line_from_port;
                SourceBlockName = get(line_from_port, 'Name');
                SourceLineHandle = SourceBlock;
                SourceLineName = SourceBlockName;
                break;
            end
        end
    end
end
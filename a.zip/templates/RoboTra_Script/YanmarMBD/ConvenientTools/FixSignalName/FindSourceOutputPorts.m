%% �������̃|�[�g����������
function SourceOutputPorts = FindSourceOutputPorts(line_handle, SourceOutputPorts_in, TopLayerName, HiliteAncestors)
    SourceOutputPorts = SourceOutputPorts_in;
    line_handle = GetParentLine(line_handle);
    if isempty(line_handle)
        return;
    end
    set(line_handle, 'HiliteAncestors', HiliteAncestors);
    srcBlockHandle = get_param(line_handle, 'SrcBlockHandle');
    if srcBlockHandle < 0 || ~ishandle(srcBlockHandle)
        return;
    end
    SourceOutputPorts(end + 1) = get_param(line_handle, 'SrcPortHandle');
    block_type = get_param(srcBlockHandle, 'BlockType');
    mask_onoff = get_param(srcBlockHandle, 'Mask');
    source_block_layer = get_param(srcBlockHandle, 'Parent');
    if strcmp(mask_onoff, 'on')
        return;
    % �\�[�X�u���b�N���C���|�[�g�u���b�N�̏ꍇ
    elseif strcmp(block_type, 'Inport')
        % �g�b�v���C���̃C���|�[�g�u���b�N�̏ꍇ
        if strcmp(source_block_layer, TopLayerName)
            return;
        end
        port = get_param(srcBlockHandle, 'Port');
        port = str2num(port);
        line_handles = get_param(source_block_layer, 'LineHandles');
        new_check_line_handle = line_handles.Inport(port);
        SourceOutputPorts = FindSourceOutputPorts(new_check_line_handle, SourceOutputPorts, TopLayerName, HiliteAncestors);
	% �\�[�X�u���b�N���T�u�V�X�e���u���b�N�̏ꍇ
    elseif strcmp(block_type, 'SubSystem')
        refernce_block = get_param(srcBlockHandle, 'ReferenceBlock');
        % ���C�u�����u���b�N�̏ꍇ
        if ~isempty(refernce_block)
            return;
        end
        line_handles = get_param(srcBlockHandle, 'LineHandles');
        source_port = get(line_handle, 'SourcePort');
        source_port_split = regexp(source_port, ':', 'split');
        source_port = str2num(source_port_split{end});
        [ ~, blk_handle ] = FindInportNameOfSubSystemFromPortNumber(srcBlockHandle, source_port, 'Outport');
        if isempty(blk_handle)
            % �`���[�g���͐^���l�\�u���b�N�̏ꍇ
            return;
        end
        line_handles = get_param(blk_handle, 'LineHandles');
        new_check_line_handle = line_handles.Inport(1);
        SourceOutputPorts = FindSourceOutputPorts(new_check_line_handle, SourceOutputPorts, TopLayerName, HiliteAncestors);
    elseif strcmp(block_type, 'BusSelector')
        try
            [ ~, ~, SourceLineHandle, ~ ] = FindSourceBlock_WithMatlabFunc(line_handle, TopLayerName);
            if ~isempty(SourceLineHandle)
                SourceOutputPorts(end + 1) = get_param(SourceLineHandle, 'SrcPortHandle');
            end
        catch
            disp('Test');
        end
    elseif strcmp(block_type, 'From')
        GotoBlock = get(srcBlockHandle, 'GotoBlock');
        if ~isempty(GotoBlock)
            GotoBlock = GotoBlock.handle;
            line_handles = get_param(GotoBlock, 'LineHandles');
            if ~isempty(GotoBlock)
                new_check_line_handle = line_handles.Inport(1);
                SourceOutputPorts = FindSourceOutputPorts(new_check_line_handle, SourceOutputPorts, TopLayerName, HiliteAncestors);
            end
        end
    else    
        % nothing
    end
end
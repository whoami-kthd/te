function varargout = FixSignalCusQuestionDialog(varargin)
% FIXSIGNALCUSQUESTIONDIALOG MATLAB code for FixSignalCusQuestionDialog.fig
%      FIXSIGNALCUSQUESTIONDIALOG by itself, creates a new FIXSIGNALCUSQUESTIONDIALOG or raises the
%      existing singleton*.
%
%      H = FIXSIGNALCUSQUESTIONDIALOG returns the handle to a new FIXSIGNALCUSQUESTIONDIALOG or the handle to
%      the existing singleton*.
%
%      FIXSIGNALCUSQUESTIONDIALOG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FIXSIGNALCUSQUESTIONDIALOG.M with the given input arguments.
%
%      FIXSIGNALCUSQUESTIONDIALOG('Property','Value',...) creates a new FIXSIGNALCUSQUESTIONDIALOG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FixSignalCusQuestionDialog_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FixSignalCusQuestionDialog_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FixSignalCusQuestionDialog

% Last Modified by GUIDE v2.5 16-Oct-2017 10:53:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FixSignalCusQuestionDialog_OpeningFcn, ...
                   'gui_OutputFcn',  @FixSignalCusQuestionDialog_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before FixSignalCusQuestionDialog is made visible.
function FixSignalCusQuestionDialog_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FixSignalCusQuestionDialog (see VARARGIN)
global param_checkList_Name;
global param_checkList_Handle;
global checkList_Name;
global checkList_Handle;
% Choose default command line output for FixSignalCusQuestionDialog
handles.output = 'Yes';

% Update handles structure
guidata(hObject, handles);

% Insert custom Title and Text if specified by the user
% Hint: when choosing keywords, be sure they are not easily confused 
% with existing figure properties.  See the output of set(figure) for
% a list of figure properties.
if(nargin > 3)
    for index = 1:2:(nargin-3),
        if nargin-3==index, break, end
        switch lower(varargin{index})
         case 'title'
          set(hObject, 'Name', varargin{index+1});
         case 'string'
          set(handles.text1, 'String', varargin{index+1});
        end
    end
end

% Determine the position of the dialog - centered on the callback figure
% if available, else, centered on the screen
FigPos=get(0,'DefaultFigurePosition');
OldUnits = get(hObject, 'Units');
set(hObject, 'Units', 'pixels');
OldPos = get(hObject,'Position');
FigWidth = OldPos(3);
FigHeight = OldPos(4);
if isempty(gcbf)
    ScreenUnits=get(0,'Units');
    set(0,'Units','pixels');
    ScreenSize=get(0,'ScreenSize');
    set(0,'Units',ScreenUnits);

    FigPos(1)=1/2*(ScreenSize(3)-FigWidth);
    FigPos(2)=2/3*(ScreenSize(4)-FigHeight);
else
    GCBFOldUnits = get(gcbf,'Units');
    set(gcbf,'Units','pixels');
    GCBFPos = get(gcbf,'Position');
    set(gcbf,'Units',GCBFOldUnits);
    FigPos(1:2) = [(GCBFPos(1) + GCBFPos(3) / 2) - FigWidth / 2, ...
                   (GCBFPos(2) + GCBFPos(4) / 2) - FigHeight / 2];
end
FigPos(3:4)=[FigWidth FigHeight];
set(hObject, 'Position', FigPos);
set(hObject, 'Units', OldUnits);

% Show a question icon from dialogicons.mat - variables questIconData
% and questIconMap
load dialogicons.mat

IconData=questIconData;
questIconMap(256,:) = get(handles.figure1, 'Color');
IconCMap=questIconMap;

Img=image(IconData, 'Parent', handles.axes1);
set(handles.figure1, 'Colormap', IconCMap);

set(handles.axes1, ...
    'Visible', 'off', ...
    'YDir'   , 'reverse'       , ...
    'XLim'   , get(Img,'XData'), ...
    'YLim'   , get(Img,'YData')  ...
    );
param = {};
if ~isempty(varargin)
param = varargin{1};
end
checkList_Name = [];
if ~isempty(param )
    checkList_Name = param{1};
    for i = 1:size(checkList_Name, 1)
        checkList_Name{i, 1} = [ '"' checkList_Name{i, 1} '"' ];
    end
    set(handles.lstSignalName, 'String', checkList_Name);
    if ~isempty(checkList_Name)
        set(handles.lstSignalName, 'Value', 1);
    end
end
checkList_Handle = [];
if length(param) > 1
    checkList_Handle = param{2};
end

if length(param) > 2
    set(handles.lblMessageBox, 'String', param{3});
end

param_checkList_Name = [];
if length(param) > 1
    param_checkList_Name = param{4};
    for i = 1:size(param_checkList_Name, 1)
        param_checkList_Name{i, 1} = [ '"' param_checkList_Name{i, 1} '"' ];
    end
    
end

param_checkList_Handle = [];
if length(param) > 1
    param_checkList_Handle = param{5};
end

% Make the GUI modal
%set(handles.figure1,'WindowStyle','modal');

% UIWAIT makes FixSignalCusQuestionDialog wait for user response (see UIRESUME)
uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = FixSignalCusQuestionDialog_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
if ~isempty(handles)
    varargout{1} = handles.output;
    % The figure can be deleted now
    delete(handles.figure1);
end

% --- Executes on button press in btnFix.
function btnFix_Callback(hObject, eventdata, handles)
% hObject    handle to btnFix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lstSignalName = get(handles.lstSignalName, 'String');
selectedIndex = get(handles.lstSignalName, 'Value');
selectName = '';
if selectedIndex > 0 && ~isempty(lstSignalName)
    selectName = lstSignalName{selectedIndex};
    selectName = regexprep(selectName, '^"', '');
    selectName = regexprep(selectName, '"$', '');
end
inputNewSignalName = get(handles.edtInputNewSignalName, 'String');
if ~isempty(inputNewSignalName)
    handles.output = inputNewSignalName;
else
    handles.output = selectName;
end
% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.figure1);

% --- Executes on button press in btnCancel.
function btnCancel_Callback(hObject, eventdata, handles)
% hObject    handle to btnCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = get(hObject,'String');

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.figure1);

% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = '�~';
% Update handles structure
guidata(hObject, handles);

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end


% --- Executes on key press over figure1 with no controls selected.
function figure1_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check for "enter" or "escape"
if isequal(get(hObject,'CurrentKey'),'escape')
    % User said no by hitting escape
    handles.output = '�~';
    
    % Update handles structure
    guidata(hObject, handles);
    
    uiresume(handles.figure1);
end    
    
if isequal(get(hObject,'CurrentKey'),'return')
    uiresume(handles.figure1);
end    


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in lstSignalName.
function lstSignalName_Callback(hObject, eventdata, handles)
% hObject    handle to lstSignalName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lstSignalName contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lstSignalName
global checkList_Handle;
global param_checkList_Handle;
if strcmp(get(handles.figure1,'SelectionType'),'open')
    index_selected = get(handles.lstSignalName,'Value');
    if get(handles.chkFilterSignalName, 'Value') == 0
        if index_selected > 0 && index_selected <= size(checkList_Handle, 1)
            selectObject = checkList_Handle{index_selected};
        end
    else
        if index_selected > 0 && index_selected <= size(param_checkList_Handle, 1)
            selectObject = param_checkList_Handle{index_selected};
        end
    end
    hilite_block(selectObject);
    hilite_system(selectObject);
end

% --- Executes during object creation, after setting all properties.
function lstSignalName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lstSignalName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edtInputNewSignalName_Callback(hObject, eventdata, handles)
% hObject    handle to edtInputNewSignalName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtInputNewSignalName as text
%        str2double(get(hObject,'String')) returns contents of edtInputNewSignalName as a double


% --- Executes during object creation, after setting all properties.
function edtInputNewSignalName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtInputNewSignalName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnClear.
function btnClear_Callback(hObject, eventdata, handles)
% hObject    handle to btnClear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edtInputNewSignalName, 'String', '');


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over lstSignalName.
function lstSignalName_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to lstSignalName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in chkFilterSignalName.
function chkFilterSignalName_Callback(hObject, eventdata, handles)
% hObject    handle to chkFilterSignalName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global param_checkList_Name;
global checkList_Name;
% Hint: get(hObject,'Value') returns toggle state of chkFilterSignalName
if get(handles.chkFilterSignalName, 'Value') == 0
    set(handles.lstSignalName, 'String', checkList_Name);
    set(handles.lstSignalName, 'Value', 1);
else
    set(handles.lstSignalName, 'String', param_checkList_Name);
    set(handles.lstSignalName, 'Value', 1);
end
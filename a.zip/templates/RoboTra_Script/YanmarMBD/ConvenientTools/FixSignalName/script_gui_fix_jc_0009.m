%% �֐����Fscript_gui_fix_jc_0009
%  �T�v�F�ujc_0009 �F �`�d�M���̕\���v
%         �M�������`�d����Ă���ꍇ�i���ɐM�������t���Ă���j�A�`�d�M���̕\����On�ɂ��āA�`�d���ꂽ�M������\�����܂��B
%       �@�`�d�M���̕\����On�ɂ��ĐM�����̕\�����s���̂́A�M�������قȂ�K�w�Œ�`���ꂽ�ꍇ�ł��B
%         �������A�ȉ��̃P�[�X�ł́A�K�w���܂����Ȃ��Ă��A�M�����̓`�d�\�����K�v�ł��B
%       �@?	�Ώۃu���b�N�F��ϊ����Z�����s�����{�u���b�N����o�͂����M��
%           �E	from 
%           �E	Bus Selector
%           �E	Signal Specification
%           �E	Function Call Split
%  �p�����[�^�F 
%        system(�I�������K�w)
%  �߂��l�F�@
%        result(���f���A�h�o�C�U�ŕ\�����錋��)
%  �쐬�ҁF LOC
%  �쐬���F 2017/03/14
function result = script_gui_fix_jc_0009(system, includeSubLayer, hasBuildModel)
global checked_line_handles;
   result = 1;
   checked_line_handles = [];
   %% �@ �Ώۃu���b�N����
   %% �@ (1) [3.chkIncludeSubLayer]�̃`�F�b�N��TRUE�̏ꍇ�A���K�w�A�K�w���̈ȉ��̃u���b�N�^�C�v������u���b�N�̌���
   % Inport|From|SignalSpecification|FunctionCallSplit
   if includeSubLayer == 1
        blocks = find_system(system, 'FindAll','on',...
                                     'LookUnderMasks', 'none',...
                                     'RegExp','on', ...
                                     'Type', 'block', ...
                                     'BlockType', 'Inport|From|SignalSpecification|FunctionCallSplit');
        subsystem_handles = find_system(system, 'FindAll','on',...
                        'RegExp', 'on', ...
                        'LookUnderMasks', 'none',...
                        'Type', 'block', ...
                        'Mask', 'off', ...
                        'BlockType', 'SubSystem' ); % AutonomusCrtl�ł�ModelReference�u���b�N����o��M���͋C�ɂ��Ȃ�����(2017/04/06 �⑺����Ɋm�F��)
                        %'BlockType', 'SubSystem|ModelReference'%); 
   %% �@ (2) [3.chkIncludeSubLayer]�̃`�F�b�N��FALSE�̏ꍇ�A���K�w�ɂ���ȉ��̃u���b�N�^�C�v������u���b�N�̌���
   % Inport|From|SignalSpecification|FunctionCallSplit
   else
        blocks = find_system(system, 'SearchDepth', '1', ...
                                     'LookUnderMasks', 'none',...
                                     'FindAll','on',...
                                     'RegExp','on', ...
                                     'Type', 'block', ...
                                     'BlockType', 'Inport|From|SignalSpecification|FunctionCallSplit');
                                 
        subsystem_handles = find_system(system, 'SearchDepth', '1', ...
                                                'FindAll','on',...
                                                'RegExp', 'on', ...
                                                'LookUnderMasks', 'none',...
                                                'Type', 'block', ...
                                                'Mask', 'off', ...
                                                'BlockType', 'SubSystem' ); % AutonomusCrtl�ł�ModelReference�u���b�N����o��M���͋C�ɂ��Ȃ�����(2017/04/06 �⑺����Ɋm�F��)
                                                %'BlockType', 'SubSystem|ModelReference' );
   end
   %% �A �Ώۃu���b�N���Ȃ��ꍇ�A�C����~
   if isempty(blocks) && isempty(subsystem_handles)
       return;
   end
   %% �B ���f�����擾
   try
        model_name = GetModelName(system);
   catch
        model_name = system;
   end
    if hasBuildModel == 1
        if ~isempty(get_param(system, 'Parent'))
            model_name = GetModelName(get_param(system, 'Parent'));
        else
            model_name = system;
        end

        % �R���p�C���J�n
        evalin('base', [ model_name '([],[],[],''compile'')']);
        % �R���p�C���I��
        evalin('base', [ model_name '([],[],[],''term'')']);
    end
   nonfixed = 0; 
   if ~isempty(blocks)
      %% �C �@�Ō�������Inport|From|SignalSpecification|FunctionCallSplit�u���b�N���ƃ`�F�b�N 
       for i = 1: size(blocks, 1)
           %% �C (1) ���C���n���h���擾 
            line_handle = get_param(blocks(i), 'LineHandles');
            block_type = get_param(blocks(i), 'BlockType');
            handle_in_out = line_handle.Outport;
            if handle_in_out < 0
                continue;
            end
            line_parent = get(handle_in_out, 'LineParent');
            if length(line_parent) > 1 || line_parent < 0
                line_parent = handle_in_out;
            end
            block_layer = get(blocks(i), 'Parent');
            parent_layer = get_param(block_layer, 'Parent');
           %% �C (2) Inport�̏ꍇ
            if strcmp(block_type, 'Inport')
             %% �C (2.1) Top���C���ȊO�̏ꍇ�̂݃`�F�b�N���s��
               if ~isempty(parent_layer)
                    if ~isempty(checked_line_handles) && ismember(line_parent, checked_line_handles)
                        continue;
                    end
                    checked_line_handles(end + 1) = line_parent;
                   SignalPropagation = get(line_parent, 'SignalPropagation');
                   signal_name = GetSignalName(line_parent);
                 %% �C (2.2) �M�������`�d���Ȃ��ꍇ�ARunFixSignalName�֐����Ăяo���B
                   %                                     �����F�u���b�N�n���h���A�M���n���h��
                   if (strcmp(SignalPropagation, 'on') && strcmp(signal_name, '<>'))
                     %% �x�����b�Z�[�W
                       hilite_system(line_parent);
                       waitfor(warndlg(sprintf('Propagation signal name is empty.\nPlease fix by jc_0008, ym_1009 or manually and try again.'), 'warning', 'modal'));
                       set(line_parent, 'HiliteAncestors', 'none');
                       nonfixed = 1; 
                       continue;
                   end
                   if strcmp(SignalPropagation, 'off') || ...
                      ~isempty(get(line_parent, 'Name'))
                        if ~isempty(get(line_parent, 'Name'))
                            [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent, 1);
                        else
                            if strcmp(SignalPropagation, 'off')
                                set(line_parent, 'SignalPropagation', 'on');
                                signal_name = GetSignalName(line_parent);
                                set(line_parent, 'SignalPropagation', 'off');
                                if strcmp(signal_name, '<>')
                                    continue;
                                end
                            end
                            [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent);
                        end
                        if isStop == 1
                            result = 0;
                            return;
                        end
                        if isCancel == 1
                            result = 0;
                        end
                   end
               end
          %% �C (3) Inport�ȊO�̏ꍇ
            else
               %% �C (3.1) Function-Call Split�u���b�N�̏ꍇ
                if strcmp(block_type, 'FunctionCallSplit')
                  %% �C (3.1.1) ���C���n���h�����X�g�`�F�b�N���J��Ԃ�
                    for j = 1: length(line_parent)
                        if ~isempty(checked_line_handles) && ismember(line_parent(j), checked_line_handles)
                            continue;
                        end
                        checked_line_handles(end + 1) = line_parent(j);
                     %% �C (3.1.2) �M�������`�d���Ȃ��ꍇ�ARunFixSignalName�֐����Ăяo��  
                        %                                       �����F�u���b�N�n���h���A�M���n���h��
                        SignalPropagation = get(line_parent(j), 'SignalPropagation');
                        signal_name = GetSignalName(line_parent(j));
                        
                        if (strcmp(SignalPropagation, 'on') && strcmp(signal_name, '<>'))
                        %% �x�����b�Z�[�W
                           hilite_system(line_parent(j));
                           waitfor(warndlg(sprintf('Propagation signal name is empty.\nPlease fix by jc_0008, ym_1009 or manually and try again.'), 'warning', 'modal'));
                           set(line_parent(j), 'HiliteAncestors', 'none');
                           nonfixed = 1; 
                           continue;
                        end
                        if strcmp(SignalPropagation, 'off') || ...
                           ~isempty(get(line_parent, 'Name'))
                            if ~isempty(get(line_parent, 'Name'))    
                                [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent, 1);
                            else
                                if strcmp(SignalPropagation, 'off')
                                    set(line_parent, 'SignalPropagation', 'on');
                                    signal_name = GetSignalName(line_parent);
                                    set(line_parent, 'SignalPropagation', 'off');
                                    if strcmp(signal_name, '<>')
                                        continue;
                                    end
                                end
                                [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent);
                            end
                            if isStop == 1
                                result = 0;
                                return;
                            end
                            if isCancel == 1
                                result = 0;
                            end
                       end
                    end
              %% �C (3.2) ���̑��u���b�N�̃`�F�b�N    
                else
                    if ~isempty(checked_line_handles) && ismember(line_parent, checked_line_handles)
                        continue;
                    end
                    checked_line_handles(end + 1) = line_parent;
                  %% �C (3.2.1) �M�������`�d���Ȃ��ꍇ�ARunFixSignalName�֐����Ăяo��  
                     %                                       �����F�u���b�N�n���h���A�M���n���h��  
                    signal_name = GetSignalName(line_parent);
                    SignalPropagation = get(line_parent, 'SignalPropagation');
                    if (strcmp(SignalPropagation, 'on') && strcmp(signal_name, '<>'))
                     %% �x�����b�Z�[�W
                       hilite_system(line_parent);
                       waitfor(warndlg(sprintf('Propagation signal name is empty.\nPlease fix by jc_0008, ym_1009 or manually and try again.'), 'warning', 'modal'));
                       set(line_parent, 'HiliteAncestors', 'none');
                       nonfixed = 1; 
                       continue;
                    end
                    if strcmp(SignalPropagation, 'off') || ...
                       ~isempty(get(line_parent, 'Name')) || (strcmp(SignalPropagation, 'on') && strcmp(signal_name, '<>'))
                       if ~isempty(get(line_parent, 'Name'))
                           [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent, 1);
                       else
                           if strcmp(SignalPropagation, 'off')
                               set(line_parent, 'SignalPropagation', 'on');
                               signal_name = GetSignalName(line_parent);
                               set(line_parent, 'SignalPropagation', 'off');
                               if strcmp(signal_name, '<>')
                                   continue;
                               end
                           end
                           [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent);
                       end
                        if isStop == 1
                            result = 0;
                            return;
                        end
                        if isCancel == 1
                            result = 0;
                        end
                   end
                end
            end
       end
   end
   %% �D �@�Ō�������Subsystem�u���b�N���ƃ`�F�b�N
    if ~isempty(subsystem_handles)
        [ isStop, isCancel, nonfixed] = CheckSignalNameSubAndChartBlock(1, subsystem_handles, system, model_name, includeSubLayer);
        if isStop == 1
            result = 0;
            return;
        end
        if isCancel == 1
            result = 0;
        end
    end
   %% Chart/TruhTable�u���b�N�̏ꍇ
   %blocks = FindChart_TruthTable(system, includeSubLayer);
   blocks = [];
   if ~isempty(blocks)
        [ isStop, isCancel, nonfixed] = CheckSignalNameSubAndChartBlock(0, blocks, system, model_name, includeSubLayer);
        if isStop == 1
            result = 0;
            return;
        end
        if isCancel == 1
            result = 0;
        end
   end
   if nonfixed == 1
       warndlg(sprintf('Some objects may not have been fixed.\nPlease check with the Guideline checker tool and fix them manually.'), 'WARNING');
       result = 0;
   end
end

%% �D �@�Ō�������Subsystem�u���b�N���ƃ`�F�b�N
function [ isStop, isCancel, nonfixed] =  CheckSignalNameSubAndChartBlock(isSubSystem, blocks, system, model_name, includeSubLayer)
global checked_line_handles;
    try
        isStop = 0;
        isCancel = 0;
        nonfixed = 0;
        if isSubSystem == 0
            blocks = FindChart_TruthTable(system, includeSubLayer);
            blocks = blocks';
        end
        for i = 1: size(blocks, 1)
           %% (1) �T�u�V�X�e���̏ꍇ
            if isSubSystem == 1
                % Chart�̏ꍇ
                try
                    if strcmp(get(blocks(i),'ErrorFcn'), 'Stateflow.Translate.translate')
                        continue;
                    end
                catch
                end
                if isempty(regexp(get(blocks(i),'Path'), system, 'match'))
                	continue;
                end
              %% (1.1) ���C�u�����u���b�N�͑ΏۊO
                if ~isempty(get(blocks(i),'ReferenceBlock'))
                	continue;
                end    
              %% (1.2) ���C���n���h���擾
                sl_block = blocks(i);
                lineHandles = get_param(sl_block, 'LineHandles');
           %% (2) Chart/TruthTable�u���b�N�̏ꍇ�F
            else
                sl_block = find_system(model_name,'FindAll', 'on', ...
                                                  'LookUnderMasks', 'none',...
                                                  'Parent', regexprep(blocks{i}.Path, ['/' blocks{i}.Name '$'], ''), ...
                                                  'Name', blocks{i}.Name);

                lineHandles = get_param(sl_block, 'LineHandles');
            end
            if isempty(lineHandles)
                continue;
            end
            if ~isempty(lineHandles.Inport)
              %% (1.2.1) �C���|�[�g�̃��C���n���h�̃`�F�b�N
                for j = 1: length(lineHandles.Inport)
                    if isempty(lineHandles.Inport(j)) || lineHandles.Inport(j) < 0
                        continue;
                    end
                    if lineHandles.Inport(j) > 0
                        line_parent = GetParentLine(lineHandles.Inport(j));
                    end
                    if line_parent < 0
                        continue;
                    end
                    if ~isempty(checked_line_handles) && ismember(line_parent, checked_line_handles)
                        continue;
                    end
                    checked_line_handles(end + 1) = line_parent;
                    SrcBlockHandle = get(line_parent, 'SrcBlockHandle');
                    SignalPropagation = get(line_parent, 'SignalPropagation');
                    if ishandle(SrcBlockHandle) && ...
                            (strcmp(get(SrcBlockHandle, 'BlockType'), 'SubSystem') && strcmp(get(SrcBlockHandle, 'Mask'), 'off'))
                        % �F (1.2.1.1) ���C�u�����u���b�N�͑ΏۊO
                        if ~isempty(get(SrcBlockHandle, 'ReferenceBlock')) || IsChartBlock(SrcBlockHandle)
                            continue;
                        end
                        %% �C (3.2.1) �M�������`�d���Ȃ��ꍇ�ARunFixSignalName�֐����Ăяo��
                        %                                       �����F�u���b�N�n���h���A�M���n���h��
                        signal_name = GetSignalName(line_parent);
                        if (strcmp(SignalPropagation, 'on') && strcmp(signal_name, '<>'))
                            %% �x�����b�Z�[�W
                            hilite_system(line_parent);
                            waitfor(warndlg(sprintf('Propagation signal name is empty.\nPlease fix by jc_0008, ym_1009 or manually and try again.'), 'warning', 'modal'));
                            set(line_parent, 'HiliteAncestors', 'none');
                            nonfixed = 1;
                            continue;
                        end
                        if strcmp(SignalPropagation, 'off') || ...
                                ~isempty(get(line_parent, 'Name')) || (strcmp(SignalPropagation, 'on') && strcmp(signal_name, '<>'))
                            if ~isempty(get(line_parent, 'Name'))
                                [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent, 1);
                            else
                                if strcmp(SignalPropagation, 'off')
                                    set(line_parent, 'SignalPropagation', 'on');
                                    signal_name = GetSignalName(line_parent);
                                    set(line_parent, 'SignalPropagation', 'off');
                                    if strcmp(signal_name, '<>')
                                        continue;
                                    end
                                end
                                [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent);
                            end
                            if isStop == 1
                                return;
                            end
                            if isCancel == 1
                                continue;
                            end
                        end
                    end
                end
            end
            if ~isempty(lineHandles.Outport)
              %% (1.2.2) �A�E�g�|�[�g�̃��C���n���h�̃`�F�b�N
                for j = 1: length(lineHandles.Outport)
                  if isempty(lineHandles.Outport(j)) || lineHandles.Outport(j) < 0
                      continue;
                  end
                  if lineHandles.Outport(j) > 0
                      line_parent = GetParentLine(lineHandles.Outport(j));
                  end
                  if line_parent < 0
                      continue;
                  end
                  if ~isempty(checked_line_handles) && ismember(line_parent, checked_line_handles)
                      continue;
                  end
                  checked_line_handles(end + 1) = line_parent;
                  %% �C (3.2.1) �M�������`�d���Ȃ��ꍇ�ARunFixSignalName�֐����Ăяo��
                  %                                       �����F�u���b�N�n���h���A�M���n���h��
                  signal_name = GetSignalName(line_parent);
                  SignalPropagation = get(line_parent, 'SignalPropagation');
                  if (strcmp(SignalPropagation, 'on') && strcmp(signal_name, '<>'))
                      %% �x�����b�Z�[�W
                      hilite_system(line_parent);
                      waitfor(warndlg(sprintf('Propagation signal name is empty.\nPlease fix by jc_0008, ym_1009 or manually and try again.'), 'warning', 'modal'));
                      set(line_parent, 'HiliteAncestors', 'none');
                      nonfixed = 1;
                      continue;
                  end
                  if strcmp(SignalPropagation, 'off') || ...
                          ~isempty(get(line_parent, 'Name')) || (strcmp(SignalPropagation, 'on') && strcmp(signal_name, '<>'))
                      if ~isempty(get(line_parent, 'Name'))
                          [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent, 1);
                      else
                          if strcmp(SignalPropagation, 'off')
                              set(line_parent, 'SignalPropagation', 'on');
                              signal_name = GetSignalName(line_parent);
                              set(line_parent, 'SignalPropagation', 'off');
                              if strcmp(signal_name, '<>')
                                  continue;
                              end
                          end
                          [ isStop, isCancel] = RunFixSignalName(blocks(i), line_parent);
                      end
                      if isStop == 1
                          return;
                      end
                      if isCancel == 1
                          continue;
                      end
                  end
                end
            end
        end
    catch ex
        errordlg([ ex.message ' ' ex.stack(1).name ' ' num2str(ex.stack(1).line)]);
    end
end

function [isStop, isCancel] = RunFixSignalName(blocks_handle, line_handle, isClearSignalName)
    if nargin <= 2
        isClearSignalName = 0;
    end
    %% �@ �e�M���̃n���h���擾
    isStop = 0;
    isCancel = 0;
    LineParent = get(line_handle, 'LineParent');
    if LineParent > 0
        line_handle = LineParent;
    end
    SetHiliteAncestorsOff(blocks_handle, line_handle, 'on');
    old_SignalPropagation = get(line_handle, 'SignalPropagation');
    set(line_handle, 'SignalPropagation', 'on');
    signal_name = GetSignalName(line_handle);
    set(line_handle, 'SignalPropagation', old_SignalPropagation);
    if ~strcmp(signal_name, '<>')
        isClearSignalName = 0;
    end
    if isClearSignalName == 1
        selectButton = questdlg(sprintf('Propagation signal name is created. Do you want to clear signal name.'), 'Question[CLEAR]','Yes', 'Cancel', 'Yes');
        switch(selectButton)
            %% Yes��I�������ꍇ
            case 'Yes'
                set(line_handle, 'Name', '');
            case 'Cancel'
                isCancel = 1;
            case ''
                SetHiliteAncestorsOff(blocks_handle, line_handle, 'off');
                isStop = 1;
                return;
        end
    else
        %% �A �ȉ��̏C���m�F���b�Z�[�W��\������ 
        if ~isempty(get(line_handle, 'Name')) && strcmp(get(line_handle, 'SignalPropagation'), 'on')
            %  ���b�Z�[�W���e�F�hPropagation signal name is created. Do you want to clear signal name.�h
            selectButton = questdlg(sprintf('Propagation signal name is created. Do you want to clear signal name.'), 'Question[CLEAR]','Yes', 'Cancel', 'Yes');
        else
            %  ���b�Z�[�W���e�F�hSignal type must be propagation. \nDo you want to fix this�h
            selectButton = questdlg(sprintf('Signal type must be propagation. \nDo you want to fix this,'), ...
                                            'Question[PROPAGATION]','Yes', 'Cancel', 'Yes');
        end
        switch(selectButton)
           %% �A (1) Yes�̏ꍇ�F�C�����s���B�M��������`����Ă���ꍇ�A�󔒂ɏC��
            case 'Yes'
                set(line_handle, 'Name', '');
                set(line_handle, 'SignalPropagation', 'on');
           %% �A (2) Cancel�̏ꍇ�F�C�����΂�    
            case 'Cancel'
                SetHiliteAncestorsOff(blocks_handle, line_handle, 'off');
                isCancel = 1;
           %% �A (3) �~�̏ꍇ�F�C����~
            case ''
                SetHiliteAncestorsOff(blocks_handle, line_handle, 'off');
                isStop = 1;
                return;
        end
    end
    SetHiliteAncestorsOff(blocks_handle, line_handle, 'off');
end

function SetHiliteAncestorsOff(block1_handle, block2_handle, on_off)
    try
        if ~ishandle(block1_handle)
            try
                block1_handle = block1_handle{1}.Path;
            catch
            end
        end
        if ~ishandle(block2_handle)
            try
                block2_handle = block2_handle{1}.Path;
            catch
            end
        end
        if strcmp(on_off, 'on')
            if ~isempty(block1_handle) 
                hilite_system(block1_handle);
            end
            if ~isempty(block2_handle) 
                hilite_system(block2_handle);
            end
        else
            if ~isempty(block1_handle) 
                set_param(block1_handle, 'HiliteAncestors', on_off);
            end
            if ~isempty(block2_handle) 
                set_param(block2_handle, 'HiliteAncestors', on_off);
            end
        end
    catch
    end
end

%% �����ݎg�p���Ȃ�
function blocks = FindChart_TruthTable(system, includeSubLayer)
    rt = sfroot;
    model_name = GetModelName(system);
    model = rt.find('Name', model_name, 'Parent', '');
    charts = model.find('-isa', 'Stateflow.Chart');
    blocks = {};
    for i = 1: size(charts, 1)
        if Check_ChartBlock_Commented(rt, model_name, regexprep(charts(i).Path, ['/' charts(i).Name '$'], ''), charts(i).Name) == 1
          continue;
        end
        % ���݂̊K�w�̂݃`�F�b�N
        if includeSubLayer == 1
            if isempty(regexp(regexprep(charts(i).Path, ['/' charts(i).Name '$'], ''), system, 'match'))
              continue;
            end
        else
            if ~strcmp(regexprep(charts(i).Path, ['/' charts(i).Name '$'], ''), system)
              continue;
            end
        end
        blocks{end+1} = charts(i);
    end  
    truthtables = model.find('-isa', 'Stateflow.TruthTableChart');
    for i = 1: size(truthtables, 1)
        if Check_ChartBlock_Commented(rt, model_name, regexprep(truthtables(i).Path, ['/' truthtables(i).Name '$'], ''), truthtables(i).Name) == 1
           continue;
        end
        % ���݂̊K�w�̂݃`�F�b�N
        if includeSubLayer == 1
            if isempty(regexp(regexprep(truthtables(i).Path, ['/' truthtables(i).Name '$'], ''), system, 'match'))
              continue;
            end
        else
            if ~strcmp(regexprep(truthtables(i).Path, ['/' truthtables(i).Name '$'], ''), system)
              continue;
            end
        end
        blocks{end+1} = truthtables(i);
    end  
end
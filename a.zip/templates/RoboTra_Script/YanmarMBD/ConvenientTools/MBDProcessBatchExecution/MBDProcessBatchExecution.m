function MBDProcessBatchExecution(~)

    warning('off');
    LogFileName = 'logfile.txt';
    Root_folder = pwd;
    
    if exist([Root_folder '/' LogFileName],'file')
        diary off;
        delete([Root_folder '/' LogFileName]);
    end
    diary([Root_folder '/' LogFileName]);
 
    dispstr = sprintf('---------------------------------------------------------------------');
    disp(dispstr);
    dispstr = sprintf('== Start MBD Process Batch Execution at %s =========', char(datetime('now')) );
    disp(dispstr);
    
    dispstr = sprintf('==== Start Style Check at %s =======================', char(datetime('now')) );
    disp(dispstr);
    result = 1;%run_StyleCheck;
    
    if result == 0
        dispstr = sprintf('============ Error when Style Check at %s ==========', char(datetime('now')) );
        disp(dispstr);
        
        diary off;
        return;
    end
    
    dispstr = sprintf('==== Finish Style Check at %s ======================', char(datetime('now')) );
    disp(dispstr);

    dispstr = sprintf('==== Start Design Error Check at %s ================', char(datetime('now')) );
    disp(dispstr);
    result = run_DesignErrorCheck;
    if result == 0
        dispstr = sprintf('======= Error when Design Error Check at %s ========', char(datetime('now')) );
        disp(dispstr);
        diary off;
        return;
    elseif result == 2
        dispstr = sprintf('======= Design Error Check is passed at %s =========', char(datetime('now')) );
        disp(dispstr);
    else
        dispstr = sprintf('==== Finish Design Error Check at %s ===============', char(datetime('now')) );
        disp(dispstr);
    end

    dispstr = sprintf('==== Start Dynamic Analysis at %s ==================', char(datetime('now')) );
    disp(dispstr);

    result = run_DynamicAnalysis;
    if result == 0
        dispstr = sprintf('======= Error when Dynamic Analysis at %s ==========', char(datetime('now')) );
        disp(dispstr);
        diary off;
        return;
    end
    
    dispstr = sprintf('==== Finish Dynamic Analysis at %s =================', char(datetime('now')) );
    disp(dispstr);
    
    dispstr = sprintf('== Finish MBD Process Batch Execution at %s ========', char(datetime('now')) );
    disp(dispstr);
    dispstr = sprintf('---------------------------------------------------------------------');
    disp(dispstr);
    diary off;
end

function result = run_StyleCheck(~)
    global btnRunCheckAll_Callback_run_Success;
    result = 1;
    
    StyleCheckObject = ModelStyleCheck('Visible', 'off');
    handles = guihandles(StyleCheckObject);
    dispstr = sprintf('========= Start Run Check at %s ====================', char(datetime('now')) );
    disp(dispstr);
    ModelStyleCheck('btnRunCheckAll_Callback', handles.btnRunCheckAll, 'CallFromMBDProcessBatch', handles);
    
    if btnRunCheckAll_Callback_run_Success == 0
        result = 0;
        return;
    end
    
    dispstr = sprintf('========= Finish Run Check at %s ===================', char(datetime('now')) );
    disp(dispstr);
    
    dispstr = sprintf('========= Start Export Style Check Result at %s ====', char(datetime('now')) );
    disp(dispstr);
    ModelStyleCheck('btnCreateReport_Callback', handles.btnCreateReport, 'CallFromMBDProcessBatch', handles);
    if btnRunCheckAll_Callback_run_Success == 0
        result = 0;
        return;
    end

    dispstr = sprintf('========= Finish Export Style Check Result at %s ===', char(datetime('now')) );
    disp(dispstr);
end


function result = run_DesignErrorCheck(~)
    result = DesignErrorDetection;
end


function result = run_DynamicAnalysis()
    result = 1;
    % Search test manager in current folder
    model = get_param(0,'CurrentSystem');
    
    % compile model
    try
        eval([model '([],[],[],''compile'');']);
        eval([model '([],[],[],''term'')']);
    catch
        dispstr = sprintf(['Dynamic Analysis/SILS Test is error !!! \nModel compile error']);
        disp(dispstr);
        result = 0;
        diary off;
        return;
    end

    folder = which(model);
    folder = replace(folder, ['\' model '.slx'], '');
    testManagerFiles = dir(fullfile(folder,'*.mldatx'));
    
    if(isempty(testManagerFiles))
        result = 0;
        dispstr = sprintf('Can not find the Test Manager file !!!');
        disp(dispstr);
        diary off;
        return;
    elseif(size(testManagerFiles, 1) > 1)
        result = 0;
        dispstr = sprintf('There are many Test Manager files in folder. Please check !!!');
        disp(dispstr);
        diary off;
        return;
    else
        try
            sltest.testmanager.clear;
            sltest.testmanager.load([testManagerFiles.folder '\' testManagerFiles.name]);
            sltest.testmanager.view;
            resultObj = sltest.testmanager.run;
            
            reportTitle =  model;
            testAuthor  = getenv('username');
            filePath = ['DynamicTest_And_SILS_ResultReport(' model ').pdf'];
            
            % https://www.mathworks.com/help/sltest/ref/sltest.testmanager.options-class.html
            sltest.testmanager.report(resultObj,filePath,...
                                    'Author',testAuthor,...
                                    'Title',reportTitle,...
                                    'IncludeMLVersion',true,...
                                    'IncludeTestResults', int32(0),...
                                    'IncludeTestRequirement',true,...
                                    'IncludeMATLABFigures',false,...
                                    'IncludeSimulationMetadata',false,...
                                    'IncludeCoverageResult',true,...
                                    'IncludeSimulationSignalPlots',true,...
                                    'IncludeComparisonSignalPlots',false,...
                                    'LaunchReport',true);
                                
            sltest.testmanager.clear;
            sltest.testmanager.clearResults;
            sltest.testmanager.close;
        catch ex
            dispstr = sprintf(['Dynamic Analysis/SILS Test is error !!! \n ' ex.message]);
            disp(dispstr);
            result = 0;
            diary off;
            return;
        end
    end
end
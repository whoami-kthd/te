%% Excel2SignalBuilder�֐�
%   �T�v�F�e�X�g�x�N�^��Excel�t�@�C����SignalBuilder�u���b�N�쐬
%   Excel�ɒ�`���Ă���e�X�g�x�N�^��ǂݍ���ŁA
%   �e�X�g�x�N�^���`�F�b�N���ASignalBuilder�u���b�N���쐬����
%   �p�����[�^�F
%           callBackInfo.userdata{1}�F���s����K�w
%           callBackInfo.userdata{2}�FContextMenu��\������ʒu
%   �߂�l�F
%           �Ȃ�
%   �쐬�ҁFLOC
%   �쐬���F2017/06/01
%   �C�����F2018/06/15
%   �C�����e�FSignalBuilder�ɕϊ����ɁAExcel�̃V�[�g����I�ׂ�悤�ɂ���
function Excel2SignalBuilder(callBackInfo)
    system = callBackInfo.userdata{1};
    pointerPosition = callBackInfo.userdata{2};
    %% �t�@�C���p�X�擾
    [FileName, PathName] = uigetfile('*.xlsx;*.xls;*.xlsm', 'Select Testvector File');
    if (ischar(FileName) && isempty(FileName)) || (isnumeric(FileName) && FileName == 0)        
        return;
    end
    ExcelApp = actxserver('Excel.Application');
    eWorkbooks = ExcelApp.Workbooks;
    exlFile = eWorkbooks.Open([ PathName '\' FileName ]);
    excel_sheetname_lst = {};
    % �e�X�g�x�N�^�V�[�g���̃��X�g�쐬
    for i  = 1:exlFile.Sheets.Count
        A1_Value = exlFile.Sheets.Item(i).Range('A1').Value;
        % ������łȂ���΁A���X�g�ɒǉ����Ȃ�
        if ~ischar(A1_Value)
            continue;
        end
        % '�e�X�g�x�N�^'������Ŏn�܂�Ȃ���΁A���X�g�ɒǉ����Ȃ�
        if isempty(regexp(A1_Value, '^�e�X�g�x�N�^', 'match', 'once'))
            continue;
        end
        excel_sheetname_lst{end + 1} = exlFile.Sheets.Item(i).Name;
    end
    exlFile.Close(false);
    Quit(ExcelApp);
    delete(ExcelApp);
    %% �e�X�g�x�N�^�V�[�g���擾�擾
    %   �f�t�H���g�V�[�g���́u�e�X�g�x�N�^�[�v�Ƃ��Ă��邪�A�K�v�ȏꍇ�͕ύX���Ă��������B
%     default_sheetname = '�e�X�g�x�N�^�[';
%     sheet_name = inputdlg(sprintf('�yInput Testvector Sheet Name�z\n'), '', 1, { default_sheetname });
    sheet_name = SelectSheetName(excel_sheetname_lst);
    if isempty(sheet_name)
       return; 
    end
    %% Excel�t�@�C������e�X�g�x�N�^�f�[�^�ǂݍ��݁A�e�X�g�x�N�^�쐬
    [ blockHandle, failed_flag ] = ReadDataAndCreateTestvector([ PathName '\' FileName], sheet_name, system, pointerPosition);
    if failed_flag == 1
        if ishandle(blockHandle)
            delete_block(blockHandle);
        end
       return; 
    end
end

%% Excel�t�@�C������e�X�g�x�N�^�f�[�^�ǂݍ��݁A�e�X�g�x�N�^�쐬
function [ blockHandle, failed_flag ] = ReadDataAndCreateTestvector(file_name, sheet_name, system, pointerPosition)
global bar;
failed_flag = 0;
blockHandle = [];
group_name_lst = {};
try
    try
        [~, ~, excelData ] = xlsread(file_name, sheet_name);
    catch
        failed_flag = 1;
        warndlg(sprintf('Can not read excel file.\nPlease make sure�u%s�v sheet is contain in file.', sheet_name), 'Warning'); 
        return;        
    end
    %% '�e�X�g�x�N�^�[ID'������Z���̃C���f�b�N�X�擾
    [ start_index ] = FindStartIndex(excelData(1:end, 1), excelData);
    if start_index == 0
        failed_flag = 1;
        warndlg('There is not the cell contain ''�e�X�g�x�N�^�[ID'' in column A.', 'Warning'); 
        return;
    end
    %% SampleTime�擾
    [ sample_time ] = GetSampleTime(excelData(1:end, 1), excelData);
    %% '�e�X�g�x�N�^�[ID'������s��'Input'�A'Output'������J�����ȊO�͍폜���s��
    [ excelData, signal_name_index_lst, error_flag, error_columnIndex, count_row_end, count_column_end ] = FindInputOutputColumnIndex(excelData, start_index);
    if error_flag == 1
        failed_flag = 1;
        columnName = GetColumnName(error_columnIndex);
        warndlg(sprintf('The header of column �u%s�v is not exist in {''Input''�A''Output'', ''Comments''}.', columnName), 'Warning'); 
        return;        
    end
    if error_flag == 2
        failed_flag = 1;
        columnName = GetColumnName(error_columnIndex);
        warndlg(sprintf('There is value in column �u%s�v but the header is empty.', columnName), 'Warning'); 
        return;        
    end
    if count_row_end == 0
        failed_flag = 1;
        warndlg('Can not find the cell contain ''End'' in column A.', 'Warning'); 
        return;        
    elseif count_row_end >= 2
        failed_flag = 1;
        warndlg('There are greater than 1 cell contain ''End'' in column A.', 'Warning'); 
        return;        
    else
        % nothing
    end
    if count_column_end == 0
        failed_flag = 1;
        warndlg(sprintf('Can not find the cell contain ''End'' in row %d.', start_index), 'Warning'); 
        return;        
    elseif count_column_end >= 2
        failed_flag = 1;
        warndlg(sprintf('There are greater than 1 cell contain ''End'' in row %d.', start_index), 'Warning'); 
        return;        
    else
        % nothing
    end
    if size(excelData, 2) <= 2
        failed_flag = 1;
        warndlg(sprintf('There is not the cell contain ''Input'' or ''Output'' in row %d.', start_index), 'Warning'); 
        return;
    end
    %% �ŏ��̃e�X�g�x�N�^ID�擾
    group_name = num2str(excelData{3, 1});
    if strcmp(group_name, 'NaN') || isempty(group_name)
        failed_flag = 1;
        warndlg('Can not get the first tesvector id.', 'Warning'); 
        return;
    end
    %% �M�������X�g�擾
    signal_name = excelData(2, 3:end);
    signal_name = signal_name';
    for i = 1: length(signal_name)
        if isnumeric(signal_name{i}) || ...
           (ischar(signal_name{i}) && isempty(regexprep(signal_name{i}, ' ', '')))
            column_name = GetColumnName(signal_name_index_lst(i + 1));
            warndlg(sprintf('The signal name in cell �u%s�v can not be null or numeric.', [ column_name num2str(start_index + 1)]), 'Warning'); 
            failed_flag = 1;
            return;
        end
    end
    signal_name_input = {};
    signal_name_output = {};
    for i = 1: length(signal_name)
        if strcmp(excelData{1, i + 2}, 'Input')
            signal_name_input{end + 1} = signal_name{i};
        end
        if strcmp(excelData{1, i + 2}, 'Output')
            signal_name_output{end + 1} = signal_name{i};
        end
    end
    check_signal_name_input = unique(signal_name_input);
    check_signal_name_output = unique(signal_name_output);
    if length(check_signal_name_input) < length(signal_name_input)
        warndlg(sprintf('There is the same input signal name. Please check row �u%d�v data', start_index + 1), 'Warning'); 
        failed_flag = 1;
        return;
    end
    if length(check_signal_name_output) < length(signal_name_output)
        warndlg(sprintf('There is the same output signal name. Please check row �u%d�v data', start_index + 1), 'Warning'); 
        failed_flag = 1;
        return;
    end
    %% SignalBuilder�u���b�N���擾
    get_name= 0;
    while(get_name >= 0)
        if get_name == 0
             sgb_name = 'Signal Builder';
        else
             sgb_name = [' Signal Builder' num2str(get_name) ];
        end
        find_blks = find_system(system, 'FindAll', 'on', 'IncludeCommented', 'on', 'Name', sgb_name);
        if isempty(find_blks)
            break
        end
        get_name = get_name + 1;
        if get_name >= 500
            warndlg('Can not select name for signal builder block.', 'Warning'); 
            failed_flag = 1;
            return;
        end
    end
    %% �s
    time = [];
    signal_data = {};
    group_name_lst{end + 1} = group_name;
    for i = 3: size(excelData, 1)
       %% ProcessBar�X�V��------------------------------------------------��
        if i == 3
            ProcessBar('Processing Start', 0, 1, 0);
        end
        if ishandle(bar) && ~isempty(getappdata(bar,'canceling'))                
            delete(bar);
            failed_flag = 1;
            return;
        end
        percent = i/size(excelData, 1);
        ProcessBar(sprintf('Processing�F%d/%d data rows.', i, size(excelData, 1)), percent, 0, 0);
       %% ProcessBar�X�V��------------------------------------------------��
        row_data = excelData(i, 2:end);
        [ valid_data, index ] = CheckTestVectorData(row_data);
        if valid_data == 0
            failed_flag = 1;
            warndlg(sprintf('Testvector value in cell �u%s�v can not be null or characters.', ...
                        [ GetColumnName(signal_name_index_lst(index)) num2str(i + start_index - 1)]), 'Warning'); 
            if ishandle(bar)
                delete(bar);
            end
            return;
        end
       %% ��
        % Testvector ID�`�F�b�N���A�V�����O���[�v�̏ꍇ�͑O�ɍ쐬�����e�X�g�x�N�^��SignalBuilder�u���b�N�ɒǉ�
        check_testvector_id = num2str(excelData{i, 1});
        if ~strcmp(check_testvector_id, group_name) && ...
           ~strcmp(check_testvector_id, 'NaN') && ...
           ~isempty(check_testvector_id)
            %% ���ɑ��݂����e�X�g�x�N�^
            if ismember(check_testvector_id, group_name_lst)
                warndlg(sprintf('Testvector id �u%s�v is created in previous.\nPlease check data of cell �u%s�v and try again.', ...
                                        check_testvector_id, [ 'A' num2str(i + start_index - 1)]), 'Warning'); 
                failed_flag = 1;
                if ishandle(bar)
                    delete(bar);
                end
                return;
            end
            %% �ŏ����� = �ő厞��
            min_time = min(time);
            max_time = max(time);
            if min_time == max_time || length(time) == 1
                warndlg(sprintf('Can not create the testvector �u%s�v\nbecause it has the same min and max simulation time.', group_name), 'Warning'); 
                failed_flag = 1;
                if ishandle(bar)
                    delete(bar);
                end
                return; 
            end
            signal_data_in_excel = excelData(i - length(time):i -1, 3:end);
            for j = 1: size(signal_data_in_excel, 2)
                signal_data{end + 1} = cell2mat(signal_data_in_excel(:, j));
            end
            signal_data = signal_data';
            time = time';
          %% �V����Signal Builder�u���b�N�ǉ�
           if isempty(blockHandle)
                try
                    blockHandle = signalbuilder([ system '/' sgb_name], 'create', time , signal_data, signal_name, group_name);
                catch ex 
                    errordlg(sprintf('Can not create signal builder block. Process is stopped.\n%s', ex.getReport), 'Error'); 
                    failed_flag = 1;
                    if ishandle(bar)
                        delete(bar);
                    end
                    return;
                end
                blkDialog = get(blockHandle, 'UserData');
                close(blkDialog);
                open_system(system);
          %% ����Signal Builder�u���b�N�ǉ������ꍇ�A�O���[�v�̂ݒǉ�     
           else
               blockHandle = signalbuilder(blockHandle, 'append', time , signal_data, signal_name, group_name);
           end
          %% �V�����O���[�v�̏����̂��߁A�ϐ��l���Z�b�g
           time = [];
           signal_data = {};
           group_name = check_testvector_id;
           group_name_lst{end + 1} = group_name;
        end
       %% �����Ȏ��ԃ`�F�b�N
        if length(time) > 1 && any(row_data{1} < time) == 1
            warndlg(sprintf('�utime�v at testvector �u%s�v is not valid.\nPlease check data of cell �u%s�v and try again.', ...
                                    group_name, [ 'B' num2str(i + start_index - 1)] )); 
            failed_flag = 1;
            if ishandle(bar)
                delete(bar);
            end
           return;
        end
        time(end + 1) = row_data{1};
        
       %% ProcessBar�X�V��------------------------------------------------��
        if i == size(excelData, 1)
            ProcessBar(sprintf('Processing�F%d/%d data rows.', i, size(excelData, 1)), percent, 0, 1);
        end
       %% ProcessBar�X�V��------------------------------------------------��
    end
    %% �Ō�̃O���[�v�̏���
    %% �ŏ����� = �ő厞��
    min_time = min(time);
    max_time = max(time);
    if min_time == max_time || length(time) == 1
        warndlg(sprintf('Can not create the testvector �u%s�v\nbecause it has the same min and max simulation time.', group_name), 'Warning'); 
        failed_flag = 1;
        if ishandle(bar)
            delete(bar);
        end
        return; 
    end
    signal_data_in_excel = excelData(i - length(time) + 1:i, 3:end);
    for j = 1: size(signal_data_in_excel, 2)
        signal_data{end + 1} = cell2mat(signal_data_in_excel(:, j));
    end
    time = time';
    signal_data = signal_data';
   %% �V����Signal Builder�u���b�N�ǉ�
   if isempty(blockHandle)
        try
            blockHandle = signalbuilder([ system '/' sgb_name], 'create', time , signal_data, signal_name, group_name);
        catch ex 
            errordlg(sprintf('Can not create signal builder block. Process is stopped.\n%s', ex.getReport), 'Error'); 
            failed_flag = 1;
            if ishandle(bar)
                delete(bar);
            end
            return;
        end
        blkDialog = get(blockHandle, 'UserData');
        close(blkDialog);
        open_system(system);
    %% ����Signal Builder�u���b�N�ǉ������ꍇ�A�O���[�v�̂ݒǉ�
    else
       blockHandle = signalbuilder(blockHandle, 'append', time , signal_data, signal_name, group_name);
   end
    ScrollbarOffset = get(get_param(system, 'handle'), 'ScrollbarOffset');
    p_X = pointerPosition(1) + ScrollbarOffset(1);
    p_Y = pointerPosition(2) + ScrollbarOffset(2);
    set(blockHandle, 'Position', [ p_X p_Y (p_X + 100) (p_Y + 25 * length(signal_name))]);
    %% SampleTime�ݒ�
    sbContain = find_system(blockHandle, 'FindAll', 'on', 'LookUnderMasks', 'on', 'BlockType', 'FromWorkspace');
    if ~isempty(sbContain)
        try
            if (isnumeric(sample_time) && isnan(sample_time) == 1) || ...
                (ischar(sample_time) && isempty(str2num(sample_time))) || ...
                (ischar(sample_time) && str2num(sample_time) <= 0) || ...
                (isnumeric(sample_time) && sample_time < 0)
                return;
            end
            set(sbContain(1), 'SampleTime', num2str(sample_time));
        catch
        end
    end
catch ex
    if ~isempty(blockHandle)
        delete(blockHandle);
    end
    errordlg([ex.getReport], 'Error');
    if ishandle(bar)
        delete(bar);
    end
end
end

%% '�e�X�g�x�N�^�[ID'������Z���̃C���f�b�N�X����
function [ start_index ] = FindStartIndex(Column_A_Data, excelData)
    start_index = 0;
    for i = 1: length(Column_A_Data)
        if strcmp(Column_A_Data{i}, '�e�X�g�x�N�^�[ID')
            RowData = excelData(i, 2:end);
            if strcmp(RowData{1}, '����')
                start_index = i;
                return;
            end
        end
    end
end

%% 'SampleTime'������Z����T���āA���ׂ̗̃Z����SampleTime�Ƃ��A�擾����
function [ sample_time ] = GetSampleTime(Column_A_Data, excelData)
    sample_time = 0;
    for i = 1: length(Column_A_Data)
        if strcmp(Column_A_Data{i}, 'SampleTime')
            sample_time = excelData{i, 2};
        end
    end
end

%% '�e�X�g�x�N�^�[ID'������s��'Input'�A'Output'������J�����ȊO�͍폜���s��
function [ excelData_new, signal_name_index_lst, error_flag, error_columnIndex, count_row_end, count_column_end ] = FindInputOutputColumnIndex(excelData, start_index)
    error_flag = 0;
    error_columnIndex = 0;
    row_end_flag = 0;
    count_row_end = 0;
    count_column_end = 0;
    excelData_new = excelData(start_index:end, 1:end);
   %% End�s�ȍ~���폜����
    for i = size(excelData_new, 1):-1:1
        if strcmpi(excelData_new{i, 1}, 'end')
            excelData_new(i, :) = [];
            row_end_flag = 1;
            count_row_end = count_row_end + 1;
        else
            if row_end_flag == 0
                excelData_new(i, :) = [];
            end
        end
    end
    %% �󔒗�AEnd��ȍ~���폜����
    signal_name_index_lst = [];
    start_check = 0;
    if size(excelData_new, 1) == 0
        return;
    end
    for i = size(excelData_new, 2): -1:2
        if strcmpi(excelData_new{1, i}, 'end')
            excelData_new(:, i) = [];
            old_signal_name_lst{i} = '';
            start_check = 1;
            count_column_end = count_column_end + 1;
            continue;
        else
            if start_check == 0
                excelData_new(:, i) = [];
                old_signal_name_lst{i} = '';
                continue;
            end
        end
        if i == 2
            if ~strcmp(excelData_new{1, i}, '����')
                excelData_new(:, i) = [];
                old_signal_name_lst{i} = '';
            else
                signal_name_index_lst(end + 1) = i;
            end
        else
            if ~strcmp(excelData_new{1, i}, 'Input') && ~strcmp(excelData_new{1, i}, 'Output') && ~strcmp(excelData_new{1, i}, 'Comments')
                columnValues = excelData_new(start_index:end, i);
                if ischar(columnValues{1}) && ~isempty(columnValues{1})
                    error_flag = 1;
                    error_columnIndex = i;
                    return;                        
                end
                for j = 2:length(columnValues)
                    if (isnumeric(columnValues{j}) && isnan(columnValues{i}) == 0) || ...
                       (ischar(columnValues{j}) && ~isempty(columnValues{i}))

                        error_flag = 2;
                        error_columnIndex = i;
                        return;
                    end
                end
                excelData_new(:, i) = [];
                old_signal_name_lst{i} = '';
            elseif strcmp(excelData_new{1, i}, 'Comments')
                excelData_new(:, i) = [];
                old_signal_name_lst{i} = '';
            else
                signal_name_index_lst(end + 1) = i;
            end
        end
    end
    signal_name_index_lst = sort(signal_name_index_lst);
end

%% �e�X�g�x�N�^�̍s�f�[�^�ɐ����łȂ��l������΁ANG�t���O��Ԃ�
function [ valid_data, index ] = CheckTestVectorData(row_data)
    valid_data = 1;
    index = 0;
    for i = 1: length(row_data)
        if ~isnumeric(row_data{i})
             valid_data = 0;
             index = i;
             return;
        else
            if isnan(row_data{i})
                valid_data = 0;
                index = i;
                return;
            end
        end
    end
end

%% �v���Z�X�o�[�̏���
function ProcessBar(message, percent, open, close)
    global bar;
    try
        %% �@ �v���Z�X�o�[�̏�����
        if open == 1
            % �@ (1) waitbar�̊֐��ŏ��������s��
            bar = waitbar(0, message, 'CreateCancelBtn', 'setappdata(gcbf,''canceling'',1)');
       %% �A ���Ƀv���Z�X�o�[���쐬���ꂽ�ꍇ�A�v���Z�X�X�V���s��
        else
            if ishandle(bar)
                % �A (1) waitbar�̊֐��Ńp�[�Z���g�ƕ\��������e���X�V����
                waitbar(percent, bar, sprintf('%s', message));
            end
        end
        %% �B �N���[�Y�t���O��1�̏ꍇ�A�v���Z�X�o�[�����
        if close == 1
            delete(bar);
        end
    catch
        if ishandle(bar)
            delete(bar);
        end
    end
end

%% Excel��ColumnIndex��ColumnName�ɕϊ�
function column_name = GetColumnName(index)
    if index <= 26
        column_name = sprintf('%s', 64 + index);
    else
        if mod(index, 26) == 0
            column_name = sprintf('%s%s', 64 + floor(index/26), 64 + 26);
        else
            column_name = sprintf('%s%s', 64 + floor(index/26), 64 + mod(index, 26));
        end
    end
end

function sheet_name = SelectSheetName(excel_sheetname_lst)
    select_sheet_name_dialog = dialog('Position',[300 300 300 120],'Name','Testvector Sheet Name');
    movegui(select_sheet_name_dialog, 'center');
    uicontrol('Parent', select_sheet_name_dialog,...
           'Style','text',...
           'Position',[20 70 300 40],...
           'String','Select Testvector Sheet Name', 'HorizontalAlignment', 'Left');

    popup = uicontrol('Parent',select_sheet_name_dialog,...
           'Style','popup',...
           'Position',[20 60 250 25],...
           'String', excel_sheetname_lst ,...
           'Callback', @popup_callback);
    find_default_index = 1;   
    for i = 1:length(excel_sheetname_lst)
        if ~isempty(regexp(excel_sheetname_lst{i}, '^�e�X�g�x�N�^', 'match', 'once'))
            find_default_index = i;
            break;
        end
    end
    popup.Value = find_default_index;
    uicontrol('Parent',select_sheet_name_dialog,...
           'Position',[75 20 70 25],...
           'String','OK',...
           'Callback',@ok_btn_callback);
       
    uicontrol('Parent',select_sheet_name_dialog,...
           'Position',[160 20 70 25],...
           'String','Cancel',...
           'Callback',@cancel_btn_callback);
       
    sheet_name = '';
    tmp_sheet_name = char(popup.String(find_default_index,:));
    uiwait(select_sheet_name_dialog);

    function popup_callback(popup, ~)
      idx = popup.Value;
      popup_items = popup.String;
      tmp_sheet_name = char(popup_items(idx,:));
    end
    function ok_btn_callback(~, ~)
      sheet_name = tmp_sheet_name;
      delete(gcf);
    end
    function cancel_btn_callback(~, ~)
      sheet_name = '';
      delete(gcf)
    end
end
%% �֐����FFix_RndMethod_BlockList
%  �T�v�F
%       �t�B�b�N�X���ʂ�\������
%  �p�����[�^�F 
%        varargin(GUI�p�̃p�����[�^)
%  �߂��l�F�@
%        varargout(GUI�̃n���h��)
%  �쐬�ҁF LOC
%  �쐬���F 2017/12/18
function varargout = Fix_RndMethod_BlockList(varargin)
% FIX_RNDMETHOD_BLOCKLIST MATLAB code for Fix_RndMethod_BlockList.fig
%      FIX_RNDMETHOD_BLOCKLIST, by itself, creates a new FIX_RNDMETHOD_BLOCKLIST or raises the existing
%      singleton*.
%
%      H = FIX_RNDMETHOD_BLOCKLIST returns the handle to a new FIX_RNDMETHOD_BLOCKLIST or the handle to
%      the existing singleton*.
%
%      FIX_RNDMETHOD_BLOCKLIST('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FIX_RNDMETHOD_BLOCKLIST.M with the given input arguments.
%
%      FIX_RNDMETHOD_BLOCKLIST('Property','Value',...) creates a new FIX_RNDMETHOD_BLOCKLIST or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Fix_RndMethod_BlockList_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Fix_RndMethod_BlockList_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Fix_RndMethod_BlockList

% Last Modified by GUIDE v2.5 18-Dec-2017 14:11:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Fix_RndMethod_BlockList_OpeningFcn, ...
                   'gui_OutputFcn',  @Fix_RndMethod_BlockList_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before Fix_RndMethod_BlockList is made visible.
function Fix_RndMethod_BlockList_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Fix_RndMethod_BlockList (see VARARGIN)

% Choose default command line output for Fix_RndMethod_BlockList
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Fix_RndMethod_BlockList wait for user response (see
% UIRESUME)2
% uiwait(handles.figure1);
movegui(handles.figure1, 'center');
try
    hJScroll = findjobj(handles.tb_fix_result); 
    hJTable = hJScroll.getViewport.getView; 
    hJTable.setNonContiguousCellSelection(false);
    hJTable.setColumnSelectionAllowed(false);
    hJTable.setRowSelectionAllowed(true);
    uitablepeer = findjobj(handles.figure1,'class', 'uitablepeer');
    set(uitablepeer, 'MouseClickedCallback',@MouseClickHandler);
    uitablepeer.SelectionForeground = javax.swing.plaf.ColorUIResource(0, 0, 0);
catch
end
global fixed_blocks;
global fixed_rule;
global fixed_rule_content;
global checkRndMeth;
global viewSelectionRndMeth;
if isempty(fixed_blocks)
    return;
end
set(handles.txtStyleInfor, 'String', fixed_rule_content);
viewSelectionRndMeth = '';
if strcmp(checkRndMeth, 'Ceiling')
    viewSelectionRndMeth = '�������̊ۂ�';
elseif strcmp(checkRndMeth, 'Convergent')
    viewSelectionRndMeth = '�ł��߂������ւ̊ۂ�';
elseif strcmp(checkRndMeth, 'Floor')    
    viewSelectionRndMeth = '�������̊ۂ�';
elseif strcmp(checkRndMeth, 'Nearest')
    viewSelectionRndMeth = '�ł��߂������ւ̊ۂ�';
elseif strcmp(checkRndMeth, 'Round')
    viewSelectionRndMeth = '�����ւ̊ۂ�';
elseif strcmp(checkRndMeth, 'Simplest')
    viewSelectionRndMeth = '�V���v���Ȋۂ�';
elseif strcmp(checkRndMeth, 'Zero')    
    viewSelectionRndMeth = '�[�������ւ̊ۂ�';
end
set(handles.txtRndMethod, 'String',[ '�C���ۂߕ����F' viewSelectionRndMeth ]);
columnWidth = {100 100};
columnName = {'', ''};
if strcmp(fixed_rule, 'ym_1018')
    columnName = {'Block Path', 'Fix parameter name', 'Before fix value', 'After fix value', 'Fix'  };
    if size(fixed_blocks, 1) >=100
        columnWidth = {440 140 130 130 65}; 
    else
        columnWidth = {460 140 130 130 65}; 
    end
end
tableData = fixed_blocks(2:end,1:end-1);
set(handles.tb_fix_result, 'Data',tableData);
set(handles.tb_fix_result, 'ColumnName', columnName);
set(handles.tb_fix_result, 'ColumnWidth', columnWidth);

% --- Outputs from this function are returned to the command line.
function varargout = Fix_RndMethod_BlockList_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA) 

% Get default command line output from handles structure
varargout{1} = handles.output;

function MouseClickHandler(handle, eventhandle)
global fixed_blocks;
try
    if eventhandle.getClickCount == 2
        if handle.SelectedRow == -1 ||  handle.SelectedColumn == -1 ||  ...
           isempty(fixed_blocks)
            return;
        end
        try
            hilite_block(fixed_blocks{handle.SelectedRow + 2, size(fixed_blocks, 2)});
        catch
            warndlg('Please check that the model is open.');
        end
    end
catch
end

% --- Executes on button press in chkFixAll.
function chkFixAll_Callback(hObject, eventdata, handles)
% hObject    handle to chkFixAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkFixAll
try
    tableData = get(handles.tb_fix_result, 'Data');
    for i = 1: size(tableData, 1)
        if ~isempty(tableData{i,4})
            continue;
        end
        % �@ [chkFixAll] = TRUE
        if get(handles.chkFixAll, 'Value') == 1
            % [tb_fix_result]��Column[5]�ɑS��TRUE���Z�b�g����
            tableData{i, 5} = true;
        % �A [chkFixAll] = FALSE    
        else
            % [tb_fix_result]��Column[5]�ɑS��FALSE���Z�b�g����
            tableData{i, 5} = false;
        end
    end
    set(handles.tb_fix_result, 'Data',tableData);
    set(handles.tb_fix_result, 'ColumnName', {'Block Path', 'Fix parameter name', 'Before fix value', 'After fix value', 'Fix' });
catch ex
    errordlg([ex.message ' '  num2str(ex.stack(1).line)], 'Error', 'modal');
end

% --- Executes on button press in btnRunFix.
function btnRunFix_Callback(hObject, eventdata, handles)
% hObject    handle to btnRunFix (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global checkRndMeth;
global checkRndMeth_Monitor;
global viewSelectionRndMeth;
try
    tableData = get(handles.tb_fix_result, 'Data');
    hasCheck = 0;
    non_fix = 0;
    for i = 1: size(tableData, 1)
        if tableData{i,5} == true
            hasCheck = 1;
        end
        if isempty(tableData{i,4})
            non_fix = 1;
        end
    end
    if non_fix == 0
        warndlg(sprintf('All round method of blocks are corrected. The fix doesn''t need.'), 'Info', 'modal');
        return;
    end
    if hasCheck == 0
        warndlg(sprintf('There is no selected block to fix round method.\nPlease check the checkbox at block which you want to fix round method and try again.'), 'Info', 'modal');
        return;
    end
    selectButton = questdlg(sprintf('Do you want to fix round method of selecting blocks below?'), 'Question','Yes', 'No', 'Yes');
    switch(selectButton)
       %% Yes��I�������ꍇ�A�C�����s���B�C���������ŃO���b�h���X�V����
        case 'Yes'
            colorgen = @(color,text) ['<html><table border=0 width=500 bgcolor=',color,'><TR><TD>',text,'</TD></TR> </table></html>'];
            for i = 1: size(tableData, 1)
                try
                    MaskType = get_param(tableData{i,1}, 'MaskType');
                catch
                    continue;
                end
                if tableData{i,5} == true
                   if strcmp(MaskType, 'MaskMonitor')
                       set_param(tableData{i,1}, 'RndMeth', checkRndMeth_Monitor);
                   else
                       set_param(tableData{i,1}, 'RndMeth', checkRndMeth);
                   end
                   tableData{i, 4} = viewSelectionRndMeth;
                   tableData{i, 5} = false;
                   tableData{i, 1} = colorgen('#55FFFF', tableData{i,1});
                   tableData{i, 2} = colorgen('#55FFFF', tableData{i,2});
                   tableData{i, 3} = colorgen('#55FFFF', tableData{i,3});
                   tableData{i, 4} = colorgen('#55FFFF', tableData{i,4});
                end
            end     
            set(handles.tb_fix_result, 'Data', tableData);
       %% No�E�~��I�������ꍇ�A�C�����L�����Z������B
        case 'No'                            
          return;
        case ''
          return;
    end
catch ex
    errordlg([ex.message ' '  num2str(ex.stack(1).line)], 'Error', 'modal');
end
% --- Executes when entered data in editable cell(s) in tb_fix_result.
function tb_fix_result_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to tb_fix_result (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
try
    % �O���b�h���̃`�F�b�N�{�b�N�X�͂P�̃`�F�b�N��OFF�ɂȂ�����A
    % [Fix All]�̃`�F�b�N�{�b�N�X�̃`�F�b�N��OFF�ɂ���
    if eventdata.Indices(2) == 5
        if eventdata.Source.Data{eventdata.Indices(1), 5} == false
            set(handles.chkFixAll, 'Value', 0);
        end
        if ~isempty(eventdata.Source.Data{eventdata.Indices(1), 4})
            eventdata.Source.Data{eventdata.Indices(1), 5} = false;
            warndlg(sprintf('Round method of block is corrected. The fix doesn''t need.'), 'Info', 'modal');
            if eventdata.Indices(1) <= 22
                return;
            end
            hJScroll = findjobj(handles.tb_fix_result); 
            hJTable = hJScroll.getViewport.getView; 
            hJTable.setRowSelectionInterval(eventdata.Indices(1) - 1, eventdata.Indices(1) - 1);
            uitablepeer = findjobj(handles.figure1, 'Class', 'uitablepeer');
            uitablepeer.updateUI();
            uitablepeer.scrollRowToVisible(eventdata.Indices(1));
            uitablepeer.updateUI();
        end
    end
catch ex
    errordlg([ex.message ' '  num2str(ex.stack(1).line)], 'Error', 'modal');
end

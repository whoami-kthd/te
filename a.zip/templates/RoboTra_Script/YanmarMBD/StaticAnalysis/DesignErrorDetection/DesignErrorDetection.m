%% �֐����FDesignErrorDetection
%  �T�v�F 
%       Configure current model and execute design error detection
%       
%  �p�����[�^�F 
%        
%  �߂��l�F�@
%  �쐬�ҁF KhaiTV
%  �쐬���F 2019/07/23

function result = DesignErrorDetection(~)
    % Check current configuration of model
    % Configuration need to check before execute design verifier are listed
    % as following:
    %    Solver option:           fixed-step (if need)
    %    Mode :                   DesignErrorDetection
    %    Maximum analysis time :  2000000
    %    Design Error Detection : Dead logic and others
    %    Result :                 Save test data to file
    %    Report :                 Generate report result       
    
    
    % result = 0: Execution error, result = 1: Execution success, result = 2: does not execution
    result = 1;
    CurrentSys = get_param(0,'CurrentSystem');
    SolverType = get_param(CurrentSys,'SolverType');
    
   %% Try to compile model for check model has error or not
    try   
        evalin('base', [ CurrentSys '([],[],[],''compile'')']);
        evalin('base', [ CurrentSys '([],[],[],''term'')']); 
    catch ex
        errordlg(sprintf(['�R���p�C���G���[  (Compile error) \n' ex.message]));
        result = 0;
        return;
    end
    
    try
        if(strcmp(SolverType, 'Fixed-step')) 
            RunTest(CurrentSys);
        else
            QuesStr = 'SolverType of model Configuration need to change:';
            QuesStr = [QuesStr newline];
            tmp = '        Variable-Step  ->  Fixed-step';
            QuesStr = [QuesStr newline tmp];

            QuesStr = [QuesStr newline newline 'Do you want to change???'];
            answer = questdlg(QuesStr, ...
                              'Change Configuration', ...
                              'Yes','No', 'Yes');

            % Handle response
            if(strcmp(answer, 'Yes'))
                 set_param(CurrentSys,'SolverType', 'Fixed-step');
                 save_system;
                 result = RunTest(CurrentSys);
            else
                % do nothing
                result = 2;
            end
        end
    catch ex
        dispstr = sprintf(['Simulink Design Verifier checking is error. Please check\n' ex.message]); 
        errordlg(dispstr);
        disp(dispstr);
        result = 0;
        return;
    end
end

function result = RunTest(system)

    result = 1;
    %opts1=  optimset('display','off');
    f = waitbar(0,'Design Error Detection start ...');
    pause(.5)
    Opts = sldvoptions;
    Opts.Mode = 'DesignErrorDetection';
    Opts.MaxProcessTime = 2000000;
    Opts.SaveDataFile = 'on';
    Opts.SaveReport = 'on';
    
    %% Run detect design error
    Opts.DetectDeadLogic = 'on';
    Opts.DetectOutOfBounds = 'on';
    Opts.DetectDivisionByZero = 'on';
    Opts.DetectIntegerOverflow = 'on';
    
    waitbar(.5,f,'Simulink Design Verifier is checking ...');
    
    t = datestr(datetime('now'), 'yyyy-mm-dd HH:MM:SS');
    t = strrep(strrep(strrep(t, ':', ''), '-', ''), ' ', '_');
    file_name = ['DesignErrorCheckResult_' t '_' system];
    Opts.ReportFileName = file_name;
    current_path = pwd;
    Opts.OutputDir = [current_path '\' file_name];
    
    try
        initialCov = cvsim(system);
        %cvhtml('sil_initial_coverage', initialCov);
        
        [ status, files] = sldvrun(system, Opts, true, initialCov);
        if (status == 1)
            waitbar(1,f,'Simulink Design Verifier checking is done');
%            current_path = pwd;
%            copyfile(files.Report, [current_path '\' file_name '.html' ], 'f');
        else
            warndlg(sprintf('Design verifier checking is not successful. Please check !!!'));
            result = 0;
            return;
        end
    catch ex
        errordlg(sprintf(['Simulink Design Verifier checking is error. Please check\n' ex.message]));
        result = 0;
        return;
    end
    
    close(f);
    return;
end
function result_fid = CreateReportBody_CheckResult_Description_Title(fid)
    result_fid = fid;
    fprintf(result_fid,'%s', '<br><br><font color="#800000"><b>');
    fprintf(result_fid,'\n');
    %% �`�F�b�N���ʂ̃O���[�v�쐬
    fprintf(result_fid,'%s', '<span class="FolderControl" id="FolderControl_');
    fprintf(result_fid,'%s', '" onclick="MATableShrink(this,''');
    fprintf(result_fid,'%s', ''')" onmouseover="this.style.cursor = ''pointer''">');
    fprintf(result_fid,'%s', '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAAhklEQVR42mL8//8/AyUAIICYGCgEAAFEsQEAAUSxAQABxIIu0NTURDBQ6urqGGFsgABiwaagpqYOp+aWliYUPkAAUewFgACi2ACAAGLBKcGCafafP/8wxAACCKcB2BRjAwABRLEXAAKIYgMAAoiFmKjCBwACiJHSzAQQQBR7ASCAKDYAIMAAUtQUow+YsTsAAAAASUVORK5CYII="></span>');
    fprintf(result_fid,'%s', '</b></font>');
    fprintf(result_fid,'\n');
    fprintf(result_fid,'%s', '<div name="');
    fprintf(result_fid,'%s', '" id="');
    fprintf(result_fid,'%s', '" class="FolderContent">');
    fprintf(result_fid,'%s', '<div class="EmptyFolderMessage" style="display: none;">���ׂẴ`�F�b�N����\���ɂȂ��Ă��܂��B</div> ');
    fprintf(result_fid,'\n');
end
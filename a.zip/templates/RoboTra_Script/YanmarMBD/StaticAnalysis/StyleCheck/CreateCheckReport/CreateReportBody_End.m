function result_fid = CreateReportBody_End(fid)
    result_fid = fid;
    fprintf(result_fid,'%s', '</body>');
    fprintf(result_fid,'\n');
    fprintf(result_fid,'%s', '</html>');
    fprintf(result_fid,'\n');
end
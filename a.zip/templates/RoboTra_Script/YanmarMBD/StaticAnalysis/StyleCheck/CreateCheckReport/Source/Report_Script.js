/* define String.trim() method if not defined (used by filterByText() function) */
if(!String.prototype.trim) {
  String.prototype.trim = function () {
    return this.replace(/^\s+|\s+$/g,'');
  };
}

// rtwreport needs it 
function init() {
    var showFailed = document.getElementById("Failed Checkbox");
    var showPassed = document.getElementById("Passed Checkbox");
    var showWarning = document.getElementById("Warning Checkbox");
    var showNotRun = document.getElementById("Not Run Checkbox");       
    
    inputText = RegExp('\\?(.*)').exec(window.location.search);

    if (inputText == null) {
        /* refresh check boxes and search input */
        showFailed.checked = true;
        showPassed.checked = true;
        showWarning.checked = true;
        showNotRun.checked = true;
        updateVisibleChecks();
        return;
    }
    else {
        showFailed.checked = false;
        showPassed.checked = false;
        showWarning.checked = false;
        showNotRun.checked = false;
    }
    
    if (!inputText[1].localeCompare("showPassedChecks")) {
        showPassed.checked = true;
    }
    if (!inputText[1].localeCompare("showWarningChecks")) {
        showWarning.checked = true;
    }
    if (!inputText[1].localeCompare("showFailedChecks")) {
        showFailed.checked = true;
    }
    if (!inputText[1].localeCompare("showNotRunChecks")) {
        showNotRun.checked = true;
    }
    if (!showFailed.checked && !showPassed.checked && 
        !showWarning.checked && !showNotRun.checked) {
        showFailed.checked = true;
        showPassed.checked = true;
        showWarning.checked = true;
        showNotRun.checked = true;
    }
    updateVisibleChecks();
}

function markEmptyFolders(){
	var nodeTypes = ["FailedCheck","PassedCheck",  "WarningCheck", "NotRunCheck"];
	var folderArray = document.querySelectorAll("div.FolderContent");
	
	for (var n=0;n<folderArray.length;n++){
		/* get direct check result children and check visibility */
		var childNodes = folderArray[n].childNodes;
		var noneVisible = true;
		var noChecksInFolder = true;
		
		for (var ni=0;ni<childNodes.length;ni++){
			if (childNodes[ni].nodeType == 1 && childNodes[ni].tagName.toLowerCase() == "div"){
				if (childNodes[ni].className == nodeTypes[0] || childNodes[ni].className == nodeTypes[1] || childNodes[ni].className == nodeTypes[2] || childNodes[ni].className == nodeTypes[3]){
					noChecksInFolder = false;
					if (childNodes[ni].style.display != "none"){
						noneVisible = false;
                        break;
					}
				}
			}
		}
		
		/* Only display hidden message if any checks inside the folders and not just other folders */
		if (!noChecksInFolder){
			var hiddenMessage = folderArray[n].querySelector("div.EmptyFolderMessage");
			
			if (hiddenMessage && noneVisible == true){
				hiddenMessage.style.display = "";
			}else if (hiddenMessage && noneVisible == false){
				hiddenMessage.style.display = "none";
			}else{
				/* hidden message not found */
			}
		}
	}

    return;
}

function updateVisibleChecks( /* show all flags */ checkbox ){
	
	var checkboxes = ["Failed Checkbox", "Passed Checkbox", "Warning Checkbox", "Not Run Checkbox"];
	var nodeTypes = ["Failed Check","Passed Check",  "Warning Check", "Not Run Check"];
	var textInput = document.getElementById("TxtFilterInput");
	
	
	if (checkbox && textInput && textInput.color=="gray"){
		var checkType = checkbox.id;
		var ind = checkboxes.indexOf(checkType);
		var nodes = document.getElementsByName(nodeTypes[ind]);
		for (i = 0; i < nodes.length;i++){
		    nodes[i].style.display = checkbox.checked ? "" : "none";
		}
	}
	else{ /* Update all checks if called from init or if a previous text filter was applied */
		for (i = 0; i < checkboxes.length; i++){
			
			  var show = document.getElementById(checkboxes[i]).checked ? "" : "none";
			  var nodes = document.getElementsByName(nodeTypes[i]);
			  for(j = 0; j < nodes.length; j++){
				  nodes[j].style.display = show;
			  }
		   
		}
	}

    /* clear text search */
	if (textInput && checkbox){
		textInput.value = "�L�[���[�h";
        textInput.style.color = "gray";
        textInput.blur;
	}

    markEmptyFolders();

    return; 
}

function filterByText(ev){
	// get all the nodes
	var allNodeTypes = ["Failed Check","Passed Check",  "Warning Check", "Not Run Check"];
	var checkboxes = ["Failed Checkbox", "Passed Checkbox", "Warning Checkbox", "Not Run Checkbox"];
	var nodeTypes = [];
	
	// get nodes depending on filter selections
	for (var n=0; n<checkboxes.length; n++){
		var checkbox = document.getElementById(checkboxes[n]);
		if (checkbox && checkbox.checked){
			nodeTypes.push(allNodeTypes[n]);
		}
	}
	
    var searchNodes = [".CheckHeading"];
    var allnodes = [];
	var alltext = [];
	if (!ev) return;
	var target = ev.target ? ev.target : window.event.srcElement;
	var searchString = target.value;
	
	if (!searchString){
        updateVisibleChecks();  // clear all and display by other filters
	}else{
		for (i = 0; i < nodeTypes.length; i++){
			var nodes = document.getElementsByName(nodeTypes[i]);
			for (j = 0; j < nodes.length; j++){
				// get text from check heading
				var checkContent = nodes[j].querySelector(searchNodes).innerHTML;
				// creaet a regular expression to ignore case
				var ss = new RegExp(searchString.trim(), "i");
				if (ss.exec(checkContent)){
				   nodes[j].style.display = "";
				}else{
				   nodes[j].style.display = "none";
				}
			}
		}
        markEmptyFolders();
	}	
}


function MATableShrink(o,tagNameStr){
    var temp = document.getElementsByName(tagNameStr);
    var classUsed = document.getElementsByName('EmbedImages'); 
    var embeddedMode = !(classUsed.length == 0);
    var img = o.querySelector("img");

    if (temp[0].style.display == "") 
    {
        temp[0].style.display = "none";
        if (embeddedMode)
        {
            img.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAAkUlEQVR42mL8//8/AyUAIICYGCgEAAFEsQEAAUSxAQABxIIu0NTURDBQ6urqGGFsgABiwaagpqYOp+aWliYUPkAAEfQCCwt+JQABRHEYAAQQCzE2w9h//vzDUAcQQDgNgCkGacamEQYAAohiLwAEEEED8NkOAgABxEJMVOEDAAHESGlmAgggisMAIIAoNgAgwAC+/BqtC+40NQAAAABJRU5ErkJggg==";
        }
        else
        {
            img.src = "./Source/plus.png";
        }
    } 
    else 
    {
        temp[0].style.display = "";
        if (embeddedMode)
        {
            img.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAAhklEQVR42mL8//8/AyUAIICYGCgEAAFEsQEAAUSxAQABxIIu0NTURDBQ6urqGGFsgABiwaagpqYOp+aWliYUPkAAUewFgACi2ACAAGLBKcGCafafP/8wxAACCKcB2BRjAwABRLEXAAKIYgMAAoiFmKjCBwACiJHSzAQQQBR7ASCAKDYAIMAAUtQUow+YsTsAAAAASUVORK5CYII=";
        }
        else
        {
            img.src = "./Source/minus.png";
        }
    }
}

// rtwreport needs it 
function updateHyperlink() {
    docObj = window.document;
    loc = document.location;
    var aHash = "";
    var externalweb = "false";
    if (loc.search || loc.hash) {
        if (loc.search)
            aHash = loc.search.substring(1);
        else
            aHash = loc.hash.substring(1);
    }    
    var args = new Array();
    args = aHash.split('&');
    for (var i = 0; i < args.length; ++i) {
        var arg = args[i];
          sep = arg.indexOf('=');
        if (sep != -1) {
            var cmd = arg.substring(0,sep);
            var opt = arg.substring(sep+1);
            switch (cmd.toLowerCase()) {
            case "externalweb":
                externalweb = opt;
                break;
            }
        }
    }        
    if (externalweb === "true") {        
        var objs = docObj.getElementsByTagName("a");
        if (objs.length > 0 && objs[0].removeAttribute) {
            for (var i = 0; i < objs.length; ++i) {           
                if (objs[i].href.indexOf('matlab') > -1)           
                    objs[i].removeAttribute("href");                
            }
        }
    }
    init();
}
    
function navigateToElement(eleID) {
   var e = document.getElementById(eleID);
   if (!!e && e.scrollIntoView) {
       e.scrollIntoView();
   }
}

function setTextContent(element, value) {
    var content = element.textContent;
    if (value === undefined) return;
    
    if (content !== undefined) element.textContent = value;
    else element.innerText = value;
}

function hideControlPanel(control){
	var panelComponents = ["ControlsCheckFiltering", "ControlsView", "ControlsTOC"];
	var reportContent = document.querySelector(".ReportContent");
	var controlPanel = document.getElementById("ControlPanel");
	var isHidden = false;
	
    if (reportContent && control && controlPanel) {
    	for (var n=0; n<panelComponents.length; n++){
			var component = document.getElementById(panelComponents[n]);
			
			if (component && component.style.display == ""){
				component.style.display = "none";
            } else if (component && component.style.display == "none"){
				component.style.display = "";
			}
		}
		
		if (controlPanel.style.width != "6px"){
			reportContent.style.marginLeft = "25px";
	    	controlPanel.style.width = "6px";
	    	control.style.left = "0px";
	       	var innerDiv = control.querySelector("#HidePanelControlInner");
	       	/* setTextContent(innerDiv, "\u25BA"); */
            setTextContent(innerDiv, "�t");
	    } else {
	    	reportContent.style.marginLeft = "225px";
        	controlPanel.style.width = "210px";
        	control.style.left = "204px";
        	var innerDiv = control.querySelector("#HidePanelControlInner");
        	/* setTextContent(innerDiv, "\u25C0"); */
            setTextContent(innerDiv, "�s");
        }
    }
}

/* Copyright 2013 The MathWorks, Inc. */
//COLLAPSIBLE FEATURE

// global variables
var GlobalCollapseState = "off";

function collapseSDHelper(o, CollElementParent, disp, mode){
    var CollElement = CollElementParent; /* ul/ol with lists, tbody with table */

    if (CollElement.nodeName == "UL" || CollElement.nodeName == "OL"){
        var CollName = "LI";
    }else if (CollElement.nodeName == "TABLE"){
        if (CollElement.querySelector('tbody')) {
            /* tr modes are child nodes of tbody node */
            CollElement = CollElement.querySelector('tbody');
        }
        var CollName = "TR";
    }
    
    // get children (li for list and tr for table)
    var children = CollElement.childNodes;

    var nElements = 0;
    for (var i=0;i<children.length;i++){
        if (children[i].nodeName == CollName){
            nElements = nElements + 1;
            if (nElements > 5){
                children[i].style.display = disp;
            }
        }
    }
    if (disp == "none"){
        if (CollName == "LI"){
            var text = " ����)";
        }else{
            var text = " �s)";
        }
        
        var textNode = document.createTextNode(("\u2228 ����� (" + (nElements-5) + text));
        o.replaceChild(textNode,o.firstChild);

        CollElementParent.setAttribute("dataCollapse", "on");

        /* scroll to element if it is not visible */
        if (mode == "single" && CollElement.offsetTop < document.documentElement.scrollTop){
			CollElement.scrollIntoView();
		}
    }else{
        var textNode = document.createTextNode(("\u2227 " + "�k��"));
        o.replaceChild(textNode,o.firstChild);

        CollElementParent.setAttribute("dataCollapse", "off");
    }
}

function collapseSD(o, ID){
    var CollElement = document.getElementById(ID);
    if (CollElement != null){
        if (CollElement.getAttribute("dataCollapse") == "off"){
            var disp="none";
        }else{
            var disp="";
        }
        collapseSDHelper(o, CollElement, disp, "single");
    }
}

function collapseAllHelper(o, CollElement, CollInfo, disp){

    if (CollElement != null){
        var img = o.querySelector("img");
        if (disp == "none"){
            CollElement.style.display = disp;
			img.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAAkUlEQVR42mL8//8/AyUAIICYGCgEAAFEsQEAAUSxAQABxIIu0NTURDBQ6urqGGFsgABiwaagpqYOp+aWliYUPkAAEfQCCwt+JQABRHEYAAQQCzE2w9h//vzDUAcQQDgNgCkGacamEQYAAohiLwAEEEED8NkOAgABxEJMVOEDAAHESGlmAgggisMAIIAoNgAgwAC+/BqtC+40NQAAAABJRU5ErkJggg==";
        }else{
            CollElement.style.display = disp;
			img.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAAhklEQVR42mL8//8/AyUAIICYGCgEAAFEsQEAAUSxAQABxIIu0NTURDBQ6urqGGFsgABiwaagpqYOp+aWliYUPkAAUewFgACi2ACAAGLBKcGCafafP/8wxAACCKcB2BRjAwABRLEXAAKIYgMAAoiFmKjCBwACiJHSzAQQQBR7ASCAKDYAIMAAUtQUow+YsTsAAAAASUVORK5CYII=";
        }

        if (CollInfo != null){
            if (disp == "none"){
                CollInfo.style.display = "";
            }else{
                CollInfo.style.display = "none";
            }
        }
    }
}

function collapseAll(o, ID, ID2){
    var CollElement = document.getElementById(ID);
    var CollInfo = document.getElementById(ID2);

    if (CollElement.style.display == ""){
        var disp = "none";
    }else{
        var disp = "";
    }

    collapseAllHelper(o, CollElement, CollInfo, disp);
}

function expandCollapseAll(o){
	/* IE has no method for getting elements by class name. Use querySelectorAll instead 
       Note: requires IE not to be in IE7 compatability mode */
    var SDCollapse = document.querySelectorAll(".SystemdefinedCollapse");
    var Button = null;

    if (GlobalCollapseState == "off"){
        var disp = "none";
        GlobalCollapseState = "on";

        if (o && o.firstChild.nodeType == 3) {
            var textNode = o.firstChild;
        	textNode.nodeValue = " �`�F�b�N�ڍׂ�\��";
		}
    }else{
        var disp = "";
        GlobalCollapseState = "off";

        if (o && o.firstChild.nodeType == 3) {
            var textNode = o.firstChild;
        	textNode.nodeValue = " �`�F�b�N�ڍׂ��\��";
		}
    }

    for (var i=0;i<SDCollapse.length;i++){
        Button = SDCollapse[i].nextSibling;
        while(Button.nodeType !== 1){
            Button = Button.nextSibling;
        }
        //Button = SDCollapse[i].parentNode.querySelector("span.SDCollapseControl");
        collapseSDHelper(Button, SDCollapse[i], disp, "all");
    }
		
    var AllCollapse = document.querySelectorAll(".AllCollapse");

    for (i=0;i<AllCollapse.length;i++){
		Button = AllCollapse[i].parentNode.querySelector("span");

        var Divs =  AllCollapse[i].parentNode.querySelectorAll("div");
        if (Button && Divs.length>=2) {
            collapseAllHelper(Button, AllCollapse[i], Divs[1], disp);
        }
    }
}


function expandCollapseAllOnLoad(){
    GlobalCollapseState = "on";
    var Switch = document.getElementById("ExpandCollapseAll");
    expandCollapseAll(Switch);
}
//END COLLAPSIBLE
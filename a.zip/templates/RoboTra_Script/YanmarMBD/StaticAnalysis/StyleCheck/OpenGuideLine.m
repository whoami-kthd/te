function [ result ] = OpenGuideLine(info)
    result = 0;
    Styles = importdata('DefineStyle.xlsx');
    guideline = Styles.Guideline;
    if size(guideline, 1) >= 2 && size(guideline, 2) >= 2
        if ~isempty(regexp(info.MAObj.ActiveCheck.getID, '^yanmar.JMAAB', 'match'))
            guideline = guideline{1, 2};
        else
            guideline = guideline{2, 2};
        end
    else
        guideline = '';
    end
    file_path_name = which(guideline);
    if isempty(file_path_name)
        warndlg('Guideline is not existed. Please check guideline file name in "DefineStyle.xlsx".', 'Warning', 'modal');
        return;
    end
    try
        winopen(file_path_name);
        result = 1;
    catch ex
        result = ModelAdvisor.Text('Error�FCan not open Guideline file.');
        errordlg(sprintf('%s\n%s', ex.message , ...
                                   'Please make sure Guideline file can open with general double click.'), 'Error', 'modal');
    end
end
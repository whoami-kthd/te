function result = Check_ChartBlock_Commented(rt, model_name, chart_path, chart_name)
   result = 0;
   model = rt.find('Name', model_name, 'Parent', '');
   blocks_handles = model.find('-isa', 'Simulink.Block', 'Commented', 'on', 'Path', chart_path, 'Name', chart_name);
   if ~isempty(blocks_handles)
       result = 1;
       return;
   end
   blocks_handles = model.find('-isa', 'Simulink.Block', 'Commented', 'through', 'Path', chart_path, 'Name', chart_name);
   if ~isempty(blocks_handles)
        result = 1;
  end
end
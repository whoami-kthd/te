function [ portName, blk_handle, chart_data ] = FindInportNameOfSubSystemFromPortNumber(subHandle, portNumber, type)
global bar;
    try
        portName = '';
        blk_handle = [];
        chart_data = [];
        blks = find_system(subHandle, 'SearchDepth', '1', 'BlockType', type, 'Port', num2str(portNumber));
        if isempty(blks)
            % �T�u�V�X�e������Inport�EOutport���擾�ł��Ȃ��ꍇ�A�`���[�g���������AportName���擾����
            try
                errorFcn = get(subHandle, 'ErrorFcn');
            catch
                errorFcn = '';
            end
            if ~strcmp(errorFcn, 'Stateflow.Translate.translate')
                return;
            end
            rt = sfroot;
            sub_Path = get(subHandle, 'Path');
            sub_Name = get(subHandle, 'Name');
            model_name = GetModelName(sub_Path);
            model = rt.find('Name', model_name, 'Parent', '');
            chart = model.find('-isa', 'Stateflow.Chart', 'Name', sub_Name, 'Path', [ sub_Path '/' sub_Name]);
            if ~isempty(chart)
               [ portNameList, dataLst ] = GetPortNames(chart, type);
               for j = 1: length(dataLst)
                   if dataLst{j}.Port == portNumber
                       portName = portNameList{j};
                       chart_data = dataLst{j};
                   end
               end
               return;
            end
            truthtable = model.find('-isa', 'Stateflow.TruthTableChart', 'Name', sub_Name, 'Path', [ sub_Path '/' sub_Name]);
            if ~isempty(truthtable)
               [ portNameList, dataLst ] = GetPortNames(truthtable, type);
               for j = 1: length(dataLst)
                   if dataLst{j}.Port == portNumber
                       portName = portNameList{j};
                       chart_data = dataLst{j};
                   end
               end
            end  
            truthtable = model.find('-isa', 'Stateflow.StateTransitionTableChart', 'Name', sub_Name, 'Path', [ sub_Path '/' sub_Name]);
            if ~isempty(truthtable)
               [ portNameList, dataLst ] = GetPortNames(truthtable, type);
               for j = 1: length(dataLst)
                   if dataLst{j}.Port == portNumber
                       portName = portNameList{j};
                       chart_data = dataLst{j};
                   end
               end
            end  
            blk_handle = [];
        else
            portName = get(blks(1), 'Name');
            blk_handle = blks(1);
        end
    catch ex
        if ishandle(bar)
            delete(bar);
        end
        errordlg([ ex.message ' ' num2str(ex.stack(1).line)]);
    end
end

function [ resultNames, dataLst ] = GetPortNames(block, type)
    resultNames = {};
    dataLst = {};
    data = block.find('-isa', 'Stateflow.Data');
    for i = 1: length(data)
        if strcmp(type, 'Inport')
            if strcmp(data(i).Scope, 'Input')
                resultNames{end + 1} = data(i).Name;
                dataLst{end + 1} = data(i);
            end
        else
            if strcmp(data(i).Scope, 'Output')
                resultNames{end + 1} = data(i).Name;
                dataLst{end + 1} = data(i);
            end
        end
    end
end
function model_name = GetModelName(SubsystemPath)
    model_handle = get_param(SubsystemPath, 'handle');
    model_name = get(model_handle, 'Path');
    if strcmp(get(model_handle, 'Name'), get(model_handle, 'Path'))
        model_name = get_param(SubsystemPath, 'Name');
        return;
    end
    model_name = GetModelName(model_name);
end
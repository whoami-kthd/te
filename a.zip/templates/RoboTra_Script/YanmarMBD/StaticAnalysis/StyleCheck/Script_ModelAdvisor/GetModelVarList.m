function vars_list = GetModelVarList(model_name)
    vars_list = {};
    vars_info = get(get_param(model_name, 'handle'), 'ReferencedWSVars');
    for i = 1: length(vars_info)
        try
            vars_list{end + 1} = vars_info(i).Name;
        catch
        end
    end
end
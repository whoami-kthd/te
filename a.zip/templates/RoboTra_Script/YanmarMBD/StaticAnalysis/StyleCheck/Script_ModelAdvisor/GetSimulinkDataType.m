function result_data_type = GetSimulinkDataType(data_type, slddSection)
    try
        % boolean, BOOL
        if strcmp(data_type, 'boolean') || strcmp(data_type, 'BOOL')
            result_data_type = 'boolean';
        else
            % int8�Aint16�Aint32�Aint64
            % uint8�Auint16�Auint32�Auint64
            intmax(data_type);
            result_data_type = data_type;
        end
    catch
        try
            % single�Adouble
            realmax(data_type);
            result_data_type = data_type;
        catch
            try
                % Fixed-point
                numericType = fixdt(data_type);
                result_data_type = data_type;
            catch
                % SLDD�ɒ�`���Ă���f�[�^�^
                try
                    slddEntry = slddSection.getEntry(data_type);
                    slddValue = slddEntry.getValue;
                    try
                        slddBaseType = slddValue.BaseType;
                    catch
                        slddBaseType = slddValue.StorageType;
                    end
                    result_data_type = GetSimulinkDataType(slddBaseType, slddSection);
                catch
                    result_data_type = '�F���ł��Ȃ��f�[�^�^';
                end
            end
        end
    end
end
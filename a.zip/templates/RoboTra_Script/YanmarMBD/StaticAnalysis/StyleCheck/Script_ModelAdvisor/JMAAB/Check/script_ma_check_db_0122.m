%% Function Name�Fscript_ma_check_db_0122
%  Overview�F�udb_0122 �F Check for Strong Data Typing with Simulink I/O �v
%             Use Strong Data Typing with Simulink I/O parameter of chart
%             block need to check. If does not check, warning is occur
%  Parameters�F 
%        system(Selected hierarchy)
%        folder_output(Excel�t�@�C���ɏo�͂���p�X)
%  Return value:
%        result(Result display data)
%        error_block(GUI Data for displaying results)
%        result_info(Data for displaying results in the GUI)

function [ result, error_block, result_info ] = script_ma_check_db_0122(system, folder_output)

    gui_flag = 1;
    if nargin == 1       
        gui_flag = 0;
    else
        result = 0;
    end
    result_info = '';
    error_block = {};
    try
       if gui_flag == 0
           ma = Simulink.ModelAdvisor.getModelAdvisor(system);
       end
       
       try
           model_name = GetModelName(get_param(system, 'handle'));
       catch
           model_name = system;
       end
      %% Try to compile model for check model has error or not
        try
            if gui_flag == 0          
                evalin('base', [ model_name '([],[],[],''compile'')']);
                evalin('base', [ model_name '([],[],[],''term'')']); 
            else           
                evalin('base', [ model_name '([],[],[],''compile'')']);
                evalin('base', [ model_name '([],[],[],''term'')']); 
            end
        catch ex
            result_info = sprintf(['�R���p�C���G���[ \nCompile error \n' ex.message]);
            if gui_flag == 1
                result = 0;
            end
            return;
        end
        
       %% Check if object description in dictionary is empty or not 
        root = sfroot;
        model = root.find('Name', model_name, 'Parent', '');
        charts = model.find('-isa', 'Stateflow.Chart');
        %% �D �`���[�g���Ȃ��ꍇ�APass����Ԃ�
        if isempty(charts)
            if gui_flag == 0
                result = ModelAdvisor.Text('No charts in the model', {'pass'});
                ma.setCheckResultStatus(true);
                ma.setActionEnable(0);
            else
                result_info = 'No charts in the model';
                result = 1;
            end
           return;
        end
        
        error_block = {};     
        error_block{end+1,1}= 'Path';
        
        for i = 1: size(charts, 1)  
            if Check_ChartBlock_Commented(root, model_name, regexprep(charts(i).Path, ['/' charts(i).Name], ''), charts(i).Name) == 1
              continue;
            end
            if ~strcmp(charts(i).Path, system) 
              if isempty(regexp(charts(i).Path, ['^' system '/'], 'match'))
                  continue;
              end
            end
            %% Check each chart block
            if( ~charts(i).StrongDataTypingWithSimulink)
                error_block{end+1,1} = charts(i).Path;
            end
        end
        
    catch ex
       result_info = sprintf([ex.message ' .\nScript: script_ma_check_db_0122.\nLine: ' num2str(ex.stack(1).line)]);
       if gui_flag == 1
            result = 0;            
       else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
          ma.setActionEnable(0);
       end
       return;
    end
	
    %% Get output
    %    Pass case
    if size(error_block, 1) == 1
       if gui_flag == 1
            result = 1;
            result_info = 'Passed !!!';
       else
            result = ModelAdvisor.Text('Passed !!!', {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(0);
        end
        return;
    end
    %    Warning case: there is data description empty

    if gui_flag == 1
        result = 1;
        return;
    end
    %    Put result if app run with Model Advisor
    messages = [ModelAdvisor.Text('Following are chart blocks which does turn on use Strong Data Typing with Simulink I/O parameter'), ModelAdvisor.LineBreak];
    
    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(1);
    
    num = 0;
    cellfun(@(error_blocks) add_linked_message(error_blocks), error_block(2:end, 1));
    function add_linked_message(blk)
        num = num + 1;
        msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
        msg_path = ModelAdvisor.Text(char(blk));
        address = sprintf('matlab:hilite_block(''%s'')', blk);
        msg_path.setHyperlink(address);

        messages = [messages, ModelAdvisor.LineBreak, msg_num, msg_path];
    end   

    result = messages;
end
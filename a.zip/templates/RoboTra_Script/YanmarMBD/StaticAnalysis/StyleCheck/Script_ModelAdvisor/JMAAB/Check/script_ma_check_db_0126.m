%  Function Name :script_ma_check_db_0126
%  OverView : db_0126 : Prohibited of Stateflow Event
%    
%  Parameters:
%        system(Selected hierarchy)
%        folder_output(Excel Path to output to file)
%
%  Return value: 
%        result(Result display data)
%        error_block(GUI Data for displaying results)
%        result_info(Data for displaying results in the GUI)
%
%  Author: Mohan Mishra
%  Created date: 2019/3/12
%
function [ result, error_block,  result_info] = script_ma_check_db_0126(system, folder_output)
    %% 1. Declaring and Initializing the Variables
    counter =0;
    
    %% 2. Flag to call from GUI or model advisor, Initialize variable to return
    % gui_flag = 1 : Execute from GUI
    % gui_flag = 0 : Run from model advisor
    gui_flag = 1;
    if nargin == 1   
        gui_flag = 0;
    else
        result = 0;
    end
	% Initializing the error Structure
    result_info = '';
    
    try
        %% 3. When calling from the model advisor, obtain model advisor information
        if gui_flag == 0
            ma = Simulink.ModelAdvisor.getModelAdvisor(system);
        end
         %% 4. get Model name form System
        try
            model_name = GetModelName(system);
        catch
            model_name = system;
        end
              
        %% 4.Get handle to the root object 
        % Search the chart in the Model
        root = sfroot;
        model = root.find('Name', model_name, 'Parent', '');
        chart = model.find('-isa', 'Stateflow.Chart');
        
        % Initializing the error Block       
        error_block = {};
        error_block{end +1, 1}= 'Event Path'; 
        counter = 0;
        
        %Initializing the Table
        ft = ModelAdvisor.FormatTemplate('TableTemplate');
        ft.setColTitles({' Event Name ', '  Path  '});
        ft.setSubBar(0);
        
        %% 5. Analysing the Chart and Function inside the Model
        %check Model have chart 
        if (~isempty(chart))
            % Chart is Found in the Model
            for i = 1:numel(chart)
                % Check for the event in the Model
                event= chart(i).find('-isa','Stateflow.Event');
                 % Check for the event in the Chart
                if (~isempty(event))
                    %Event Found in the Model
                    for j = 1:numel(event)
                        counter = counter+1;
                        % Adding the Event Log
                        result = ModelAdvisor.Text('Event Found in the Model');
                        ft.addRow({event(j).name, event(j).path});
                        result =ft;
                    end
                end
            end
            %No Event is found in the Model. Throwing Pass Message to MA
            if (counter == 0)
                 if gui_flag == 0
                    result = ModelAdvisor.Text('No Event in Model', {'pass'});
                    ma.setCheckResultStatus(true);
                    ma.setActionEnable(0);
                 else
                    result_info = 'No Event in Model';
                    result = 1;
                 end
            end

        else
            % Model Have No Chart
            if gui_flag == 0
                result = ModelAdvisor.Text('No charts in the model', {'pass'});
                ma.setCheckResultStatus(true);
                ma.setActionEnable(0);
            else
                result_info = 'No charts in the model';
                result = 1;
            end
           return;
        end
        
    catch ex
        result_info = sprintf([ex.message ' .\nScript: script_ma_check_db_0126.\nLine: ' num2str(ex.stack(1).line)]);
        if gui_flag == 1
            result = 0;
        else
            result = ModelAdvisor.Text(result_info);
            ma.setCheckResultStatus(false);
            ma.setCheckErrorSeverity(1);
            ma.setActionEnable(0);
        end
        return;
    end
  
    if gui_flag == 1
        result = 1;
        return;
    end
    % If error block exist the adding link to Error Block
    if size(error_block, 1) > 1
        messages = [ModelAdvisor.Text('Event Found in the Model'), ModelAdvisor.LineBreak];
        ma.setCheckResultStatus(false);
        ma.setCheckErrorSeverity(0);
        ma.setActionEnable(1);
        num = 0;
        
        cellfun(@(error_blocks) add_linked_message(error_blocks), error_block(2:end, 1));   
       result = messages;
    end
    % Function to add the link
    function add_linked_message(blk)
    num = num + 1;

    msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
    msg_path = ModelAdvisor.Text(char(blk));
    address = sprintf('matlab:hilite_block(''%s'')', blk);
    msg_path.setHyperlink(address);

    messages = [messages, ModelAdvisor.LineBreak, ...
                msg_num, msg_path];
            result = messages;
    end      
end
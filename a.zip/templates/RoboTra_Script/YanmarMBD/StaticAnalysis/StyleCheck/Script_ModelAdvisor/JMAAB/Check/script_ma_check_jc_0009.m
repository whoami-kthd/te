%% �֐����Fscript_ma_check_jc_0009
%  �T�v�F�ujc_0009 �F �`�d�M���̕\���v
%         �M�������`�d����Ă���ꍇ�i���ɐM�������t���Ă���j�A�`�d�M���̕\����On�ɂ��āA�`�d���ꂽ�M������\�����܂��B
%       �@�`�d�M���̕\����On�ɂ��ĐM�����̕\�����s���̂́A�M�������قȂ�K�w�Œ�`���ꂽ�ꍇ�ł��B
%         �������A�ȉ��̃P�[�X�ł́A�K�w���܂����Ȃ��Ă��A�M�����̓`�d�\�����K�v�ł��B
%       �@?	�Ώۃu���b�N�F��ϊ����Z�����s�����{�u���b�N����o�͂����M��
%           �E	from 
%           �E	Bus Selector
%           �E	Signal Specification
%           �E	Function Call Split
%  �p�����[�^�F 
%        system(�I�������K�w)
%        folder_output(Excel�t�@�C���ɏo�͂���p�X)
%  �߂��l�F�@
%        result(���ʕ\���p�̃f�[�^)
%        error_block(GUI�Ō��ʕ\���p�̃f�[�^)
%        result_info(GUI�Ō��ʕ\���p�̃f�[�^)
%  �쐬�ҁF LOC
%  �쐬���F 2017/03/01
function [ result, error_block,  result_info] = script_ma_check_jc_0009(system, folder_output)
    %% �@ GUI���̓��f���A�h�o�C�U����Ăяo���t���O����A�Ԃ��ϐ��̏�����
    % gui_flag = 1�F GUI������s
    gui_flag = 1;
    if nargin == 1
        % gui_flag = 0�F ���f���A�h�o�C�U�[������s
        gui_flag = 0;
    else
        result = 0;
    end
    error_block = {};
    result_info = '';
    %% �A ���f���A�h�o�C�U����Ăяo���ꍇ�A���f���A�h�o�C�U�̏����擾����
    if gui_flag == 0
        ma = Simulink.ModelAdvisor.getModelAdvisor(system);
    end
    %% �B ���K�w�y�ъK�w�̉��̈ȉ��̃u���b�N�^�C�v������u���b�N�̌���
    %       Inport�AFrom�ASignalSpecification�AFunctionCallSplit�ASubSystem
    blocks = find_system(system, 'FindAll','on',...
                                 'LookUnderMasks', 'none',...
                                 'RegExp','on', ...
                                 'Type', 'block', ...
                                 'BlockType', '^Inport$|^From$|^SignalSpecification$|^FunctionCallSplit$');
    subsystem_handles = find_system(system, 'FindAll','on',...
                                                    'RegExp', 'on', ...
                                                    'LookUnderMasks', 'none',...
                                                    'Type', 'block', ...
                                                    'Mask', 'off', ...
                                                    'BlockType', 'SubSystem' );% AutonomusCrtl�ł�ModelReference�u���b�N����o��M���͋C�ɂ��Ȃ�����(2017/04/06 �⑺����Ɋm�F)
                                                    %'BlockType', 'SubSystem|ModelReference' );
                             
   %% �C �I�u�W�F�N�g���Ȃ��ꍇ�APass����Ԃ�	
   if isempty(blocks) && isempty(subsystem_handles)
       if gui_flag == 0
            result = ModelAdvisor.Text(sprintf('�Ώۃu���b�N��������܂��� \nTarget block not found'), {'pass'});
            ma.setCheckResultStatus(true);
       else
           result = 1;
           result_info = sprintf('�Ώۃu���b�N��������܂��� \nTarget block not found');
       end
       return;
   end
   %% �D ���f�����擾 
   try
        model_name = GetModelName(system);
   catch
        model_name = system;
   end
   error_block = {};
   error_block{end + 1, 1 } = 'Block Path';
   error_block{end, 2 } = 'Line Handle';
   try
       %% �E �B�Ŏ擾����Inport|From|SignalSpecification|FunctionCallSplit�u���b�N���ƃ`�F�b�N
        for i = 1: size(blocks, 1)
            %% �E (1) ���C���n���h���擾
            line_handle = get_param(blocks(i), 'LineHandles');
            block_type = get_param(blocks(i), 'BlockType');
            handle_in_out = line_handle.Outport;
            if handle_in_out < 0
                continue;
            end
            line_parent = get(handle_in_out, 'LineParent');
            if length(line_parent) > 1 || line_parent < 0
                line_parent = handle_in_out;
            end
            block_layer = get(blocks(i), 'Parent');
            parent_layer = get_param(block_layer, 'Parent');
           %% �E (2) Inport�̏ꍇ
            if strcmp(block_type, 'Inport')
               % �E (2.1) Top���C���ȊO�̏ꍇ�̂݃`�F�b�N���s��
               if ~isempty(parent_layer)
                   SignalPropagation = get(line_parent, 'SignalPropagation');
                   % �E (2.2) �M�������`�d���Ȃ��ꍇ�A�G���[���X�g�Ɋi�[
                   if strcmp(SignalPropagation, 'off')
                       set(line_parent, 'SignalPropagation', 'on');
                       signal_name = GetSignalName(line_parent);
                       set(line_parent, 'SignalPropagation', 'off');
                       if ~strcmp(signal_name, '<>') && (isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0)
                            error_block{end+1, 1} = MakePathBlock(blocks(i));
                            error_block{end, 2} = line_parent;                       
                       end
                   else
                       %SrcPortHandle = get(line_parent, 'SrcPortHandle');
                       %signal_name = get(SrcPortHandle, 'PropagatedSignals');
                       signal_name = GetSignalName(line_parent);
                       if strcmp(signal_name, '<>') && (isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0)
                            error_block{end+1, 1} = MakePathBlock(blocks(i));
                            error_block{end, 2} = line_parent;                       
                       else
                           signal_name = get(line_parent, 'Name');
                           if ~isempty(signal_name)
                               if isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0
                                    error_block{end+1, 1} = MakePathBlock(blocks(i));
                                    error_block{end, 2} = line_parent;                       
                               end
                           end
                       end
                   end
               end
          %% �E (3) Inport�ȊO�̏ꍇ
            else
                % �E (3.1) Function-Call Split�u���b�N�̏ꍇ
                if strcmp(block_type, 'FunctionCallSplit')
                    % �E (3.1.1) ���C���n���h�����X�g�`�F�b�N���J��Ԃ�
                    for j = 1: length(line_parent)
                        SignalPropagation = get(line_parent(j), 'SignalPropagation');
                        % �E (3.1.2) �M�������`�d���Ȃ��ꍇ�A�G���[���X�g�Ɋi�[  
                        if strcmp(SignalPropagation, 'off')
                            set(line_parent(j), 'SignalPropagation', 'on');
                            signal_name = GetSignalName(line_parent(j));
                            set(line_parent(j), 'SignalPropagation', 'off');
                            if ~strcmp(signal_name, '<>') && (isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0)
                                error_block{end+1, 1} = MakePathBlock(blocks(i));
                                error_block{end, 2} = line_parent(j);
                            end
                       else
%                            SrcPortHandle = get(line_parent(j), 'SrcPortHandle');
%                            signal_name = get(SrcPortHandle, 'PropagatedSignals');
%                            if isempty(signal_name)
%                                 if isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0
%                                     error_block{end+1, 1} = [ get(blocks(i), 'Path') '/' get(blocks(i), 'Name') ];
%                                     error_block{end, 2} = line_parent(j);                       
%                                 end
%                            end
                            signal_name = GetSignalName(line_parent(j));
                            if strcmp(signal_name, '<>') && (isempty(error_block) || CheckExisted(line_parent(j), error_block(1:end, 2)) == 0)
                                error_block{end+1, 1} = MakePathBlock(blocks(i));
                                error_block{end, 2} = line_parent(j);
                            else
                                signal_name = get(line_parent(j), 'Name');
                                if ~isempty(signal_name)
                                    if isempty(error_block) || CheckExisted(line_parent(j), error_block(1:end, 2)) == 0
                                        error_block{end+1, 1} = MakePathBlock(blocks(i));
                                        error_block{end, 2} = line_parent(j);
                                    end
                                end
                            end
                       end
                    end
                % �E (3.2) ���̑��u���b�N�̃`�F�b�N
                else
                    SignalPropagation = get(line_parent, 'SignalPropagation');
                    % �E (3.2.1) �M�������`�d���Ȃ��ꍇ�A�G���[���X�g�Ɋi�[  
                    if strcmp(SignalPropagation, 'off')
                        set(line_parent, 'SignalPropagation', 'on');
                        signal_name = GetSignalName(line_parent);
                        set(line_parent, 'SignalPropagation', 'off');
                        if ~strcmp(signal_name, '<>') && (isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0)
                            error_block{end+1, 1} = MakePathBlock(blocks(i));
                            error_block{end, 2} = line_parent;
                        end
                   else
%                        SrcPortHandle = get(line_parent, 'SrcPortHandle');
%                        signal_name = get(SrcPortHandle, 'PropagatedSignals');
%                        if isempty(signal_name)
%                             if isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0
%                                 error_block{end+1, 1} = [ get(blocks(i), 'Path') '/' get(blocks(i), 'Name') ];
%                                 error_block{end, 2} = line_parent;                       
%                             end
%                        end
                       signal_name = GetSignalName(line_parent);
                       if strcmp(signal_name, '<>') && (isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0)
                            error_block{end+1, 1} = MakePathBlock(blocks(i));
                            error_block{end, 2} = line_parent;                       
                       else
                            signal_name = get(line_parent, 'Name');
                            if ~isempty(signal_name)
                                if isempty(error_block) || CheckExisted(line_parent, error_block(1:end, 2)) == 0
                                    error_block{end+1, 1} = MakePathBlock(blocks(i));
                                    error_block{end, 2} = line_parent;
                                end
                            end
                       end
                   end
                end
            end
        end
       if ~isempty(subsystem_handles)
           %% �F �B�Ŏ擾����Subsystem�u���b�N���ƃ`�F�b�N
            rt_error_block = CheckSignalNameSubAndChartBlock(1, subsystem_handles, system, model_name, error_block);
            error_block = rt_error_block;
       end
       % Chart/TruhTable�u���b�N�̏ꍇ
       %blocks = FindChart_TruthTable(system);
       blocks = [];
       if ~isempty(blocks)
            rt_error_block = CheckSignalNameSubAndChartBlock(0, blocks, system, model_name, error_block);
            error_block = rt_error_block;
       end
      %% �G GUI����Ăт����̏ꍇ�F
       %�t�H���_�p�X��n���ꍇ�AExcel�ɃG���[�u���b�N�����o��
       %(�����_��GUI����󔒂�n��)
       if gui_flag == 1
          % Excel�Ɍ��ʂ��o�͂���
          if ~isempty(folder_output)
              outpath = [folder_output '/jc_0008_CheckResult' ];
              try
                  xlswrite([outpath '.xlsx'], error_block);
              catch
                  xlswrite([ outpath '_' datestr(now, 'yyyyMMdd_HHmmss') '.xlsx'], error_block);
              end
          end
       end
   catch ex
       result_info = sprintf([ex.message ' .\nScript: script_ma_check_jc_0009.\nLine: ' num2str(ex.stack(1).line)]);
       if gui_flag == 1
           result = 0;
      else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
      end
       return;
   end
   %% �H ���ʏo��
   %     �H (1) �G���[���Ȃ��ꍇ�F
   %            Pass����Ԃ�
   if size(error_block, 1) == 1
       if gui_flag == 0
            result = ModelAdvisor.Text(sprintf('�S�M�������K�؂ɐݒ肳��Ă��܂� \nAll signal name are set properly'), {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(false);
       else
           result = 1;
           result_info = sprintf('�S�M�������K�؂ɐݒ肳��Ă��܂� \nAll signal name are set properly');
       end
        return;
   end
   %     �H (2) �G���[������ꍇ�F
   %         �H (2.1)GUI����Ăяo���ꍇ�A
   %                 GUI�ɖ߂��A���ʏo�͏���GUI�ŏ�������
   if gui_flag == 1
        result = 1;
        return;
   end
   %         �H (2.2�j���f���A�h�o�C�U����Ăяo���ꍇ�A    
   %                  ���f���A�h�o�C�U�ɏo�͏����쐬����
    messages = [ModelAdvisor.Text(sprintf('�ȉ��̐M�����͓`�d���ݒ肳��Ă��܂��� \nFollowing is the list of signal names which does not set propagation')), ...
                ModelAdvisor.LineBreak ...
                ModelAdvisor.Text(sprintf('���`�d�M���Ɠo�^�M���������ɑ��݂���ꍇ��NG�Ƃ��Ă��� \nIf the propagation signal and the registration signal exist at the same time, it is NG')), ...
                ModelAdvisor.LineBreak];

    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(true);
    
    num = 0;
    cellfun(@(error_blocks, error_block_handles) add_linked_message(error_blocks, error_block_handles), ...
               error_block(2:end, 1), error_block(2:end, 2));
    function add_linked_message(blk, blk_handle)
        num = num + 1;

        msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
        msg_path = ModelAdvisor.Text(char(blk));
        address = sprintf('matlab:hilite_block(%10.30f)', blk_handle);
        msg_path.setHyperlink(address);

        messages = [messages, ModelAdvisor.LineBreak, ...
                    msg_num, msg_path];
    end    

    result = messages;
end

%% �F �T�u�V�X�e���u���b�N����o��M���̃`�F�b�N
function rt_error_block = CheckSignalNameSubAndChartBlock(isSubSystem, blocks, system, model_name, error_block)
    rt_error_block = error_block;
    if isSubSystem == 0
        blocks = FindChart_TruthTable(system);
        blocks = blocks';
    end
    for i = 1: size(blocks, 1)
       %% �F (1) �T�u�V�X�e���̏ꍇ
        if isSubSystem == 1
            try
                % Chart�̏ꍇ
                if strcmp(get(blocks(i),'ErrorFcn'), 'Stateflow.Translate.translate')
                    continue;
                end
            catch
            end
            if isempty(regexp(get(blocks(i),'Path'), system, 'match'))
                continue;
            end
            % �F (1.1) ���C�u�����u���b�N�͑ΏۊO
            if ~isempty(get(blocks(i),'ReferenceBlock'))
                continue;
            end
            sl_block = blocks(i);
            % �F (1.2) ���C���n���h���擾
            lineHandles = get_param(blocks(i), 'LineHandles');
%            block_type = get_param(blocks(i), 'BlockType');
%             is_load_system = 0;
%             ModelReference_Handle = [];
%             if strcmp(block_type, 'ModelReference')
%                 ModelName = get_param(blocks(i), 'ModelName');
%                 try
%                     ModelReference_Handle = get_param(ModelName, 'handle');
%                     if isempty(ModelReference_Handle)
%                         try
%                             ModelReference_Handle = load_system(Model_Name);
%                             is_load_system = 1;
%                         catch
%                             continue;
%                         end
%                     end
%                 catch
%                     try
%                         ModelReference_Handle = load_system(ModelName);
%                         is_load_system = 1;
%                     catch
%                         continue;
%                     end
%                 end
%             end
       %% �F (2) �`���[�g�̏ꍇ�F
        else
%             is_load_system = 0;
%             ModelReference_Handle = [];
            block_name = blocks{i}.Name;
            sl_block = find_system(model_name,'FindAll', 'on', 'Parent', regexprep(blocks{i}.Path, ['/' blocks{i}.Name '$'], ''), ...
                                               'Name', blocks{i}.Name);

            lineHandles = get_param(sl_block, 'LineHandles');
        end
        if isempty(lineHandles)
            continue;
        end
        %% �F (1.2.1) �C���|�[�g�̃��C���n���h�̃`�F�b�N
        if ~isempty(lineHandles.Inport)
            for j = 1: length(lineHandles.Inport)
                if isempty(lineHandles.Inport(j)) || lineHandles.Inport(j) < 0
                    continue;
                end
                line_parent = -1;
                if lineHandles.Inport(j) > 0
                    line_parent = GetParentLine(lineHandles.Inport(j));
                end
                if line_parent < 0
                    continue;
                end
                SrcBlockHandle = get(line_parent, 'SrcBlockHandle');
                SignalPropagation = get(line_parent, 'SignalPropagation');
                if ishandle(SrcBlockHandle) && ...
                   (strcmp(get(SrcBlockHandle, 'BlockType'), 'SubSystem') && strcmp(get(SrcBlockHandle, 'Mask'), 'off'))
                   % �F (1.2.1.1) ���C�u�����u���b�N�͑ΏۊO�A�`���[�g�u���b�N
                   if ~isempty(get(SrcBlockHandle, 'ReferenceBlock')) || IsChartBlock(SrcBlockHandle)
                       continue;
                   end
                   % �E (3.2.1) �M�������`�d���Ȃ��ꍇ�A�G���[���X�g�Ɋi�[
                   if strcmp(SignalPropagation, 'off')
                       set(line_parent, 'SignalPropagation', 'on');
                       signal_name = GetSignalName(line_parent);
                       set(line_parent, 'SignalPropagation', 'off');
                       if (~strcmp(signal_name, '<>') || ...
                           ~isempty(get(line_parent, 'Name'))) ...
                           && (isempty(rt_error_block) || CheckExisted(line_parent, rt_error_block(1:end, 2)) == 0)
                           if isSubSystem == 1
                               rt_error_block{end+1, 1} = MakePathBlock(blocks(i));
                               rt_error_block{end, 2} = line_parent;
                           else
                               rt_error_block{end+1, 1} = blocks{i}.Path;
                               rt_error_block{end, 2} = line_parent;
                           end
                       end
                   else
                       signal_name = GetSignalName(line_parent);
                       if strcmp(signal_name, '<>') && (isempty(rt_error_block) || CheckExisted(line_parent, rt_error_block(1:end, 2)) == 0)
                           if isSubSystem == 1
                               rt_error_block{end+1, 1} = MakePathBlock(blocks(i));
                               rt_error_block{end, 2} = line_parent;
                           else
                               rt_error_block{end+1, 1} = blocks{i}.Path;
                               rt_error_block{end, 2} = line_parent;
                           end
                       else
                           signal_name = get(line_parent, 'Name');
                           if ~isempty(signal_name)
                               if isempty(rt_error_block) || CheckExisted(line_parent, rt_error_block(1:end, 2)) == 0
                                   if isSubSystem == 1
                                       rt_error_block{end+1, 1} = MakePathBlock(blocks(i));
                                       rt_error_block{end, 2} = line_parent;
                                   else
                                       rt_error_block{end+1, 1} = blocks{i}.Path;
                                       rt_error_block{end, 2} = line_parent;
                                   end
                               end
                           end
                       end
                   end
                end
            end
        end
        %% �F (1.2.2) �A�E�g�|�[�g�̃��C���n���h�̃`�F�b�N
        if ~isempty(lineHandles.Outport)
            for j = 1: length(lineHandles.Outport)
                if isempty(lineHandles.Outport(j)) || lineHandles.Outport(j) < 0
                    continue;
                end
                if lineHandles.Outport(j) > 0
                    line_parent = GetParentLine(lineHandles.Outport(j));
                end
                if line_parent < 0
                    continue;
                end
                SignalPropagation = get(line_parent, 'SignalPropagation');
                % �E (3.2.1) �M�������`�d���Ȃ��ꍇ�A�G���[���X�g�Ɋi�[
                if strcmp(SignalPropagation, 'off')
                    set(line_parent, 'SignalPropagation', 'on');
                    signal_name = GetSignalName(line_parent);
                    set(line_parent, 'SignalPropagation', 'off');
                    if (~strcmp(signal_name, '<>') || ...
                            ~isempty(get(line_parent, 'Name'))) ...
                            && (isempty(rt_error_block) || CheckExisted(line_parent, rt_error_block(1:end, 2)) == 0)
                        if isSubSystem == 1
                            rt_error_block{end+1, 1} = MakePathBlock(blocks(i));
                            rt_error_block{end, 2} = line_parent;
                        else
                            rt_error_block{end+1, 1} = blocks{i}.Path;
                            rt_error_block{end, 2} = line_parent;
                        end
                    end
                else
                    signal_name = GetSignalName(line_parent);
                    if strcmp(signal_name, '<>') && (isempty(rt_error_block) || CheckExisted(line_parent, rt_error_block(1:end, 2)) == 0)
                        if isSubSystem == 1
                            rt_error_block{end+1, 1} = MakePathBlock(blocks(i));
                            rt_error_block{end, 2} = line_parent;
                        else
                            rt_error_block{end+1, 1} = blocks{i}.Path;
                            rt_error_block{end, 2} = line_parent;
                        end
                    else
                        signal_name = get(line_parent, 'Name');
                        if ~isempty(signal_name)
                            if isempty(rt_error_block) || CheckExisted(line_parent, rt_error_block(1:end, 2)) == 0
                                if isSubSystem == 1
                                    rt_error_block{end+1, 1} = MakePathBlock(blocks(i));
                                    rt_error_block{end, 2} = line_parent;
                                else
                                    rt_error_block{end+1, 1} = blocks{i}.Path;
                                    rt_error_block{end, 2} = line_parent;
                                end
                            end
                        end
                    end
                end
            end
        end
%         if is_load_system == 1
%             try
%                 close_system(ModelReference_Handle);
%             catch
%                 continue;
%             end
%         end
    end
end

function blocks = FindChart_TruthTable(system)
    rt = sfroot;
    model_name = GetModelName(system);
    model = rt.find('Name', model_name, 'Parent', '');
    charts = model.find('-isa', 'Stateflow.Chart');
    blocks = {};
    for i = 1: size(charts, 1)
        if Check_ChartBlock_Commented(rt, model_name, regexprep(charts(i).Path, ['/' charts(i).Name '$'], ''), charts(i).Name) == 1
          continue;
        end
        if isempty(regexp(regexprep(charts(i).Path, ['/' charts(i).Name '$'], ''), system, 'match'))
          continue;
        end
        blocks{end+1} = charts(i);
    end  
    truthtables = model.find('-isa', 'Stateflow.TruthTableChart');
    for i = 1: size(truthtables, 1)
        if Check_ChartBlock_Commented(rt, model_name, regexprep(truthtables(i).Path, ['/' truthtables(i).Name '$'], ''), truthtables(i).Name) == 1
           continue;
        end
        if isempty(regexp(regexprep(truthtables(i).Path, ['/' truthtables(i).Name '$'], ''), system, 'match'))
           continue;
        end
        blocks{end+1} = truthtables(i);
    end  
end

function result = CheckExisted(value, arrayCheck)
    result = 0;
    for i = 1: length(arrayCheck)
        if iscell(arrayCheck(i))
            checkValue = cell2mat(arrayCheck(i));
        else
            checkValue = arrayCheck(i);
        end
        if value == checkValue
            result = 1;
            return;
        end
    end
end
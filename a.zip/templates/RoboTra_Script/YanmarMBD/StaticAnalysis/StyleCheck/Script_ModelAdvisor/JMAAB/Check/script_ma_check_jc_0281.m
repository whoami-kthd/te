%% �֐����Fscript_ma_check_jc_0281

function [ result, error_block,  result_info] = script_ma_check_jc_0281(system, folder_output)
    %% �@ GUI���̓��f���A�h�o�C�U����Ăяo���t���O����A�Ԃ��ϐ��̏�����
    % gui_flag = 1�F GUI������s
    gui_flag = 1;
    if nargin == 1
        gui_flag = 0;
    else
        result = 0;
    end
    error_block = {};
    result_info = '';
    
    try
        if gui_flag == 0
            ma = Simulink.ModelAdvisor.getModelAdvisor(system);
        end
    
       try
           model_name = GetModelName(get_param(system, 'handle'));
       catch
           model_name = system;
       end
       
      %% Try to compile model for check model has error or not
        try
            if gui_flag == 0          
                evalin('base', [ model_name '([],[],[],''compile'')']);
                evalin('base', [ model_name '([],[],[],''term'')']); 
            else           
                evalin('base', [ model_name '([],[],[],''compile'')']);
                evalin('base', [ model_name '([],[],[],''term'')']); 
            end
        catch ex
            result_info = sprintf(['�R���p�C���G���[ \nCompile error \n' ex.message]);
            if gui_flag == 1
                result = 0;
            end
            return;
        end
    
        %% Check if model contains trigger, chart blocks or not
        trigger_blocks = find_system(system, 'FindAll','on',...
                                     'LookUnderMasks', 'none',...
                                     'RegExp','on', ...
                                     'Type', 'block', ...
                                     'BlockType', '^TriggerPort$');

        S = sfroot; 
        events = S.find('-isa','Stateflow.Event');

       if isempty(trigger_blocks) && isempty(events)
           if gui_flag == 0
                result = ModelAdvisor.Text('There is no trigger and chart blocks', {'pass'});
                ma.setCheckResultStatus(true);
           else
               result = 1;
               result_info = 'There is no trigger and chart blocks';
           end
           return;
       end

        error_block                 = {};
        error_block{end + 1, 1 }    = 'Block Path';
        error_block{end, 2 }        = 'Line Handle';

        %% Trigger block
        if ~isempty(trigger_blocks)
            for i = 1: size(trigger_blocks, 1)
                % Get information from trigger blocks 
                trigger_type        = get_param(trigger_blocks(i), 'TriggerType');
                trigger_Name        = get_param(trigger_blocks(i), 'Name');

                block_layer         = get(trigger_blocks(i), 'Parent');
                line_handle         = get_param(block_layer, 'LineHandles');
                line_trigger        = line_handle.Trigger;
                line_trigger_name   = GetSignalName(line_trigger);
                block_input_handle  = get(line_trigger, 'SrcBlockHandle');
                block_input_name    = getfullname(block_input_handle);

                % Get name only
                tmp                     = strsplit(block_layer,'/');
                block_layer_name_only   = tmp{end};
                tmp                     = strsplit(block_input_name,'/');
                block_input_name_only   = tmp{end};

                % Check if name of input block as same as trigger name or not
                if (strcmp(trigger_type, 'function-call'))
                    if(strcmp(get_param(block_input_name, 'BlockType') , 'Inport'))
                        if(~strcmp(block_input_name_only,  trigger_Name))
                            error_block{end+1, 1}   = MakePathBlock(trigger_blocks(i));
                            error_block{end, 2}     = line_trigger;
                        end
                    end

                    % Check if name of input block and name of parent's trigger
                    % block has common part of the string
                    %common_to_use = intersect(strsplit(block_layer_name_only),strsplit(block_input_name_only),'stable');
                    if ~find_common(block_layer_name_only, block_input_name_only)
                        error_block{end+1, 1}   = MakePathBlock(trigger_blocks(i));
                        error_block{end, 2}     = line_trigger;
                    end
                    
                    % Check if line signal name and trigger_name has common part of string
                    if isempty(line_trigger_name)
                        error_block{end+1, 1}   = MakePathBlock(trigger_blocks(i));
                        error_block{end, 2}     = line_trigger;
                    else
                        %common_to_use = intersect(strsplit(trigger_Name),strsplit(line_trigger_name),'stable');
                        if ~find_common(trigger_Name, line_trigger_name)
                            error_block{end+1, 1}   = MakePathBlock(trigger_blocks(i));
                            error_block{end, 2}     = line_trigger;
                        end
                    end

                else
                    if isempty(line_trigger_name)
                        error_block{end+1, 1}   = MakePathBlock(trigger_blocks(i));
                        error_block{end, 2}     = line_trigger;
                    else
                        %common_to_use = intersect(strsplit(block_layer_name_only),strsplit(line_trigger_name),'stable');
                        if ~find_common(block_layer_name_only, line_trigger_name)
                            error_block{end+1, 1}   = MakePathBlock(trigger_blocks(i));
                            error_block{end, 2}     = line_trigger;
                        end
                    end
                end
           end
        end

       %% Chart block
        if ~isempty(events)
           for i = 1: size(events, 1)
                events_Name         = events(i).Name;
                events_Scope        = events(i).Scope;
                line_handle         = get_param(events(i).Path, 'LineHandles');
                line_trigger        = line_handle.Trigger;
                line_trigger_name   = GetSignalName(line_trigger);
                block_input_handle  = get(line_trigger, 'SrcBlockHandle');
                block_input_name    = getfullname(block_input_handle);
                
                % Get name only
                tmp                     = strsplit(events(i).Path,'/');
                block_layer_name_only   = tmp{end};
                tmp                     = strsplit(block_input_name,'/');
                block_input_name_only   = tmp{end};
                
                % Check if name of input block as same as trigger name or not
                if (strcmp(trigger_type, 'function-call'))
                    if(strcmp(get_param(block_input_name, 'BlockType') , 'Inport'))
                        if(~strcmp(block_input_name_only,  events_Name))
                            error_block{end+1, 1}   = MakePathBlock(events(i).Path);
                            error_block{end, 2}     = line_trigger;
                        end
                    end

                    % Check if name of input block and name of parent's trigger
                    % block has common part of the string
                    %common_to_use = intersect(strsplit(block_layer_name_only),strsplit(block_input_name_only),'stable');
                    if ~find_common(block_layer_name_only, block_input_name_only)
                        error_block{end+1, 1}   = MakePathBlock(events(i).Path);
                        error_block{end, 2}     = line_trigger;
                    end
                    
                    % Check if line signal name and trigger_name has common part of string
                    if isempty(line_trigger_name)
                        error_block{end+1, 1}   = MakePathBlock(events(i).Path);
                        error_block{end, 2}     = line_trigger;
                    else
                        %common_to_use = intersect(strsplit(events_Name),strsplit(line_trigger_name),'stable');
                        if ~find_common(events_Name, line_trigger_name)
                            error_block{end+1, 1}   = MakePathBlock(events(i).Path);
                            error_block{end, 2}     = line_trigger;
                        end
                    end                    
                else
                    if isempty(line_trigger_name)
                        error_block{end+1, 1}   = MakePathBlock(events(i).Path);
                        error_block{end, 2}     = line_trigger;
                    else
                        %common_to_use = intersect(strsplit(block_layer_name_only),strsplit(line_trigger_name),'stable');
                        if ~find_common(block_layer_name_only, line_trigger_name)
                            error_block{end+1, 1}   = MakePathBlock(events(i).Path);
                            error_block{end, 2}     = line_trigger;
                        end
                    end
                end
           end
        end
       
      %% �F GUI����Ăт����̏ꍇ�F
       % �t�H���_�p�X��n���ꍇ�AExcel�ɃG���[�u���b�N�����o��
       % (�����_��GUI����󔒂�n��)
       if gui_flag == 1
          % Excel�Ɍ��ʂ��o�͂���
          if ~isempty(folder_output)
              outpath = [folder_output '/jc_0281_CheckResult' ];
              try
                  xlswrite([outpath '.xlsx'], error_block);
              catch
                  xlswrite([ outpath '_' datestr(now, 'yyyyMMdd_HHmmss') '.xlsx'], error_block);
              end
          end
       end
   catch ex
       result_info = sprintf([ex.message ' .\nScript: script_ma_check_jc_0281.\nLine: ' num2str(ex.stack(1).line)]);
       if gui_flag == 1
           result = 0;
      else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
      end
       return;
   end
   %% �G ���ʏo��
    %    �G (1)�G���[���Ȃ��ꍇ�F
    %           Pass����Ԃ�
   if size(error_block, 1) == 1
       if gui_flag == 0
            result = ModelAdvisor.Text(sprintf('�S�M�������K�؂ɐݒ肳��Ă��܂� \nAll of signal name are set properly'), {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(false);
       else
           result = 1;
           result_info = sprintf('�S�M�������K�؂ɐݒ肳��Ă��܂� \nAll of signal name are set properly');
       end
        return;
   end
   %    �G (2) �G���[������ꍇ�F
   %      �G (2.1�jGUI����Ăяo���ꍇ�A
   %               GUI�ɖ߂��A���ʏo�͏���GUI�ŏ�������
   if gui_flag == 1
       result = 1;
       return;
   end
   
    %     �G (2.2) ���f���A�h�o�C�U����Ăяo���ꍇ�A    
    %              ���f���A�h�o�C�U�ɏo�͏����쐬����
    messages = [ModelAdvisor.Text('�ȉ��̐M�����͒�`���ݒ肳��Ă��܂���'), ...
                ModelAdvisor.LineBreak, ...
                ModelAdvisor.Text('Following is the list of signal name which does not set properly'), ...
                ModelAdvisor.LineBreak];

    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(true);
    
    num = 0;
    cellfun(@(error_blocks, error_block_handles) add_linked_message(error_blocks, error_block_handles), ...
               error_block(2:end, 1), error_block(2:end, 2));
    function add_linked_message(blk, blk_handle)
        num = num + 1;

        msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
        msg_path = ModelAdvisor.Text(char(blk));
        address = sprintf('matlab:hilite_block(%10.30f)', blk_handle);
        msg_path.setHyperlink(address);

        messages = [messages, ModelAdvisor.LineBreak, ...
                    msg_num, msg_path];
    end    

    result = messages;
end

function is_has_common = find_common(str1, str2)
    is_has_common = 0;
    w1 = regexp(str1,'\S+','match');
    w2 = regexp(str2,'\S+','match');
    tmp = intersect(w1,w2);
    tmp1 = contains(str1,str2);
    tmp2 = contains(str2,str1);
    if ~isempty(tmp) || tmp1  || tmp2
        is_has_common = 1;
    end
end
%% �֐����Fscript_ma_check_jc_0640

function [ result, error_block,  result_info] = script_ma_check_jc_0640(system, folder_output)
    %% �@ GUI���̓��f���A�h�o�C�U����Ăяo���t���O����A�Ԃ��ϐ��̏�����
    % gui_flag = 1�F GUI������s
    gui_flag = 1;
    if nargin == 1
        gui_flag = 0;
    else
        result = 0;
    end
    error_block = {};
    result_info = '';
    
    if gui_flag == 0
        ma = Simulink.ModelAdvisor.getModelAdvisor(system);
    end
    
    subsystem_blocks = find_system(system, 'FindAll','on',...
                                 'LookUnderMasks', 'none',...
                                 'RegExp','on', ...
                                 'Type', 'block', ...
                                 'BlockType', '^SubSystem$');

    merge_blocks = find_system(system, 'FindAll','on',...
                                 'LookUnderMasks', 'none',...
                                 'RegExp','on', ...
                                 'Type', 'block', ...
                                 'BlockType', '^Merge$');
 
   if isempty(subsystem_blocks) && isempty(merge_blocks)
       if gui_flag == 0
            result = ModelAdvisor.Text('There is no subsystem block and merge blocks', {'pass'});
            ma.setCheckResultStatus(true);
       else
           result = 1;
           result_info = 'There is no subsystem block and merge blocks';
       end
       return;
   end
   %% �D ���f�����擾
   try
       try
            model_name = GetModelName(system);
       catch
            model_name = system;
       end
   catch
   end
   try
        %% �E �B�Ŏ擾�����I�u�W�F�N�g�̐ڑ����Ă��郉�C���ɐM������o�^���Ă��邩�`�F�b�N
        error_block                 = {};
        error_block{end + 1, 1 }    = 'Block Path';
        error_block{end, 2 }        = 'Block Handle';

        %% Subsystem block
        if ~isempty(subsystem_blocks)
            for i = 1: size(subsystem_blocks, 1)
                % Get information from subsystem blocks
                % Check if this subsystem is conditional subsystem or not
                % Conditional subsystem are:
                %                           - Enable subsystem
                %                           - Triggered subsystem
                %                           - Function-call subsystem
                %                           - Triggered and Enabled subsystem
                %                           - If/else subsystem
                %                           - Switch/case subsystem
                ports = get_param(subsystem_blocks(i),'PortHandles'); 
                conditional = ~isempty(ports.Enable) || ~isempty(ports.Trigger) || ~isempty(ports.Ifaction) || ~isempty(ports.Reset);
                if (conditional)
                    outport_blocks = find_system(subsystem_blocks(i), 'FindAll','on',...
                             'LookUnderMasks', 'none',...
                             'RegExp','on', ...
                             'Type', 'block', ...
                             'BlockType', '^Outport$');
                    
                    for outport_cnt=1:size(outport_blocks, 1)
                        if strcmp(get_param(outport_blocks(outport_cnt), 'InitialOutput'), '[]')
                            error_block{end+1, 1}   = MakePathBlock(outport_blocks(outport_cnt));
                            error_block{end, 2}     = outport_blocks(outport_cnt);
                        end
                    end
                end
            end
        end

       %% Merge blocks
        if ~isempty(merge_blocks)
           for i = 1: size(merge_blocks, 1)
                if strcmp(get_param(merge_blocks(i), 'InitialOutput'), '[]')
                    error_block{end+1, 1}   = MakePathBlock(merge_blocks(i));
                    error_block{end, 2}     = merge_blocks(i);
                end
           end
        end
       
      %% �F GUI����Ăт����̏ꍇ�F
       % �t�H���_�p�X��n���ꍇ�AExcel�ɃG���[�u���b�N�����o��
       % (�����_��GUI����󔒂�n��)
       if gui_flag == 1
          % Excel�Ɍ��ʂ��o�͂���
          if ~isempty(folder_output)
              outpath = [folder_output '/jc_0640_CheckResult' ];
              try
                  xlswrite([outpath '.xlsx'], error_block);
              catch
                  xlswrite([ outpath '_' datestr(now, 'yyyyMMdd_HHmmss') '.xlsx'], error_block);
              end
          end
       end
   catch ex
       result_info = sprintf([ex.message ' .\nScript: script_ma_check_jc_0640.\nLine: ' num2str(ex.stack(1).line)]);
       if gui_flag == 1
           result = 0;
      else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
      end
       return;
   end
   %% �G ���ʏo��
    %    �G (1)�G���[���Ȃ��ꍇ�F
    %           Pass����Ԃ�
   if size(error_block, 1) == 1
       if gui_flag == 0
            result = ModelAdvisor.Text(sprintf('�S�M�������K�؂ɐݒ肳��Ă��܂� \nAll signal names are set properly'), {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(false);
       else
           result = 1;
           result_info = sprintf('�S�M�������K�؂ɐݒ肳��Ă��܂� \nAll signal names are set properly');
       end
        return;
   end
   %    �G (2) �G���[������ꍇ�F
   %      �G (2.1�jGUI����Ăяo���ꍇ�A
   %               GUI�ɖ߂��A���ʏo�͏���GUI�ŏ�������
   if gui_flag == 1
       result = 1;
       return;
   end
   
    %     �G (2.2) ���f���A�h�o�C�U����Ăяo���ꍇ�A    
    %              ���f���A�h�o�C�U�ɏo�͏����쐬����
    messages = [ModelAdvisor.Text('�ȉ��̐M�����͒�`���ݒ肳��Ă��܂���'), ...
                ModelAdvisor.LineBreak, ...
                ModelAdvisor.Text('Following is the list of signal name which does not set properly'), ...
                ModelAdvisor.LineBreak];

    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(true);
    
    num = 0;
    cellfun(@(error_blocks, error_block_handles) add_linked_message(error_blocks, error_block_handles), ...
               error_block(2:end, 1), error_block(2:end, 2));
    function add_linked_message(blk, blk_handle)
        num = num + 1;

        msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
        msg_path = ModelAdvisor.Text(char(blk));
        address = sprintf('matlab:hilite_block(%10.30f)', blk_handle);
        msg_path.setHyperlink(address);

        messages = [messages, ModelAdvisor.LineBreak, ...
                    msg_num, msg_path];
    end    

    result = messages;
end
%% Function Name�Fscript_ma_check_jc_0723
%  Overview�F�ujc_0723 �F Prohibit direct transition from external state to child state�v
%             The cases are OK :  - Transition from parent state to parent state
%                                 - Transition from a child state to another parent state
%             The cases are NG :  - Transitioning directly from an external state to a child state within the state.
%                                 - There is a direct transition from a child state of the external state to a child state within the state.
%
%  Parameters�F 
%        system(Selected hierarchy)
%        folder_output(Excel�t�@�C���ɏo�͂���p�X)
%  Return value:
%        result(Result display data)
%        error_block(GUI Data for displaying results)
%        result_info(Data for displaying results in the GUI)

function [ result, error_block, result_info ] = script_ma_check_jc_0723(system, folder_output)

    gui_flag = 1;
    if nargin == 1       
        gui_flag = 0;
    else
        result = 0;
    end
    result_info = '';
    error_block = {};
    
    try
       if gui_flag == 0
           ma = Simulink.ModelAdvisor.getModelAdvisor(system);
       end
       
       try
           model_name = GetModelName(get_param(system, 'handle'));
       catch
           model_name = system;
       end
      %% Try to compile model for check model has error or not
        try
            if gui_flag == 0          
                evalin('base', [ model_name '([],[],[],''compile'')']);
                evalin('base', [ model_name '([],[],[],''term'')']); 
            else           
                evalin('base', [ model_name '([],[],[],''compile'')']);
                evalin('base', [ model_name '([],[],[],''term'')']); 
            end
        catch ex
            result_info = sprintf(['�R���p�C���G���[ \nCompile error \n' ex.message]);
            if gui_flag == 1
                result = 0;
            end
            return;
        end
        
       %% Check if object description in dictionary is empty or not 
        root = sfroot;
        model = root.find('Name', model_name, 'Parent', '');
        charts = model.find('-isa', 'Stateflow.Chart');
        %% �D �`���[�g���Ȃ��ꍇ�APass����Ԃ�
        if isempty(charts)
            if gui_flag == 0
                result = ModelAdvisor.Text('No charts in the model', {'pass'});
                ma.setCheckResultStatus(true);
                ma.setActionEnable(0);
            else
                result_info = 'No charts in the model';
                result = 1;
            end
           return;
        end
        
        error_block = {};
        error_block_tmp1 = {};
        error_block_tmp2 = {};
        error_block_tmp3 = {};
        error_block_tmp4 = {};
        error_block_tmp1{end + 1, 1}= 'Name'; 
        error_block_tmp2{end + 1, 1}= 'Source -> Destination';
        error_block_tmp3{end + 1, 1}= 'Path';
        error_block_tmp4{end + 1, 1}= 'SSID';
        
        for i = 1: size(charts, 1)  
            if Check_ChartBlock_Commented(root, model_name, regexprep(charts(i).Path, ['/' charts(i).Name], ''), charts(i).Name) == 1
              continue;
            end
            if ~strcmp(charts(i).Path, system) 
              if isempty(regexp(charts(i).Path, ['^' system '/'], 'match'))
                  continue;
              end
            end
            %% Lists of transition lines in the model
            lines = charts(i).find('-isa','Stateflow.Transition','IsCommented', 0);
            % Check 
            % states which do not have a source

            % Transitions which do not have a destination
            for j = 1:length(lines)
                    Destination_state = lines(j).Destination;
                    Source_state = lines(j).Source;
                    if isempty(Source_state) || isempty(Destination_state) 
                        continue;
                    else
                        % Step for check as: 
                        %   Check destination state is substate, then check parent of source state is state or not
                        %   If parent of source state is state, check it's name as same as parent of destination state or not
                        %
                        if(isSubstate(Destination_state))
                            if(strcmp(class(Source_state.getParent), 'Stateflow.State'))
                                if(~strcmp(Source_state.getParent.LabelString, Destination_state.getParent.LabelString))
                                    error_block_tmp1{end+1,1} = lines(j).LabelString;
                                    error_block_tmp2{end+1,1} = [Source_state.LabelString ' -> ' Destination_state.LabelString];
                                    error_block_tmp3{end+1,1} = lines(j).Path;
                                    error_block_tmp4{end+1,1} = lines(j).SSIdNumber;
                                end
                            else
                                error_block_tmp1{end+1,1} = lines(j).LabelString;
                                error_block_tmp2{end+1,1} = [Source_state.LabelString ' -> ' Destination_state.LabelString];
                                error_block_tmp3{end+1,1} = lines(j).Path;
                                error_block_tmp4{end+1,1} = lines(j).SSIdNumber;
                            end
                        end
                    end
            end 

        end 
        
        error_block = horzcat(error_block_tmp1, error_block_tmp2, error_block_tmp3, error_block_tmp4);
        
    catch ex
       result_info = sprintf([ex.message ' .\nScript: script_ma_check_jc_0723.\nLine: ' num2str(ex.stack(1).line)]);
       if gui_flag == 1
            result = 0;            
       else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
          ma.setActionEnable(0);
       end
       return;
    end
	
    %% Get output
    %    Pass case
    if size(error_block, 1) == 1
       if gui_flag == 1
            result = 1;
            result_info = 'Passed !!!';
       else
            result = ModelAdvisor.Text('Passed !!!', {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(0);
        end
        return;
    end
    %    Warning case: there is data description empty

    if gui_flag == 1
        result = 1;
        return;
    end
    %    Put result if app run with Model Advisor
    messages = [ModelAdvisor.Text('Following are warning of prohibit direct transition from external state to child state.'), ModelAdvisor.LineBreak];
    
    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(1);
    
    num = 0;
    cellfun(@(error_blocks) add_linked_message(error_blocks), error_block(2:end, 1));
    function add_linked_message(blk)
        num = num + 1;
        msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
        msg_path = ModelAdvisor.Text(char(blk));
        address = sprintf('matlab:hilite_block(''%s'')', blk);
        msg_path.setHyperlink(address);

        messages = [messages, ModelAdvisor.LineBreak, msg_num, msg_path];
    end   

    result = messages;
end


function isSubs = isSubstate(state)
    % Check if destination state and source state is substate or not
    % Following are conditions for check one state is substate or not
    %       - Has not children
    %       - Parent is not state
    if(isempty(state.getChildren) && strcmp(class(state.getParent), 'Stateflow.State'))
        isSubs = 1;
    else
        isSubs = 0;
    end
end
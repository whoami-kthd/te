%  Function Name :script_ma_check_jc_0801
%  OverView : jc_0801 : Prohibited use of the Comment Symbol /*....*/ in MPT objects only
%                       MPT objects include mpt.Parameter or mpt.Signal in SLDD
%           
%  Parameters:
%        system(Selected hierarchy)
%        folder_output(Excel Path to output to file)
%
%  Return value: 
%        result(Result display data)
%        error_block(GUI Data for displaying results)
%        result_info(Data for displaying results in the GUI)
%
function [ result, error_block,  result_info] = script_ma_check_jc_0801(system, folder_output)
    
    % Flag to call from GUI or model advisor, Initialize variable to return
    % gui_flag = 1 : Execute from GUI
    % gui_flag = 0 : Run from model advisor
    gui_flag = 1;
    if nargin == 1   
        gui_flag = 0;
    else
        result = 0;
    end
	% Initializing the error Structure
    error_block = {};
    error_block{end + 1, 1}= 'Signal name'; 
    result_info = '';
	
    % When calling from the model advisor, obtain model advisor information
    if gui_flag == 0
        ma = Simulink.ModelAdvisor.getModelAdvisor(system);
    end
    % get Model name from System
    try
        model_name = GetModelName(system);
    catch
        model_name = system;
    end

    % compile model
    try
        eval([model_name '([],[],[],''compile'');']);
    catch ex
        result_info = sprintf(['�R���p�C���G���[\nCompile error\n' ex.message]);
        if gui_flag == 1
            result = 0;
        else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
          ma.setActionEnable(0);
        end
        return;
    end

    eval([model_name '([],[],[],''term'')']);
    try    
        % Find Data Dictionary linked to the Model
        rt = sfroot;
        model = rt.find('Name', model_name, 'Parent', '');
        dd = model.DataDictionary;
        
        dcount = strfind(dd,'.sldd');
        % Data Dictionary Found in the Model
        if(dcount > 0)
            % Open Data Dictionary to get its Object
            myDictionaryObj = Simulink.data.dictionary.open(dd);
            
            % Check in roost data dictionary
            dDataSectObj = getSection(myDictionaryObj,'Design Data');
            foundEntries = find(dDataSectObj,'-value','-class','mpt.Signal', '-or', '-class','mpt.Parameter');
                        
            for entry_cnt=1:size(foundEntries,1)
                tmp = getValue(foundEntries(entry_cnt));                
                if(isempty(strfind(tmp.Description,'/*')) && isempty(strfind(tmp.Description,'*/')))
                    % do nothing
                else
                    error_block{end + 1, 1}= foundEntries(entry_cnt).Name; 
                    error_block{end, 2} = foundEntries(entry_cnt).Name;
                end
            end
        else
            %No data Dictionary in the Model
            if gui_flag == 0
                result = ModelAdvisor.Text(sprintf('No data dictionary connect with model !!!'), {'pass'});
                ma.setCheckResultStatus(true);
                ma.setActionEnable(0);
            else
                result = 1;
                result_info = sprintf('No data dictionary connect with model !!!');
            end
            return;
        end

        % In calling from the GUI:When passing
        % folder path, output error block information to Excel
        % (Currently passing whitespace from the GUI)
        if(gui_flag == 1)
            if ~isempty(folder_output)
                outpath = [folder_output '/jc_0801_CheckResult' ];
                try
                    xlswrite([outpath '.xlsx'], error_block);
                catch
                    xlswrite([ outpath '_' datestr(now, 'yyyyMMdd_HHmmss') '.xlsx'], error_block);
                end
            end
        end
    catch ex
        result_info = sprintf([ex.message ' .\nScript: script_ma_check_jc_0801.\nLine: ' num2str(ex.stack(1).line)]);
        if gui_flag == 1
            result = 0;
        else
            result = ModelAdvisor.Text(result_info);
			
			if gui_flag == 0
				ma.setCheckResultStatus(false);
				ma.setCheckErrorSeverity(1);
			end
        end
        return;
    end 
    
    
   % ���ʏo��
    if size(error_block, 1) == 1
        if gui_flag == 0
            result = ModelAdvisor.Text(sprintf('All of MPT objects in SLDD do not constains /* ... */'), {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(0);
        else
            result = 1;
            result_info = sprintf('All of MPT objects in SLDD do not constains /* ... */');
        end
        return;
    end
    
   if gui_flag == 1
        result = 1;
        return;
    end

    messages = [ModelAdvisor.Text('Following is the list of MPT signals which contains /* ... */ '), ...
                ModelAdvisor.LineBreak];

    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(1);

    num = 0;
    cellfun(@(error_blocks) add_linked_message(error_blocks), error_block(2:end, 1));
    function add_linked_message(blk)
        num = num + 1;

        msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
        msg_path = ModelAdvisor.Text(char(blk));

        messages = [messages, ModelAdvisor.LineBreak, ...
                    msg_num, msg_path];
    end    

    result = messages;
end
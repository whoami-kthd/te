%  Function Name :script_ma_check_jc_0804
%  OverView : jc_0802 : Prohibited of implicit Type Cast
%    
%  Parameters:
%        system(Selected hierarchy)
%        folder_output(Excel Path to output to file)
%
%  Return value: 
%        result(Result display data)
%        error_block(GUI Data for displaying results)
%        result_info(Data for displaying results in the GUI)
%
%  Author: Mohan Mishra
%  Created date: 2019/1/28
%
function [result, error_block,  result_info] = script_ma_check_jc_0802(system, folder_output)
    %% 1. Declaring and Initializing the Variables

    
    %% 2. Flag to call from GUI or model advisor, Initialize variable to return
    % gui_flag = 1 : Execute from GUI
    % gui_flag = 0 : Run from model advisor
    gui_flag = 1;
    if nargin == 1   
        gui_flag = 0;
    else
        result = 0;
    end
	% Initializing the error Structure
    result_info = '';
	
    try
        %% 3. When calling from the model advisor, obtain model advisor information
        if gui_flag == 0
            ma = Simulink.ModelAdvisor.getModelAdvisor(system);
        end
         %% 4. get Model name form System
        try
            model_name = GetModelName(system);
        catch
            model_name = system;
        end
        
        
        rt = sfroot;
        model = rt.find('Name', model_name, 'Parent', '');
        m = rt.find('-isa','Simulink.BlockDiagram');
        % Fing Data Dictionary in the Model
        dd = model.DataDictionary;

        me = daexplr;
        uiopen(dd,1);
                
        % Open Data Dictionary to get its Object
        DictionaryObj = Simulink.data.dictionary.open(dd);            
        % Analyzing Signals and Parameters of Base SLDD
        hDesign = DictionaryObj.getSection('Global');
        
        childNames = hDesign.evalin('who'); 
        arr=[0,0];
        % Loading Signal & Parameter of Reference SLDD
        for i = 1:numel(childNames)
            hEntry = hDesign.getEntry(childNames{i});
            Name = hEntry.Name;
            DataType= hEntry.getValue.DataType;
          % arr(i,2) = DataType;
          % arr(i,1) = Name;
        end
        % Close Model Explorer
        me.delete; 
                   
    catch ex
        result_info = sprintf([ex.message ' .\nScript: script_ma_check_jc_0802.\nLine: ' num2str(ex.stack(1).line)]);
        if gui_flag == 1
            result = 0;
        else
            result = ModelAdvisor.Text(result_info);
            ma.setCheckResultStatus(false);
            ma.setCheckErrorSeverity(1);
        end
        return;
    end 
    
    if gui_flag == 1
        result = 1;
        return;
    end
 
end
%% �֐����Fscript_ma_check_jc_0805

function [ result, error_block,  result_info] = script_ma_check_jc_0805(system_in, folder_output)
    %% �@ GUI���̓��f���A�h�o�C�U����Ăяo���t���O����A�Ԃ��ϐ��̏�����
    % gui_flag = 1�F GUI������s
    gui_flag = 1;
    if nargin == 1
        gui_flag = 0;
    else
        result = 0;
    end
    error_block = {};
    result_info = '';
    
    if gui_flag == 0
        ma = Simulink.ModelAdvisor.getModelAdvisor(system_in);
    end

    blocks = find_system(system_in, 'FindAll','on',...
                                 'LookUnderMasks', 'none',...
                                 'RegExp','on', ...
                                 'Type', 'block', ...
                                 'BlockType', '^Abs$|^Sqrt$|^Math$|^Product$');

   if isempty(blocks)
       if gui_flag == 0
            result = ModelAdvisor.Text('There is no Abs, Sqrt, Math Function and Product blocks', {'pass'});
            ma.setCheckResultStatus(true);
       else
           result = 1;
           result_info = 'There is no Abs, Sqrt, Math Function and Product blocks';
       end
       return;
   end
   %% �D ���f�����擾
   try
       try
            model_name = GetModelName(system_in);
       catch
            model_name = system_in;
       end
   catch
   end
   
    % compile model
    try
        eval([model_name '([],[],[],''compile'');']);
    catch ex
        result_info = sprintf(['Model can not compile, Please check !!!\n'   ex.message ]);
        if gui_flag == 1
            result = 0;
        else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
          ma.setActionEnable(0);
        end
        return;
    end
   
    try
        %% �E �B�Ŏ擾�����I�u�W�F�N�g�̐ڑ����Ă��郉�C���ɐM������o�^���Ă��邩�`�F�b�N
        error_block                 = {};
        error_block{end + 1, 1 }    = 'Block Path';
        error_block{end, 2 }        = 'Block Handle';

        %% Check block when input is constant block only
        if ~isempty(blocks)
            for i = 1: size(blocks, 1)
                
                errFlg = 0;
                errFlg1 = 0;
                % Get input
                block_property  = get_param(blocks(i),'CompiledPortDataTypes');

                input_data_type = block_property.Inport{1};
                block_type      = get_param(blocks(i), 'BlockType');
                PortConnect     = get_param(blocks(i), 'PortConnectivity');
                SrcBlock        = PortConnect.SrcBlock;
                
                if(strcmp(get_param(SrcBlock, 'BlockType'), 'Constant'))
                    const_val       = get_param(SrcBlock, 'Value');
                    
                    % a, When [abs] is used, the minimum value of a signed integer type is not entered.
                    if(strcmp(block_type, 'Abs'))
                        switch (input_data_type)
                            case ('int8')
                                if(str2num(const_val) == intmin('int8'))
                                    errFlg = 1;
                                end
                            case ('CHAR')
                                if(str2num(const_val) == intmin('int8'))
                                    errFlg = 1;
                                end
                            case ('int16')
                                if(str2num(const_val) == intmin('int16'))
                                    errFlg = 1;
                                end
                            case ('SHORT')
                                if(str2num(const_val) == intmin('int16'))
                                    errFlg = 1;
                                end
                            case ('int32')
                                if(str2num(const_val) == intmin('int32'))
                                    errFlg = 1;
                                end
                            case ('LONG')
                                if(str2num(const_val) == intmin('int32'))
                                    errFlg = 1;
                                end
                            case ('int64')
                                if(str2num(const_val) == intmin('int64'))
                                    errFlg = 1;
                                end
                                % b, When using [abs], do not enter an unsigned integer type or fixed-point type.
                            otherwise
                                errFlg = 1;
                        end
                        
                        % c1, When using [Sqrt], do not enter negative numbers.
                    elseif (strcmp(block_type, 'Sqrt'))
                        operator_param = get_param(Sqrt_blocks(i), 'Operator');
                        % Check if input of Sqrt block is negative number or not
                        if strcmp(operator_param, 'Sqrt')
                            if(str2num(const_val) < 0)
                                errFlg = 1;
                            end
                            % d, When using [Reciprocal Sqrt], do not enter a number less than or equal zero.
                        elseif strcmp(operator_param, 'rSqrt')
                            if(str2num(const_val) <= 0)
                                errFlg = 1;
                            end
                        else
                            % do nothing
                        end
                    elseif (strcmp(block_type, 'Math'))
                        % e, Check if 'Operator' parameter is�glog�h,�glog10�hor not
                        param   = get_param(blocks(i), 'Operator');
                        param1  = get_param(blocks(i), 'OutputSignalType');
                        
                        % e, When using {Math Function] {Function} with �glog�h or �glog10�h, do not enter zero.
                        % f, When using {Math Function] with {Function} set to �glog�h or �glog10�h, do not enter negative numbers.
                        % When using {Math Function] with {Function} set to �glog�h or �glog10�h, set {Output signal type} to �gComplex�h.
                        
                        if strcmp(param, 'log') || strcmp(param, 'log10')
                           if((str2num(const_val) <= 0) || strcmp(param1, 'complex'))
                                errFlg = 1;
                           end
                        % h, When using {Math Function] with {Function} set to �greciprocal�h, do not enter zero.
                        elseif(strcmp(param, 'reciprocal'))
                            if(str2num(const_val) == 0)
                                errFlg = 1;
                           end
                        else
                            % do nothing
                        end
                        
                    elseif (strcmp(block_type, 'Product'))
                        % i, When using {Multiply}, Product] with �gelement unit (. *)�h, zero is not input to the divisor input (input port set to �g/�h in {input number}).
                        % j, When [Product] {Multiplication} is set to �gMatrix (*)�h and used, the singular value matrix is not input to the divisor input (input port set to �g/�h in {Input Number})
                        
                        PortConnect     = get_param(blocks(i), 'PortConnectivity');
                        SrcBlock        = {PortConnect.SrcBlock};
                        SrcBlock(~cellfun('isempty',SrcBlock));
                        
                        param = get_param(blocks(i), 'Multiplication');
                        if strcmp(param, 'Element-wise(.*)')
                            
                            list_of_str = get_param(blocks(i), 'Inputs');
                            divide_char = findstr(list_of_str, '/');
                            if ~isempty(divide_char)
                                if(strcmp(get_param(SrcBlock{divide_char}, 'BlockType'), 'Constant'))
                                    const_val       = get_param(SrcBlock{divide_char}, 'Value');
                                    if(str2num(const_val) == 0)
                                        errFlg = 1;
                                    end
                                end
                            else
                                % do nothing
                            end                            
                        else
                            list_of_str = get_param(blocks(i), 'Inputs');
                            divide_char = findstr(list_of_str, '/');
                            if ~isempty(divide_char)
                                if(strcmp(get_param(SrcBlock{divide_char}, 'BlockType'), 'Constant'))
                                    dimension_out   = get_param(SrcBlock{divide_char},'CompiledPortDimensions');
                                    if(dimension_out.Outport(1) >= 2)
                                        const_val   = str2num(get_param(SrcBlock{divide_char}, 'Value'));
                                        if(rcond(const_val) < 1e-12)
                                            errFlg = 1;
                                        end
                                    end
                                end
                            else
                                % do nothing
                            end
                        end
                    else
                        % do nothing
                    end
                    
                    if (errFlg == 1)
                        error_block{end+1, 1}   = MakePathBlock(blocks(i));
                        error_block{end, 2}     = blocks(i);
                    end
                end
                
                %%
                if(strcmp(block_type, 'Abs'))
                    % a2, Check if 'saturate on integer overflow' parameter of Abs block is checked or not
                    param = get_param(blocks(i), 'SaturateOnIntegerOverflow');
                    if strcmp(param, 'off')
                        errFlg1 = 1;
                    end

                elseif (strcmp(block_type, 'Sqrt'))
                    % c2, Check if 'Output signal type' parameter of Sqrt block is 'Complex' or not
                    param = get_param(blocks(i), 'OutputSignalType');
                    if strcmp(param, 'complex')
                        errFlg1 = 1;
                    end
                else
                    % do nothing
                end
                
                if (errFlg1 == 1)
                    error_block{end+1, 1}   = MakePathBlock(blocks(i));
                    error_block{end, 2}     = blocks(i);
                end
            end
        end
                
        %% �F GUI����Ăт����̏ꍇ�F
        % �t�H���_�p�X��n���ꍇ�AExcel�ɃG���[�u���b�N�����o��
        % (�����_��GUI����󔒂�n��)
       if gui_flag == 1
          % Excel�Ɍ��ʂ��o�͂���
          if ~isempty(folder_output)
              outpath = [folder_output '/jc_0805_CheckResult' ];
              try
                  xlswrite([outpath '.xlsx'], error_block);
              catch
                  xlswrite([ outpath '_' datestr(now, 'yyyyMMdd_HHmmss') '.xlsx'], error_block);
              end
          end
       end
    catch ex
       result_info = sprintf([ex.message ' .\nScript: script_ma_check_jc_0805.\nLine: ' num2str(ex.stack(1).line)]);
       if gui_flag == 1
            result = 0;
       else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
          ma.setActionEnable(0);
       end
       return;
    end
    
    eval([model_name '([],[],[],''term'')']);
    
    %% �G ���ʏo��
    %        �G �i1�j�G���[���Ȃ��ꍇ�F
    %                Pass����Ԃ�
    if size(error_block, 1) == 1
       if gui_flag == 0
            result = ModelAdvisor.Text(sprintf(['�SAbs, Sqrt, Math Function, Product�u���b�N�͓K�؂ɐݒ肳��Ă��܂� \n' ...
                                                'All of Abs, Sqrt, Math Function and Product blocks are set properly']), {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(0);
        else
            result = 1;
            result_info = sprintf(['�SAbs, Sqrt, Math Function, Product�u���b�N�͓K�؂ɐݒ肳��Ă��܂� \n' ...
                                   'All of Abs, Sqrt, Math Function and Product blocks are set properly']);
        end
        return;
    end
    %        �G �i2�j�G���[������ꍇ�F
    %            �G (2.1) GUI����Ăяo���ꍇ�A
    %                       GUI�ɖ߂��A���ʏo�͏���GUI�ŏ�������
    if gui_flag == 1
        result = 1;
        return;
    end
    %            �G (2.2) ���f���A�h�o�C�U����Ăяo���ꍇ�A    
    %                       ���f���A�h�o�C�U�ɏo�͏����쐬����
    messages = [ModelAdvisor.Text('�ȉ���Abs, Sqrt, Math Function, Product�u���b�N�̐ݒ肪�s�K�؂ł�'), ...
                ModelAdvisor.LineBreak, ...
                ModelAdvisor.Text('Following is the list of Abs, Sqrt, Math Function, Product blocks which does not set properly'), ...
                ModelAdvisor.LineBreak];

    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(1);

    num = 0;
    
    cellfun(@(error_blocks) add_linked_message(error_blocks), error_block(2:end, 1));
    function add_linked_message(blk)
        num = num + 1;

        msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
        msg_path = ModelAdvisor.Text(char(blk));
        address = sprintf('matlab:hilite_block(''%s'')', blk);
        msg_path.setHyperlink(address);

        messages = [messages, ModelAdvisor.LineBreak, ...
                    msg_num, msg_path];
    end    

    result = messages;
end
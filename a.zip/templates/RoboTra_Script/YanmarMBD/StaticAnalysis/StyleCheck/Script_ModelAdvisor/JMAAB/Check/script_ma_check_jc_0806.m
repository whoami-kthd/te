
%% ��?���?Fscript_ma_check_jc_0806
%  The script checks for the values of the Simulink Model Configuration
%  parameters 1) Division by singular matrix
%             2) Detect overflow and
%             3) Inf or NaN block output
% According to the JMAAB guideline jc_0806, these configuration parameters
% must be set to the option 'error' for Detection of unjust arithmetic
% operations.
% The fix script script_ma_fix_jc_0806 automatically changes the values of
% the above mentioned configuration parameters as described in the
% guideline

function [ result, error_block,  result_info] = script_ma_check_jc_0806(system, folder_output)
    %% �@ GUI���̓��f���A�h�o�C�U����Ă�?o���t���O����?A�Ԃ���?���?�����  Determining the flag called from GUI or Model advisor,Initialisation of variables to be returned
    %gui_flag = 1?F GUI�����?s
    gui_flag = 1;
    if nargin == 1
        % gui_flag = 0?F ���f���A�h�o�C�U?[�����?s
        gui_flag = 0;
    else
        result = 0;
    end
     error_block = {};
    result_info = '';
    try
        %% �A ���f���A�h�o�C�U����Ă�?o��?�?�?A���f���A�h�o�C�U��?����擾���� Get the model advisor information if it is to be called from the model advisor
        if gui_flag == 0
            ma = Simulink.ModelAdvisor.getModelAdvisor(system);
        end
        %% �B ���f�����擾 Get model names
        try
            model_name = GetModelName(system);
        catch
            model_name = system;
        end
        %% �C  Get the active simulink configuration
        rt = sfroot;
        model = rt.find('Name', model_name, 'Parent', '');
        Config = getActiveConfigSet(model);
        
        %% �D Return the Pass value if all the configuration parameters are already set to the required values
        if ((strcmp(Config.get_param('CheckMatrixSingularityMsg'), 'error')) && (strcmp(Config.get_param('ParameterOverflowMsg'), 'error')) && (strcmp(Config.get_param('SignalInfNanChecking'), 'error')))
            if gui_flag == 0
                result = ModelAdvisor.Text('Simulation parameters are as expected', {'pass'});
                ma.setCheckResultStatus(true);
                ma.setActionEnable(false);
            else
                result_info = 'Simulation parameters are as expected';
                result = 1;
            end
           return;
        end
        %% �E Initialising the error structure
        error_block = {};
        error_block{end + 1, 1}= 'ModelName'; 
        error_block{end, 2}= 'Simulink Parameter'; 
        error_block{end, 3}= 'Value'; 
        
         %% �E If any of the parameters 'CheckMatrixSingularityMsg', 'ParameterOverflowMsg' or 'SignalInfNanChecking' is not 'error', store it in the error list
          if ~strcmp(Config.get_param('CheckMatrixSingularityMsg'), 'error') == 1
               error_block{end + 1, 1} = model_name;
               error_block{end, 2} = 'Division by singular matrix';
               error_block{end, 3} = Config.get_param('CheckMatrixSingularityMsg'); 
          end
          
          if ~strcmp(Config.get_param('ParameterOverflowMsg'), 'error') == 1
               error_block{end + 1, 1} = model_name;
               error_block{end, 2} = 'Detect overflow';
               error_block{end, 3} = Config.get_param('ParameterOverflowMsg'); 
          end
          
          if ~strcmp(Config.get_param('SignalInfNanChecking'), 'error') == 1
               error_block{end + 1, 1} = model_name;
               error_block{end, 2} = 'Inf or NaN block output';
               error_block{end, 3} = Config.get_param('SignalInfNanChecking'); 
          end
%           
%         %% �F GUI����Ăт�����?�?�?F If calling from GUI
%         % �t�H���_�p�X��n��?�?�?AExcel�ɃG��?[�u�?�b�N?���?o�� If the folder path is to be passed
%         % or transferred, output the error block information into the excel
%         % (�����_��GUI����󔒂�n��) Right now empty is passd from GUI
       if gui_flag == 1
          % Excel�Ɍ��ʂ�?o�͂��� Output the results into the excel
          if ~isempty(folder_output)
              outpath = [folder_output '/jc_0806_CheckResult' ];
              try
                  xlswrite([outpath '.xlsx'], error_block);
              catch
                  xlswrite([ outpath '_' datestr(now, 'yyyyMMdd_HHmmss') '.xlsx'], error_block);
              end
          end
       end
        
    catch ex
       result_info = sprintf([ex.message ' .\nScript: script_ma_check_jc_0806.\nLine: ' num2str(ex.stack(1).line)]);
       if gui_flag == 1
            result = 0;
       else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
       end
       return;
    end
    % �G ����?o�� Result output
    %        �G ?i1?j�G��?[���Ȃ�?�?�?F  In the absence of an error
    %                Pass?���Ԃ� Return pass information
    if size(error_block, 1) == 1
       if gui_flag == 0
            result = ModelAdvisor.Text('Simulation parameters are as expected', {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(false);
        else
            result = 1;
            result_info = 'Simulation parameters are as expected';
        end
        return;
    end
%     %        �G ?i2?j�G��?[������?�?�?F In case of an error
%     %           �G (2.1) GUI����Ă�?o��?�?�?A If calling from GUI
%     %                    GUI�ɖ߂�?A����?o��?���GUI��?��?���� Result output information
%     %                    which is returned to the GUI is processed in the
%     %                    GUI
    if gui_flag == 1
        result = 1;
        return;
    end
%     %           �G (2.2) ���f���A�h�o�C�U����Ă�?o��?�?�?A If calling from Model advisor    
%     %                    ���f���A�h�o�C�U��?o��?���?�?����� Create output information in model advisor as a table    
                
    ft = ModelAdvisor.FormatTemplate('TableTemplate');
    ft.setColTitles({'Configuration Parameter', 'Current Value', 'Expected Value'});
    ft.setSubBar(0);

    if strcmp(Config.get_param('CheckMatrixSingularityMsg'), 'error') == 0
        ft.addRow({'Division by singular matrix', Config.get_param('CheckMatrixSingularityMsg') , 'error'});
    end

    if strcmp(Config.get_param('ParameterOverflowMsg'), 'error') == 0
        ft.addRow({'Detect overflow', Config.get_param('ParameterOverflowMsg') , 'error'});
    end

    if strcmp(Config.get_param('SignalInfNanChecking'), 'error') == 0
        ft.addRow({'Inf or NaN block output', Config.get_param('SignalInfNanChecking') , 'error'});
    end

    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(true);

    
%Output ft error table
    result = ft;

     
end
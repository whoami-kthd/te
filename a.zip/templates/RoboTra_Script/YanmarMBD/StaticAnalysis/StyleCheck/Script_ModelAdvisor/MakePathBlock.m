%% �֐����Fhilite_line
%  �T�v�F
%       ���C����\������B
%  �p�����[�^�F 
%       block_handle(�u���b�N�n���h��)
%  �߂��l�F�@path(�u���b�N�̃p�X)
%  �쐬�ҁF LOC
%  �쐬���F 2017/03/09
function return_path = MakePathBlock(block_info, ischart)
    try
        if ishandle(block_info)
            try
                block_path = get(block_info, 'Parent');
            catch
                block_path = get(block_info, 'Path');
            end
            block_path = regexprep(block_path, '\n', ' ');
            block_name = get(block_info, 'Name');
            block_name = regexprep(block_name, '\n', ' ');
            if nargin > 1 && ischart == 1
                return_path = block_path;
            else
                return_path = [ block_path '/' block_name ];
            end
        elseif isstruct(block_info)
            block_path = block_info.Parent;
            block_path = regexprep(block_path, '\n', ' ');
            block_name = block_info.Name;
            block_name = regexprep(block_name, '\n', ' ');
            return_path = [ block_path '/' block_name ];
        else
            return_path = block_info;
        end
    catch
        return_path = block_info;
    end
end
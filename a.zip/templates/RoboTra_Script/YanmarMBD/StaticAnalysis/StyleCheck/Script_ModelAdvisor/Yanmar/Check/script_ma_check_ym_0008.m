%% Function Name�Fscript_ma_check_ym_0008
%  Overview�F�uym_0008 �F Check if object description in dictionary is empty or
%             not�v
%  Parameters�F 
%        system(Selected hierarchy)
%        folder_output(Excel�t�@�C���ɏo�͂���p�X)
%  Return value:
%        result(Result display data)
%        error_block(GUI Data for displaying results)
%        result_info(Data for displaying results in the GUI)

function [ result, error_block, result_info ] = script_ma_check_ym_0008(system, folder_output)
    gui_flag = 1;
    if nargin == 1       
        gui_flag = 0;
    else
        result = 0;
    end
    result_info = '';
    error_block = {};
    
    try
       if gui_flag == 0
           ma = Simulink.ModelAdvisor.getModelAdvisor(system);
       end
       
       try
           model_name = GetModelName(get_param(system, 'handle'));
       catch
           model_name = system;
       end
      %% Try to compile model for check model has error or not
        try
            if gui_flag == 0          
                evalin('base', [ model_name '([],[],[],''compile'')']);
                evalin('base', [ model_name '([],[],[],''term'')']); 
            else           
                evalin('base', [ model_name '([],[],[],''compile'')']);
                evalin('base', [ model_name '([],[],[],''term'')']); 
            end
        catch ex
            result_info = sprintf(['�R���p�C���G���[ \nCompile error \n' ex.message]);
            if gui_flag == 1
                result = 0;
            end
            return;
        end
        
       %% Check if object description in dictionary is empty or not 
        slddSection = {};
        try
            sldd_filename = get(get_param(model_name, 'handle'), 'DataDictionary');
            myDictionaryObj = Simulink.data.dictionary.open(sldd_filename);
            slddSection = myDictionaryObj.getSection('Design Data');
        catch
        end

        if isempty(slddSection)
           result_info = 'Model does not link with data dictionary !!!';
           if gui_flag == 1
               result = 1;
           else
              result = ModelAdvisor.Text(result_info);
              ma.setCheckResultStatus(false);
              ma.setCheckErrorSeverity(0);
              ma.setActionEnable(0);
           end
           return;

        else
            % If model using SLDD, steps to check as following
            %   1: export sldd section to mat file
            %   2: assign data in sldd to structure
            %   3: get name of each data and check description in structure
            %   is empty or not
            exportToFile(slddSection, 'all_entry.mat');
            all_entry_struct = load('all_entry.mat');
            fields = fieldnames(all_entry_struct);
            delete('all_entry.mat');

            num_entry = length(fields);
            error_block = {'Warning'};
            for cnt=1:num_entry
               field_name_str = fields{cnt};
               if(isempty(all_entry_struct.(field_name_str).Description))
                   error_block{end+1, 1} = field_name_str;
               else
                   % do nothing
               end
            end
        end
        
    catch ex
       result_info = sprintf([ex.message ' .\nScript: script_ma_check_ym_0008.\nLine: ' num2str(ex.stack(1).line)]);
       if gui_flag == 1
            result = 0;            
       else
          result = ModelAdvisor.Text(result_info);
          ma.setCheckResultStatus(false);
          ma.setCheckErrorSeverity(1);
          ma.setActionEnable(0);
       end
       return;
    end
	
    %% Get output
    %    Pass case
    if size(error_block, 1) == 1
       if gui_flag == 1
            result = 1;
            result_info = 'All of object description in dictionary are not empty';
       else
            result = ModelAdvisor.Text('All of object description in dictionary are not empty', {'pass'});
            ma.setCheckResultStatus(true);
            ma.setActionEnable(0);
        end
        return;
    end
    %    Warning case: there is data description empty

    if gui_flag == 1
        result = 1;
        return;
    end
    %    Put result if app run with Model Advisor
    messages = [ModelAdvisor.Text('Following are object which have description in dictionary are empty.'), ModelAdvisor.LineBreak];
    
    ma.setCheckResultStatus(false);
    ma.setCheckErrorSeverity(0);
    ma.setActionEnable(1);
    
    num = 0;
    cellfun(@(error_blocks) add_linked_message(error_blocks), error_block(2:end, 1));
    function add_linked_message(blk)
        num = num + 1;
        msg_num = ModelAdvisor.Text(sprintf('(%d) ', num));
        msg_path = ModelAdvisor.Text(char(blk));
        address = sprintf('matlab:hilite_block(''%s'')', blk);
        msg_path.setHyperlink(address);

        messages = [messages, ModelAdvisor.LineBreak, msg_num, msg_path];
    end   

    result = messages;
end

% Defines custom Model Advisor checks
function defineChecks

    eval('assignin(''base'', ''checker_yanmar_style_ids'', []);');
    eval('assignin(''base'', ''checker_jmaab_style_ids'', []);');
    
    %% �X�^�C���ڍׂ�ǂݍ���
    Styles = importdata('DefineStyle.xlsx');
    JMAABStyles = Styles.JMAABStyle;
    %% �A�h�o�C�U��JMAAB Style �`�F�b�N�o�^
    if ~isempty(JMAABStyles) && size(JMAABStyles, 1) > 1
        JMAABStyles = JMAABStyles(2:end, 1:end);
        for i = 1: size(JMAABStyles, 1)
            % �����C���\�̏ꍇ
            if ~isempty(JMAABStyles{i,5}) && ~isempty(regexp(JMAABStyles{i,5}, '_fix_', 'match'))
                regist_check(['yanmar.' JMAABStyles{i,1}], ...
                             eval('base', ['@' JMAABStyles{i,3}]), ...
                             JMAABStyles{i,2}, ...  
                             JMAABStyles{i,4}, ...
                             evalin('base', ['@' JMAABStyles{i,5}]), ...
                             '�����C��', ...        
                             JMAABStyles{i,6}, ...
                             0);
            % �����C���s�̏ꍇ    
            else
                regist_check(['yanmar.' JMAABStyles{i,1}], ...
                             eval('base', ['@' JMAABStyles{i,3}]), ...
                             JMAABStyles{i,2}, ...
                             JMAABStyles{i,4}, ...
                             evalin('base', ['@' JMAABStyles{i,5}]), ...
                             '�K�C�h���C�����J��', ...
                             JMAABStyles{i,6}, ...
                             0);
            end
        end
    end
   %% �A�h�o�C�U��Yanmar Style �`�F�b�N�o�^ (Yanmar Style�͕ʂ̃c�[���Ŏ��s���邽�߁C�R�����g�A�E�g���Ă���)
    YanmarStyles = Styles.YanmarStyle;
    if ~isempty(YanmarStyles) && size(YanmarStyles, 1) > 1
        YanmarStyles = YanmarStyles(2:end, 1:end);
        for i = 1: size(YanmarStyles, 1)
            % �����C���\�̏ꍇ
            if ~isempty(YanmarStyles{i,5}) && ~isempty(regexp(YanmarStyles{i,5}, '_fix_', 'match'))
                regist_check(['yanmar.' YanmarStyles{i,1}], ...
                             eval('base', ['@' YanmarStyles{i,3}]), ...
                             YanmarStyles{i,2}, ...
                             YanmarStyles{i,4}, ...
                             eval('base', ['@' YanmarStyles{i,5}]), ...
                             '�����C��', ...
                             YanmarStyles{i,6}, ...
                             1);
            % �����C���s�̏ꍇ    
            else
                regist_check(['yanmar.' YanmarStyles{i,1}], ...
                             eval('base', ['@' YanmarStyles{i,3}]), ...
                             YanmarStyles{i,2}, ...
                             YanmarStyles{i,4}, ...
                             evalin('base', ['@' YanmarStyles{i,5}]), ...
                             '�K�C�h���C�����J��', ...
                             YanmarStyles{i,6}, ...
                             1);
            end
        end
    end
end

function regist_check(check_id, check_fcn, check_title, check_desc, ...
                      action_fcn, action_name, action_desc, isYanmarStyle)

    if nargin < 5
        action_fcn = [];
        action_name = '';
        action_desc = '';
    end
                  
    check = ModelAdvisor.Check(check_id);
    % Yanmar_ym_1006(Goto/From�u���b�N�̐F)
    if strcmp(check_id, 'yanmar.Yanmar_ym_1006')
        check = DefineCheckInputParameter_ym_1006(check);
    % Yanmar_ym_1008
    elseif strcmp(check_id, 'yanmar.Yanmar_ym_1008')
        check = DefineCheckInputParameter_ym_1008(check);
    % Yanmar_ym_1018(�ۂߕ���)
    elseif strcmp(check_id, 'yanmar.Yanmar_ym_1018')
        check = DefineCheckInputParameter_ym_1018(check);
    % Yanmar_ym_1025(�֐��Ăяo���T�u�V�X�e���̍ĊJ���̏�Ԃ�Outport�u���b�N�̃f�B�Z�[�u�����̏o��)
    elseif strcmp(check_id, 'yanmar.Yanmar_ym_1025')
        check = DefineCheckInputParameter_ym_1025(check);
    % Yanmar_ym_2005(Stateflow�̌���)
    elseif strcmp(check_id, 'yanmar.Yanmar_ym_2005')
        check = DefineCheckInputParameter_ym_2005(check);
    else
        %nothing
    end
    check.Title = check_title;
    check.Description = check_desc;
    
    setCallbackFcn(check, check_fcn, 'None', 'StyleOne');
    
    if ~isempty(action_fcn)
        modifyAction = ModelAdvisor.Action;
        setCallbackFcn(modifyAction, action_fcn);
        modifyAction.Name = action_name;
        modifyAction.Description = action_desc;
        modifyAction.Enable = true;
        setAction(check, modifyAction);    
    end
    
    mdladvRoot = ModelAdvisor.Root;
    mdladvRoot.register(check);

    if isYanmarStyle == 1
        checker_yanmar_style_ids = evalin('base', 'checker_yanmar_style_ids');
        checker_yanmar_style_ids{end + 1} = check_id;
        assignin('base', 'checker_yanmar_style_ids', checker_yanmar_style_ids);
    else
        checker_jmaab_style_ids = evalin('base', 'checker_jmaab_style_ids');
        checker_jmaab_style_ids{end + 1} = check_id;
        assignin('base', 'checker_jmaab_style_ids', checker_jmaab_style_ids);
    end
end

function result_check = DefineCheckInputParameter_ym_1006(check)
    result_check = check;
    result_check.setInputParametersLayoutGrid([1 3]);
    % define input parameters
    inputParam = ModelAdvisor.InputParameter;
    inputParam.Name='Check Rule';
    inputParam.Type='Combobox';
    inputParam.Description='PJ��I������';
    inputParam.Entries={'���[���@�F���{�g��PJ (Rule�@: Robot PJ)', '���[���A�F����PJ (Rule�A: Other PJ)'};
    inputParam.setRowSpan([1 1]);
    inputParam.setColSpan([1 1]);

    result_check.setInputParameters({inputParam});
end

function result_check = DefineCheckInputParameter_ym_1008(check)
    result_check = check;
    result_check.setInputParametersLayoutGrid([3 2]);
    
    % define input parameters
    inputParam = ModelAdvisor.InputParameter;
    inputParam.Name='Code Generation Layer';
    inputParam.Type='String';
    inputParam.Description='Code Generation Layer';
    inputParam.Value = 'AutonomousCtrl';
    inputParam.setRowSpan([1 1]);
    inputParam.setColSpan([1 1]);
    
    result_check.setInputParameters({inputParam});
end

function result_check = DefineCheckInputParameter_ym_1018(check)
    result_check = check;
    result_check.setInputParametersLayoutGrid([2 3]);
    % define input parameters
    inputParam = ModelAdvisor.InputParameter;
    inputParam.Name='�ۂߕ���';
    inputParam.Type='Combobox';
    inputParam.Description='�ۂߕ�����I������';
    inputParam.Entries={ '�[�������ւ̊ۂ� (Zero)', '�������̊ۂ� (Ceiling)', '�ł��߂������ւ̊ۂ� (Convergent)', '�������̊ۂ� (Floor)', ....
                        '�ł��߂������ւ̊ۂ� (Nearest)', '�����ւ̊ۂ� (Round)', '�V���v���Ȋۂ� (Simplest)'};  
                
    inputParam.setRowSpan([2 2]);
    inputParam.setColSpan([1 1]);
    
    % define input parameters
    inputParam1 = ModelAdvisor.InputParameter;
    inputParam1.Name = '�p�����[�^�\���`�F�b�N';
    inputParam1.Type = 'Bool';
    inputParam1.Value = false;
    inputParam1.Description = 'AttributesFormatString Parameter Check';
    inputParam1.setRowSpan([2 2]);
    inputParam1.setColSpan([2 2]);
    
    result_check.setInputParameters({inputParam,inputParam1});
end

function result_check = DefineCheckInputParameter_ym_1025(check)
    result_check = check;
    result_check.setInputParametersLayoutGrid([1 3]);
    
    inputParam = ModelAdvisor.InputParameter;
    inputParam.Name = 'TriggerPort�u���b�N�̃C�l�[�u�����̏�Ԃ��p���̏ꍇ�͖ڎ��`�F�b�N�ςł�';
    inputParam.Type = 'Bool';
    inputParam.Value = false;
    inputParam.Description = '�C�l�[�u�����̏�Ԃ��p���̏ꍇ�͖ڎ��`�F�b�N�ςł��B�܂�`�F�b�N�͑ΏۊO�Ƃ���';
    inputParam.setRowSpan([1 1]);
    inputParam.setColSpan([1 1]);

    result_check.setInputParameters({inputParam});
end

function result_check = DefineCheckInputParameter_ym_2005(check)
    result_check = check;
    result_check.setInputParametersLayoutGrid([1 3]);
    % define input parameters
    inputParam = ModelAdvisor.InputParameter;
    inputParam.Name='Stateflow����';
    inputParam.Type='Combobox';
    inputParam.Description='Stateflow����';
    inputParam.Entries={ 'Matlab����', 'C����'};
    inputParam.setRowSpan([1 1]);
    inputParam.setColSpan([1 1]);

    result_check.setInputParameters({inputParam});
end
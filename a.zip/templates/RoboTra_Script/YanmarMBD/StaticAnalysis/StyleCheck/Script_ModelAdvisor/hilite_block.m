%% �֐����Fhilite_block
%  �T�v�F
%       �u���b�N��\������B
%  �p�����[�^�F 
%       block(�u���b�N�̖��O)
%  �߂��l�F�@����
%  �쐬�ҁF LOC
%  �쐬���F 2017/01/17
function hilite_block(block, block_path)
    if nargin == 2
        if ~ishandle(block)
            block_handle = get_param(block_path, 'handle');
            if isempty(block_handle)
                return;
            end
        else
            block_handle = block;
        end
    else
        if isempty(block) || (ischar(block) && strcmp(block, 'Simulink����'))
            return;
        end
        block_handle = get_param(block, 'handle');
        if ~ishandle(block_handle)
            return;
        end
    end
    if bdroot(block_handle) == block_handle
        open_system(block_handle);
    else
        hilite_system(block_handle);
        for i = 1:5
            if mod(i,2) == 1
                set_param(block_handle, 'HiliteAncestors', 'on');
            else
                set_param(block_handle, 'HiliteAncestors', 'off');
            end
            pause(0.5);
        end
        set_param(block_handle, 'HiliteAncestors', 'off');
    end
end
function sl_customization(cm)
    
    % register custom checks
    cm.addModelAdvisorCheckFcn(@defineChecks);

    % register custom factory group
    cm.addModelAdvisorTaskFcn(@defineTasks);

end
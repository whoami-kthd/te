function update
    sl_refresh_customizations;
end
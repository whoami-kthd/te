%  Function Name :StyleCheckResultAutoSaving
%  
%  Functionality: Export result of style checking to excel file in GUI
%			      This function is used in function "Create Report" of StyleCheck (GUI, script)
%  Parameters:
%        system	: 			Model name
%        folder_output : 	Excel Path to output to file
%        result	:			Result of style checking from GUI
%
function [error_msg] = StyleCheckResultAutoSaving(system, folder_output, result)
    
    try
       %% 6.Start Creating Excel Sheet and save all the information in it
        % Specify sheet number, data, and range to write to Excel Sheet
        Start_time = [ datestr(now, 'HH') ':'  datestr(now, 'MM') ':' datestr(now, 'SS')];
        TargetFolder = '\\NARDR009\Project\AHE6652\AHE6652_Temp\khaitv\StyleCheckResults';
        
        if ~exist(TargetFolder, 'dir')
            %mkdir(TargetFolder)
            %disp(sprintf(['There is no folder, please create new folder !!! \n�t�H���_������܂���A�V�����t�H���_������Ă������� !!!']));
            error_msg = '';
            return;
        end
        
        % Create New Excel Sheet StyleCheck in Present Working Directory
        name = 'StyleCheckResult';
        date = datestr(now, 'yyyymmdd_HHMMSS');
        user_name = getenv('username');
        FileName = [TargetFolder '\' date '_' name '_' user_name '.csv']; 
        
        sheetnum=1;
        BaseData{1} = 'Date';
        BaseData{2} = 'Start Time';
        BaseData{3} = 'End Time';
        BaseData{4} = 'Total Time';
        BaseData{5} = 'Matlab License Name';
        BaseData{6} = 'Model Name';
        BaseData{7} = 'Rule ID';

        % Taking Transpose of an Array to write in Excel Sheet
        BaseData = transpose(BaseData);

        % Write the Current Date and Time in an Array
        BaseData_1 = {};
        date = [ datestr(now, 'yyyy') datestr(now, 'mm') datestr(now, 'dd')];
        BaseData_1{1} = date;
        
        % Take a log of Start Time        
        BaseData_1{2} = [date '_' datestr(Start_time,'HHMMSS')];
        BaseData_1_tmp = datestr(Start_time,'HH:MM:SS');
        
        % Take a log of Current Time
        BaseData_1{3} = {''};
        
        %Take a log of Differnce of Start and End Time in Minute
        BaseData_1{4} = {''};
        
        % Take a log of License Name 
        BaseData_1{5} = license;
        % Take a log of Model Name 
        BaseData_1{6} = system;
        
        BaseData_1{7} = 'Result';
        BaseData_1 = transpose(BaseData_1);        
        base = horzcat(BaseData, BaseData_1);
        
        temp = size(result);
        length_result = temp(1);
        
        ma = Simulink.ModelAdvisor.getModelAdvisor(system);
        allIDs = ma.getCheckAll;
        
        if verLessThan('matlab','9.5')
            IndexC = strfind(allIDs,'yanmar');
            yanmarID = allIDs(find(not(cellfun('isempty',IndexC))));
        else
            yanmarID = allIDs(find(contains(allIDs, 'yanmar')));
        end
        
         temp = size(yanmarID);         
         length_IDs = temp(2);
         
         if(length_result <= length_IDs)
             ID_result = result(:,1);
             stt_result = result(:,2);
             new_result = {};
             
             for count=1:length_result
                if verLessThan('matlab','9.5')
                    IndexC = strfind(yanmarID,ID_result{count});
                    no = find(not(cellfun('isempty',IndexC)));
                else
                    no = find(contains(yanmarID, ID_result{count}));
                end
                new_result{count, 1} = yanmarID{no};
                new_result{count, 2} = stt_result{count};
             end
             
         else
             error_msg = '';
             result = 0;
             return;
         end
         
        base = vertcat(base, new_result);
         
        % Take a log of Current Time
        Stop_time = [date '_'  datestr(now, 'HH')  datestr(now, 'MM') datestr(now, 'SS')];
        Stop_time_tmp = [ datestr(now, 'HH') ':'  datestr(now, 'MM') ':' datestr(now, 'SS')];
        base{3,2} = Stop_time;
        
        %Take a log of Differnce of Start and End Time in Minute
        t11=datevec(datenum(BaseData_1_tmp));
        t22=datevec(datenum(Stop_time_tmp));
        time_interval_in_seconds = (etime(t22,t11)/60);
        base{4, 2} = time_interval_in_seconds;
        
        %% Check size of folder is greater than 1GB or not
        serverDir = dir(TargetFolder);
        if(numel(serverDir)>=0)
            % Folder Exist on Server
            TargetFolderSize = sum([serverDir.bytes]);
            % Total Size in GB
            if (TargetFolderSize > (1024^3))
                %Folder Size is > 1 GB
                % do nothing
                error_msg = '';
                return;
            else
                %Folder Size is < 1 GB
                xlswrite(FileName,base,sheetnum);
                % Check StyleCheckSummaryGenerate file is existed or not
                % if not, copy to current folder
                StyleCheckSummaryGenerate_file = 'StyleCheckSummaryGenerate.xlsm';
                if exist([TargetFolder '\' StyleCheckSummaryGenerate_file], 'file') == 2
                    % File exists
                    % do nothing
                    error_msg = '';
                else
                    % StyleCheckSummaryGenerate file does not exist.
                    path_copy = '';
                    original_path = which(StyleCheckSummaryGenerate_file, '-all');
                    if size(original_path, 1) >= 1
                        for path_cnt=1:size(original_path, 1)
                            if contains(original_path{path_cnt},'YanmarMBD\StaticAnalysis\StyleCheck\StyleCheck_Doc')
                                path_copy = original_path{path_cnt};
                            else
                                continue;
                            end
                        end
                    else
                        path_copy = original_path{1};
                    end

                    if ~isempty(path_copy)
                        copyfile(path_copy, [TargetFolder '\' StyleCheckSummaryGenerate_file], 'f');
                        error_msg = '';
                    else
                        error_msg = sprintf('There is no StyleCheckSummaryGenerate.xlsm file in StyleCheck_Doc folder. Please check !!!');
                    end
                end
            end
        end
	catch ex
		error_msg = sprintf([ex.message ' .\nScript: StyleCheckResultAutoSaving\nLine: ' num2str(ex.stack(1).line)]); 
		return;
    end
end

% target folder constain xlsx, xlsm files only, so don't need to use this function
function out = DirSize(dirIn)
    %DirSize Determine the size of a directory in bytes.
    %   bytes = DirSize(dirIn) Recursively searches the directory indicated by
    %   the string dirIn and all of its subdirectories, summing up the file
    %   sizes as it goes.  
    %   
    %   Example:
    %   ________
    %       DirSize(pwd)./(1024*1024)  %Returns size of the current directory
    %       in megabytes.
    %Richard Moore
    %April 17, 2013
    originDir = pwd;
    cd(dirIn);
    a = dir;
    out = 0;
    for x = 1:1:numel(a)
        %Check to make sure that this part of 'a' is an actual file or
        %subdirectory.  
        if ~strcmp(a(x).name,'.')&&~strcmp(a(x).name,'..')
            %Add up the sizes.
            out = out + a(x).bytes;
            if a(x).isdir 
                %Ooooooh, recursive!  Fancy!
                out = out + DirSize([dirIn '\' a(x).name]);
            end
        end
    end
    cd(originDir);
end
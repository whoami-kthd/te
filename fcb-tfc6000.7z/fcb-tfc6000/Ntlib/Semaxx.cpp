//#include "stdafx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include	<afxmt.h>
#include	<semaxx.h>

/////////////////////////////////////////////////////////////////////////////
// CSemaphoreX

BOOL CSemaphoreX::Lock(DWORD dwTimeout)
{
	if (::WaitForSingleObject(m_hObject, dwTimeout) != WAIT_OBJECT_0)
		return FALSE;
	else
		return TRUE;
}

IMPLEMENT_DYNAMIC(CSemaphoreX, CSemaphore)

/////////////////////////////////////////////////////////////////////////////
// CEventX

BOOL CEventX::Lock(DWORD dwTimeout)
{
	if (::WaitForSingleObject(m_hObject, dwTimeout) != WAIT_OBJECT_0)
		return FALSE;
	else
		return TRUE;
}

IMPLEMENT_DYNAMIC(CEventX, CEvent)

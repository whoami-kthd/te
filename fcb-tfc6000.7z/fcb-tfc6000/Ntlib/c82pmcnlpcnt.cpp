/*---------------------------------------------------------------------
	Cognex MVS-8200 ���� �N���X���C�u����
	1�_�F������f�J�E���g�����F���N���X	
								2001 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------
  --------------------------------------------------------------------*/
//-------------------------------------------------------------------


#include <ch_cvl/defs.h>
#include <ch_cvl/board.h>
#include <ch_cvl/acq.h>

#include <ch_cvl/except.h>
#include <ch_cvl/pelmap.h>
// #KS1154(S) 02-07-04 COG8200�p�c�ݕ␳�ڐA
#include <ch_cvl/diagsrv.h>

#include <ch_cvl/vidfmt.h>
#include <ch_cvl/constrea.h>
#include <ch_cvl/units.h>

//#include <ch_cog/rpc.h>
//#include <ch_cvl/vp8200.h>
#include <ch_cvl/vp8504.h>

#include <ch_cvl/pelbuf.h>
#include <ch_cvl/pelfunc.h>
#include <ch_cvl/windisp.h>
#include <ch_cvl/uishapes.h>
#include <ch_cvl/shapes.h>
#include <ch_cvl/pmalign.h>
#include <ch_cvl/autoslct.h>
#include <ch_cvl/atslptmx.h>
#include <ch_cvl/timer.h>
#include <ch_cvl/blobtool.h>
#include <ch_cvl/blobdesc.h>
#include <ch_cvl/histo.h>
#include <ch_cvl/histstat.h>
#include <ch_cvl/scnangle.h>
#include <ch_cvl/caliper.h>

#include <iostream>
#include <string>


#include <afxwin.h>
#include "libstd.h"
#include "semaxx.h"
#include "c8200dlg.h"
#include "c8200rpc.h"
#include "c8200.h"
//#include "dib.h"
#include "pos.h"


bool	CPMCnlPCnt::PixelCount(
			double x,double y,double w,double h,
			int threshold,	//  threshold	--> �Z�x臒l
			BOOL dark,		//	dark		-->	true:�Â���f���J�E���g	false:���邢��f���J�E���g
			int judgecount,	//	judgecount	--> �����f��
			int display,	//	disply		--> �\������t���O
			int& pcount)	//	pcount		--> ���o��f��
		//	return		--> true:�����f���ȏ�	false:�����f���ȉ�
		//	disply ---	eDisplayText1(�e�L�X�g�\��),eDisplayGraphic1(�q�X�g�O����),eDisplayGraphic2(��l���摜�j



{
	bool	r=true;
	pPC->Live(false);	// ���C�u�\����~
#if GPDEBUG
//	CompleteEvent.SetEvent();				// ���������C�x���g
	return false;
#endif// #IK080402-04 Badϰ����o�ł���܂��~����s��C��
//	CSingleLock	Sema(&pPC->CogSema,true);
	try{
		ccPelBuffer<c_UInt8> pb;
		{
			CSingleLock	Sema2(&pPC->CogfifoSema,true);
			GetFifo()->properties().movePartCallback(pPC->nullCallbackPtrh); // ���Z�b�g
			GetFifo()->properties().completeCallback(pPC->nullCallbackPtrh);
			GetFifo()->properties().roi(getWindowFromClient(x,y,w,h));
			GetFifo()->start();				// start acquisition
			pb = GetFifo()->complete();		// wait on acq.
			// #MU150821-01(S)
//			if(pPC->m_LiveCameraIndex == pPC->ICSearchCamera && pPC->ICImageRotation){
			if(m_CameraIndex == pPC->ICSearchCamera && pPC->ICImageRotation){
				pb = cfPelFlipH(pb);
			}
			// #MU150821-01(E)
		}
// #IK080402-04 Badϰ����o�ł���܂��~����s��C��
		CSingleLock	Sema(&pPC->CogSema,true);

		ccPelBuffer<c_UInt8> pbw(pb);
		ccTimer	time(true);	

		cmStd vector<c_UInt32> histogram(256);
		for(int i=0;i<256;i++)	histogram[i] = 0;
		cfPelHistogram(pbw,histogram);
		ccHistoStats HistoStats(histogram);
		pcount = 0;
		if(dark){
			for(i=0;i<=threshold;i++)
				pcount += histogram[i];
		}
		else{
			for(i=threshold;i<=255;i++)
				pcount += histogram[i];
		}
		if(pcount < judgecount)	r = false;	

		

		if(display){
// #IK080610-03(S) ��ػ���F�����ʉ摜�����{�\������邱�Ƃ�����
//			// #NN8007 2008-03-28  �F�����ʕ\����ʂŉ摜�\���{�������{�ɂȂ��Ă��܂��s��΍�
//			pPC->resetDisplayZoom(m_CameraIndex);
// #IK080610-03(E)
			if(display & CMVS8200::eDisplayGraphic2){
				std::vector<c_UInt8> map(256);
				for(i=0;i<threshold;i++)	map[i] = 0;
				for(;i<256;i++)				map[i] = 255;
				if(dark)	map[threshold] = 0;
				ccPelBuffer<c_UInt8> mappedImage = cfPelMap(pbw,map);
				mappedImage.clientFromImageXform(getClientFromImageXform());	// ���W�ϊ��I�u�W�F�N�g�̐ݒ�
				pPC->display->image(mappedImage);	// �摜�\��
// #IK080610-03 ��ػ���F�����ʉ摜�����{�\������邱�Ƃ�����
				pPC->resetDisplayZoom(m_CameraIndex);
			}
			else{
				pPC->display->image(pbw);		// �摜�\��
			}
		}
		if(display & CMVS8200::eDisplayText1){
			pPC->tablet->sketch().erase();
			pPC->display->eraseSketch(ccDisplay::eClientCoords);
			pPC->display->eraseSketch(ccDisplay::eImageCoords);
			pPC->display->eraseSketch(ccDisplay::eDisplayCoords);
			ccUIFormat txtFormat(0, ccUIFormat::eTopLeft );
			ccUIFormat txtFormat2(0, ccUIFormat::eCenter );
			CString	msg;
			msg.Format("time = %d ms %s %s Pixel : %d(%d) Threshold : %d",
						(int)time.msec(),
						r ? "Detected" : "Not Found", 
						dark ? "Dark" : "Light", 
						pcount,judgecount,threshold);
			pPC->tablet->draw((char*)LPCSTR(msg), cc2Vect(10,10),
						ccColor::green,ccColor::pass,txtFormat);
			pPC->display->drawSketch(pPC->tablet->sketch(), ccDisplay::eDisplayCoords);
			pPC->tablet->sketch().erase();
		}
		if(display & CMVS8200::eDisplayGraphic1){	
			pPC->display->drawSketch(pPC->tablet->sketch(), ccDisplay::eClientCoords);
			pPC->tablet->sketch().erase();

			pPC->tablet->draw(ccLineSeg(cc2Vect(-255,-150),cc2Vect(255,-150)),ccColor::green);
			double	k=1;
			double	max=0;
			for(i=0;i<256;i++){
				if(max < histogram[i])	max = histogram[i];
			}
			if(max > 0)	k = 300.0/max;
			double	x0=-255,y0=-150,x1,y1;
			for(i=0;i<256;i++){
				x1 = -255 + i*2;
				y1 = histogram[i] * k - 150;
				pPC->tablet->draw(ccLineSeg(cc2Vect(x0,y0),cc2Vect(x1,y1)),ccColor::green);
				x0 = x1; y0 = y1;
			}
			pPC->tablet->draw(ccLineSeg(cc2Vect(x0,y0),cc2Vect(255,-150)),ccColor::green);
			x0 = threshold * 2;
			x0 += (-255);
			pPC->tablet->draw(ccLineSeg(cc2Vect(x0,-160),cc2Vect(x0,150)),ccColor::green);
			pPC->display->drawSketch(pPC->tablet->sketch(), ccDisplay::eClientCoords);
			pPC->tablet->sketch().erase();
		}
	}
	catch(ccException &exc){
		ccUIFormat txtFormat(0, ccUIFormat::eTopLeft );
		pPC->tablet->draw(exc.message().c_str(), cc2Vect(10,10),
						ccColor::green,ccColor::pass,txtFormat);
		pPC->display->drawSketch(pPC->tablet->sketch(), ccDisplay::eDisplayCoords);
		pPC->tablet->sketch().erase();
		return false;
	}
	return	r;
}




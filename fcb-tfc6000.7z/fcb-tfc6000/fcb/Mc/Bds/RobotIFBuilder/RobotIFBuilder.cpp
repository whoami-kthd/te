// RobotIFBuilder.cpp: CRobotIFBuilder �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <mcc.h>
#include "RobotIFBuilder.h"
#include "RobotIFDefine.h"
#include "..\BND\bndiodef.h"


#define	REQ_TIME_OUT_MOVING			10000	// time waiting signal 'Moving' in 30s
#define	REQ_TIME_OUT_LAN_MSG		10000	// time waiting receive LAN message in 60s

enum	RobIFSnsInList{
	eSnsInDummy = 0,
	eSnsInMoving,
	eSnsInEndOfLot,
	eSnsInErr,
	eSnsInMax,
};
enum	RobIFSnsOutList{
	eSnsOutDummy = 0,
	eSnsOutReady,
	eSnsOutReadyToLoad,
	eSnsOutReadyToUnload,
	eSnsOutWaferIn,
	eSnsOutComplete,
	eSnsOutErr,
	eSnsOutMax,
};
static OrdinarySnsTBL	ROBIF_SNS_IN_TBL[]	= {
//	Sensor No				time out	ON delay	Err
	{DINTBL_DummyB			,	0,			0,		0},
	{IO_Moving_SNS_IN		,	1000,		0,		0},
	{IO_EnOfLot_SNS_IN		,	1000,		0,		0},
	{IO_Error_SNS_IN		,	1000,		0,		0},
//	{DINTBL_85				,	1000,		0,		0},
//	{DINTBL_86				,	1000,		0,		0},
//	{DINTBL_87				,	1000,		0,		0},
};
static OrdinaryOutTBL	ROBIF_SNS_OUT_TBL[]	= {
	// Address
	{DINTBL_DummyB},
	{IO_Ready_SNS_OUT},
	{IO_ReadyToLoad_SNS_OUT},
	{IO_ReadyToUnload_SNS_OUT},
	{IO_WaferIn_SNS_OUT},
	{IO_Complete_SNS_OUT},
	{IO_Error_SNS_OUT},
};
static VacTBL	BDS_VACTBL[] = {
	// �ݻA����,				�ݻB����,					�z���o��,					�z���j��,				���A, ���B(��۰����)�CON�ިڲA�CON�ިڲB, OFF�ިڲA�COFF�ިڲB, �װA,				�װB
	{ DINTBL_DummyB,			-1,							DOUTTBL_DummyB,				DOUTTBL_DummyB,			100,		  50,		100,		100,		0,		0,		/* ��Őݒ� */0,						/* ��Őݒ� */0},
	{ IO_BgStgVacuum_SNS_IN,	-1,							IO_BgStgVacuum_OUT,			IO_BgStgVacuumD_OUT,	1000,		 500,		0,			0,			0,		0,		CRobotIFBuilder::Err_BgStgVacuum,	CRobotIFBuilder::Err_BgStgVacuum	},
};

//////////////////////////////////////////////////////////////////////
// Contructor/Decontructor
//////////////////////////////////////////////////////////////////////
CRobotIFBuilder::CRobotIFBuilder()
{

}

CRobotIFBuilder::~CRobotIFBuilder()
{

}

CRobotIFBuilder::CRobotIFBuilder(int class_id,			// class Id: BDS_ID
								 int pinIdx,
								 int myErrStart,
								 int lanIFErrStart
								 ):
	m_robotLANIF(class_id,lanIFErrStart),
	EvReqAutoStop(FALSE, TRUE) //#MI130418	�����^�]�ŃX�g�b�v�������Ȃ�
// #KS20130531-03 [�s�] ���{�b�gIF���ALoader Auto �������Ȃ�
	, m_LoaderAuto(true)
{
    // Init error
	this->ErrorInit(myErrStart);
	this->m_err.Initinstance(class_id,myErrStart);

	// Init for Lift-Pin motor
	this->mtLiftPin.InitInstance(class_id, pinIdx);
	m_liftPinUpPos	= -1.0;
	m_liftPinDwnPos	= 0.0;
	m_alignAngle	= 0.0;
	// Init for Vacumm of Bg Stg
	this->vacBgStg.Initinstance(class_id,	&BDS_VACTBL[1]);
	
	// Init input sensor
	this->m_inMoving.Initinstance( class_id, &ROBIF_SNS_IN_TBL[eSnsInMoving] );
	this->m_inEndOfLot.Initinstance( class_id, &ROBIF_SNS_IN_TBL[eSnsInEndOfLot] );
	this->m_inError.Initinstance( class_id,&ROBIF_SNS_IN_TBL[eSnsInErr] );
	// Init output sensor
	this->m_outReady.Initinstance( class_id, &ROBIF_SNS_OUT_TBL[eSnsOutReady] );
	this->m_outReadyToLoadWF.Initinstance( class_id, &ROBIF_SNS_OUT_TBL[eSnsOutReadyToLoad] );
	this->m_outReadyToUnloadWF.Initinstance( class_id, &ROBIF_SNS_OUT_TBL[eSnsOutReadyToUnload] );
	this->m_outWaferIn.Initinstance( class_id, &ROBIF_SNS_OUT_TBL[eSnsOutWaferIn] );
	this->m_outComplete.Initinstance( class_id, &ROBIF_SNS_OUT_TBL[eSnsOutComplete] );
	this->m_outError.Initinstance( class_id, &ROBIF_SNS_OUT_TBL[eSnsOutErr] );

	// Create main thread
	ActionMTC.Create(this,(unsigned int (__cdecl *)(void *))ActionFunc/*,THREAD_PRIORITY_TIME_CRITICAL*/);
	// Create sub thread
	for(int i=0;i < eThread_Max;i++){
		ActionSMTC[i].Create(this,(unsigned int (__cdecl *)(void *))ActionFunc);
	}

	// Init Event
	this->EvAutoStart.ResetEvent();
	this->EvReqAutoStop.ResetEvent();
	this->EvFinish.ResetEvent();
	this->EvAutoFinished.ResetEvent();
	this->EvBndReqInsertFrm.ResetEvent();
	this->EvBndReqCarryOutFrm.ResetEvent();
	this->EvSubInfoOK.ResetEvent();
	this->EvSubInfoNG.ResetEvent();
	this->EvPickedDataOK.ResetEvent();
	this->EvPickedDataNG.ResetEvent();
	this->EvCloseLANConnection.ResetEvent();
	this->EvFinRecvWFAG.ResetEvent();
	this->EvFinRecvWFIF.ResetEvent();
	this->EvFailRecvLAN.ResetEvent();
	this->EvStopWaiting.ResetEvent();

	this->pEvBndFinInsertFrm		= NULL;
	this->pEvBndFailInsertFrm		= NULL;
	this->pEvBndFinCarryOutFrm		= NULL;
	this->pEvBndFailCarryOutFrm		= NULL;
	this->pEvFrmSetOnBgStg			= NULL;
	this->pEvBndCarryOutStartOK		= NULL;

	this->pIsAbleToGoUp				= NULL;
	this->pSendWFIFToHOST			= NULL;
	this->pSendPickedMappingData	= NULL;
	this->m_isConnected				= false;
	this->m_frameLeft				= 3;
//	this->m_reqTimeOut				= REQ_TIME_OUT_MOVING;		// initialize time waiting signal 'Moving'
//	this->m_reqTimeOutLAN			= REQ_TIME_OUT_LAN_MSG;		// initialize time waiting receive LAN message
}
///////////////////////////////////////////////////////////////////////
// Init
//
BOOL CRobotIFBuilder::Init()
{
	int	r=TRUE;
	// Start main thread
	r = ActionMTC.ActionStart(CmdAutoRun, NULL, NULL, FALSE);
	// Start sub thread
	if(r){
		r = ActionSMTC[eLANThread].ActionStart(CmdRobotLANInterfaceThread, NULL, NULL, FALSE);
	}

	return	r;
}
///////////////////////////////////////////////////////////////////////
// Auto Init
//
bool CRobotIFBuilder::AutoInit()
{
	return true;
}

// �f�o�C�X�̏�����
void CRobotIFBuilder::DeviceInit(){
	// ���ʂ̃f�o�C�X�̏��������s�������ꍇ�͂�����
	// �R���X�g���N�^�ŏ���������Ǝ��ʂ��̒��S
//	CSingleLock	S(&MemSema, TRUE);
	this->m_outReady.Out(false);
	this->m_outReadyToLoadWF.Out(false);
	this->m_outReadyToUnloadWF.Out(false);
	this->m_outWaferIn.Out(false);
	this->m_outComplete.Out(false);
	this->m_outError.Out(false);
}
///////////////////////////////////////////////////////////////////////
// Error Init
//
void CRobotIFBuilder::ErrorInit(int myErrStart){
	ROBIF_SNS_IN_TBL[eSnsInMoving].error		= myErrStart + Err_MovingSns;
	ROBIF_SNS_IN_TBL[eSnsInEndOfLot].error		= myErrStart + Err_EndOfLotSns;
	ROBIF_SNS_IN_TBL[eSnsInErr].error			= myErrStart + Err_ErrorSns;
	BDS_VACTBL[Err_BgStgVacuum].ErrorA			= myErrStart + Err_BgStgVacuum;
	BDS_VACTBL[Err_BgStgVacuum].ErrorB			= myErrStart + Err_BgStgVacuum;
}
///////////////////////////////////////////////////////////////////////
// �ڰтƗL�����o�ݻ�̏������
//
bool CRobotIFBuilder::FrameExistsUpdate(bool errOut){
	bool r = true;
	bool detect1 = true;
	bool detect2 = true;
	bool detect3 = true;

#if !GPDEBUG
	// �_�~�[�łȂ���΋z����ԃ`�F�b�N
	if(r && !this->isAging){
		// �_�~�[�ł�Sns�ł��w�ߏ�Ԃ��A���Ă���̂ŁA
		// �z����ԂŗL�����`�F�b�N����̂͊댯
		bool detect = false;
		// �{���f�B���O�X�e�[�W�z����Ԃ��擾����B
		r = this->vacBgStg.Sns(true, detect);
		// �z�����Ă���̂Ƀ{���f�B���O�X�e�[�W�̏�Ԃ��u���v�ł����
		if(r && !(*this->pHasAFrame)(eOnWfBgStg) && detect){
			// �{���f�B���O�X�e�[�W�̏�Ԃ�L��ɐݒ肷��B
			(*this->pSetAFrame)(eOnWfBgStg, true);
			this->m_outWaferIn.Out(true);	//#MI130414
		}
	}
#endif
	return(r);
}

//////////////////////////////////////////////////////////////////////
// Main operation
//
UINT CRobotIFBuilder::ActionFunc(MTCtrl	*pParam)
{
	MTCtrl	*pMTC=(MTCtrl *)pParam;	// pointer of MTCtrl object
	CRobotIFBuilder *pRIB = (CRobotIFBuilder *)pMTC->GetpMCC();
	
	int	Command,Parameter;
	int	r;
	BOOL	MainThred=FALSE;
	
	while (TRUE){
		pMTC->WaitForCommand(Command,Parameter);		// waiting for command direction
		if(Command == MCCStd::CmdKill)	break;			// end command
		r = TRUE;
		
		// Classify command 
		if (CmdAutoRun == Command) {
			r = pRIB->AutoRun();
		} else if (CmdRobotLANInterfaceThread == Command) {
			r = pRIB->RobotLANInterfaceThread();
		} else {
			// Do nothing
		}
		pMTC->CommandEnd(r);		// report result
	}

	pMTC->CommandEnd(TRUE);			// report result
	return	0;
}


//////////////////////////////////////////////////////////////////////
// AutoRun operation
//
bool CRobotIFBuilder::AutoRun()
{
	BOOL r = true;			// #KI130317

	enum {
		WaitCnt = 5,		// Maximum number event
	};

	CSyncObject *ppObjects[WaitCnt] = {0};			
	ppObjects[0]	= &EvFinish;					// request finish from MCC
	ppObjects[1]	= &EvReqAutoStop;				// request stop from BND
	ppObjects[2]	= &EvAutoStart;					// automatic opreration start
	ppObjects[3]	= &EvBndReqInsertFrm;			// request insert frame from BND
	ppObjects[4]	= &EvBndReqCarryOutFrm;			// request carry out frame from BND
	CMultiLock	M(ppObjects,WaitCnt);


	for (; ;) {
#if GPDEBUG
		{
			int flag = 0;
			if (1 == flag){							// auto stop
				EvReqAutoStop.SetEvent();
				flag = 0;
			} else if (2 == flag) {					// auto start
				EvAutoStart.SetEvent();
				flag = 0;
			} else if (3 == flag) {					// request insert board
				EvBndReqInsertFrm.SetEvent();
				flag = 0;
			} else if (4 == flag) {					// request carry out board
				EvBndReqCarryOutFrm.SetEvent();
				flag = 0;
			} else if (5 == flag) {					// request finish
				EvFinish.SetEvent();
				flag = 0;
			} else {
				flag = 0;
			}
		}
#endif
		int i = M.Lock(INFINITE, FALSE);
		M.Unlock();
		i -= WAIT_OBJECT_0;		// ?????????????
		CString msg; //#MI130401
		switch (i) {
		case 0:		// request finish
			r	= false;
			msg.Format("RobotBuilder::AutoRun(): Request finish AutoRun\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			EvAutoFinished.SetEvent();
			break;

		case 1:		// request stop
			msg.Format("RobotBuilder::AutoRun(): Request stop AutoRun\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			EvReqAutoStop.ResetEvent();	//#MI130418	�����^�]�ŃX�g�b�v�������Ȃ�
			EvAutoFinished.SetEvent();

			r = false;

			{
				CString msg;
				msg.Format("Error %s(%d) Request stop AutoRun = %d\n", __FILE__, __LINE__, i);
				this->m_err.LogSaveNFL(msg);
			}

			break;

		case 2:		// auto start
			msg.Format("RobotBuilder::AutoRun(): Request start AutoStart\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
// #KS20130413-06(S) [�s�]�C�x���g���Z�b�g�s��
			this->EvReqAutoStop.ResetEvent();
			this->EvAutoFinished.ResetEvent();
// #KS20130413-06(E)
	 		r = true;	//#MI130414
// #KS20130531-02(S) [�s�] [BDS](1731)Robot I/F ConnectingFailed. �Ή�
/*
			// Connect to Server
			if (INVALID_SOCKET == m_robotLANIF.m_clientSocket) {
				r = m_robotLANIF.ConnectServer();
			}

			// Turn On SystemReady signal
			if (r) {
				m_isConnected = true;
				m_outReady.Out(true);
			} else {
				m_robotLANIF.DisconnectServer();
			}
*/
// #KS20130531-02(E)
			break;
		case 3:		// request insert frame
			msg.Format("RobotBuilder::AutoRun(): Request insert frame \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			r = true;
//			if(this->pSetAFrame){	// ����{���f�B���O�X�e�[�W�ɏ���� //#MI130418���]�X�^�[�g�^�C�~���O�ύX
//				(*this->pSetAFrame)(eOnWfBgStg, true);
//			}		
//			if(r && this->pEvFrmSetOnBgStg){	// ��s���]�X�^�[�g�n�j
//				this->pEvFrmSetOnBgStg->SetEvent();
//			}
// #KS20130531-03(S) [�s�] ���{�b�gIF���ALoader Auto �������Ȃ�
			if (r && !GetLoaderAuto()) {
				this->m_err.PutError(Err_LoaderAutoOff);
				r = false;
			}
// #KS20130531-03(E)
			// �@ �E�F�n����{���f�B���O�X�e�[�W�ɓ���
			if(r){
				{
					int	r2 = TRUE;
					bool isCmdOn;
					r2 = this->vacBgStg.Sts(true, isCmdOn);
					if(!r2 || isCmdOn){
						CString estr;
						estr.Format( "EvMngReqSetWaferOnBgStg:�z���w�ߏ��ON�͕� %d, %d", r, isCmdOn);
						this->m_err.LogSaveNFL(estr);
						r2 = this->vacBgStg.Act(false);	// �z���j��
						::Sleep(100);
					}
				}
				if(r){	// ���t�g�s���㏸
					r = this->LiftPinUp();
				}
				if(r){	// �ʐM�J�n
					r = this->LoadSub();
				}
				if(r && this->pSetAFrame){	//#MI130418���]�X�^�[�g�^�C�~���O�ύX
					(*this->pSetAFrame)(eOnWfBgStg, true);
				}		
				if(r && this->pEvFrmSetOnBgStg){	// ��s���]�X�^�[�g�n�j
					this->pEvFrmSetOnBgStg->SetEvent();
				}
				if(r){	// ���~�O�Ƀ{���f�B���O�X�e�[�W���z��ON������B
					r = this->vacBgStg.Out(true,true);
				}
				if(r){	// ���t�g�s�����~
					r = this->LiftPinDown();
				}
				if(!r){
					// ���s�����̂Ń{���f�B���O�X�e�[�W�Ɋ�͂Ȃ�
					if(this->pSetAFrame){
						(*this->pSetAFrame)(eOnWfBgStg, false);
					}
				}
			}			
			// Set event Finish/Failure insert frame
			if (r) {
				msg.Format("RobotBuilder::LoadSub() Execute successful \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
				}
				#if !Release
					TRACE(msg);
				#endif
				// Permit carry out to BND
				pEvBndCarryOutStartOK->SetEvent();
				pEvBndFinInsertFrm->SetEvent();
			} else {
				msg.Format("RobotBuilder::LoadSub() Execute unsuccessful \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
				}
				#if !Release
					TRACE(msg);
				#endif
				pEvBndFailInsertFrm->SetEvent();
			}
			break;

		case 4:		// request carry out frame
			msg.Format("RobotBuilder::AutoRun(): Request carry out frame \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			r = true;
			if(r){
				{
					int	r2 = TRUE;
					bool isCmdOn;
					r2 = this->vacBgStg.Sts(true, isCmdOn);
					if(!r2 || isCmdOn){
						CString msg;
						msg.Format( "EvMngReqCarryOutWafer:�z���w�ߏ��ON�͕� %d, %d", r, isCmdOn);
						this->m_err.LogSaveNFL(msg);
						r2 = this->vacBgStg.Act(false);	// �z���j��
						::Sleep(100);
					}
				}
				if(r){
					r = this->LiftPinUp();
				}
				if (r) {
					r = this->UnloadSub();
				}
				if(r){	// ����{���f�B���O�X�e�[�W���烍�{�b�g�A�[���ցB
					(*this->pSetAFrame)(eOnWfBgStg, false);
				}
			}
			// Set event Finish/Failure carry out frame
			if (r) {
				msg.Format("RobotBuilder::UnloadSub() execute successful \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
					this->LogRobotInterface(0);
				}
				#if !Release
					TRACE(msg);
				#endif
				pEvBndFinCarryOutFrm->SetEvent();
			} else {
				msg.Format("RobotBuilder::UnloadSub() execute unsuccessful \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
					this->LogRobotInterface(0);
				}
				#if !Release
					TRACE(msg);
				#endif
				pEvBndFailCarryOutFrm->SetEvent();
			}
			break;

		default:
			// Do nothing
			break;
		}
	}
	return (r)?true:false;	// #KI130317
}


//////////////////////////////////////////////////////////////////////
// LAN interface thread
//
bool CRobotIFBuilder::RobotLANInterfaceThread()
{
	bool	r = true;
	char	recvBuf[MAX_LENGTH_MESSAGE];			// buffer contain received message
	int		recvBufLen = MAX_LENGTH_MESSAGE;	
	int		recvResult;
	SOCKET	sock;
	CString msg; //#MI130401
	
	for (;;) {
		if (false == this->m_isConnected) {
// #KS20130316-01[�s�]CPU100%
			::Sleep(100);
			continue;							// connection is not setup
		}
		
		// Check connection to server
		sock = m_robotLANIF.m_clientSocket;
		if (INVALID_SOCKET == sock) {			
			EvCloseLANConnection.SetEvent();
// #KS20130413-02(S) [����]�ʐM�ؒf���P
//			break;	//�����Ńu���[�N������߂��Ă���̂��H
			this->m_isConnected = false;
			continue;
// #KS20130413-02(E)
		}
				
		// Reset buffer
		memset(recvBuf, 0, MAX_LENGTH_MESSAGE);

		// Receive message
		recvResult = m_robotLANIF.RecvMessage(sock, recvBuf, recvBufLen, 0);
			
		// Classify message
		if (recvResult > 0) {					// normal message
			// Parse message
			if (true == m_robotLANIF.ParseMessage(recvBuf, recvResult)) {	
				// Set event follow receive message	
				if (WFIF_MESSAGE == m_robotLANIF.GetHeaderResMessage()) {
					EvFinRecvWFIF.SetEvent();					// set event receive WFIF
					::Sleep(500);	
					EvSubInfoOK.SetEvent();	// TODO WFIF is OK �z�X�g�ɐڑ�������߂�
					#if GPDEBUG
					{
						int flag = 1;
						::Sleep(1000);		// sleep to ensure send WFIF to HOST finished
						if (1 == flag) {			// WFIF is OK
							EvSubInfoOK.SetEvent();
							flag = 0;
						} else if (2 == flag) {		// WFIF is NG
							EvSubInfoNG.SetEvent();
							flag = 0;
						}  else {	
							flag = 0;
						}
					}
					#endif

				} else if (WFAG_MESSAGE == m_robotLANIF.GetHeaderResMessage()) {
					EvFinRecvWFAG.SetEvent();					// set event receive WFAG
				} else {
					// Do nothing
				}
			} else {
				EvFailRecvLAN.SetEvent();						// set event receive message failure
			}

		} else {
			// Go to next receive message
		}
		
		// Check connection close
		int nError = WSAGetLastError();
// #KS20130413-02 [����]�ʐM�ؒf���P
//		if (WSAECONNRESET == nError) {
		if (0 == recvResult || WSAECONNRESET == nError) {
			EvCloseLANConnection.SetEvent();
			m_robotLANIF.DisconnectServer();
			m_isConnected = false;
			msg.Format("RobotBuilder::RobotLANInterfaceThread()�R�l�N�V�����̐ؒf \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
		}
	}

	return r;
}


//////////////////////////////////////////////////////////////////////
// Load substrate wafer
//
bool CRobotIFBuilder::LoadSub()
{
	BOOL r = true;			// #KI130317
	bool IsLoaderError		= false;
	bool IsLoaderEndOfLot	= false;

	enum {
		eOK		= 0,
		eNG,
	};

	enum {
		WaitCnt = 6,		// Maximum number event
	};

	// Status of each operation
	bool IsWaitWFIF			= true;		// BDS is waiting for WFIF from Loader
	bool IsWaitWFAG			= false;	// BDS is waiting for WFAG from Loader
	bool IsRecvWFAG			= false;	// BDS received WFAG from Loader
	int	 replyS12			= -1;		// Receive reply S12 from HOST

	CString msg; //#MI130401
	
	CSyncObject *ppObjects[WaitCnt] = {0};			
	ppObjects[0]	= &EvFinRecvWFIF;					// receive WFIF successful
	ppObjects[1]	= &EvFinRecvWFAG;					// receive WFAG successful
	ppObjects[2]	= &EvFailRecvLAN;					// receive message via LAN unsuccessful
	ppObjects[3]	= &EvCloseLANConnection;			// connection is closed
	ppObjects[4]	= &EvReqAutoStop;					// request stop from BND
	ppObjects[5]	= &EvStopWaiting;					// request stop when press "Stop" button from TP
// #KS20130413-03(S) [���P]LAN��M�C�x���g������
	EvFinRecvWFIF.ResetEvent();
	EvFinRecvWFAG.ResetEvent();
	EvFailRecvLAN.ResetEvent();
	EvCloseLANConnection.ResetEvent();
// #KS20130413-03(E)

	CMultiLock	M(ppObjects,WaitCnt);

	msg.Format("RobotBuilder::LoadSub() Start ... \n");
	if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
		this->m_err.LogSaveNFL(msg);
	}
	#if !Release
		TRACE(msg);
	#endif

	// Turn ON 'SystemReady'
	if (r) {
		r = this->m_outReady.Out(true);

		if (r) {
			msg.Format("RobotBuilder::LoadSub() Turn ON 'SystemReady' \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
		}
	}
	// Turn ON 'ReadyToLoadWF'
	if (r) {
		r = this->m_outReadyToLoadWF.Out(true);

		if (r) {
			msg.Format("RobotBuilder::LoadSub() Turn ON 'ReadyToLoadWF' \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
		}
	}
	// Check connect to Server
	if (INVALID_SOCKET == m_robotLANIF.m_clientSocket) {
		EvCloseLANConnection.ResetEvent();		// reset event when connection is closed
		r = m_robotLANIF.ConnectServer();
		if (r) {
			m_isConnected = true;
		} else {
			m_robotLANIF.DisconnectServer();
			this->m_outReadyToLoadWF.Out(false);	//#MI130415
			this->LogRobotInterface(0);
			return false;
		}
	}		
	// Check end of lot in Loader #MI130418End of Lot�M���Ď��^�C�~���O�ύX
//	if (r) {
//		r = this->m_inEndOfLot.IsDetected(IsLoaderEndOfLot);
//		#if GPDEBUG
//			::Sleep(500);
//			IsLoaderEndOfLot = false;
//		#endif
//		if ( r && (true == IsLoaderEndOfLot)) {
//			msg.Format("RobotBuilder::LoadSub() signal 'EndOfLot' of Loader is ON \n");
//			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
//				this->m_err.LogSaveNFL(msg);
//				this->LogRobotInterface(0);
//			}
//			#if !Release
//				TRACE(msg);
//			#endif
//			this->m_err.PutError(Err_EndOfLot);
//			r = false;
//		}
//	}
	for (; r ;) {
		int i;

		// Check error signal of Loader
		r = this->m_inError.IsDetected(IsLoaderError);
		#if GPDEBUG
			::Sleep(500);
			IsLoaderError = false;
		#endif
		if ( r && (true == IsLoaderError)){
			msg.Format("RobotBuilder::LoadSub() signal 'Error' of Loader is ON \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			this->m_err.PutError(Err_LoaderError);
			r = false;
			break;
		}
		// Check end of lot in Loader #MI130418End of Lot�M���Ď��^�C�~���O�ύX
		if (r) {
			r = this->m_inEndOfLot.IsDetected(IsLoaderEndOfLot);
			#if GPDEBUG
				::Sleep(500);
				IsLoaderEndOfLot = false;
			#endif
			if ( r && (true == IsLoaderEndOfLot)) {
				msg.Format("RobotBuilder::LoadSub() signal 'EndOfLot' of Loader is ON \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
					this->LogRobotInterface(0);
				}
				#if !Release
					TRACE(msg);
				#endif
				this->m_err.PutError(Err_EndOfLot);
				r = false;
				break;
			}
		}
// #KS20130413-04(S) [���P]LAN�p�f�o�b�O���b�Z�[�W
#if !Release
		if (IsWaitWFIF) {
			TRACE("\nWaiting oWFIF:<ID>\n");
		} else if (IsWaitWFAG) {
			TRACE("\nWaiting oWFAG:\n");
		}
#endif
// #KS20130413-04(E)

		// Waiting for event
//		i = M.Lock(TimeOut_LAN_Message, FALSE);
		i = M.Lock((long)(this->m_reqTimeOutLANMsg), FALSE);	//#MI130418�^�C���A�E�g�ݒ�Ή�
		M.Unlock(); 

		if(i == WAIT_TIMEOUT){
			r = false;
			msg.Format("RobotBuilder::LoadSub() waiting LAN message is timeout \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			this->m_err.PutError(Err_LANRecvMesTimeOut);
			break;
		}

		i -= WAIT_OBJECT_0;
		// Received WFIF
		if ((0 == i) && (IsWaitWFIF)) {
			//////////////////////////////////////////////////
			// Wait oWFIF from Loader by LAN interface
			// Send WFIF to Host by SECS
			CString			oWFIFData;
			msg.Format("RobotBuilder::LoadSub() Receive oWFIF from Loader \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif

			if (r) {
				// get data from robot LAN
				r = m_robotLANIF.GetWFIFResMessage(oWFIFData);
			}

			if (r) {
				// send data to Host
// #KS20130416-01(S) [�ǉ�]SECS��}�b�s���O				
//				r = (*this->pSendWFIFToHOST)(oWFIFData);
				BOOL ret = (*this->pSendWFIFToHOST)(oWFIFData);	// �����ŕԎ���҂�
				IsWaitWFIF = false;
				replyS12 = (ret) ? eOK : eNG;
				if (!ret) {
					this->m_err.PutError(Err_SendS12ToHost);
				}
#if 0
// #KS20130416-01(E)

				if (r) {
					EvSubInfoOK.SetEvent();		//TuVV: temporary because no�@host
					
					IsWaitWFIF = false;

					msg.Format("RobotBuilder::LoadSub() Send WFIF to HOST successful \n");	//#MI130401
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
					}
					#if !Release
						TRACE(msg);
					#endif

					// Wait reply from HOST
					CSyncObject *ppObjects[2] = {0};			
					ppObjects[0]	= &EvSubInfoOK;				// report data OK
					ppObjects[1]	= &EvSubInfoNG;				// report data NG

					CMultiLock	M(ppObjects,2);
//					int i = M.Lock(TimeOut_HOST_S12, FALSE);
					int	i = M.Lock((long)(this->m_reqTimeOutHost), FALSE);	//#MI130418�^�C���A�E�g�ݒ�Ή�
					M.Unlock();

					// Check time out
					if (i == WAIT_TIMEOUT) {
						msg.Format("RobotBuilder::LoadSub() waiting HOST reply S12 is timeout \n");
						if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
							this->m_err.LogSaveNFL(msg);
							this->LogRobotInterface(0);
						}
						#if !Release
							TRACE(msg);
						#endif

						r = false;
						this->m_err.PutError(Err_SendS12ToHost);
						break;
					}

					i -= WAIT_OBJECT_0;

					if (i == 0) {
						replyS12 = eOK;
						msg.Format("RobotBuilder::LoadSub() Receive WFIF:OK from HOST \n");
						if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
							this->m_err.LogSaveNFL(msg);
						}
						#if !Release
							TRACE(msg);
						#endif
					}else if (i == 1) {
						replyS12 = eNG;
						msg.Format("RobotBuilder::LoadSub() Receive WFIF:NG from HOST \n");
						if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
							this->m_err.LogSaveNFL(msg);
						}
						#if !Release
							TRACE(msg);
						#endif
					}
				}else {
					msg.Format("RobotBuilder::LoadSub() Send WFIF to HOST fail \n");
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
						this->LogRobotInterface(0);
					}
					#if !Release
						TRACE(msg);
					#endif
					this->m_err.PutError(Err_SendS12ToHost);
					break;
				}
// #KS20130416-01 [�ǉ�]SECS��}�b�s���O
#endif
			}
		} 
		// Received WFAG after reply OK from HOST
		else if ((1 == i) && IsWaitWFAG) {
			//////////////////////////////////////////////////
			// Wait oWFAG (ask notch angle)
			// Send aWFAG to Loader, turn ON 'WaferIn' 
			char pBuf[MAX_LEN_REQ_WFAG];
			int  lenBuf;

			msg.Format("RobotBuilder::LoadSub() Receive oWFAG from Loader \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif

			m_robotLANIF.SetHeaderReqMessage(WFAG_MESSAGE);
			
			r = m_robotLANIF.BuildMessage(pBuf, &lenBuf);
			
//			if (r && (MAX_LEN_REQ_WFAG == lenBuf)) {	//#MI130411
			if (r) {
				if (SOCKET_ERROR != m_robotLANIF.SendMessage(m_robotLANIF.m_clientSocket, pBuf, lenBuf, 0)) {
					IsWaitWFAG = false;
					IsRecvWFAG = true;

					msg.Format("RobotBuilder::LoadSub() Send aWFAG to Loader successful \n");
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
						this->LogRobotInterface(0);
					}
					#if !Release
						TRACE(msg);
					#endif

					if (r) {
						msg.Format("RobotBuilder::LoadSub() Turn ON 'WaferIn' successful \n");
						if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
							this->m_err.LogSaveNFL(msg);
							this->LogRobotInterface(0);
						}
						#if !Release
							TRACE(msg);
						#endif
					} else {
						msg.Format("RobotBuilder::LoadSub() Turn ON 'WaferIn' unsuccessful \n");
						if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
							this->m_err.LogSaveNFL(msg);
							this->LogRobotInterface(0);
						}
						#if !Release
							TRACE(msg);
						#endif
					}					
				} else {
					msg.Format("RobotBuilder::LoadSub() Send aWFAF to Loader unsuccessful \n");
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
						this->LogRobotInterface(0);
					}
					#if !Release
						TRACE(msg);
					#endif
					r = false;
				}
			} else {
				r = false;
			}
			break;
			
		}
		// Receive message is invalid
		else if (2 == i) {
			msg.Format("RobotBuilder::LoadSub() Message received from Loader is invalid \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
			TRACE(msg);
			#endif
			r = false;
			break;
		}
		// Close connection
		else if (3 == i) {
			msg.Format("RobotBuilder::LoadSub() Connection is close \n");	//#MI130401
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			r = false;
			break;
		}
		// Request stop from BND or press Stop key
		else if ((4 == i) || (5 == i)) {
			msg.Format("RobotBuilder::LoadSub() Request stop LoadSub() \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			r = false;
//			EvReqAutoStop.ResetEvent();	//#MI130418	�����^�]�ŃX�g�b�v�������Ȃ�
//			EvStopWaiting.ResetEvent();	//#MI130418	�����^�]�ŃX�g�b�v�������Ȃ�
			break;
		} else {
			// Do nothing
		}

		// If receive reply S12 OK from HOST
		if (r && (replyS12 == eOK)) {
			char pBuf[MAX_LEN_REQ_WFIF];
			int  lenBuf;

			replyS12	= -1;

			m_robotLANIF.SetHeaderReqMessage(WFIF_MESSAGE);
			m_robotLANIF.SetStatusReqMessage(WFIF_OK);
			
			r = m_robotLANIF.BuildMessage(pBuf, &lenBuf);
			
//			if ((TRUE == r) && (MAX_LEN_REQ_WFIF == lenBuf)) {// #KI130317
			if (TRUE == r) {	//#MI130411
				if (SOCKET_ERROR != m_robotLANIF.SendMessage(m_robotLANIF.m_clientSocket, pBuf, lenBuf, 0)) {
					IsWaitWFAG = true;
					msg.Format("RobotBuilder::LoadSub() Send aWFIF:OK to Loader successful \n");
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
						this->m_err.LogSaveNFL(pBuf);	//#MI130410
					}
					#if !Release
						TRACE(msg);
						TRACE(pBuf);
					#endif
				} else {
					msg.Format("RobotBuilder::LoadSub() Send aWFIF:OK to Loader unsuccessful \n");		
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
						this->m_err.LogSaveNFL(pBuf);	//#MI130410
					}
					#if !Release
						TRACE(msg);
					#endif
					r = false;
					break;
				}
			} else {
				r = false;
				break;
			}

			// Temporary: Sub data is set for BgStg after host mapping data

			if(r && this->pEvFrmSetOnBgStg/*(host mapping ok)*/){
				this->pEvFrmSetOnBgStg->SetEvent();
			}
		}
		// If receive reply S12 NG from HOST
		else if (r && (replyS12 == eNG)) {
			char pBuf[MAX_LEN_REQ_WFIF];
			int  lenBuf;

			replyS12 = -1;

			m_robotLANIF.SetHeaderReqMessage(WFIF_MESSAGE);
			m_robotLANIF.SetStatusReqMessage(WFIF_NG);
			
			r = m_robotLANIF.BuildMessage(pBuf, &lenBuf);
			
//			if ((TRUE == r) && (MAX_LEN_REQ_WFIF == lenBuf)) {// #KI130317
			if (TRUE == r) {	//#MI130411
				if (SOCKET_ERROR != m_robotLANIF.SendMessage(m_robotLANIF.m_clientSocket, pBuf, lenBuf, 0)) {
					IsWaitWFAG		 = false;
					msg.Format("RobotBuilder::LoadSub() Send aWFIF:NG to Loader successful \n");
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
					}
					#if !Release
						TRACE(msg);
					#endif
				} else {
					msg.Format("RobotBuilder::LoadSub() Send aWFIF:NG to Loader unsuccessful \n");
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
					}
					#if !Release
						TRACE(msg);
					#endif
				}
			}
			r = false;
		}
	}

	// If receive WFAG wait Moving signal ON->OFF
	if (r && IsRecvWFAG) {				
		r = WaitMovingLoad();
	}
	this->m_outReadyToLoadWF.Out(false);	//#MI130414
	return (r)?true:false;// #KI130317
}


//////////////////////////////////////////////////////////////////////
// Waiting for load substrate wafer
//
bool CRobotIFBuilder::WaitMovingLoad()
{
	bool r = true;
	bool IsLoaderError = false;
	bool IsMoving = false;
	int t;
	CString msg; //#MI130401

	CSingleLock lock(&EvReqAutoStop, false);		// lock for event request stop from BND
	CSingleLock lockTP(&EvStopWaiting, false);		// lock for event press "Stop" button from TP
	
//	StopWatch SW(TimeOut_Load_Moving);
	StopWatch SW((long)(this->m_reqTimeOutLd));	//#MI130418�^�C���A�E�g�ݒ�Ή�
	SW.Start();
	for (; r ;) {
		t = SW.Read();
		if (t == 0) {	// timeout
			// TODO: Handle error
			msg.Format("RobotBuilder::LoadSub() Waiting signal 'Moving' is timeout \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			this->m_err.PutError(Err_LoadingTimeOut);
			r = false;
			break;
		}

		// Request stop from BND
		if(lock.Lock(1)){
			msg.Format("RobotBuilder::LoadSub() Request stop LoadSub() \n");	//#MI130401
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			r = false;
//			EvReqAutoStop.ResetEvent();	//#MI130418	�����^�]�ŃX�g�b�v�������Ȃ�
			break;
		}
		
		// Request stop from Touch Panel
		if(lockTP.Lock(1)){
			msg.Format("RobotBuilder::LoadSub() Request stop LoadSub() \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			r = false;
			EvStopWaiting.ResetEvent();
			break;
		}
	
		// Check 'Error' signal
		r = this->m_inError.IsDetected(IsLoaderError);		// check error signal of Loader
		#if GPDEBUG
			::Sleep(500);
			IsLoaderError = false; //#MI130405
		#endif
		if (r && IsLoaderError) {
			msg.Format("RobotBuilder::LoadSub() signal 'Error' of Loader is ON \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);	//#MI130401
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			this->m_err.PutError(Err_LoaderError);
			r = false;	//#MI130418 �G���[�M���n�m�ł�����I�����Ă��܂�
			break;
		}
		
		// Wait 'Moving' is ON firstly
		if (r && (!IsMoving)) {
			r = this->m_inMoving.IsDetected(IsMoving);
			if (r && IsMoving) {
				msg.Format("RobotBuilder::LoadSub() Signal 'Moving' of Loader is ON \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
					this->LogRobotInterface(0);
				}
				#if !Release
					TRACE(msg);
				#endif
			}
		}

		// Wait Moving is ON->OFF
		if (r && IsMoving) {
			r = this->m_inMoving.IsDetected(IsMoving);
		#if GPDEBUG
			::Sleep(500);
			IsMoving = false;
		#endif
			if (r && (!IsMoving)) {
				msg.Format("RobotBuilder::LoadSub() Signal 'Moving' of Loader is OFF \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
					this->LogRobotInterface(0);
				}
				#if !Release
					TRACE(msg);
				#endif

				if (r) {
					// Turn OFF ReadyToLoad
					r = this->m_outReadyToLoadWF.Out(false);
				}

				if (r) {
					// Turn ON signal 'WaferIn' after received Wf
					r = this->m_outWaferIn.Out(true);
				}

				if (r) {
					msg.Format("RobotBuilder::LoadSub() Turn OFF signal 'ReadyToLoadWF' \n");
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
						this->LogRobotInterface(0);
					}
					#if !Release
						TRACE(msg);
					#endif
				}
				break;
			}
		}
	}

	return r;
}


//////////////////////////////////////////////////////////////////////
// Unload substrate wafer
//
bool CRobotIFBuilder::UnloadSub()
{
	BOOL r = true;			// #KI130317
	bool r2 = true;			// result detect signal error
	bool IsLoaderError = false;
	bool IsMoving = false;
	int t;

	CString msg; //#MI130401

	CSingleLock lock(&EvReqAutoStop, false);		// lock for event request stop from BND
	CSingleLock lockTP(&EvStopWaiting, false);		// lock for event press "Stop" button from TP

	// Turn ON 'SystemReady'
	if (r) {
		r = this->m_outReady.Out(true);

		if (r) {
			msg.Format("RobotBuilder::UnloadSub() Turn ON 'SystemReady' \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
		}
		else{
			return false;
		}
	}
	// Turn ON 'm_outReadyToUnloadWF'
	if (r) {
		r = this->m_outReadyToUnloadWF.Out(true);

		if (r) {
			msg.Format("RobotBuilder::UnloadSub() Turn ON 'ReadyToUnloadWF' \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
		}
		else{
			return false;
		}
	}
//	//UnloadSub()�ł͂k�`�m�̃R�l�N�V�����͕K�v�Ȃ�#MI130415
//	// Check connect to Server
//	if (INVALID_SOCKET == m_robotLANIF.m_clientSocket) {
//		EvCloseLANConnection.ResetEvent();		// reset event when connection is closed
//		r = m_robotLANIF.ConnectServer();
//		if (r) {
//			m_isConnected = true;
//		} else {
//			m_robotLANIF.DisconnectServer();
//			this->m_outReadyToUnloadWF.Out(false);	//#MI130414
//			return false;
//		}
//	}

//	StopWatch SW(TimeOut_Unload_Moving);
	StopWatch SW((long)(this->m_reqTimeOutUld));	//#MI130418�^�C���A�E�g�ݒ�Ή�
	SW.Start();
	
	for (;;) {
		t = SW.Read();
		if (t == 0) {	// timeout
			// TODO: Handle error
			msg.Format("RobotBuilder::UnloadSub() Waiting signal 'Moving' is timeout \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			this->m_err.PutError(Err_UnloadingTimeOut);
			r = false;
			break;
		}
	
		// Check error signal of Loader
		r2 = this->m_inError.IsDetected(IsLoaderError);
		#if GPDEBUG
			::Sleep(500);
			IsLoaderError = false; //#MI130405
		#endif
		if ((false == r2) || (true == IsLoaderError)) {
			// TODO: Handle error
			msg.Format("RobotBuilder::UnloadSub() signal 'Error' of Loader is ON \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			this->m_err.PutError(Err_LoaderError);
			r = false;
			break;
		}
		
		// Request stop from BND
		if(lock.Lock(1)){
			#if !Release
				TRACE("RobotBuilder::UnloadSub() Request stop UnloadSub() \n");
			#endif
			r = false;
//			EvReqAutoStop.ResetEvent();	//#MI130418	�����^�]�ŃX�g�b�v�������Ȃ�
			break;
		}
		
		// Request stop from Touch Panel
		if(lockTP.Lock(1)){
			#if !Release
				TRACE("RobotBuilder::UnloadSub() Request stop UnloadSub() \n");
			#endif
			r = false;
			EvStopWaiting.ResetEvent();
			break;
		}

		// Check 'Error' signal
		r = this->m_inError.IsDetected(IsLoaderError);		// check error signal of Loader
		#if GPDEBUG
			::Sleep(500);
			IsLoaderError = false;
		#endif
		if (r && IsLoaderError) {
			msg.Format("RobotBuilder::UnloadSub() signal 'Error' of Loader is ON \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			this->m_err.PutError(Err_LoaderError);
			r = false;	//#MI130418 �G���[�M���n�m�ł�����I�����Ă��܂�
			break;
		}
		
		// Wait 'Moving' is ON firstly
		if (r && (!IsMoving)) {
			r = this->m_inMoving.IsDetected(IsMoving);
			
			if (r && IsMoving) {
				msg.Format("RobotBuilder::UnloadSub() Signal 'Moving' of Loader is ON \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
					this->LogRobotInterface(0);
				}
				#if !Release
					TRACE(msg);
				#endif
			}
		}

		// Wait Moving is ON->OFF
		if (r && IsMoving) {
			r = this->m_inMoving.IsDetected(IsMoving);
			#if GPDEBUG
				::Sleep(500);
				IsMoving = false;
			#endif
			if (r && (!IsMoving)) {
				msg.Format("RobotBuilder::UnloadSub() Signal 'Moving' of Loader is OFF \n");
				if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
					this->m_err.LogSaveNFL(msg);
					this->LogRobotInterface(0);
				}
				#if !Release
					TRACE(msg);
				#endif

				// Turn OFF ReadyToUnload
				if (r) {
					r = this->m_outReadyToUnloadWF.Out(false);
				}
				// Turn OFF WaferIn
				if (r) {
					r = this->m_outWaferIn.Out(false);
				}
				// Turn OFF Complete
				if (r) {
					r = this->m_outComplete.Out(false);
				}

				if (r) {
					msg.Format("RobotBuilder::UnloadSub() Turn OFF signal 'ReadyToLoadWF','WaferIn','Complete' \n");
					if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
						this->m_err.LogSaveNFL(msg);
						this->LogRobotInterface(0);
					}
					#if !Release
						TRACE(msg);
					#endif
				}
				break;
			}
		} 
	}

	// Report to host after unload
	if (r) {
		r = (*this->pSendPickedMappingData)();
	}
	// 
	EvPickedDataOK.SetEvent();  // TuVV: temporary because no HOST

	// Wait reply from HOST
	if (r) {
		CSyncObject *ppObjects[2] = {0};			
		ppObjects[0]	= &EvPickedDataOK;				// report data OK
		ppObjects[1]	= &EvPickedDataNG;				// report data NG

		CMultiLock	M(ppObjects,2);
//		int i = M.Lock(TimeOut_HOST_PickData, FALSE);
		int i = M.Lock((long)(this->m_reqTimeOutHost), FALSE);	//#MI130418�^�C���A�E�g�ݒ�Ή�
		M.Unlock();

		if(i == WAIT_TIMEOUT){
			r = false;
			msg.Format("RobotBuilder::UnloadSub() waiting HOST is timeout \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
				this->LogRobotInterface(0);
			}
			#if !Release
				TRACE(msg);
			#endif
			this->m_err.PutError(Err_SendReportToHost);
		}
		
		i -= WAIT_OBJECT_0;

		if (i == 0) {
			r = true;
		}else if (i == 1) {
			r = false;
		}

	}
	this->m_outReadyToUnloadWF.Out(false);	//#MI130414

	return (r)?true:false;// #KI130317
}

//////////////////////////////////////////////////////////////////////
// Method for BND set ON/OFF signal 'Complete'
//
bool CRobotIFBuilder::TurnComplete(bool OnOff)
{
	bool r	= true;
	r = m_outComplete.Out(OnOff);
	return r;
}


//////////////////////////////////////////////////////////////////////
// Callback function to send WFIF to Host
// Empty function that will be defined later
//
bool CRobotIFBuilder::SendWFIFToHost(int carrierID, int slotNo, CString secsData)
{
	bool r = true;

	return r;
}

//////////////////////////////////////////////////////////////////////
// Request insert board from BND
//
bool CRobotIFBuilder::BND_Board_Insert_Request(
						CEventX *pEvFin,			// Normal finish Event
						CEventX *pEvFail,			// Abnormal finish Event
						CEventX *pEvFinFrm)			// Set frame data finish
{
	bool r = TRUE;
	// Point to Event of BND
	pEvBndFinInsertFrm	= pEvFin;
	pEvBndFailInsertFrm	= pEvFail;
	pEvFrmSetOnBgStg	= pEvFinFrm;	// Need or not?

	// Reset before request
	pEvBndFinInsertFrm->ResetEvent();
	pEvBndFailInsertFrm->ResetEvent();
	pEvFrmSetOnBgStg->ResetEvent();

	// Request insert board Event
	EvBndReqInsertFrm.SetEvent();
	return(r);
}
//////////////////////////////////////////////////////////////////////
// Request carry out board from BND
//
bool CRobotIFBuilder::BND_Board_CarryOut_Request(
						CEventX *pEvFin,			// Normal finish Event
						CEventX *pEvFail)			// Abnormal finish Event
{
	bool r = true;
	// Point to Event of BND
	pEvBndFinCarryOutFrm	= pEvFin;
	pEvBndFailCarryOutFrm	= pEvFail;
	// Request carry out Evemt
	EvBndReqCarryOutFrm.SetEvent();
	return(r);
}
void CRobotIFBuilder::BND_Board_BringIn_Request()
{
	// nothing
}
bool CRobotIFBuilder::BND_Board_CarryOut_StartOK(CEventX *pEvOK)
{
	bool r = true;
	// Point to Event of BND
	pEvBndCarryOutStartOK	= pEvOK;
	return(r);
}
bool CRobotIFBuilder::GetLoaderAuto()
{
// #KS20130531-03 [�s�] ���{�b�gIF���ALoader Auto �������Ȃ�
//	return true;
	return(m_LoaderAuto);
}
void CRobotIFBuilder::SetLoaderAuto(bool isValid)
{
	// nothing
// #KS20130531-03 [�s�] ���{�b�gIF���ALoader Auto �������Ȃ�
	m_LoaderAuto = isValid;
}
void CRobotIFBuilder::SetFrameLeft(int left)
{
	this->m_frameLeft = left;
}

void CRobotIFBuilder::SetNeedBoard(bool& toRoboArmA){
	toRoboArmA = false;
	if(this->m_frameLeft >= 2){			// remain 2 or 3 frames
		toRoboArmA = true;
	}else if(this->m_frameLeft == 1){	// remain 1 frame
		if((*this->pHasAFrame)(eOnWfBgStg)){
			toRoboArmA = false;
		}else{
			toRoboArmA = true;
		}
	}else if(this->m_frameLeft == 0){	// remain 0 frame
		toRoboArmA = false;
	}
}

//////////////////////////////////////////////////////////////////////
// Lift pin up
//
BOOL CRobotIFBuilder::LiftPinUp()
{
	BOOL r = TRUE;
	CString msg; //#MI130401
	
	if(this->pIsAbleToGoUp == NULL){
		r = FALSE;
	}else{
		// Check able to go up liftpin
		r = (*this->pIsAbleToGoUp)();
	}

	if(r){
		r = this->mtLiftPin.MotorMoveAbs(this->m_liftPinUpPos);
	}

	if (r) {
		msg.Format("CRobotIFBuilder::LiftPinUp() execute successful \n");
		if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
			this->m_err.LogSaveNFL(msg);
		}
	}else {
		msg.Format("CRobotIFBuilder::LiftPinUp() execute unsuccessful \n");
		if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
			this->m_err.LogSaveNFL(msg);
		}
	}
	#if !Release
		TRACE(msg);
	#endif

	return r;
}
//////////////////////////////////////////////////////////////////////
// Lift pin down
//
BOOL CRobotIFBuilder::LiftPinDown()
{
	BOOL r	= TRUE;
	CString msg; //#MI130401

	r = this->mtLiftPin.MotorMoveAbs(this->m_liftPinDwnPos);
	::Sleep(200);

//	#if GPDEBUG #MI130401
	if (r) {
		msg.Format("CRobotIFBuilder::LiftPinDown() execute successful \n");
		if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
			this->m_err.LogSaveNFL(msg);
		}
	}else {
		msg.Format("CRobotIFBuilder::LiftPinDown() execute unsuccessful \n");
		if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
			this->m_err.LogSaveNFL(msg);
		}
	}
	#if !Release
		TRACE(msg);
	#endif

	return r;
}

////////////////////////////////////////////////////////////
// Set Wafer
BOOL CRobotIFBuilder::ManuSetWaferOnBgStg()
{	
	BOOL r = TRUE;
	// �z���Ȃ��烊�t�g�s�����~
	if(r){
		// ���~�O�Ƀ{���f�B���O�X�e�[�W���z��ON������B
		r = this->vacBgStg.Out(true,true);
	}
	if(r){
		// ���t�g�s�����~
		r = this->LiftPinDown();
	}
	if(r){
		// �{���f�B���O�X�e�[�W�Ɋ���ڂ���
//		(*this->pMoveFrameBringInRobotArmToBgStg)();
		(*this->pSetAFrame)(eOnWfBgStg, true);
	}
	return r;
}

////////////////////////////////////////////////////////////
// �E�F�n�����o��
BOOL CRobotIFBuilder::ManuCarryOutWafer(){
	BOOL r = TRUE;
	// �E�F�n������o��
	if(r){
		// ����{���f�B���O�X�e�[�W������o�A�[���ցB
//		(*this->pMoveFrameBgStgToCarryOutRobotArm)();
		(*this->pSetAFrame)(eOnWfBgStg, false);
	}
	if(r){
		r = this->LiftPinDown();
	}
	return r;
}

//////////////////////////////////////////////////////////////////////
// ���{�b�g�h�^�e�ʐM���O #MI130327RobotI/F�ǉ�
//
void CRobotIFBuilder::LogRobotInterface(int mode)
{
	bool r=true;
	CString	Msg,Msg2;
	CTime theTime;

	bool InMoving = false;
	bool InEndOfLot = false;
	bool InError = false;
	bool OutReady = false;
	bool OutRdyToLd = false;
	bool OutRdyToUld = false;
	bool OutWfrIn = false;
	bool OutComp = false;
	bool OutError = false;

	//���͐M�����W
	r = this->m_inMoving.IsDetected(InMoving);
	r = this->m_inEndOfLot.IsDetected(InEndOfLot);
	r = this->m_inError.IsDetected(InError);
	//�o�͐M�����W
	r = this->m_outReady.CmdSts(OutReady);
	r = this->m_outReadyToLoadWF.CmdSts(OutRdyToLd);
	r = this->m_outReadyToUnloadWF.CmdSts(OutRdyToUld);
	r = this->m_outWaferIn.CmdSts(OutWfrIn);
	r = this->m_outComplete.CmdSts(OutComp);
	r = this->m_outError.CmdSts(OutError);
	//�k�`�m�ʐM�֌W���W
	int ResMess = m_robotLANIF.GetHeaderResMessage();
	int ReqMess = m_robotLANIF.m_msgReq.m_header;
	double WfAngle = m_robotLANIF.m_msgReq.m_wfAngle;
	CString WFIFData;
	m_robotLANIF.GetWFIFResMessage(WFIFData);

	if(!this->m_RobotIFLog){	//���{�b�g�C���^�t�F�C�X���O�L�����m�F
		r = false;
	}
	if(r){
		if(mode==0){	//�h�^�n�̐M�����O
			theTime = CTime::GetCurrentTime();
//			Msg = theTime.Format("%H:%M:%S,���{�b�g�h�^�e�ʐM�m�F,");	// ����/��/�b/ �^�C�g��
			Msg = theTime.Format("���{�b�g�h�^�e�ʐM�m�F,");	// ����/��/�b/ �^�C�g��
			Msg2.Format("InMove ,InEndLt,InErr  ,OtRdy  ,OtRdyLd,OtRdyUd,InWfr  ,OtComp ,OtErr  ,ResMess,ReqMess,WfAngle,WfInfo , ");
			Msg += Msg2;
			this->m_err.LogSaveNFL(Msg);
		}
		if(mode==0){	//mode0=�h�n�̐M�����O
//			theTime = CTime::GetCurrentTime();
//			Msg = theTime.Format("%H:%M:%S,���{�b�g�h�^�e�ʐM�m�F,");	// ����/��/�b/ �^�C�g��
			Msg = theTime.Format("���{�b�g�h�^�e�ʐM�m�F,");	// ����/��/�b/ �^�C�g��
			Msg2.Format("%d      ,%d      ,%d      ,%d      ,%d      ,%d      ,%d      ,%d      ,%d      ,%d      ,%d      ,%07.3f,%s    ",
						InMoving,	//����Moving
						InEndOfLot,	//����EndOfLot
						InError,	//����Error
						OutReady,	//�o��Ready
						OutRdyToLd,	//�o��RdyToLd
						OutRdyToUld,//�o��RdyToUld
						OutWfrIn,	//�o��WfrIn
						OutComp,	//�o��Comp
						OutError,	//�o��Error
						ResMess,	//
						ReqMess,	//
						WfAngle,	//WaferAngle
						WFIFData	//WafetInformation
						);
			Msg += Msg2;
			this->m_err.LogSaveNFL(Msg);
		}
		if(mode==1){	//mode1=�k�`�m�ʐM�̃��O
			Msg2.Format("%d      ,%d      ,%d      ,%07.3f,%s    ",
						ResMess,	//
						ReqMess,	//
						WfAngle,	//WaferAngle
						WFIFData	//WafetInformation
						);
			Msg += Msg2;
			this->m_err.LogSaveNFL(Msg);
		}
	}
}
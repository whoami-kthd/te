// RobotIFBuilder.h: CRobotIFBuilder �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ROBOTIFBUILDER_H__114C9EE1_8DFA_413F_8DD7_7FCA7DF6D2F3__INCLUDED_)
#define AFX_ROBOTIFBUILDER_H__114C9EE1_8DFA_413F_8DD7_7FCA7DF6D2F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"
#include "..\AbstractFeeder.h"
#include "RobotLANInterface.h"
#include <Ulib.h>
#include <mcstd.h>
#include <SingleMtCtrl.h>


class CRobotIFBuilder : 
	public MCCStd, 
	public AbstractFeeder  
{
public:
	// Contructor and decontructor
	CRobotIFBuilder();
	virtual ~CRobotIFBuilder();
	CRobotIFBuilder(int classId,
					int pinIdx,
					int myErrStart,
					int lanIFErrStart
					);
	
	// Command for AutoFunc()
	enum { 		
		CmdAutoRun,						// AutoRun thread
		CmdRobotLANInterfaceThread		// robot LAN Interface thread
	};

	enum {
		WFIF_NG = 0,
		WFIF_OK,
		WFIF_MAX
	};

	enum {
		HELO_MESSAGE = 0,
		WFIF_MESSAGE,
		WFAG_MESSAGE,
		MAX_TYPE_MESSAGE
	};

//////////////////////////////////////////////////////////////////////
// Attribute
	CRobotLANInterface	m_robotLANIF;

	// Input sensor
	OrdinarySensor		m_inMoving;
	OrdinarySensor		m_inEndOfLot;
	OrdinarySensor		m_inError;

	// Output sensor
	OrdinaryOut			m_outReady;
	OrdinaryOut			m_outReadyToLoadWF;
	OrdinaryOut			m_outReadyToUnloadWF;
	OrdinaryOut			m_outWaferIn;
	OrdinaryOut			m_outComplete;
	OrdinaryOut			m_outError;

	ErrorMediator	m_err;				// Output hanlde

	// Timeout waiting for Interface
//	double				m_reqTimeOutLd;		// time out for waitint Loading		//#MI130418�^�C���A�E�g�ݒ�Ή�
//	double				m_reqTimeOutUld;	// time out for waiting Unloading	//#MI130418�^�C���A�E�g�ݒ�Ή�
	// Flag for setup connection
	bool		m_isConnected;

	// Public event
	CEventX			EvAutoStart;
	CEventX			EvReqAutoStop;		// Request stop from BND
	CEventX			EvFinish;
	CEventX			EvStopWaiting;		// Stop when press Stop button
	CEventX			EvAutoFinished;		// Inform finish to BND

	// Protected event
	CEventX			EvBndReqInsertFrm;			// BND request insert frame
	CEventX*		pEvBndFinInsertFrm;			// inform BND insert frame finish
	CEventX*		pEvBndFailInsertFrm;		// infrom BND insert frame failure 
	CEventX			EvBndReqCarryOutFrm;		// BND request carry out frame
	CEventX*		pEvBndFinCarryOutFrm;		// inform BND carry out frame finish
	CEventX*		pEvBndFailCarryOutFrm;		// inform BND carry out frame failure
	// CEventX*		pEvLoaderEndOfLot;			// inform BND Loader is end of lot
	CEventX*		pEvFrmSetOnBgStg;			// Already set Sub on BgStg
	CEventX*		pEvBndCarryOutStartOK;		// Carry out OK

	CEventX			EvSubInfoOK;				// board information is OK
	CEventX			EvSubInfoNG;				// board information is NG
	CEventX			EvPickedDataOK;				// report after unload is OK
	CEventX			EvPickedDataNG;				// report after unload is NG
	
	CEventX			EvCloseLANConnection;		// connection close
	CEventX			EvFinRecvWFAG;				// receive WFAG finish
	CEventX			EvFinRecvWFIF;				// receive WFIF finish
	CEventX			EvFailRecvLAN;				// receive message via LAN failure
	
protected:
	enum{
		eLANThread		= 0,					// LAN thread
		eThread_Max,
	};
	MTCtrl	ActionMTC;							// Main control thread
	MTCtrl	ActionSMTC[eThread_Max];			// Sub control thread

private:
	VacuumStd		vacBgStg;					// Bonding Stage vacumm
	SingleMtCtrl	mtLiftPin;					// Lift Pin motor
	bool			isAging;					// �G�[�W���O��� #MI130405
	double			m_liftPinUpPos;				// Lift pin up position
	double			m_liftPinDwnPos;			// Lift pin down position
	double			m_oriFlat;					// OriFlat #MI130313RobotI/F�ǉ�
	double			m_alignAngle;				// Align angle
	double			m_correctAngle;				// CorrectAngle #MI130313RobotI/F�ǉ�
	int				m_frameLeft;				// Remain frame
	CString			m_ipAddress;				// IP address
	int				m_portNo;					// Port number
	int				m_RobotIFLog;				// ���{�b�g�C���^�[�t�F�C�X���O�L��(0:���@1:�L)
	// Timeout waiting for Interface
	double			m_reqTimeOutLd;				// time out for waitint Loading		//#MI130418�^�C���A�E�g�ݒ�Ή�
	double			m_reqTimeOutUld;			// time out for waiting Unloading	//#MI130418�^�C���A�E�g�ݒ�Ή�
	double			m_reqTimeOutLANCnct;		// time out for waiting LAN	Connect	//#MI130418�^�C���A�E�g�ݒ�Ή�
	double			m_reqTimeOutLANMsg;			// time out for waiting LAN	Message	//#MI130418�^�C���A�E�g�ݒ�Ή�
	double			m_reqTimeOutHost;			// time out for waiting Host		//#MI130418�^�C���A�E�g�ݒ�Ή�

// #KS20130531-03 [�s�] ���{�b�gIF���ALoader Auto �������Ȃ�
	bool			m_LoaderAuto;

//////////////////////////////////////////////////////////////////////
// Method
public:
	BOOL Init();
	bool AutoInit();
	void ErrorInit(int myErrStart);
	void DeviceInit();	//#MI130416

	// Automatic operation
	static UINT ActionFunc(MTCtrl	*pParam);
	bool AutoRun();
	bool RobotLANInterfaceThread();
	bool FrameExistsUpdate(bool errOut=true);		// �ڰя��Update(�Z���T��Ԃɏ�������)

	// Send WFIF to Host. Empty function that is defined later
	bool SendWFIFToHost(int carrierID, int slotNo, CString secsData);

	// Method for BND set ON/OFF signal 'Complete'
	bool TurnComplete(bool OnOff);

	// Method to load and unload wafer
	bool LoadSub();
	bool UnloadSub();

	// Method to waiting for moving load wafer
	bool WaitMovingLoad();

	// Method control BND hardware
	BOOL LiftPinUp();
	BOOL LiftPinDown();

	//�A������ #MI130405
	BOOL	ManuSetWaferOnBgStg();					// �E�F�n�Z�b�g
	BOOL	ManuCarryOutWafer();					// �E�F�n�����o��

	// ���{�b�g�C���^�[�t�F�C�X�ʐM���O #MI130327RobotI/F�ǉ�
	void LogRobotInterface(int mode);
public:
	// Override function
	void BND_Board_BringIn_Request();
	bool BND_Board_Insert_Request(
						CEventX *pEvFin,
						CEventX *pEvFail,
						CEventX *pEvFinFrm);
	bool BND_Board_CarryOut_Request(
						CEventX *pEvFin,	
						CEventX *pEvFail);
	bool BND_Board_CarryOut_StartOK(CEventX *pEvOK);

	bool (__cdecl *pHasAFrame)(int);
	void SetHasAFrameFunc(bool (__cdecl *pFunc)(int)){
		pHasAFrame	= pFunc;
	}

	void (__cdecl *pSetAFrame)(int,bool);
	void SetSetAFrameFunc(void (__cdecl *pFunc)(int,bool)){
		pSetAFrame = pFunc;
	}
	bool GetLoaderAuto();
	void SetLoaderAuto(bool isValid);
	void SetFrameLeft(int left);

	// Getting, Setting function
	void SetLiftPinUpPos(double pos){
		this->m_liftPinUpPos	= pos;
	}
	void SetLiftPinDwnPos(double pos){
		this->m_liftPinDwnPos	= pos;
	}
	// �����p�x�␳�l�̃Z�b�g #MI130318RobotI/F�ǉ�
	void SetCorrectAngle(double angle){
		this->m_correctAngle	= angle;
	}
	// �I���t���p�x��ݒ肷�� #MI130318RobotI/F�ǉ�
	void SetOriFra(double angle){
		if(angle < 0.000 || angle >= 360.0){
			CString msg;
			msg.Format("Error %s(%d)SetOrifra = %f", __FILE__, __LINE__, angle);
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		this->m_oriFlat	= angle;
	}
	void SetAlignAngle(double angle){
//		this->m_alignAngle	= angle;	#MI130318RobotI/F�ǉ�
//		this->m_robotLANIF.m_msgReq.m_wfAngle = angle;	#MI130318RobotI/F�ǉ�
		this->m_robotLANIF.m_msgReq.m_wfAngle = this->m_oriFlat + this->m_correctAngle;
	}
	void SetTimeOutLD(double Sec){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		this->m_reqTimeOutLd = Sec * 1000;
	}
	void SetTimeOutULD(double Sec){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		this->m_reqTimeOutUld = Sec * 1000;
	}
	void SetTimeOutLANCnct(double Sec){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		this->m_reqTimeOutLANCnct = Sec * 1000;
	}
	void SetTimeOutLANMsg(double Sec){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		this->m_reqTimeOutLANMsg = Sec * 1000;
	}
	void SetTimeOutHOST(double Sec){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		this->m_reqTimeOutHost = Sec * 1000;
	}
	// �G�[�W���O�̃Z�b�g #MI130318RobotI/F�ǉ�
	void SetAging(bool aging){
		this->isAging	= aging;
	}
	double GetLiftPinUpPos(){
		return(this->m_liftPinUpPos);
	}
	double GetLiftPinDwnPos(){
		return(this->m_liftPinDwnPos);
	}
	double GetAlignAngle(){
		return(this->m_alignAngle);
	}
	// �␳�ʃƂ��擾(double angel)
	double GetCorrectAngle(){
		return this->m_correctAngle;
	}
	double GetTimeOutLD(){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		return this->m_reqTimeOutLd / 1000;
	}
	double GetTimeOutULD(){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		return this->m_reqTimeOutUld / 1000;
	}
	double GetTimeOutLANCnct(){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		return this->m_reqTimeOutLANCnct / 1000;
	}
	double GetTimeOutLANMsg(){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		return this->m_reqTimeOutLANMsg / 1000;
	}
	double GetTimeOutHOST(){	//#MI130418�^�C���A�E�g�ݒ�Ή�
		return this->m_reqTimeOutHost / 1000;
	}

	void SetNeedBoard(bool& toRoboArmA);

	// Call back
	bool (__cdecl *pIsAbleToGoUp)(void);
	void SetIsAbleToGoUpFunc(bool (__cdecl *pFunc)(void)){
		pIsAbleToGoUp = pFunc;
	}

	// Call back: send WFIF to HOST
	BOOL (__cdecl *pSendWFIFToHOST)(CString);
	void SetSendWFIFToHOST(BOOL (__cdecl *pFunc)(CString)){
		pSendWFIFToHOST = pFunc;
	}

	// Call back: send pick mapping data request to HOST
	BOOL (__cdecl *pSendPickedMappingData)(void);
	void SetSendPickedMappingData(BOOL (__cdecl *pFunc)(void)){
		pSendPickedMappingData = pFunc;
	}

	// �������{�b�g�A�[������{���f�B���O�X�e�[�W�փZ�b�g #MI130405
	void (__cdecl *pMoveFrameBringInRobotArmToBgStg)(void);
	// �������{�b�g�A�[������{���f�B���O�X�e�[�W�փZ�b�g�֐��̃Z�b�g
	void SetMoveFrameBringInRobotArmToBgStgFunc(void (__cdecl *pFunc)(void)) {
		pMoveFrameBringInRobotArmToBgStg = pFunc;
	}

	// Machine Data read/write
	bool McDataRW(BOOL Read,LPCTSTR FNam, CString MSec){
		CString section = MSec + ":RobotIFBuilder";
		bool	r = TRUE;
		
		if((!Read) && FNam[0] ==0){
			return r;
		}
		GWPPfileData(FNam,section,"�h�o�A�h���X",					Read, this->m_ipAddress,		"10.16.116.101");	//#MI130318RobotI/F�ǉ�
		GWPPfileData(FNam,section,"�|�[�g�ԍ�",						Read, this->m_portNo,			5001);				//#MI130318RobotI/F�ǉ�
		GWPPfileData(FNam,section,"���t�g�s���㏸�ʒu(mm)",			Read, this->m_liftPinUpPos,		-10.0);				//#MI130318RobotI/F�ǉ�
		GWPPfileData(FNam,section,"���t�g�s�����~�ʒu(mm)",			Read, this->m_liftPinDwnPos,	0.0);				//#MI130318RobotI/F�ǉ�
		GWPPfileData(FNam,section,"���{�b�g�ʐM���O�L��(0:��,1:�L)",Read, this->m_RobotIFLog,		0);					//#MI130318RobotI/F�ǉ�
		GWPPfileData(FNam,section,"�������ѱ�Ď���(I/F)",Read, this->m_reqTimeOutLd,		120000.0);
		GWPPfileData(FNam,section,"����o��ѱ�Ď���(I/F)",Read, this->m_reqTimeOutUld,	120000.0);
		GWPPfileData(FNam,section,"�k�`�m�ڑ���ѱ�Ď���(I/F)",Read, this->m_reqTimeOutLANCnct,10000.0);
		GWPPfileData(FNam,section,"�k�`�mү������ѱ�Ď���(I/F)",Read, this->m_reqTimeOutLANMsg,	60000.0);
		GWPPfileData(FNam,section,"�g�n�r�s�ʐM��ѱ�Ď���(I/F)",Read, this->m_reqTimeOutHost,	10000.0);

		this->m_robotLANIF.m_ipAddress	= this->m_ipAddress;
		this->m_robotLANIF.m_portNo		= this->m_portNo;
		this->m_robotLANIF.m_RobotIFLog	= this->m_RobotIFLog;	//MI130409RobotI/F LOG
		this->m_robotLANIF.m_reqTimeOutLANCnct	= this->m_reqTimeOutLANCnct;	//#MI130418�^�C���A�E�g�ݒ�Ή�

		return r;
	}

	// Device data read/write
	BOOL DvDataRW(BOOL Read, LPCTSTR FNam, CString DSec) {
		CString section = DSec + ":RobotIFBuilder";
		int r = TRUE;
		if ((! Read) && FNam[0] == 0) {
			return	r;
		}

//		GWPPfileData(FNam,section,"Alignment angle",			Read, this->m_alignAngle,	0.0);	//#MI130318RobotI/F�ǉ�
		GWPPfileData(FNam,section,"�����p�x�␳��(�x)",			Read, this->m_correctAngle,	0.0);

		// Set data for align angle
//		this->m_robotLANIF.m_msgReq.m_wfAngle	= this->m_alignAngle;	//#MI130318RobotI/F�ǉ�
		this->SetAlignAngle(0);	//#MI130318RobotI/F�ǉ�
		return(r);
	}

	// Error number
	enum	ErrNo{
		Err_MovingSns			= 1,
		Err_EndOfLotSns			= 2,
		Err_ErrorSns			= 3,
		Err_BgStgVacuum			= 4,
		Err_ReceiveTimeOut		= 5,
		Err_LoadingFailed		= 6,
		Err_UnloadingFailed		= 7,
		Err_LoadingTimeOut		= 8,
		Err_UnloadingTimeOut	= 9,
		Err_LoaderError			= 10,
		Err_EndOfLot			= 11,
		Err_LANRecvMesTimeOut	= 12,
		Err_SendS12ToHost		= 13,
		Err_SendReportToHost	= 14,
// #KS20130531-03 [�s�] ���{�b�gIF���ALoader Auto �������Ȃ�
		Err_LoaderAutoOff		= 15,
	};
};

#endif // !defined(AFX_ROBOTIFBUILDER_H__114C9EE1_8DFA_413F_8DD7_7FCA7DF6D2F3__INCLUDED_)

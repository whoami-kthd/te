
////////////////////////////////////////////////////////////////
//	IO Definition
//
#define	IO_Moving_SNS_IN				DINTBL_144		// Moving sensor
#define	IO_EnOfLot_SNS_IN				DINTBL_145		// End of lot sensor
#define	IO_Error_SNS_IN					DINTBL_146		// In error sensor

#define	IO_Ready_SNS_OUT				DOUTTBL_128		// System ready sensor
#define	IO_ReadyToLoad_SNS_OUT			DOUTTBL_129		// Ready to load sensor
#define	IO_ReadyToUnload_SNS_OUT		DOUTTBL_130		// Ready to unload sensor
#define	IO_WaferIn_SNS_OUT				DOUTTBL_131		// Wafer in sensor
#define	IO_Complete_SNS_OUT				DOUTTBL_132		// Complete sensor
#define	IO_Error_SNS_OUT				DOUTTBL_133		// Out error sensor

////////////////////////////////////////////////////////////////
//	Time Out Definition
//
#define TimeOut_Load_Moving				600000			// Wait load sub
#define TimeOut_Unload_Moving			600000			// Wait unload sub
#define TimeOut_LAN_Connecting			600000			// Wait reply oHELO from Loader
#define TimeOut_LAN_Message				600000			// Wait message from Loader
#define TimeOut_HOST_S12				600000			// Wait reply S12 from HOST
#define TimeOut_HOST_PickData			600000			// Wait reply report from HOST
#define TimeOut_Connection				600000			// Wait connect to Loader
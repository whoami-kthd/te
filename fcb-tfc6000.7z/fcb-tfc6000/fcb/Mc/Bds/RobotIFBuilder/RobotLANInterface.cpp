// RobotLANInterface.cpp: implementation of the CRobotLANInterface class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RobotLANInterface.h"
#include "RobotIFDefine.h"
#include <mcc.h>

#define	WFIF_NG	0
#define WFIF_OK 1

#define TIMEOUT_RECV_HELO_MSG		10000		// timeout to receive HELO message in 30s
#define DELAY_TIME_RECV_MSG			10			// delay time to receive message in 10ms

#define WSA_VERSION  MAKEWORD(2,0)

//////////////////////////////////////////////////////////////////////
// Define global variable
char ResHeaderMsg[3][7] = {	"oHELO:",
						    "oWFIF:",
							"oWFAG:",
};

char ReqHeaderMsg[3][7] = {	"aHELO:",
						    "aWFIF:",
							"aWFAG:",
};

char StatusWFIF[2][3] = { "NG",
						  "OK"
};

char EndCharacter = '\x0d';


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRobotLANInterface::CRobotLANInterface()
{

}

CRobotLANInterface::~CRobotLANInterface()
{
	this->DisconnectServer();
}

CRobotLANInterface::CRobotLANInterface(	int class_Id,
										int myErrStart)
{
	this->m_ipAddress			= "";
	this->m_portNo				= 0;
	this->m_clientSocket		= INVALID_SOCKET;
//	this->m_timeout				= TIMEOUT_RECV_HELO_MSG;
//	this->m_delayTime			= DELAY_TIME_RECV_MSG;
	this->m_msgReq.m_wfAngle	= 0;

	// Init error
	this->m_err.Initinstance(class_Id,myErrStart);
}
//////////////////////////////////////////////////////////////////////
// Connect to server
//
bool CRobotLANInterface::ConnectServer()
{
	bool	r			= true;
	CString msg;	//#MI130401
	SOCKET	sock		= INVALID_SOCKET;
    struct	sockaddr_in serverAddr;
	WSADATA		WSAData = { 0 };

	msg.Format("RobotLANIF::ConnectServer() connecting ... \n");
	if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
		this->m_err.LogSaveNFL(msg);
	}
	#if !Release
		TRACE(msg);
	#endif

	// Initialize Winsock
	if ( 0 != WSAStartup( WSA_VERSION, &WSAData ) )
	{
		// Tell the user that we could not find a usable
		// WinSock DLL.
		if ( LOBYTE( WSAData.wVersion ) != LOBYTE(WSA_VERSION) ||
			 HIBYTE( WSAData.wVersion ) != HIBYTE(WSA_VERSION) )
			 ::MessageBox(NULL, _T("Incorrect version of WS2_32.dll found"), _T("Error"), MB_OK);

		WSACleanup( );
		return FALSE;
	}

	// Create a socket that is connect to server
    // family:		(AF_INET)
    // socket type: (SOCK_STREAM)
	// protocol:	(IPPROTO_IP)
    sock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP);
	
	// Set up the sockaddr structure
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_addr.s_addr = inet_addr(m_ipAddress);
	serverAddr.sin_port = htons(m_portNo);

//	StopWatch	SW(TimeOut_Connection);
//	SW.Start();
//
//	while (true){
//		int r2 = connect( sock, (SOCKADDR*) &serverAddr, sizeof(serverAddr));
//		
//		int t = SW.Read();
//		if (t == 0) {
//			r = false;
//			break;	// Connection time out
//		}
//
//		if (r2 != SOCKET_ERROR) {
//			break;	// Connect successfully
//		}
//	}

	// Connect to server
    if (SOCKET_ERROR == connect( sock, (SOCKADDR*) &serverAddr, sizeof(serverAddr))) {
		closesocket(sock);
		sock = INVALID_SOCKET;
		this->m_err.PutError(Err_ConnectingFailed);		// Show Error

		msg.Format("RobotLANIF::ConnectServer() Fail");
		if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
			this->m_err.LogSaveNFL(msg);
		}
		#if !Release
			TRACE(msg);
		#endif
		r = false;
	}
	
	// Set non-blocking socket for check timeout
	unsigned long iMode = 1;
	ioctlsocket(sock, FIONBIO, &iMode);
	
	// Receive and send HELO message
	if (r) {
		r = RecvSendHELOMessage(sock);
	}
	msg.Format("RobotLANIF::ConnectServer() finish \n");
	if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
		this->m_err.LogSaveNFL(msg);
	}
	#if !Release
		TRACE(msg);
	#endif

	// Save client socket
	m_clientSocket = sock;

	return r;
}


//////////////////////////////////////////////////////////////////////
// Receive and send HELO message after connect to server
//
bool CRobotLANInterface::RecvSendHELOMessage(SOCKET socket)
{
	bool r = true;
	int t;
	CString msg;	//#MI130401
//	StopWatch	SW(TimeOut_LAN_Connecting);
	StopWatch SW((long)(this->m_reqTimeOutLANCnct));	//#MI130415�^�C���A�E�g�ݒ�Ή�
	SW.Start();

// #KS20130413-04(S) [���P]LAN�p�f�o�b�O���b�Z�[�W
#if !Release
	TRACE("\nWaiting oHELO:\n");
#endif
// #KS20130413-04(E)

	for(; r ;){
		t = SW.Read();
		if (0 == t) {
			r = false;
			this->m_err.PutError(Err_ConnectingTimeOut);
	
			CString msg;
			msg.Format("RobotLANIF::RecvSendHELOMessage() Timeout");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			break;
		} else {
			char	recvBuf[MAX_LENGTH_MESSAGE];			// buffer contain received message
			int		recvBufLen = MAX_LENGTH_MESSAGE;	
			int		recvResult;
				
			// Receive message
			recvResult = this->RecvMessage(socket, recvBuf, recvBufLen, 0);
			if (recvResult > 0) {
				if (true == this->ParseMessage(recvBuf, recvResult)) {	
					char pBuf[MAX_LEN_REQ_WFIF];
					int  lenBuf;

					// Receive HELO message	
					if (HELO_MESSAGE == this->GetHeaderResMessage()) {
						msg.Format("RobotLANIF::RecvSendHELOMessage() Received oHELO OK\n");
						if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
							this->m_err.LogSaveNFL(msg);
						}
						#if !Release
							TRACE(msg);
						#endif
						this->SetHeaderReqMessage(HELO_MESSAGE);
						this->BuildMessage(pBuf, &lenBuf);
						
						if (SOCKET_ERROR == this->SendMessage(socket, pBuf, lenBuf, 0)) {
							msg.Format("RobotLANIF::RecvSendHELOMessage() Send aHELO Fail\n");
							if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
								this->m_err.LogSaveNFL(msg);
							}
							#if !Release
								TRACE(msg);
							#endif
							closesocket(socket);
							WSACleanup();
							r = false;
						} else {
							msg.Format("RobotLANIF::RecvSendHELOMessage() Send aHELO OK\n");
							if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
								this->m_err.LogSaveNFL(msg);
							}
							#if !Release
								TRACE(msg);
							#endif
						}

						break;
					} else {
						// Do nothing
					}
				
				} else {
					// Do nothing	
				}
			} else {
				// Do nothing
			}
		}
	}

	return r;
}

//////////////////////////////////////////////////////////////////////
// Connect to server
//
bool CRobotLANInterface::DisconnectServer()
{		
	CString msg;	//#MI130401
// #KS20130413-02(S) [����]�ʐM�ؒf���P
/*
	// Shutdown the connection since no more data will be sent
    if (SOCKET_ERROR == shutdown(m_clientSocket, SD_SEND)) {
		closesocket(m_clientSocket);
        WSACleanup();
		msg.Format("shutdown failed with error: %d\n", WSAGetLastError());
		if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
			this->m_err.LogSaveNFL(msg);
		}
		#if !Release
			TRACE(msg);
		#endif
        return false;
    }
*/ // ��L�Ŏ��s����Ƃ������Ȃ��ƂɂȂ�
	closesocket(m_clientSocket);	// �{���͖߂�l������K�v���邪���L�Ŗ����Ƃ��Ă���̂łƂ肠����OK�̂͂�
// #KS20130413-02(E)
// #KS20130413-05 [�s�]�ʐM�ؒf���ɃG���[���o�Ȃ�
	this->m_err.PutError(Err_ConnectingFailed);		// Show Error

	m_clientSocket = INVALID_SOCKET;

	msg.Format("RobotLANIF::DisconnectServer() successful \n");
	if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
		this->m_err.LogSaveNFL(msg);
	}
	#if !Release
		TRACE(msg);
	#endif

	return true;
}


//////////////////////////////////////////////////////////////////////
// Check status of client socket
//
bool CRobotLANInterface::IsOpen()
{
	return (INVALID_SOCKET != m_clientSocket);
}


//////////////////////////////////////////////////////////////////////
// Build message to sent
//
bool CRobotLANInterface::BuildMessage(char *pBuf, int *pSizeBuf)
{
	char *pTemp;
	bool ret = true;
	CString msg;	//#MI130401
	
	// Check input parameter
	if ((NULL == pBuf) || (NULL == pSizeBuf)) {
		return false;
	}
	pTemp = pBuf;

	// Build message
	switch (m_msgReq.m_header) {
		case HELO_MESSAGE:		// aHELO message
		{	
			// Save header message
			memcpy(pTemp, ReqHeaderMsg[HELO_MESSAGE], MAX_LEN_HEADER_MESSAGE);
			pTemp += MAX_LEN_HEADER_MESSAGE;
			
			// Save type client FC: 1
			*pTemp = '1';
			pTemp++;

			*pTemp = EndCharacter;
			*pSizeBuf = 9;
			
			msg.Format("RobotLANIF::BuildMessage() aHELO is successful\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			break;
		}

		case WFIF_MESSAGE:		// aWFIF message
		{
			// Save header message
			memcpy(pTemp, ReqHeaderMsg[WFIF_MESSAGE], MAX_LEN_HEADER_MESSAGE);
			pTemp += MAX_LEN_HEADER_MESSAGE;
			
			// Save status OK or NG
			if (WFIF_NG == m_msgReq.m_status) {
				memcpy(pTemp, &StatusWFIF[WFIF_NG], 2);
				pTemp += 2;
			} else if (WFIF_OK == m_msgReq.m_status) {
				memcpy(pTemp, &StatusWFIF[WFIF_OK], 2);
				pTemp += 2;
			} else {
				// Handle error
			}

			*pTemp = EndCharacter;
			*pSizeBuf = MAX_LEN_REQ_WFIF;

			msg.Format("RobotLANIF::BuildMessage() aWFIF is successful\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			break;
		}

		case WFAG_MESSAGE:		// aWFAG message
		{
//			char WFAngle[5];
			char WFAngle[10];	//#MI130411
			memcpy(pTemp, ReqHeaderMsg[WFAG_MESSAGE], MAX_LEN_HEADER_MESSAGE);
			pTemp += MAX_LEN_HEADER_MESSAGE;
		
			sprintf (WFAngle, "%05.1f", m_msgReq.m_wfAngle);
			memcpy(pTemp, WFAngle, sizeof(WFAngle));
			pTemp += 5;

			*pTemp = EndCharacter;
			*pSizeBuf = MAX_LEN_REQ_WFAG;

			msg.Format("RobotLANIF::BuildMessage() aWFAG is successful\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			break;
		}
		default:
			//Show error
			ret = false;
			break;
	}
// #KS20130410(S) [�C��]�ʐM���b�Z�[�W��
	if (ret) {
		pTemp++;
		*pTemp = 0;
		*pSizeBuf = (int)(pTemp - pBuf);
	}
// #KS20130410(E)
	return ret;
}


//////////////////////////////////////////////////////////////////////
// Parse message received
//
bool CRobotLANInterface::ParseMessage(char *pBuf, int sizeBuf)
{
	char *pTemp;
	char HeaderMsgBuf[6];		// buffer for header of message
	int  idx;
	bool ret = true;
	CString msg;	//#MI130401
	
	// Check input parameter
	if ((NULL == pBuf) && (sizeBuf <= 0)) {
		return false;
	}
	
	// Parse header message
	pTemp = pBuf;
	memcpy(HeaderMsgBuf, pTemp, MAX_LEN_HEADER_MESSAGE);
	pTemp += 6;
	for (idx = 0; idx < MAX_TYPE_MESSAGE; idx++) {
		if (0 == strncmp(HeaderMsgBuf, ResHeaderMsg[idx], MAX_LEN_HEADER_MESSAGE)) {
			break;
		}
	}

	// Parse data message
	switch (idx) {
	case HELO_MESSAGE:	// aHELO message
		{
			m_msgRes.m_header = idx;
			
			// Check end character
			if (EndCharacter != *pTemp) {
				// Show error
				ret = false; 
			}
			msg.Format("RobotLANIF::ParseMessage() oHELO is successful\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			break;
		}

	case WFIF_MESSAGE:	// aWFIF message
		{
			char aWFIFData[60];		// buffer for carrier ID
			char *pTempBuf;			// pointer to determine length of carrier ID
			int	 len;
			m_msgRes.m_header = idx;
			
			// Save carrier ID
			pTempBuf = pTemp;
//			for (len = 0; len < 20; len++) {
			for (len = 0; len < 60; len++) {	//#MI130410
				if ('\x0d' == *pTempBuf) {
					break;	
				}
				pTempBuf++;
			}
			memcpy(aWFIFData, pTemp, len);
			m_msgRes.m_WFIFData = CString(aWFIFData, len);
			pTemp += len; 

			// Check end character
			if (EndCharacter != *pTemp) {
				// Show error
				ret = false;
			}
			msg.Format("RobotLANIF::ParseMessage() oWFIF is successful\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
			break;
		}
	
	case WFAG_MESSAGE:	// aWFAG message
		{
			m_msgRes.m_header = idx;
				
			// Check end character
			if (EndCharacter != *pTemp) {
				// Show error
				ret = false;
			}
			msg.Format("RobotLANIF::ParseMessage() oWFAG is successful\n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}			
			#if !Release
				TRACE(msg);
			#endif
			break;
		}

	default:
		// Show error
		ret = false;
		break;
	}

	return ret;
}


//////////////////////////////////////////////////////////////////////
// Send message to client
//
int	CRobotLANInterface::SendMessage( SOCKET socket,	char *pBuf, int SizeBuf, int Flag)
{
	int r;
	CString msg;	//#MI130401
		
	if (INVALID_SOCKET != socket) {		
		r = send(socket, pBuf, SizeBuf, Flag);
		if (SOCKET_ERROR == r) {
			this->m_err.PutError(Err_SendMessageFail);
			msg.Format("RobotLANIF::SendMessage() unsuccessful \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}	
			#if !Release
				TRACE(msg);
			#endif
		} else {
			msg.Format("RobotLANIF::SendMessage() successful \n");
			if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
				this->m_err.LogSaveNFL(msg);
			}
			#if !Release
				TRACE(msg);
			#endif
		}
	} else {
		r = INVALID_SOCKET;
		msg.Format("RobotLANIF::SendMessage() unsuccessful \n");
		if(this->m_RobotIFLog){	//MI130409RobotI/F LOG
			this->m_err.LogSaveNFL(msg);
		}
		#if !Release
			TRACE(msg);
		#endif
	}
	
	return r;
}


//////////////////////////////////////////////////////////////////////
// Receive message from client
//
int	CRobotLANInterface::RecvMessage( SOCKET socket,	char *pBuf, int SizeBuf, int Flag)
{
	int r = recv(socket, pBuf, SizeBuf, Flag);
// #KS20130413-01(S) [���P]LAN��M�����ב΍�
	if (0 > r) {
		::Sleep(1);
	}
// #KS20130413-01(E)
	return r;
}


//////////////////////////////////////////////////////////////////////
// Set value for header of request message
//
bool CRobotLANInterface::SetHeaderReqMessage(int headerMessage)
{
	bool r = true;
	
	if (headerMessage > MAX_TYPE_MESSAGE) {
		r = false;	
	} else {
		m_msgReq.m_header = headerMessage;
	}

	return r;
}


//////////////////////////////////////////////////////////////////////
// Set wafer angle for request message
//
bool CRobotLANInterface::SetStatusReqMessage(int statusWFIF)
{
	bool r = true;
	
	if (statusWFIF > WFIF_MAX) {
		r = false;
	} else {
		m_msgReq.m_status = statusWFIF;
	}

	return r;
}


//////////////////////////////////////////////////////////////////////
// Set wafer angle for request message
//
bool CRobotLANInterface::SetAngleReqMessage(double waferAngle)
{
	bool r = true;
	
	if ((waferAngle < 0) || (waferAngle > 360)) {		// TODO: consider compare with double type
		r = false;
	} else {
		m_msgReq.m_wfAngle = waferAngle;
	}

	return r;
}


//////////////////////////////////////////////////////////////////////
// Get value of header of response message
//
int CRobotLANInterface::GetHeaderResMessage()
{
	return (m_msgRes.m_header);
}


//////////////////////////////////////////////////////////////////////
// Get value of WFIF of response message
//	
bool CRobotLANInterface::GetWFIFResMessage(CString &aWFIFData)
{
	bool r = true;
	aWFIFData = this->m_msgRes.m_WFIFData;
// #KS20130423-02 [����]���{�b�gIF�E�F�nID�C��
	aWFIFData = aWFIFData.Mid(aWFIFData.ReverseFind('_') + 1);
	return r;
}

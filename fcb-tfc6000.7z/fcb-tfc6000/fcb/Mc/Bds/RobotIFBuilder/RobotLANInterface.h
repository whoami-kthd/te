// RobotLANInterface.h: interface for the CRobotLANInterface class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ROBOTLANINTERFACE_H__7E93425C_5164_4BB6_B4AE_104A8846DD75__INCLUDED_)
#define AFX_ROBOTLANINTERFACE_H__7E93425C_5164_4BB6_B4AE_104A8846DD75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef _WINSOCKAPI_
#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <list>
#include <ws2tcpip.h>
#endif

#include "stdafx.h"
#include <stdlib.h>
#include <Ulib.h>
#include <semaxx.h>

#pragma comment(lib, "ws2_32")

// Define marco
//#define MAX_LENGTH_MESSAGE		50			// Max length message for LAN communication
#define MAX_LENGTH_MESSAGE		100			// Max length message for LAN communication
#define MAX_LEN_REQ_WFIF		10
#define MAX_LEN_REQ_WFAG		13
#define MAX_LEN_HEADER_MESSAGE	6


class CRobotLANInterface  
{
public:
	// Constructor/ Deconstructor
	CRobotLANInterface();
	virtual ~CRobotLANInterface();

	CRobotLANInterface(	int class_Id,
						int myErrStart);
	
	// Data structure for request message
	typedef struct {
		int			m_header;		// header of message
		double		m_wfAngle;		// angle for wafer
		int			m_status;		// status of wafer information: NG: 0; OK: 1
		int			m_clientType;	// Client type: 1 is FC; 3 is RF
	} ReqStruct_t;

	// Data structure for response message
	typedef struct {
		int			m_header;		// header of message
		CString		m_WFIFData;		// aWFIF data from Loader
	} ResStruct_t;

	enum {
		WFIF_NG = 0,
		WFIF_OK,
		WFIF_MAX
	};

	enum {
		HELO_MESSAGE = 0,
		WFIF_MESSAGE,
		WFAG_MESSAGE,
		MAX_TYPE_MESSAGE
	};
	
//////////////////////////////////////////////////////////////////////
// Attribute
	SOCKET			m_clientSocket;		// socket to listen client
	ReqStruct_t		m_msgReq;			// content of request message
	ResStruct_t		m_msgRes;			// content of response message
	CString			m_ipAddress;		// IP address of server
	int				m_portNo;			// port number of server

	int				m_timeout;			// timeout to wait HELO message
	int				m_delayTime;		// delay time for receive message
	int				m_RobotIFLog;		// ���{�b�g�C���^�[�t�F�C�X���O�L��(0:���@1:�L)
	double			m_reqTimeOutLANCnct;// time out for waiting LAN connect #MI130415�^�C���A�E�g�ݒ�Ή�

	ErrorMediator	m_err;				// Error handle

//////////////////////////////////////////////////////////////////////
// Method
	bool	ConnectServer();								// connect to server
	bool	DisconnectServer();								// disconnect to server
	bool	IsOpen();										// check status of server
	
	bool	RecvSendHELOMessage(SOCKET socket);				// receive then send HELO message after connect to server

	bool	BuildMessage(char *pBuf, int *pSizeBuf);		// build message to sent
	bool	ParseMessage(char *pBuf, int sizeBuf);			// parse message received
	int		SendMessage( SOCKET socket,						// send message to client
						 char *pBuf,
						 int SizeBuf,
						 int Flag);									
	int		RecvMessage( SOCKET socket,						// receive message from client
						 char *pBuf,
						 int SizeBuf,
						 int Flag);										
	
	// Access LAN message
	bool SetHeaderReqMessage(int headerMessage);							// Set value for header of request message
	bool SetStatusReqMessage(int statusWFIF);								// Set status of WFIF for request message
	bool SetAngleReqMessage(double waferAngle);								// Set wafer angle for request message

	int GetHeaderResMessage();												// Get value of header of response message
	bool GetWFIFResMessage(CString &aWFIFData);										// Get value of WFIF of response message


	enum Error{
		Err_ConnectingFailed	= 1,	// Cant connect to Server
		Err_ConnectingTimeOut,			// Cant receive oHELO
		Err_SendMessageFail,			// Send message failure
		Err_RecvMessageFail,			// Receive message failure
	};

};

#endif // !defined(AFX_ROBOTLANINTERFACE_H__7E93425C_5164_4BB6_B4AE_104A8846DD75__INCLUDED_)

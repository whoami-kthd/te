// CSMLDCtrl.cpp
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include <mcc.h>

//////////////////////////////////////////////////////////////////////
//Class implementation
//////////////////////////////////////////////////////////////////////
static bool changeMgz = false;

CSMLDCtrl::~CSMLDCtrl()
{

}

CSMLDCtrl::CSMLDCtrl()
{

}

CSMLDCtrl::CSMLDCtrl (
					CString name,
					int class_id,					// Class ID
					CEventX* pEvRequestLoad,		// Load request event
					CEventX* pEvLoadOK,				// Load OK report event
					CEventX* pEvLoadNG,				// Load NG report event
					CEventX* pEvLoadStop,			// Load stop event
					CEventX* pEvFinish,				// Finish event
					OrdinarySnsTBL* pSnsMgzExist,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsMgzExist2,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsCoverClose,	// Cover close detect sensor
					OrdinarySnsTBL* pSnsSubstExist,	// Subst exist sensor
					int idx_mtMgz,					// Transfer motor X index
					int myErrStart					// Error start
					):StdSbstLDUDCtrl(name, class_id, pSnsMgzExist, pSnsMgzExist2, pSnsCoverClose, pSnsSubstExist, idx_mtMgz, myErrStart)
{	
	this->pEvRequestLoad	= pEvRequestLoad;
	this->pEvLoadOK			= pEvLoadOK;
	this->pEvLoadNG			= pEvLoadNG;
	this->pEvLoadStop		= pEvLoadStop;
	this->pEvFinish			= pEvFinish;

	this->pEvRequestLoad->ResetEvent();
	this->pEvLoadOK->ResetEvent();
	this->pEvLoadNG->ResetEvent();
	this->pEvFinish->ResetEvent();
	this->pEvLoadStop->ResetEvent();

	this->m_currentSlot = 0;
	this->m_isAutoRunning = false;
	
	this->m_MCSec = _T("_(Loader magazine)");
	this->m_DVSec = _T("_(Loader magazine)");		
	this->m_PDSec = _T("_(Loader magazine)");		

	//Substrate existence init
//	for(int j = 0; j < eSubstNumberMax; j++){
//		this->waferUmu[j]	= eSubstNone;
//	}

	this->m_slotMapIsMade = false;
//	this->pauseWait.PauseInit();

	// Create thread
	ActionMTC.Create(this,(unsigned int (__cdecl *)(void *))ActionFunc/*,THREAD_PRIORITY_TIME_CRITICAL*/);

}

//==============================================
// Machine data read/ write
//==============================================
BOOL CSMLDCtrl::MCDataRW(BOOL Read,LPCTSTR FNam, CString MSec)
{	
	int	r  = TRUE;
	int r2 = TRUE;

	CString MgzSec = MSec + this->m_MCSec + this->m_MD.MgzD.Sec;
			
	if ((! Read) && FNam[0] == 0) {
		return	r;
	}

	// Magazine data read/ write
	GWPPfileData( FNam, MgzSec,"Load magazine height at teaching",	Read, this->m_MD.MgzD.mgzHeightTeach,	0.0);
	
	GWPPfileData( FNam, MgzSec,"Load magazine (1) elevator offset",		Read, this->m_MD.MgzD.elvOffset[0],	-300.0);	
	GWPPfileData( FNam, MgzSec,"Load magazine (2) elevator offset",		Read, this->m_MD.MgzD.elvOffset[1],	-300.0);	
	
	GWPPfileData( FNam, MgzSec,"Load magazine exchange position",	Read, this->m_MD.MgzD.mgzExchgPos,	-10.0);
	GWPPfileData( FNam, MgzSec,"Load magazine wait position",		Read, this->m_MD.MgzD.mgzWaitPos,	0.0);
	GWPPfileData( FNam, MgzSec,"Load feed pusher limit position",	Read, this->m_MD.MgzD.pusherLimitPos,	-400.0);
//	GWPPfileData( FNam, MgzSec,"Load cassette slit",				Read, this->m_MD.MgzD.currSlitNo,	1);		// yk130508:PD�ֈړ�
	
	return (r);
}	

//=====================================================
// Device data read/ write
//=====================================================		
BOOL CSMLDCtrl::DVDataRW(BOOL Read, LPCTSTR FNam, CString MSec)
{
	int r = TRUE;
	
	CString section = MSec + this->m_DVSec;				

	if ((! Read) && FNam[0] == 0) {
			return	r;
	}

	GWPPfileData( FNam, section,"Load magazine width",					Read, this->m_DD.mgzWidth,		0.0);
	GWPPfileData( FNam, section,"Load magazine height",					Read, this->m_DD.mgzHeight,		0.0);
	GWPPfileData( FNam, section,"Load magazine frame top height",		Read, this->m_DD.frmTopHeight,	0.0);
	GWPPfileData( FNam, section,"Load magazine frame store height",		Read, this->m_DD.frmStoreHeight,0.0);
	GWPPfileData( FNam, section,"Load magazine stock number",			Read, this->m_DD.stockNo,		eMgzMax	,	25);
	GWPPfileData( FNam, section,"Load magazine top height",				Read, this->m_DD.topHeight,		5.0);
	GWPPfileData( FNam, section,"Load magazine pitch",					Read, this->m_DD.pitch,			1.0);
	GWPPfileData( FNam, section,"Load magazine escape level",			Read, this->m_DD.EscLvl,		-1.0);
	GWPPfileData( FNam, section,"Load magazine ring check height",		Read, this->m_DD.EvtRingChkOfsHeight,		-100.0);
	GWPPfileData( FNam, section,"Load magazine elevator sensor timer",	Read, this->m_DD.ElvSns_Timer,	500);		
	GWPPfileData( FNam, section,"Back push timer",						Read, this->m_DD.BackPushTimer,	500);
	return (r);
}

//=====================================================	// yk130508
// Product data read/ write
//=====================================================		
BOOL CSMLDCtrl::PDDataRW(BOOL Read, LPCTSTR FNam, CString PSec)
{
	int r = TRUE;
	
	CString section = PSec + this->m_PDSec;

	if ((! Read) && FNam[0] == 0) {
			return	r;
	}

	GWPPfileData(FNam,section,"Load cassette (1) slit",					Read,this->m_PD.currSlitNo[0],		1);
	GWPPfileData(FNam,section,"Load cassette (2) slit",					Read,this->m_PD.currSlitNo[1],		1);
	GWPPfileData(FNam,section,"Load cassette magazine",					Read,this->m_PD.currMgzNo,		1);

	return (r);
}

//====================================================
// Get next slot number
//====================================================
BOOL CSMLDCtrl::GetNextSlot(int& mgzNo, int& slot, bool& canGet)
{
	BOOL r		= TRUE;
	bool exist	= false;
	bool on	= false;
	bool other	= false;
	
	// Get the current slot  number
	mgzNo		= this->GetCurrMgz();
	slot		= this->GetCurrMgSlot(mgzNo);
	int Plset	= this->GetStockNo(mgzNo); 	
	canGet		= true;
	TRACE("                                   [BDS]CSMLDCtrl::Get NextSlot()�J�n<slot=%d>\n", slot);

	// yk130426:��а�^�]����slot�i�����ı��߂���
	if (this->m_isAging) {
#if 0
		if (slot < 1 || slot > Plset){		// yk130509:��а�^�]����������
			slot = 1;
		}
#endif
	}
	
	// If the current slot is the top slot return false
	if (r) {	
//		// Move feed pusher to magazine escape position		// Magazine��Pusher��ޔ�����K�v�͖���
//		if (r && pMovePusherToMgzEsc) {
//			r = (*pMovePusherToMgzEsc)(true);
//		} else {
//			r = FALSE;
//		}	
		
		for (;r;) {
			if (slot < 1 || slot > Plset){		// yk130405
				canGet = false;
				break;
			}
			// Check subst existence by sensor
			if (r && this->m_mgzFeedType == eFeedChunkOnly) {
				if (r) {
					// Move magazine to ring check position
					r = MgRingCheckPosMove(mgzNo, slot);
				}
				r = this->m_snsSubstExist.IsDetected(exist);
			} else if (r && this->m_mgzFeedType == eFeedBackPush) {
				// Move magazine to load position
				r = MoveToLoadPos(mgzNo, slot);
				TRACE("                                   [BDS]CSMLDCtrl::Get NextSlot()MoveToLoadPos<r=%d>\n", r);
				StopWatch SW(this->m_DD.BackPushTimer);
				// Back push push
				if (r) {
					r = this->IsEnableBackPush();
				}
				r = r && m_CyBackPush.Act(true, true);
				bool bpOrigin = false;
				bool olBackPush = false;
				while(true) {
					// Check origin sensor
					r = r && m_snsBackPushOri.IsDetected(bpOrigin);
#if GPDEBUG																			// #yk140109-1:GPDEBUG���͊��Mag��BackPush�߂�ݻoff�͊Ď����Ȃ�
	bpOrigin = false;
#endif
					if (!bpOrigin) {
						// Push timer start
						SW.Start();
						break;
					}
				}
				
				int t = SW.Read();
				while(t) {
					t = SW.Read();
					if (r) {
						r = r && m_snsBackPushOL.IsDetected(olBackPush);
#if GPDEBUG
	olBackPush = false;
#endif
						// If over load sensor is ON
						if (olBackPush) {
							this->m_err.PutError(Err_BackPushNotOri);		// #yk140123-5:BDS:Load�ޯ��߼����ߕ��ׂł��ُ�ɂȂ�Ȃ�
							r = FALSE;
							break;
						}
					}
				}
				r = m_CyBackPush.Act(false, true) && r;						// #yk140123-5:BDS:Load�ޯ��߼����ߕ��ׂł��ُ�ɂȂ�Ȃ�

				// Check substrate in rail
				if (r && this->m_mgzFeedType == eFeedBackPush) {
					if (r) {
						r = m_snsSubInRail.IsDetected(exist);
						TRACE("                                   [BDS]CSMLDCtrl::Get NextSlot()�ޯ��߯���ŉ��o���Ċ�L���ݻ����<sns=%d>\n", exist);
					}
				}
			}
			
#if GPDEBUG
	if (r)	exist = true;
#endif

#if !GPDEBUG
			// yk130426:��а�^�]���̂ݗL���ݻ�𖳌��ɂ���
			if (this->m_isAging) {
				exist = true;
			}
#endif

			if (!this->m_isAutoRunning && !exist) {	// #yk140410-3:�蓮���쎞�Ɋ�������ꍇ�͂�1�i�ňُ�ɂ���
				this->m_err.PutError(Err_SubstNotExistL);
				r = FALSE;
				slot ++;
				SetCurrMgSlot(mgzNo, slot);		// yk130502
				break;
			}
			// If can detect then break
			if (r && exist) {
				// HangNT-130424
//				slot++;
				break;
			}

			// If cannot detect then move to next slot
			slot ++;
		}
	} // End for

	if (!canGet)  {
		// If FALSE then move magazine to wait position
//		r = MoveToWaitPos();			BOOL CSMLDCtrl::WaitAndExecute()

	}	

	TRACE("                                   [BDS]CSMLDCtrl::Get NextSlot()����<slot=%d,r=%d,canget=%d>\n", slot, r, canGet);
	return r;
}

//=====================================================
// Wait and execute function
//=====================================================
BOOL CSMLDCtrl::WaitAndExecute()
{
	BOOL r	= TRUE;
	BOOL r2 = TRUE;

	// Wait for request event
	enum{
		WaitCnt		= 3,
	};

	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinish;			// Finish event
	ppObjects[1]	= pEvRequestLoad;		// Move magazine to load position
	ppObjects[2]	= pEvLoadStop;			// Auto stop event
	
	CMultiLock	M(ppObjects,WaitCnt);
	// Wait for event until end
	for (; ;) {
		int i = M.Lock(INFINITE, FALSE);
		M.Unlock();
		i -= WAIT_OBJECT_0;		// if get event

		TRACE("                                   [BDS]%s::WaitAndExecute()-Receive event:i=%d\n", this->m_name, i);

		if (0 == i ||2 == i ) {			// If get finish event
			r = FALSE;		
		} else if (1 == i) {
			r = TRUE;		// yk130428:r������
			int slotNo;
			int mgzNo;
			bool canGet = false;


			// ��o���\MagazineCheck								// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
			if (r) {
				r = isGetMgzSide(mgzNo, slotNo, canGet);
			}

			if (r && !canGet) {
				if (this->m_isAutoRunning) {
					if (r) {
						r = this->MgEndSub();		// ϶޼��or��������̌������
						if (r) {
							r = isGetMgzSide(mgzNo, slotNo, canGet);		// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
							if (!canGet){
								r = FALSE;
								this->m_err.PutError(Err_MgzNotExistL);
// #IK20130605-05 [�C��] ϶޼�݋�̂Ƃ��͏����ʒu�Ƃ���
								SetCurrMgSlot(eDownMgz, 1);
								SetCurrMgSlot(eUpMgz, 1);
							}

						}
					}
				} else {
					// If manual run mode then put out error
					r = FALSE;
					this->m_err.PutError(Err_MgRunOutSubst);
// #IK20130605-05 [�C��] ϶޼�݋�̂Ƃ��͏����ʒu�Ƃ���
					SetCurrMgSlot(eDownMgz, 1);
					SetCurrMgSlot(eUpMgz, 1);
				}
			}
			if (r && canGet) {
				// Move to load position
				if (r) {
					SetCurrMgSlot(mgzNo, slotNo);		// yk130502
					r = MoveToLoadPos(mgzNo, slotNo);
					slotNo++;							// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
					SetCurrMgSlot(mgzNo, slotNo);		// ��
				}
			}

			// If move successful then set load OK report event
			if (r) {
				pEvLoadOK->SetEvent();
			} else {
				pEvLoadNG->SetEvent();
			}			
		}

		// Reset request event
		pEvRequestLoad->ResetEvent();
	}

	return (r);
}

//=====================================================
// Action function
//=====================================================
UINT CSMLDCtrl::ActionFunc(MTCtrl *pParam)
{
	MTCtrl	*pMTC=(MTCtrl *)pParam;	// 
	CSMLDCtrl	*pMCC = (CSMLDCtrl *)pMTC->GetpMCC();	// 
	int	Command,Parameter;
	int	r;

	while (TRUE){
		pMTC->WaitForCommand(Command,Parameter);	// ����ގw���҂�
		if(Command == MCCStd::CmdKill)	break;		// �I�������

		pMCC->SetActionFlag(TRUE);
		r=TRUE;

		switch(Command) {
		case	MCCStd::CmdReset:
			//r = pMCC->Reset();
			break;	
		case	CmdWaitAndExecute:
			r = pMCC->WaitAndExecute();
			break;
		case	CmdMoveToExchg:
			r = pMCC->MoveToExchPos();
			break;
		}

		pMCC->SetActionFlag(FALSE);
		pMTC->CommandEnd(r);			// ���ʂ��
	}

	pMTC->CommandEnd(TRUE);				// ���ʂ��

	return	0;
}

//=====================================================
// Init instance
//=====================================================
BOOL CSMLDCtrl::InitInstance()
{
	int	r=TRUE;	
	//Start main thread
	r = ActionMTC.ActionStart(CmdWaitAndExecute, NULL, NULL, FALSE);

	return (r);
}

//=====================================================
// Magazine end sub
//=====================================================
BOOL CSMLDCtrl::MgEndSub()
{
	TRACE("                                   [BDS]CSMLDCtrl::Mg EndSub()���۰��϶޼�݌������-�J�n\n");
	BOOL r	= TRUE;
	
	// Set magazine slot to 0
//	this->SetCurrMgSlot(0);	

	// Move magazine to exchange position
	r = this->MoveToExchPos();

	// Pause and wait for operator
	if (r) {
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
		CSingleLock	S(this->pMCPauseSema,true);
// #IK20130608-02 [�C��] auseAndWait�C��
		this->pauseWait.PauseInit();
		TRACE("                                   [BDS]CSMLDCtrl::Mg EndSub()���۰��϶޼�݌������-�\���v��<r=%d>\n", r);
		r = this->pauseWait.SetPauseAndWait(ePauseNeedMgzChgLoad);
		TRACE("                                   [BDS]CSMLDCtrl::Mg EndSub()���۰��϶޼�݌������-��ʂ�������<r=%d>\n", r);
	}

	for (;r;) {
		bool onCover = true,onExistU = true,onExistL = true;					// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
		// Check magazine cover		// yk130502:϶޼�݌������̏������
		if (r) {
			r = this->m_snsCoverClose.IsDetected(onCover);
			if (r){
				if ( !onCover ) {
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
					CSingleLock	S(this->pMCPauseSema,true);
// #IK20130608-02 [�C��] auseAndWait�C��
					this->pauseWait.PauseInit();
					r = this->pauseWait.SetPauseAndWait(ePauseMgzCoverCloseL);
				}
//				if (!r) {
//					this->m_err.PutError(Err_CoverOpenL);
//					r = FALSE;
//				}
			}
		}

		// Check magazine exist
		if (r) {
			r = this->m_snsMgzExist[0].IsDetected(onExistU) && r;		// ��i		// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
			r = this->m_snsMgzExist[1].IsDetected(onExistL) && r;		// ���i	
			// yk130506:��а�^�]���;ݻ�𖳌��ɂ���
			if (this->m_isAging) {
				onExistU = true;
			}
			if (r){
				if ( !onExistU && !onExistL ) {
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
					CSingleLock	S(this->pMCPauseSema,true);
// #IK20130608-02 [�C��] auseAndWait�C��
					this->pauseWait.PauseInit();
					r = this->pauseWait.SetPauseAndWait(ePauseMgzExistL);
				}

//				if (!r) {
//					this->m_err.PutError(Err_MgzNotExistL);
//					r = FALSE;
//				}
			}
		}
		if (r && onCover && (onExistU || onExistL)) {
			break;		// ����
		}
	}
	
	// Move magazine to top position
	if (r) {
		SetCurrMgSlot(0, 1);
		SetCurrMgSlot(1, 1);
//		r = MoveToLoadPos(1);			// yk130503
	}

	TRACE("                                   [BDS]CSMLDCtrl::Mg EndSub()���۰��϶޼�݌������-����<r=%d>\n", r);
	return (r);
}

#if 0
//==================================================
// Machine data read
//==================================================
BOOL CSMLDCtrl::MC_Data_File_Read(LPCTSTR FileName)
{
	int	r = MCDataRW(TRUE,FileName);

	// Set auto event between unloader IF and unloader magazine
	//pMCC->BDS.SetAutoLoadEvent(&EvRequestLoad, &EvLoadOK, &EvLoadNG, &EvLoadStop);
	return	r;
}

//==================================================
// Machine data write
//==================================================
BOOL CSMLDCtrl::MC_Data_File_Write(LPCTSTR FileName)
{
	int	r = MCDataRW(FALSE,FileName);
	return	r;
}

//==================================================
// Device data read
//==================================================
BOOL CSMLDCtrl::DV_Data_File_Read(LPCTSTR FileName)
{
	int	r = DVDataRW(TRUE,FileName);
	return	r;
}

//==================================================
// Machine data write
//==================================================
BOOL CSMLDCtrl::DV_Data_File_Write(LPCTSTR FileName)
{
	int	r = DVDataRW(FALSE,FileName);
	return	r;
}

#endif

///////////////////////////////////////////////////
// Move to load position
//
BOOL CSMLDCtrl::MoveToLoadPos(int mgzNo, int slotNo)
{
	TRACE("                                   [BDS]%s::Move ToLoadPos()<slot=%d>\n", this->m_name, slotNo);
	BOOL r		= TRUE;
	bool exist	= true;
	double	Pos = 0.0;	// target position

	int Plset = this->GetStockNo(mgzNo);
	if (r && (Plset == 0)) {
		r = FALSE;
	}
	
	int No = slotNo;
	if (r && (No > Plset))	{
		No = Plset;
	} else if (1 > No) {
		No = 1;
	}	

	if (r) {
		// Calculate the target position
		double TopHeight	= this->m_DD.topHeight;
		double ElvOffSet	= this->m_MD.MgzD.elvOffset[mgzNo];
		double Pitch		= this->m_DD.pitch;
		double EscLevel		= this->m_DD.EscLvl;
		
		Pos  = TopHeight + ElvOffSet;	
		Pos += (No - 1) * Pitch;
		Pos += EscLevel;

		//TRACE("FCB-%s::MoveToLoadPos() - Slot No = %d TopHeight = %lf, Pitch = %lf, ElvOffSet = %lf, Pos = %lf\n",this->m_name, No, TopHeight, Pitch, ElvOffSet, Pos);

		// 
		if (r) {
			r = this->MgzMoveAbs(Pos, true);
		}

#if 0

		// Check existence of substrate at current slot
		if (r) {
			r = this->m_snsSubstExist.IsDetected(exist);

			// If substrate is not exist
			if (r && !exist) {
				// Put error
				this->m_err.PutError(Err_SubstNotExistL);
				r = FALSE;
			}
		}
#endif
		
		// Set the value of current magazine slot if move successfully
		if (r) {
			this->SetCurrMgSlot(mgzNo, No);
		}
	}

//	TRACE("                                   [BDS]CSMLDCtrl::MoveToLoadPos() - Finish\n");
	return(r);
}

///////////////////////////////////////////////////
// Move magazine to exchange position
//================================================
BOOL CSMLDCtrl::MoveToExchPos()
{
	BOOL r = TRUE;
	
	// Move magazine to exchange position
	r = MgzMoveAbs(this->m_MD.MgzD.mgzExchgPos, true);

	//TRACE("FCB-%s::MoveToExchPos() - Move to position: %f\n", this->m_name, this->m_MD.MgzD.mgzExchgPos);

	return r;
}

//================================================
// Magazine move to wait position
//================================================
BOOL CSMLDCtrl::MoveToWaitPos()
{
	BOOL r = TRUE;
	
	// Move magazine to wait position
	r = MgzMoveAbs(this->m_MD.MgzD.mgzWaitPos, true);

	//TRACE("FCB-%s::MoveToWait() - Move to position: %f\n", this->m_name, this->m_MD.MgzD.mgzWaitPos);

	return r;
}

//================================================
// Magazine move abs
//================================================
BOOL CSMLDCtrl::MgzMoveAbs(double pos, bool wait)
{
	BOOL r				= TRUE;	
	
	if (r) {
		// Action check
		r = this->m_mtMgz.ActionCheck();
	}
	
	// Get the speed ratio
	double speed	= this->m_mtMgz.GetHighSpeed();
	//speed			= speed  * this->m_MD.MgzD.speedRatio;

	// Check BackPush sensor
	if (r) {
		bool on = false;
		this->m_CyBackPush.Sts(false,on);
		if (!on){
			r = false;
			this->m_err.PutError(Err_BackPushNotOri);
		}
	}
	// Check cover close sensor			// yk130430#8:SubstMagazine Cover�ݻ
	if (r) {
		bool on = false;
		r = this->m_snsCoverClose.IsDetected(on);
// #IK20130508-05 [�C��] ϶޼�ݍ���è��ݸޏC��
		if (m_isAutoRunning) {
			// Pause and wait
			if (r && !on) {
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
				CSingleLock	S(this->pMCPauseSema,true);
// #IK20130608-02 [�C��] auseAndWait�C��
				this->pauseWait.PauseInit();
				r = this->pauseWait.SetPauseAndWait(ePauseMgzCoverCloseL);
			}
		} else {
			if (r && !on) {
				r = false;
			}
		}
		if (!r) {
			this->m_err.PutError(Err_CoverOpenL);
			r = FALSE;
		}
	}


	if (r && isAbleToMoveMgz()) {
		// Move magazine
		r = this->m_mtMgz.MotorMoveAbs(pos, speed, (wait)? TRUE : FALSE);
	}

	return(r);
}

//================================================
// Move magazine to ring check position
//================================================
BOOL	CSMLDCtrl::MgRingCheckPosMove(int mgzNo, int No){	
	BOOL r = TRUE;
	double Pos			= 0;
	double EvtPos		= 0;
	double EvtChkPos	= 0;
	double Pitch		= 0;
	
	int Plset = this->GetStockNo(mgzNo);
	if (r && (Plset == 0)) {
		r = FALSE;
	}

	if (r && (No > Plset))	{
		No = Plset;
	} else if (1 > No) {
		No = 1;
	}	

	
	EvtPos			+= this->m_DD.topHeight;
	EvtChkPos		+= this->m_DD.EvtRingChkOfsHeight;
	Pitch			=  this->m_DD.pitch;

	Pos = EvtChkPos + EvtPos ;
	Pos += (No - 1) * Pitch;
	r	= MgzMoveAbs(Pos, true);
	return r;
}

//================================================
// Make slot map
//================================================
BOOL CSMLDCtrl::MakeSlotMap()
{
	int r = TRUE;
	////////////////////////////////////////////
	
	bool isWTrfSafe = false;
	
	////////////////////////////////////////////
	//
	// SlotMap
	//
	int numberSlit;
		numberSlit = this->m_DD.stockNo[eUpMgz];

		for(int i=0; i < numberSlit; i++){
			bool exist = false;
			r = this->MgRingCheckPosMove(eUpMgz, i+1);
			::Sleep(this->m_DD.ElvSns_Timer);

			if (r) {
				r = this->m_snsSubstExist.IsDetected(exist);
			}
			#if GPDEBUG
			exist = false;
			#endif
			// 
			if (r && exist) {				
				this->waferUmu[0][i]	= eSubstExist;
			} else {				
				this->waferUmu[0][i]	= eSubstNone;
			}
		}

#if GPDEBUG
		{
			for(i=0;i<5;i++){
				this->waferUmu[0][i]	= eSubstExist;
			}
			for(i = 5;i < numberSlit;i++){
				this->waferUmu[0][i]	= eSubstNone;
			}
		}
#endif	

		if (r) {
			this->m_slotMapIsMade = true;
		}
	return(r);
}

//================================================
// Check if magazine is currently at position of slotNo
//================================================
bool CSMLDCtrl::isMgzAtSlotPos()
{
	BOOL r			= TRUE;
	double curPos	= 0.0;
	double calPos	= 0.0;
	int slotNo		= 0;
	int mgzNo		= 0;
	
	// Get current slot
	if (r) {
		mgzNo = GetCurrMgz();
		slotNo = GetCurrMgSlot(mgzNo);
	}

	// Get the current position of load magazine
	if (r) {
		r = this->m_mtMgz.MotorPosition(curPos);
	}

	// Calculate of position corresponding to slotNo
	double TopHeight	= this->m_DD.topHeight;
	double ElvOffSet	= this->m_MD.MgzD.elvOffset[mgzNo];
	double Pitch		= this->m_DD.pitch;
	double EscLevel		= this->m_DD.EscLvl;
		
	calPos  = TopHeight + ElvOffSet + EscLevel;	
	calPos += (slotNo - 1) * Pitch;

	// Compare 2 position if match
	if (r && (calPos - 0.1 < curPos) && (calPos + 0.1 > curPos)) {
		r = TRUE;
	} else {
		r = FALSE;
	}

	return (r != FALSE);
}


//=================================================
// Check if can move magazine
//=================================================
BOOL  CSMLDCtrl::isAbleToMoveMgz()
{
	BOOL r = TRUE;
// �R���x�A�[�����̂��߈ȉ��s�v
#if 0
	double pusherPos	= 0.0;
	bool origin		= false;
	bool exist		= false;
	if (this->mgzFeedType == eFeedBackPush) {
		r = m_snsBackPushOri.IsDetected(origin);
		if (r && !origin) {
			// Put error code
			this->m_err.PutError(Err_BackPushNotOri);
			r = FALSE;
		}
		if (r) {
			r = m_snsSubInRail.IsDetected(exist);
			if (r && exist) {
				// Put error code
				this->m_err.PutError(Err_SubstrateInRail);
				r = FALSE;
			}
		}
	}
	// Get the current position of load pusher
	if (r) {
		r = (*this->pGetPusherPos)(true, pusherPos);
	}

	// If load pusher in limit position then move to escape position
	if (r && (pusherPos < this->m_MD.MgzD.pusherLimitPos - 0.1)) {
		r = (*this->pMovePusherToMgzEsc)(true);

		if (!r) {
			// Put error
			this->m_err.PutError(Err_MazPusherIL);
			r = FALSE;
		}
	}	
#endif
	return(r);
}

// #IK20130508-02 [�C��] ۰�ޗ�O����ב΍�
void CSMLDCtrl::SetStopFlag(int flag)		// �����~�׸ސݒ�
{
	MCCStd::SetStopFlag(flag);
}

BOOL CSMLDCtrl::IsEnableBackPush()
{
	BOOL r = TRUE;
	// Check subtrate in rail sensor
	bool subInRail = false;
	r = m_snsSubInRail.IsDetected(subInRail);
#if GPDEBUG
	subInRail = false;
#endif
	if (!r || subInRail) {
		// put error
		this->m_err.PutError(Err_SubstrateInRail);
		r = FALSE;
	}
	
	// Check position of magazine elevator
	double mgzPos = 0.0;
	if (r) {
		r = m_mtMgz.MotorPosition(mgzPos);
		int mgzNo = this->GetCurrMgz();
		double max, min;
		max = m_MD.MgzD.elvOffset[mgzNo] + m_DD.topHeight + (m_DD.stockNo[mgzNo] - 1)*m_DD.pitch + 5;
		min = m_MD.MgzD.elvOffset[mgzNo] + m_DD.topHeight - 5;
		if (mgzPos < min || mgzPos > max) {
			//put error code 
#if !GPDEBUG		// TODO check data
			this->m_err.PutError(Err_MgzPosIllegal);
			r = FALSE;
#endif
		}
	}

	// Check feed chuck open or not
#if 0	// �����ł͕s�v
	bool open = false;
	if (r) {
		if (pFeedChuckOnSns) {
			(*this->pFeedChuckOnSns)(open);
		}
		if (open) {
			// put error code 
			this->m_err.PutError(Err_FeedChuckNotOpen);
			r = FALSE;
		}
	}
#endif
	return r;
}

// Check Magazine Status:Magazine�L��sensor,Slot�ԍ�������			// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
BOOL CSMLDCtrl::isGetMgzSide(int& mgzNo, int& slotNo, bool& canGet)
{
	BOOL r = TRUE;
	int Plset;
	canGet = false;
	bool on;

	// Current����Magazine���check
	mgzNo	= this->GetCurrMgz();
	slotNo	= this->GetCurrMgSlot(mgzNo);
	Plset	= this->GetStockNo(mgzNo); 	

	if (r) {
		r = this->m_snsMgzExist[1 - mgzNo].IsDetected(on);	// ϶޼�ݍݐоݻ
	}
	if (r && this->m_isAging) {
		on = true;
	}

	if (r && on && (1 <= slotNo) && (slotNo <= Plset) ) {
		this->SetCurrMgz(mgzNo);
		if (r) {
			r = GetNextSlot(mgzNo, slotNo, canGet);
		}
	}
	if (r && !canGet) {				// Current�����������̏ꍇ�͑��葤������
		if(eDownMgz == mgzNo){
			this->SetCurrMgz(eUpMgz);
		} else {
			this->SetCurrMgz(eDownMgz);
		}
		// ��Current����Magazine���check
		mgzNo	= this->GetCurrMgz();
		slotNo	= this->GetCurrMgSlot(mgzNo);
		Plset	= this->GetStockNo(mgzNo); 	

		if (r) {
			r = this->m_snsMgzExist[1 - mgzNo].IsDetected(on);	// ϶޼�ݍݐоݻ
		}
		if (r && this->m_isAging) {
			on = true;
		}

		if (r && on && (1 <= slotNo) && (slotNo <= Plset) ) {
			this->SetCurrMgz(mgzNo);
			if (r) {
				r = GetNextSlot(mgzNo, slotNo, canGet);
			}
		}
	}

	return	r;
}

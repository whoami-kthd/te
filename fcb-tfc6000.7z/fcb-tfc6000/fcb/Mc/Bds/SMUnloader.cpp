//===========================================================
//Unloader method implementation
//===========================================================
#include "stdafx.h"
#include "FCB.h"
#include <mcc.h>
#include "CommonDef.h"

//////////////////////////////////////////////////////////////////////
//Class implementation
//////////////////////////////////////////////////////////////////////
static bool changeMgz = false;

CSMUDCtrl::~CSMUDCtrl()
{

}
CSMUDCtrl::CSMUDCtrl()
{

}

CSMUDCtrl::CSMUDCtrl (
					CString name,
					int class_id,					// Class ID
					CEventX* pEvRequestUnLoad,		// Load request event
					CEventX* pEvUnLoadOK,			// Load OK report event
					CEventX* pEvUnLoadNG,			// Load NG report event
					CEventX* pEvUnLoadStop,			// Load stop event
					CEventX* pEvFinish,				// Finish event
					OrdinarySnsTBL* pSnsMgzExist,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsMgzExist2,	// Magazine exist sensor
					OrdinarySnsTBL* pSnsCoverClose,	// Cover close detect sensor
					OrdinarySnsTBL* pSnsSubstExist,	// Subst exist sensor
					int idx_mtMgz,					// Transfer motor X index
					int myErrStart					// Error start
					):StdSbstLDUDCtrl(name, class_id, pSnsMgzExist, pSnsMgzExist2, pSnsCoverClose, pSnsSubstExist, idx_mtMgz, myErrStart)
{	
	this->pEvRequestUnLoad	= pEvRequestUnLoad;
	this->pEvUnLoadOK		= pEvUnLoadOK;
	this->pEvUnLoadNG		= pEvUnLoadNG;
	this->pEvUnLoadStop		= pEvUnLoadStop;
	this->pEvFinish			= pEvFinish;

	this->pEvRequestUnLoad->ResetEvent();
	this->pEvUnLoadOK->ResetEvent();
	this->pEvUnLoadNG->ResetEvent();
	this->pEvFinish->ResetEvent();
	this->pEvUnLoadStop->ResetEvent();

	this->m_currentSlot = 0;
	this->m_isAutoRunning = false;
	
	this->m_MCSec = _T("_(Unloader magazine)");
	this->m_DVSec = _T("_(Unloader magazine)");	
	this->m_PDSec = _T("_(Unloader magazine)");	
	
	this->m_slotMapIsMade = false;
//	this->pauseWait.PauseInit();

	// Create thread
	ActionMTC.Create(this,(unsigned int (__cdecl *)(void *))ActionFunc/*,THREAD_PRIORITY_TIME_CRITICAL*/);

}

//==============================================
// Method implementation
//==============================================
BOOL CSMUDCtrl::MCDataRW(BOOL Read,LPCTSTR FNam, CString MSec)
{	
	int	r  = TRUE;
	int r2 = TRUE;

	CString MgzSec = MSec + this->m_MCSec + this->m_MD.MgzD.Sec;
			
	if ((! Read) && FNam[0] == 0) {
		return	r;
	}			
			
	// Magazine data read/ write
	
	GWPPfileData( FNam, MgzSec,"Unload magazine (1) elevator offset",		Read, this->m_MD.MgzD.elvOffset[0],	-300.0);
	GWPPfileData( FNam, MgzSec,"Unload magazine (2) elevator offset",		Read, this->m_MD.MgzD.elvOffset[1],	-300.0);
	GWPPfileData( FNam, MgzSec,"Unload magazine exchange position",			Read, this->m_MD.MgzD.mgzExchgPos,	-10.0);
	GWPPfileData( FNam, MgzSec,"Unload magazine wait position",				Read, this->m_MD.MgzD.mgzWaitPos,	0.0);
	GWPPfileData( FNam, MgzSec,"Unload feed pusher limit position",			Read, this->m_MD.MgzD.pusherLimitPos, 300.0);
//	GWPPfileData( FNam, MgzSec,"Unload cassette slit",						Read, this->m_MD.MgzD.currSlitNo,	25);		// yk130508:PD�ֈړ�
			
	return (r);
}	
		
BOOL CSMUDCtrl::DVDataRW(BOOL Read, LPCTSTR FNam, CString MSec)
{
	int r = TRUE;

	CString section = MSec + this->m_DVSec;	
	if ((! Read) && FNam[0] == 0) {
		return	r;
	}


	GWPPfileData( FNam, section,"Unload magazine width",				Read, this->m_DD.mgzWidth,		0.0);
	GWPPfileData( FNam, section,"Unload magazine height",				Read, this->m_DD.mgzHeight,		0.0);
	GWPPfileData( FNam, section,"Unload magazine frame top height",		Read, this->m_DD.frmTopHeight,	0.0);
	GWPPfileData( FNam, section,"Unload magazine frame store height",	Read, this->m_DD.frmStoreHeight,0.0);
	GWPPfileData( FNam, section,"Unload magazine stock number",			Read, this->m_DD.stockNo,		eMgzMax	,	25);
	GWPPfileData( FNam, section,"Unload magazine top height",			Read, this->m_DD.topHeight,		5.0);
	GWPPfileData( FNam, section,"Unload magazine pitch",				Read, this->m_DD.pitch,			1.0);
	GWPPfileData( FNam, section,"Unload magazine escape level",			Read, this->m_DD.EscLvl,		1.0);
	GWPPfileData( FNam, section,"Unload magazine ring check height",	Read, this->m_DD.EvtRingChkOfsHeight,		-100.0);	
	GWPPfileData( FNam, section,"UnLoad magazine elevator sensor timer",Read, this->m_DD.ElvSns_Timer,	500);
				
	return (r);
}

//=====================================================	// yk130508
// Product data read/ write
//=====================================================		
BOOL CSMUDCtrl::PDDataRW(BOOL Read, LPCTSTR FNam, CString PSec)
{
	int r = TRUE;
	
	CString section = PSec + this->m_PDSec;

	if ((! Read) && FNam[0] == 0) {
			return	r;
	}

	GWPPfileData(FNam,section,"Unload cassette (1) slit",						Read,this->m_PD.currSlitNo[0],		25);
	GWPPfileData(FNam,section,"Unload cassette (2) slit",						Read,this->m_PD.currSlitNo[1],		25);
	GWPPfileData(FNam,section,"Unload cassette magazine",					Read,this->m_PD.currMgzNo,		1);

	return (r);
}

///////////////////////////////////////////////////
// Get next slot number
//
BOOL CSMUDCtrl::GetNextSlot(int& mgzNo, int& slot, bool& canGet)
{
	BOOL r		= TRUE;
	bool exist	= false;
	bool on	= false;
	bool other	= false;

	canGet		= true;
	mgzNo = this->GetCurrMgz();
	// Get the current slot  number
	slot		= this->GetCurrMgSlot(mgzNo);
	int Plset	= this->GetStockNo(mgzNo); 	

	TRACE("                                   [BDS]%s::Get NextSlot()�J�n<slot=%d>\n", this->m_name, slot);
	
	// yk130508:��а�^�]����slot�i�����ı��߂���
	if (this->m_isAging) {
#if 0					// yk130509:��а�^�]����������
		if (slot < 1 || slot > m_DD.stockNo[mgzNo]){
			slot = m_DD.stockNo;
		}
#endif
	}

	if (r) {	// Else get next slot
//		// Move feed pusher to magazine escape position	// yk130428:FeedPush�͂����œ������Ȃ�
//		if (r && pMovePusherToMgzEsc) {
//			r = (*pMovePusherToMgzEsc)(false);
//		} else {
//			r = FALSE;
//		}

		for (;r;) {
			// If the current slot is the top slot return false
			if ( slot < 1 || slot > Plset) {
				canGet = false;
				break;
			}
			if (r && this->m_mgzFeedType == eFeedChunkOnly) {
				// Move magazine to ring check position
				if (r) {
					r = MgRingCheckPosMove(mgzNo, slot);
				}
				
				// Check subst existence by sensor
				if (r) {
					r = this->m_snsSubstExist.IsDetected(exist);
				}
			} else if (r && this->m_mgzFeedType == eFeedBackPush) {
				// Move to load position
				exist = false;
				r = this->MoveToLoadPos(mgzNo, slot);
			}

#if GPDEBUG
			if (slot > 1) {
				exist = false;
			} else {
				exist = true;
			}
#endif
			
#if !GPDEBUG
			// yk130426:��а�^�]���̂ݗL���ݻ�𖳌��ɂ���
			if (this->m_isAging) {
				exist = false;
			}
#endif
			// If not exist then break
			if (r && !exist) {
				// HangNT130424
//				slot--;
				break;
			} else {
				slot--;
			}
		} // for
	}

//	if (!canGet) {		// yk130428
//		TRACE("                                   [BDS]Unload Magazine Full\n");
//		// If cannot get the next slot then move magazine to wait pos		
//		r = MoveToWaitPos();		
//	}

	TRACE("                                   [BDS]CSMUDCtrl::Get NextSlot()����\n");
	return r;
}

BOOL CSMUDCtrl::WaitAndExecute()
{
	BOOL r	= TRUE;
	BOOL r2 = TRUE;

	// Wait for request event
	enum{
		WaitCnt		= 3,
	};

	CSyncObject *ppObjects[WaitCnt] = {0};
	ppObjects[0]	= pEvFinish;			// Finish event
	ppObjects[1]	= pEvRequestUnLoad;		// Move magazine to load position
	ppObjects[2]	= pEvUnLoadStop;		// Auto unload stop event
	
	CMultiLock	M(ppObjects,WaitCnt);
	// wait for event until end
	for (;/*r*/;) {	// yk130428
		int i = M.Lock(INFINITE, FALSE);
		M.Unlock();
		i -= WAIT_OBJECT_0;		// if get event

		TRACE("                                   [BDS]%s::WaitAndExecute()����Ď�M<i=%d>\n", this->m_name, i);

		if (0 == i || 2 == i) {			// if get finish event
			r = FALSE;		
		} else if (1 == i) {
			r = TRUE;		// yk130428
			int slotNo;
			int mgzNo;
			bool canGet = false;

			// Get next slot
			if (r) {
				r = isGetMgzSide(mgzNo, slotNo, canGet);			// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
			}
			
			// If cannot get the next slot then exchange magazine
			if (r && !canGet) {
				if (this->m_isAutoRunning) {
					r = MgEndSub();
					if (r) {
						r = isGetMgzSide(mgzNo, slotNo, canGet);		// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
						if (!canGet){
							r = FALSE;
							this->m_err.PutError(Err_MgzNotExistU);
// #IK20130605-05 [�C��] ϶޼�݋�̂Ƃ��͏����ʒu�Ƃ���
							SetCurrMgSlot(eDownMgz, GetStockNo(eDownMgz));
							SetCurrMgSlot(eUpMgz, GetStockNo(eUpMgz));
						}
					}
				} else {
					r = FALSE;
					this->m_err.PutError(Err_MgFullSubst);
// #IK20130605-05 [�C��] ϶޼�݋�̂Ƃ��͏����ʒu�Ƃ���
					SetCurrMgSlot(eDownMgz, GetStockNo(eDownMgz));
					SetCurrMgSlot(eUpMgz, GetStockNo(eUpMgz));
				}
			}
			if (r && canGet) {						// yk130503
				// Move to load position
				if (r) {
					SetCurrMgSlot(mgzNo, slotNo);
					r = MoveToLoadPos(mgzNo, slotNo);
					slotNo--;											// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
					SetCurrMgSlot(mgzNo, slotNo);
				}
			}
			// If move successful then set load OK report event
			if (r) {
				pEvUnLoadOK->SetEvent();
			} else {
				pEvUnLoadNG->SetEvent();
			}			
		}

		// Reset request event
		pEvRequestUnLoad->ResetEvent();
	}

	return (r);
}

//==============================================================
// Action function
//
UINT CSMUDCtrl::ActionFunc(MTCtrl *pParam)
{
	MTCtrl	*pMTC=(MTCtrl *)pParam;	// MTCtrl ��޼ު�Ă��߲��
	CSMUDCtrl	*pMCC = (CSMUDCtrl *)pMTC->GetpMCC();	// ���u�����޼ު�Ăւ��߲��
	int	Command,Parameter;
	int	r;

	while (TRUE) {
		pMTC->WaitForCommand(Command,Parameter);	// ����ގw���҂�
		if(Command == MCCStd::CmdKill)	break;		// �I�������

		pMCC->SetActionFlag(TRUE);
		r=TRUE;
		switch (Command) {
		case	MCCStd::CmdReset:
			//r = pMCC->Reset();
			break;	
		case	CmdWaitAndExecute:
			r = pMCC->WaitAndExecute();
			break;
		case	CmdMoveToExchg:
			r = pMCC->MoveToExchPos();
			break;
		}

		pMCC->SetActionFlag(FALSE);
		pMTC->CommandEnd(r);			// ���ʂ��
	}

	pMTC->CommandEnd(TRUE);				// ���ʂ��
	return	0;
}

BOOL CSMUDCtrl::InitInstance() {
	int	r=TRUE;	
	
	//Start main thread
	r = ActionMTC.ActionStart(CmdWaitAndExecute, NULL, NULL, FALSE);

	return (r);
}

BOOL CSMUDCtrl::MgEndSub()
{
	TRACE("                                   [BDS]CSMUDCtrl::Mg EndSub() - Start\n");
	BOOL r = TRUE;
	bool on = true;
	
	// Set magazine slot to 0
//	this->SetCurrMgSlot(0);	

	// Move magazine to exchange position
	r = this->MoveToExchPos();	

	// Pause and wait
	if (r) {
		//TODO(HangNT): need to modify pause and wait processing
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
		CSingleLock	S(this->pMCPauseSema,true);
// #IK20130608-02 [�C��] auseAndWait�C��
		this->pauseWait.PauseInit();
		r = this->pauseWait.SetPauseAndWait(ePauseNeedMgzChgUnload);
	}

	for (;r;) {
		bool onCover = true,onExistU = true,onExistL = true;		// #yk140126-1:BDS:϶޼�ݍݐоݻ������.
		// Check magazine cover		// yk130502:϶޼�݌������̏������
		if (r) {
			r = this->m_snsCoverClose.IsDetected(onCover);
			if (r){
				if ( !onCover ) {
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
					CSingleLock	S(this->pMCPauseSema,true);
// #IK20130608-02 [�C��] auseAndWait�C��
					this->pauseWait.PauseInit();
					r = this->pauseWait.SetPauseAndWait(ePauseMgzCoverCloseU);
				}
//				if (!r) {
//					this->m_err.PutError(Err_CoverOpenU);
//					r = FALSE;
//				}
			}
		}

		// Check magazine exist
		if (r) {
			r = this->m_snsMgzExist[0].IsDetected(onExistU);
			r = this->m_snsMgzExist[1].IsDetected(onExistL);
			// yk130506:��а�^�]���;ݻ�𖳌��ɂ���
			if (this->m_isAging) {
				onExistU = true;
			}
			if (r){
				if ( !onExistU && !onExistL ) {
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
					CSingleLock	S(this->pMCPauseSema,true);
// #IK20130608-02 [�C��] auseAndWait�C��
					this->pauseWait.PauseInit();
					r = this->pauseWait.SetPauseAndWait(ePauseMgzExistU);
				}
//				if (!r) {
//					this->m_err.PutError(Err_MgzNotExistU);
//					r = FALSE;
//				}
			}
		}
		if (r && onCover && (onExistU || onExistL)) {
			break;		// ����
		}
	}

	// Move magazine to top position
	if (r) {
		this->SetCurrMgSlot(eDownMgz, this->m_DD.stockNo[eDownMgz]);	
		this->SetCurrMgSlot(eUpMgz, this->m_DD.stockNo[eUpMgz]);	
//		r = MoveToLoadPos(this->m_DD.stockNo);		// yk130405
	}

	TRACE("                                   [BDS]CSMUDCtrl::Mg EndSub() - Finish\n");
	return (r);
}

///////////////////////////////////////////////////
// Move to load position
//
BOOL CSMUDCtrl::MoveToLoadPos(int mgzNo, int slotNo)
{
	BOOL r		= TRUE;
	bool exist	= true;
	double	Pos = 0.0;	// target position

	int Plset = this->GetStockNo(mgzNo);
	if (r && (Plset == 0)) {
		r = FALSE;
	}
	
	int No = slotNo;
	if (r && No > Plset)	{
		No = Plset;
	} else if (1 > No) {
		No = 1;
	}	

	if (r) {
		// Calculate the target position
		double TopHeight	= this->m_DD.topHeight;
		double ElvOffSet	= this->m_MD.MgzD.elvOffset[mgzNo];
		double Pitch		= this->m_DD.pitch;
		double EscLevel		= this->m_DD.EscLvl;

		Pos  = TopHeight + ElvOffSet;	
		Pos += (No - 1) * Pitch;
		Pos += EscLevel;

		//TRACE("FCB-%s::MoveToLoadPos() - Slot No = %d TopHeight = %lf, Pitch = %lf, ElvOffSet = %lf, Pos = %lf\n",this->m_name, No, TopHeight, Pitch, ElvOffSet, Pos);

		// 
		if (r) {
			r = this->MgzMoveAbs(Pos, true);
		}
		
		// Set the value of current magazine slot if move successfully
		if (r) {
			this->SetCurrMgSlot(mgzNo, No);
		}
	}

	return(r);
}

///////////////////////////////////////////////////
// Move magazine to exchange position
//
BOOL CSMUDCtrl::MoveToExchPos()
{
	BOOL r = TRUE;
	
	// Move magazine to exchange position
	r = MgzMoveAbs(this->m_MD.MgzD.mgzExchgPos, true);

	//TRACE("FCB-%s::MoveToExchPos() - Move to position: %f\n", this->m_name, this->m_MD.MgzD.mgzExchgPos);

	return r;
}

//============================================================
// Magazine move absolute
//============================================================
BOOL CSMUDCtrl::MgzMoveAbs(double pos, bool wait)
{
	BOOL r				= TRUE;
	
	if (r) {
		// Action check
		r = this->m_mtMgz.ActionCheck();
	}

	// Get the speed ratio
	double speed	= this->m_mtMgz.GetHighSpeed();
	//speed			= speed * this->m_MD.MgzD.speedRatio;

	// Check cover close sensor			// yk130430#8:SubstMagazine Cover�ݻ
	if (r) {
		bool on = false;
		r = this->m_snsCoverClose.IsDetected(on);
// #IK20130508-05 [�C��] ϶޼�ݍ���è��ݸޏC��
		if (m_isAutoRunning) {
			// Pause and wait
			if (r && !on) {
// #IK20130615-03 [�C��] SetPauseAndWait()�ł���܂�
				CSingleLock	S(this->pMCPauseSema,true);
// #IK20130608-02 [�C��] auseAndWait�C��
				this->pauseWait.PauseInit();
				r = this->pauseWait.SetPauseAndWait(ePauseMgzCoverCloseU);
			}
		} else {
			if (r && !on) {
				r = false;
			}
		}
		if (!r) {
			this->m_err.PutError(Err_CoverOpenU);
			r = FALSE;
		}
	}

	if (r && isAbleToMoveMgz()) {
		// Move magazine
		r = this->m_mtMgz.MotorMoveAbs(pos, speed, (wait)? TRUE : FALSE);
	}

	return(r);
}

//============================================================
// Magazine ring check position move
//============================================================
BOOL CSMUDCtrl::MgRingCheckPosMove(int mgzNo, int No){			// �ݸ������ʒu�ړ�
	BOOL r = TRUE;

	int Plset = this->GetStockNo(mgzNo);
	if (r && (Plset == 0)) {
		r = FALSE;
	}
	
	if (r && (No > Plset))	{
		No = Plset;
	} else if (1 > No) {
		No = 1;
	}

	double Pos			= 0;
	double EvtPos		= 0;
	double EvtChkPos	= 0;
	double Pitch		= 0;
	
	EvtPos			+= this->m_DD.topHeight /*+ this->m_MD.MgzD.elvOffset*/;
	EvtChkPos		+= this->m_DD.EvtRingChkOfsHeight;
	Pitch			=  this->m_DD.pitch;

	Pos = EvtChkPos + EvtPos ;
	Pos += (No - 1) * Pitch;
	r	= MgzMoveAbs(Pos, true);
	return r;
}

//============================================================
// Make slot map
//============================================================
BOOL CSMUDCtrl::MakeSlotMap()
{
	int r = TRUE;
	////////////////////////////////////////////
	
	bool isWTrfSafe = false;
	
	////////////////////////////////////////////
	//
	// SlotMap
	//
	int numberSlit;
		numberSlit = this->m_DD.stockNo[eUpMgz];
		for(int i = 0; i < numberSlit; i++){
			bool exist = false;
			r = this->MgRingCheckPosMove(eUpMgz, i+1);
			::Sleep(this->m_DD.ElvSns_Timer);	// ????? ??????????????

			if (r) {
				r = this->m_snsSubstExist.IsDetected(exist);
			}
			#if GPDEBUG
			exist = false;
			#endif
			// 
			if (r && exist) {				
				this->waferUmu[0][i]	= eSubstExist;
			} else {				
				this->waferUmu[0][i]	= eSubstNone;
			}
		}
#if GPDEBUG
		{
			for(i=0;i<2;i++){
				this->waferUmu[0][i]	= eSubstExist;
			}
			for(i=2;i < numberSlit;i++){
				this->waferUmu[0][i]	= eSubstNone;
			}
		}
#endif	
		if (r) {
			this->m_slotMapIsMade = true;
		}
	return(r);
}

//============================================================
// Check if magazine is at current slot map loading position
//============================================================
bool CSMUDCtrl::isMgzAtSlotPos()
{
	BOOL r			= TRUE;
	double curPos	= 0.0;
	double calPos	= 0.0;
	int slotNo		= 0;
	int mgzNo		= 0;
	// Get current slot
	if (r) {
		mgzNo = this->GetCurrMgz();
		slotNo = GetCurrMgSlot(mgzNo);
	}

	// Get the current position of load magazine
	if (r) {
		r = this->m_mtMgz.MotorPosition(curPos);
	}

	// Calculate of position corresponding to slotNo
	double TopHeight	= this->m_DD.topHeight;
	double ElvOffSet	= this->m_MD.MgzD.elvOffset[mgzNo];
	double Pitch		= this->m_DD.pitch;
	double EscLevel		= this->m_DD.EscLvl;
		
	calPos  = TopHeight + ElvOffSet + EscLevel;	
	calPos += (slotNo - 1) * Pitch;

	// Compare 2 position if match
	if (r && (calPos - 0.1 < curPos) && (calPos + 0.1 > curPos)) {
		r = TRUE;
	} else {
		r = FALSE;
	}

	return (r != FALSE);
}

//=================================================
// Check if can move magazine
//=================================================
BOOL  CSMUDCtrl::isAbleToMoveMgz()

{
	BOOL r = TRUE;
// ۰�ް���ͺ��ޱ�����̂��ߕs�v�����A��۰�ޑ����߯��������邽�ߕK�v
#if 1
	double pusherPos	= 0.0;


	// Get the current position of load pusher
	if (r) {
		r = (*this->pGetPusherPos)(false, pusherPos);
	}

	// If load pusher in limit position then move to escape position
// �Ȃɂ䂦�ЯĈʒu�ȉ��Ŕ��肷��̂��H
//	if (r && (pusherPos < this->m_MD.MgzD.pusherLimitPos - 0.1)) {
	if (r && (pusherPos > this->m_MD.MgzD.pusherLimitPos + 0.1)) {
		r = (*this->pMovePusherToMgzEsc)(false);

		if (!r) {
			// Put error
			this->m_err.PutError(Err_MazPusherIL);
			r = FALSE;
		}
	}	
#endif
	return(r);
}

//=================================================
// Move magazine to wait position
//=================================================
BOOL	CSMUDCtrl::MoveToWaitPos()
{
	BOOL r = TRUE;
	
	// Move magazine to exchange position
	r = MgzMoveAbs(this->m_MD.MgzD.mgzWaitPos, true);

	return (r);
}

// #IK20130508-02 [�C��] ۰�ޗ�O����ב΍�
void CSMUDCtrl::SetStopFlag(int flag)		// �����~�׸ސݒ�
{
	MCCStd::SetStopFlag(flag);
}

// Check Magazine Status:Magazine�L��sensor,Slot�ԍ�������
BOOL CSMUDCtrl::isGetMgzSide(int& mgzNo, int& slotNo, bool& canGet)
{
	BOOL r = TRUE;
	int Plset;
	canGet = false;
	bool on;

	// Current����Magazine���check
	mgzNo	= this->GetCurrMgz();
	slotNo	= this->GetCurrMgSlot(mgzNo);
	Plset	= this->GetStockNo(mgzNo); 	

	if (r) {
		r = this->m_snsMgzExist[1 - mgzNo].IsDetected(on);	// ϶޼�ݍݐоݻ
	}
	if (r && this->m_isAging) {
		on = true;
	}

	if (r && on && (1 <= slotNo) && (slotNo <= Plset) ) {
		this->SetCurrMgz(mgzNo);
		if (r) {
			r = GetNextSlot(mgzNo, slotNo, canGet);
		}
	}
	if (r && !canGet) {				// Current�����������̏ꍇ�͑��葤������
		if(eDownMgz == mgzNo){
			this->SetCurrMgz(eUpMgz);
		} else {
			this->SetCurrMgz(eDownMgz);
		}
		// ��Current����Magazine���check
		mgzNo	= this->GetCurrMgz();
		slotNo	= this->GetCurrMgSlot(mgzNo);
		Plset	= this->GetStockNo(mgzNo); 	

		if (r) {
			r = this->m_snsMgzExist[1 - mgzNo].IsDetected(on);	// ϶޼�ݍݐоݻ
		}
		if (r && this->m_isAging) {
			on = true;
		}

		if (r && on && (1 <= slotNo) && (slotNo <= Plset) ) {
			this->SetCurrMgz(mgzNo);
			if (r) {
				r = GetNextSlot(mgzNo, slotNo, canGet);
			}
		}
	}

	return	r;
}

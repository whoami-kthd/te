// Manipulator.cpp: CManipulatorComm �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#ifdef	TEST
#include "..\stdafx.h"
#else
#include "..\..\..\..\stdafx.h"
#endif
//#include "LPMPPARITest.h"
//#include "PortComm.h"
#include "ManipulatorComm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

CManipulatorComm::CManipulatorComm()
{

//	m_hComm = 0;

	// ��M�گ�ދN��(�ꎞ��~Ӱ�ނŋN������ɍĊJ����)
	pRThread = AfxBeginThread( CommRecv, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED );
	if( !pRThread ){
	//	AfxMessageBox( "��M�X���b�h�̋N���Ɏ��s���܂����B", MB_OK, 0 );
	//	return FALSE;
	}

	// �گ������ٕۑ�
	m_hCommRThread = pRThread->m_hThread;

	// ���M�گ�ދN��(�ꎞ��~Ӱ�ނŋN������ɍĊJ����)
	pSThread = AfxBeginThread( CommSend, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED );
	if( !pSThread ){
	//	AfxMessageBox( "���M�X���b�h�̋N���Ɏ��s���܂����B", MB_OK, 0 );
	//	return FALSE;
	}

	// �گ������ٕۑ�
	m_hCommSThread = pSThread->m_hThread;

	m_hsema = CreateSemaphore( NULL, 1, 10, NULL );		// ��̫����ق̍\�z	����ޑ��M�̔r���p 2�ł����Ǝv�����AMAX��10�Ƃ��Ă݂�

	evAnswerData = 0;
	evEVENT = 0;			// �C�x���g�ʒm�pEVENT�N���A
	evANSWER = 0;			// �����ʒm�pEVENT�N���A
	int i;
	for( i=0 ; i<MP_EVENT_QMAX ; i++ ){
		mp_event_q[i].cmdNum		= 0;
		mp_event_q[i].eventObj		= 0;
		mp_event_q[i].finishData	= 0;
		mp_event_q[i].unit			= 0;
	};

	pRThread->ResumeThread();
	pSThread->ResumeThread();

}

CManipulatorComm::~CManipulatorComm()
{

}


void	CManipulatorComm::SetCommPara( CString ComPort, int boudrate, int databit, int parity, int evenodd, int stopbit )
{

	PortComm.SetCommOpenInfo( ComPort, boudrate, databit, stopbit, parity, evenodd );

}

BOOL	CManipulatorComm::OpenComm()
{
	BOOL	r;
	r = PortComm.CommOpen();
	if( r ){
//		pRThread->ResumeThread();
		CommSetting();
	}
	return r;
}
// COM �|�[�g�̃N���[�Y
BOOL	CManipulatorComm::CloseComm()
{
	BOOL	r = TRUE;
//	r = PortComm.CommClose();
	if(PortComm.m_hComm && PortComm.m_hComm != INVALID_HANDLE_VALUE) {

		CloseHandle(PortComm.m_hComm);
		PortComm.m_hComm = 0;

	}

	return r;
}

//***************************************************************
//  ���O�@�@: CommSetting
//  �������e: COM�߰Ă̏������E�ݒ�
//  �����@�@: ����
//  �߂�l�@: TRUE(==1):���� FALSE(==0):�ݒ�װ
//  ��O����: ���ɖ���
//***************************************************************
BOOL CManipulatorComm::CommSetting()
{

	// get any early notifications(�ʐM�|�[�g�ɑ΂���Ď��C�x���g�𖾊m�ɂ���)
	SetCommMask( PortComm.m_hComm, EV_RXCHAR ) ;
	// setup device buffers (����M�ޯ̧���ނ̎w��)
	if( !SetupComm( PortComm.m_hComm, 4096, 4096 ) )
		return FALSE;
	// purge any information in the buffer(����M�ޯ̧�̸ر)
	PurgeComm( PortComm.m_hComm,	PURGE_TXABORT | PURGE_RXABORT |
						PURGE_TXCLEAR | PURGE_RXCLEAR ) ;

	// set up for overlapped I/O (Timeout�ݒ�)
	PortComm.m_CommTimeOuts.ReadIntervalTimeout =0xFFFFFFFF ;		// ������ Timeout
	PortComm.m_CommTimeOuts.ReadTotalTimeoutMultiplier = 0 ;
//	PortComm.m_CommTimeOuts.ReadTotalTimeoutConstant = 3000 ;		// ��M Timeout(ms)
	PortComm.m_CommTimeOuts.ReadTotalTimeoutConstant = 100 ;		// ��M Timeout(ms)
	PortComm.m_CommTimeOuts.WriteTotalTimeoutMultiplier = 0 ;
//	PortComm.m_CommTimeOuts.WriteTotalTimeoutConstant = 1000 ;		// ���M Timeout(ms)
	PortComm.m_CommTimeOuts.WriteTotalTimeoutConstant = 100 ;		// ���M Timeout(ms)
	// ��ѱ�Đݒ�
	if(!SetCommTimeouts(PortComm.m_hComm, &PortComm.m_CommTimeOuts))
		return FALSE;

	//*** COM Port Setup ***
		
	PortComm.m_Dcb.DCBlength = sizeof( DCB ) ;
	if(!GetCommState( PortComm.m_hComm, &PortComm.m_Dcb ))	// �ʐM�߰Ă̌��ݒ�̎擾
		return FALSE;

	// DCB�\���̂ɐݒ�l��āi�����w�蕔���j

	PortComm.m_Dcb.BaudRate = PortComm.m_BaudRate;	// �`�����x
	PortComm.m_Dcb.ByteSize = PortComm.m_ByteSize;	// �ް���(4�`8)
	PortComm.m_Dcb.StopBits = PortComm.m_StopBits;	// STOP�r�b�g 0=1�r�b�g 1=2�r�b�g
	PortComm.m_Dcb.fParity  = PortComm.m_fParity;		// ���è���� 0=���A1=�L
	if( PortComm.m_fParity == 0 )
		PortComm.m_Dcb.Parity   = NOPARITY;   // 0=no, 1=odd, 2=even
	else
		PortComm.m_Dcb.Parity = PortComm.m_Parity;
	                                // ���è���������̏ꍇ�AParity�ɂ�NOPARYTY���
	                                // �L��̏ꍇ�́AODD | EVEN �̐���������Ă��鎖�B

	// DCB�\���̂�ݒ肵�܂��B�i�����w�蕔���O�j
// 2012.01.09 �f�[�^�����o�����܂ł̃^�C�����O���������̂ňȉ��𐶂����Ă݂����A���܂�ω��Ȃ��B
#if	0
	PortComm.m_Dcb.XonLim = 100;
	PortComm.m_Dcb.XoffLim = 100;
// other various settings
	PortComm.m_Dcb.fBinary = TRUE ;						// binary mode

	PortComm.m_Dcb.fTXContinueOnXoff = 0;
	PortComm.m_Dcb.fOutX = FALSE;							// XON/XOFF out flow control
	PortComm.m_Dcb.fInX = FALSE;							// XON/XOFF in flow control
	PortComm.m_Dcb.fRtsControl = RTS_CONTROL_HANDSHAKE;   // RST flow control (default)
	PortComm.m_Dcb.fAbortOnError = 0;

	PortComm.m_Dcb.fNull = TRUE;			// NULL�����̔j��
	PortComm.m_Dcb.EofChar = 0x03;        // end of input character ���̕������������ް��I��
	PortComm.m_Dcb.EofChar = 0x00;        // end of input character ���̕������������ް��I��
	PortComm.m_Dcb.EvtChar = 0x02;        // received event character ���̕�������M����Ʋ���Ă�����
#endif

	// �ʐM�߰Ă̐ݒ��ύX���܂��B
	if(!SetCommState(PortComm.m_hComm, &PortComm.m_Dcb)){
		long we = GetLastError();
		return FALSE;
	}

	//// DTR( data-terminal-ready)�M���𑗂�܂��B�[���̓��f�B��ԂɂȂ�B
	//if( !EscapeCommFunction(m_hComm, SETDTR)) {
	//	return FALSE;
	//}

	return TRUE;
}


bool	CManipulatorComm::RestartReceive()	// �����܂��̓C�x���g�̏������I��������A���̃��\�b�h���Ă�(���s�v�ƂȂ���)
{
//	evNextRcvOk.SetEvent();

	return true;
}

// ���[�h�|�[�g����\���I�ɑ����Ă���C�x���g�̒ʒm�p�C�x���g�I�u�W�F�N�g�Ə��i�[����Z�b�g
bool	CManipulatorComm::SetEventEventObject( CEvent *evObj, struct MP_EVENTDATA *evData )
{
	evEventData = evData;
	evEVENT = evObj;
	return true;
}

// �R�}���h���s��A���슮�����_�ő����Ă���C�x���g�̒ʒm�p�C�x���g�I�u�W�F�N�g�Ə��i�[����Z�b�g
//		�쓮�݂̂̏ꍇ�A�R�}���h�𔭍s����O�ɁA���̊֐����Ă�ł���
bool	CManipulatorComm::SetEventAndObjectForCommandFinish( int unit, int CmdNum, CEvent *evObj, struct MP_FINISHDATA *evData )
{
	int	i;

	if( (CmdNum == Cmd_CRSM) || (CmdNum == Cmd_CEMG) )		// CRCM(���f����̍ĊJ)��CEMG(�ً}��~)�͓��쒆�R�}���h�̎��s�I���`���������Ă��邽�߃L���[�ɓ���Ȃ�
		return true;

	for( i=0 ; i<MP_EVENT_QMAX ; i++ ){
		if( mp_event_q[i].cmdNum == 0 ){
			mp_event_q[i].unit = unit;
			mp_event_q[i].cmdNum = CmdNum;
			mp_event_q[i].eventObj = evObj;
			mp_event_q[i].finishData = evData;
			return true;
		}
	}
	return false;		// �L���[�ɋ󂫂��Ȃ�
}

// 2012.01.09 �G���[���C�x���g�҂��L���[����폜����
void	CManipulatorComm::DequeueFromEventQueue( int unit, int CmdCode )
{
	int	i;

	for( i=0 ; i<MP_EVENT_QMAX ; i++ ){
		if( mp_event_q[i].cmdNum == (UINT)CmdCode && mp_event_q[i].unit == unit && mp_event_q[i].eventObj ){		// �v���̃R�}���h��������
			break;
		}
	}
	if( i < MP_EVENT_QMAX ){	// �I���C�x���g�҂�����������
#if !Release
	CString	Msg;
	CTime theTime;
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE("Delete Queue(%d) : Unit(%d) Cmd(%d)\n", i, mp_event_q[i].unit, mp_event_q[i].cmdNum);
#endif
		mp_event_q[i].cmdNum = 0;
		mp_event_q[i].unit = 0;
	}
}

void	CManipulatorComm::DequeueAll()
{
	int	i;
	for( i=0 ; i<MP_EVENT_QMAX ; i++ ){
		if(mp_event_q[i].unit != 0){		// �v���̃R�}���h��������
#if !Release
	CString	Msg;
	CTime theTime;
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE("Queue(%d) is Remained : Unit(%d) Cmd(%d)\n", i, mp_event_q[i].unit, mp_event_q[i].cmdNum);
#endif
			mp_event_q[i].cmdNum = 0;
			mp_event_q[i].unit = 0;
		}
	}
}

// �����̒ʒm�p�C�x���g�I�u�W�F�N�g�Ə��i�[����Z�b�g(�����p)
bool	CManipulatorComm::SetAnswerEventObject( CEvent *evObj, struct MP_ANSWERDATA *asData )
{
	evAnswerData = asData;
	evANSWER = evObj;
	return true;
}










// ��M�����f�[�^����͂��A�����Ȃ̂��C�x���g�Ȃ̂���Ԃ��B
// ��͌��ʂ̃f�[�^�́A�����p�܂��̓C�x���g�p�\���̂֊i�[����B
int		CManipulatorComm::AnalizeReceiveData( CString rstr )
{
	int		i, len, r;
//	char*	P;
	char	st;
	char	cmd[100];
	unsigned int	errorCode;
	int				unit, status, errorLvl, eventno;

	const static char* cmdArray[] =
		{
			"INIT",		"MHOM",		"MTRS",		"MGET",		"MPUT",		"MEXG",		"MPNT",		"MTRG",		"MTRP",		"MTRE",
			"MTPT",		"MTRO",		"MTGO",		"MTPO",		"MTTO",		"MMAP",		"MALN",		"MTCH",		"MABS",		"MREL",
			"MMCA",		"MACA",		"MADJ",		"CHLT",		"CRSM",		"CEMG",		"CSRV",		"CCLR",		"CSOL",		"CLFT",
			"CCHK",		"CCTM",		"ffffffff"
		};
	const static unsigned int codeArray[] =
		{
			Cmd_INIT,		Cmd_MHOM,		Cmd_MTRS,		Cmd_MGET,		Cmd_MPUT,		Cmd_MEXG,		Cmd_MPNT,		Cmd_MTRG,		Cmd_MTRP,		Cmd_MTRE,
			Cmd_MTPT,		Cmd_MTRO,		Cmd_MTGO,		Cmd_MTPO,		Cmd_MTTO,		Cmd_MMAP,		Cmd_MALN,		Cmd_MTCH,		Cmd_MABS,		Cmd_MREL,
			Cmd_MMCA,		Cmd_MACA,		Cmd_MADJ,		Cmd_CHLT,		Cmd_CRSM,		Cmd_CEMG,		Cmd_CSRV,		Cmd_CCLR,		Cmd_CSOL,		Cmd_CLFT,
			Cmd_CCHK,		Cmd_CCTM
		};

	r = RcvERROR;
	len = rstr.GetLength();					// ��M�ް��̕�����
	if( len >= MP_RECEIVE_MIN_SIZE ){		// �ŏ��������蒷��
		char	rcsum[3], buff[1000];
		int		rsum, msum;
		strcpy( rcsum, rstr.Right( 2 ) );
		sscanf( rcsum, "%2x", &rsum );			// rsum = ��M�f�[�^�̃`�F�b�N�T���l

		strcpy( buff, rstr.Mid( 1, len - 3 ) );
		msum = MakeCheckSum( buff, len - 3 );		// �`�F�b�N�T���l���쐬

		if( rsum != msum ){
			// �ʐM�d�l�ł͉����`���̃`�F�b�N�T���G���[�ł͎�M�f�[�^��j�����A�^�C���A�E�g�܂ő҂��ƂɂȂ��Ă��邽��
			// ��ʂɑ΂��ĉ����ʒm���Ȃ������悢
			if( rstr.Left( 1 ) == "$" ){		// �擪�� $ -> �R�}���h�ɑ΂��鉞��
			//	if( evAnswerData ){
			//		evAnswerData->unit		= 0;				// UNIT
			//		evAnswerData->status	= 0;				// �X�e�[�^�X
			//		evAnswerData->errCode	= ErrCheckSum;		// �G���[�R�[�h
			//		evAnswerData->errLevel	= 0;				// �G���[���x��	
			//		if( r != RcvERROR ){
			//			if( evANSWER ){
			//				// ������M�����C�x���g���s
			//				evANSWER->SetEvent();
			//			}
			//			evAnswerData = 0;
			//			evANSWER = 0;
			//		}
			//	}
			}

		} else {

			if( rstr.Left( 1 ) == "$" ){		// �擪�� $ -> �R�}���h�ɑ΂��鉞��

				r = RcvANSWER;

				sscanf( rstr, "%c%1d%2x%1x%3x", &st, &unit, &status, &errorLvl, &errorCode );

				if( evAnswerData ){
					evAnswerData->unit		= unit;				// UNIT
					evAnswerData->status	= status;			// �X�e�[�^�X
					evAnswerData->errCode	= errorCode;		// �G���[�R�[�h
					evAnswerData->errLevel	= errorLvl;			// �G���[���x��	

					if( errorCode == Err0x0000 ){		// ���퉞��
						switch( CommandWaitingForReply ){
						case Cmd_INIT:
						case Cmd_MHOM:
						case Cmd_MTRS:
						case Cmd_MGET:
						case Cmd_MPUT:
						case Cmd_MEXG:
						case Cmd_MPNT:
						case Cmd_MTRG:
						case Cmd_MTRP:
						case Cmd_MTRE:
						case Cmd_MTPT:
						case Cmd_MTRO:
						case Cmd_MTGO:
						case Cmd_MTPO:
						case Cmd_MTTO:
						case Cmd_MMAP:
						case Cmd_MALN:
						case Cmd_MTCH:
						case Cmd_MABS:
						case Cmd_MREL:
						case Cmd_MMCA:
						case Cmd_MACA:
						case Cmd_MADJ:
						case Cmd_CHLT:
						case Cmd_CRSM:
						case Cmd_CEMG:
						case Cmd_CSRV:
						case Cmd_CCLR:
						case Cmd_CSOL:
						case Cmd_CLFT:
						case Cmd_CCHK:
						case Cmd_CCTM:
						case Cmd_SSPD:
						case Cmd_SSPP:
						case Cmd_SPOS:
						case Cmd_SABS:
						case Cmd_SPSV:
						case Cmd_SOFS:
						case Cmd_SMOD:
						case Cmd_SPIT:
						case Cmd_SSLT:
						case Cmd_SRSV:
						case Cmd_SMSK:
						case Cmd_STYP:
						case Cmd_SSTT:
						case Cmd_SSLV:
						case Cmd_SIOS:
						case Cmd_SPUD:
						case Cmd_SPRM:
						case Cmd_SSTD:
						case Cmd_SSTN:
						case Cmd_SCAL:
							break;

						case Cmd_RSPD:
							{
								long	value;
								sscanf( rstr, "%c%1d%2x%3x%1x%6d", &st, &unit, &status, &errorCode, &errorLvl, &value );
								evAnswerData->u_asdata.rspd.Value = value;
							}
							break;

						case Cmd_RSPP:
							{
								long	value;
								sscanf( rstr, "%c%1d%2x%3x%1x%4d", &st, &unit, &status, &errorCode, &errorLvl, &value );
								evAnswerData->u_asdata.rspp.Value = value;
							}
							break;

						case Cmd_RPOS:
							{
								long	value1, value2, value3, value4, value5;
								value1 = value2 = value3 = value4 = value5 = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%8d%8d%8d%8d%8d", &st, &unit, &status, &errorCode, &errorLvl,
																				&value1, &value2, &value3, &value4, &value5 );
								evAnswerData->u_asdata.rpos.Value1 = value1;		// ����   -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rpos.Value2 = value2;		// �L�k��1  -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rpos.Value3 = value3;		// �L�k��2  -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rpos.Value4 = value4;		// ���~��   -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rpos.Value5 = value5;		// (���s��) -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rpos.Value6 = 0;				// 
							}
							break;

						case Cmd_ROFS:
							{
								long	offset1, offset2, offset3, offset4, offset5;
								offset1 = offset2 = offset3 = offset4 = offset5 = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%8d%8d%8d%8d%8d", &st, &unit, &status, &errorCode, &errorLvl,
																				&offset1, &offset2, &offset3, &offset4, &offset5 );
								evAnswerData->u_asdata.rofs.Offset1 = offset1;		// �����I�t�Z�b�g							-999 - 9999�͈̔͂ŉ���(����\��0.01[mm])
								evAnswerData->u_asdata.rofs.Offset2 = offset2;		// ����I�t�Z�b�g							-999 - 9999�͈̔͂ŉ���(����\��0.01[mm])
								evAnswerData->u_asdata.rofs.Offset3 = offset3;		// �L�����I�t�Z�b�g(�O���b�p�^�C�v�̏ꍇ)	-999 - 9999�͈̔͂ŉ���(����\��0.01[mm])
								evAnswerData->u_asdata.rofs.Offset4 = offset4;		// �k�����I�t�Z�b�g(�O���b�p�^�C�v�̏ꍇ)	-999 - 9999�͈̔͂ŉ���(����\��0.01[mm])
								evAnswerData->u_asdata.rofs.Offset5 = offset5;		// Put �����I�t�Z�b�g(�O���b�p�^�C�v�̏ꍇ)	-999 - 9999�͈̔͂ŉ���(����\��0.01[mm])
							}
							break;

						case Cmd_RCST:
							{
								char	mode = 0x0;
								int		slotno = 0;
								long	value1, value2, value3, value4;
								value1 = value2 = value3 = value4 = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%c%6d%6d%2d", &st, &unit, &status, &errorCode, &errorLvl,
																				&mode, &value1, &value2, &slotno );
								if( mode == 'A' )
									evAnswerData->u_asdata.rcst.Mode = MPRPL_MODE_A;		// �X���b�g�ԃs�b�`�����������[�h	MPRPL_MODE_A or F
								else if( mode == 'F' )
									evAnswerData->u_asdata.rcst.Mode = MPRPL_MODE_F;		// �X���b�g�ԃs�b�`�����������[�h	MPRPL_MODE_A or F
								else
									r = RcvERROR;

								if( r != RcvERROR ){
									evAnswerData->u_asdata.rcst.Value1 = value1;		// �X���b�g�ԃs�b�`����	�L�k��1(�n���h1)�p	����n�n���h1 �p
									evAnswerData->u_asdata.rcst.Value2 = value2;		// �X���b�g�ԃs�b�`����	�L�k��2(�n���h2)�p	����n�n���h2 �p
									evAnswerData->u_asdata.rcst.Value3 = value3;		// �X���b�g�ԃs�b�`����						�E��n�n���h1 �p
									evAnswerData->u_asdata.rcst.Value4 = value4;		// �X���b�g�ԃs�b�`����						�E��n�n���h2 �p
									evAnswerData->u_asdata.rcst.SlotNo = slotno;		// �X���b�g�� 1�`30
								}
							}
							break;

						case Cmd_RMAP:
							{
								int		slotNo[MP_MAX_SLOT+1];		// �X���b�g�ԍ� 0�`30 0:�����X�e�[�W�AP/A �X�e�[�W�w�莞
								char	result[MP_MAX_SLOT+1][5];	// �}�b�s���O���� MPRPL_RESULT_NO or OK or DW or CW
								memset( slotNo, 0, sizeof(slotNo) );
								memset( result, 0, sizeof(result) );
								sscanf( rstr, "%c%1d%2x%3x%1x%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s%2d%2s",
												&st, &unit, &status, &errorCode, &errorLvl,
												&slotNo[ 0], result[ 0], &slotNo[ 1], result[ 1], &slotNo[ 2], result[ 2], &slotNo[ 3], result[ 3], &slotNo[ 4], result[ 4], &slotNo[ 5], result[ 5], &slotNo[ 6], result[ 6], &slotNo[ 7], result[ 7], &slotNo[ 8], result[ 8], &slotNo[ 9], result[ 9],
												&slotNo[10], result[10], &slotNo[11], result[11], &slotNo[12], result[12], &slotNo[13], result[13], &slotNo[14], result[14], &slotNo[15], result[15], &slotNo[16], result[16], &slotNo[17], result[17], &slotNo[18], result[18], &slotNo[19], result[19],
												&slotNo[20], result[20], &slotNo[21], result[21], &slotNo[22], result[22], &slotNo[23], result[23], &slotNo[24], result[24], &slotNo[25], result[25], &slotNo[26], result[26], &slotNo[27], result[27], &slotNo[28], result[28], &slotNo[29], result[29] );
								for( i = 0 ; i < MP_MAX_SLOT ; i++ ){
									evAnswerData->u_asdata.rmap.SlotNo[i] = slotNo[i];		// �X���b�g�ԍ� 0�`30 0:�����X�e�[�W�AP/A �X�e�[�W�w�莞
									if( strcmp( result[i], "OK" ) == 0 )
										evAnswerData->u_asdata.rmap.Result[i] = MPRPL_RESULT_OK;		// �}�b�s���O���� MPRPL_RESULT_NO or OK or DW or CW
									else if( strcmp( result[i], "DW" ) == 0 )
										evAnswerData->u_asdata.rmap.Result[i] = MPRPL_RESULT_DW;		// �}�b�s���O���� MPRPL_RESULT_NO or OK or DW or CW
									else if( strcmp( result[i], "CW" ) == 0 )
										evAnswerData->u_asdata.rmap.Result[i] = MPRPL_RESULT_CW;		// �}�b�s���O���� MPRPL_RESULT_NO or OK or DW or CW
									else if( strcmp( result[i], "--" ) == 0 )
										evAnswerData->u_asdata.rmap.Result[i] = MPRPL_RESULT_NO;		// �}�b�s���O���� MPRPL_RESULT_NO or OK or DW or CW
									else {
										r = RcvERROR;
										break;
									}
								}
							}
							break;

						case Cmd_RSTS:
							{
								int		st1, st2, st3, st4;
								int		errCd;
								st1 = st2 = st3 = st4 = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%4x%1x%1x%1x%1x", &st, &unit, &status, &errorCode, &errorLvl, &errCd, &st1, &st2, &st3, &st4 );

								evAnswerData->u_asdata.rsts.ErrorCd = errCd;		// �w�胆�j�b�g�ɂ��Č��ݔ������Ă���G���[�R�[�h������(�G���[�������́h0000�h������)
								evAnswerData->u_asdata.rsts.Status1 = st1;			// �L�k��1,2���[�N�L�����,�`���b�L���O�w�ߏ��
								evAnswerData->u_asdata.rsts.Status2 = st2;			// �O���C���^�[���b�N1,2,3,4 ��ԏ��,�O���b�v�Z���T/�A���O���b�v�Z���T���
								evAnswerData->u_asdata.rsts.Status3 = st3;			// �O���C���^�[���b�N5,6,7,8 ��ԏ��,���t�^�㉺�Z���T���,���t�^�w�ߏ��
								evAnswerData->u_asdata.rsts.Status4 = st4;			// 
							}
							break;

						case Cmd_RERR:
							{
								int	errcd[32];
								memset( errcd, 0, sizeof(errcd) );
								sscanf( rstr, "%c%1d%2x%3x%1x%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d%4d",
												&st, &unit, &status, &errorCode, &errorLvl,
												&errcd[ 0], &errcd[ 1], &errcd[ 2], &errcd[ 3], &errcd[ 4], &errcd[ 5], &errcd[ 6], &errcd[ 7], &errcd[ 8], &errcd[ 9],
												&errcd[10], &errcd[11], &errcd[12], &errcd[13], &errcd[14], &errcd[15], &errcd[16], &errcd[17], &errcd[18], &errcd[19],
												&errcd[20], &errcd[21], &errcd[22], &errcd[23], &errcd[24], &errcd[25], &errcd[26], &errcd[27], &errcd[28], &errcd[29],
												&errcd[30], &errcd[31] );
								for( i = 0 ; i < 32 ; i++ ){
									evAnswerData->u_asdata.rerr.Errcd[i] = errcd[i];
								}
							}
							break;

						case Cmd_RERT:
							{
								int		errcd, svErr, subCd, month, day, hour, minute, second;
								errcd = svErr = subCd = month = day = hour = minute = second = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%4d%3d%5d%2d%2d%2d%2d%2d", &st, &unit, &status, &errorCode, &errorLvl,
																				&errcd, &svErr, &subCd, &month, &day, &hour, &minute, &second );
								evAnswerData->u_asdata.rert.Errcd	= errcd;
								evAnswerData->u_asdata.rert.SvErr	= svErr;
								evAnswerData->u_asdata.rert.SubCd	= subCd;
								evAnswerData->u_asdata.rert.Month	= month;
								evAnswerData->u_asdata.rert.Day		= day;	
								evAnswerData->u_asdata.rert.Hour	= hour;
								evAnswerData->u_asdata.rert.Minute	= minute;
								evAnswerData->u_asdata.rert.Second	= second;
							}
							break;

						case Cmd_RMSK:
							{
								int		valid1, valid2, valid3, valid4;
								valid1 = valid2 = valid3 = valid4 = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%1x%1x%1x%1x", &st, &unit, &status, &errorCode, &errorLvl, &valid1, &valid2, &valid3, &valid4 );

								evAnswerData->u_asdata.rmsk.Valid1 = valid1;
								evAnswerData->u_asdata.rmsk.Valid2 = valid2;
								evAnswerData->u_asdata.rmsk.Valid3 = valid3;
								evAnswerData->u_asdata.rmsk.Valid4 = valid4;
							}
							break;

						case Cmd_RTYP:
							{
								int		type = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%1d", &st, &unit, &status, &errorCode, &errorLvl, &type );

								evAnswerData->u_asdata.rtyp.Type = type;
							}
							break;

						case Cmd_RSTT:
							{
								int		type = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%1d", &st, &unit, &status, &errorCode, &errorLvl, &type );

								evAnswerData->u_asdata.rstt.Type = type;
							}
							break;

						case Cmd_RVER:
							{
								char	ver[5];
								memset( ver, 0, sizeof(ver) );

								sscanf( rstr, "%c%1d%2x%3x%1x%4s", &st, &unit, &status, &errorCode, &errorLvl, ver );

								strcpy( evAnswerData->u_asdata.rver.Version, ver );
							}
							break;

						case Cmd_RMDL:
							{
								char	mdl[64];
								memset( mdl, 0, sizeof(mdl) );

								sscanf( rstr, "%c%1d%2x%3x%1x%63s", &st, &unit, &status, &errorCode, &errorLvl, mdl );

								strcpy( evAnswerData->u_asdata.rmdl.MdlDat, mdl );
							}
							break;

						case Cmd_RLOG:
							{
								int		logNo, logTyp;
								char	logDat[512];
								logNo = logTyp = 0;
								memset( logDat, 0, sizeof(logDat) );

								sscanf( rstr, "%c%1d%2x%3x%1x%2d%1d%512s", &st, &unit, &status, &errorCode, &errorLvl, &logNo, &logTyp, logDat );

								evAnswerData->u_asdata.rlog.LogNo = logNo;
								evAnswerData->u_asdata.rlog.LogTyp = logTyp;
								strcpy( evAnswerData->u_asdata.rlog.LogDat, logDat );
							}
							break;

						case Cmd_RALN:
							{
								long	value1, value2, value3;
								value1 = value2 = value3 = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%6d%6d%6d", &st, &unit, &status, &errorCode, &errorLvl,
																				&value1, &value2, &value3 );
								evAnswerData->u_asdata.raln.Value1 = value1;		// �E�F�n�ΐS��(�v���A���C�i���񒆐S����̋���)
								evAnswerData->u_asdata.raln.Value2 = value2;		// �E�F�n�ΐS����(�Z���T�ʒu����̊p�x)
								evAnswerData->u_asdata.raln.Value3 = value3;		// �m�b�` / �I���t������(�Z���T�ʒu����̊p�x)
							}
							break;

						case Cmd_RSLV:
							{
								char	lvl = 0x0;
								sscanf( rstr, "%c%1d%2x%3x%1x%c", &st, &unit, &status, &errorCode, &errorLvl, &lvl );
								if( lvl == 'H' )
									evAnswerData->u_asdata.rslv.Level = MPRPL_LEVEL_H;		// �������x���x��
								else if( lvl == 'M' )
									evAnswerData->u_asdata.rslv.Level = MPRPL_LEVEL_M;		// �������x���x��
								else if( lvl == 'L' )
									evAnswerData->u_asdata.rslv.Level = MPRPL_LEVEL_L;		// �������x���x��
								else
									r = RcvERROR;
							}
							break;

						case Cmd_RSTP:
							{
								long	value1, value2, value3, value4, value5;
								value1 = value2 = value3 = value4 = value5 = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%8d%8d%8d%8d%8d", &st, &unit, &status, &errorCode, &errorLvl,
																				&value1, &value2, &value3, &value4, &value5 );
								evAnswerData->u_asdata.rstp.Value1 = value1;		// ����   -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rstp.Value2 = value2;		// �L�k��1  -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rstp.Value3 = value3;		// �L�k��2  -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rstp.Value4 = value4;		// ���~��   -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rstp.Value5 = value5;		// (���s��) -9999999 - 99999999�͈̔͂Ŏw��(����\��0.01[mm]�A[deg])
								evAnswerData->u_asdata.rstp.Value6 = 0;				//
							}
							break;

						case Cmd_RIOS:
							{
								int		data1, data2, data3, data4;
								data1 = data2 = data3 = data4 = 0;
								sscanf( rstr, "%c%1d%2x%3x%1x%1x%1x%1x%1x", &st, &unit, &status, &errorCode, &errorLvl, &data1, &data2, &data3, &data4 );

								evAnswerData->u_asdata.rios.Data1 = data1;
								evAnswerData->u_asdata.rios.Data2 = data2;
								evAnswerData->u_asdata.rios.Data3 = data3;
								evAnswerData->u_asdata.rios.Data4 = data4;
							}
							break;

						case Cmd_RMPD:
							{
								long	updata[MP_MAX_SLOT], dndata[MP_MAX_SLOT];;
								memset( updata, 0, sizeof(updata) );
								memset( dndata, 0, sizeof(dndata) );
								sscanf( rstr, "%c%1d%2x%3x%1x%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d%7d",
												&st, &unit, &status, &errorCode, &errorLvl,
												&updata[ 0], &dndata[ 0], &updata[ 1], &dndata[ 1], &updata[ 2], &dndata[ 2], &updata[ 3], &dndata[ 3], &updata[ 4], &dndata[ 4], &updata[ 5], &dndata[ 5], &updata[ 6], &dndata[ 6], &updata[ 7], &dndata[ 7], &updata[ 8], &dndata[ 8], &updata[ 9], &dndata[ 9],
												&updata[10], &dndata[10], &updata[11], &dndata[11], &updata[12], &dndata[12], &updata[13], &dndata[13], &updata[14], &dndata[14], &updata[15], &dndata[15], &updata[16], &dndata[16], &updata[17], &dndata[17], &updata[18], &dndata[18], &updata[19], &dndata[19],
												&updata[20], &dndata[20], &updata[21], &dndata[21], &updata[22], &dndata[22], &updata[23], &dndata[23], &updata[24], &dndata[24], &updata[25], &dndata[25], &updata[26], &dndata[26], &updata[27], &dndata[27], &updata[28], &dndata[28], &updata[29], &dndata[29] );
								for( i = 0 ; i < MP_MAX_SLOT ; i++ ){
									evAnswerData->u_asdata.rmpd.Updata[i] = updata[i];
									evAnswerData->u_asdata.rmpd.Dndata[i] = dndata[i];
								}
							}
							break;

						case Cmd_RPRM:
							{
								char	ctype[4];
								int type = 0, prmNo = 0;
								long	t1 = 0, t2 = 0;
								double	value = 0.0, v1 = 0.0;

								sscanf( rstr, "%c%1d%2x%3x%1x%3s%4d%9d%3d", &st, &unit, &status, &errorCode, &errorLvl, ctype, &prmNo, &t1, &t2 );

								// 12���̐������P���double�ɓ�����Ȃ����߁A9��+3���ɕ����Ď擾���A1000�{���ĉ��Z����
								v1 = t1;
								value = v1 * 1000 + t2;

								if( strcmp( ctype, "CIU" ) == 0 )
									type = MPRPL_TYPE_CIU;
								else if( strcmp( ctype, "CRU" ) == 0 )
									type = MPRPL_TYPE_CRU;
								else if( strcmp( ctype, "UIU" ) == 0 )
									type = MPRPL_TYPE_UIU;
								else if( strcmp( ctype, "URU" ) == 0 )
									type = MPRPL_TYPE_URU;
								else
									r = RcvERROR;

								if( r != RcvERROR ){
									evAnswerData->u_asdata.rprm.Type = type;		// �p�����[�^���	MPRPL_TYPE_CIU - URU
									evAnswerData->u_asdata.rprm.PrmNo = prmNo;		// �p�����[�^�ԍ�	0000 - 9999�͈̔͂ŉ���
									evAnswerData->u_asdata.rprm.Value = value;		// �p�����[�^�l		-99999999999 - 999999999999�͈̔͂ŉ���(�����p�����[�^�̕���\��0.0001)
								}
							}
							break;

						case Cmd_RCAL:
							{
								int		year, mon, day, hour, min, sec;
								year = mon = day = hour = min = sec = 0;

								sscanf( rstr, "%c%1d%2x%3x%1x%4d%2d%2d%2d%2d%2d", &st, &unit, &status, &errorCode, &errorLvl, &year, &mon, &day, &hour, &min, &sec );

								evAnswerData->u_asdata.rcal.Year	= year;
								evAnswerData->u_asdata.rcal.Mon		= mon;
								evAnswerData->u_asdata.rcal.Day		= day;
								evAnswerData->u_asdata.rcal.Hour	= hour;
								evAnswerData->u_asdata.rcal.Min		= min;
								evAnswerData->u_asdata.rcal.Sec		= sec;
							}
							break;

						case Cmd_RCCD:
							{
								int		light = 0, ccd = 0;

								sscanf( rstr, "%c%1d%2x%3x%1x%5d%5d", &st, &unit, &status, &errorCode, &errorLvl, &light, &ccd );

								evAnswerData->u_asdata.rccd.Light	= light;
								evAnswerData->u_asdata.rccd.Ccd		= ccd;
							}
							break;

						case Cmd_RSTN:
							{
								long	t11, t12, t21, t22, t31, t32, t41, t42, t51, t52;
								double	value1, value2, value3, value4, value5, v1;
								t11 = t12 = t21 = t22 = t31 = t32 = t41 = t42 = t51 = t52 = 0;
								value1 = value2 = value3 = value4 = value5 = 0.0;

								sscanf( rstr, "%c%1d%2x%3x%1x%9d%3d%9d%3d%9d%3d%9d%3d%9d%3d", &st, &unit, &status, &errorCode, &errorLvl,
																				&t11, &t12, &t21, &t22, &t31, &t32, &t41, &t42, &t51, &t52 );

								// 12���̐������P���double�ɓ�����Ȃ����߁A9��+3���ɕ����Ď擾���A1000�{���ĉ��Z����
								v1 = t11;
								value1 = v1 * 1000 + t12;
								v1 = t21;
								value2 = v1 * 1000 + t22;
								v1 = t31;
								value3 = v1 * 1000 + t32;
								v1 = t41;
								value4 = v1 * 1000 + t42;
								v1 = t51;
								value5 = v1 * 1000 + t52;

								evAnswerData->u_asdata.rstn.Value1 = value1;		// ����  
								evAnswerData->u_asdata.rstn.Value2 = value2;		// �L�k��1 
								evAnswerData->u_asdata.rstn.Value3 = value3;		// �L�k��2 
								evAnswerData->u_asdata.rstn.Value4 = value4;		// ���~��  
								evAnswerData->u_asdata.rstn.Value5 = value5;		// (���s��)
								evAnswerData->u_asdata.rstn.Value6 = 0;				//
							}
							break;

						case Cmd_ACKN:
							break;
		//				case Cmd_UPOS:
		//				case Cmd_UCPR:
		//				case Cmd_UPRM:
		//				case Cmd_DPOS:
		//				case Cmd_DCPR:
		//				case Cmd_DPRM:
		//					break;
						default:
							r = RcvERROR;				// ������҂��Ă���R�}���h���Ȃ�
						}
					}
					if( r != RcvERROR ){
						if( evANSWER ){
							// ������M�����C�x���g���s
							evANSWER->SetEvent();
						}
						evAnswerData = 0;
						evANSWER = 0;
					}
				}
			} else
			if( rstr.Left( 1 ) == "!" ){		// �擪�� ! -> �R�}���h�̓���I��

				r = RcvFINISH;

				sscanf( rstr, "%c%1d%2x%4x%4s", &st, &unit, &status, &errorCode, cmd );

				SendACKNCommand( unit );	// ���s�I���m�F�ʒm�̑��M

				for( i=0 ; ; i++ ){
					if( strcmp( cmdArray[i], "ffffffff" ) == 0 ){	// �e�[�u���̏I��
						r = RcvERROR;								// �Y���R�}���h������Ȃ�
						break;
					}
					if( strcmp( cmd, cmdArray[i] ) == 0 ){			// �R�}���h����������
						break;
					}
				}
				if( r != RcvERROR ){
					long	value1, value2;
					unsigned int cmdNum = codeArray[i];

					if( cmdNum == Cmd_CCTM ){	// CCTM(�`���b�L���O���쎞�Ԍv��)�R�}���h�͎��s�����`���Ōv�����Ԃ��Ԃ��Ă���
						value1 = value2 = 0;
						sscanf( rstr, "%c%1d%2x%4x%4s%4d%4d", &st, &unit, &status, &errorCode, cmd, &value1, &value2 );
					}

					for( i=0 ; i<MP_EVENT_QMAX ; i++ ){
						if( mp_event_q[i].cmdNum == cmdNum && mp_event_q[i].unit == unit && mp_event_q[i].eventObj ){		// �v���̃R�}���h��������
							mp_event_q[i].finishData->command = cmdNum;
							mp_event_q[i].finishData->status  = status;
							mp_event_q[i].finishData->errCode = errorCode;
							if( cmdNum == Cmd_CCTM ){
								mp_event_q[i].finishData->u_findata.cctm.value1 = value1;
								mp_event_q[i].finishData->u_findata.cctm.value2 = value2;
							}
							break;
						}
					}
					if( i < MP_EVENT_QMAX ){	// �I���C�x���g�҂�����������
						mp_event_q[i].eventObj->SetEvent();

						mp_event_q[i].cmdNum = 0;
						mp_event_q[i].unit = 0;
					}

				}
			} else
			if( rstr.Left( 1 ) == ">" ){		// �擪�� > -> �C�x���g

				r = RcvEVENT;

				if( evEventData ){

					sscanf( rstr, "%c%1d%4s%3d%1x%3x", &st, &unit, cmd, &eventno, &errorLvl, &errorCode );

					if( eventno == Event_100 ){		// �G���[�����C�x���g
						evEventData->unit = unit;
						evEventData->evNumb = Event_100;
						evEventData->u_evdata.error.errLvl = errorLvl;
						evEventData->u_evdata.error.errCode = errorCode;

						if( evEVENT ){
							// �C�x���g��M�C�x���g���s
							evEVENT->SetEvent();
						}
					} else
					if( eventno == Event_110 ){		// �����|�C���g���B(�ʉ�)�C�x���g
						char	cfork, cpoint[3];
						int		point;

						sscanf( rstr, "%c%1d%4s%3d%c%2s", &st, &unit, cmd, &eventno, &cfork, cpoint );
						if( cfork == 'A' ){
							evEventData->u_evdata.arrivePass.fork = MPCMD_FORK_A;
						} else
						if( cfork == 'B' ){
							evEventData->u_evdata.arrivePass.fork = MPCMD_FORK_B;
						} else {
							r = RcvERROR;
						}
						if( r != RcvERROR ){

							if( cpoint[0] == 'G' ){
								switch( cpoint[1] ){
								case '1':
									point = MPCMD_TRSPNT_G1;
									break;
								case '2':
									point = MPCMD_TRSPNT_G2;
									break;
								case 'b':
									point = MPCMD_TRSPNT_Gb;
									break;
								case '3':
									point = MPCMD_TRSPNT_G3;
									break;
								case '4':
									point = MPCMD_TRSPNT_G4;
									break;
								case '5':
									point = MPCMD_TRSPNT_G5;
									break;
								case '6':
									point = MPCMD_TRSPNT_G6;
									break;
								case '7':
									point = MPCMD_TRSPNT_G7;
									break;
								case '8':
									point = MPCMD_TRSPNT_G8;
									break;
								default:
									r = RcvERROR;
									break;
								}
							} else
							if( cpoint[0] == 'P' ){
								switch( cpoint[1] ){
								case '1':
									point = MPCMD_TRSPNT_P1;
									break;
								case '2':
									point = MPCMD_TRSPNT_P2;
									break;
								case 'b':
									point = MPCMD_TRSPNT_Pb;
									break;
								case '3':
									point = MPCMD_TRSPNT_P3;
									break;
								case '4':
									point = MPCMD_TRSPNT_P4;
									break;
								case '5':
									point = MPCMD_TRSPNT_P5;
									break;
								case '6':
									point = MPCMD_TRSPNT_P6;
									break;
								case '7':
									point = MPCMD_TRSPNT_P7;
									break;
								case '8':
									point = MPCMD_TRSPNT_P8;
									break;
								default:
									r = RcvERROR;
									break;
								}
							} else {
								r = RcvERROR;
							}
							if( r != RcvERROR ){
								evEventData->unit = unit;
								evEventData->evNumb = Event_110;
								evEventData->u_evdata.arrivePass.point = point;

								if( evEVENT ){
									// �C�x���g��M�C�x���g���s
									evEVENT->SetEvent();
								}
							}
						}
					} else {
						r = RcvERROR;
					}
				}

			} else
			if( rstr.Left( 1 ) == "?" ){		// �擪�� ? -> �ُ퉞��

				sscanf( rstr, "%c%3x%1x", &st, &errorCode, &errorLvl );

				if( evAnswerData ){
					evAnswerData->unit		= 0;				// UNIT
					evAnswerData->status	= 0;				// �X�e�[�^�X
					evAnswerData->errCode	= errorCode;		// �G���[�R�[�h
					evAnswerData->errLevel	= errorLvl;			// �G���[���x��	

					if( evANSWER ){
						// ������M�����C�x���g���s
						evANSWER->SetEvent();
					}
					evAnswerData = 0;
					evANSWER = 0;
				}
			}
		}
	}
	return r;
}

int		CManipulatorComm::MakeCommandString( int unit, int CmdCode, char* CommandLine, union MP_COMMAND_PARA* para )
{
	int	r = ErrNone;
	char Terminate[4];

	//memset( CommandLine, 0, sizeof(CommandLine) );
	Terminate[0] = 0x00;	// CheckSum 1
	Terminate[1] = 0x00;	// CheckSum 2
	Terminate[2] = 0x0D;	// <CR>
	Terminate[3] = 0x00;

	switch( CmdCode ){
		case Cmd_INIT:
			sprintf( CommandLine, "$%dINIT%02d", unit, para->init.IMode );
			break;
		case Cmd_MHOM:
			sprintf( CommandLine, "$%dMHOM%c", unit, para->mhom.MMode==MPCMD_MMODE_F? 'F':'A' );
			break;
		case Cmd_MTRS:
			{
				char trsSt[3], nextMtn[3], posture[3];
				GetTransferStationChar( trsSt, para->mtrs.TrsSt );
				GetNextMoveModeChar( nextMtn, para->mtrs.NextMtn );
				GetPostureChar( posture, para->mtrs.Posture );

				sprintf( CommandLine, "$%dMTRS%s%02d%s%s", unit, trsSt, para->mtrs.SlotNo, nextMtn, posture );
			}
			break;
		case Cmd_MGET:
			sprintf( CommandLine, "$%dMGET", unit );
			break;
		case Cmd_MPUT:
			sprintf( CommandLine, "$%dMPUT", unit );
			break;
		case Cmd_MEXG:
			sprintf( CommandLine, "$%dMEXG", unit );
			break;
		case Cmd_MPNT:
			{
				char trsPnt[3];
				GetTransferPointChar( trsPnt, para->mpnt.TrsPnt );

				sprintf( CommandLine, "$%dMPNT%s", unit, trsPnt );
			}
			break;
		case Cmd_MTRG:
			{
				char trsSt[3], mtnMode[3], posture[3];
				GetTransferStationChar( trsSt, para->mtrg.TrsSt );
				GetMtnModeChar( mtnMode, para->mtrg.MtnMode );
				GetPostureChar( posture, para->mtrg.Posture );

				sprintf( CommandLine, "$%dMTRG%s%02d%s%s", unit, trsSt, para->mtrg.SlotNo, mtnMode, posture );
			}
			break;
		case Cmd_MTRP:
			{
				char trsSt[3], mtnMode[3], posture[3];
				GetTransferStationChar( trsSt, para->mtrp.TrsSt );
				GetMtnModeChar( mtnMode, para->mtrp.MtnMode );
				GetPostureChar( posture, para->mtrp.Posture );

				sprintf( CommandLine, "$%dMTRP%s%02d%s%s", unit, trsSt, para->mtrp.SlotNo, mtnMode, posture );
			}
			break;
		case Cmd_MTRE:
			{
				char trsSt[3], mtnMode[3], posture[3];
				GetTransferStationChar( trsSt, para->mtre.TrsSt );
				GetMtnModeChar( mtnMode, para->mtre.MtnMode );
				GetPostureChar( posture, para->mtre.Posture );

				sprintf( CommandLine, "$%dMTRE%s%02d%s%s", unit, trsSt, para->mtre.SlotNo, mtnMode, posture );
			}
			break;
		case Cmd_MTPT:
			{
				char trsSt[3], nextMtn[3], posture[3], trsPnt[3];
				GetTransferStationChar( trsSt, para->mtpt.TrsSt );
				GetNextMoveModeChar( nextMtn, para->mtpt.NextMtn );
				GetPostureChar( posture, para->mtpt.Posture );
				GetTransferPointChar( trsPnt, para->mtpt.TrsPnt );

				sprintf( CommandLine, "$%dMTPT%s%02d%s%s", unit, trsSt, para->mtpt.SlotNo, nextMtn, posture );
			}
			break;
		case Cmd_MTRO:
			{
				char trsSt[3], nextMtn[3], posture[3];
				GetTransferStationChar( trsSt, para->mtro.TrsSt );
				GetNextMoveModeChar( nextMtn, para->mtro.NextMtn );
				GetPostureChar( posture, para->mtro.Posture );

				sprintf( CommandLine, "$%dMTRO%s%02d%s%s%05d%05d%05d", unit, trsSt, para->mtro.SlotNo, nextMtn, posture, para->mtro.OffsetX, para->mtro.OffsetY, para->mtro.OffsetZ );
			}
			break;
		case Cmd_MTGO:
			{
				char trsSt[3], mtnMode[3], posture[3];
				GetTransferStationChar( trsSt, para->mtgo.TrsSt );
				GetMtnModeChar( mtnMode, para->mtgo.MtnMode );
				GetPostureChar( posture, para->mtgo.Posture );

				sprintf( CommandLine, "$%dMTGO%s%02d%s%s%05d%05d%05d", unit, trsSt, para->mtgo.SlotNo, mtnMode, posture, para->mtgo.OffsetX, para->mtgo.OffsetY, para->mtgo.OffsetZ );
			}
			break;
		case Cmd_MTPO:
			{
				char trsSt[3], mtnMode[3], posture[3];
				GetTransferStationChar( trsSt, para->mtpo.TrsSt );
				GetMtnModeChar( mtnMode, para->mtpo.MtnMode );
				GetPostureChar( posture, para->mtpo.Posture );

				sprintf( CommandLine, "$%dMTPO%s%02d%s%s%05d%05d%05d", unit, trsSt, para->mtpo.SlotNo, mtnMode, posture, para->mtpo.OffsetX, para->mtpo.OffsetY, para->mtpo.OffsetZ );
			}
			break;
		case Cmd_MTTO:
			{
				char trsSt[3], mtnMode[3], posture[3];
				GetTransferStationChar( trsSt, para->mtto.TrsSt );
				GetMtnModeChar( mtnMode, para->mtto.MtnMode );
				GetPostureChar( posture, para->mtto.Posture );

				sprintf( CommandLine, "$%dMTTO%s%02d%s%s%05d%05d%05d", unit, trsSt, para->mtto.SlotNo, mtnMode, posture, para->mtto.OffsetX, para->mtto.OffsetY, para->mtto.OffsetZ );
			}
			break;
		case Cmd_MMAP:
			{
				char trsSt[3];
				GetTransferStationChar( trsSt, para->mmap.TrsSt );

				if( para->mmap.SlotNo != -1 )
					sprintf( CommandLine, "$%dMMAP%s%02d", unit, trsSt, para->mmap.SlotNo );
				else
					sprintf( CommandLine, "$%dMMAP%sFF", unit, trsSt );
			}
			break;
		case Cmd_MALN:
			{
			//	char trsSt[3];
			//	GetTransferStationChar( trsSt, para->maln.TrsSt );

			//	sprintf( CommandLine, "$%dMALN%1d%s%06d", unit, para->maln.TUNo, trsSt, para->maln.Angle );
				sprintf( CommandLine, "$%dMALN%1d%06d", unit, para->maln.TUNo, para->maln.Angle );
			}
			break;
		case Cmd_MTCH:
			{
				char fork[3], trsSt[3], pmode[3], posture[3];
				GetForkChar( fork, para->mtch.Fork );
				GetTransferStationChar( trsSt, para->mtch.TrsSt );
				GetPositionModeChar( pmode, para->mtch.PMode );
				GetPostureChar( posture, para->mtch.Posture );

				sprintf( CommandLine, "$%dMTCH%s%s%s%s%08d%08d", unit, fork, trsSt, pmode, posture, para->mtch.ZOffset, trsSt, para->mtch.ROffset );
			}
			break;
		case Cmd_MABS:
			{
				char axis[3], mode[3];
				GetAxisChar( axis, para->mabs.Axis );
				GetWristModeChar( mode, para->mabs.Mode );

				sprintf( CommandLine, "$%dMABS%s%s%08d", unit, axis, mode, para->mabs.Value );
			}
			break;
		case Cmd_MREL:
			{
				char axis[3], mode[3];
				GetAxisChar( axis, para->mrel.Axis );
				GetWristModeChar( mode, para->mrel.Mode );

				sprintf( CommandLine, "$%dMREL%s%s%08d", unit, axis, mode, para->mrel.Value );
			}
			break;
		case Cmd_MMCA:
			{
				char trsSt[3];
				GetTransferStationChar( trsSt, para->mmca.TrsSt );

				sprintf( CommandLine, "$%dMMCA%s", unit, trsSt );
			}
			break;
		case Cmd_MACA:
			{
			//	char trsSt[3];
			//	GetTransferStationChar( trsSt, para->maca.TrsSt );

			//	sprintf( CommandLine, "$%dMACA%1d%s", unit, para->maca.TUNo, trsSt );
				sprintf( CommandLine, "$%dMACA%1d", unit, para->maca.TUNo );
			}
			break;
		case Cmd_MADJ:
			{
			//	char trsSt[3];
			//	GetTransferStationChar( trsSt, para->madj.TrsSt );

			//	sprintf( CommandLine, "$%dMADJ%1d%s%06d", unit, para->madj.TUNo, trsSt, para->madj.Angle );
				sprintf( CommandLine, "$%dMADJ%1d%06d", unit, para->madj.TUNo, para->madj.Angle );
			}
			break;
		case Cmd_CHLT:
			sprintf( CommandLine, "$%dCHLT", unit );
			break;
		case Cmd_CRSM:
			sprintf( CommandLine, "$%dCRSM", unit );
			break;
		case Cmd_CEMG:
			sprintf( CommandLine, "$%dCEMG", unit );
			break;
		case Cmd_CSRV:
			{
				char servo[3];
				GetServoOnOffChar( servo, para->csrv.Sw );

				sprintf( CommandLine, "$%dCSRV%s", unit, servo );
			}
			break;
		case Cmd_CCLR:
			{
				char cmode[3];
				GetClearModeChar( cmode, para->cclr.CMode );

				sprintf( CommandLine, "$%dCCLR%s", unit, cmode );
			}
			break;
		case Cmd_CSOL:
			{
				char fork[3], chuck[3];
				GetForkChar( fork, para->csol.Fork );
				GetChuckingChar( chuck, para->csol.Sw );

				sprintf( CommandLine, "$%dCSOL%s%s", unit, fork, chuck );
			}
			break;
		case Cmd_CLFT:
			{
				char lift[3];
				GetLifterChar( lift, para->clft.Sw );

				sprintf( CommandLine, "$%dCLFT%s", unit, lift );
			}
			break;
		case Cmd_CCHK:
			{
				char fork[3], chuck[3];
				GetForkChar( fork, para->cchk.Fork );
				GetChuckingChar( chuck, para->cchk.Sw );

				sprintf( CommandLine, "$%dCCHK%s%s", unit, fork, chuck );
			}
			break;
		case Cmd_CCTM:
			{
				char fork[3], chuckt[3];
				GetForkChar( fork, para->cchk.Fork );
				GetChuckingTimeChar( chuckt, para->cctm.Sw );

				sprintf( CommandLine, "$%dCCTM%s%s", unit, fork, chuckt );
			}
			break;
		case Cmd_SSPD:
			{
				char axis[3], smode[3];
				GetAxisChar( axis, para->sspd.Axis );
				GetSpeedModeChar( smode, para->sspd.SMode );

				sprintf( CommandLine, "$%dSSPD%s%s%06d", unit, axis, smode, para->sspd.Value );
			}
			break;
		case Cmd_SSPP:
			{
				char axis[3], smode[3];
				GetAxisChar( axis, para->sspp.Axis );
				GetSpeedModeChar( smode, para->sspp.SMode );

				sprintf( CommandLine, "$%dSSPP%s%s%04d", unit, axis, smode, para->sspp.Value );
			}
			break;
		case Cmd_SPOS:
			{
				char mem[3], rmode[3], trsSt[3], fork[3], posture[3];
				GetMemoryChar( mem, para->spos.Mem );
				GetRegistModeChar( rmode, para->spos.RMode );
				GetTransferStationChar( trsSt, para->spos.TrsSt );
				GetForkChar( fork, para->spos.Fork );
				GetPostureChar( posture, para->spos.Posture );

				sprintf( CommandLine, "$%dSPOS%s%s%s%s%s", unit, mem, rmode, trsSt, fork, posture );
			}
			break;
		case Cmd_SABS:
			{
				char mem[3], rmode[3], trsSt[3], fork[3], posture[3];
				GetMemoryChar( mem, para->sabs.Mem );
				GetRegistModeChar( rmode, para->sabs.RMode );
				GetTransferStationChar( trsSt, para->sabs.TrsSt );
				GetForkChar( fork, para->sabs.Fork );
				GetPostureChar( posture, para->sabs.Posture );

				sprintf( CommandLine, "$%dSABS%s%s%s%s%s%08d%08d%08d%08d%08d", unit, mem, rmode, trsSt, fork, posture,
														para->sabs.Value1, para->sabs.Value2, para->sabs.Value3, para->sabs.Value4, para->sabs.Value5 );
			}
			break;
		case Cmd_SPSV:
			{
				char trsSt[3], fork[3];
				GetTransferStationChar( trsSt, para->spsv.TrsSt );
				GetForkChar( fork, para->spsv.Fork );

				sprintf( CommandLine, "$%dSPSV%s%s", unit, trsSt, fork );
			}
			break;
		case Cmd_SOFS:
			{
				char mem[3], trsSt[3];
				GetMemoryChar( mem, para->sofs.Mem );
				GetTransferStationChar( trsSt, para->sofs.TrsSt );

				sprintf( CommandLine, "$%dSOFS%s%s%04d%04d%04d%04d%04d", unit, mem, trsSt, 
														para->sofs.Offset1, para->sofs.Offset2, para->sofs.Offset3, para->sofs.Offset4, para->sofs.Offset5 );
			}
			break;
		case Cmd_SMOD:
			{
				char mem[3], trsSt[3], mode[3];
				GetMemoryChar( mem, para->smod.Mem );
				GetTransferStationChar( trsSt, para->smod.TrsSt );
				GetSlotPitchModeChar( mode, para->smod.Mode );

				sprintf( CommandLine, "$%dSMOD%s%s%s", unit, mem, trsSt, mode );
			}
			break;
		case Cmd_SPIT:
			{
				char mem[3], trsSt[3];
				GetMemoryChar( mem, para->spit.Mem );
				GetTransferStationChar( trsSt, para->spit.TrsSt );

				sprintf( CommandLine, "$%dSPIT%s%s%06d", unit, mem, trsSt, para->spit.Value );
			}
			break;
		case Cmd_SSLT:
			{
				char mem[3], trsSt[3];
				GetMemoryChar( mem, para->sslt.Mem );
				GetTransferStationChar( trsSt, para->smod.TrsSt );

				sprintf( CommandLine, "$%dSSLT%s%s%02d", unit, mem, trsSt, para->sslt.SlotNo );
			}
			break;
		case Cmd_SRSV:
			sprintf( CommandLine, "$%dSRSVFFFF", unit );
			break;
		case Cmd_SMSK:
			sprintf( CommandLine, "$%dSMSK%1x%1x%1x%1x", unit, para->smsk.Valid1, para->smsk.Valid2, para->smsk.Valid3, para->smsk.Valid4 );
			break;
		case Cmd_STYP:
			{
				char type[3];
				GetSystemTypeChar( type, para->styp.Type );

				sprintf( CommandLine, "$%dSTYP%s", unit, type );
			}
			break;
		case Cmd_SSTT:
			{
				char type[3], trsSt[3];
				GetSystemTypeChar( type, para->sstt.Type );
				GetTransferStationChar( trsSt, para->sstt.TrsSt );

				sprintf( CommandLine, "$%dSSTT%s%s", unit, type, trsSt );
			}
			break;
		case Cmd_SSLV:
			{
				char level[3];
				GetTransferSpeedLevelChar( level, para->sslv.Level );

				sprintf( CommandLine, "$%dSSLV%s", unit, level );
			}
			break;
		case Cmd_SIOS:
			sprintf( CommandLine, "$%dSIOS%1x%1x%1x%1x", unit, para->sios.Data1, para->sios.Data2, para->sios.Data3, para->sios.Data4 );
			break;
		case Cmd_SPUD:
			{
				char umode[3], trsSt[3], fork[3], posture[3];
				GetUpdateModeChar( umode, para->spud.UMode );
				GetTransferStationChar( trsSt, para->spud.TrsSt );
				GetForkChar( fork, para->spud.Fork );
				GetPostureChar( posture, para->spud.Posture );

				sprintf( CommandLine, "$%dSPUD%s%s%s%s", unit, umode, trsSt, fork, posture );
			}
			break;
		case Cmd_SPRM:
			{
				char type[4];
				GetParameterKindCode( type, para->sprm.Type );

				sprintf( CommandLine, "$%dSPRM%s%04d%012.0f", unit, type, para->sprm.PrmNo, para->sprm.Value );
			}
			break;
		case Cmd_SSTD:
			{
				char axis[3];
				GetAxisChar( axis, para->sstd.Axis );

				sprintf( CommandLine, "$%dSSTD%s", unit, axis );
			}
			break;
		case Cmd_SSTN:
			sprintf( CommandLine, "$%dSSTN%012.0f%012.0f%012.0f%012.0f%012.0f",
														para->sstn.Value1, para->sstn.Value2, para->sstn.Value3, para->sstn.Value4, para->sstn.Value5 );
			break;
		case Cmd_SCAL:
			sprintf( CommandLine, "$%dSCAL%04d%02d%02d%02d%02d%02d", para->scal.Year, para->scal.Mon, para->scal.Day, para->scal.Hour, para->scal.Min, para->scal.Sec );
			break;
		case Cmd_RSPD:
			{
				char axis[3], smode[3];
				GetAxisChar( axis, para->rspd.Axis );
				GetSpeedModeChar( smode, para->rspd.SMode );

				sprintf( CommandLine, "$%dRSPD%s%s", unit, axis, smode );
			}
			break;
		case Cmd_RSPP:
			{
				char axis[3], smode[3];
				GetAxisChar( axis, para->rspp.Axis );
				GetSpeedModeChar( smode, para->rspp.SMode );

				sprintf( CommandLine, "$%dRSPP%s%s", unit, axis, smode );
			}
			break;
		case Cmd_RPOS:
			{
				char trsSt[3], fork[3], posture[3];
				GetTransferStationChar( trsSt, para->rpos.TrsSt );
				GetForkChar( fork, para->rpos.Fork );
				GetPostureChar( posture, para->rpos.Posture );

				sprintf( CommandLine, "$%dRPOS%s%s%s", unit, trsSt, fork, posture );
			}
			break;
		case Cmd_ROFS:
			{
				char trsSt[3];
				GetTransferStationChar( trsSt, para->rofs.TrsSt );

				sprintf( CommandLine, "$%dROFS%s", unit, trsSt );
			}
			break;
		case Cmd_RCST:
			{
				char trsSt[3];
				GetTransferStationChar( trsSt, para->rcst.TrsSt );

				sprintf( CommandLine, "$%dRCST%s", unit, trsSt );
			}
			break;
		case Cmd_RMAP:
			{
				char trsSt[3];
				GetTransferStationChar( trsSt, para->rmap.TrsSt );

				if( para->rmap.SlotNo != -1 ){
					sprintf( CommandLine, "$%dRCST%s%02d", unit, trsSt, para->rmap.SlotNo );
				} else {
					sprintf( CommandLine, "$%dRCST%s%FF", unit, trsSt );
				}
			}
			break;
		case Cmd_RSTS:
			sprintf( CommandLine, "$%dRSTS", unit );
			break;
		case Cmd_RERR:
			sprintf( CommandLine, "$%dRERR", unit );
			break;
		case Cmd_RERT:
			{
				char mem[3];
				GetMemoryChar( mem, para->rert.Mem );

				sprintf( CommandLine, "$%dRERT%s%03d", unit, mem, para->rert.HNo );
			}
			break;
		case Cmd_RMSK:
			sprintf( CommandLine, "$%dRMSK", unit );
			break;
		case Cmd_RTYP:
			sprintf( CommandLine, "$%dRTYP", unit );
			break;
		case Cmd_RSTT:
			{
				char trsSt[3];
				GetTransferStationChar( trsSt, para->rstt.TrsSt );

				sprintf( CommandLine, "$%dRSTT%s", unit, trsSt );
			}
			break;
		case Cmd_RVER:
			sprintf( CommandLine, "$%dRVER", unit );
			break;
		case Cmd_RMDL:
			{
				char mdlNo[3];
				GetModelNumberChar( mdlNo, para->rmdl.MdlNo );

				sprintf( CommandLine, "$%dRMDL%s", unit, mdlNo );
			}
			break;
		case Cmd_RLOG:
			{
				char logNo[3];
				GetLogNumberChar( logNo, para->rlog.LogNo );

				sprintf( CommandLine, "$%dRLOGL%s", unit, logNo );
			}
			break;
		case Cmd_RALN:
			sprintf( CommandLine, "$%dRALN%1d", unit, para->raln.TUNo );
			break;
		case Cmd_RSLV:
			sprintf( CommandLine, "$%dRSLV", unit );
			break;
		case Cmd_RSTP:
			{
				char trsSt[3], pmode[3], fork[3], posture[3];
				GetTransferStationChar( trsSt, para->rstp.TrsSt );
				GetPositionModeChar( pmode, para->rstp.PMode );
				GetForkChar( fork, para->rstp.Fork );
				GetPostureChar( posture, para->rstp.Posture );

				sprintf( CommandLine, "$%dRSTP%s%s%s%s", unit, trsSt, pmode, fork, posture );
			}
			break;
		case Cmd_RIOS:
			sprintf( CommandLine, "$%dRIOS", unit );
			break;
		case Cmd_RMPD:
			{
				char trsSt[3];
				GetTransferStationChar( trsSt, para->rmpd.TrsSt );

				sprintf( CommandLine, "$%dRMPD%s", unit, trsSt );
			}
			break;
		case Cmd_RPRM:
			{
				char type[4];
				GetParameterKindCode( type, para->rprm.Type );

				sprintf( CommandLine, "$%dRPRM%s%04d", unit, type, para->rprm.PrmNo );
			}
			break;
		case Cmd_RCAL:
			sprintf( CommandLine, "$%dRCAL", unit );
			break;
		case Cmd_RCCD:
			sprintf( CommandLine, "$%dRCCD", unit );
			break;
		case Cmd_RSTN:
			sprintf( CommandLine, "$%dRSTN", unit );
			break;
		case Cmd_ACKN:
			sprintf( CommandLine, "$%dACKN", unit );
			break;
//		case Cmd_UPOS:
//			break;
//		case Cmd_UCPR:
//			break;
//		case Cmd_UPRM:
//			break;
//		case Cmd_DPOS:
//			break;
//		case Cmd_DCPR:
//			break;
//		case Cmd_DPRM:
//			break;
		default:
			r = ErrInvalidCmd;
			break;
	}

	if( r == ErrNone ){
		int len = strlen( CommandLine );
		int sum = MakeCheckSum( &CommandLine[1], len-1 );
		sprintf( Terminate, "%02X", sum );
		Terminate[2] = 0x0d;
		Terminate[3] = 0x00;
		
		strcat( CommandLine, Terminate );
	}
	return 0;
}

// �`�F�b�N�T���̍쐬
int		CManipulatorComm::MakeCheckSum( char* P, int n )
{
	int	i;
	int	sum = 0;

	for( i = 0 ; i < n ; i++ ){
		sum += P[i];
	}
	sum &= 0xff;		// ��8�r�b�g�̎��o��

	return sum;
}


int		CManipulatorComm::SendReply( int unit, int CmdCode, char* CommandLine, struct MP_ANSWERDATA* answer)
{
	int		r;
	BOOL	br;
//	BOOL	fWriteStat;				// �������ݏ����ð��
	DWORD	dwBytesWritten=0;		// �������ݻ���(����)
//	int		len;					// ���M�ް���
//	CEvent	eventAnswer;

	CSingleLock S( &eventAnswer );

	SetAnswerEventObject( &eventAnswer, answer );

	WaitForSingleObject( m_hsema, INFINITE );		// ��̫�̊l��

	strcpy( CommandLineBuff, CommandLine );

	// COM�߰��ޯ̧��̸ر
//	PortComm.CommPurge();

	CommandWaitingForReply = CmdCode;
#if 0//!Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"���M:"+CommandLineBuff+"\n");
#endif
//
//	// ������ް����M
//	len = strlen( CommandLine );
//	dwBytesWritten = 0;
//	fWriteStat = WriteFile( PortComm.m_hComm, CommandLine, len, &dwBytesWritten, 0 );
//	if( !fWriteStat || !dwBytesWritten ) {
//		r = ErrSendError;
//		return r;
//	}
//
	evSendRequest.SetEvent();
#if 0
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"���MSetEvent():"+CommandLineBuff+"\n");
#endif


	br = S.Lock( MP_REPLY_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrRTimeOut;
	} else {
		r = answer->errCode;
	}

// 2012.01.09 �G���[���C�x���g�҂��L���[����폜����
	if( r != Err0x0000 ){
		DequeueFromEventQueue( unit, CmdCode );
	}

//	RestartReceive();

	return r;
}



int		CManipulatorComm::SendACKNCommand( int unit )
{
	int		r = ErrNone;
//	BOOL	fWriteStat;				// �������ݏ����ð��
	DWORD	dwBytesWritten=0;		// �������ݻ���(����)
//	int		len;					// ���M�ް���
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_ACKN, CommandLine, &para );

	WaitForSingleObject( m_hsema, INFINITE );		// ��̫�̊l��

	strcpy( CommandLineBuff, CommandLine );

	// COM�߰��ޯ̧��̸ر
//	PortComm.CommPurge();

//	// ������ް����M
//	len = strlen( CommandLine );
//	dwBytesWritten = 0;
//	fWriteStat = WriteFile( PortComm.m_hComm, CommandLine, len, &dwBytesWritten, 0 );
//	if( !fWriteStat || !dwBytesWritten ) {
//		r = ErrSendError;
//	}

	evSendRequest.SetEvent();

	return r;
}



/////////////////////////////////////////////////////////////////////////////
//	GetMoveModeCharForMHOM
//		MHOM �R�}���h�Ŏg�p����MMode���A�R�[�h���當����֕ϊ�����
//	GetMoveModeCodeForMHOM
//		MHOM �R�}���h�Ŏg�p����MMode���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetMoveModeCharForMHOM( char cmmode[], int MMode )
{
	cmmode[0] = 0x0;
	cmmode[1] = 0x0;

	if( MMode == MPCMD_MMODE_F ){
		cmmode[0] = '0';
	} else if( MMode == MPCMD_MMODE_A ){
		cmmode[0] = '1';
	}
}
int		CManipulatorComm::GetMoveModeCodeForMHOM( CString cmmode )
{
	int		r = -1;
	if( cmmode == _T("F") )
		r = MPCMD_MMODE_F;
	else
	if( cmmode == _T("A") )
		r = MPCMD_MMODE_A;
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetTransferStationChar
//		�����X�e�[�V�������A�R�[�h���當����֕ϊ�����
//	GetTransferStationCode
//		�����X�e�[�V�������A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetTransferStationChar( char ctrsSt[], int TrsSt )
{
	int	btable[] =
	{
		MPCMD_TRSST_C1, MPCMD_TRSST_C2, MPCMD_TRSST_C3, MPCMD_TRSST_C4, MPCMD_TRSST_C5, MPCMD_TRSST_C6, MPCMD_TRSST_C7, MPCMD_TRSST_C8, MPCMD_TRSST_S1, MPCMD_TRSST_S2,
		MPCMD_TRSST_S3, MPCMD_TRSST_S4, MPCMD_TRSST_S5, MPCMD_TRSST_S6, MPCMD_TRSST_S7, MPCMD_TRSST_S8, MPCMD_TRSST_S9, MPCMD_TRSST_SA, MPCMD_TRSST_SB, MPCMD_TRSST_SC,
		MPCMD_TRSST_H1, MPCMD_TRSST_H2, MPCMD_TRSST_H3, MPCMD_TRSST_H4, MPCMD_TRSST_H5, MPCMD_TRSST_H6, MPCMD_TRSST_H7, MPCMD_TRSST_H8, MPCMD_TRSST_P1, MPCMD_TRSST_P2,
		MPCMD_TRSST_GP, MPCMD_TRSST_R3, MPCMD_TRSST_R2, MPCMD_TRSST_FF, MPCMD_TRSST_FE, -1
	};
	char*	ctable[] =
	{
		"C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "S1", "S2",
		"S3", "S4", "S5", "S6", "S7", "S8", "S9", "SA", "SB", "SC",
		"H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8", "P1", "P2",
		"GP", "R3", "R2", "FF", "FE"
	};

	Code2String( ctrsSt, TrsSt, 3, btable, ctable );

}
int		CManipulatorComm::GetTransferStationCode( CString ctrsSt )
{
	int		r;
	int	btable[] =
	{
		MPCMD_TRSST_C1, MPCMD_TRSST_C2, MPCMD_TRSST_C3, MPCMD_TRSST_C4, MPCMD_TRSST_C5, MPCMD_TRSST_C6, MPCMD_TRSST_C7, MPCMD_TRSST_C8, MPCMD_TRSST_S1, MPCMD_TRSST_S2,
		MPCMD_TRSST_S3, MPCMD_TRSST_S4, MPCMD_TRSST_S5, MPCMD_TRSST_S6, MPCMD_TRSST_S7, MPCMD_TRSST_S8, MPCMD_TRSST_S9, MPCMD_TRSST_SA, MPCMD_TRSST_SB, MPCMD_TRSST_SC,
		MPCMD_TRSST_H1, MPCMD_TRSST_H2, MPCMD_TRSST_H3, MPCMD_TRSST_H4, MPCMD_TRSST_H5, MPCMD_TRSST_H6, MPCMD_TRSST_H7, MPCMD_TRSST_H8, MPCMD_TRSST_P1, MPCMD_TRSST_P2,
		MPCMD_TRSST_GP, MPCMD_TRSST_R3, MPCMD_TRSST_R2, MPCMD_TRSST_FF, MPCMD_TRSST_FE, -1
	};
	char*	ctable[] =
	{
		"C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "S1", "S2",
		"S3", "S4", "S5", "S6", "S7", "S8", "S9", "SA", "SB", "SC",
		"H1", "H2", "H3", "H4", "H5", "H6", "H7", "H8", "P1", "P2",
		"GP", "R3", "R2", "FF", "FE"
	};

	r = String2Code( ctrsSt, btable, ctable );

	return r;
}

/////////////////////////////////////////////////////////////////////////////
//	GetNextMoveModeChar
//		 �����샂�[�h���A�R�[�h���當����֕ϊ�����
//	GetNextMoveModeCode
//		 �����샂�[�h���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetNextMoveModeChar( char cnextMtn[], int NextMtn )
{
	int	btable[] =
	{
		MPCMD_NEXTMTN_GA, MPCMD_NEXTMTN_GB, MPCMD_NEXTMTN_GW, MPCMD_NEXTMTN_PA, MPCMD_NEXTMTN_PB, MPCMD_NEXTMTN_PW, MPCMD_NEXTMTN_EA, MPCMD_NEXTMTN_EB, MPCMD_NEXTMTN_AL, -1
	};
	char*	ctable[] =
	{
		"GA", "GB", "GW", "PA", "PB", "PW", "EA", "EB", "AL"
	};

	Code2String( cnextMtn, NextMtn, 3, btable, ctable );

}
int		CManipulatorComm::GetNextMoveModeCode( CString cnextMtn )
{
	int		r;
	int	btable[] =
	{
		MPCMD_NEXTMTN_GA, MPCMD_NEXTMTN_GB, MPCMD_NEXTMTN_GW, MPCMD_NEXTMTN_PA, MPCMD_NEXTMTN_PB, MPCMD_NEXTMTN_PW, MPCMD_NEXTMTN_EA, MPCMD_NEXTMTN_EB, MPCMD_NEXTMTN_AL, -1
	};
	char*	ctable[] =
	{
		"GA", "GB", "GW", "PA", "PB", "PW", "EA", "EB", "AL"
	};

	r = String2Code( cnextMtn, btable, ctable );

	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetPostureChar
//		 �A�[���p�����A�R�[�h���當����֕ϊ�����
//	GetPostureCode
//		 �A�[���p�����A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetPostureChar( char cposture[], int Posture )
{
	int	btable[] =
	{
		MPCMD_POSTURE_L, MPCMD_POSTURE_R, MPCMD_POSTURE_A, -1
	};
	char*	ctable[] =
	{
		"L", "R", "A"
	};

	Code2String( cposture, Posture, 3, btable, ctable );

}
int		CManipulatorComm::GetPostureCode( CString cposture )
{
	int		r;
	int	btable[] =
	{
		MPCMD_POSTURE_L, MPCMD_POSTURE_R, MPCMD_POSTURE_A, -1
	};
	char*	ctable[] =
	{
		"L", "R", "A"
	};

	r = String2Code( cposture, btable, ctable );

	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetTransferPointChar
//		 �����|�C���g ���A�R�[�h���當����֕ϊ�����
//	GetTransferPointCode
//		 �����|�C���g ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetTransferPointChar( char ctrsPnt[], int TrsPnt )
{
	int	btable[] =
	{
		MPCMD_TRSPNT_G1, MPCMD_TRSPNT_G2, MPCMD_TRSPNT_Gb, MPCMD_TRSPNT_G3, MPCMD_TRSPNT_G4, MPCMD_TRSPNT_G5, MPCMD_TRSPNT_G6, MPCMD_TRSPNT_G7, MPCMD_TRSPNT_G8, MPCMD_TRSPNT_P1,
		MPCMD_TRSPNT_P2, MPCMD_TRSPNT_Pb, MPCMD_TRSPNT_P3, MPCMD_TRSPNT_P4, MPCMD_TRSPNT_P5, MPCMD_TRSPNT_P6, MPCMD_TRSPNT_P7, MPCMD_TRSPNT_P8, -1
	};
	char*	ctable[] =
	{
		"G1", "G2", "Gb", "G3", "G4", "G5", "G6", "G7", "G8", "P1",
		"P2", "Pb", "P3", "P4", "P5", "P6", "P7", "P8"
	};

	Code2String( ctrsPnt, TrsPnt, 3, btable, ctable );
}
int		CManipulatorComm::GetTransferPointCode( CString ctrsPnt )
{
	int		r;
	int	btable[] =
	{
		MPCMD_TRSPNT_G1, MPCMD_TRSPNT_G2, MPCMD_TRSPNT_Gb, MPCMD_TRSPNT_G3, MPCMD_TRSPNT_G4, MPCMD_TRSPNT_G5, MPCMD_TRSPNT_G6, MPCMD_TRSPNT_G7, MPCMD_TRSPNT_G8, MPCMD_TRSPNT_P1,
		MPCMD_TRSPNT_P2, MPCMD_TRSPNT_Pb, MPCMD_TRSPNT_P3, MPCMD_TRSPNT_P4, MPCMD_TRSPNT_P5, MPCMD_TRSPNT_P6, MPCMD_TRSPNT_P7, MPCMD_TRSPNT_P8, -1
	};
	char*	ctable[] =
	{
		"G1", "G2", "Gb", "G3", "G4", "G5", "G6", "G7", "G8", "P1",
		"P2", "Pb", "P3", "P4", "P5", "P6", "P7", "P8"
	};

	r = String2Code( ctrsPnt, btable, ctable );

	return r;
}



/////////////////////////////////////////////////////////////////////////////
//	GetMtnModeChar
//		 ���샂�[�h ���A�R�[�h���當����֕ϊ�����
//	GetMtnModeCode
//		 ���샂�[�h ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetMtnModeChar( char cmtnMode[], int MtnMode )
{
	int	btable[] =
	{
		MPCMD_MTNMODE_GA, MPCMD_MTNMODE_GB, MPCMD_MTNMODE_GW, MPCMD_MTNMODE_PA, MPCMD_MTNMODE_PB, MPCMD_MTNMODE_PW, MPCMD_MTNMODE_EA, MPCMD_MTNMODE_EB, -1
	};
	char*	ctable[] =
	{
		"GA", "GB", "GW", "PA", "PB", "PW", "EA", "EB"
	};

	Code2String( cmtnMode, MtnMode, 3, btable, ctable );
}
int		CManipulatorComm::GetMtnModeCode( CString cmtnMode )
{
	int		r;
	int	btable[] =
	{
		MPCMD_MTNMODE_PA, MPCMD_MTNMODE_PB, MPCMD_MTNMODE_PW, MPCMD_MTNMODE_EA, MPCMD_MTNMODE_EB, -1
	};
	char*	ctable[] =
	{
		"PA", "PB", "PW", "EA", "EB"
	};

	r = String2Code( cmtnMode, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetForkChar
//		 �t�H�[�N�w�� ���A�R�[�h���當����֕ϊ�����
//	GetForkCode
//		 �t�H�[�N�w�� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetForkChar( char cfork[], int Fork )
{
	int	btable[] =
	{
		MPCMD_FORK_A, MPCMD_FORK_B, MPCMD_FORK_M, MPCMD_FORK_W, -1
	};
	char*	ctable[] =
	{
		"A", "B", "M", "W"
	};

	Code2String( cfork, Fork, 3, btable, ctable );
}
int		CManipulatorComm::GetForkCode( CString cfork )
{
	int		r;
	int	btable[] =
	{
		MPCMD_FORK_A, MPCMD_FORK_B, MPCMD_FORK_M, MPCMD_FORK_W, -1
	};
	char*	ctable[] =
	{
		"A", "B", "M", "W"
	};

	r = String2Code( cfork, btable, ctable );
	return r;
}



/////////////////////////////////////////////////////////////////////////////
//	GetPositionModeChar
//		 �ʒu���[�h ���A�R�[�h���當����֕ϊ�����
//	GetPositionModeCode
//		 �ʒu���[�h ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetPositionModeChar( char cpmode[], int PMode )
{
	int	btable[] =
	{
		MPCMD_PMODE_S, MPCMD_PMODE_R, MPCMD_PMODE_B, MPCMD_PMODE_E, MPCMD_PMODE_V, MPCMD_PMODE_C, -1
	};
	char*	ctable[] =
	{
		"S", "R", "B", "E", "V", "C"
	};

	Code2String( cpmode, PMode, 2, btable, ctable );
}
int		CManipulatorComm::GetPositionModeCode( CString cpmode )
{
	int		r;
	int	btable[] =
	{
		MPCMD_PMODE_S, MPCMD_PMODE_R, MPCMD_PMODE_B, MPCMD_PMODE_E, MPCMD_PMODE_V, MPCMD_PMODE_C, -1
	};
	char*	ctable[] =
	{
		"S", "R", "B", "E", "V", "C"
	};

	r = String2Code( cpmode, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetAxisChar
//		 �� ���A�R�[�h���當����֕ϊ�����
//	GetAxisCode
//		 �� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetAxisChar( char caxis[], int Axis )
{
	int	btable[] =
	{
		MPCMD_AXIS_S, MPCMD_AXIS_A, MPCMD_AXIS_B, MPCMD_AXIS_H, MPCMD_AXIS_I, MPCMD_AXIS_Z, MPCMD_AXIS_T, MPCMD_AXIS_X, MPCMD_AXIS_Y, MPCMD_AXIS_G, -1
	};
	char*	ctable[] =
	{
		"S", "A", "B", "H", "I", "Z", "T", "X", "Y", "G"
	};

	Code2String( caxis, Axis, 2, btable, ctable );
}
int		CManipulatorComm::GetAxisCode( CString caxis )
{
	int		r;
	int	btable[] =
	{
		MPCMD_AXIS_S, MPCMD_AXIS_A, MPCMD_AXIS_B, MPCMD_AXIS_H, MPCMD_AXIS_I, MPCMD_AXIS_Z, MPCMD_AXIS_T, MPCMD_AXIS_X, MPCMD_AXIS_Y,MPCMD_AXIS_G, -1
	};
	char*	ctable[] =
	{
		"S", "A", "B", "H", "I", "Z", "T", "X", "Y", "G"
	};

	r = String2Code( caxis, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetWristModeChar
//		 ��񎲓��샂�[�h ���A�R�[�h���當����֕ϊ�����
//	GetWristModeCode
//		 ��񎲓��샂�[�h ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetWristModeChar( char cmode[], int Mode )
{
	int	btable[] =
	{
		MPCMD_MODE_C, MPCMD_MODE_H, MPCMD_MODE_I, -1
	};
	char*	ctable[] =
	{
		"C", "H", "I"
	};

	Code2String( cmode, Mode, 2, btable, ctable );
}
int		CManipulatorComm::GetWristModeCode( CString cmode )
{
	int		r;
	int	btable[] =
	{
		MPCMD_MODE_C, MPCMD_MODE_H, MPCMD_MODE_I, -1
	};
	char*	ctable[] =
	{
		"C", "H", "I"
	};

	r = String2Code( cmode, btable, ctable );
	return r;
}



/////////////////////////////////////////////////////////////////////////////
//	GetServoOnOffChar
//		 �T�[�{�w�� ���A�R�[�h���當����֕ϊ�����
//	GetServoOnOffCode
//		 �T�[�{�w�� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetServoOnOffChar( char cservo[], int Servo )
{
	int	btable[] =
	{
		MPCMD_SERVO_OFF, MPCMD_SERVO_ON, -1
	};
	char*	ctable[] =
	{
		"0", "1"
	};

	Code2String( cservo, Servo, 2, btable, ctable );
}
int		CManipulatorComm::GetServoOnOffCode( CString cservo )
{
	int		r;
	int	btable[] =
	{
		MPCMD_SERVO_OFF, MPCMD_SERVO_ON, -1
	};
	char*	ctable[] =
	{
		"0", "1"
	};

	r = String2Code( cservo, btable, ctable );
	return r;
}



/////////////////////////////////////////////////////////////////////////////
//	GetClearModeChar
//		 �N���A���[�h ���A�R�[�h���當����֕ϊ�����
//	GetClearModeCode
//		 �N���A���[�h ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetClearModeChar( char ccmode[], int CMode )
{
	int	btable[] =
	{
		MPCMD_CMODE_E, MPCMD_CMODE_H, -1
	};
	char*	ctable[] =
	{
		"E", "H"
	};

	Code2String( ccmode, CMode, 2, btable, ctable );
}
int		CManipulatorComm::GetClearModeCode( CString ccmode )
{
	int		r;
	int	btable[] =
	{
		MPCMD_CMODE_E, MPCMD_CMODE_H, -1
	};
	char*	ctable[] =
	{
		"E", "H"
	};

	r = String2Code( ccmode, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetChuckingChar
//		 �`���b�L���O�w�� ���A�R�[�h���當����֕ϊ�����
//	GetChuckingCode
//		 �`���b�L���O�w�� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetChuckingChar( char cchuck[], int Chuck )
{
	int	btable[] =
	{
		MPCMD_CHUCK_OFF, MPCMD_CHUCK_ON, -1
	};
	char*	ctable[] =
	{
		"0", "1"
	};

	Code2String( cchuck, Chuck, 2, btable, ctable );
}
int		CManipulatorComm::GetChuckingCode( CString cchuck )
{
	int		r;
	int	btable[] =
	{
		MPCMD_CHUCK_OFF, MPCMD_CHUCK_ON, -1
	};
	char*	ctable[] =
	{
		"0", "1"
	};

	r = String2Code( cchuck, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetChuckingTimeChar
//		 �`���b�L���O���Ԍv�� ���A�R�[�h���當����֕ϊ�����
//	GetChuckingTimeCode
//		 �`���b�L���O���Ԍv�� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetChuckingTimeChar( char cchuck[], int Chuck )
{
	int	btable[] =
	{
		MPCMD_CHUCK_OFF, MPCMD_CHUCK_ON, -1
	};
	char*	ctable[] =
	{
		"0", "1"
	};

	Code2String( cchuck, Chuck, 2, btable, ctable );
}
int		CManipulatorComm::GetChuckingTimeCode( CString cchuck )
{
	int		r;
	int	btable[] =
	{
		MPCMD_CHUCK_OFF_TM, MPCMD_CHUCK_ON_TM, -1
	};
	char*	ctable[] =
	{
		"0", "1"
	};

	r = String2Code( cchuck, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetLifterChar
//		 ���t�^�w�� ���A�R�[�h���當����֕ϊ�����
//	GetLifterCode
//		 ���t�^�w�� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetLifterChar( char clift[], int Lift )
{
	int	btable[] =
	{
		MPCMD_LIFT_DOWN, MPCMD_LIFT_UP, -1
	};
	char*	ctable[] =
	{
		"0", "1"
	};

	Code2String( clift, Lift, 2, btable, ctable );
}
int		CManipulatorComm::GetLifterCode( CString clift )
{
	int		r;
	int	btable[] =
	{
		MPCMD_LIFT_DOWN, MPCMD_LIFT_UP, -1
	};
	char*	ctable[] =
	{
		"0", "1"
	};

	r = String2Code( clift, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetSpeedModeChar
//		 ���x���[�h ���A�R�[�h���當����֕ϊ�����
//	GetSpeedModeCode
//		 ���x���[�h ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetSpeedModeChar( char csmode[], int SMode )
{
	int	btable[] =
	{
		MPCMD_SMODE_H, MPCMD_SMODE_M, MPCMD_SMODE_L, MPCMD_SMODE_O, MPCMD_SMODE_B, -1
	};
	char*	ctable[] =
	{
		"H", "M", "L", "O", "B"
	};

	Code2String( csmode, SMode, 2, btable, ctable );
}
int		CManipulatorComm::GetSpeedModeCode( CString csmode )
{
	int		r;
	int	btable[] =
	{
		MPCMD_SMODE_H, MPCMD_SMODE_M, MPCMD_SMODE_L, MPCMD_SMODE_O, MPCMD_SMODE_B, -1
	};
	char*	ctable[] =
	{
		"H", "M", "L", "O", "B"
	};

	r = String2Code( csmode, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetMemoryChar
//		 ������ ���A�R�[�h���當����֕ϊ�����
//	GetMemoryCode
//		 ������ ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetMemoryChar( char cmemory[], int Memory )
{
	int	btable[] =
	{
		MPCMD_MEM_V, MPCMD_MEM_N, -1
	};
	char*	ctable[] =
	{
		"V", "N"
	};

	Code2String( cmemory, Memory, 2, btable, ctable );
}
int		CManipulatorComm::GetMemoryCode( CString cmemory )
{
	int		r;
	int	btable[] =
	{
		MPCMD_MEM_V, MPCMD_MEM_N, -1
	};
	char*	ctable[] =
	{
		"V", "N"
	};

	r = String2Code( cmemory, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetRegistModeChar
//		 �o�^���[�h ���A�R�[�h���當����֕ϊ�����
//	GetRegistModeCode
//		 �o�^���[�h ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetRegistModeChar( char crmode[], int RMode )
{
	int	btable[] =
	{
		MPCMD_RMODE_N, MPCMD_RMODE_A, MPCMD_RMODE_V, -1
	};
	char*	ctable[] =
	{
		"B", "A", "V"
	};

	Code2String( crmode, RMode, 2, btable, ctable );
}
int		CManipulatorComm::GetRegistModeCode( CString crmode )
{
	int		r;
	int	btable[] =
	{
		MPCMD_RMODE_N, MPCMD_RMODE_A, MPCMD_RMODE_V, -1
	};
	char*	ctable[] =
	{
		"B", "A", "V"
	};

	r = String2Code( crmode, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetSlotPitchModeChar
//		 �X���b�g�ԃs�b�`�����������[�h ���A�R�[�h���當����֕ϊ�����
//	GetSlotPitchModeCode
//		 �X���b�g�ԃs�b�`�����������[�h ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetSlotPitchModeChar( char cspmode[], int SPMode )
{
	int	btable[] =
	{
		MPCMD_SPMODE_A, MPCMD_SPMODE_F, -1
	};
	char*	ctable[] =
	{
		"A", "F"
	};

	Code2String( cspmode, SPMode, 2, btable, ctable );
}
int		CManipulatorComm::GetSlotPitchModeCode( CString cspmode )
{
	int		r;
	int	btable[] =
	{
		MPCMD_SPMODE_A, MPCMD_SPMODE_F, -1
	};
	char*	ctable[] =
	{
		"A", "F"
	};

	r = String2Code( cspmode, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetSystemTypeChar
//		 �V�X�e���^�C�v ���A�R�[�h���當����֕ϊ�����
//	GetSystemTypeCode
//		 �V�X�e���^�C�v ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetSystemTypeChar( char cstype[], int SType )
{
	int	btable[] =
	{
		MPCMD_TYPE_1, MPCMD_TYPE_2, MPCMD_TYPE_3, MPCMD_TYPE_4, -1
	};
	char*	ctable[] =
	{
		"1", "2", "3", "4"
	};

	Code2String( cstype, SType, 2, btable, ctable );
}
int		CManipulatorComm::GetSystemTypeCode( CString cstype )
{
	int		r;
	int	btable[] =
	{
		MPCMD_TYPE_1, MPCMD_TYPE_2, MPCMD_TYPE_3, MPCMD_TYPE_4, -1
	};
	char*	ctable[] =
	{
		"1", "2", "3", "4"
	};

	r = String2Code( cstype, btable, ctable );
	return r;
}



/////////////////////////////////////////////////////////////////////////////
//	GetTransferSpeedLevelChar
//		 �������x���x�� ���A�R�[�h���當����֕ϊ�����
//	GetTransferSpeedLevelCode
//		 �������x���x�� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetTransferSpeedLevelChar( char cslevel[], int SLevel )
{
	int	btable[] =
	{
		MPCMD_SLEVEL_H, MPCMD_SLEVEL_M, MPCMD_SLEVEL_L, -1
	};
	char*	ctable[] =
	{
		"H", "M", "L"
	};

	Code2String( cslevel, SLevel, 2, btable, ctable );
}
int		CManipulatorComm::GetTransferSpeedLevelCode( CString cslevel )
{
	int		r;
	int	btable[] =
	{
		MPCMD_SLEVEL_H, MPCMD_SLEVEL_M, MPCMD_SLEVEL_L, -1
	};
	char*	ctable[] =
	{
		"H", "M", "L"
	};

	r = String2Code( cslevel, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetUpdateModeChar
//		 �X�V���[�h ���A�R�[�h���當����֕ϊ�����
//	GetUpdateModeCode
//		 �X�V���[�h ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetUpdateModeChar( char cumode[], int UMode )
{
	int	btable[] =
	{
		MPCMD_UMODE_A, MPCMD_UMODE_N, MPCMD_UMODE_V, -1
	};
	char*	ctable[] =
	{
		"A", "N", "V"
	};

	Code2String( cumode, UMode, 2, btable, ctable );
}
int		CManipulatorComm::GetUpdateModeCode( CString cumode )
{
	int		r;
	int	btable[] =
	{
		MPCMD_UMODE_A, MPCMD_UMODE_N, MPCMD_UMODE_V, -1
	};
	char*	ctable[] =
	{
		"A", "N", "V"
	};

	r = String2Code( cumode, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetParameterKindChar
//		 �p�����[�^��� ���A�R�[�h���當����֕ϊ�����
//	GetParameterKindCode
//		 �p�����[�^��� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetParameterKindChar( char cptype[], int PType )
{
	int	btable[] =
	{
		MPCMD_UMODE_A, MPCMD_UMODE_N, MPCMD_UMODE_V, -1
	};
	char*	ctable[] =
	{
		"A", "N", "V"
	};

	Code2String( cptype, PType, 4, btable, ctable );
}
void		CManipulatorComm::GetParameterKindCode( char cptype[], int PCType )
{
//	int		r;
	int	btable[] =
	{
		MPCMD_TYPE_CIU, MPCMD_TYPE_CRU, MPCMD_TYPE_UIU, MPCMD_TYPE_URU, -1
	};
	char*	ctable[] =
	{
		"CIU", "CRU", "UIU", "URU"
	};

//	r = String2Code( cptype, btable, ctable );
	Code2String( cptype, PCType, 4, btable, ctable );
//	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetModelNumberChar
//		 ���f���ԍ� ���A�R�[�h���當����֕ϊ�����
//	GetModelNumberCode
//		 ���f���ԍ� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetModelNumberChar( char cmodel[], int Model )
{
	int	btable[] =
	{
		MPCMD_MODEL_00, MPCMD_MODEL_01, MPCMD_MODEL_10, MPCMD_MODEL_11, MPCMD_MODEL_12, MPCMD_MODEL_13, MPCMD_MODEL_20, -1
	};
	char*	ctable[] =
	{
		"00", "01", "10", "11", "12", "13", "20"
	};

	Code2String( cmodel, Model, 3, btable, ctable );
}
int		CManipulatorComm::GetModelNumberCode( CString cmodel )
{
	int		r;
	int	btable[] =
	{
		MPCMD_MODEL_00, MPCMD_MODEL_01, MPCMD_MODEL_10, MPCMD_MODEL_11, MPCMD_MODEL_12, MPCMD_MODEL_13, MPCMD_MODEL_20, -1
	};
	char*	ctable[] =
	{
		"00", "01", "10", "11", "12", "13", "20"
	};

	r = String2Code( cmodel, btable, ctable );
	return r;
}


/////////////////////////////////////////////////////////////////////////////
//	GetLogNumberChar
//		 ���O�ԍ� ���A�R�[�h���當����֕ϊ�����
//	GetLogNumberCode
//		 ���O�ԍ� ���A�����񂩂�R�[�h�֕ϊ�����
/////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::GetLogNumberChar( char clogno[], int LogNo )
{
	int	btable[] =
	{
		MPCMD_MODEL_00, MPCMD_MODEL_01, MPCMD_MODEL_10, MPCMD_MODEL_11, MPCMD_MODEL_12, MPCMD_MODEL_13, MPCMD_MODEL_20, -1
	};
	char*	ctable[] =
	{
		"00", "01", "10", "11", "12", "13", "20"
	};

	Code2String( clogno, LogNo, 3, btable, ctable );
}
int		CManipulatorComm::GetLogNumberCode( CString clogno )
{
	int		r;
	int	btable[] =
	{
		MPCMD_MODEL_00, MPCMD_MODEL_01, MPCMD_MODEL_10, MPCMD_MODEL_11, MPCMD_MODEL_12, MPCMD_MODEL_13, MPCMD_MODEL_20, -1
	};
	char*	ctable[] =
	{
		"00", "01", "10", "11", "12", "13", "20"
	};

	r = String2Code( clogno, btable, ctable );
	return r;
}




///////////////////////////////////////////////////////////////////////////////////////////////////////
void	CManipulatorComm::Code2String( char* str, int code, int n, int btable[], char *ctable[] )
{
	int		i, j;
	for( i = 0 ; i < n+1 ; i ++ ){
		str[i] = 0x0;
	}

	for( i = 0 ; btable[i] != -1 ; i ++ ){
		if( code == btable[i] ){
			for( j = 0 ; j < n ; j ++ ){
				str[j] = ctable[i][j];
			}
			break;
		}
	}
}
int		CManipulatorComm::String2Code( CString str, int btable[], char *ctable[] )
{
	int		i, r;

	r = -1;
	for( i = 0 ; btable[i] != -1 ; i ++ ){
		if( str == _T(ctable[i]) ){
			r = btable[i];
			break;
		}
	}
	return r;
}





// COM �|�[�g��M�X���b�h
UINT	CManipulatorComm::CommRecv( LPVOID pParam )
{
	enum {
		IDLE = 0,		// �A�C�h�����		'$'or'!'or'>'�̎�M�҂�->0x0D��M�܂ŉ����܂��̓C�x���g�Ƃ��ĕ������ێ�
		WTCR = 1,		// �I�[��M��		0x0D�̎�M�҂�
	};

	int		i, fReadStat;
	int		PStatus;
	unsigned long	dwLength = 0;
	char	rcvBuf[1000];
	CString		rstr;

	CManipulatorComm	*pManipulator = (CManipulatorComm *)pParam;

	PStatus = IDLE;
//	CSingleLock	S( &(pLoadPort->evNextRcvOk) );
#if !Release
	CString	Msg;
	CTime theTime;
#endif
	rstr.Empty();
	for(;;) {
		if( (pManipulator->PortComm.m_hComm != (void *)0) && ((pManipulator->PortComm.m_hComm != (void *)0xffffffff)) ){
			fReadStat = ReadFile( pManipulator->PortComm.m_hComm, &rcvBuf, 1, &dwLength, 0 );

			if( fReadStat && dwLength ){

				for( i=0 ; i<(int)dwLength ; i++ ){
					switch( PStatus ){
					case	IDLE:		// �A�C�h�����
						if ( (rcvBuf[i] == CManipulatorComm::STARTCHAR1) || (rcvBuf[i] == CManipulatorComm::STARTCHAR2) || (rcvBuf[i] == CManipulatorComm::STARTCHAR3) ){
							rstr += rcvBuf[i];
							PStatus = WTCR;
//#if !Release
//	theTime = CTime::GetCurrentTime();
//	Msg = theTime.Format("%H:%M:%S,");
//	TRACE(Msg+"��M:");
//#endif						
						}
						break;
					case	WTCR:		// �I�[��M��
						if (rcvBuf[i] != CManipulatorComm::TERMCHAR1 ){
							rstr += rcvBuf[i];
						} else {
							int		len;
							len = rstr.GetLength();
							if( len > 3 ){
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,��M:");
//	TRACE(Msg+"��M:");
//	theTime = CTime::GetCurrentTime();
//	Msg = theTime.Format(":%S,");
//	TRACE(rstr+" "+Msg+"\n");
	TRACE(Msg+rstr+"\n");
#endif
								int ae = pManipulator->AnalizeReceiveData( rstr );		// ��M�f�[�^����͂����Z�b�g��C�x���g�𔭍s����
//								if ( ae == CManipulatorComm::RcvANSWER ){
//									S.Lock( INFINITE );
//									S.Unlock();
//								} else
//								if ( ae == CManipulatorComm::RcvEVENT ){
//									S.Lock( INFINITE );
//									S.Unlock();
//								} else {
//									rstr.Empty();				// ��M����������S�Ĕj��
//									PStatus = IDLE;				// �A�C�h����Ԃ�
//								}
							}
							rstr.Empty();				// ��M����������S�Ĕj��
							PStatus = IDLE;				// �A�C�h����Ԃ�
						}
						break;
					}
				}
			} else {
				Sleep( 10 );
			}
		} else {
			Sleep( 10 );
		}
	}
	return 0;
}

UINT	CManipulatorComm::CommSend( LPVOID pParam )
{
	long	pc;
	BOOL	fWriteStat;				// �������ݏ����ð��
	DWORD	dwBytesWritten=0;		// �������ݻ���(����)
	int		len;					// ���M�ް���

	CManipulatorComm	*pManipulator = (CManipulatorComm *)pParam;

	CSingleLock	S( &(pManipulator->evSendRequest) );

	for(;;) {
		S.Lock( INFINITE );
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"���M:"+pManipulator->CommandLineBuff+"\n");
#endif
		// ������ް����M
		len = strlen( pManipulator->CommandLineBuff );
		dwBytesWritten = 0;
		fWriteStat = WriteFile( pManipulator->PortComm.m_hComm, pManipulator->CommandLineBuff, len, &dwBytesWritten, 0 );
		if( !fWriteStat || !dwBytesWritten ) {
		//	r = ErrSendError;
		//	return r;
		}

#if !Release
//	CString	Msg;
//	CTime 
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"���M����:"+pManipulator->CommandLineBuff+"\n");
#endif
		S.Unlock();

		ReleaseSemaphore( pManipulator->m_hsema, 1, &pc );			// ��̫�̉��

	}
	return 0;
}

UINT	CManipulatorComm::CommEvent( LPVOID pParam )
{
	return 0;
}


// ManipulatorCommand.cpp: CManipulatorComm �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#ifdef	TEST
#include "..\stdafx.h"
#else
#include "..\..\..\..\stdafx.h"
#endif
//#include "LPMPPARITest.h"
//#include "PortComm.h"
#include "ManipulatorComm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////////////////////////////
// �J�Z�b�g��ƒi���Ə㉺�r���w�肵�āA�J�Z�b�g���烏�[�N���󂯎��A�v���A���C�i�[��֎󂯓n���B
//
//	int SendManipulator_GetFromCassetteAndPutToPreAligner( int TrsSt, int SlotNo, int Fork, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData )
//
//	Return	: error code
//	
//	int TrsSt	: MPCMD_TRSST_C1 �` MPCMD_TRSST_C4 (300mm) or MPCMD_TRSST_C5 �` MPCMD_TRSST_C8 (200mm)
//	int SlotNo	: 1 �` 25
//	int Fork	: MPCMD_FORK_A or MPCMD_FORK_B
//	struct MP_ANSWERDATA* anData	: �������(�����G���[�����������ꍇ�A�Ō�̃R�}���h�̉������)
//	struct MP_FINISHDATA* fnData	: ����I�����(�����G���[�����������ꍇ�A�Ō�̃R�}���h�̏I�����)
//
/////////////////////////////////////////////////////////////////////////////////////////////////////
int	CManipulatorComm::SendManipulator_GetFromCassetteAndPutToPreAligner( int TrsSt, int SlotNo, int Fork, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData )
{
	int		r = ErrNone;
	int		sts1, sts2, sts3, andd;
	int		nextMtn;

	if( TrsSt < MPCMD_TRSST_C1 || MPCMD_TRSST_C8 < TrsSt ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( Fork != MPCMD_FORK_A && Fork != MPCMD_FORK_B ){
		r = ErrParameter;
		return r;
	}

	r = SendManipulator_RSTS( UNIT_MANIPULATOR, anData );	// �}�j�s�����[�^�̃X�e�[�^�X�ǂݍ���
	if( r != ErrNone ){
		return r;
	}

//TRACE( "Send RSTS Command To Manipurator\n" );

	andd = 0x05;		// �L�k��1(�n���h1)��̃��[�N�L����� �� �L�k��1(�n���h1)�̃`���b�L���O�w�ߏ��
	if( Fork == MPCMD_FORK_B ){
		andd = 0x0A;		// �L�k��2(�n���h2)��̃��[�N�L����� �� �L�k��2(�n���h2)�̃`���b�L���O�w�ߏ��
	}
	sts1 = anData->u_asdata.rsts.Status1 & andd;
	if( sts1 != andd ){		// ���[�N�������Ă���
		r = ErrDetectedWork;
		return r;
	}
	sts2 = anData->u_asdata.rsts.Status2 & 0xf;		// �O���C���^�[���b�N���(�ėp�M��) 1 �` 4
	sts3 = anData->u_asdata.rsts.Status3 & 0xf;		// �O���C���^�[���b�N���(�ėp�M��) 5 �` 8
//	if( sts2 != 0x0f || sts3 != 0x0f ){
//		r = ErrExtInterLock;						// �O���C���^�[���b�N�G���[
//		return r;
//	}

	r = SendManipulator_RSTS( UNIT_PREALIGNER, anData );	// �v���A���C�i�[�̃X�e�[�^�X�ǂݍ���
	if( r != ErrNone ){
		return r;
	}

//TRACE( "Send RSTS Command To Prealigner\n" );

	sts1 = anData->u_asdata.rsts.Status1 & 0x7;
	if( sts1 != 0x7 ){		// ���[�N�������Ă���
		r = ErrDetectedWork;
		return r;
	}

	nextMtn = MPCMD_NEXTMTN_GA;		// ������͐L�k��1(�n���h1)�Ń��[�N���蓮��
	if( Fork == MPCMD_FORK_B ){
		nextMtn = MPCMD_NEXTMTN_GB;	// ������͐L�k��2(�n���h2)�Ń��[�N���蓮��
	}

	r = SendManipulator_MTRS( UNIT_MANIPULATOR, TrsSt, SlotNo, nextMtn, MPCMD_POSTURE_A, anData, fnData, false );	// �J�Z�b�g���烏�[�N�����o�����߂̑ҋ@�ʒu�ړ�
	if( r != ErrNone ){
		return r;
	}

//TRACE( "Send MTRS Command To Manipurator for Get from Cassette\n" );

	r = SendManipulator_MGET( UNIT_MANIPULATOR, anData, fnData, false );		// �J�Z�b�g���烏�[�N�����o��
	if( r != ErrNone ){
		return r;
	}

//TRACE( "Send MGET Command To Manipurator\n" );

	nextMtn = MPCMD_NEXTMTN_PA;		// ������͐L�k��1(�n���h1)�Ń��[�N��n������
	if( Fork == MPCMD_FORK_B ){
		nextMtn = MPCMD_NEXTMTN_PB;	// ������͐L�k��2(�n���h2)�Ń��[�N��n������
	}

	r = SendManipulator_MTRS( UNIT_MANIPULATOR, MPCMD_TRSST_P1, 0, nextMtn, MPCMD_POSTURE_A, anData, fnData, false );	// ���[�N���v���A���C�i�[�֓n�����߂̑ҋ@�ʒu�ړ�
	if( r != ErrNone ){
		return r;
	}

//TRACE( "Send MTRS Command To Manipurator for Put to Prealigner\n" );

	nextMtn = MPCMD_NEXTMTN_AL;		// ������̓A���C�����g����
	r = SendManipulator_MTRS( UNIT_PREALIGNER, MPCMD_TRSST_GP, 0, nextMtn, MPCMD_POSTURE_A, anData, fnData, false );		// �v���A���C�i�[�����[�N���󂯎�邽�߂̑ҋ@�ʒu�ړ�
	if( r != ErrNone ){
		return r;
	}

//TRACE( "Send MTRS Command To Prealigner\n" );

	r = SendManipulator_MPUT( UNIT_MANIPULATOR, anData, fnData, false );		// ���[�N���v���A���C�i�[��֒u��
	if( r != ErrNone ){
		return r;
	}

//TRACE( "Send MPUT Command To Manipurator\n" );

	r = SendManipulator_CSOL( UNIT_PREALIGNER, MPCMD_FORK_A, MPCMD_CHUCK_ON, anData, fnData, false );
	if( r != ErrNone ){
		return r;
	}

//TRACE( "Send CSOL Command To Prealigner (Vacume On)\n" );

	r = SendManipulator_MTRS( UNIT_PREALIGNER, MPCMD_TRSST_R3, 0, MPCMD_NEXTMTN_AL, MPCMD_POSTURE_A, anData, fnData, false );		// �v���A���C�i�[�����[�N���󂯎�邽�߂̑ҋ@�ʒu�ړ�

//TRACE( "Send MTRS Command To Prealigner\n" );


	return r;
}

// �쓮�R�}���h
	// ���j�b�g������
int CManipulatorComm::SendManipulator_INIT( int unit, int Imode, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	if( !CheckParaInitMode( Imode ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.init.IMode = Imode;

	MakeCommandString( unit, Cmd_INIT, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_INIT, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_INIT, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// HOME �ʒu�ړ�
int CManipulatorComm::SendManipulator_MHOM( int unit, int Mmode, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )								// HOME �ʒu�ړ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	if( Mmode != MPCMD_MMODE_F &&
		Mmode != MPCMD_MMODE_A ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mhom.MMode = Mmode;

	MakeCommandString( unit, Cmd_MHOM, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MHOM, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MHOM, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �ҋ@�ʒu�ړ�
int CManipulatorComm::SendManipulator_MTRS( int unit, int TrsSt, int SlotNo, int NextMtn, int Posture,																	// �ҋ@�ʒu�ړ�
									struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaNextMtn( NextMtn ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtrs.TrsSt = TrsSt;
	para.mtrs.SlotNo = SlotNo;
	para.mtrs.NextMtn = NextMtn;
	para.mtrs.Posture = Posture;

	MakeCommandString( unit, Cmd_MTRS, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTRS, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTRS, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���[�N���蓮��
int CManipulatorComm::SendManipulator_MGET( int unit, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )											// ���[�N���蓮��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_MGET, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MGET, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MGET, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���[�N��n������
int CManipulatorComm::SendManipulator_MPUT( int unit, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )											// ���[�N��n������
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_MPUT, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MPUT, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MPUT, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���[�N���ւ�����
int CManipulatorComm::SendManipulator_MEXG( int unit, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )											// ���[�N���ւ�����
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_MEXG, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MEXG, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MEXG, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �����|�C���g�ԓ���
int CManipulatorComm::SendManipulator_MPNT( int unit, int TrsPnt, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )								// �����|�C���g�ԓ���
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsPnt( TrsPnt ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mpnt.TrsPnt = TrsPnt;

	MakeCommandString( unit, Cmd_MPNT, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MPNT, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MPNT, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �ҋ@�ʒu�ړ��y�у��[�N���蓮��
int CManipulatorComm::SendManipulator_MTRG( int unit, int TrsSt, int SlotNo, int MtnMode, int Posture,																	// �ҋ@�ʒu�ړ��y�у��[�N���蓮��
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMtnMode( MtnMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtrg.TrsSt = TrsSt;
	para.mtrg.SlotNo = SlotNo;
	para.mtrg.MtnMode = MtnMode;
	para.mtrg.Posture = Posture;

	MakeCommandString( unit, Cmd_MTRG, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTRG, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTRG, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �ҋ@�ʒu�ړ��y�у��[�N��n������
int CManipulatorComm::SendManipulator_MTRP( int unit, int TrsSt, int SlotNo, int MtnMode, int Posture,																	// �ҋ@�ʒu�ړ��y�у��[�N��n������
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMtnMode( MtnMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtrp.TrsSt = TrsSt;
	para.mtrp.SlotNo = SlotNo;
	para.mtrp.MtnMode = MtnMode;
	para.mtrp.Posture = Posture;

	MakeCommandString( unit, Cmd_MTRP, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTRP, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTRP, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �ҋ@�ʒu�ړ��y�у��[�N���ւ�����
int CManipulatorComm::SendManipulator_MTRE( int unit, int TrsSt, int SlotNo, int MtnMode, int Posture,																	// �ҋ@�ʒu�ړ��y�у��[�N���ւ�����
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMtnMode( MtnMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtre.TrsSt = TrsSt;
	para.mtre.SlotNo = SlotNo;
	para.mtre.MtnMode = MtnMode;
	para.mtre.Posture = Posture;

	MakeCommandString( unit, Cmd_MTRE, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTRE, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTRE, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �ҋ@�ʒu�ړ��y�є����|�C���g�ԓ���
int CManipulatorComm::SendManipulator_MTPT( int unit, int TrsSt, int SlotNo, int NextMtn, int Posture, int TrsPnt,														// �ҋ@�ʒu�ړ��y�є����|�C���g�ԓ���
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaNextMtn( NextMtn ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsPnt( TrsPnt ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtpt.TrsSt = TrsSt;
	para.mtpt.SlotNo = SlotNo;
	para.mtpt.NextMtn = NextMtn;
	para.mtpt.Posture = Posture;
	para.mtpt.TrsPnt = TrsPnt;

	MakeCommandString( unit, Cmd_MTPT, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTPT, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTPT, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �␳�@�\�t���ҋ@�ʒu�ړ�
int CManipulatorComm::SendManipulator_MTRO( int unit, int TrsSt, int SlotNo, int NextMtn, int Posture, long OffsetX, long OffsetY, long OffsetZ,							// �␳�@�\�t���ҋ@�ʒu�ړ�
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaNextMtn( NextMtn ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}
	if( OffsetX < -9999 || OffsetX > 99999 ){
		r = ErrParameter;
		return r;
	}
	if( OffsetY < -9999 || OffsetY > 99999 ){
		r = ErrParameter;
		return r;
	}
	if( OffsetZ < -9999 || OffsetZ > 99999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtro.TrsSt = TrsSt;
	para.mtro.SlotNo = SlotNo;
	para.mtro.NextMtn = NextMtn;
	para.mtro.Posture = Posture;
	para.mtro.OffsetX = OffsetX;
	para.mtro.OffsetY = OffsetY;
	para.mtro.OffsetZ = OffsetZ;

	MakeCommandString( unit, Cmd_MTRO, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTRO, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTRO, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �␳�@�\�t���ҋ@�ʒu�ړ��{���[�N���蓮��
int CManipulatorComm::SendManipulator_MTGO( int unit, int TrsSt, int SlotNo, int MtnMode, int Posture, long OffsetX, long OffsetY, long OffsetZ,							// �␳�@�\�t���ҋ@�ʒu�ړ��{���[�N���蓮��
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMtnMode( MtnMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}
	if( OffsetX < -9999 || OffsetX > 99999 ){
		r = ErrParameter;
		return r;
	}
	if( OffsetY < -9999 || OffsetY > 99999 ){
		r = ErrParameter;
		return r;
	}
	if( OffsetZ < -9999 || OffsetZ > 99999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtgo.TrsSt = TrsSt;
	para.mtgo.SlotNo = SlotNo;
	para.mtgo.MtnMode = MtnMode;
	para.mtgo.Posture = Posture;
	para.mtgo.OffsetX = OffsetX;
	para.mtgo.OffsetY = OffsetY;
	para.mtgo.OffsetZ = OffsetZ;

	MakeCommandString( unit, Cmd_MTGO, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTGO, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTGO, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �␳�@�\�t���ҋ@�ʒu�ړ��{���[�N��n������
int CManipulatorComm::SendManipulator_MTPO( int unit, int TrsSt, int SlotNo, int MtnMode, int Posture, long OffsetX, long OffsetY, long OffsetZ,							// �␳�@�\�t���ҋ@�ʒu�ړ��{���[�N��n������
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMtnMode( MtnMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}
	if( OffsetX < -9999 || OffsetX > 99999 ){
		r = ErrParameter;
		return r;
	}
	if( OffsetY < -9999 || OffsetY > 99999 ){
		r = ErrParameter;
		return r;
	}
	if( OffsetZ < -9999 || OffsetZ > 99999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtpo.TrsSt = TrsSt;
	para.mtpo.SlotNo = SlotNo;
	para.mtpo.MtnMode = MtnMode;
	para.mtpo.Posture = Posture;
	para.mtpo.OffsetX = OffsetX;
	para.mtpo.OffsetY = OffsetY;
	para.mtpo.OffsetZ = OffsetZ;

	MakeCommandString( unit, Cmd_MTPO, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTPO, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTPO, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �␳�@�\�t���ҋ@�ʒu�ړ��{�����|�C���g�ԓ���
int CManipulatorComm::SendManipulator_MTTO( int unit, int TrsSt, int SlotNo, int MtnMode, int Posture, int TrsPnt, long OffsetX, long OffsetY, long OffsetZ,				// �␳�@�\�t���ҋ@�ʒu�ړ��{�����|�C���g�ԓ���
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMtnMode( MtnMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsPnt( TrsPnt ) ){
		r = ErrParameter;
		return r;
	}
	if( OffsetX < -9999 || OffsetX > 99999 ){
		r = ErrParameter;
		return r;
	}
	if( OffsetY < -9999 || OffsetY > 99999 ){
		r = ErrParameter;
		return r;
	}
	if( OffsetZ < -9999 || OffsetZ > 99999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtto.TrsSt = TrsSt;
	para.mtto.SlotNo = SlotNo;
	para.mtto.MtnMode = MtnMode;
	para.mtto.Posture = Posture;
	para.mtto.TrsPnt = TrsPnt;
	para.mtto.OffsetX = OffsetX;
	para.mtto.OffsetY = OffsetY;
	para.mtto.OffsetZ = OffsetZ;

	MakeCommandString( unit, Cmd_MTTO, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTTO, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTTO, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �}�b�s���O����
int CManipulatorComm::SendManipulator_MMAP( int unit, int TrsSt, int SlotNo, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )					// �}�b�s���O����
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mmap.TrsSt = TrsSt;
	para.mmap.SlotNo = SlotNo;

	MakeCommandString( unit, Cmd_MMAP, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MMAP, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MMAP, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �A���C�����g����
//int CManipulatorComm::SendManipulator_MALN( int unit, int TUNo, int TrsSt, int Angle, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )			// �A���C�����g����
int CManipulatorComm::SendManipulator_MALN( int unit, int TUNo, int Angle, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )			// �A���C�����g����
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( TUNo != UNIT_MANIPULATOR && TUNo != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
//	if( !CheckParaTrsSt( TrsSt ) ){
//		r = ErrParameter;
//		return r;
//	}
	if( !CheckParaAngle( Angle ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.maln.TUNo = TUNo;
//	para.maln.TrsSt = TrsSt;
	para.maln.Angle = Angle;

	MakeCommandString( unit, Cmd_MALN, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MALN, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MALN, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �o�^�ʒu����
int CManipulatorComm::SendManipulator_MTCH( int unit, int Fork, int TrsSt, int PMode, int Posture, long ZOffset, long ROffset,											// �o�^�ʒu����
								struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPMode( PMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}
	if( ZOffset < -9999999 || ZOffset > 99999999 ){
		r = ErrParameter;
		return r;
	}
	if( ROffset < -9999999 || ROffset > 99999999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mtch.Fork = Fork;
	para.mtch.TrsSt = TrsSt;
	para.mtch.PMode = PMode;
	para.mtch.Posture = Posture;
	para.mtch.ZOffset = ZOffset;
	para.mtch.ROffset = ROffset;

	MakeCommandString( unit, Cmd_MTCH, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MTCH, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MTCH, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���W�ʒu�w�蓮��
int CManipulatorComm::SendManipulator_MABS( int unit, int Axis, int Mode, long Value, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )			// ���W�ʒu�w�蓮��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaAxis( Axis ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaWristMode( Mode ) ){
		r = ErrParameter;
		return r;
	}
	if( Value < -9999999 || Value > 99999999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mabs.Axis = Axis;
	para.mabs.Mode = Mode;
	para.mabs.Value = Value;

	MakeCommandString( unit, Cmd_MABS, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MABS, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MABS, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���Ηʎw�蓮��
int CManipulatorComm::SendManipulator_MREL( int unit, int Axis, int Mode, long Value, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )			// ���Ηʎw�蓮��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaAxis( Axis ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaWristMode( Mode ) ){
		r = ErrParameter;
		return r;
	}
	if( Value < -9999999 || Value > 99999999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mrel.Axis = Axis;
	para.mrel.Mode = Mode;
	para.mrel.Value = Value;

	MakeCommandString( unit, Cmd_MREL, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MREL, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MREL, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �}�b�s���O�L�����u���[�V��������
int CManipulatorComm::SendManipulator_MMCA( int unit, int TrsSt, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )								// �}�b�s���O�L�����u���[�V��������
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.mmca.TrsSt = TrsSt;

	MakeCommandString( unit, Cmd_MMCA, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MMCA, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MMCA, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �A���C�����g�L�����u���[�V��������
//int CManipulatorComm::SendManipulator_MACA( int unit, int TUNo, int TrsSt, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )					// �A���C�����g�L�����u���[�V��������
int CManipulatorComm::SendManipulator_MACA( int unit, int TUNo, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )					// �A���C�����g�L�����u���[�V��������
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( TUNo != UNIT_MANIPULATOR && TUNo != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
//	if( !CheckParaTrsSt( TrsSt ) ){
//		r = ErrParameter;
//		return r;
//	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.maca.TUNo = TUNo;
//	para.maca.TrsSt = TrsSt;

	MakeCommandString( unit, Cmd_MACA, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MACA, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MACA, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �A���C�����g�ʒu�␳����
//int CManipulatorComm::SendManipulator_MADJ( int unit, int TUNo, int TrsSt, int Angle, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )			// �A���C�����g�ʒu�␳����
int CManipulatorComm::SendManipulator_MADJ( int unit, int TUNo, int Angle, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )			// �A���C�����g�ʒu�␳����
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

	CSingleLock	S( &eventFINISH );

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( TUNo != UNIT_MANIPULATOR && TUNo != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
//	if( !CheckParaTrsSt( TrsSt ) ){
//		r = ErrParameter;
//		return r;
//	}
	if( !CheckParaAngle( Angle ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.madj.TUNo = TUNo;
//	para.madj.TrsSt = TrsSt;
	para.madj.Angle = Angle;

	MakeCommandString( unit, Cmd_MADJ, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
		br = SetEventAndObjectForCommandFinish( unit, Cmd_MADJ, &eventFINISH, fnData );
	}

	r = SendReply( unit, Cmd_MADJ, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

// ����R�}���h
	// ����̒��f(������~)
int CManipulatorComm::SendManipulator_CHLT( int unit, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )											// ����̒��f(������~)
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );
	CSingleLock	S( &eventFINISHC );		// 2011.11.30 CXXX�p�ɕ�Event���g�p

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_CHLT, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CHLT, &eventFINISH, fnData );
		br = SetEventAndObjectForCommandFinish( unit, Cmd_CHLT, &eventFINISHC, fnData );		// 2011.11.30 CXXX�p�ɕ�Event���g�p
	}

	r = SendReply( unit, Cmd_CHLT, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���f����̍ĊJ
int CManipulatorComm::SendManipulator_CRSM( int unit, struct MP_ANSWERDATA* anData )											// ���f����̍ĊJ
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_CRSM, CommandLine, &para );

//	if( execute == 0 ){			// �����҂�
//		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CRSM, &eventFINISH, fnData );
//	}

	r = SendReply( unit, Cmd_CRSM, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
//	if( execute == 1 ){			// �쓮�̂�
//		return 0;
//	}
//
//	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
//	S.Unlock();
//
//	if( br == 0 ){		// Time Out
//		r = ErrETimeOut;
//	} else {
//		r = fnData->errCode;
//	}

	return r;
}

	// �ً}��~(������~�A�T�[�{OFF)
int CManipulatorComm::SendManipulator_CEMG( int unit, struct MP_ANSWERDATA* anData )											// �ً}��~(������~�A�T�[�{OFF)
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_CEMG, CommandLine, &para );

//	if( execute == 0 ){			// �����҂�
//		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CEMG, &eventFINISH, fnData );
//	}

	r = SendReply( unit, Cmd_CEMG, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
//	if( execute == 1 ){			// �쓮�̂�
//		return 0;
//	}
//
//	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
//	S.Unlock();
//
//	if( br == 0 ){		// Time Out
//		r = ErrETimeOut;
//	} else {
//		r = fnData->errCode;
//	}

	return r;
}

	// �T�[�{�w��
int CManipulatorComm::SendManipulator_CSRV( int unit, int Sw, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )									// �T�[�{�w��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );
	CSingleLock	S( &eventFINISHC );		// 2011.11.30 CXXX�p�ɕ�Event���g�p

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaServo( Sw ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.csrv.Sw = Sw;

	MakeCommandString( unit, Cmd_CSRV, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CSRV, &eventFINISH, fnData );
		br = SetEventAndObjectForCommandFinish( unit, Cmd_CSRV, &eventFINISHC, fnData );		// 2011.11.30 CXXX�p�ɕ�Event���g�p
	}
#if !Release
//	TRACE("SendManipulator_CSRV()SendReply Start\n");
#endif

	r = SendReply( unit, Cmd_CSRV, CommandLine, anData );
#if !Release
//	TRACE("SendManipulator_CSRV()SendReply End\n");
#endif

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();
#if !Release
//	TRACE("SendManipulator_CSRV()Finished End\n");
#endif

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �G���[����(�N���A)
int CManipulatorComm::SendManipulator_CCLR( int unit, int Cmode, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )								// �G���[����(�N���A)
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );
	CSingleLock	S( &eventFINISHC );		// 2011.11.30 CXXX�p�ɕ�Event���g�p

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaClear( Cmode ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.cclr.CMode = Cmode;

	MakeCommandString( unit, Cmd_CCLR, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CCLR, &eventFINISH, fnData );
		br = SetEventAndObjectForCommandFinish( unit, Cmd_CCLR, &eventFINISHC, fnData );		// 2011.11.30 CXXX�p�ɕ�Event���g�p
	}

	r = SendReply( unit, Cmd_CCLR, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���[�N�̃`���b�L���O�w��
int CManipulatorComm::SendManipulator_CSOL( int unit, int Fork, int Sw, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )						// ���[�N�̃`���b�L���O�w��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );
	CSingleLock	S( &eventFINISHC );		// 2011.11.30 CXXX�p�ɕ�Event���g�p

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaChuck( Sw ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.csol.Fork = Fork;
	para.csol.Sw = Sw;

	MakeCommandString( unit, Cmd_CSOL, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CSOL, &eventFINISH, fnData );
		br = SetEventAndObjectForCommandFinish( unit, Cmd_CSOL, &eventFINISHC, fnData );		// 2011.11.30 CXXX�p�ɕ�Event���g�p
	}

	r = SendReply( unit, Cmd_CSOL, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���t�^����
int CManipulatorComm::SendManipulator_CLFT( int unit, int Sw, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )									// ���t�^����
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );
	CSingleLock	S( &eventFINISHC );		// 2011.11.30 CXXX�p�ɕ�Event���g�p

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaLift( Sw ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.clft.Sw = Sw;

	MakeCommandString( unit, Cmd_CLFT, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CLFT, &eventFINISH, fnData );
		br = SetEventAndObjectForCommandFinish( unit, Cmd_CLFT, &eventFINISHC, fnData );		// 2011.11.30 CXXX�p�ɕ�Event���g�p
	}

	r = SendReply( unit, Cmd_CLFT, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// ���[�N�̃`���b�L���O�w��(�����Ď��L��)
int CManipulatorComm::SendManipulator_CCHK( int unit, int Fork, int Sw, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )						// ���[�N�̃`���b�L���O�w��(�����Ď��L��)
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );
	CSingleLock	S( &eventFINISHC );		// 2011.11.30 CXXX�p�ɕ�Event���g�p

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaChuck( Sw ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.cchk.Fork = Fork;
	para.cchk.Sw = Sw;

	MakeCommandString( unit, Cmd_CCHK, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CCHK, &eventFINISH, fnData );
		br = SetEventAndObjectForCommandFinish( unit, Cmd_CCHK, &eventFINISHC, fnData );		// 2011.11.30 CXXX�p�ɕ�Event���g�p
	}

	r = SendReply( unit, Cmd_CCHK, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}

	// �`���b�L���O���쎞�Ԍv��
int CManipulatorComm::SendManipulator_CCTM( int unit, int Fork, int Sw, struct MP_ANSWERDATA* anData, struct MP_FINISHDATA* fnData, bool execute )						// �`���b�L���O���쎞�Ԍv��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );
	CSingleLock	S( &eventFINISHC );		// 2011.11.30 CXXX�p�ɕ�Event���g�p

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaChuckTime( Sw ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.cctm.Fork = Fork;
	para.cctm.Sw = Sw;

	MakeCommandString( unit, Cmd_CCTM, CommandLine, &para );

	if( execute == 0 ){			// �����҂�
		bool br;
//		br = SetEventAndObjectForCommandFinish( unit, Cmd_CCTM, &eventFINISH, fnData );
		br = SetEventAndObjectForCommandFinish( unit, Cmd_CCTM, &eventFINISHC, fnData );		// 2011.11.30 CXXX�p�ɕ�Event���g�p
	}

	r = SendReply( unit, Cmd_CCTM, CommandLine, anData );

	if( r != Err0x0000 ){		// ���s���ł͂Ȃ�(�G���[�݂�)
		return r;
	}
	if( execute == 1 ){			// �쓮�̂�
		return 0;
	}

	BOOL br = S.Lock( MP_EVENT_TIMEOUT );
	S.Unlock();

	if( br == 0 ){		// Time Out
		r = ErrETimeOut;
	} else {
		r = fnData->errCode;
	}

	return r;
}


// �ݒ�R�}���h
	// ���쑬�x�ݒ�
int CManipulatorComm::SendManipulator_SSPD( int unit, int Axis, int SMode, int Value, struct MP_ANSWERDATA* anData )														// ���쑬�x�ݒ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaAxis( Axis ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSpeedMode( SMode ) ){
		r = ErrParameter;
		return r;
	}
	if( Value < 1 || Value > 999999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sspd.Axis = Axis;
	para.sspd.SMode = SMode;
	para.sspd.Value = Value;

	MakeCommandString( unit, Cmd_SSPD, CommandLine, &para );

	r = SendReply( unit, Cmd_SSPD, CommandLine, anData );

	return r;
}

	// ���쑬�x�ݒ�2([%]�w��)
int CManipulatorComm::SendManipulator_SSPP( int unit, int Axis, int SMode, int Value, struct MP_ANSWERDATA* anData )														// ���쑬�x�ݒ�2([%]�w��)
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaAxis( Axis ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSpeedMode( SMode ) ){
		r = ErrParameter;
		return r;
	}
	if( Value < 1 || Value > 1000 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sspp.Axis = Axis;
	para.sspp.SMode = SMode;
	para.sspp.Value = Value;

	MakeCommandString( unit, Cmd_SSPP, CommandLine, &para );


	r = SendReply( unit, Cmd_SSPP, CommandLine, anData );

	return r;
}

	// ���݈ʒu�o�^
int CManipulatorComm::SendManipulator_SPOS( int unit, int Mem, int RMode, int TrsSt, int Fork, int Posture, struct MP_ANSWERDATA* anData )								// ���݈ʒu�o�^
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMemory( Mem ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaRegistMode( RMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.spos.Mem = Mem;
	para.spos.RMode = RMode;
	para.spos.TrsSt = TrsSt;
	para.spos.Fork = Fork;
	para.spos.Posture = Posture;

	MakeCommandString( unit, Cmd_SPOS, CommandLine, &para );


	r = SendReply( unit, Cmd_SPOS, CommandLine, anData );

	return r;
}

	// ���W�ʒu�o�^
int CManipulatorComm::SendManipulator_SABS( int unit, int Mem, int RMode, int TrsSt, int Fork, int Posture, long Value1, long Value2, long Value3,						// ���W�ʒu�o�^
													long Value4, long Value5, long Value6, struct MP_ANSWERDATA* anData )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMemory( Mem ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaRegistMode( RMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}
	if( Value1 < -9999999 || Value1 > 99999999 ){
		r = ErrParameter;
		return r;
	}
	if( Value2 < -9999999 || Value2 > 99999999 ){
		r = ErrParameter;
		return r;
	}
	if( Value3 < -9999999 || Value3 > 99999999 ){
		r = ErrParameter;
		return r;
	}
	if( Value4 < -9999999 || Value4 > 99999999 ){
		r = ErrParameter;
		return r;
	}
	if( Value5 < -9999999 || Value5 > 99999999 ){
		r = ErrParameter;
		return r;
	}
	if( Value6 < -9999999 || Value6 > 99999999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sabs.Mem = Mem;
	para.sabs.RMode = RMode;
	para.sabs.TrsSt = TrsSt;
	para.sabs.Fork = Fork;
	para.sabs.Posture = Posture;
	para.sabs.Value1 = Value1;
	para.sabs.Value2 = Value2;
	para.sabs.Value3 = Value3;
	para.sabs.Value4 = Value4;
	para.sabs.Value5 = Value5;
	para.sabs.Value6 = Value6;

	MakeCommandString( unit, Cmd_SABS, CommandLine, &para );


	r = SendReply( unit, Cmd_SABS, CommandLine, anData );

	return r;
}

	// �ʒu�f�[�^�̃Z�[�u
int CManipulatorComm::SendManipulator_SPSV( int unit, int TrsSt, int Fork, struct MP_ANSWERDATA* anData )																// �ʒu�f�[�^�̃Z�[�u
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
// "FF"�Œ�̂��ߔ��肵�Ȃ�
//	if( !CheckParaTrsSt( TrsSt ) ){
//		r = ErrParameter;
//		return r;
//	}
//	if( !CheckParaFork( Fork ) ){
//		r = ErrParameter;
//		return r;
//	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.spsv.TrsSt = TrsSt;
	para.spsv.Fork = Fork;

	MakeCommandString( unit, Cmd_SPSV, CommandLine, &para );


	r = SendReply( unit, Cmd_SPSV, CommandLine, anData );

	return r;
}

	// �����I�t�Z�b�g�ݒ�
int CManipulatorComm::SendManipulator_SOFS( int unit, int Mem, int TrsSt, long Offset1, long Offset2, long Offset3, long Offset4, long Offset5,							// �����I�t�Z�b�g�ݒ�
																							struct MP_ANSWERDATA* anData )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMemory( Mem ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( Offset1 < -999 || Offset1 > 9999 ){
		r = ErrParameter;
		return r;
	}
	if( Offset2 < -999 || Offset2 > 9999 ){
		r = ErrParameter;
		return r;
	}
	if( Offset3 < -999 || Offset3 > 9999 ){
		r = ErrParameter;
		return r;
	}
	if( Offset4 < -999 || Offset4 > 9999 ){
		r = ErrParameter;
		return r;
	}
	if( Offset5 < -999 || Offset5 > 9999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sofs.Mem = Mem;
	para.sofs.TrsSt = TrsSt;
	para.sofs.Offset1 = Offset1;
	para.sofs.Offset2 = Offset2;
	para.sofs.Offset3 = Offset3;
	para.sofs.Offset4 = Offset4;
	para.sofs.Offset5 = Offset5;

	MakeCommandString( unit, Cmd_SOFS, CommandLine, &para );


	r = SendReply( unit, Cmd_SOFS, CommandLine, anData );

	return r;
}

	// �X���b�g�ԃs�b�`�����������[�h�ݒ�
int CManipulatorComm::SendManipulator_SMOD( int unit, int Mem, int TrsSt, int Mode, struct MP_ANSWERDATA* anData )														// �X���b�g�ԃs�b�`�����������[�h�ݒ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMemory( Mem ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotPitchMode( Mode ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.smod.Mem = Mem;
	para.smod.TrsSt = TrsSt;
	para.smod.Mode = Mode;

	MakeCommandString( unit, Cmd_SMOD, CommandLine, &para );


	r = SendReply( unit, Cmd_SMOD, CommandLine, anData );

	return r;
}

	// �X���b�g�ԃs�b�`�ݒ�
int CManipulatorComm::SendManipulator_SPIT( int unit, int Mem, int TrsSt, int Value, struct MP_ANSWERDATA* anData )														// �X���b�g�ԃs�b�`�ݒ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMemory( Mem ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( Value < 0 || Value > 999999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.spit.Mem = Mem;
	para.spit.TrsSt = TrsSt;
	para.spit.Value = Value;

	MakeCommandString( unit, Cmd_SPIT, CommandLine, &para );


	r = SendReply( unit, Cmd_SPIT, CommandLine, anData );

	return r;
}

	// �X���b�g���ݒ�
int CManipulatorComm::SendManipulator_SSLT( int unit, int Mem, int TrsSt, int SlotNo, struct MP_ANSWERDATA* anData )														// �X���b�g���ݒ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMemory( Mem ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sslt.Mem = Mem;
	para.sslt.TrsSt = TrsSt;
	para.sslt.SlotNo = SlotNo;

	MakeCommandString( unit, Cmd_SSLT, CommandLine, &para );


	r = SendReply( unit, Cmd_SSLT, CommandLine, anData );

	return r;
}

	// �p�����[�^�̃Z�[�u
int CManipulatorComm::SendManipulator_SRSV( int unit, int PrmNo, int TrsSt, struct MP_ANSWERDATA* anData )																// �p�����[�^�̃Z�[�u
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
//	"FF"�Œ�̂��ߔ��肵�Ȃ�
//	if( !CheckParaKindOfPara( PrmNo ) ){
//		r = ErrParameter;
//		return r;
//	}
//	if( !CheckParaTrsSt( TrsSt ) ){
//		r = ErrParameter;
//		return r;
//	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.srsv.PrmNo = PrmNo;
	para.srsv.TrsSt = TrsSt;

	MakeCommandString( unit, Cmd_SRSV, CommandLine, &para );


	r = SendReply( unit, Cmd_SRSV, CommandLine, anData );

	return r;
}

	// �C���^�[���b�N�Ď��L��/�����ݒ�
int CManipulatorComm::SendManipulator_SMSK( int unit, unsigned char Valid1, unsigned char Valid2, unsigned char Valid3, unsigned char Valid4,								// �C���^�[���b�N�Ď��L��/�����ݒ�
																							struct MP_ANSWERDATA* anData )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.smsk.Valid1 = Valid1;
	para.smsk.Valid2 = Valid2;
	para.smsk.Valid3 = Valid3;
	para.smsk.Valid4 = Valid4;

	MakeCommandString( unit, Cmd_SMSK, CommandLine, &para );


	r = SendReply( unit, Cmd_SMSK, CommandLine, anData );

	return r;
}

	// �V�X�e���^�C�v�ݒ�
int CManipulatorComm::SendManipulator_STYP( int unit, int Type, struct MP_ANSWERDATA* anData )																			// �V�X�e���^�C�v�ݒ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSystemType( Type ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.styp.Type = Type;

	MakeCommandString( unit, Cmd_STYP, CommandLine, &para );


	r = SendReply( unit, Cmd_STYP, CommandLine, anData );

	return r;
}

	// �����X�e�[�V�����^�C�v�ݒ�
int CManipulatorComm::SendManipulator_SSTT( int unit, int TrsSt, int Type, struct MP_ANSWERDATA* anData )																// �����X�e�[�V�����^�C�v�ݒ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( Type < 1 || Type > 4 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sstt.TrsSt = TrsSt;
	para.sstt.Type = Type;

	MakeCommandString( unit, Cmd_SSTT, CommandLine, &para );


	r = SendReply( unit, Cmd_SSTT, CommandLine, anData );

	return r;
}

	// �������x���x���ݒ�
int CManipulatorComm::SendManipulator_SSLV( int unit, int Level, struct MP_ANSWERDATA* anData )																			// �������x���x���ݒ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrSpeedLevel( Level ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sslv.Level = Level;

	MakeCommandString( unit, Cmd_SSLV, CommandLine, &para );


	r = SendReply( unit, Cmd_SSLV, CommandLine, anData );

	return r;
}

	// �o�͐M���ݒ�R�}���h
int CManipulatorComm::SendManipulator_SIOS( int unit, unsigned char Data1, unsigned char Data2, unsigned char Data3, unsigned char Data4,									// �o�͐M���ݒ�R�}���h
																							struct MP_ANSWERDATA* anData )
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sios.Data1 = Data1;
	para.sios.Data2 = Data2;
	para.sios.Data3 = Data3;
	para.sios.Data4 = Data4;

	MakeCommandString( unit, Cmd_SIOS, CommandLine, &para );


	r = SendReply( unit, Cmd_SIOS, CommandLine, anData );

	return r;
}

	// �o�^�ʒu�X�V
int CManipulatorComm::SendManipulator_SPUD( int unit, int UMode, int TrsSt, int Fork, int Posture, struct MP_ANSWERDATA* anData )										// �o�^�ʒu�X�V
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaUpdateMode( UMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.spud.UMode = UMode;
	para.spud.TrsSt = TrsSt;
	para.spud.Fork = Fork;
	para.spud.Posture = Posture;

	MakeCommandString( unit, Cmd_SPUD, CommandLine, &para );


	r = SendReply( unit, Cmd_SPUD, CommandLine, anData );

	return r;
}

	// �p�����[�^�ݒ�
int CManipulatorComm::SendManipulator_SPRM( int unit, int Type, int PrmNo, double Value, struct MP_ANSWERDATA* anData )													// �p�����[�^�ݒ�
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaKindOfPara( Type ) ){
		r = ErrParameter;
		return r;
	}
	if( PrmNo < 0 || PrmNo > 9999 ){
		r = ErrParameter;
		return r;
	}
	if( Value < -99999999999.0 || Value > 999999999999.0 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sprm.Type = Type;
	para.sprm.PrmNo = PrmNo;
	para.sprm.Value = Value;

	MakeCommandString( unit, Cmd_SPRM, CommandLine, &para );


	r = SendReply( unit, Cmd_SPRM, CommandLine, anData );

	return r;
}

	// ��ʒu�o�^
int CManipulatorComm::SendManipulator_SSTD( int unit, int Axis, struct MP_ANSWERDATA* anData )																			// ��ʒu�o�^
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaAxis( Axis ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sstd.Axis = Axis;

	MakeCommandString( unit, Cmd_SSTD, CommandLine, &para );


	r = SendReply( unit, Cmd_SSTD, CommandLine, anData );

	return r;
}

	// ��ʒu�o�^(���l�w��)
int CManipulatorComm::SendManipulator_SSTN( int unit, double Value1, double Value2, double Value3, double Value4, double Value5, double Value6, struct MP_ANSWERDATA* anData )				// ��ʒu�o�^(���l�w��)
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( Value1 < -99999999999.0 || Value1 > 999999999999.0 ){
		r = ErrParameter;
		return r;
	}
	if( Value2 < -99999999999.0 || Value2 > 999999999999.0 ){
		r = ErrParameter;
		return r;
	}
	if( Value3 < -99999999999.0 || Value3 > 999999999999.0 ){
		r = ErrParameter;
		return r;
	}
	if( Value4 < -99999999999.0 || Value4 > 999999999999.0 ){
		r = ErrParameter;
		return r;
	}
	if( Value5 < -99999999999.0 || Value5 > 999999999999.0 ){
		r = ErrParameter;
		return r;
	}
	if( Value6 < -99999999999.0 || Value6 > 999999999999.0 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.sstn.Value1 = Value1;
	para.sstn.Value2 = Value2;
	para.sstn.Value3 = Value3;
	para.sstn.Value4 = Value4;
	para.sstn.Value5 = Value5;
	para.sstn.Value6 = Value6;

	MakeCommandString( unit, Cmd_SSTN, CommandLine, &para );


	r = SendReply( unit, Cmd_SSTN, CommandLine, anData );

	return r;
}

	// �J�����_�[�ݒ�
int CManipulatorComm::SendManipulator_SCAL( int unit, int Year, int Mon, int Day, int Hour, int Min, int Sec, struct MP_ANSWERDATA* anData )								// �J�����_�[�ݒ�

{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( Year < 2000 || Year > 2100 ){
		r = ErrParameter;
		return r;
	}
	if( Mon < 1 || Mon > 12 ){
		r = ErrParameter;
		return r;
	}
	if( Day < 1 || Day > 31 ){
		r = ErrParameter;
		return r;
	}
	if( Hour < 0 || Hour > 23 ){
		r = ErrParameter;
		return r;
	}
	if( Min < 0 || Min > 59 ){
		r = ErrParameter;
		return r;
	}
	if( Sec < 0 || Sec > 59 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.scal.Year = Year;
	para.scal.Mon = Mon;
	para.scal.Day = Day;
	para.scal.Hour = Hour;
	para.scal.Min = Min;
	para.scal.Sec = Sec;

	MakeCommandString( unit, Cmd_SCAL, CommandLine, &para );


	r = SendReply( unit, Cmd_SCAL, CommandLine, anData );

	return r;
}

// �Q�ƃR�}���h
	// ���쑬�x�Q��
int CManipulatorComm::SendManipulator_RSPD( int unit, int Axis, int SMode, struct MP_ANSWERDATA* anData )																// ���쑬�x�Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaAxis( Axis ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSpeedMode( SMode ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rspd.Axis = Axis;
	para.rspd.SMode = SMode;

	MakeCommandString( unit, Cmd_RSPD, CommandLine, &para );


	r = SendReply( unit, Cmd_RSPD, CommandLine, anData );

	return r;
}

	// ���쑬�x�Q��2([%]�Q��)
int CManipulatorComm::SendManipulator_RSPP( int unit, int Axis, int SMode, struct MP_ANSWERDATA* anData )																// ���쑬�x�Q��2([%]�Q��)
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaAxis( Axis ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSpeedMode( SMode ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rspp.Axis = Axis;
	para.rspp.SMode = SMode;

	MakeCommandString( unit, Cmd_RSPP, CommandLine, &para );


	r = SendReply( unit, Cmd_RSPP, CommandLine, anData );

	return r;
}

	// ���݈ʒu/�o�^�ʒu�Q��
int CManipulatorComm::SendManipulator_RPOS( int unit, int TrsSt, int Fork, int Posture, struct MP_ANSWERDATA* anData )													// ���݈ʒu/�o�^�ʒu�Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rpos.TrsSt = TrsSt;
	para.rpos.Fork = Fork;
	para.rpos.Posture = Posture;

	MakeCommandString( unit, Cmd_RPOS, CommandLine, &para );


	r = SendReply( unit, Cmd_RPOS, CommandLine, anData );

	return r;
}

	// �����I�t�Z�b�g�Q��
int CManipulatorComm::SendManipulator_ROFS( int unit, int TrsSt, struct MP_ANSWERDATA* anData )																			// �����I�t�Z�b�g�Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rofs.TrsSt = TrsSt;

	MakeCommandString( unit, Cmd_ROFS, CommandLine, &para );


	r = SendReply( unit, Cmd_ROFS, CommandLine, anData );

	return r;
}

	// �J�Z�b�g�X�e�[�W���Q��
int CManipulatorComm::SendManipulator_RCST( int unit, int TrsSt, struct MP_ANSWERDATA* anData )																			// �J�Z�b�g�X�e�[�W���Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rcst.TrsSt = TrsSt;

	MakeCommandString( unit, Cmd_RCST, CommandLine, &para );


	r = SendReply( unit, Cmd_RCST, CommandLine, anData );

	return r;
}

	// �}�b�s���O���ʎQ��
int CManipulatorComm::SendManipulator_RMAP( int unit, int TrsSt, int SlotNo, struct MP_ANSWERDATA* anData )																// �}�b�s���O���ʎQ��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaSlotNumber( SlotNo ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rmap.TrsSt = TrsSt;
	para.rmap.SlotNo = SlotNo;

	MakeCommandString( unit, Cmd_RMAP, CommandLine, &para );


	r = SendReply( unit, Cmd_RMAP, CommandLine, anData );

	return r;
}

	// �e���ԎQ��
int CManipulatorComm::SendManipulator_RSTS( int unit, struct MP_ANSWERDATA* anData )																						// �e���ԎQ��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RSTS, CommandLine, &para );


	r = SendReply( unit, Cmd_RSTS, CommandLine, anData );

	return r;
}

	// �G���[�����Q��
int CManipulatorComm::SendManipulator_RERR( int unit, struct MP_ANSWERDATA* anData )																						// �G���[�����Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RERR, CommandLine, &para );


	r = SendReply( unit, Cmd_RERR, CommandLine, anData );

	return r;
}

	// �^�C���X�^���v�t���G���[�����Q��
int CManipulatorComm::SendManipulator_RERT( int unit, int Mem, int HNo, struct MP_ANSWERDATA* anData )																	// �^�C���X�^���v�t���G���[�����Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaMemory( Mem ) ){
		r = ErrParameter;
		return r;
	}
	if( HNo < 0 || HNo > 127 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rert.Mem = Mem;
	para.rert.HNo = HNo;

	MakeCommandString( unit, Cmd_RERT, CommandLine, &para );


	r = SendReply( unit, Cmd_RERT, CommandLine, anData );

	return r;
}

	// �C���^�[���b�N�Ď����Q��
int CManipulatorComm::SendManipulator_RMSK( int unit, struct MP_ANSWERDATA* anData )																						// �C���^�[���b�N�Ď����Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RMSK, CommandLine, &para );


	r = SendReply( unit, Cmd_RMSK, CommandLine, anData );

	return r;
}

	// �V�X�e���^�C�v�Q��
int CManipulatorComm::SendManipulator_RTYP( int unit, struct MP_ANSWERDATA* anData )																						// �V�X�e���^�C�v�Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RTYP, CommandLine, &para );


	r = SendReply( unit, Cmd_RTYP, CommandLine, anData );

	return r;
}

	// �����X�e�[�V�����^�C�v�Q��
int CManipulatorComm::SendManipulator_RSTT( int unit, int TrsSt, struct MP_ANSWERDATA* anData )																			// �����X�e�[�V�����^�C�v�Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rstt.TrsSt = TrsSt;

	MakeCommandString( unit, Cmd_RSTT, CommandLine, &para );


	r = SendReply( unit, Cmd_RSTT, CommandLine, anData );

	return r;
}

	// �\�t�g�E�F�A�o�[�W�����Q��
int CManipulatorComm::SendManipulator_RVER( int unit, struct MP_ANSWERDATA* anData )																						// �\�t�g�E�F�A�o�[�W�����Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RVER, CommandLine, &para );


	r = SendReply( unit, Cmd_RVER, CommandLine, anData );

	return r;
}

	// �e�탂�f�����Q��
int CManipulatorComm::SendManipulator_RMDL( int unit, int MdlNo, struct MP_ANSWERDATA* anData )																			// �e�탂�f�����Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaModelNumber( MdlNo ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rmdl.MdlNo = MdlNo;

	MakeCommandString( unit, Cmd_RMDL, CommandLine, &para );


	r = SendReply( unit, Cmd_RMDL, CommandLine, anData );

	return r;
}

	// �e�탍�O���Q��
int CManipulatorComm::SendManipulator_RLOG( int unit, int LogNo, struct MP_ANSWERDATA* anData )																			// �e�탍�O���Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaLogNumber( LogNo ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rlog.LogNo = LogNo;

	MakeCommandString( unit, Cmd_RLOG, CommandLine, &para );


	r = SendReply( unit, Cmd_RLOG, CommandLine, anData );

	return r;
}

	// �A���C�����g���ʎQ��
int CManipulatorComm::SendManipulator_RALN( int unit, int TUNo, struct MP_ANSWERDATA* anData )																			// �A���C�����g���ʎQ��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( TUNo != UNIT_MANIPULATOR && TUNo != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.raln.TUNo = TUNo;

	MakeCommandString( unit, Cmd_RALN, CommandLine, &para );


	r = SendReply( unit, Cmd_RALN, CommandLine, anData );

	return r;
}

	// �������x���x���Q��
int CManipulatorComm::SendManipulator_RSLV( int unit, struct MP_ANSWERDATA* anData )																						// �������x���x���Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RSLV, CommandLine, &para );


	r = SendReply( unit, Cmd_RSLV, CommandLine, anData );

	return r;
}

	// �o�^�ʒu�̏ڍ׎Q��
int CManipulatorComm::SendManipulator_RSTP( int unit, int TrsSt, int PMode, int Fork, int Posture, struct MP_ANSWERDATA* anData )										// �o�^�ʒu�̏ڍ׎Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPMode( PMode ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaFork( Fork ) ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaPosture( Posture ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rstp.TrsSt = TrsSt;
	para.rstp.PMode = PMode;
	para.rstp.Fork = Fork;
	para.rstp.Posture = Posture;

	MakeCommandString( unit, Cmd_RSTP, CommandLine, &para );


	r = SendReply( unit, Cmd_RSTP, CommandLine, anData );

	return r;
}

	// IO �M���Q�ƃR�}���h
int CManipulatorComm::SendManipulator_RIOS( int unit, struct MP_ANSWERDATA* anData )																						// IO �M���Q�ƃR�}���h
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RIOS, CommandLine, &para );


	r = SendReply( unit, Cmd_RIOS, CommandLine, anData );

	return r;
}

	// �}�b�s���O�f�[�^�Q��
int CManipulatorComm::SendManipulator_RMPD( int unit, int TrsSt, struct MP_ANSWERDATA* anData )																			// �}�b�s���O�f�[�^�Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaTrsSt( TrsSt ) ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rmpd.TrsSt = TrsSt;

	MakeCommandString( unit, Cmd_RMPD, CommandLine, &para );


	r = SendReply( unit, Cmd_RMPD, CommandLine, anData );

	return r;
}

	// �p�����[�^�Q��
int CManipulatorComm::SendManipulator_RPRM( int unit, int Type, int PrmNo, struct MP_ANSWERDATA* anData )																// �p�����[�^�Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}
	if( !CheckParaKindOfPara( Type ) ){
		r = ErrParameter;
		return r;
	}
	if( PrmNo < 0 || PrmNo > 9999 ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	para.rprm.Type = Type;
	para.rprm.PrmNo = PrmNo;

	MakeCommandString( unit, Cmd_RPRM, CommandLine, &para );


	r = SendReply( unit, Cmd_RPRM, CommandLine, anData );

	return r;
}

	// �J�����_�[�Q��
int CManipulatorComm::SendManipulator_RCAL( int unit, struct MP_ANSWERDATA* anData )																						// �J�����_�[�Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RCAL, CommandLine, &para );


	r = SendReply( unit, Cmd_RCAL, CommandLine, anData );

	return r;
}

	// ���ʒl�y��CCD �Z���T�l�̎Q��
int CManipulatorComm::SendManipulator_RCCD( int unit, struct MP_ANSWERDATA* anData )																						// ���ʒl�y��CCD �Z���T�l�̎Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RCCD, CommandLine, &para );


	r = SendReply( unit, Cmd_RCCD, CommandLine, anData );

	return r;
}

	// ��ʒu�̎Q��
int CManipulatorComm::SendManipulator_RSTN( int unit, struct MP_ANSWERDATA* anData )																						// ��ʒu�̎Q��
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_RSTN, CommandLine, &para );


	r = SendReply( unit, Cmd_RSTN, CommandLine, anData );

	return r;
}

	// ���s�I���m�F�ʒm
int CManipulatorComm::SendManipulator_ACKN( int unit, struct MP_ANSWERDATA* anData )																						// ���s�I���m�F�ʒm
{
	int		r = 0;
	char	CommandLine[1000];
	union	MP_COMMAND_PARA	para;
//	struct	MP_ANSWERDATA	answer;
//	struct	MP_FINISHDATA	fine;
//	CEvent	evFINISH;			// ���슮���C�x���g

//	CSingleLock	S( &eventFINISH );	// 2011.11.30 CommentOut

	if( unit != UNIT_MANIPULATOR && unit != UNIT_PREALIGNER ){
		r = ErrParameter;
		return r;
	}

	memset( CommandLine, 0, sizeof(CommandLine) );

	MakeCommandString( unit, Cmd_ACKN, CommandLine, &para );


	r = SendReply( unit, Cmd_ACKN, CommandLine, anData );

	return r;
}











// �R�}���h�p�����[�^�̃`�F�b�N�֐��Q
//
// INIT �R�}���h ���������[�h
BOOL	CManipulatorComm::CheckParaInitMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_IMODE_00 && n <= MPCMD_IMODE_10 ){
		r = TRUE;
	}
	return r;
}
// MHOM �R�}���h ���샂�[�h
BOOL	CManipulatorComm::CheckParaMHOMMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_MMODE_F && n <= MPCMD_MMODE_A ){
		r = TRUE;
	}
	return r;
}
// �����X�e�[�V����
BOOL	CManipulatorComm::CheckParaTrsSt( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_TRSST_C1 && n <= MPCMD_TRSST_FE ){
		r = TRUE;
	}
	return r;
}
// �X���b�g�ԍ�
BOOL	CManipulatorComm::CheckParaSlotNumber( int n )
{
	BOOL	r = FALSE;
	if( (n >= 0 && n <= MP_MAX_SLOT) || (n == -1) ){		// MMAP�R�}���h�ɂđS�X���b�g�w�莞��-1
		r = TRUE;
	}
	return r;
}
// �����샂�[�h
BOOL	CManipulatorComm::CheckParaNextMtn( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_NEXTMTN_GA && n <= MPCMD_NEXTMTN_AL ){
		r = TRUE;
	}
	return r;
}
// �A�[���p��
BOOL	CManipulatorComm::CheckParaPosture( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_POSTURE_L && n <= MPCMD_POSTURE_A ){
		r = TRUE;
	}
	return r;
}
// �����|�C���g
BOOL	CManipulatorComm::CheckParaTrsPnt( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_TRSPNT_G1 && n <= MPCMD_TRSPNT_P8 ){
		r = TRUE;
	}
	return r;
}
// ���샂�[�h
BOOL	CManipulatorComm::CheckParaMtnMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_MTNMODE_GA && n <= MPCMD_MTNMODE_EB ){
		r = TRUE;
	}
	return r;
}
// �t�H�[�N�w��
BOOL	CManipulatorComm::CheckParaFork( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_FORK_A && n <= MPCMD_FORK_W ){
		r = TRUE;
	}
	return r;
}
// �ʒu���[�h
BOOL	CManipulatorComm::CheckParaPMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_PMODE_S && n <= MPCMD_PMODE_C ){
		r = TRUE;
	}
	return r;
}
// ��
BOOL	CManipulatorComm::CheckParaAxis( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_AXIS_S && n <= MPCMD_AXIS_G ){
		r = TRUE;
	}
	return r;
}
// ��񎲓��샂�[�h
BOOL	CManipulatorComm::CheckParaWristMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_MODE_C && n <= MPCMD_MODE_I ){
		r = TRUE;
	}
	return r;
}
// �T�[�{�w��
BOOL	CManipulatorComm::CheckParaServo( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_SERVO_OFF && n <= MPCMD_SERVO_ON ){
		r = TRUE;
	}
	return r;
}
// �N���A���[�h
BOOL	CManipulatorComm::CheckParaClear( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_CMODE_E && n <= MPCMD_CMODE_H ){
		r = TRUE;
	}
	return r;
}
// �`���b�L���O�w��
BOOL	CManipulatorComm::CheckParaChuck( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_CHUCK_OFF && n <= MPCMD_CHUCK_ON ){
		r = TRUE;
	}
	return r;
}
// �`���b�L���O���Ԍv��
BOOL	CManipulatorComm::CheckParaChuckTime( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_CHUCK_OFF_TM && n <= MPCMD_CHUCK_ON_TM ){
		r = TRUE;
	}
	return r;
}
// ���t�^�w��
BOOL	CManipulatorComm::CheckParaLift( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_LIFT_DOWN && n <= MPCMD_LIFT_UP ){
		r = TRUE;
	}
	return r;
}
// ���x���[�h
BOOL	CManipulatorComm::CheckParaSpeedMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_SMODE_H && n <= MPCMD_SMODE_B ){
		r = TRUE;
	}
	return r;
}
// ������
BOOL	CManipulatorComm::CheckParaMemory( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_MEM_V && n <= MPCMD_MEM_N ){
		r = TRUE;
	}
	return r;
}
// �o�^���[�h
BOOL	CManipulatorComm::CheckParaRegistMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_RMODE_N && n <= MPCMD_RMODE_V ){
		r = TRUE;
	}
	return r;
}
// �X���b�g�ԃs�b�`�����������[�h
BOOL	CManipulatorComm::CheckParaSlotPitchMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_SPMODE_A && n <= MPCMD_SPMODE_F ){
		r = TRUE;
	}
	return r;
}
// �V�X�e���^�C�v
BOOL	CManipulatorComm::CheckParaSystemType( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_TYPE_1 && n <= MPCMD_TYPE_4 ){
		r = TRUE;
	}
	return r;
}
// �������x���x��
BOOL	CManipulatorComm::CheckParaTrSpeedLevel( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_SLEVEL_H && n <= MPCMD_SLEVEL_L ){
		r = TRUE;
	}
	return r;
}
// �X�V���[�h
BOOL	CManipulatorComm::CheckParaUpdateMode( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_UMODE_A && n <= MPCMD_UMODE_V ){
		r = TRUE;
	}
	return r;
}
// �p�����[�^���
BOOL	CManipulatorComm::CheckParaKindOfPara( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_TYPE_CIU && n <= MPCMD_TYPE_URU ){
		r = TRUE;
	}
	return r;
}
// ���f���ԍ�
BOOL	CManipulatorComm::CheckParaModelNumber( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_MODEL_00 && n <= MPCMD_MODEL_20 ){
		r = TRUE;
	}
	return r;
}
// ���O�ԍ�
BOOL	CManipulatorComm::CheckParaLogNumber( int n )
{
	BOOL	r = FALSE;
	if( n >= MPCMD_LOG_00 && n <= MPCMD_LOG_21 ){
		r = TRUE;
	}
	return r;
}
// �A���O��
BOOL	CManipulatorComm::CheckParaAngle( int n )
{
	BOOL	r = FALSE;
	if( n >= 0 && n <= 35999 ){
		r = TRUE;
	}
	return r;
}


// RFIDComm.cpp: RFIDComm �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#ifdef	TEST
#include "stdafx.h"
#else
#include "stdafx.h"
#endif

#include "RFIDComm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Constructor 
//////////////////////////////////////////////////////////////////////

RFIDComm::RFIDComm()
{
	eventAnswer.ResetEvent();
	
	pRThread = AfxBeginThread(this->RFIDCommRecv, this, THREAD_PRIORITY_NORMAL);
	if( !pRThread ){
		AfxMessageBox("Cannot create receive thread", MB_OK, 0);
	}
	m_hCommRThread = pRThread->m_hThread;
	this->m_readerID = '0';
	this->m_errorID = 0;
}

//////////////////////////////////////////////////////////////////////
// Destructor
//////////////////////////////////////////////////////////////////////

RFIDComm::~RFIDComm()
{

}

//////////////////////////////////////////////////////////////////////
// Set RS232 communication parameter 
//////////////////////////////////////////////////////////////////////

void	RFIDComm::SetCommPara( CString ComPort, int boudrate, int databit, int stopbit, int parity, int evenodd )
{
	PortComm.SetCommOpenInfo( ComPort, boudrate, databit, stopbit, parity, evenodd );
}

//////////////////////////////////////////////////////////////////////
// Open communication
//////////////////////////////////////////////////////////////////////

BOOL	RFIDComm::OpenComm()
{
	BOOL	r;
	r = PortComm.CommOpen();
	if( r ){
		CommSetting();
	}
	return r;
}

//////////////////////////////////////////////////////////////////////
// Close communication 
//////////////////////////////////////////////////////////////////////

BOOL	RFIDComm::CloseComm()
{
	BOOL	r = TRUE;
//	r = PortComm.CommClose();
	if(PortComm.m_hComm && PortComm.m_hComm != INVALID_HANDLE_VALUE) {
		CloseHandle(PortComm.m_hComm);
		PortComm.m_hComm = 0;
	}

	return r;
}

//////////////////////////////////////////////////////////////////////
// Communication settings
//////////////////////////////////////////////////////////////////////
BOOL RFIDComm::CommSetting()
{
	// get any early notifications
	SetCommMask( PortComm.m_hComm, EV_RXCHAR ) ;
	// setup device buffers 
	if( !SetupComm( PortComm.m_hComm, 4096, 4096 ) )
		return FALSE;
	// purge any information in the buffer
	PurgeComm( PortComm.m_hComm,	PURGE_TXABORT | PURGE_RXABORT |
						PURGE_TXCLEAR | PURGE_RXCLEAR ) ;

	// set up for overlapped I/O
	PortComm.m_CommTimeOuts.ReadIntervalTimeout =0xFFFFFFFF ;		//  Timeout
	PortComm.m_CommTimeOuts.ReadTotalTimeoutMultiplier = 0 ;
	PortComm.m_CommTimeOuts.ReadTotalTimeoutConstant = 100 ;		//  Timeout(ms)
	PortComm.m_CommTimeOuts.WriteTotalTimeoutMultiplier = 0 ;
	PortComm.m_CommTimeOuts.WriteTotalTimeoutConstant = 100 ;		//  Timeout(ms)
	if(!SetCommTimeouts(PortComm.m_hComm, &PortComm.m_CommTimeOuts))
		return FALSE;

	//*** COM Port Setup ***
		
	PortComm.m_Dcb.DCBlength = sizeof( DCB ) ;
	if(!GetCommState( PortComm.m_hComm, &PortComm.m_Dcb ))
		return FALSE;

	PortComm.m_Dcb.BaudRate = PortComm.m_BaudRate;	// �`�����x
	PortComm.m_Dcb.ByteSize = PortComm.m_ByteSize;	// �ް���(4�`8)
	PortComm.m_Dcb.StopBits = PortComm.m_StopBits;	// STOP�r�b�g 0=1�r�b�g 1=2�r�b�g
	PortComm.m_Dcb.fParity  = PortComm.m_fParity;	// ���è���� 0=���A1=�L
	if( PortComm.m_fParity == 0 )
		PortComm.m_Dcb.Parity   = NOPARITY;   // 0=no, 1=odd, 2=even
	else
		PortComm.m_Dcb.Parity = PortComm.m_Parity;

	// �ʐM�߰Ă̐ݒ��ύX���܂��B
	if(!SetCommState(PortComm.m_hComm, &PortComm.m_Dcb)){
		long we = GetLastError();
		return FALSE;
	}
	return TRUE;
}

void RFIDComm::SetAnswerObject(CEvent* evOK, CEvent* evNG, LP_ANSWERDATA *ansData)
{
	lp_reply_q.pEventObjOK = evOK;
	lp_reply_q.pEventObjNG = evNG;
	lp_reply_q.ansData = ansData;
}

int		RFIDComm::AnalizeReceiveData( CString rstr )
{
	int r;
	char* P;
	char lengthD[2] = {0};
	char chkXOR[2] = {0};
	char chkADD[2] = {0};
	
	char cmdKind = 0;
	char cmdData[17] = {0};
	char errId = 0;
	char page[2] = {0};
	char paraNo = 0;
	char paraVal[2] = {0};
	char readerId = 0;
	char resCode[4] = {0};
	char serial[4] = {0};
	r = TRUE;

	const static char cmdArray[] =
		{
			'x',	'w',	'R',	'g',	'p',	'e',	'h',	'v',	'l',	'i',	'j'		,'A', 	'n'
		};
	const static unsigned int codeArray[] =
		{
			Cmd_Read,		
			Cmd_Write,		
			Cmd_AutoRead,		
			Cmd_ReqPara,		
			Cmd_SetPara,		
			Cmd_Error,		
			Cmd_HeartBeat,		
			Cmd_QueryRev,
			Cmd_LockPage,	
			Cmd_SetTune,	
			Cmd_ReqTuneSett,		
			Cmd_Sensor,		
			Cmd_Reset
		};
	
	if (r) {
		int length = rstr.GetLength();
		char* replyData =  rstr.GetBuffer(length);
		P = (char *)malloc(length);
		memset(P, 0, length);
		memcpy(P, replyData+2, length-6);
		lengthD[0] = replyData[0];
		lengthD[1] = replyData[1];
		chkXOR[0] = replyData[length - 4];
		chkXOR[1] = replyData[length - 3];
		chkADD[0] = replyData[length - 2];
		chkADD[1] = replyData[length - 1];
		if (P[0] == cmdArray[Cmd_Read]) {
			r = RcvANSWER;
			sscanf(P, "%1c%1c%2c%16c", &cmdKind, &readerId, page, cmdData);
			cmdData[16] = 0;
			memcpy(lp_reply_q.ansData->u_asdata.data, cmdData, 17);
		} else if (P[0] == cmdArray[Cmd_Write]) {
			r = RcvANSWER;
			sscanf(P, "%c%c", &cmdKind, &readerId);
		} else if (P[0] == cmdArray[Cmd_AutoRead]) {
			r = RcvANSWER;
			sscanf(P, "%c%c%2c%16c", &cmdKind, &readerId, page, cmdData);
		} else if (P[0] == cmdArray[Cmd_ReqPara]) {
			r = RcvANSWER;
			sscanf(P, "%c%c%c%2c", &cmdKind, &readerId, paraNo, paraVal);
		} else if (P[0] == cmdArray[Cmd_SetPara]) {
			r = RcvANSWER;
			sscanf(P, "%c%c", &cmdKind, &readerId);
		} else if (P[0] == cmdArray[Cmd_Error]) {
			r = RcvERROR;
			sscanf(P, "%1c%1c%1c", &cmdKind, &readerId, &errId);
			m_errorID = (int)errId;
			TRACE("+++++REPLY--pEventObjNG is set\n");
			lp_reply_q.pEventObjNG->SetEvent();
			return r;
		} else if (P[0] == cmdArray[Cmd_HeartBeat]) {
			r = RcvANSWER;
			sscanf(P, "%c%c%4c%4c", &cmdKind, &readerId, serial, resCode);
		} else if (P[0] == cmdArray[Cmd_QueryRev]) {
			r = RcvANSWER;
			sscanf(P, "%c%c%16c", &cmdKind, &readerId, cmdData);
		} else if (P[0] == cmdArray[Cmd_LockPage]) {
			r = RcvANSWER;
			sscanf(P, "%c%c", &cmdKind, &readerId);
		} else if (P[0] == cmdArray[Cmd_SetTune]) {
			r = RcvANSWER;
			sscanf(P, "%c%c", &cmdKind, &readerId);
		} else if (P[0] == cmdArray[Cmd_ReqTuneSett]) {
			r = RcvANSWER;
			sscanf(P, "%c%c%2c", &cmdKind, &readerId, paraVal);
		} else if (P[0] == cmdArray[Cmd_Sensor]) {
			r = RcvANSWER;
			sscanf(P, "%c%c%", &cmdKind, &readerId);
		} else if (P[0] == cmdArray[Cmd_Reset]) {
			r = RcvANSWER;
			sscanf(P, "%c%c", &cmdKind, &readerId);
		}
// Notify to caller
	
		TRACE("+++++REPLY--pEventObjOK is set\n");
		lp_reply_q.pEventObjOK->SetEvent();
	}
	return r;
}

void 	RFIDComm::MakeReadCommand(char* CommandLine, int pageNo)
{
	char cmd[4] = {0};
	char length[2] = {0};
	char cs_add[2] = {0};
	char cs_xor[2] = {0};
	
	sprintf(cmd, "X%c%02d", this->m_readerID, pageNo);
	sprintf(length, "%02d", strlen(cmd));
	sprintf(CommandLine, "S%s%s", length, cmd);
	int lth = strlen(CommandLine);
	CommandLine[lth] = 0x0D;
	CommandLine[lth+1] = 0;
	SendChecksumCalculator(CommandLine, lth+1, cs_add[0], cs_add[1], cs_xor[0], cs_xor[1]);
	CommandLine[lth+1] = cs_xor[0];
	CommandLine[lth+2] = cs_xor[1];
	CommandLine[lth+3] = cs_add[0];
	CommandLine[lth+4] = cs_add[1];
	CommandLine[lth+5] = 0;
}

int		RFIDComm::SendChecksumCalculator(char* data, int length, char& CSH_ADD, char& CSI_ADD, char& CSH_XOR, char& CSI_XOR)
{
	bool r = true;
	int i;
	int sum = 0;
	int XOR = 0;
	CString chkSum;
	for (i = 0; i< length; i++) {
		sum += (int)data[i];
		XOR ^= (int)data[i];
	}
//	sum += 0x0D;
//	XOR ^= 0x0D;
	chkSum.Format("%x", sum);
	chkSum = chkSum.Right(2);
	CSH_ADD = chkSum[0];
	CSI_ADD = chkSum[1];
	chkSum.Format("%x", XOR);
	chkSum = chkSum.Right(2);
	CSH_XOR = chkSum[0];
	CSI_XOR = chkSum[1];	
	return r;
}

int		RFIDComm::Send(char* CommandLine)
{
	int		r = Err_None;
	BOOL	fWriteStat;
	DWORD	dwBytesWritten=0;
	int		len = strlen(CommandLine);
	
	PortComm.CommPurge();
	dwBytesWritten = 0;
	fWriteStat = WriteFile(PortComm.m_hComm, CommandLine, len, &dwBytesWritten, 0);
	TRACE("LPM Send(%s)\n",CommandLine);
	if(!fWriteStat || !dwBytesWritten) {
		r = Err_SendError;
	}
	
	return r;
}

int	RFIDComm::WaitForAnswer()
{
	int r = Err_None;
	
	if (r) {
		CSyncObject *ppObjects[2] = {0};
		ppObjects[0] = lp_reply_q.pEventObjOK;
		ppObjects[1] = lp_reply_q.pEventObjNG;
		
		CMultiLock	M(ppObjects,2);
		int	m = M.Lock(LP_REPLY_TIMEOUT,FALSE);
		if (m == WAIT_TIMEOUT) {
			r = Err_RTimeOut;
		} else if (m == 0) {
			r = Err_None;
		} else {
			r = this->m_errorID;
		}
	}
	
	return r;
}


//////////////////////////////////////////////////////////////////////
// Receive thread 
//////////////////////////////////////////////////////////////////////

UINT	RFIDComm::RFIDCommRecv( LPVOID pParam )
{
	enum {
		IDLE = 0,		// Start from 'S'
		WTCR = 1,		// Wait for 0x0D
		WTED = 2		// Wait for end package
	};

	int		i, fReadStat;
	int		PStatus;
	unsigned long	dwLength = 0;
	char	rcvBuf[1000];
	CString		rstr;
	int chkSumLength = 0;
	RFIDComm	*pRFIDPort = (RFIDComm *)pParam;

	PStatus = IDLE;

	rstr.Empty();
	for(;;) {
		if( (pRFIDPort->PortComm.m_hComm != (void *)0) && ((pRFIDPort->PortComm.m_hComm != (void *)0xffffffff)) ){
			fReadStat = ReadFile( pRFIDPort->PortComm.m_hComm, &rcvBuf, 1, &dwLength, 0 );

			if( fReadStat && dwLength ){
				for( i=0 ; i<(int)dwLength ; i++ ){
					switch( PStatus ){
					case	IDLE:		// Start reading
						if (rcvBuf[i] == RFIDComm::STARTCHAR ){
//							rstr += RFIDComm::STARTCHAR;
							PStatus = WTCR;
						}
						break;
					case	WTCR:		// Wait for 0x0D
						if (rcvBuf[i] != RFIDComm::TERMCHAR1){
							rstr += rcvBuf[i];
						} else {		// 0x0D
							rstr += rcvBuf[i];
							PStatus = WTED;
						}
						break;
					case	WTED:		// Wait for end
						if (chkSumLength < 3){		// 4 check sum characters
							rstr += rcvBuf[i];
							chkSumLength++;
							PStatus = WTED;			// continue get check sum
						} else {
							// Analyse receive message
							chkSumLength = 0;
							int ae = pRFIDPort->AnalizeReceiveData(rstr);		
							rstr.Empty();				// Reset string 
							PStatus = IDLE;				// Wait for next command
						}
						break;
					}
				}
			} else {
				Sleep( 10 );
			}
		} else {
			Sleep( 10 );
		}
	}
	return 0;
}


CString RFIDComm::GetCarrierID()
{
	int ret = Err_None;
	CString carrierID = "";
	char cmdLine[30];
	LP_ANSWERDATA	answerD;
	CEvent 	EvAnswerOK;
	CEvent	EvAnswerNG;
	EvAnswerOK.ResetEvent();
	EvAnswerNG.ResetEvent();
	int pageNo = 1;	// Temporary => ask Ito-san
	MakeReadCommand(cmdLine, pageNo);
	ret = Send(cmdLine);
	if (ret == Err_None) {
		// Set answer object event
		SetAnswerObject(&EvAnswerOK, &EvAnswerNG, &answerD);
		// Wait for answer from load port
		ret = WaitForAnswer();
	}
	if (ret == Err_None) {
		carrierID = dataConvertToChar(CString(lp_reply_q.ansData->u_asdata.data));
	}
	
	return carrierID;
}

CString RFIDComm::dataConvertToChar(CString str){
	CString data = "";
	char tmp_c;

	for(int i = 0; i < str.GetLength()/2; i++){
		sscanf(str.Mid(i*2,2), "%X", &tmp_c);
		data = data + tmp_c;
	}
	return data;
}
#include "stdafx.h"
#include "LoadPort.h"

// Initialize load port
BOOL LoadPort::OriginLoadPort()
{
	BOOL ret = TRUE;
	TRACE("FCB-%s::OriginLoadPort() \n", this->name);
	if(!this->isEnable){
		return TRUE;
	}
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"OriginLoadPort() Start\n");
#endif
#if 1// #KI150718 ���{�b�g�ʐM����������܂Ŏb��Todo
	ret	= this->RobotArmIsSafety() && ret;
#else
	ret = true;
#endif
	ret = ret && GetStatus(&answerData);
	if(ret){
		if(answerData.u_asdata.stateLP[11] == '1'){	// Carrier is open
			ret = LoadPortComm.SendLoadPort_MOV_VACON();
			if(ret == TDKLoadPortComm::Err_None){
				ret = TRUE;
			}else{
				CString estr;
				estr.Format("Origin LoadPort Error Code [%04x]\r\n", ret);
				this->PutLoadPortError(ret, estr);
				ret = FALSE;
			}
			if (ret) {
				ret = LoadPortComm.SendLoadPort_MOV_ABORG();
				if(ret == TDKLoadPortComm::Err_None){
					ret = TRUE;
					// Slot map not set
					this->slotMapIsMade		= false;
				}else{
					CString estr;
					estr.Format("Origin LoadPort Error Code [%04x]\r\n", ret);
					this->PutLoadPortError(ret, estr);
					ret = FALSE;
				}
			}
		} else {					// Carrier is close
			if (ret) {
				// #KI150902-04
				// �t�[�v�̊J��Ԃɂ�����炸�������_���A�Ƃ���B
//				ret = LoadPortComm.SendLoadPort_MOV_ORGSH();
				ret = LoadPortComm.SendLoadPort_MOV_ABORG();
#if !Release
				theTime = CTime::GetCurrentTime();
				Msg = theTime.Format("%H:%M:%S,");
				TRACE(Msg+"OriginLoadPort() End[0x%04x]\n", ret);
#endif
				if(ret == TDKLoadPortComm::Err_None){
					ret = TRUE;
					// Slot map not set
					this->slotMapIsMade		= false;
				}else{
					CString estr;
					estr.Format("Origin LoadPort Error Code [%04x]\r\n", ret);
					this->PutLoadPortError(ret, estr);
					ret = FALSE;
				}
			}
		}
	}
	
	return ret;
}

// Load carrier 
BOOL LoadPort::CarrierLoad()
{
	BOOL ret = TRUE;
	bool isPlaced	= false;
	TRACE("FCB-%s::CarrierLoad() \n",this->name);
	// bool isReady	= false;
	// 6000W����Ȃ��ꍇ,��������GPDEBUG��
	if(!this->isEnable){
		return TRUE;
	}
	if (ret &&(!this->CarrierPlacedSns(isPlaced)||!isPlaced)) {
		ret = FALSE;
		this->err.PutError(Err_CassetIsNotPlaced);
	}
	ret	= this->RobotArmIsSafety() && ret;
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"CarrierLoad() Start\n");
#endif
	if(ret){
		ret = LoadPortComm.SendLoadPort_MOV_CLOAD();
#if !Release
		theTime = CTime::GetCurrentTime();
		Msg = theTime.Format("%H:%M:%S,");
		TRACE(Msg+"CarrierLoad() End[0x%04x]\n", ret);
#endif
		if(ret == TDKLoadPortComm::Err_None){
			ret = TRUE;
		}else{
			CString estr;
			estr.Format( "CarrierLoad Error Code [%04x]\r\n", ret );
			this->PutLoadPortError(ret, estr);
			ret = FALSE;
		}
	}
	return ret;
}

// Unload carrier
BOOL LoadPort::CarrierUnLoad()
{
	BOOL ret = TRUE;
	bool isPlaced	= false;
	// bool isReady	= false;

	TRACE("FCB-%s::CarrierUnLoad() \n",this->name);

	// 6000W����Ȃ��ꍇ,��������GPDEBUG��
	if(!this->isEnable){
		return TRUE;
	}
	if (ret &&(!this->CarrierPlacedSns(isPlaced)||!isPlaced)) {
		ret = FALSE;
		this->err.PutError(Err_CassetIsNotPlaced);
	}
	ret	= this->RobotArmIsSafety() && ret;
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"CarrierUnLoad() Start\n");
#endif
	if(ret){
		ret = LoadPortComm.SendLoadPort_MOV_CULOD();
#if !Release
		theTime = CTime::GetCurrentTime();
		Msg = theTime.Format("%H:%M:%S,");
		TRACE(Msg+"CarrierUnLoad() End[0x%04x]\n", ret);
#endif
		if(ret == TDKLoadPortComm::Err_None){
			ret = TRUE;
			// �X���b�g�}�b�v�͍���ĂȂ�
			this->slotMapIsMade		= false;
		}else{
			CString estr;
			estr.Format( "CarrierUnLoad Error Code [%04x]\r\n", ret );
			this->PutLoadPortError(ret, estr);
			ret = FALSE;
		}
	}
	return ret;
}

// Read carrier ID
BOOL LoadPort::ReadCarrierID()
{
	BOOL r = TRUE;
	this->carrierID = this->m_RFIDComm.GetCarrierID();
#if GPDEBUG
	this->carrierID = "CARRIERID";
#endif
	if (pSendS06F11) {
		r = (*pSendS06F11)(/*DlgSG300::eRFIDRead*/2, /*DlgSG300::eBottomPortNo*/1);
	}
	return r;
}

// Clamp FOUP
BOOL LoadPort::ClampFoupAct(bool clamp)
{
	BOOL ret = TRUE;
	// bool isPlaced	= false;
	TRACE("FCB-%s::ClampFoupAct() - clamp = %d \n",this->name,clamp);
	// 6000W����Ȃ��ꍇ,��������GPDEBUG��
#if GPDEBUG
	if (clamp) {
		ret = (*pSendS06F11)(/*DlgSG300::eFoupClamp*/0, /*DlgSG300::eBottomPortNo*/1);
	} else {
		ret = (*pSendS06F11)(/*DlgSG300::eFoupUnclamp*/1, /*DlgSG300::eBottomPortNo*/1);
	}
#endif
	if(!this->isEnable){
		return TRUE;
	}
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"ClampFoupAct(%d) Start\n", clamp);
#endif
	if(ret){
		if(clamp){
			ret = LoadPortComm.SendLoadPort_MOV_PODCL();
		}else{
			ret = LoadPortComm.SendLoadPort_MOV_PODOP();
		}
#if !Release
		theTime = CTime::GetCurrentTime();
		Msg = theTime.Format("%H:%M:%S,");
		TRACE(Msg+"ClampFoupAct() End[0x%04x]\n", ret);
#endif
		if(ret == TDKLoadPortComm::Err_None){
			ret = TRUE;
			if (pSendS06F11) {
				if (clamp) {
					ret = (*pSendS06F11)(/*DlgSG300::eFoupClamp*/0, /*DlgSG300::eBottomPortNo*/1);
				} else {
					ret = (*pSendS06F11)(/*DlgSG300::eFoupUnclamp*/1, /*DlgSG300::eBottomPortNo*/1);
				}
			}
		}else{
			CString estr;
			estr.Format( "ClampFoupAct Error Code [%04x]\r\n", ret );
			this->PutLoadPortError(ret, estr);
			ret = FALSE;
		}
	}
	
	return ret;
}

// Dock FOUP action
BOOL LoadPort::DockFoupAct(bool dock)
{
	BOOL ret = TRUE;
	TRACE("FCB-%s::DockFoupAct() - dock = %d \n",this->name,dock);
#if GPDEBUG
	if (dock) {
		ret = (*pSendS06F11)(/*DlgSG300::eFoupClamp*/3, /*DlgSG300::eBottomPortNo*/1);
	} else {
		ret = (*pSendS06F11)(/*DlgSG300::eFoupUnclamp*/4, /*DlgSG300::eBottomPortNo*/1);
	}
#endif
	// 6000W����Ȃ��ꍇ,��������GPDEBUG��
	if(!this->isEnable){
		return TRUE;
	}
	ret	= this->RobotArmIsSafety() && ret;
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"DockFoupAct(%d) Start\n", dock);
#endif
	if(ret){
		if(dock){
			ret = LoadPortComm.SendLoadPort_MOV_YDOOR();
		}else{
			ret = LoadPortComm.SendLoadPort_MOV_YWAIT();
		}
#if !Release
		theTime = CTime::GetCurrentTime();
		Msg = theTime.Format("%H:%M:%S,");
		TRACE(Msg+"DockFoupAct() End[0x%04x]\n", ret);
#endif
		if(ret == TDKLoadPortComm::Err_None){
			ret = TRUE;
			if (pSendS06F11) {
				if (dock) {
					ret = (*pSendS06F11)(/*DlgSG300::eFoupDock*/3, /*DlgSG300::eBottomPortNo*/1);
				} else {
					ret = (*pSendS06F11)(/*DlgSG300::eFoupUndock*/4, /*DlgSG300::eBottomPortNo*/1);
				}
			}
		}else{
			CString estr;
			estr.Format( "DockFoupAct Error Code [%04x]\r\n", ret );
			this->PutLoadPortError(ret, estr);
			ret = FALSE;
		}
	}
	return (ret);
}

BOOL LoadPort::OpenFoupAct(bool open)
{
	BOOL ret = TRUE;
	bool isPlaced	= false;
	TRACE("FCB-%s::OpenFoupAct() - open = %d \n",this->name,open);
	// 6000W����Ȃ��ꍇ,��������GPDEBUG��
	if(!this->isEnable){
		return TRUE;
	}
	if (ret &&(!this->CarrierPlacedSns(isPlaced)||!isPlaced)) {
		ret = FALSE;
		this->err.PutError(Err_CassetIsNotPlaced);
	}
	// If Door already Open, do nothing
	bool isClosed	= false;
	if (ret &&(this->DoorClosedSns(isClosed)&&!isClosed) && open) {
		ret = GetStatus(&answerData);
		if(ret){
			if(answerData.u_asdata.stateLP[10] == '1'){	// Check Door status
				return(TRUE);
			}
		}
	}
	ret	= this->RobotArmIsSafety() && ret;
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"OpenFoupAct(%d) Start\n", open);
#endif
	if(ret){
		if(open){
			ret = LoadPortComm.SendLoadPort_MOV_CLOAD();
		}else{
			ret = LoadPortComm.SendLoadPort_MOV_CULYD();
		}
#if !Release
		theTime = CTime::GetCurrentTime();
		Msg = theTime.Format("%H:%M:%S,");
		TRACE(Msg+"MakeSlotMap() End[0x%04x]\n", ret);
#endif
		if(ret == TDKLoadPortComm::Err_None){
			ret = TRUE;
		}else{
			CString estr;
			estr.Format( "OpenFoupAct Error Code [%04x]\r\n", ret );
			this->PutLoadPortError(ret, estr);
			ret = FALSE;
		}
	}
	return (ret);
}

// Get current data
BOOL LoadPort::GetStatus(TDKLoadPortComm::LP_ANSWERDATA* anData)
{
	BOOL ret = TRUE;
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetStatus() Start\n");
#endif
	ret = LoadPortComm.SendLoadPort_GET_STATE(anData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetStatus() End[0x%04x]\n", ret);
#endif
	return ret;
}

// Check if Foup is clamp or not 
bool	LoadPort::FoupIsClamped(void)
{
	bool	isClamped	= false;
	BOOL ret = TRUE;
	// Get current load port status
	ret = GetStatus(&answerData);
	if(ret == TDKLoadPortComm::Err_None){
		// Check the load port clamp
		if(answerData.u_asdata.stateLP[7] == '1'){ 
			isClamped	= true;
		}else{
			isClamped	= false;
		}
	}else{
		isClamped	= false;
	}
	return isClamped;
}

// Carrier unload sequence 2
BOOL LoadPort::RejectCarrierSeq2()
{
	BOOL r = TRUE;
	// �t�[�v�J�Z�b�g�N���[�Y
	if(r){
		// �A���h�b�N���ďI��
		r = this->DockFoupAct(false);
	}
	if(r){
		// �X���b�g�}�b�v�͍���ĂȂ�
		this->slotMapIsMade		= false;
		// �A���N�����v
		r = this->ClampFoupAct(false);
	}
	return r;
}

// Carrier unload sequence 1
BOOL	LoadPort::RejectCarrierSeq1()
{
	BOOL r = TRUE;
	// �t�[�v�J�Z�b�g�N���[�Y
	if(r){
		// �t�[�v�J�Z�b�g�����
		r = this->OpenFoupAct(false);
	}
	return r;
}

// Carrier reject
BOOL	LoadPort::RejectCarrier()
{
	BOOL r = TRUE;
	TRACE("FCB-%s::RejectCarrier() \n", this->name);
	bool isOpened	= false;
	// �t�[�v�J�Z�b�g�N���[�Y
	if(r){
		// #KI150722-03(S)
		// ���Ă����
		if ((this->DoorOpenedSns(isOpened)&&!isOpened)) {
			// Undock
			r = this->DockFoupAct(false);
		}else{
			// �P�Ȃ�L�����A�A�����[�h
			r = this->CarrierUnLoad();
		}
		// #KI150722-03(E)
	}
	if(r){
		// �X���b�g�}�b�v�͍���ĂȂ�
		this->slotMapIsMade		= false;
	}
	return r;
}

// Read slot map
BOOL	LoadPort::SlotMapRead()
{
	BOOL r = TRUE;
//	TRACE("FCB-%s::SlotMapRead() \n",this->name);
	// �t�[�v�J�Z�b�g�I�[�v��
	if(r){
		// �X���b�g�}�b�v�쐬����Ȃ�A
		if((this->makeSlotMap)&&(!this->slotMapIsMade)){
			// �X���b�g�}�b�v�쐬�̃��[�h true=open
			r = this->MakeSlotMap(true);
			if(r){
				// �X���b�g�}�b�v�͍��ꂽ
				this->slotMapIsMade		= true;
				if (r && pSendS06F11) {
					r = (*pSendS06F11)(/*DlgSG300::eSlotMapRead*/5, /*DlgSG300::eBottomPortNo*/1);
				}
			}
		}else{
			// �쐬�Ȃ��Ȃ�A�P�Ȃ郍�[�h
			r = this->CarrierLoad();
		}
	}
	return r;
}

// Make slot map
BOOL	LoadPort::MakeSlotMap()
{
	BOOL r = TRUE;
	r = this->MakeSlotMap(true);
	if(r){
		// �X���b�g�}�b�v�͍��ꂽ
		this->slotMapIsMade		= true;
	}
	return (r);
}

BOOL	LoadPort::DockDUFoupAct(){
	BOOL ret = TRUE;
	// #KI150722-05(S)
	bool isPlaced	= false;
	if ((!this->CarrierPlacedSns(isPlaced)||!isPlaced)) {
		ret = FALSE;
		this->err.PutError(Err_CassetIsNotPlaced);
	}
	if(ret){
		ret = GetStatus(&answerData);
	}
	// #KI150722-05(E)
	if (ret == TDKLoadPortComm::Err_None) {
		if(answerData.u_asdata.stateLP[13] == '1'){	// Carrier is dock?
			ret = this->DockFoupAct(false);		// Undock
			if(ret){
				// �X���b�g�}�b�v�͍���ĂȂ�
				this->slotMapIsMade		= false;
				ret = this->ClampFoupAct(false);	// �A���N�����v
			}
		}else{
			ret = this->ClampFoupAct(true);	// �N�����v
			if(ret){
				ret = this->DockFoupAct(true);		// �h�b�N
			}
		}
	}
	return(ret);
}

BOOL	LoadPort::ClampCUFoupAct(){
	BOOL ret = TRUE;
	// #KI150722-05(S)
	bool isPlaced	= false;
	if ((!this->CarrierPlacedSns(isPlaced)||!isPlaced)) {
		ret = FALSE;
		this->err.PutError(Err_CassetIsNotPlaced);
	}
	if(ret){
		ret = GetStatus(&answerData);
	}
	// #KI150722-05(E)
	if(ret){
		if(answerData.u_asdata.stateLP[7] == '1'){// Carrier is clamped 
			ret = this->ClampFoupAct(false);	// Unclamp
		}else{
			ret = this->ClampFoupAct(true);		// Clamp
		}
	}
	return(ret);
}

BOOL	LoadPort::OpenFoupAct(){
	BOOL ret = TRUE;
	ret = GetStatus(&answerData);
	if(ret){
		if(answerData.u_asdata.stateLP[11] == '1'){	// Carrier is open
			ret = this->OpenFoupAct(false);		// Close 
		}else{
			ret = this->OpenFoupAct(true);		// Open
		}
	}
	return(ret);
}

BOOL	LoadPort::MakeSlotMap(bool doOpen)
{
	BOOL ret = TRUE;
	bool isPlaced	= false;
	TRACE("FCB-%s::MakeSlotMap() - open = %d \n", this->name, doOpen);
#if GPDEBUG
	{
		for(int i=0;i<10;i++){
			this->waferUmu[i]	= LoadPort::eWaferExist;
		}
		for(i=10;i<this->Plset;i++){
			this->waferUmu[i]	= LoadPort::eWaferNone;
		}
	}
#endif
	// 6000W����Ȃ��ꍇ,��������GPDEBUG��
	if(!this->isEnable){
		return TRUE;
	}
	if (ret &&(!this->CarrierPlacedSns(isPlaced)||!isPlaced)) {
		ret = FALSE;
		this->err.PutError(Err_CassetIsNotPlaced);
	}
	ret	= this->RobotArmIsSafety() && ret;
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"MakeSlotMap(%d) Start\n", doOpen);
#endif
	if(ret){
		if(doOpen){
			ret = LoadPortComm.SendLoadPort_MOV_CLDMP();
		}else{
			ret = LoadPortComm.SendLoadPort_MOV_CUDMP();
		}
		if (ret == TDKLoadPortComm::Err_None) {
			ret = LoadPortComm.SendLoadPort_GET_MAPRD(&answerData);
		}
		
		if (ret == TDKLoadPortComm::Err_None) {
			CString es;
			es.Format( "mapInfo[%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d][%d]\r\n",
										answerData.u_asdata.mapInfo[ 0], answerData.u_asdata.mapInfo[ 1], answerData.u_asdata.mapInfo[ 2], answerData.u_asdata.mapInfo[ 3], answerData.u_asdata.mapInfo[ 4],
										answerData.u_asdata.mapInfo[ 5], answerData.u_asdata.mapInfo[ 6], answerData.u_asdata.mapInfo[ 7], answerData.u_asdata.mapInfo[ 8], answerData.u_asdata.mapInfo[ 9],
										answerData.u_asdata.mapInfo[10], answerData.u_asdata.mapInfo[11], answerData.u_asdata.mapInfo[12], answerData.u_asdata.mapInfo[13], answerData.u_asdata.mapInfo[14],
										answerData.u_asdata.mapInfo[15], answerData.u_asdata.mapInfo[16], answerData.u_asdata.mapInfo[17], answerData.u_asdata.mapInfo[18], answerData.u_asdata.mapInfo[19],
										answerData.u_asdata.mapInfo[20], answerData.u_asdata.mapInfo[21], answerData.u_asdata.mapInfo[22], answerData.u_asdata.mapInfo[23], answerData.u_asdata.mapInfo[24] );
			// �����ň�xwaferID��������
			for(int j=0;j<eWaferNumberMax;j++){
				this->waferID[j]	= '0';
			}
			CString	str;
			for(int i=0;i<this->Plset;i++){
				this->waferUmu[i]	= (int)(answerData.u_asdata.mapInfo[ i]);
				if((int)(answerData.u_asdata.mapInfo[ i]) == LoadPort::eWaferExist){
					str.Format("WAFER.%02d",i+1);
					this->waferID[i]	= str;
				}else{
					this->waferID[i]	= '1';
				}
			}
		}
#if !Release
		theTime = CTime::GetCurrentTime();
		Msg = theTime.Format("%H:%M:%S,");
		TRACE(Msg+"MakeSlotMap() End[0x%04x]\n", ret);
#endif
		if(ret == TDKLoadPortComm::Err_None){
			ret = TRUE;
		}else{
			CString estr;
			estr.Format( "MakeSlotMap Error Code [%04x]\r\n", ret );
			this->PutLoadPortError(ret, estr);
			ret = FALSE;
		}
	}
	return (ret);
}

BOOL	LoadPort::DoFoupClamp(){
	BOOL r = TRUE;
	BOOL ret = TRUE;
	TRACE("FCB-%s::DoFoupClamp() \n",this->name);
	// �A�N�Z�X�X�C�b�`�n�m��҂�
	if(r){
		// �L�����A�N�����v��Ԃ�����
		ret = GetStatus(&answerData);
		if(ret){
			if(answerData.u_asdata.stateLP[7] == '1'){// �L�����A�N�����v���
			}else{
				// �A���N�����v��Ԃł���΁A�N�����v����B
				ret = this->ClampFoupAct(true);
			}
		}
	}
	return r;
}

BOOL	LoadPort::LockDoorAct(){
	BOOL ret = TRUE;
	return(ret);
}
BOOL	LoadPort::LockDoorAct(bool clamp){
	BOOL ret = TRUE;
	return (ret);
}

BOOL	LoadPort::GetDockStatus(bool &alreadyDocked){
	BOOL ret = TRUE;
	// Get current load port status
	ret = GetStatus(&answerData);
	if(ret == TDKLoadPortComm::Err_None){
		// Check the load port clamp
		if(answerData.u_asdata.stateLP[13] == '1'){ 
			alreadyDocked	= true;
		}else{
			alreadyDocked	= false;
		}
	}else{
		alreadyDocked	= false;
	}
	return ret;
}

BOOL	LoadPort::ResetLPError()
{
	BOOL ret = TRUE;
	TRACE("FCB-%s::ResetLPError()\n",this->name);
	// 6000W����Ȃ��ꍇ,��������GPDEBUG��
	if(!this->isEnable){
		return TRUE;
	}

	#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"ResetLPError(%d) Start\n");
#endif
	if(ret){
		ret = LoadPortComm.SendLoadPort_SET_RESET();
		if (ret == TDKLoadPortComm::Err_None) {
			
		}
#if !Release
		theTime = CTime::GetCurrentTime();
		Msg = theTime.Format("%H:%M:%S,");
		TRACE(Msg+"ResetLPError() End[0x%04x]\n", ret);
#endif
		if(ret == TDKLoadPortComm::Err_None){
			ret = TRUE;
		}else{
			CString estr;
			estr.Format( "ResetLPError Error Code [%04x]\r\n", ret );
			this->PutLoadPortError(ret, estr);
			ret = FALSE;
		}
	}

	return ret;
}

BOOL	LoadPort::CheckSlotEmpty(int slotNo) 
{
	BOOL r = TRUE;
	bool isPlaced	= false;
	// 6000W����Ȃ��ꍇ,��������GPDEBUG��
	if(!this->isEnable){
		return r;
	}
	if (r &&(!this->CarrierPlacedSns(isPlaced)||!isPlaced)) {
		r = FALSE;
		this->err.PutError(Err_CassetIsNotPlaced);
	}
	if (r) {
		// Check by wafer Umu
		if (this->waferUmu[slotNo - 1] == eWaferNone) {
			r = TRUE;
		} else {
			r = FALSE;
		}
	}
	
	return r;
}
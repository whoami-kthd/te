// BasicCameraCtrl.cpp: BasicCameraCtrl �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include "BasicCameraCtrl.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

BasicCameraCtrl::BasicCameraCtrl()
{

}

BasicCameraCtrl::~BasicCameraCtrl()
{

}

BasicCameraCtrl::BasicCameraCtrl(int cameraNo)
{
	this->cameraNo = cameraNo;
}

BOOL BasicCameraCtrl::CameraSelect(bool Live)						// ��אؑ�

{
	int r = true;
	// ����Z���N�^�A�h���X�Ȃ�
	// �J�����Z���N�^����ꍇ�́AOrdinaryOut�Œǉ�����B
//		r = CameraSelectorOut(idx);
	if (r) {
		this->pRec->CameraIndex(this->cameraNo);
		this->pRec->CursorDisplay(CMVS8200::CLEAR+CMVS8200::CFLUSH,ccColor::green,0,0,0,0);
		if(Live){	this->pRec->Live(true);}
		else{		this->pRec->Live(false);}
	}
	return (r);
}

/////////////////////////////////////////////////////////////////////
//
void BasicCameraCtrl::CursorDisplay(int x,int y,int sx,int sy)	// ���ٕ\��
{
	this->pRec->CursorDisplay(CMVS8200::CLEAR,ccColor::green,0,0,0,0);
	if(sx == 1 && sy == 1){
		this->pRec->CursorDisplay(CMVS8200::CROSSHAIR+CMVS8200::CFLUSH,ccColor::green,x,y,1,1);
	}
	else if(sx > 1 && sy > 1){
		this->pRec->CursorDisplay(CMVS8200::RECTANGLE+CMVS8200::CFLUSH,ccColor::green,x,y,sx,sy);
	}
}
void BasicCameraCtrl::Live(bool isOn)	// Live �\���ݒ�		true:Live�\��ON
{
	this->pRec->Live(isOn);
}



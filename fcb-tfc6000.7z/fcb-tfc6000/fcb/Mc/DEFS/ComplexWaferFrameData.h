/*---------------------------------------------------------------------
	ComplexWaferFrameData header file
								2013 MinhNN / TSDV Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/

//#if !defined(AFX_COMPLEXWAFERFRAMEDATA_H__93F78B70_6C78_4A16_974A_5D37B3DFD327__INCLUDED_)
//#define AFX_COMPLEXWAFERFRAMEDATA_H__93F78B70_6C78_4A16_974A_5D37B3DFD327__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include	<CommonDef.h>
#include	<pos.h>
#include	<Gwpp.h>


//*******************************************************************
//
//	#MH130801: Add LocateEdit function
//	Add new class for data of Complex mode
//	These data of Left side and Right side are same
//
//*******************************************************************
class CComplexWaferFrameData 
{
public:
	CComplexWaferFrameData();
	virtual ~CComplexWaferFrameData();
public:

	//##DuyND
	struct MappingInfo {
		int		FNLOC;
		double	REFPX;
		double	REFPY;
		CString	BCEQU;
		CString	NULBC;
		CString BCPAS;
		CString BCBND;
		int REFND;
		BOOL BCRead;

		BOOL DataRW(BOOL read, LPCTSTR FNam) {
			BOOL r = TRUE;
			if (!read) {
				return r;
			}

			CString sec = "MappingData";
			GWPPfileData(FNam, sec, "FNLOC", read, FNLOC);
			GWPPfileData(FNam, sec, "BCEQU", read, BCEQU);
			GWPPfileData(FNam, sec, "NULBC", read, NULBC);
			GWPPfileData(FNam, sec, "BCPAS", read, BCPAS);
			GWPPfileData(FNam, sec, "BCBND", read, BCBND);
			GWPPfileData(FNam, sec, "REFPX", read, REFPX);
			GWPPfileData(FNam, sec, "REFPY", read, REFPY);
			GWPPfileData(FNam, sec, "REFND", read, REFND);
			GWPPfileData(FNam, sec, "BCRead", read, BCRead);
			// 

			return r;
		}
	}MI;

private:
	int		regNumbers;													// max regNumbers that be used
	R2Pos	regOffset[eCplxRegNumberMax];								// start position of each regNo on frame
	int		eachIcType[eCplxRegNumberMax];								// regNo to IcType
	R2Pos	chipSize[eCplxRegNumberMax];								// regNo to chipSize
	R2Pos	chipPitch[eCplxRegNumberMax];								// regNo to chipPitch
	int		BgLocateArrayX[eCplxRegNumberMax];							// regNo to max number on a column
	int		BgLocateArrayY[eCplxRegNumberMax];							// regNo to max number on a row
	R2Pos	BgLocateOffsetXY[eCplxRegNumberMax][MapMax][MapMax];		// loccate offset XY data
	double	BgLocateOffsetT[eCplxRegNumberMax][MapMax][MapMax];			// locate offset T data
	int	    BgLocateValid[eCplxRegNumberMax][MapMax][MapMax];			// Valid/invalid position data
	CString bgSiteName[eCplxRegNumberMax];								// Bgsite name
	int		eachToolNo[eCplxRegNumberMax];								// regNo to ToolNo		//#DMV170720 Add ToolNo Locate Edit

public:
	BOOL ComplexDVDataReadRegNo(BOOL read, LPCTSTR FNam);
	BOOL ComplexDVDataReadOffsetAndValid(BOOL read, LPCTSTR FNam);
	BOOL ComplexDVDataRead(BOOL read, LPCTSTR FNam);
	
	int		GetRegNumber() {
		return this->regNumbers;
	}
	R2Pos	GetRegOffset(int regNo) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		return this->regOffset[regNo - 1];
	}
	int		GetEachIcType(int regNo) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		return this->eachIcType[regNo - 1];	
	}
	//#DMV170720 Add ToolNo Locate Edit (S)
	int		GetEachToolNo(int regNo) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		return this->eachToolNo[regNo - 1];	
	}
	//#DMV170720 Add ToolNo Locate Edit (E)
	R2Pos	GetChipSize(int regNo) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		return this->chipSize[regNo - 1];
	}
	R2Pos	GetChipPitch(int regNo) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		return this->chipPitch[regNo - 1];
	}
	int		GetBgLocateArrayX(int regNo) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		return this->BgLocateArrayX[regNo - 1];
	}
	int 	GetBgLocateArrayY(int regNo) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		return this->BgLocateArrayY[regNo - 1];
	}
	R2Pos	GetBgLocateOffsetXY(int regNo, int x, int y) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		} else if (x <= 0 || x > BgLocateArrayX[regNo - 1]){
			CString msg;
			msg.Format("Error %s(%d) NumberX = %d", __FILE__, __LINE__, x);
			AfxMessageBox(msg);
		} else if (y <= 0 || y > BgLocateArrayY[regNo - 1]) {
			CString msg;
			msg.Format("Error %s(%d) NumberY = %d", __FILE__, __LINE__, y);
			AfxMessageBox(msg);
		}
		return this->BgLocateOffsetXY[regNo - 1][x - 1][y - 1];
	}
	double	GetBgLocateOffsetT(int regNo, int x, int y) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		} else if (x <= 0 || x > BgLocateArrayX[regNo - 1]){
			CString msg;
			msg.Format("Error %s(%d) NumberX = %d", __FILE__, __LINE__, x);
			AfxMessageBox(msg);
		} else if (y <= 0 || y > BgLocateArrayY[regNo - 1]) {
			CString msg;
			msg.Format("Error %s(%d) NumberY = %d", __FILE__, __LINE__, y);
			AfxMessageBox(msg);
		}
		return this->BgLocateOffsetT[regNo - 1][x - 1][y - 1];
	}
	int		GetBgLocateValid(int regNo, int x, int y) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		} else if (x <= 0 || x > BgLocateArrayX[regNo - 1]){
			CString msg;
			msg.Format("Error %s(%d) NumberX = %d", __FILE__, __LINE__, x);
			AfxMessageBox(msg);
		} else if (y <= 0 || y > BgLocateArrayY[regNo - 1]) {
			CString msg;
			msg.Format("Error %s(%d) NumberY = %d", __FILE__, __LINE__, y);
			AfxMessageBox(msg);
		}
		return this->BgLocateValid[regNo - 1][x - 1][y - 1];
	}

	CString	GetBgSiteName(int regNo) {
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		return this->bgSiteName[regNo - 1];
	}

	// Get position of first valid IC
	bool	GetFirstPositionXY(int regNo, int &x, int &y) {
		bool r = false;				// return value
		if (regNo <= 0 || regNo > regNumbers) {
			CString msg;
			msg.Format("Error %s(%d) regNumbers = %d", __FILE__, __LINE__, regNo);
			AfxMessageBox(msg);
		}
		// Look for the first valid IC
		int xIdx = 0 ;
		int yIdx = 0;
		for (yIdx = 0; yIdx < BgLocateArrayY[regNo-1]; yIdx++) {
			for (xIdx = 0; xIdx < BgLocateArrayX[regNo-1]; xIdx++) {
				if (BgLocateValid[regNo-1][xIdx][yIdx]) {
					// If found
					break;
				}
			}
			if (xIdx < BgLocateArrayX[regNo-1]) {
				// If found
				break;
			}
		}

		if (yIdx < BgLocateArrayY[regNo-1]) {
			// If found
			x = xIdx + 1;
			y = yIdx + 1;
			r = true;
		}

		return r;
	}

	//////////////////////////////////////////////////////////////////////
	//	Callback function
	//
	void (__cdecl *pDisplayTPProgressBar)(BOOL start, LPCSTR str,LPCSTR str2);				// Safety postition to move Bonding Head to Bonding position
	// Set interlock moving checking function
	void SetDisplayTPProgressBar(void (__cdecl *pFunc)(BOOL start, LPCSTR str,LPCSTR str2)){
		pDisplayTPProgressBar	= pFunc;
	}
};

//#endif // !defined(AFX_COMPLEXWAFERFRAMEDATA_H__93F78B70_6C78_4A16_974A_5D37B3DFD327__INCLUDED_)

// FrameIcInfo.cpp: FrameIcInfo �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FCB.h"
#include "MC\DEFS\FrameIcInfo.h"
#include "MC\DEFS\FrameIcCtrl.h"		//#THAIHV170818 Add Locate Edit
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

// �ݽ�׸�
FrameIcInfo::FrameIcInfo()
{
	// �ϐ�������
	moveDir = 0;	// �ړ����� 0:��, 1:��, 2:��, 3:�E
	moveType = 0;	// �ړ��^�C�v
	this->layerStackedCount = 1;
	this->useLayerMode	= false;	// �����̓A�h���X�ϑw
	this->regNumbers	= 1;		// IC�i�퐔
	this->nowRegNumber	= 1;		// ����IC�i��
	for(int i=0;i<RegNumberMax;i++){
		this->badRecogByBCam[i] = false;
		frmAreaX = 1;
		frmAreaY = 1;
	}
	// ���i��}���`
	this->bgSiteNumbers			= 1;
	this->anywaySkipBad			= false;	//
	this->globalBgSts			= 2;		// 2:4���ł����s�ݒ薳��(�������)
	this->useMultiStackMode		= 0;
	this->columnOf_1blkX		= 1;		// 1�u���b�N���ڂw
	// #KI131119-03(S)
	this->badSubStrate			= 0;
	this->nowXIdx				= 1;
	this->nowYIdx				= 1;
	// #KI131119-03(E)
	isSubComplex				= 0;		//#THAIHV170818 Add Locate Edit	
}

// �޽�׸�
FrameIcInfo::~FrameIcInfo()
{

}
// �ڰ����ق�����������B
void FrameIcInfo::InitialFrameModel(bool hasToDisp){
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �ڰя�̂h�b�����擾����
// �ð�ޏ���ڰт����邩�ǂ����͏�ʂŔ��f���邱��
//
bool FrameIcInfo::GetIcStatus(unsigned short bgSiteNo, unsigned short xIdx, unsigned short yIdx,
									   unsigned char &bdSts, unsigned char &bgSts, unsigned short &stackCount){
	CSingleLock S(&FrameIcSema, TRUE);
	//#THAIHV170818 Add Locate Edit (S)
	unsigned short maxX, maxY;
	if (isSubComplex) {
		maxX = this->pCplxWaferD->GetBgLocateArrayX(bgSiteNo);
		maxY = this->pCplxWaferD->GetBgLocateArrayY(bgSiteNo);
	} else {
		maxX = this->frmAreaX;
		maxY = this->frmAreaY;
	}
	//#THAIHV170818 Add Locate Edit (E)
	// xIdx�̑傫���`�F�b�N
	// yIdx�̑傫���`�F�b�N
	// �ُ�l�ł����Debug Break
	//if(xIdx==0||yIdx==0||(this->frmAreaX < xIdx) || (this->frmAreaY < yIdx)){
	if(xIdx==0||yIdx==0||(/*this->frmAreaX*/maxX < xIdx) || (/*this->frmAreaY*/maxY < yIdx)){			//#THAIHV170818 Add Locate Edit
		CString msg;
		msg.Format("Error %s(%d) this->frmAreaX=%d, this->frmAreaY=%d, xIdx=%d, yIdx=%d", __FILE__, __LINE__, this->frmAreaX, this->frmAreaY, xIdx, yIdx);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	bdSts = this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].GetBoardSts();
	bgSts = this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].GetBondSts();
	stackCount = this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].GetStackedCount();
	return true;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �ڰя�̊�ɂ�����h�b����ݒ肷��(�������ĕs��)�B
//
bool FrameIcInfo::SetIcStatus(unsigned short bgSiteNo, unsigned short xIdx, unsigned short yIdx, int kind, unsigned char status, bool hasToSend)
// xIdx�̑傫���`�F�b�N
// yIdx�̑傫���`�F�b�N
//this->frmAreaX	//�g�p��G���AX(�g�p����w��)
//this->frmAreaY	// �g�p��G���AY(�g�p����x��)
//
{
	//#THAIHV170818 Add Locate Edit (S)
	unsigned short maxX, maxY;
	if (isSubComplex) {
		maxX = this->pCplxWaferD->GetBgLocateArrayX(bgSiteNo);
		maxY = this->pCplxWaferD->GetBgLocateArrayY(bgSiteNo);
	} else {
		maxX = this->frmAreaX;
		maxY = this->frmAreaY;
	}
	//#THAIHV170818 Add Locate Edit (E)
	//-------------------------------------
	// �ُ�l�ł����Debug Break
	//if(xIdx==0||yIdx==0||(this->frmAreaX < xIdx)||(this->frmAreaY < yIdx)){
	if(xIdx==0||yIdx==0||(/*this->frmAreaX*/maxX < xIdx) || (/*this->frmAreaY*/maxY < yIdx)){			//#THAIHV170818 Add Locate Edit
		CString msg;
		msg.Format("Error %s(%d) frmAreaX=%d, frmAreaY=%d, xIdx=%d, yIdx=%d", __FILE__, __LINE__, this->frmAreaX, this->frmAreaY, xIdx, yIdx);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	//-------------------------------------
	switch(kind){
	case eBdStsIdx:		// ����
//		if(status == 1){
//			int r = true;
//		}
//		if(status == 2){
//			int r = true;
//		}
		this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].SetBoardSts(status);
		//#THAIHV170818 Add Locate Edit (S)
		// If in complex mode
		if (isSubComplex) {
			if (hasToSend) {
				switch (status) {
				case BadMark:
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(DET_BAD_L, bgSiteNo, xIdx, yIdx);		// left side
					break;
				case GoodMark:
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(DET_GOOD_L, bgSiteNo, xIdx, yIdx);		// left side
					break;
				default:
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(DET_UNKN_L, bgSiteNo, xIdx, yIdx);		// left side
					break;
				}
			}
		}
		//#THAIHV170818 Add Locate Edit (E)
		break;
	default:			// �{���f�B���O���
		this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].SetBondSts(status);
		//#THAIHV170818 Add Locate Edit (S)
		// If in complex mode
		if (isSubComplex) {
			if (hasToSend) {
				switch (status) {
				case HasToBond:
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_NDONE_L, bgSiteNo, xIdx, yIdx);		// left side
					break;
				case FailedToBond:
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_FAIL_L, bgSiteNo, xIdx, yIdx);		// left side
					break;
				// #DDT140306: Add case for bond by operator
				case SucceededToBondByOp:
				case SucceededToBond:
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_DONE_L, bgSiteNo, xIdx, yIdx);		// left side
					break;
				case OnStack:
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_STACK_L, bgSiteNo, xIdx, yIdx);		// left side
					// Report stack count to BLE
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(STACK_COUNT_L + frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].GetStackedCount(), bgSiteNo, xIdx, yIdx);
					break;
				default:
					pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_SKIP_L, bgSiteNo, xIdx, yIdx);		// left side
					break;
				}
			}
		}
		//#THAIHV170818 Add Locate Edit (E)
		break;
	}
	return true;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �ڰя�̊�ɂ�����h�b�������ꂼ��ݒ肷��(�������ĕs��)�B
//
bool FrameIcInfo::SetIcEachStatus(unsigned short bgSiteNo, unsigned short xIdx, unsigned short yIdx, unsigned char mStatus,unsigned char bStatus, bool hasToSend){
	// xIdx�̑傫���`�F�b�N
	// yIdx�̑傫���`�F�b�N
	// �ُ�l�ł����Debug Break
	//this->frmAreaX	//�g�p��G���AX(�g�p����w��)
	//this->frmAreaY	// �g�p��G���AY(�g�p����x��)
	//#THAIHV170818 Add Locate Edit (S)
	unsigned short maxX, maxY;
	if (isSubComplex) {
		maxX = this->pCplxWaferD->GetBgLocateArrayX(bgSiteNo);
		maxY = this->pCplxWaferD->GetBgLocateArrayY(bgSiteNo);
	} else {
		maxX = frmAreaX;
		maxY = frmAreaY;
	}
	//#THAIHV170818 Add Locate Edit (E)

	//if(xIdx==0||yIdx==0||(this->frmAreaX < xIdx) || (this->frmAreaY < yIdx)){
	if(xIdx==0||yIdx==0||(/*this->frmAreaX*/maxX < xIdx) || (/*this->frmAreaY*/maxY < yIdx)){		//#THAIHV170818 Add Locate Edit
		CString msg;
		msg.Format("Error %s(%d) frmAreaX=%d, frmAreaY=%d, xIdx=%d, yIdx=%d", __FILE__, __LINE__, this->frmAreaX, this->frmAreaY, xIdx, yIdx);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].SetBoardSts(mStatus);
	this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].SetBondSts(bStatus);
	//#THAIHV170818 Add Locate Edit (S)
	// If in complex mode 
	if (isSubComplex) {
		if (hasToSend) {
			// Set bond status to BLE
			switch (bStatus) {
			case HasToBond:
				pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_NDONE_L, bgSiteNo, xIdx, yIdx);		// left side
				break;
			case FailedToBond:
				pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_FAIL_L, bgSiteNo, xIdx, yIdx);		// left side
				break;
			// #DDT140306: Add case for bond by operator
			case SucceededToBondByOp:
			case SucceededToBond:
				pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_DONE_L, bgSiteNo, xIdx, yIdx);		// left side
				break;
			case OnStack:
				pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_STACK_L, bgSiteNo, xIdx, yIdx);		// left side
				break;
			default:
				pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(BOND_SKIP_L, bgSiteNo, xIdx, yIdx);		// left side
				break;
			}
			
			// Set board status to BLE
			switch (mStatus) {
			case BadMark:
				pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(DET_BAD_L, bgSiteNo, xIdx, yIdx);		// left side
				break;
			case GoodMark:
				pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(DET_GOOD_L, bgSiteNo, xIdx, yIdx);		// left side
				break;
			default:
				pFrameIcCtrl->sbMapping.m_subInfo.BLECtrl(DET_UNKN_L, bgSiteNo, xIdx, yIdx);		// left side
				break;
			}
		}
	}
	//#THAIHV170818 Add Locate Edit (E)
	return true;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// �i�ςݽ������ı��߂���B
//
void FrameIcInfo::IcStackCountUp(unsigned short bgSiteNo, unsigned short xIdx, unsigned short yIdx){
	//#THAIHV170818 Add Locate Edit (S)
	unsigned short maxX, maxY;
	if (isSubComplex) {
		maxX = this->pCplxWaferD->GetBgLocateArrayX(bgSiteNo);
		maxY = this->pCplxWaferD->GetBgLocateArrayY(bgSiteNo);
	} else {
		maxX = this->frmAreaX;
		maxY = this->frmAreaY;
	}
	//#THAIHV170818 Add Locate Edit (E)
	unsigned char sts;
	int cnt;
	//if(xIdx==0||yIdx==0||(this->frmAreaX < xIdx) || (this->frmAreaY < yIdx)){
	if(xIdx==0||yIdx==0||(/*this->frmAreaX*/maxX < xIdx) || (/*this->frmAreaY*/maxY < yIdx)){				//#THAIHV170818 Add Locate Edit
		CString msg;
		msg.Format("Error %s(%d) this->frmAreaX=%d, this->frmAreaY=%d, xIdx=%d, yIdx=%d", __FILE__, __LINE__, this->frmAreaX, this->frmAreaY, xIdx, yIdx);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].StackedCountUp();
	if((cnt = this->frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].GetStackedCount()) >= this->numberOfStack){
		// ����ިݸލς�
		sts = SucceededToBond;
	}
	else{
		// ����ިݸ޽�����
		sts = OnStack;
	}
	this->SetIcStatus(bgSiteNo, this->nowXIdx, this->nowYIdx, eBgStsIdx, sts);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ���ޯ���ʒu��IC�i����擾����
int	 FrameIcInfo::GetRegNo(int bgSiteNo, int xIdx, int yIdx)
{
//	int x, y;
	CSingleLock S(&this->FrameIcSema, TRUE);
	// ���ޯ����-1�̎��͌��݂̲��ޯ�����g�p����
	//#THAIHV170818 Add Locate Edit (S)
	// In Complex Mode, regNo = bgSiteNo
	if (isSubComplex == eComplexMode) {
		if ((bgSiteNo > 0) && (bgSiteNo <= this->bgSiteNumbers)) {
			return bgSiteNo;
		} else {
			return 1;
		}
	}
	//#THAIHV170818 Add Locate Edit (E)
	if (-1 == xIdx){
		xIdx = this->nowXIdx;
	}
	if (-1 == yIdx){
		yIdx = this->nowYIdx;
	}
	// �ُ�l�ł����Debug Break
//	if(((x = this->frmAreaX) < xIdx) || ((y = this->frmAreaY) < yIdx)){
//		CString msg;
//		msg.Format("Error %s(%d) this->frmAreaX=%d, this->frmAreaY=%d, xIdx=%d, yIdx=%d", __FILE__, __LINE__, this->frmAreaX, this->frmAreaY, xIdx, yIdx);
//		AfxMessageBox(msg);
//		AfxDebugBreak();
//	}
	int regNo = frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].GetRegNo();
	// �i��؂�ւ�����ُ͈�l�������Ă��邱�Ƃ�����(this->nowXIdx��this->nowYIdx���G���A�O)�B���̏ꍇ�͂P��Ԃ��B
	if(regNo <= 0 || regNo > this->regNumbers){
		regNo = 1;
	}
	return regNo;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ���ޯ���ʒu�̽����ϒi�����擾����
//
int	 FrameIcInfo::GetStackedCount(int bgSiteNo, int xIdx, int yIdx)
{
	CSingleLock S(&FrameIcSema, TRUE);
	// ���ޯ����-1�̎��͌��݂̲��ޯ�����g�p����
	if (-1 == xIdx) xIdx = nowXIdx;
	if (-1 == yIdx) yIdx = nowYIdx;
	//#THAIHV170818 Add Locate Edit (S)
	unsigned short maxX, maxY;
	if (isSubComplex) {
		maxX = this->pCplxWaferD->GetBgLocateArrayX(bgSiteNo);
		maxY = this->pCplxWaferD->GetBgLocateArrayY(bgSiteNo);
	} else {
		maxX = this->frmAreaX;
		maxY = this->frmAreaY;
	}
	//#THAIHV170818 Add Locate Edit (E)
	// �ُ�l�ł����Debug Break
	//if((this->frmAreaX < xIdx) || (this->frmAreaY < yIdx)){
	if((/*this->frmAreaX*/maxX < xIdx) || (/*this->frmAreaY*/maxY < yIdx)){				//#THAIHV170818 Add Locate Edit
		CString msg;
		msg.Format("Error %s(%d) this->frmAreaX=%d, this->frmAreaY=%d, xIdx=%d, yIdx=%d",
											__FILE__, __LINE__,
											this->frmAreaX,
											this->frmAreaY,
											xIdx, yIdx);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	// todo �T�u�X�g���[�g�̏ꍇ��bgSiteNo=1�ŁB
	return frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].GetStackedCount();
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ���ޯ���ʒu�̽����ϒi����ݒ肷��
//
void FrameIcInfo::SetStackedCount(int stack, int bgSiteNo, int xIdx, int yIdx)
{
	// ���ޯ����-1�̎��͌��݂̲��ޯ�����g�p����
	if (-1 == xIdx) xIdx = nowXIdx;
	if (-1 == yIdx) yIdx = nowYIdx;
	// �ُ�l�ł����Debug Break
	//#THAIHV170818 Add Locate Edit (S)
	unsigned short maxX, maxY;
	if (isSubComplex) {
		maxX = this->pCplxWaferD->GetBgLocateArrayX(bgSiteNo);
		maxY = this->pCplxWaferD->GetBgLocateArrayY(bgSiteNo);
	} else {
		maxX = this->frmAreaX;
		maxY = this->frmAreaY;
	}
	//#THAIHV170818 Add Locate Edit (E)
	//if((this->frmAreaX < xIdx) || (this->frmAreaY < yIdx)){
	if((/*this->frmAreaX*/maxX < xIdx) || (/*this->frmAreaY*/maxY < yIdx)){			//#THAIHV170818 Add Locate Edit
		CString msg;
		msg.Format("Error %s(%d) this->frmAreaX=%d, this->frmAreaY=%d, xIdx=%d, yIdx=%d", __FILE__, __LINE__, this->frmAreaX, this->frmAreaY, xIdx, yIdx);
		AfxMessageBox(msg);
		AfxDebugBreak();
	}
	frameStsData[bgSiteNo-1][xIdx-1][yIdx-1].SetStackedCount(stack);
}
//#THAIHV170818 Add Locate Edit (S)
void FrameIcInfo::GetRegNoXY(int index, unsigned short& regNo, unsigned short& x, unsigned short& y)
{
	index = index + 1;
	for (int j = 1; j <= 5; j++) {
		index = index - (this->pCplxWaferD->GetBgLocateArrayX(j) * this->pCplxWaferD->GetBgLocateArrayY(j));
		if (index <= 0) {
			index = index + (this->pCplxWaferD->GetBgLocateArrayX(j) * this->pCplxWaferD->GetBgLocateArrayY(j));
			regNo = j;
			break;
		}
	}
	if ((index % this->pCplxWaferD->GetBgLocateArrayX(regNo)) == 0) {
		x = this->pCplxWaferD->GetBgLocateArrayX(regNo);
		y = index / this->pCplxWaferD->GetBgLocateArrayX(regNo);
	} else {
		y = index / this->pCplxWaferD->GetBgLocateArrayX(regNo) + 1;
		x = index % this->pCplxWaferD->GetBgLocateArrayX(regNo);
	}
}

void FrameIcInfo::SetAllIcStatus(int regNo, int target, unsigned char status, bool hasToSend, bool reverse) 
{
	unsigned char bdSts;					// board status
//	unsigned char dsSts;					// dispense status
	unsigned char bgSts;					// bonding status
	unsigned short stackCount;				// stack count
	if (regNo == 0) {
		regNo = this->pCplxWaferD->GetRegNumber();
	}
	for (int i = 1; i <= regNo; i++) {
		int xMax = this->pCplxWaferD->GetBgLocateArrayX(i);
		int yMax = this->pCplxWaferD->GetBgLocateArrayY(i);
		for (int j = 1; j <= yMax; j++) {
			for (int k = 1; k <= xMax; k++) {
				// For reverse ICs' status case
				if (reverse) {
					this->GetIcStatus(i, k, j, bdSts, bgSts, stackCount);
					if (bgSts == HasToBond) {
						// Change from NotDone -> Done
						this->SetIcStatus(i, k, j, target, SucceededToBond, hasToSend);
					} else if (bgSts == SucceededToBond) {
						// Change from Done -> NotDone
						this->SetIcStatus(i, k, j, target, HasToBond, hasToSend);
					} else {
						// Do nothing
					}
				} else {
					this->SetIcStatus(i, k, j, target, status, hasToSend);
				}
			}
		}
	}
}
//#THAIHV170818 Add Locate Edit (E)
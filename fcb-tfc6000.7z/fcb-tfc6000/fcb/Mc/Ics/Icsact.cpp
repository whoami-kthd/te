/*---------------------------------------------------------------------
	��ʋ�������׽�@
								1998 T.Yausda / Toshiba Mechatronics Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

------------------------------------------------------------------*/

#include	<mcc.h>
#include	<iodef.h>
#include	"icsIodef.h"
#include	"resource.h"
#include	"BCR_Input.h"
#include <resource.h>
#include <waferposdisp.h>

//////////////////////////////////////////////////////////////////////
/// �_�~�[���[�h
BOOL ICSCtrl::WfDummyMode()
{
	return(pMCC->GetDummyMode());
}

//////////////////////////////////////////////////////////////////////
/// �_�~�[���[�h
bool ICSCtrl::IsPickVacDummyMode()
{
	// �w�b�h�z������а�Ȃ�A���]�������l�Ƃ���
	return(pMCC->DD.ModeD.DummyModeFlag && !pMCC->DD.ModeD.HeadVacTest);
}

///////////////////////////////////////////////////////////////////////////////
//	ܰ�ݸ�ү���ޕ\��
///////////////////////////////////////////////////////////////////////////////
void	ICSCtrl::Warning_msg(int no)
{
	CSingleLock W(&WarnSema);
	if(no == Err_PushPinUse_W && !WarnOut[0]) {			//�ˏグ��ݎg�p�񐔌x��
		WarnFlag |= 0x0001;
		WarnOut[0] = 1;
	} else if(no == Err_ColletUse_W && !WarnOut[1]) {	//���]�ƯĺگĎg�p�񐔌x��
		WarnFlag |= 0x0002;
		WarnOut[1] = 1;
	} else if(no == Err_WAFER_L1_W && !WarnOut[2]) {	//�E�F�n���˓_�����Ԍx��
		WarnFlag |= 0x0004;
		WarnOut[2] = 1;
	} else if(no == Err_WAFER_L2_W && !WarnOut[3]) {	//�E�F�n�Ό��_�����Ԍx��
		WarnFlag |= 0x0008;
		WarnOut[3] = 1;
	}
	if(WarnFlag){
		this->pauseWait.SetPauseOnly();
	}
}

//////////////////////////////////////////////////////////////////////
// BCR�֘A
//
BOOL	ICSCtrl::BCRInputInit()
{
	BOOL r = TRUE;
	if (1 == pMCC->MD.OptionD.HandyBarCodeReader) {
		if (r) r = pBCR_INP->Init(TRUE);
	} else {
		if (r) r = pBCR_INP->Init(FALSE);
	}
	return r;
}
// �E�F�n�}�K�W��ID�o�[�R�[�h�ǂݍ���
const char *ICSCtrl::GetWfMgzID()
{
	if (1 == pMCC->MD.OptionD.HandyBarCodeReader
		&& this->wfStage.IsWfMappingMode(0, 0)) {
		return(this->wfStage.MappingPD.WfMgzID);
	} else {
		return("");
	}
}
//////////////////////////////////////////////////////////////////////
// �C�I�i�C�U�֘A
//
// Pickup���C�I�i�C�U�ُ�`�F�b�N
BOOL	ICSCtrl::IsOkPickPosIonizer(){
	BOOL isOk = TRUE;
#if !GPDEBUG
	if(pMCC->MD.OptionD.PickupPosIonizer){
		bool isAlarmed = false;
		isOk = pMCC->DIO_Input(IO_PickupPosIonizerAlarm_IN, isAlarmed);
		if (!isOk) {
			pMCC->PutErrorCode(Err_PickPosIonizerAlarm,BND_ID);
			isOk = false;
		}
		else if((pMCC->MD.OptionD.PickupPosIonizer == eIonAbnormalON)&&(isAlarmed)){
			pMCC->PutErrorCode(Err_PickPosIonizerAlarm,BND_ID);
			isOk = false;
		}
		else if((pMCC->MD.OptionD.PickupPosIonizer == eIonNormalON)&&(!isAlarmed)){
			pMCC->PutErrorCode(Err_PickPosIonizerAlarm,BND_ID);
			isOk = false;
		}
	}
#endif
	return isOk;
}


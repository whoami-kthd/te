#include "RFIDCtrl.h"

CRFIDReader::CRFIDReader(){

} 

CRFIDReader::~CRFIDReader(){

}

CRFIDReader::CRFIDReader(CString name):
								m_cidrw640(){
	this->name = name;
}

BOOL CRFIDReader::StartComunicattion(){
	BOOL r	= TRUE;

	this->m_cidrw640.SetCommPara("COM1",9600,8,0,0,0);		// Setting & open port

	r = this->m_cidrw640.CIDRW640CommStart();				// Start thread for communicating

	return r;
}

CString CRFIDReader::GetCarrierId(unsigned short device_id){
	CString carrierID	= "";
	BOOL r	= TRUE;
	
	// Set device id: from 1 to 31
	this->m_cidrw640.setDeviceID(device_id);
	// Clear page spec -> set pageSpec 0,1->write data into m_SendFormatData (comCode 0101)
	this->m_cidrw640.SetCarrierIdReadCommand();
	this->m_cidrw640.SetSendStartEvent();

	r = this->m_cidrw640.WaitCIDRW640SendEndEvent();
	if(r){
		carrierID = this->m_cidrw640.getCarrierId();
	}

	return carrierID;
}

CString CRFIDReader::GetSinglePageData(unsigned short device_id,int page_no){
	CString pageData	= "";
	BOOL r	= TRUE;

	this->m_cidrw640.setDeviceID(device_id);
	this->m_cidrw640.SetSinglePageReadCommand(page_no);
	this->m_cidrw640.SetSendStartEvent();

	r = this->m_cidrw640.WaitCIDRW640SendEndEvent();
	if(r){
		CString pageData = this->m_cidrw640.getSinglePageData(page_no);
	}

	return pageData;
}

BOOL CRFIDReader::WriteDataToSinglePage(unsigned short device_id,int page_no){
	BOOL r	= TRUE;
	CString writeData = "00000000";	// 8 characters

	this->m_cidrw640.setDeviceID(device_id);
	this->m_cidrw640.SetSinglePageWriteCommand(page_no, writeData);
	this->m_cidrw640.SetSendStartEvent();

	r = this->m_cidrw640.WaitCIDRW640SendEndEvent();

	return r;
}

BOOL CRFIDReader::EndComunication(){
	return this->m_cidrw640.CIDRW640CommEnd();
}

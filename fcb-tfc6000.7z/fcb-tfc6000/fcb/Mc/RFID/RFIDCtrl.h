// RFIDCtrl.h: CRFIDCtrl �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(_CRFIDCTR_H)
#define _CRFIDCTR_H

#include	"CIDRW640.h"

class CRFIDReader{

public:
	CRFIDReader();
	virtual ~CRFIDReader();
	CRFIDReader(CString name);

public:
	CCIDRW640		m_cidrw640;

private:
	CString			name;

public:
	// Get carrier ID of device and convert to CString
	CString GetCarrierId(unsigned short device_id);
	// Get data from single page
	CString GetSinglePageData(unsigned short device_id,int page_no);
	// Write data into sigle page
	BOOL WriteDataToSinglePage(unsigned short device_id,int page_no);
	// Start communication
	BOOL StartComunicattion();
	// End comunication
	BOOL EndComunication();
};

#endif // !defined(_CRFIDCTR_H)
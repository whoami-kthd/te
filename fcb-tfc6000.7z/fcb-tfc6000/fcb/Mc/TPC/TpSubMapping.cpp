/*---------------------------------------------------------------------
	������ِ���׽�@��}�b�s���O�֘A

---------------------------------------------------------------------*/
#include "mcc.h"
#include "tpc.h"
#include "tpctrl.h"
#include "BL600.h"
#include	"resource.h"
#include	"BCR_Input.h"


/////////////////////////////////////////////////////////////////////////////
// �o�[�R�[�h����
BOOL TPCtrl::SubMap_OpeBarCodeInput(int Mode)
{
	enum {
		SNo				= 5055,	// ���No.
		//
		AttIdx			= 700,	// �ҏW
		AttAdr			= 702,	// �ҏW�f�[�^�A�h���X
		Ttl				= 704,	// ���ٕ\��������
		TtlMax			= 20,	//
		Msg				= 714,	// ү���ޕ\��������
		MsgMax			= 40,	//
		BarCode			= 734,	// �o�[�R�[�h
		BarCodeMax		= 32,	//
		ErrMsg			= 750,	// �G���[���b�Z�[�W
		//
		KeyEnter		= 65,	// �o�^���s
		KeyCancel		= 66,	// �L�����Z��
		KeyBzOff		= 67,	// �u�U�[�n�e�e
		KeyRead			= 68,	// �o�[�R�[�h�ǂݍ���
		KeyBarCode		= 69,	// �o�[�R�[�h����
		KeyInput		= 70,	// ���͊���
		//
		MaxMode			= 1,

	};
	const char *msg[][2][2] = {
		//     12345678901234567890		 1234567890123456789012345678901234567890
		{
			{ "�o�[�R�[�h�ǎ�G���[",	"�o�[�R�[�h��ݒ肵�Ă�������" },
			{ "Bar Code Read Error",	"Set Bar Code Data" },
		},
		{
		//     12345678901234567890		 1234567890123456789012345678901234567890
			{ "Lot No              ",	"���϶޼�݂�Lot No.��ݒ肵�Ă�������" },
			{ "Lot No              ",	"Set Lot No. of Wafer Magazine" },
		},
		{
		//     12345678901234567890		 1234567890123456789012345678901234567890
			{ "BgSite %d           ",	"�}�b�s���O��ݒ肵�Ă�������" },
			{ "BgSite %d           ",	"Setting mapping data" },
		},
		{
		//     12345678901234567890		 1234567890123456789012345678901234567890
			{ "Offset              ",	"Set offset data" },			//#Ducmv 20150821 Set offset input
			{ "Offset              ",	"Set offset data" },
		}
	};
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	if( Mode == 3 ){                                 //#Ducmv 20150821 SECS S75/76
		//do nothing
	} else if (1 == pMCC->MD.OptionD.HandyBarCodeReader) {
		if (1 == Mode) {
			pMCC->BND.frame.MappingPD.WfMgzID = "";
		} else {
			Mode = 1;
		}
	}
	CString tmp = CString(msg[Mode][Lang][0]);
	if (Mode == 3){                                 //#Ducmv 20150821 SECS S75/76
		tmp = CString(msg[Mode][Lang][0]);
	} else if (pMCC->MD.OptionF.isCowMapping && pMCC->BND.frame.GetBondingSiteMode()) {
		Mode = 2;
		tmp.Format(msg[Mode][Lang][0], pMCC->BND.GetNowBgSiteNo());
	} else {
		tmp = CString(msg[Mode][Lang][0]);
	}
	tpc.GpPutStrLen(Ttl, tmp, TtlMax);
	tpc.GpPutStrLen(Msg, msg[Mode][Lang][1], MsgMax);
	tpc.GpPutStrLen(BarCode, "", BarCodeMax);
	const char *ErrMsg1, *ErrMsg2;
	if (0 == Mode) {
		ErrorMessageGet(pMCC->BND.frame.MappingWD.BarCodeErr, BND_ID, &ErrMsg1, &ErrMsg2);
	} else if (3 == Mode){
		ErrMsg1 = "Input CSV file name";					//#Ducmv 20150824 SECS S75/76
	} else {
		ErrMsg1 = "";
	}
	tpc.GpPutStrLen(ErrMsg,(char *)ErrMsg1,60);
	int SaveSNo = tpc.GetGpScreen();	// ���No.�̕ۑ�
	tpc.GpPut16(AttIdx, 0);
	SecsAlm(pMCC->BND.frame.MappingWD.BarCodeErr, BND_ID, true);	// �G���[����
	tpc.GpScreenDisp(SNo);				// ��ʐ؂�ւ�
	BOOL r = FALSE;
	int idx = 0;
	char Buf[BlRcvBufMax];
	for (;;) {
		int key = KeyWait();
		if (key) {
			tpc.GpBeep();
		} else {
			continue;
		}
		if (KeyStopSW == key) {	// ��~SW�m�F
			r = FALSE;
			break;
		} else if (KeyEnter == key) {	// �m��
			tpc.GpGetStr(BarCode, Buf, BarCodeMax);
			CString BC = Buf;
			BC.TrimRight();
			if (BC.GetLength()) {
				if (Mode ==3) {
					pMCC->BND.frame.MappingPD.StsOffset = 0;
				} else {
					pMCC->BND.frame.MappingPD.StsBarCode = 1;
				}
			}
			if (Mode == 3){									//#Ducmv 20150821 SECS S75/76
				pMCC->BND.frame.MappingPD.OffsetCode = BC;
			} else if (pMCC->MD.OptionD.hasASubHandyBarCodeReader) {
				pMCC->BND.frame.MappingPD.WfMgzID = BC;
			} else {
				pMCC->BND.frame.MappingPD.BarCode = BC;
			}
			r = TRUE;
			break;
		} else if (KeyCancel == key) {	// �L�����Z��
			if (Mode ==3) {
				pMCC->BND.frame.MappingPD.StsOffset = 0;
			} else {
				pMCC->BND.frame.MappingPD.StsBarCode = 0;
			}
			r = FALSE;
			break;
		} else if (KeyBzOff == key) {	// �u�U�[�n�e�e
			pMCC->op.OprBzzA(pMCC->op.Off);
			pMCC->op.OprBzzB(pMCC->op.Off);
		} else if (KeyRead == key) {	// �o�[�R�[�h�ēǂݍ���
			if (idx || (Mode == 3)) continue;		// #DDT(150904): Don't retry read barcode if input csv file name
			tpc.GpPut16(AttIdx, idx = 1);
			tpc.GpPutStrLen(BarCode, "", BarCodeMax);
			tpc.GpPutStrLen(ErrMsg, "", 60);
			if (pMCC->MD.OptionD.BL600_COM) {
				int	error = 0;
				r = pMCC->BND.frame.sbMapping.barcode.BarCodeRead(Buf, &error);
				pMCC->BND.frame.MappingWD.BarCodeErr	= BNDCtrl::Err_BarCodeStart + error;
			} else if (pMCC->MD.OptionD.HandyBarCodeReader) {
				CString BC = pBCR_INP->GetBarCode(true);
				int len = BC.GetLength();
				if (0 >= len || 15 < len) {
					r = FALSE;
					pMCC->BND.frame.MappingWD.BarCodeErr = BNDCtrl::Err_Bl6Other;
				} else {
					strcpy(Buf, BC);
					r = TRUE;
				}
			} else {
				r = FALSE;
			}
			if (r) {
				tpc.GpPutStrLen(ErrMsg, "", 60);
			} else {	// �ǂݍ��ݎ��s
				ErrorMessageGet(pMCC->BND.frame.MappingWD.BarCodeErr, BND_ID, &ErrMsg1, &ErrMsg2);
				tpc.GpPutStrLen(ErrMsg, (char *)ErrMsg1, 60);
			}
			tpc.GpPut16(AttIdx, idx = 0);
		} else if (KeyBarCode == key) {	// �o�[�R�[�h�f�[�^�ݒ�
			if (0 != idx && 2 != idx) continue;
			if (0 == idx) {
				tpc.GpPut16(AttAdr, BarCode);
				tpc.GpPut16(AttIdx, (idx = 2) | 0x8000);
			} else {
				tpc.GpPut16(AttIdx, idx = 0);
			}
		} else if (KeyInput == key) {	// ���͊���
			if (0 == idx) continue;
			tpc.GpPut16(AttIdx, idx = 0);
		}
	}
	pMCC->op.OprBzzA(pMCC->op.Off);
	pMCC->op.OprBzzB(pMCC->op.Off);
	SecsAlm(BNDCtrl::Err_MapBarCode, BND_ID, false);	// �G���[����
	tpc.GpScreenDisp(SaveSNo);
	return(r);
}


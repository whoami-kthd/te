/*---------------------------------------------------------------------
	������ى�ʊ֐��i�i���ް�:�{���h�`�F�b�N�j

	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_BondChk(int step,int page)
{
	int OptIdx = 0;
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r=OK_END;
	for(;;){
		if(step == 0){		// �ް��ݒ�
			if(page ==1)		r = DVd_BondChk1();
			else				r = Data1_END;
		} else {				// è��ݸ�
			if(page == 1)		r = DVt_BondChk1();
			else				r = Teach1_END;
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}


////////////////////////////////////////////////////////////////////////////////-
// �{���h�`�F�b�N�i�f�[�^�ݒ�j
int TPCtrl::DVd_BondChk1()
{
	enum {
		// ��ʔԍ�
		SNo					= 1800,		// ���No.     
		AttBondCheckOn		= 206,	
		AttBondCheckOff		= 207,
		AttErrorOn			= 208,
		AttErrorOff			= 209,

		M					= 310,	
		MCoarse				= 300,	
		LvA					= 320,	
		LvB					= 330,	
		Threshold			= 340,
		Delay				= 350,	
		Retry				= 390,
		//                          
		KeyM				= 65,	
		KeyMCoarse			= 66,
		KeyConThr			= 67,
		KeyBCheckOn			= 68,
		KeyBCheckOff		= 69,
		KeyErrorOn			= 70,
		KeyErrorOff			= 71,
		KeyRetry			= 72,
		KeyLvA				= 80,	
		KeyLvB				= 81,	
		KeyDelay			= 82,	
		//
		//
		KeyHome			= '0'	,
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyData1				,
		KeyData2				,
		KeyData3				,
		KeyData4				,
		KeyData5				,
	};

	int	r = KeyPrev;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int isDieBond;
	pMCC->GetProcess(isDieBond);
	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		
		for(;;){
			/////////////////////
			
			/////////////////////
			
			tpc.GpPut16(AttBondCheckOn, pMCC->BND.MD.BondCheckD.isBondCheck ? ATTR_B00 : ATTR_B01);
			tpc.GpPut16(AttBondCheckOff, !pMCC->BND.MD.BondCheckD.isBondCheck ? ATTR_B00 : ATTR_B01);
			tpc.GpPut16(AttErrorOff, !pMCC->BND.MD.BondCheckD.isErrorSkip ? ATTR_B00 : ATTR_B01);
			tpc.GpPut16(AttErrorOn, pMCC->BND.MD.BondCheckD.isErrorSkip ? ATTR_B00 : ATTR_B01);
			/////////////////////
			// �F���p�����[�^�̎擾
//			double contrastThr	= pMCC->BND.MD.BCCamD.spara.ContrastThr;
			double contrastThr	= pMCC->BND.bondCheckCamera.pBCCalibD.spara.ContrastThr;
			double	AcceptThr[2];
			AcceptThr[0] = pMCC->BND.bondCheckCamera.pBCCalibD.spara.AcceptThr[0] * 100;
			AcceptThr[1] = pMCC->BND.bondCheckCamera.pBCCalibD.spara.AcceptThr[1] * 100;
			DataPut(M,				AcceptThr[1], 10);		// ��F���}�b�`���O��(�ڍ�)
			DataPut(MCoarse,		AcceptThr[0], 10);		// ��F���}�b�`���O��(�e)
			DataPut(Threshold,		contrastThr, 1);			// �w�b�h�F������
			DataPut(LvA,pMCC->BND.bondCheckCamera.pBCCalibD.lightLevel.A);
			DataPut(LvB,pMCC->BND.bondCheckCamera.pBCCalibD.lightLevel.B);
			DataPut(Delay,pMCC->BND.bondCheckCamera.pBCCalibD.dTime);
			DataPut(Retry,pMCC->BND.MD.BondCheckD.RecogRetry);
		
		
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			if(KeyM == key){
				const char *msg[] = {
					"�}�b�`���O��(�ڍ�)",
					"Matching Ratio (Fine)",
				};
				///////////////
				// �ް��ҏW
				if(DataEdit(msg[Lang],"%", AcceptThr[1], 0, 100, 10)){
					DataPut(M, AcceptThr[1], 10);
					pMCC->BND.bondCheckCamera.pBCCalibD.spara.AcceptThr[1] = AcceptThr[1] / 100;
					DataUpdate = TRUE;
				}
			}
			////////////////////////////
			// �}�b�`���O���ݒ�i�e�j
			else if(KeyMCoarse == key){
				const char *msg[] = {
					"�}�b�`���O��(�e)",
					"Matching Ratio (Coares)",
				};
				///////////////
				// �ް��ҏW
				if(DataEdit(msg[Lang],"%", AcceptThr[0], 0, 100, 10)){
					DataPut(MCoarse, AcceptThr[0], 10);
					pMCC->BND.bondCheckCamera.pBCCalibD.spara.AcceptThr[0] = AcceptThr[0] / 100;
					DataUpdate = TRUE;
				}
			}
			else if(KeyLvA == key){
				const char *msg[] = {
					"�c�[���F�����ˏƖ�����",
					"Bond Check Camera Vertical Level",
				};
				///////////////
				// �f�[�^�ҏW
				if (DataEdit(msg[Lang],"dig",pMCC->BND.bondCheckCamera.pBCCalibD.lightLevel.A,0,LIGHTLEVEL_MAX)){
					DataPut(LvA,pMCC->BND.bondCheckCamera.pBCCalibD.lightLevel.A);	
					DataUpdate = TRUE;
				}
			}
			////////////////////////////
			// �Ό��Ɩ����x���ݒ�
			else if(KeyLvB == key){
				const char *msg[] = {
					"�c�[���F���Ό��Ɩ�����",
					"Bond Check Camera Oblique Level",
				};
				///////////////
				// �f�[�^�ҏW
				if (DataEdit(msg[Lang],"dig",pMCC->BND.bondCheckCamera.pBCCalibD.lightLevel.B,0,LIGHTLEVEL_MAX)){
					DataPut(LvA,pMCC->BND.bondCheckCamera.pBCCalibD.lightLevel.B);	
					DataUpdate = TRUE;
				}
			}
				else if(KeyConThr == key){
				const char *msg[] = {
					"Contrast Threshold",
					"Contrast Threshold",
				};
				///////////////
				// �f�[�^�ҏW
				int Min = 0;
				int Max = 255;
				if (DataEdit(msg[Lang],"",contrastThr,Min,Max)){
					DataPut(Threshold,contrastThr);	
					pMCC->BND.bondCheckCamera.pBCCalibD.spara.ContrastThr = contrastThr;
					DataUpdate = TRUE;
				}
			}
			////////////////////////////
			// �F���f�B���C�i1�j
			else if(KeyDelay == key){
				const char *msg[] = {
					"Recognition Time Delay",
					"Recognition Time Delay",
				};
				///////////////
				// �f�[�^�ҏW
				double Min = 0.0;
				double Max = 3.0;
				if (DataEdit(msg[Lang],"sec",pMCC->BND.bondCheckCamera.pBCCalibD.dTime,Min,Max)){
					DataPut(Delay,pMCC->BND.bondCheckCamera.pBCCalibD.dTime);					
					DataUpdate = TRUE;
				}
			}
			else if(KeyRetry == key){
				const char *msg[] = {
					"Recognition Retry",
					"Recognition Retry",
				};
				///////////////
				// �f�[�^�ҏW
				double Min = 0;
				double Max = 4;
				if (DataEdit(msg[Lang],"",pMCC->BND.MD.BondCheckD.RecogRetry,Min,Max)){
					DataPut(Retry,pMCC->BND.MD.BondCheckD.RecogRetry);					
					DataUpdate = TRUE;
				}
			}
			else if(KeyBCheckOn == key){
				if(!pMCC->BND.MD.BondCheckD.isBondCheck){
					pMCC->BND.MD.BondCheckD.isBondCheck = 1;
					DataUpdate = TRUE;
				}else{
					//Do nothing
				}
				
			}
			else if(KeyBCheckOff == key){
			
				if(pMCC->BND.MD.BondCheckD.isBondCheck){
					pMCC->BND.MD.BondCheckD.isBondCheck = 0;
					DataUpdate = TRUE;
				}else{
					//Do nothing
				}
			}
			else if(KeyErrorOn == key){
				if(!pMCC->BND.MD.BondCheckD.isErrorSkip){
					pMCC->BND.MD.BondCheckD.isErrorSkip = 1;
					DataUpdate = TRUE;
				}else{
					//Do nothing
				}
				
			}
			else if(KeyErrorOff == key){
			
				if(pMCC->BND.MD.BondCheckD.isErrorSkip){
					pMCC->BND.MD.BondCheckD.isErrorSkip = 0;
					DataUpdate = TRUE;
				}else{
					//Do nothing
				}
			}
			else if(KeyPrev == key){
				End = TRUE;
				r =	Prev_END;
			}
			else if(KeyHome == key){
				End = TRUE;
				r = Home_END;
			}
			else if(KeyTeach == key){
				End = TRUE;
				r = Teach2_END;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �ް�����
		pMCC->BND.MD.BondCheckD.DataRW(pMCC->C8200, FALSE , pMCC->BND.MD.FName);
		pMCC->BND.bondCheckCamera.pBCCalibD.DataRW(FALSE,pMCC->BND.MD.FName,pMCC->BND.MD.Sec,1);
	}
	return r;
}

/////////////////////////////////////////////////////////////////////////////
//----- �{���h�`�F�b�N�i�e�B�[�`���O�j
int TPCtrl::DVt_BondChk1()
{
	enum{
		SNo			= 1805,		// ���No.

		Msg					= 160,	// ү���ޕ\��������

		MXX					= 300,		// �{�� XX
		MXY					= 302,		// �{�� XY
		MYX					= 304,		// �{�� YX
		MYY					= 306,		// �{�� YY
		MXXUNIT				= 308,		// �{�� XX�P��
		MXYUNIT				= 310,		// �{�� XY�P��
		MYXUNIT				= 312,		// �{�� YX�P��
		MYYUNIT				= 314,		// �{�� YY�P��

		KeyEnter			= 'A'	,	// �o�^���s
		KeyCancel				,
		KeyBC					,	// ��¶��
		KeyIC					,	// IC���
		KeyDC					,	// �f�B�X�y���X��¶��
		KeyCursor				,	// ���وړ�
		KeyIVC					,	// IC�z��
		KeyBVC					,	// ��z��
		KeyBClmp		= 75	, 	// Bð�߸����(�J/��)

		AttEnter			= 200,	// �o�^���s
		AttCancel				,
		AttBC					,	// ��¶��
		AttIC					,	// IC���
		AttDC					,	// �f�B�X�y���X��¶��
		AttCursor				,	// ���وړ�
		AttIVC					,	// IC�z��
		AttBVC					,	// ��z��
		AttBClmp			= 210,	// Bð�߸����(�J/��)

		KeyHome			= '0'	,
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyTeach1				,
		KeyTeach2				,
		KeyTeach3				,
		KeyTeach4				,
		KeyTeach5				,

		KeyPatternSetup		= 80,
		AttPatternSetup		= 207,
		KeyTeachPanel		= 52,
	};

	int	 r = KeyPrev;
	double	keta;
	BOOL	DataUpdate=FALSE;

	const char*	Emsg[]=	{	"Please press [Set-up / Done]            ",
							"1/3 Setup & Select Unique Pattern       ",
							"2/3 Eye-point Pattern Left Up	         ",
							"3/3 Confirm teaching process is OK or not ",
						};

	const char*	EmsgEng[]=	{	"Please press [Set-up / Done]            ",
								"1/3 Setup & Select Unique Pattern       ",
								"2/3 Eye-point Pattern Left Up	         ",
								"3/3 Confirm Teaching is OK or not ",
							};

	int	Cam = BondChkCamNo;

	int maxstep = 4;
	bool doCalibPosCnv = true;

	BNDCtrl::MC_Data::CameraData::CamData	*pCD=&pMCC->BND.MD.CameraD.IC;
	pMCC->CameraSelect(Cam);
	pMCC->BND.LightSelect(1,Cam, BNDCtrl::SP_LightLevel);
	tpc.GpPut16(AttDC,0);
	tpc.GpPut16(AttBC,ATTR_SEL);
	tpc.GpPut16(AttIC,0);
	tpc.GpPut16(AttCancel	,0);
	tpc.GpPut16(AttEnter	,0);
	tpc.GpPut16(AttCursor	,0);
	tpc.GpPut16(AttPatternSetup,	0);
	tpc.GpScreenDisp(SNo);

	for(;;){
		BOOL	End=FALSE;
		bool On;
		int	 ECnt=0;
		
		int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

		if (pMCC->C8200.Camera_Info[Cam].deform) {
			keta = 1;
			for (int i=0; i<4; i++)	tpc.GpPut16(MXXUNIT+2*i, 1);
		} else {
			keta = 1000;
			for (int i=0; i<4; i++)	tpc.GpPut16(MXXUNIT+2*i, 0);
		}
		DataPut(MXX,pCD->MX.X()*keta,10000);
		DataPut(MXY,pCD->MX.Y()*keta,10000);
		DataPut(MYX,pCD->MY.X()*keta,10000);
		DataPut(MYY,pCD->MY.Y()*keta,10000);

		tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0], 40);		// ү���ޕ\��

		bool ModelInput = false;
		for(;;){
			int rtn;
			rtn = pMCC->BND.bond.HeadIcVacuumSns(On);
			tpc.GpPut16(AttIVC, (rtn && On) ? ATTR_S0 : ATTR_S1);

			rtn = pMCC->BND.BgStgVacuum.Sns(true, On);
			tpc.GpPut16(AttBVC, (rtn && On) ? ATTR_S0 : ATTR_S1);

			BOOL	Restart=FALSE;

			int	key;
			int	Axis_Sw = BGH_XY | BGH_Z | CAM_XY | CAM_Z | STG_XY;
			key = KeyWait_Adjust_BND_STAGE_CAMERA(TRUE,eAdjMode_Normal,0,0,Axis_Sw);	//�@��ެ�ċ@�\�t��������
			if(key)	tpc.GpBeep();

			if(key == KeyEnter){
				bool	isAlreadyPatternSetUp = true;
				if (ECnt == 1 || ECnt == 2 || ECnt == 3) {
					if(!ModelInput){
						const char* msg[] = {
							"�p�^�[����ݒ肵�Ă��������B",
							"Please Set the Pattern.",
						};
						isAlreadyPatternSetUp = false;
						Warn(msg[Lang]);
					}
				}

				if(isAlreadyPatternSetUp){
					ECnt ++;
					if(maxstep > ECnt){
						bool hasToSetIndexAutomatic = true;
						tpc.GpPut16(AttEnter	,ATTR_SEL);
						tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[ECnt] : Emsg[ECnt], 40);		// ү���ޕ\��
					
						if (ECnt == 2) {			//KTV#170830 Get top-left of first LED
							R2Pos P=R2Pos(0,0), R;
							// ���ف{�۽ͱ���ٕ\��
							r = pMCC->BND.PointInput(Cam,2,P,R,true);	// �ׯ��ްقɂ���߲�ē���								  
							if (r) {
								pMCC->BND.WD.ICTopLeftPoint.x = P.x;
								pMCC->BND.WD.ICTopLeftPoint.y = P.y;
							}
							else {
								const char* msg[] = {
									"Teaching is NG, please execute again !!!",
									"Teaching is NG, please execute again !!!",
								};
								Warn(msg[Lang]);									
							}
						}

						if(ECnt == 3) {		// KTV#170829 Confirm teaching process is OK or not
							r = IsTeachingLEDOK();
							if (!r) {		// teaching process is NG
								const char* msg[] = {
									"Teaching is NG, please execute again !!!",
									"Teaching is NG, please execute again !!!",
								};
								Warn(msg[Lang]);
							}
						}
					}
					else{
						tpc.GpPut16(AttEnter	,0);
						tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0], 40);		// ү���ޕ\��
						ECnt = 0;
						DataUpdate = false;
						Restart = true;
						// �f�[�^������
//						pMCC->BND.DD.BGlobalAlignD.DataRW(pMCC->C8200, FALSE , pMCC->BND.DD.FName);
					}
				}
			} else if (key == KeyPatternSetup) {	// KTV#170828: Add key pattern setup
				
				tpc.GpPut16(AttPatternSetup , ATTR_SEL);
				pMCC->BND.DD.ToolPickRecD.ToolPickModelD.Train(pMCC->BND.DD.ToolPickRecD, pMCC->C8200, 1, 1);
				DataUpdate = true;
				ModelInput = TRUE;
				
				tpc.GpPut16(AttPatternSetup , 0);

			} else if (key == KeyTeachPanel) {		// KTV#170828: Change to pickup teach before
				Step = 1;
				End = TRUE;
			} else if(key == KeyCursor && ECnt >= 1){		// ���وړ�
				MCC_Action_Call	A(pMCC);	// ����J�n���w��	�޽�׸��ŏI�����w��
				tpc.GpPut16(AttCursor	,ATTR_SEL);		// �I�����
				pMCC->BND.CameraMagInp(Cam);			// ���وړ�
				tpc.GpBeep();
				tpc.GpPut16(AttCursor	,0);			// ��I�����
				DataUpdate = TRUE;
			} else if(key == KeyCancel){
				tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
				pMCC->BND.CameraMagTeach(Cam,-1);		// ��ݾ�
				if(DataUpdate)
					pMCC->BND.MD.CameraD.DataRW(pMCC->C8200,TRUE,pMCC->BND.MD.FName);
				tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
				DataUpdate = FALSE;
				Restart = TRUE;
			} else if(ECnt == 0){	// �o�^���s�y�ъm�F���ł͂Ȃ�
				if(key == KeyPrev){
					End = TRUE;
					r = Prev_END;
				} else if(key == KeyHome){
					End = TRUE;
					r = Home_END;
				} else if(key == KeyData){
					End = TRUE;
					r = Data1_END;	// �ް��ݒ��߰��1��
				} else if(KeyTeach1 <= key && key <= KeyTeach5){
					End = TRUE;
					r = Teach1_END + key - KeyTeach1;
				} 
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}

	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.frame.DVDataRW(FALSE,pMCC->BND.DD.FName, pMCC->BND.DD.Sec);
		pMCC->BND.DD.BGlobalAlignD.DataRW(pMCC->C8200, FALSE , pMCC->BND.DD.FName);
	}
	
	return	r;
}
/*---------------------------------------------------------------------
	������ى�ʊ֐��i�i���ް�:˰��j
								1997 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

#include	"SDC10.h"
extern CSDC10	g_CSDC10;	// �O���[�o���ɂ��Ȃ��ƒʐM�s�\�B�����͕s��

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_Heater(int step,int page)
{
	int	r=OK_END;
	for(;;){
		if(step == 0){			
			if(page == 1)			r = DVd_Heater1();
			else					r = Data1_END;
		}
		else{
			r = Prev_END;
		}
		//
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		}
		else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}
/////////////////////////////////////////////////////////////////////////////
//----- �ް��ݒ�@�߰��1	
int TPCtrl::DVd_Heater1()
{
	enum {
		// ��ʔԍ�
		SNo1				= 1610,		// ���No. ����F��
		//
		BgHead				= 300,		// Bgͯ��
		BgStg				= 302,		// Bg�ð��
//todo ���̂������Ƃ��ɃR�[�f�B���O���邱�ƁB
		DisStg				= 304,		// Dis�ð��
		// #IK20081030-1(S) TFC6000
		PreHeater			= 306,		// ���˰�
		AftHeater			= 308,		// ���˰�
		R_Heater			= 310,		// 
		// #IK20081030-1(E)
		//
		KeyBgHead			= 65,		// Bgͯ��
		KeyBgStg			= 66,		// Bg�ð��
		KeyDisStg			= 67,		// Dis�ð��
		// #IK20081030-1(S) TFC6000
		KeyPreHeater		= 68,		// ���˰�
		KeyAftHeater		= 69,		// ���˰�
		KeyPreHeater_R		= 70,		// 
		// #IK20081030-1(E)

		// ���ʃ{�^���C���f�b�N�X
		KeyHome				= '0',
		KeyPrev				= '1',
		KeyTeach			= '2',
		KeyData				= '3',
		KeyData1			= '4',
		KeyData2			= '5',
		KeyData3			= '6',
		KeyData4			= '7',
		KeyData5			= '8',
		KeyCancel			= '9',
	};

	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r;
	bool DataUpdate = false;
	tpc.GpScreenDisp(SNo1);	// 	��ʐ؂�ւ�

	for (bool End = false; !End;) {
		DataPut(BgHead,		(0 != pMCC->MD.SDC10D.Node[SDC10_BgHd])		? pMCC->DD.SDC10D.Unit[SDC10_BgHd].SP_Temp		: 0);
		DataPut(BgStg,		(0 != pMCC->MD.SDC10D.Node[SDC10_BgStg])	? pMCC->DD.SDC10D.Unit[SDC10_BgStg].SP_Temp		: 0);
//todo ���̂������Ƃ��ɃR�[�f�B���O���邱�ƁB
		DataPut(DisStg, 0.0);
// #IK20081030-1(S) TFC6000
		DataPut(PreHeater,	(0 != pMCC->MD.SDC10D.Node[SDC10_PreHt])	? pMCC->DD.SDC10D.Unit[SDC10_PreHt].SP_Temp		: 0);
		DataPut(AftHeater,	(0 != pMCC->MD.SDC10D.Node[SDC10_AftHt])	? pMCC->DD.SDC10D.Unit[SDC10_AftHt].SP_Temp		: 0);
// #IK20081030-1(E)
//todo ���̂������Ƃ��ɃR�[�f�B���O���邱�ƁB
		DataPut(R_Heater, 0.0);

		for (bool Restart = false; !Restart && !End;) {
			int key = KeyWait();
			// �z�X�g�ɂ���ă��b�N����Ă���ꍇ�́A�J�ڃ{�^���ȊO�͖����ɂ���B
			if(this->IsLockedByHost(key)){
				continue;
			}
			if (key) tpc.GpBeep();
			switch (key) {
			case KeyBgHead :
				if (0 != pMCC->MD.SDC10D.Node[SDC10_BgHd]) {
					const char* msg[] = {
						"Bgͯ��",
						"Bg Head",
					};
					int	min = pMCC->MD.SDC10D.SP[SDC10_BgHd].Min;
					int	max = pMCC->MD.SDC10D.SP[SDC10_BgHd].Max;
					if (DataEdit(msg[Lang], "��", pMCC->DD.SDC10D.Unit[SDC10_BgHd].SP_Temp, min, max)) {
						DataPut(BgHead, pMCC->DD.SDC10D.Unit[SDC10_BgHd].SP_Temp);
						DataUpdate = true;
						// �ʐM����
						pMCC->SDC10DataSet(CSDC10::SP_WRITE, pMCC->MD.SDC10D.Node[SDC10_BgHd], true, pMCC->DD.SDC10D.Unit[SDC10_BgHd].SP_Temp);
						int val=0, err=0;
						pMCC->SDC10Comm(0, val, err);	// ����M
					}
				} else Warn(OptionDisp[Lang]);
				break;
			case KeyBgStg :
				if (0 != pMCC->MD.SDC10D.Node[SDC10_BgStg]) {
					const char* msg[] = {
						"Bg�ð��",
						"Bg Stage",
					};
					int	min = pMCC->MD.SDC10D.SP[SDC10_BgStg].Min;
					int	max = pMCC->MD.SDC10D.SP[SDC10_BgStg].Max;
					if (DataEdit(msg[Lang], "��", pMCC->DD.SDC10D.Unit[SDC10_BgStg].SP_Temp, min, max)) {
						DataPut(BgStg, pMCC->DD.SDC10D.Unit[SDC10_BgStg].SP_Temp);
						DataUpdate = true;
						// �ʐM����
						pMCC->SDC10DataSet(CSDC10::SP_WRITE, pMCC->MD.SDC10D.Node[SDC10_BgStg], true, pMCC->DD.SDC10D.Unit[SDC10_BgStg].SP_Temp);
						int val=0, err=0;
						pMCC->SDC10Comm(0, val, err);	// ����M
					}
				} else Warn(OptionDisp[Lang]);
				break;
// #IK20081030-1(S) TFC6000
			case KeyDisStg:
//todo ���̂������Ƃ��ɃR�[�f�B���O���邱�ƁB
				Warn(OptionDisp[Lang]);
				break;
			case KeyPreHeater :
				if (0 != pMCC->MD.SDC10D.Node[SDC10_PreHt]) {
					const char* msg[] = {
						"���˰�",
						"Pre-Heater",
					};
					int	min = pMCC->MD.SDC10D.SP[SDC10_PreHt].Min;
					int	max = pMCC->MD.SDC10D.SP[SDC10_PreHt].Max;
					if (DataEdit(msg[Lang], "��", pMCC->DD.SDC10D.Unit[SDC10_PreHt].SP_Temp, min, max)) {
						DataPut(PreHeater, pMCC->DD.SDC10D.Unit[SDC10_PreHt].SP_Temp);
						DataUpdate = true;
						// �ʐM����
						pMCC->SDC10DataSet(CSDC10::SP_WRITE, pMCC->MD.SDC10D.Node[SDC10_PreHt], true, pMCC->DD.SDC10D.Unit[SDC10_PreHt].SP_Temp);
						int val=0, err=0;
						pMCC->SDC10Comm(0, val, err);	// ����M
					}
				} else Warn(OptionDisp[Lang]);
				break;
			case KeyAftHeater :
				if (0 != pMCC->MD.SDC10D.Node[SDC10_AftHt]) {
					const char* msg[] = {
						"����˰�",
						"Aft-Heater",
					};
					int	min = pMCC->MD.SDC10D.SP[SDC10_AftHt].Min;
					int	max = pMCC->MD.SDC10D.SP[SDC10_AftHt].Max;
					if (DataEdit(msg[Lang], "��", pMCC->DD.SDC10D.Unit[SDC10_AftHt].SP_Temp, min, max)) {
						DataPut(AftHeater, pMCC->DD.SDC10D.Unit[SDC10_AftHt].SP_Temp);
						DataUpdate = true;
						// �ʐM����
						pMCC->SDC10DataSet(CSDC10::SP_WRITE, pMCC->MD.SDC10D.Node[SDC10_AftHt], true, pMCC->DD.SDC10D.Unit[SDC10_AftHt].SP_Temp);
						int val=0, err=0;
						pMCC->SDC10Comm(0, val, err);	// ����M
					}
				} else Warn(OptionDisp[Lang]);
				break;
// #IK20081030-1(E)
			case KeyPreHeater_R:
//todo ���̂������Ƃ��ɃR�[�f�B���O���邱�ƁB
				Warn(OptionDisp[Lang]);
				break;
			case KeyCancel:	// �ް���۰��
				if (DataUpdate) {
					pMCC->DD.SDC10D.DataRW(TRUE, pMCC->DD.FName);
					DataUpdate = false;
					Restart = true;
				}
				break;
			case KeyPrev:  End = TRUE; r = Prev_END;	break;
			case KeyHome:  End = TRUE; r = Home_END;	break;
			case KeyTeach: End = TRUE; r = Teach1_END;	break;
			case KeyData1: End = TRUE; r = Data1_END;	break;
			case KeyData2: End = TRUE; r = Data2_END;	break;
			case KeyData3: End = TRUE; r = Data3_END;	break;
			case KeyData4: End = TRUE; r = Data4_END;	break;
			case KeyData5: End = TRUE; r = Data5_END;	break;
			}
		}
	}
	if (DataUpdate)	{	// �ް�����
		pMCC->DD.SDC10D.DataRW(FALSE, pMCC->DD.FName);
	}
	return(r);
}

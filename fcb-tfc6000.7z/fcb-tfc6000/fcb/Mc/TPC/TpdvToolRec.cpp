/*---------------------------------------------------------------------
	�^�b�`�p�l����ʊ֐��i�i��f�[�^:�X�e�[�W�`���g�j
						2013 Shuhei.Sato / Shibaura Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
// Tool�F��
//
int TPCtrl::DV_ToolRec(int step,int page)
{
	int	r=OK_END;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	for(;;){
		/////////////////////////
		// �f�[�^�ݒ�
		if(step == 0){
			if(page == 1)		{r = DVd_ToolRec1();}
				else				{r = Data1_END;}
		}
		/////////////////////////
		// �e�B�[�`���O
		else {
			if(page == 1)		{r = DVt_ToolRec1();}
			else				{r = Prev_END;		}
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}
////////////////////////////////////////////////////////////
// �y�[�W�P Tool�F���@�f�[�^�ݒ�
//
int TPCtrl::DVd_ToolRec1(){

	int	r = TRUE;
	return r;
}
////////////////////////////////////////////////////////////
// �y�[�W�P Tool�F���@�e�B�[�`���O
//
int TPCtrl::DVt_ToolRec1(){
	int	 r = TRUE;
	return r;
}

/*---------------------------------------------------------------------
	������ى�ʊ֐��i�i���ް�:��ػ���߯����߁j
								1997 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_PrePickup(int step,int page)
{
	enum {
		P4Name	 = 1300,	// 1300 ... 1309
		P5Name	 = 1310,	// 1310 ... 1319
	};
	const char *P4titles[][2][2] = {
		{	{ "�I�v�V����", "          "}, 
			{ "  Option  ", "          "} },
		{	{ "  °����� ", " �߯��޳� "}, 
			{ " ToolChip ", " Put down "} },
	};
	const char *P5titles[][2][1] = {
		{	{"�I�v�V����"}, 
			{"  Option  "} },
		{	{"  ������  "},
			{"  Force   "} },
	};
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int OptionIdx = 1;
	int i;
	for (i = 0; i < 2; i++) {
		tpc.GpPutStrLen(P4Name + 5 * i, P4titles[OptionIdx][Lang][i], 10);
	}
	tpc.GpPutStrLen(P5Name, P5titles[OptionIdx][Lang][0], 10);

	int	r = OK_END;
	for (;;) {
		if (0 == step) {
			if (1 == page){
			}
			else if (2 == page){
			}
			else{
				r = Data1_END;
			}
		} 
		else {
			if(2 == page){
			}
			else{
				r = Teach1_END;
			}
		}
		if (Home_END == r)		break;
		else if(Prev_END == r)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		}
		else if(Teach1_END <= r && r <= Teach8_END) {
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}



/*---------------------------------------------------------------------
	������ى�ʊ֐��iϼ��ް�:Pickup �L�����u���[�V�����j
								
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
// #YT20170814-02(S)
int TPCtrl::MC_PickupCalib(int step,int page)
{
	int OptIdx = 0;
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r=OK_END;
	for(;;){
		if(step == 0){		// �ް��ݒ�
			if(page ==1)		r = MCd_PickupCalib1();	
			else				r = Data1_END;

		} else {				// è��ݸ�
			if(page == 1)		r = MCt_PickupCalib1();	
			else				r = Teach1_END;
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::MCd_PickupCalib1()
{
	enum{
//		SNo					= 2500,		// ���No.
		SNo					= 2550,		// ���No.
		//
		KeyCalibSel_NoUse		= 65,		// Calibration Select No Use
		KeyCalibSel_Use			= 66,		// Calibration Select Use
		KeyCarriZRecHeight		= 67,		// �F�����L�����A�J��������
		KeyCarriStgPosX			= 68,		// �F�����L�����A�X�e�[�W�ʒu�w
		KeyCarriStgPosY			= 69,		// �F�����L�����A�X�e�[�W�ʒu�x
		KeyCarri_RecDelay		= 70,		// �L�����A�J�����F���f�B���C
		KeyToolCam_RecDelay		= 83,		// �c�[���J�����F���f�B���C
		KeyCarri_LightLevelA	= 74,		// �L�����A�J���� Vertical Light Level
		KeyCarri_LightLevelB	= 75,		// �L�����A�J���� Oblique Light Level
		KeyToolCam_LightLevelA	= 84,		// �c�[���J���� Vertical Light Level
		KeyToolCam_LightLevelB	= 85,		// �c�[���J���� Oblique Light Level
		//
		AttCalibSel			= 200,			// Calibration Select
		//
		CalibSel_NoUse			= 300,		// Calibration Select No Use
		CalibSel_Use			= 302,		// Calibration Select Use
		CarriZRecHeight			= 304,		// �F�����L�����A�J��������
		CarriStgPosX			= 306,		// �F�����L�����A�X�e�[�W�ʒu�w
		CarriStgPosY			= 308,		// �F�����L�����A�X�e�[�W�ʒu�x
		Carri_RecDelay			= 310,		// �L�����A�J�����F���f�B���C
		ToolCam_RecDelay		= 312,		// �c�[���J�����F���f�B���C
		Carri_LightLevelA		= 314,		// �L�����A�J���� Vertical Light Level
		Carri_LightLevelB		= 316,		// �L�����A�J���� Oblique Light Level
		ToolCam_LightLevelA		= 318,		// �c�[���J���� Vertical Light Level
		ToolCam_LightLevelB		= 320,		// �c�[���J���� Oblique Light Level
		//
		KeyHome				= '0',
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyData1				,
		KeyData2				,
	};
	int	r = KeyPrev;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		/////////////////////
		// �����l�\��
		tpc.GpPut16(AttCalibSel, 1 << (0x00ff & pMCC->BND.MD.BDICCalib.CalibSel));																// Calibration Select
//		DataPut(MeasureCnt,		pMCC->BND.MD.HdTargetCalibD.measureCount);																		// Interval Bg Count
		///////////////
		// �L�����A�J������
		///////////////
		// �c�[���J������
		//
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			switch(key){
#if 0
				///////////////
				// Calibration Select
				case KeyCalibSel_NoUse	:
				case KeyCalibSel_Use	:
					{
						int val = (KeyCalibSel_NoUse == key) ? 0 : 1;
						if (val != pMCC->BND.MD.BDICCalib.CalibSel) {
							tpc.GpPut16(AttCalibSel, 1 << (pMCC->BND.MD.BDICCalib.CalibSel = val));
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Measurement Count
				case KeyMeasureCnt	:
					{
						const char* msg[] = {
							{ "Measurement Count" },
							{ "Measurement Count" },
						};
						///////////////
						// �f�[�^�ҏW
						int min = 1;
						int max = 10;
						if(DataEdit(msg[Lang],"count",pMCC->BND.MD.HdTargetCalibD.measureCount,min,max,1)){
							DataPut(MeasureCnt,pMCC->BND.MD.HdTargetCalibD.measureCount,1);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// IC Camera Side
				///////////////
				// Head Position X
				case KeyIC_HeadPosX	:
					{
						const char* msg[] = {
							{ "Head Position X" },
							{ "Head Position X" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].x,min,max,10000)){
//							DataPut(IC_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].x,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,min,max,10000)){
							DataPut(IC_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Y
				case KeyIC_HeadPosY	:
					{
						const char* msg[] = {
							{ "Head Position Y" },
							{ "Head Position Y" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].y,min,max,10000)){
//							DataPut(IC_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].y,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,min,max,10000)){
							DataPut(IC_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Z
				case KeyIC_HeadPosZ	:
					{
						const char* msg[] = {
							{ "Head Position Z" },
							{ "Head Position Z" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][1] - 0.1;
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_ICSide],min,max,10000)){
							DataPut(IC_HeadPosZ,pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_ICSide],10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Alignment Delay
				case KeyIC_AlignDelay	:
					{
						const char* msg[] = {
							{ "Alignment Delay" },
							{ "Alignment Delay" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = 0.0;
						double max = 4.0;
						if(DataEdit(msg[Lang],"sec",pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_ICSide],min,max,1000)){
							DataPut(IC_AlignDelay,pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_ICSide],1000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Vertical Light Level
				case KeyIC_LightLevelA	:
					{
						if(pMCC->SD.IO.ICLight.ANo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Vertical Light Level" },
								{ "Vertical Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].A,0,LIGHTLEVEL_MAX)){
								DataPut(IC_LightLevelA,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].A);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Oblique Light Level
				case KeyIC_LightLevelB	:
					{
						if(pMCC->SD.IO.ICLight.BNo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Oblique Light Level" },
								{ "Oblique Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].B,0,LIGHTLEVEL_MAX)){
								DataPut(IC_LightLevelB,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].B);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Sub Camera Side
				///////////////
				// Head Position X
				case KeySub_HeadPosX	:
					{
						const char* msg[] = {
							{ "Head Position X" },
							{ "Head Position X" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].x,min,max,10000)){
//							DataPut(Sub_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].x,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,min,max,10000)){
							DataPut(Sub_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Y
				case KeySub_HeadPosY	:
					{
						const char* msg[] = {
							{ "Head Position Y" },
							{ "Head Position Y" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].y,min,max,10000)){
//							DataPut(Sub_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].y,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,min,max,10000)){
							DataPut(Sub_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Z
				case KeySub_HeadPosZ	:
					{
						const char* msg[] = {
							{ "Head Position Z" },
							{ "Head Position Z" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][1] - 0.1;
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_SubSide],min,max,10000)){
							DataPut(Sub_HeadPosZ,pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_SubSide],10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Alignment Delay
				case KeySub_AlignDelay	:
					{
						const char* msg[] = {
							{ "Alignment Delay" },
							{ "Alignment Delay" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = 0.0;
						double max = 4.0;
						if(DataEdit(msg[Lang],"sec",pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_SubSide],min,max,1000)){
							DataPut(Sub_AlignDelay,pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_SubSide],1000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Vertical Light Level
				case KeySub_LightLevelA	:
					{
						if(pMCC->SD.IO.BCLight.ANo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Vertical Light Level" },
								{ "Vertical Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].A,0,LIGHTLEVEL_MAX)){
								DataPut(Sub_LightLevelA,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].A);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Oblique Light Level
				case KeySub_LightLevelB	:
					{
						if(pMCC->SD.IO.BCLight.BNo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Oblique Light Level" },
								{ "Oblique Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].B,0,LIGHTLEVEL_MAX)){
								DataPut(Sub_LightLevelB,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].B);
								DataUpdate = TRUE;
							}
						}
					}
					break;
#endif
				///////////////
				// 
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyTeach:
					End = TRUE;
					r = Teach1_END;
					break;
				case KeyData1:
					if(pMCC->MD.OptionD.hasACalib_HeadTarget){
						r = Data1_END;
						End = TRUE;
					} else {
						Warn(OptionDisp[Lang]);
					}
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.MD.BDICCalib.DataRW(FALSE, pMCC->BND.MD.FName);
		pMCC->BND.MD.HdTargetCalibD.DataRW(pMCC->C8200, FALSE, pMCC->BND.MD.FName);
	}
	return r;
}

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::MCt_PickupCalib1()
{
	enum{		
//		SNo			= 2354,		// ���No.	
		SNo			= 2555,		// ���No.

		Msg					= 160,	// ү���ޕ\��������

		KeyEnter			='A'	,	// �o�^���s
		KeyCancel				,	
		KeyMove				='F'	,	// �r���ʒu�ړ�

		AttEnter			=200	,
		AttCancel				,	
		AttMove				=205	,
	
		KeyHome			= '0'	,	
		KeyPrev					,	
		KeyTeach				,	
		KeyData					,	
		KeyTeach1				,		// ��ĉ׏d�r�����
		KeyTeach2				,		// �ƭ�ى׏d�r�����
	};
	int		r = KeyPrev;
	BOOL	DataUpdate=FALSE;
	int		Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

	return	r;
}

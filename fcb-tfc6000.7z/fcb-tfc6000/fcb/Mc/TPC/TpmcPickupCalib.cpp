/*---------------------------------------------------------------------
	������ى�ʊ֐��iϼ��ް�:Pickup �L�����u���[�V�����j
								
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
// #YT20170814-02(S)
int TPCtrl::MC_PickupCalib(int step,int page)
{
	int OptIdx = 0;
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r=OK_END;
	for(;;){
		if(step == 0){		// �ް��ݒ�
			if(page ==1)		r = MCd_PickupCalib1();	
			else				r = Data1_END;

		} else {				// è��ݸ�
			if(page == 1)		r = MCt_PickupCalib1();	
			else				r = Teach1_END;
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::MCd_PickupCalib1()
{
	enum{
//		SNo					= 2500,		// ���No.
		SNo					= 2550,		// ���No.
			//
		KeyCalibSel_NoUse	= 65,		// Calibration Select No Use
		KeyCalibSel_Head	= 66,		// Calibration Select Head
		KeyCalibSel_Stage	= 67,		// Calibration Select Stage
		KeyMeasureCnt		= 68,		// Measurement Count
		KeyIC_HeadPosX		= 70,		// IC-Side  Head Position X
		KeyIC_HeadPosY		= 71,		// IC-Side  Head Position Y
		KeyIC_HeadPosZ		= 72,		// IC-Side  Head Position Z
		KeyIC_AlignDelay	= 73,		// IC-Side  Alignment Delay
		KeyIC_LightLevelA	= 74,		// IC-Side  Vertical Light Level
		KeyIC_LightLevelB	= 75,		// IC-Side  Oblique Light Level
		KeySub_HeadPosX		= 80,		// Sub-Side Head Position X
		KeySub_HeadPosY		= 81,		// Sub-Side Head Position Y
		KeySub_HeadPosZ		= 82,		// Sub-Side Head Position Z
		KeySub_AlignDelay	= 83,		// Sub-Side Alignment Delay
		KeySub_LightLevelA	= 84,		// Sub-Side Vertical Light Level
		KeySub_LightLevelB	= 85,		// Sub-Side Oblique Light Level
		//
		AttCalibSel			= 200,		// Calibration Select
		//
		MeasureCnt			= 300,		// Measurement Count
		IC_HeadPosX			= 310,		// IC-Side  Head Position X
		IC_HeadPosY			= 312,		// IC-Side  Head Position Y
		IC_HeadPosZ			= 314,		// IC-Side  Head Position Z
		IC_AlignDelay		= 316,		// IC-Side  Alignment Delay
		IC_LightLevelA		= 318,		// IC-Side  Vertical Light Level
		IC_LightLevelB		= 320,		// IC-Side  Oblique Light Level
		Sub_HeadPosX		= 330,		// Sub-Side Head Position X
		Sub_HeadPosY		= 332,		// Sub-Side Head Position Y
		Sub_HeadPosZ		= 334,		// Sub-Side Head Position Z
		Sub_AlignDelay		= 336,		// Sub-Side Alignment Delay
		Sub_LightLevelA		= 338,		// Sub-Side Vertical Light Level
		Sub_LightLevelB		= 340,		// Sub-Side Oblique Light Level
		//
		KeyHome				= '0',
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyData1				,
		KeyData2				,
	};
	int	r = KeyPrev;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		/////////////////////
		// �����l�\��
		tpc.GpPut16(AttCalibSel, 1 << (0x00ff & pMCC->BND.MD.BDICCalib.CalibSel));																// Calibration Select
		DataPut(MeasureCnt,		pMCC->BND.MD.HdTargetCalibD.measureCount);																		// Interval Bg Count
		///////////////
		// IC Camera Side
								// Head Position Y
		DataPut(IC_HeadPosX,	pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,	10000);																// Head Position X
		DataPut(IC_HeadPosY,	pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,	10000);																// Head Position Y
		DataPut(IC_HeadPosZ,	pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_ICSide],	10000);									// Head Position Z
		DataPut(IC_AlignDelay,	pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_ICSide],		1000);									// Alignment Delay
		DataPut(IC_LightLevelA,	(pMCC->SD.IO.ICLight.ANo == -1) ? 0 : pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].A);	// Vertical Light Level
		DataPut(IC_LightLevelB,	(pMCC->SD.IO.ICLight.BNo == -1) ? 0 : pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].B);	// Oblique Light Level
		///////////////
		// Sub Camera Side
		//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//		DataPut(Sub_HeadPosX,	pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].x,	10000);									// Head Position X
//		DataPut(Sub_HeadPosY,	pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].y,	10000);									// Head Position Y
		DataPut(Sub_HeadPosX,	pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,	10000);																// Head Position X
		DataPut(Sub_HeadPosY,	pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,	10000);																// Head Position Y
		DataPut(Sub_HeadPosZ,	pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_SubSide],10000);									// Head Position Z
		DataPut(Sub_AlignDelay,	pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_SubSide],		1000);									// Alignment Delay
		DataPut(Sub_LightLevelA,(pMCC->SD.IO.BCLight.ANo == -1) ? 0 : pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].A);	// Vertical Light Level
		DataPut(Sub_LightLevelB,(pMCC->SD.IO.BCLight.BNo == -1) ? 0 : pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].B);	// Oblique Light Level
		//
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			switch(key){
				///////////////
				// Calibration Select
				case KeyCalibSel_NoUse	:
				case KeyCalibSel_Head	:
				case KeyCalibSel_Stage	:
					{
						int val = (KeyCalibSel_NoUse == key) ? 0 : ((KeyCalibSel_Head == key) ? 1 : 2);
						if (val != pMCC->BND.MD.BDICCalib.CalibSel) {
							tpc.GpPut16(AttCalibSel, 1 << (pMCC->BND.MD.BDICCalib.CalibSel = val));
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Measurement Count
				case KeyMeasureCnt	:
					{
						const char* msg[] = {
							{ "Measurement Count" },
							{ "Measurement Count" },
						};
						///////////////
						// �f�[�^�ҏW
						int min = 1;
						int max = 10;
						if(DataEdit(msg[Lang],"count",pMCC->BND.MD.HdTargetCalibD.measureCount,min,max,1)){
							DataPut(MeasureCnt,pMCC->BND.MD.HdTargetCalibD.measureCount,1);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// IC Camera Side
				///////////////
				// Head Position X
				case KeyIC_HeadPosX	:
					{
						const char* msg[] = {
							{ "Head Position X" },
							{ "Head Position X" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].x,min,max,10000)){
//							DataPut(IC_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].x,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,min,max,10000)){
							DataPut(IC_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Y
				case KeyIC_HeadPosY	:
					{
						const char* msg[] = {
							{ "Head Position Y" },
							{ "Head Position Y" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].y,min,max,10000)){
//							DataPut(IC_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].y,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,min,max,10000)){
							DataPut(IC_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Z
				case KeyIC_HeadPosZ	:
					{
						const char* msg[] = {
							{ "Head Position Z" },
							{ "Head Position Z" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][1] - 0.1;
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_ICSide],min,max,10000)){
							DataPut(IC_HeadPosZ,pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_ICSide],10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Alignment Delay
				case KeyIC_AlignDelay	:
					{
						const char* msg[] = {
							{ "Alignment Delay" },
							{ "Alignment Delay" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = 0.0;
						double max = 4.0;
						if(DataEdit(msg[Lang],"sec",pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_ICSide],min,max,1000)){
							DataPut(IC_AlignDelay,pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_ICSide],1000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Vertical Light Level
				case KeyIC_LightLevelA	:
					{
						if(pMCC->SD.IO.ICLight.ANo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Vertical Light Level" },
								{ "Vertical Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].A,0,LIGHTLEVEL_MAX)){
								DataPut(IC_LightLevelA,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].A);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Oblique Light Level
				case KeyIC_LightLevelB	:
					{
						if(pMCC->SD.IO.ICLight.BNo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Oblique Light Level" },
								{ "Oblique Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].B,0,LIGHTLEVEL_MAX)){
								DataPut(IC_LightLevelB,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].B);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Sub Camera Side
				///////////////
				// Head Position X
				case KeySub_HeadPosX	:
					{
						const char* msg[] = {
							{ "Head Position X" },
							{ "Head Position X" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].x,min,max,10000)){
//							DataPut(Sub_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].x,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,min,max,10000)){
							DataPut(Sub_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Y
				case KeySub_HeadPosY	:
					{
						const char* msg[] = {
							{ "Head Position Y" },
							{ "Head Position Y" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].y,min,max,10000)){
//							DataPut(Sub_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].y,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,min,max,10000)){
							DataPut(Sub_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Z
				case KeySub_HeadPosZ	:
					{
						const char* msg[] = {
							{ "Head Position Z" },
							{ "Head Position Z" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][1] - 0.1;
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_SubSide],min,max,10000)){
							DataPut(Sub_HeadPosZ,pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_SubSide],10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Alignment Delay
				case KeySub_AlignDelay	:
					{
						const char* msg[] = {
							{ "Alignment Delay" },
							{ "Alignment Delay" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = 0.0;
						double max = 4.0;
						if(DataEdit(msg[Lang],"sec",pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_SubSide],min,max,1000)){
							DataPut(Sub_AlignDelay,pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_SubSide],1000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Vertical Light Level
				case KeySub_LightLevelA	:
					{
						if(pMCC->SD.IO.BCLight.ANo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Vertical Light Level" },
								{ "Vertical Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].A,0,LIGHTLEVEL_MAX)){
								DataPut(Sub_LightLevelA,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].A);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Oblique Light Level
				case KeySub_LightLevelB	:
					{
						if(pMCC->SD.IO.BCLight.BNo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Oblique Light Level" },
								{ "Oblique Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].B,0,LIGHTLEVEL_MAX)){
								DataPut(Sub_LightLevelB,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].B);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// 
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyTeach:
					End = TRUE;
					r = Teach1_END;
					break;
				case KeyData1:
					if(pMCC->MD.OptionD.hasACalib_HeadTarget){
						r = Data1_END;
						End = TRUE;
					} else {
						Warn(OptionDisp[Lang]);
					}
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.MD.BDICCalib.DataRW(FALSE, pMCC->BND.MD.FName);
		pMCC->BND.MD.HdTargetCalibD.DataRW(pMCC->C8200, FALSE, pMCC->BND.MD.FName);
	}
	return r;
}

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::MCt_PickupCalib1()
{
	enum{		
//		SNo			= 2354,		// ���No.	
		SNo			= 2551,		// ���No.

		Senser_aL			= 306,	// �ݻ�r���W��	��	
		Senser_bL			= 308,	// �ݻ�r���W��	��	
		Senser_a			= 310,	// �ݻ�r���W��	��	
		Senser_b			= 312,	// �ݻ�r���W��	��	
		Motor_a				= 314,	// Ӱ���r���W��	��	
		Motor_b				= 316,	// Ӱ���r���W��	��	
		
		Msg					= 160,	// ү���ޕ\��������

		KeyEnter			='A'	,	// �o�^���s
		KeyCancel				,	
		KeyMove				='F'	,	// �r���ʒu�ړ�

		AttEnter			=200	,
		AttCancel				,	
		AttMove				=205	,
	
		KeyHome			= '0'	,	
		KeyPrev					,	
		KeyTeach				,	
		KeyData					,	
		KeyTeach1				,		// ��ĉ׏d�r�����
		KeyTeach2				,		// �ƭ�ى׏d�r�����
	};
	int		r;
	double	F_k = 10;	// �׏d����:������1�ʂ܂�
	double	FUcnv = (!pMCC->MD.OptionD.ForceKgf) ? 1 : N_KGF;
	BOOL	DataUpdate=FALSE;
	int		Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

				//			 1234567890123456789012345678901234567890
	const char*	Emsg[]=	{	"[�o�^���s] �������Ă��������B           ",
							"1/1 �׏d�r�����J�n���܂��B�@          �@",
						};
					//			 1234567890123456789012345678901234567890
	const char*	EmsgEng[]=	{	"Please press [Set-up / Done]            ",
								"1/1 Force Calibration will Start        ",
							};

	tpc.GpPut16(AttEnter,0);
	tpc.GpPut16(AttMove,0);
	tpc.GpPut16(AttCancel,0);

	DataPut(Motor_a,pMCC->BND.bond.GetMotor_a(),10000);				
	DataPut(Motor_b,pMCC->BND.bond.GetMotor_b(),100);				
	DataPut(Senser_aL,pMCC->BND.bond.GetSenser_aL() * FUcnv,10000);
	DataPut(Senser_bL,pMCC->BND.bond.GetSenser_bL() * FUcnv,100);
	DataPut(Senser_a,pMCC->BND.bond.GetSenser_a() * FUcnv,10000);
	DataPut(Senser_b,pMCC->BND.bond.GetSenser_b() * FUcnv,100);


	for(;;){
		BOOL	End=FALSE;
		int		ECnt=0;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0],40);		// ү���ޕ\��
		int	cnt=0,cnt1=2;
		for(;;){
			cnt ++;
			if(cnt > cnt1){
				cnt = 0;
				double	w=pMCC->BND.bond.pBGHD->GetForce();
			}
			BOOL	Restart=FALSE;
			int key;
			int	Axis_Sw = BGH_XY | BGH_Z | CAM_XY | CAM_Z | STG_XY;	// JOG���L����
			if(ECnt == 0){
				//====================================================================
				// ۰�޾ق̉׏d���擾���\�����邽�߂Ƀ|�[�����O����K�v�����邪�A
				// KeyWait_Adjust_BND_STAGE_CAMERA()���g�p���A������ѱ�Ď��Ԃ��Z����
				// �{�^���̌��������Ɉ����Ȃ�B
				// ���Ƃ�������ѱ�Ď��Ԃ𑽂������۰�޾ق̉׏d�\�������ɓ݂��B
				// KeyWait()���g�p����Ə�L���_�����P�����B
				//====================================================================
				//key = KeyWait_Adjust_BND_STAGE_CAMERA(TRUE,eAdjMode_Normal,0,500,Axis_Sw);	//�@��ެ�ċ@�\�t��������
				key = KeyWait(true,100);
			}
			else{
				Set_Adjust_BND_STAGE_CAMERA_Sel(eKeyBND_BgStageSel);
				Axis_Sw = STG_XY;
				key = KeyWait_Adjust_BND_STAGE_CAMERA(TRUE,eAdjMode_Normal,0,0,Axis_Sw);	//�@��ެ�ċ@�\�t��������
			}
			if(key)	tpc.GpBeep();
			if(key == KeyEnter){	// �o�^���s
				MCC_Action_Call	A(pMCC);	// ����J�n���w��	�޽�׸��ŏI�����w��
				int stop=false;
				r = true;
				if(ECnt == 1){
					const char *msg[][2] = {
						{ "�׏d�r�������s���Ă���낵���ł����H", "B\'gͯ�ނ����~���܂��I�I" },
						{ "Is it ok? to start force calibretion.", "B\'g head will down." },
					};
					r = YesNo(msg[Lang][0], msg[Lang][1]);	//-- �m�F���
				}
				if(r)	r = BGHFCalibAction(stop,ECnt, BNDCtrl::CmdBGHFCalibTeach);
				if(r && !stop){				// è��ݸ� 
					ECnt ++ ;
					DataUpdate = TRUE;
					if(ECnt > 1){	// �I��

						DataPut(Motor_a,pMCC->BND.bond.GetMotor_a(),10000);				
						DataPut(Motor_b,pMCC->BND.bond.GetMotor_b(),100);				
						DataPut(Senser_aL,pMCC->BND.bond.GetSenser_aL() * FUcnv,10000);
						DataPut(Senser_bL,pMCC->BND.bond.GetSenser_bL() * FUcnv,100);
						DataPut(Senser_a,pMCC->BND.bond.GetSenser_a() * FUcnv,10000);
						DataPut(Senser_b,pMCC->BND.bond.GetSenser_b() * FUcnv,100);

						tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
						tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0],40);			// ү���ޕ\��
						ECnt = 0;
						DataUpdate = false;
						pMCC->BND.MD.BGHD.DataRW(pMCC->BND,FALSE,pMCC->BND.MD.FName);
						pMCC->BND.MD.STGD.DataRW(FALSE,pMCC->BND.MD.FName);
						pMCC->BND.bond.DataRW(pMCC->BND.frame.GetRegNumbers(), true/*isMcData*/, FALSE, pMCC->BND.MD.FName);
					}
					else{
						tpc.GpPut16(AttEnter	,ATTR_SEL);		// �o�^���s�@�I�����
						tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[ECnt] : Emsg[ECnt],40);	// ү���ޕ\��
						// ��׎��ޔ�
						r = pMCC->BND.CameraMoveAbs(pMCC->BND.MtSel(BNDCtrl::CXI)|pMCC->BND.MtSel(BNDCtrl::CYI),
										pMCC->BND.MD.CameraD.CameraRailChangePos,0,0/*PMode*/,2/*�ޔ��ʒu�ړ����x�g�p*/);
					}
				}
			}
			else if(key == KeyCancel){
				tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
				tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0],40);		// ү���ޕ\��
				if(DataUpdate) {
					pMCC->BND.MD.BGHD.DataRW(pMCC->BND,TRUE,pMCC->BND.MD.FName);
					pMCC->BND.MD.STGD.DataRW(TRUE,pMCC->BND.MD.FName);
				}
				DataUpdate = FALSE;
				Restart = TRUE;
			}
			else if(key == KeyMove && ECnt == 1){		// �׏d�r���ʒu�ړ�
				MCC_Action_Call	A(pMCC);	// ����J�n���w��	�޽�׸��ŏI�����w��
				tpc.GpPut16(AttMove,ATTR_SEL);

				int SaveMCSpd = pMCC->GetMCSpeed();
				pMCC->SetMCSpeed(0);			// �ᑬ�ɐݒ�
				pMCC->BND.BGHFCalibMove();		// �ړ� 
				pMCC->SetMCSpeed(SaveMCSpd);	// ���ɖ߂�
				pMCC->BND.bond.SetSpeedRatio(pMCC->MD.ParamD.MCSpdRatio[SaveMCSpd] / 10.0);

				tpc.GpPut16(AttMove,0);
			}
			else if(ECnt == 0){	// �o�^���s�y�ъm�F���ł͂Ȃ�
				if(key == KeyPrev){
					End = TRUE;
					r = Prev_END;
				}
				else if(key == KeyHome){
					End = TRUE;
					r = Home_END;
				}
				else if(key == KeyData){
					End = TRUE;
					r = Data1_END;	// �ް��ݒ��߰��1��
				}
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	return	r;
}
// #YT20170814-02(E)
//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FCB.rc
//
#define IDSTART                         3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FCB_DIALOG                  102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_DIALOG2                     131
#define IDD_DIALOG3                     132
#define IDB_Offline                     136
#define IDB_OnlineRemote                137
#define IDB_OnlineLocal                 138
#define IDD_DIALOG4                     139
#define IDD_DIALOG5                     141
#define IDD_DIALOG6                     142
#define IDD_DIALOG7                     143
#define IDD_DIALOG8                     144
#define IDD_DIALOG9                     145
#define IDD_BCR_DIALOG                  146
#define IDD_WPD                         147
#define IDC_CURSOR1                     157
#define IDD_DIALOG10                    170
#define IDD_DIALOG11                    185
#define IDD_SG300_DIALOG                194
#define IDD_STATUS                      196
#define IDI_ICON1                       202
#define IDD_DEBUG                       205
#define IDOKPB                          1000
#define IDCANCELPB                      1001
#define IDC_SYSDATA_SAVE                1002
#define IDC_EDIT1                       1003
#define IDC_START                       1004
#define IDC_STOP                        1005
#define IDC_RESET                       1006
#define IDC_BUTTONLEFT                  1007
#define IDC_BUTTONRIGHT                 1008
#define IDC_BUTTONUP                    1009
#define IDC_BUTTONDOWN                  1012
#define IDC_BUTTONUPLEFT                1013
#define IDC_BUTTONDOWNRIGHT             1014
#define IDC_BUTTONUPRIGHT               1015
#define IDC_BUTTONDOWNLEFT              1016
#define IDC_Console                     1017
#define IDC_STATICSPD                   1020
#define IDC_RADIOSPDLOW                 1021
#define IDC_RADIOSPDHIGH                1022
#define IDC_RADIOSPDPITCH               1023
#define IDC_BDBgStgSet                  1024
#define IDC_MCDATA_LOAD                 1026
#define IDC_MCDATA_SAVE                 1027
#define IDC_DVDATA_LOAD                 1028
#define IDC_DVDATA_SAVE                 1029
#define IDD_DISTRACEDLG                 1030
#define IDC_PICT                        1031
#define IDC_SCALEDIV                    1032
#define IDC_XCOMSECSCTRL1               1037
#define IDC_SG300CMSCTRL1               1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        213
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

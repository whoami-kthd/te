// Microsoft Visual C++ �Ŏ����������ꂽ IDispatch ���b�v �N���X

// ����: ���̃t�@�C���̓��e��ҏW���Ȃ��ł��������B ���̃N���X���ēx
//  Microsoft Visual C++ �Ő������ꂽ�ꍇ�A�ύX���㏑�����܂��B


#include "stdafx.h"
#include "sg300cms.h"

/////////////////////////////////////////////////////////////////////////////
// CSG300CMS

IMPLEMENT_DYNCREATE(CSG300CMS, CWnd)

/////////////////////////////////////////////////////////////////////////////
// CSG300CMS �v���p�e�B

long CSG300CMS::GetOpenMode()
{
	long result;
	GetProperty(0x1, VT_I4, (void*)&result);
	return result;
}

void CSG300CMS::SetOpenMode(long propVal)
{
	SetProperty(0x1, VT_I4, propVal);
}

long CSG300CMS::GetCloseMode()
{
	long result;
	GetProperty(0x2, VT_I4, (void*)&result);
	return result;
}

void CSG300CMS::SetCloseMode(long propVal)
{
	SetProperty(0x2, VT_I4, propVal);
}

long CSG300CMS::GetOSEventlog()
{
	long result;
	GetProperty(0x3, VT_I4, (void*)&result);
	return result;
}

void CSG300CMS::SetOSEventlog(long propVal)
{
	SetProperty(0x3, VT_I4, propVal);
}

short CSG300CMS::GetRunTimeFlag()
{
	short result;
	GetProperty(0x4, VT_I2, (void*)&result);
	return result;
}

void CSG300CMS::SetRunTimeFlag(short propVal)
{
	SetProperty(0x4, VT_I2, propVal);
}

short CSG300CMS::GetLinkStatus()
{
	short result;
	GetProperty(0x5, VT_I2, (void*)&result);
	return result;
}

void CSG300CMS::SetLinkStatus(short propVal)
{
	SetProperty(0x5, VT_I2, propVal);
}

long CSG300CMS::GetCurrentCarrierCnt()
{
	long result;
	GetProperty(0x6, VT_I4, (void*)&result);
	return result;
}

void CSG300CMS::SetCurrentCarrierCnt(long propVal)
{
	SetProperty(0x6, VT_I4, propVal);
}

long CSG300CMS::GetCurrentCarrierOutCnt()
{
	long result;
	GetProperty(0x7, VT_I4, (void*)&result);
	return result;
}

void CSG300CMS::SetCurrentCarrierOutCnt(long propVal)
{
	SetProperty(0x7, VT_I4, propVal);
}

long CSG300CMS::GetCarrierOutSpace()
{
	long result;
	GetProperty(0x8, VT_I4, (void*)&result);
	return result;
}

void CSG300CMS::SetCarrierOutSpace(long propVal)
{
	SetProperty(0x8, VT_I4, propVal);
}

/////////////////////////////////////////////////////////////////////////////
// CSG300CMS �I�y���[�V����

long CSG300CMS::OpenProject(LPCTSTR project_path, LPCTSTR project_name)
{
	long result;
	static BYTE parms[] =
		VTS_BSTR VTS_BSTR;
	InvokeHelper(0x9, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		project_path, project_name);
	return result;
}

long CSG300CMS::CloseProject()
{
	long result;
	InvokeHelper(0xa, DISPATCH_METHOD, VT_I4, (void*)&result, NULL);
	return result;
}

long CSG300CMS::CreateGem300Object(const VARIANT& objtype, const VARIANT& objid)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT;
	InvokeHelper(0xb, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, &objid);
	return result;
}

long CSG300CMS::DeleteGem300Object(const VARIANT& objtype, const VARIANT& objid)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT;
	InvokeHelper(0xc, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, &objid);
	return result;
}

long CSG300CMS::CreateCarrier(const VARIANT& carrierid, short state)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_I2;
	InvokeHelper(0xd, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, state);
	return result;
}

long CSG300CMS::DeleteCarrier(const VARIANT& carrierid)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT;
	InvokeHelper(0xe, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid);
	return result;
}

long CSG300CMS::GetAttr(const VARIANT& objtype, LPCTSTR attr_name, VARIANT* attrid, short* item_type, long* element, VARIANT* max, VARIANT* min, VARIANT* def, short* flag)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_BSTR VTS_PVARIANT VTS_PI2 VTS_PI4 VTS_PVARIANT VTS_PVARIANT VTS_PVARIANT VTS_PI2;
	InvokeHelper(0xf, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, attr_name, attrid, item_type, element, max, min, def, flag);
	return result;
}

long CSG300CMS::SetAttr(const VARIANT& objtype, LPCTSTR attr_name, const VARIANT& v, short item_type, long element, short flag)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_BSTR VTS_VARIANT VTS_I2 VTS_I4 VTS_I2;
	InvokeHelper(0x10, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, attr_name, &v, item_type, element, flag);
	return result;
}

long CSG300CMS::GetAttrData(const VARIANT& objtype, const VARIANT& objid, LPCTSTR attr_name, VARIANT* value, short* item_type, long* element, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT VTS_BSTR VTS_PVARIANT VTS_PI2 VTS_PI4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x11, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, &objid, attr_name, value, item_type, element, index_1, index_2, index_3, index_4);
	return result;
}

long CSG300CMS::PutAttrData(const VARIANT& objtype, const VARIANT& objid, LPCTSTR attr_name, const VARIANT& value, short item_type, long element, long index_1, long index_2, long index_3, long index_4)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT VTS_BSTR VTS_VARIANT VTS_I2 VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4;
	InvokeHelper(0x12, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&objtype, &objid, attr_name, &value, item_type, element, index_1, index_2, index_3, index_4);
	return result;
}

long CSG300CMS::CarrierLoad(short ptn, const VARIANT& carrierid, short state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_VARIANT VTS_I2;
	InvokeHelper(0x13, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, &carrierid, state);
	return result;
}

long CSG300CMS::CarrierUnLoad(short ptn, const VARIANT& carrierid, short state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_VARIANT VTS_I2;
	InvokeHelper(0x14, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, &carrierid, state);
	return result;
}

long CSG300CMS::MoveStart(const VARIANT& carrierid, short loctype, short no)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_I2 VTS_I2;
	InvokeHelper(0x15, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, loctype, no);
	return result;
}

long CSG300CMS::MoveEnd(const VARIANT& carrierid, short loctype, short no, short nResult)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_I2 VTS_I2 VTS_I2;
	InvokeHelper(0x16, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, loctype, no, nResult);
	return result;
}

long CSG300CMS::ChangeLPTransferState(short ptn, short state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_I2;
	InvokeHelper(0x17, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, state);
	return result;
}

long CSG300CMS::GetLPTransferState(short ptn, VARIANT* carrierid, short* state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_PVARIANT VTS_PI2;
	InvokeHelper(0x18, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, carrierid, state);
	return result;
}

long CSG300CMS::CarrierOut(const VARIANT& carrierid, short ptn)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_I2;
	InvokeHelper(0x19, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, ptn);
	return result;
}

long CSG300CMS::CancelCarrierOut(const VARIANT& carrierid)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT;
	InvokeHelper(0x1a, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid);
	return result;
}

long CSG300CMS::GetCarrierLocState(short loctype, short no, short* state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_I2 VTS_PI2;
	InvokeHelper(0x1b, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		loctype, no, state);
	return result;
}

long CSG300CMS::GetCarrierLocation(const VARIANT& carrierid, short* loctype, short* no, short* state)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_PI2 VTS_PI2 VTS_PI2;
	InvokeHelper(0x1c, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, loctype, no, state);
	return result;
}

long CSG300CMS::ChangeLPReserveState(short ptn, short state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_I2;
	InvokeHelper(0x1d, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, state);
	return result;
}

long CSG300CMS::GetLPReserveState(short ptn, short* state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_PI2;
	InvokeHelper(0x1e, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, state);
	return result;
}

long CSG300CMS::ChangeLPAccessMode(short ptn, short state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_I2;
	InvokeHelper(0x1f, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, state);
	return result;
}

long CSG300CMS::GetLPAccessMode(short ptn, short* state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_PI2;
	InvokeHelper(0x20, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, state);
	return result;
}

long CSG300CMS::Bind(short ptn, const VARIANT& carrierid)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_VARIANT;
	InvokeHelper(0x21, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, &carrierid);
	return result;
}

long CSG300CMS::CancelBind(short ptn, const VARIANT& carrierid)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_VARIANT;
	InvokeHelper(0x22, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, &carrierid);
	return result;
}

long CSG300CMS::GetLPAssociationState(short* ptn, VARIANT* carrierid, short* state)
{
	long result;
	static BYTE parms[] =
		VTS_PI2 VTS_PVARIANT VTS_PI2;
	InvokeHelper(0x23, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, carrierid, state);
	return result;
}

long CSG300CMS::GetLPState(short ptn, short* access_mode, short* reserve_state, short* association_state, short* transfer_state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_PI2 VTS_PI2 VTS_PI2 VTS_PI2;
	InvokeHelper(0x24, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, access_mode, reserve_state, association_state, transfer_state);
	return result;
}

long CSG300CMS::ReadCarrierId(short ptn, const VARIANT& carrierid, short state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_VARIANT VTS_I2;
	InvokeHelper(0x25, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, &carrierid, state);
	return result;
}

long CSG300CMS::ReadSlotMap(const VARIANT& carrierid, const VARIANT& slotmap, long slotcount, short state)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_VARIANT VTS_I4 VTS_I2;
	InvokeHelper(0x26, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, &slotmap, slotcount, state);
	return result;
}

long CSG300CMS::ChangeCarrierAccessState(const VARIANT& carrierid, short state)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_I2;
	InvokeHelper(0x27, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, state);
	return result;
}

long CSG300CMS::GetCarrierState(const VARIANT& carrierid, short* carrierid_state, short* slotmap_state, short* access_state)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_PI2 VTS_PI2 VTS_PI2;
	InvokeHelper(0x28, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, carrierid_state, slotmap_state, access_state);
	return result;
}

long CSG300CMS::GetAllCarrierId(VARIANT* carrierlist, long* count)
{
	long result;
	static BYTE parms[] =
		VTS_PVARIANT VTS_PI4;
	InvokeHelper(0x29, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		carrierlist, count);
	return result;
}

long CSG300CMS::GetLPTrasferState(short ptn, VARIANT* carrierid, short* state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_PVARIANT VTS_PI2;
	InvokeHelper(0x2a, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, carrierid, state);
	return result;
}

long CSG300CMS::GetLPTransferState2(short ptn, VARIANT* carrierid, short* state, short* trsrdy_state)
{
	long result;
	static BYTE parms[] =
		VTS_I2 VTS_PVARIANT VTS_PI2 VTS_PI2;
	InvokeHelper(0x2b, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		ptn, carrierid, state, trsrdy_state);
	return result;
}

long CSG300CMS::CarrierDock(const VARIANT& carrierid, short loctype, short no, short state)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_I2 VTS_I2 VTS_I2;
	InvokeHelper(0x2c, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, loctype, no, state);
	return result;
}

long CSG300CMS::CarrierClamp(const VARIANT& carrierid, short loctype, short no, short state)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_I2 VTS_I2 VTS_I2;
	InvokeHelper(0x2d, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, loctype, no, state);
	return result;
}

long CSG300CMS::CarrierFoup(const VARIANT& carrierid, short loctype, short no, short state)
{
	long result;
	static BYTE parms[] =
		VTS_VARIANT VTS_I2 VTS_I2 VTS_I2;
	InvokeHelper(0x2e, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		&carrierid, loctype, no, state);
	return result;
}

long CSG300CMS::CarrierAction(long handle, const VARIANT& dataid, const VARIANT& CarrierAction, const VARIANT& carrierspec, short ptn, const VARIANT& parameter, VARIANT* caack, VARIANT* errcode)
{
	long result;
	static BYTE parms[] =
		VTS_I4 VTS_VARIANT VTS_VARIANT VTS_VARIANT VTS_I2 VTS_VARIANT VTS_PVARIANT VTS_PVARIANT;
	InvokeHelper(0x2f, DISPATCH_METHOD, VT_I4, (void*)&result, parms,
		handle, &dataid, &CarrierAction, &carrierspec, ptn, &parameter, caack, errcode);
	return result;
}

void CSG300CMS::AboutBox()
{
	InvokeHelper(0xfffffdd8, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

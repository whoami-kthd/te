#if !defined(AFX_SG300CMS_H__860655F8_885A_4C2E_BC3B_81245FA1BC8E__INCLUDED_)
#define AFX_SG300CMS_H__860655F8_885A_4C2E_BC3B_81245FA1BC8E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//  Microsoft Visual C++ �ɂ���Ď����������ꂽ IDispatch ���b�v �N���X

// ����: ���̃t�@�C���̓��e��ҏW���Ȃ��ł��������B ���̃N���X���ēx
//  Microsoft Visual C++ �Ő������ꂽ�ꍇ�A�ύX���㏑�����܂��B

/////////////////////////////////////////////////////////////////////////////
// CSG300CMS ���b�v �N���X

class CSG300CMS : public CWnd
{
protected:
	DECLARE_DYNCREATE(CSG300CMS)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x918a077c, 0xab8f, 0x4cc1, { 0xa1, 0x63, 0x80, 0xc6, 0xcd, 0xde, 0x17, 0x61 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName,
		LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect,
		CWnd* pParentWnd, UINT nID,
		CCreateContext* pContext = NULL)
	{ return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); }

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect, CWnd* pParentWnd, UINT nID,
		CFile* pPersist = NULL, BOOL bStorage = FALSE,
		BSTR bstrLicKey = NULL)
	{ return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
		pPersist, bStorage, bstrLicKey); }

// �A�g���r���[�g
public:
	long GetOpenMode();
	void SetOpenMode(long);
	long GetCloseMode();
	void SetCloseMode(long);
	long GetOSEventlog();
	void SetOSEventlog(long);
	short GetRunTimeFlag();
	void SetRunTimeFlag(short);
	short GetLinkStatus();
	void SetLinkStatus(short);
	long GetCurrentCarrierCnt();
	void SetCurrentCarrierCnt(long);
	long GetCurrentCarrierOutCnt();
	void SetCurrentCarrierOutCnt(long);
	long GetCarrierOutSpace();
	void SetCarrierOutSpace(long);

// �I�y���[�V����
public:
	long OpenProject(LPCTSTR project_path, LPCTSTR project_name);
	long CloseProject();
	long CreateGem300Object(const VARIANT& objtype, const VARIANT& objid);
	long DeleteGem300Object(const VARIANT& objtype, const VARIANT& objid);
	long CreateCarrier(const VARIANT& carrierid, short state);
	long DeleteCarrier(const VARIANT& carrierid);
	long GetAttr(const VARIANT& objtype, LPCTSTR attr_name, VARIANT* attrid, short* item_type, long* element, VARIANT* max, VARIANT* min, VARIANT* def, short* flag);
	long SetAttr(const VARIANT& objtype, LPCTSTR attr_name, const VARIANT& v, short item_type, long element, short flag);
	long GetAttrData(const VARIANT& objtype, const VARIANT& objid, LPCTSTR attr_name, VARIANT* value, short* item_type, long* element, long index_1, long index_2, long index_3, long index_4);
	long PutAttrData(const VARIANT& objtype, const VARIANT& objid, LPCTSTR attr_name, const VARIANT& value, short item_type, long element, long index_1, long index_2, long index_3, long index_4);
	long CarrierLoad(short ptn, const VARIANT& carrierid, short state);
	long CarrierUnLoad(short ptn, const VARIANT& carrierid, short state);
	long MoveStart(const VARIANT& carrierid, short loctype, short no);
	long MoveEnd(const VARIANT& carrierid, short loctype, short no, short nResult);
	long ChangeLPTransferState(short ptn, short state);
	long GetLPTransferState(short ptn, VARIANT* carrierid, short* state);
	long CarrierOut(const VARIANT& carrierid, short ptn);
	long CancelCarrierOut(const VARIANT& carrierid);
	long GetCarrierLocState(short loctype, short no, short* state);
	long GetCarrierLocation(const VARIANT& carrierid, short* loctype, short* no, short* state);
	long ChangeLPReserveState(short ptn, short state);
	long GetLPReserveState(short ptn, short* state);
	long ChangeLPAccessMode(short ptn, short state);
	long GetLPAccessMode(short ptn, short* state);
	long Bind(short ptn, const VARIANT& carrierid);
	long CancelBind(short ptn, const VARIANT& carrierid);
	long GetLPAssociationState(short* ptn, VARIANT* carrierid, short* state);
	long GetLPState(short ptn, short* access_mode, short* reserve_state, short* association_state, short* transfer_state);
	long ReadCarrierId(short ptn, const VARIANT& carrierid, short state);
	long ReadSlotMap(const VARIANT& carrierid, const VARIANT& slotmap, long slotcount, short state);
	long ChangeCarrierAccessState(const VARIANT& carrierid, short state);
	long GetCarrierState(const VARIANT& carrierid, short* carrierid_state, short* slotmap_state, short* access_state);
	long GetAllCarrierId(VARIANT* carrierlist, long* count);
	long GetLPTrasferState(short ptn, VARIANT* carrierid, short* state);
	long GetLPTransferState2(short ptn, VARIANT* carrierid, short* state, short* trsrdy_state);
	long CarrierDock(const VARIANT& carrierid, short loctype, short no, short state);
	long CarrierClamp(const VARIANT& carrierid, short loctype, short no, short state);
	long CarrierFoup(const VARIANT& carrierid, short loctype, short no, short state);
	long CarrierAction(long handle, const VARIANT& dataid, const VARIANT& CarrierAction, const VARIANT& carrierspec, short ptn, const VARIANT& parameter, VARIANT* caack, VARIANT* errcode);
	void AboutBox();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ �͑O�s�̒��O�ɒǉ��̐錾��}�����܂��B

#endif // !defined(AFX_SG300CMS_H__860655F8_885A_4C2E_BC3B_81245FA1BC8E__INCLUDED_)

#if !defined(AFX_XCOMSECS_H__924F4B6D_7E4F_42BE_878C_E69FE21F28ED__INCLUDED_)
#define AFX_XCOMSECS_H__924F4B6D_7E4F_42BE_878C_E69FE21F28ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//  Microsoft Visual C++ �ɂ���Ď����������ꂽ IDispatch ���b�v �N���X

// ����: ���̃t�@�C���̓��e��ҏW���Ȃ��ł��������B ���̃N���X���ēx
//  Microsoft Visual C++ �Ő������ꂽ�ꍇ�A�ύX���㏑�����܂��B

/////////////////////////////////////////////////////////////////////////////
// CXcomSecs ���b�v �N���X

class CXcomSecs : public CWnd
{
protected:
	DECLARE_DYNCREATE(CXcomSecs)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x5a5f80d3, 0x3480, 0x11d0, { 0xa9, 0x76, 0x0, 0x40, 0x5, 0x1a, 0xf8, 0xd4 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName,
		LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect,
		CWnd* pParentWnd, UINT nID,
		CCreateContext* pContext = NULL)
	{ return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); }

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect, CWnd* pParentWnd, UINT nID,
		CFile* pPersist = NULL, BOOL bStorage = FALSE,
		BSTR bstrLicKey = NULL)
	{ return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
		pPersist, bStorage, bstrLicKey); }

// �A�g���r���[�g
public:
	VARIANT GetMhead();
	void SetMhead(const VARIANT&);
	VARIANT GetRcvhead();
	void SetRcvhead(const VARIANT&);
	long GetErrorStatus();
	void SetErrorStatus(long);
	CString GetErrorActionName();
	void SetErrorActionName(LPCTSTR);
	short GetErrorCommand();
	void SetErrorCommand(short);
	short GetRunTimeFlag();
	void SetRunTimeFlag(short);
	long GetOpenMode();
	void SetOpenMode(long);
	long GetCloseMode();
	void SetCloseMode(long);
	long GetSelectState();
	void SetSelectState(long);
	long GetTermMBNotAllow();
	void SetTermMBNotAllow(long);
	long GetOSEventlog();
	void SetOSEventlog(long);
	long GetTcpConnectEvent();
	void SetTcpConnectEvent(long);

// �I�y���[�V����
public:
	long OpenProject(LPCTSTR project_path, LPCTSTR project_name);
	long CloseProject();
	long PutSecsItem(LPCTSTR item_name, const VARIANT& value, long index_1, long index_2, long index_3, long index_4);
	long PutSecsEvent(LPCTSTR event_name);
	long PutExtendItem(LPCTSTR item_name, const VARIANT& value, short item_type, long element, long index_1, long index_2, long index_3, long index_4);
	long GetItemData(LPCTSTR item_name, VARIANT* value, short* item_type, long* element, long index_1, long index_2, long index_3, long index_4);
	long GetMsgSize(LPCTSTR msg_name, long* msg_size);
	long WriteCurrentData();
	long GetMsgBlk(LPCTSTR msg_name, VARIANT* msg_blk, long* msg_size);
	long GetVID(LPCTSTR vid_name, short* vid_type, VARIANT* vid, VARIANT* vname, VARIANT* unit, VARIANT* v, VARIANT* vmax, VARIANT* vmin, VARIANT* vdef, VARIANT* item_name, short* v_fmt, long* v_elm);
	long SetVID(LPCTSTR vid_name, const VARIANT& v, long rsv1, long rsv2);
	long SndEvntInf(LPCTSTR ceid_name, short rsv);
	long PutAlarmEvent(LPCTSTR alm_name, short flg);
	long GetAlarm(LPCTSTR alm_name, VARIANT* alid, VARIANT* alcd, VARIANT* altx, VARIANT* aled);
	long PutClockEvent();
	long GetTraceData(LPCTSTR trid_name, short* trid, long* dsper, long* totsmp, long* repgsz);
	long ChangeCommunication(long enable_flag);
	long EnableAlarm(LPCTSTR alm_name, short flg);
	long EnableTraceData(LPCTSTR trid_name, short flg);
	long ChangeCR();
	long ChangeOnline(short mode);
	long ChangeOnlineSubState(short mode);
	long EqProcessState(short mode);
	long FindAlarmList();
	long FindNextAlarmList(long handle, VARIANT* alm_name, VARIANT* alid, VARIANT* alcd, VARIANT* altx, VARIANT* aled);
	long FindNextTermText(long handle, VARIANT* text);
	long SetAlarm(LPCTSTR alm_name, const VARIANT& alid, const VARIANT& alcd, const VARIANT& altx);
	BOOL GetDATAID(VARIANT* value, short itmfmt, long elements);
	long GetVIDVal(LPCTSTR vid_name, VARIANT* value, short* item_type, long* element, long index_1, long index_2, long index_3, long index_4);
	long SetVIDVal(LPCTSTR vid_name, const VARIANT& v, short item_type, long element, long index_1, long index_2, long index_3, long index_4);
	long CreateObject(const VARIANT& objtype, const VARIANT& objid);
	long DeleteObject(const VARIANT& objtype, const VARIANT& objid);
	long GetAttrData(const VARIANT& objtype, const VARIANT& objid, LPCTSTR attr_name, VARIANT* v, short* item_type, long* element, long index_1, long index_2, long index_3, long index_4);
	long PutAttrData(const VARIANT& objtype, const VARIANT& objid, LPCTSTR attr_name, const VARIANT& v, short item_type, long element, long index_1, long index_2, long index_3, long index_4);
	long GetAttr(const VARIANT& objtype, LPCTSTR attr_name, short* item_type, long* element, VARIANT* attrid, VARIANT* max, VARIANT* min, VARIANT* def, short* flag);
	long SetAttr(const VARIANT& objtype, LPCTSTR attr_name, const VARIANT& v, short item_type, long element, short flag);
	long GetXComLinkStatus(long* status, short flg);
	long GetGEM300Error(long errorid, VARIANT* errcode, short* fmterrcode, long* elmerrcode, VARIANT* errtext, short* fmterrtext, long* elmerrtext);
	long SetCEIDDelete(LPCTSTR ceid_name, short flg);
	long GetCEIDInfo(LPCTSTR ceid_name, VARIANT* ceid, VARIANT* rptidname_list, VARIANT* rptid_list, long* count, short* flg);
	long GetRPTIDInfo2(LPCTSTR rptid_name, VARIANT* rptid, VARIANT* vidname_list, VARIANT* vid_list, long* count);
	long GetCEIDList(VARIANT* ceid_list, long* count);
	long GetRPTIDList(VARIANT* rptid_list, long* count);
	void AboutBox();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ �͑O�s�̒��O�ɒǉ��̐錾��}�����܂��B

#endif // !defined(AFX_XCOMSECS_H__924F4B6D_7E4F_42BE_878C_E69FE21F28ED__INCLUDED_)

// FCBDlg.cpp : �C���v�������e�[�V���� �t�@�C��
//

#include "stdafx.h"
#include	<mcc.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include "FCB.h"
#include "FCBDlg.h"
#include <SubstInfo.h>		//#THAIHV170818 Add Locate Edit
#include <Mapping.h>
#include <AutoCount.h>
#include "DisTraceDlg.h"	// �ި���ݻ�EײèݸދO�Օ\����ʒǉ�


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// �A�v���P�[�V�����̃o�[�W�������Ŏg���Ă��� CAboutDlg �_�C�A���O
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �_�C�A���O �f�[�^
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard �͉��z�֐��̃I�[�o�[���C�h�𐶐����܂�
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �̃T�|�[�g
	//}}AFX_VIRTUAL

// �C���v�������e�[�V����
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFCBDlg �_�C�A���O

CFCBDlg::CFCBDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFCBDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFCBDlg)
	m_SpdCtrl = -1;
	//}}AFX_DATA_INIT
	// ����: LoadIcon �� Win32 �� DestroyIcon �̃T�u�V�[�P���X��v�����܂���B
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_SpdCtrl = 0;
}

void CFCBDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFCBDlg)
	DDX_Control(pDX, IDC_BDBgStgSet, m_BDBgStgSet);
	DDX_Control(pDX, IDC_BUTTONDOWNRIGHT, m_JoyDownRight);
	DDX_Control(pDX, IDC_BUTTONUPRIGHT, m_JoyUpRight);
	DDX_Control(pDX, IDC_BUTTONUPLEFT, m_JoyUpLeft);
	DDX_Control(pDX, IDC_BUTTONDOWNLEFT, m_JoyDownLeft);
	DDX_Control(pDX, IDC_BUTTONUP, m_JoyUp);
	DDX_Control(pDX, IDC_BUTTONRIGHT, m_JoyRight);
	DDX_Control(pDX, IDC_BUTTONLEFT, m_JoyLeft);
	DDX_Control(pDX, IDC_BUTTONDOWN, m_JoyDown);
	DDX_Control(pDX, IDC_RESET, m_ResetButton);
	DDX_Control(pDX, IDC_STOP, m_StopButton);
	DDX_Control(pDX, IDC_START, m_StartButton);
	DDX_Control(pDX, IDC_Console, m_Console);
	DDX_Radio(pDX, IDC_RADIOSPDLOW, m_SpdCtrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFCBDlg, CDialog)
	//{{AFX_MSG_MAP(CFCBDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_MCDATA_LOAD, OnMcdataLoad)
	ON_BN_CLICKED(IDC_DVDATA_LOAD, OnDvdataLoad)
	ON_BN_CLICKED(IDC_MCDATA_SAVE, OnMcdataSave)
	ON_BN_CLICKED(IDC_DVDATA_SAVE, OnDvdataSave)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDOKPB, OnOkpb)
	ON_BN_CLICKED(IDCANCELPB, OnCancelpb)
	ON_BN_CLICKED(IDC_SYSDATA_SAVE, OnSysdataSave)
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_BN_CLICKED(IDC_BDBgStgSet, OnBDBgStgSet)
	ON_MESSAGE(WM_USER0, OnUserMessage0)	// հ�ްү���ޏ���
	//#THAIHV170818 Add Locate Edit
    ON_REGISTERED_MESSAGE(TFC_CTRL, OnProcessLocateEditMess)
	ON_REGISTERED_MESSAGE(TFC_CTRL, OnLoadCarrierMap)

	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFCBDlg ���b�Z�[�W �n���h��

BOOL CFCBDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// "�o�[�W�������..." ���j���[���ڂ��V�X�e�� ���j���[�֒ǉ����܂��B

	// IDM_ABOUTBOX �̓R�}���h ���j���[�͈̔͂łȂ���΂Ȃ�܂���B
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	SetWindowText(_T("TFC")); //#NhamNV-170901
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���̃_�C�A���O�p�̃A�C�R����ݒ肵�܂��B�t���[�����[�N�̓A�v���P�[�V�����̃��C��
	// �E�B���h�E���_�C�A���O�łȂ����͎����I�ɐݒ肵�܂���B
	SetIcon(m_hIcon, TRUE);			// �傫���A�C�R����ݒ�
	SetIcon(m_hIcon, FALSE);		// �������A�C�R����ݒ�
	
	// TODO: ���ʂȏ��������s�����͂��̏ꏊ�ɒǉ����Ă��������B
#if !GPDEBUG
	m_StartButton.ShowWindow(SW_HIDE);
	m_StopButton.ShowWindow(SW_HIDE);
	m_ResetButton.ShowWindow(SW_HIDE);
	//
	m_JoyUp.ShowWindow(SW_HIDE);
	m_JoyDown.ShowWindow(SW_HIDE);
	m_JoyLeft.ShowWindow(SW_HIDE);
	m_JoyRight.ShowWindow(SW_HIDE);
	m_JoyUpLeft.ShowWindow(SW_HIDE);
	m_JoyUpRight.ShowWindow(SW_HIDE);
	m_JoyDownLeft.ShowWindow(SW_HIDE);
	m_JoyDownRight.ShowWindow(SW_HIDE);

	GetDlgItem(IDC_RADIOSPDLOW)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIOSPDHIGH)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_RADIOSPDPITCH)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_STATICSPD)->ShowWindow(SW_HIDE);

	m_BDBgStgSet.ShowWindow(SW_HIDE);
#endif

	SetTimer(1,1000,NULL);	// 1�b��ɏ��������������s����@
	
	return TRUE;  // TRUE ��Ԃ��ƃR���g���[���ɐݒ肵���t�H�[�J�X�͎����܂���B
}

void CFCBDlg::OnTimer(UINT nIDEvent) 
{
	if(nIDEvent == 1){	// ����������
		KillTimer(1);
		ConsoleMessage("\r\n ���������D�D�D \r\n");	
		pTPC = new TPCtrl(NULL);
		pMCC = pTPC->pMCC;
		pTPC->pMCC->pTPC = pTPC;
		pMCC->ICS.wfStage.icMapping.vMap.SetCWnd(this/*, pMCC*/);
		pMCC->BND.frame.sbMapping.vMap.SetCWnd(this/*, pMCC*/);
		//#THAIHV170818 Add Locate Edit
		pMCC->BND.frame.sbMapping.m_subInfo.SetCWnd(this/*, pMCC*/);
		pMCC->BND.frame.sbMapping.m_locateEdit.SetCWnd(this/*, pMCC*/);
		WPD.Create(IDD_WPD, this);
		pWPD = &WPD;
		gAutoCount.SetMcc(pMCC);
		BCR_INP.Create(IDD_BCR_DIALOG, this);
		pBCR_INP = &BCR_INP;
		pMCC->InitInstance(NULL);	// ���u�����޼ު�ĲƼ��

		pMCC->dlgSG300.Create(IDD_SG300_DIALOG, this);
// #KS20130417-01 [�ǉ�]GEM�Q�|�[�g��
//		pMCC->dlgSG300P2.SetID(1);
//		pMCC->dlgSG300P2.Create(IDD_SG300_DIALOG, this);
		AfxBeginThread(TPCtrl::TpctrlThread, pTPC);	// ������ِ���گ�ނ��N������
		
		pMCC->BDS.feeder.pMCC = pMCC;
#if GPDEBUG
		SetTimer(2,1000,NULL);	// 1�b��ɌĂяo��
#endif
	}
#if GPDEBUG
	else if (2 == nIDEvent) {
		KillTimer(1);

		UpdateData(TRUE);
		pMCC->op.SetJoyStickFlag(
					(0x0004 & m_JoyRight.GetState() || 0x0004 & m_JoyUpRight.GetState() || 0x0004 & m_JoyDownRight.GetState()) ? true : false,
					(0x0004 & m_JoyLeft.GetState() || 0x0004 & m_JoyUpLeft.GetState() || 0x0004 & m_JoyDownLeft.GetState()) ? true : false,
					(0x0004 & m_JoyUp.GetState() || 0x0004 & m_JoyUpRight.GetState() || 0x0004 & m_JoyUpLeft.GetState()) ? true : false,
					(0x0004 & m_JoyDown.GetState() || 0x0004 & m_JoyDownRight.GetState() || 0x0004 & m_JoyDownLeft.GetState()) ? true : false);

		pMCC->op.SetSpdCtrlFlag(m_SpdCtrl);
		SetTimer(2,20,NULL);	// 20ms��ɌĂяo��
		

	}
#endif	
	CDialog::OnTimer(nIDEvent);
}

void CFCBDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����_�C�A���O�{�b�N�X�ɍŏ����{�^����ǉ�����Ȃ�΁A�A�C�R����`�悷��
// �R�[�h���ȉ��ɋL�q����K�v������܂��BMFC �A�v���P�[�V������ document/view
// ���f�����g���Ă���̂ŁA���̏����̓t���[�����[�N�ɂ�莩���I�ɏ�������܂��B

void CFCBDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // �`��p�̃f�o�C�X �R���e�L�X�g

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// �N���C�A���g�̋�`�̈���̒���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// �A�C�R����`�悵�܂��B
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// �V�X�e���́A���[�U�[���ŏ����E�B���h�E���h���b�O���Ă���ԁA
// �J�[�\����\�����邽�߂ɂ������Ăяo���܂��B
HCURSOR CFCBDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFCBDlg::OnMcdataLoad() 
{
	if(AfxMessageBox("ϼ��ް���۰�ނ��܂��B��낵���ł����H",MB_OKCANCEL) == IDOK){
		CString	FileName,FilePath;
		FileName = pTPC->MD_NameGet();
		FilePath = pTPC->MD_FileName(FileName);
		pMCC->MC_Data_File_Read(FilePath);
		AfxMessageBox("ϼ��ް���۰�ނ��܂����B");
	}
}

void CFCBDlg::OnDvdataLoad() 
{
	if(AfxMessageBox("�i���ް���۰�ނ��܂��B��낵���ł����H",
							MB_OKCANCEL) == IDOK){
		CString	FileName,FilePath;
		FileName = pTPC->DD_NameGet();
		FilePath = pTPC->DD_FileName(FileName);
		//#THAIHV170818 Add Locate Edit (S)
		//##DuyND inform to subinfo to reload data
		if (pMCC->BND.frame.GetSubstrateMode() == eComplexMode) {
			CWnd* bleWnd =NULL;
			bleWnd = FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);
			if (bleWnd != NULL) {
				bleWnd->PostMessage(BLE_CTRL, BLE_FILE, 0);		
			}
		}
		//#THAIHV170818 Add Locate Edit (E)
		pMCC->DV_Data_File_Read(FilePath);
		AfxMessageBox("�i���ް���۰�ނ��܂����B");
	}

	
}

void CFCBDlg::OnMcdataSave() 
{
	if(AfxMessageBox("ϼ��ް����ނ��܂��B��낵���ł����H",
							MB_OKCANCEL) == IDOK){
		CString	FileName,FilePath;
		FileName = pTPC->MD_NameGet();
		FilePath = pTPC->MD_FileName(FileName);
		pMCC->MC_Data_File_Write(FilePath);
		AfxMessageBox("ϼ��ް����ނ��܂����B");
	}
}

void CFCBDlg::OnDvdataSave() 
{
	if(AfxMessageBox("�i���ް����ނ��܂��B��낵���ł����H",
							MB_OKCANCEL) == IDOK){
		CString	FileName,FilePath;
		FileName = pTPC->DD_NameGet();
		FilePath = pTPC->DD_FileName(FileName);
		pMCC->DV_Data_File_Write(FilePath);
		AfxMessageBox("�i���ް����ނ��܂����B");
	}
	else{
		// �̈����		mode:CROSS(xy),CROSSHAIR(xy),RECTANGLE(xywh),CIRCLE(xyw)
		double x=0,y=0,w=100,h=50;
		pMCC->C8200.SetROI(CMVS8200::RECTANGLE,ccColor::green,x,y,w,h,false);
			// workerThread true: �Ăяo���������[�J�[�X���b�h�ł���
			//				false:�Ăяo���������[�U�[�C���^�[�t�F�[�X�X���b�h�ł���
	}
}

extern	CFCBApp theApp;
void ConsoleMessage( LPCTSTR pszMsg )	// �R���\�[���Ƀ��b�Z�[�W��\��
{
	CFCBDlg *pDlg;
	pDlg = (CFCBDlg *)theApp.m_pMainWnd;
	CSingleLock	S(&pDlg->Message.MemSema,true);
	pDlg->Message.Str.insert(pDlg->Message.Str.end(),CString(pszMsg));
	::PostMessage(pDlg->m_hWnd,WM_USER0,0,0);		
}

LRESULT CFCBDlg::OnUserMessage0(WPARAM wParam, LPARAM lParam)
{
	CSingleLock	S(&Message.MemSema,true);
	for(int i=0;i<Message.Str.size();i++){
		ConsoleMessage(Message.Str[i]);
	}
	Message.Str.clear();
	UpdateData(false);
	return 0;
}
void CFCBDlg::ConsoleMessage( LPCTSTR pszMsg ){
	if( ( 0 == pszMsg ) || ( 0 == pszMsg[0] ) ) return;
	CEdit *pwEdit = &m_Console;
	if( 0 == pwEdit ) return;
	int	s_nLimitMsgBytes=30000-10;
	int nAddLen = lstrlen( pszMsg );
	int nCurLen = pwEdit->GetWindowTextLength();
	if( s_nLimitMsgBytes <= ( nCurLen + nAddLen ) ){
		// �����l�ȓ��ɉ������邽�߂ɐ擪���폜
		int nExLen = nCurLen + nAddLen - s_nLimitMsgBytes;
		int nDelLen = 0;
		for(int i=0;;i++){
			nDelLen =pwEdit->LineIndex(i);
			if(nExLen < nDelLen)		break;
		}
		pwEdit->SetRedraw( FALSE ); 
		pwEdit->SetSel( 0 , nDelLen );
		pwEdit->ReplaceSel( "" );
		pwEdit->SetSel( s_nLimitMsgBytes , s_nLimitMsgBytes );
		pwEdit->SetRedraw( TRUE ); 
	}
	pwEdit->SetSel( s_nLimitMsgBytes , s_nLimitMsgBytes );
	pwEdit->ReplaceSel( pszMsg );
}	

// #IK5029(S) 03-06-16 ESC,RET�����޲�۸ނ��I�����Ȃ��悤�ɂ���
void CFCBDlg::OnOK() 
{
	// TODO: ���̈ʒu�ɂ��̑��̌��ؗp�̃R�[�h��ǉ����Ă�������
	
//	CDialog::OnOK();
}

void CFCBDlg::OnCancel() 
{
	// TODO: ���̈ʒu�ɓ��ʂȌ㏈����ǉ����Ă��������B
	
//	CDialog::OnCancel();
}

// #IK5029(E)

void CFCBDlg::OnOkpb() 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	CDialog::OnOK();
}

void CFCBDlg::OnCancelpb() 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	CDialog::OnCancel();
}
// #IK5029(E)
// #IK051122-02 �����ް��͖���͕ۑ����Ȃ��悤�ɂ���
void CFCBDlg::OnSysdataSave() 
{
	if(AfxMessageBox("�����ް����ނ��܂��B��낵���ł����H",
							MB_OKCANCEL) == IDOK){
		CString	FileName,FilePath;
		CString	SD_Path = FILE_PATH;
		SD_Path += SYSDATA_FILENAME;
		pMCC->Sys_Data_File_Write(SD_Path);
		AfxMessageBox("�����ް����ނ��܂����B");
	}
}

void CFCBDlg::OnStart() 
{
#if GPDEBUG
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	pMCC->SetButton(0);
#endif	
}

void CFCBDlg::OnStop() 
{
#if GPDEBUG
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	pMCC->SetButton(1);
#endif
}

void CFCBDlg::OnReset() 
{
#if GPDEBUG
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	pMCC->SetButton(2);
#endif	
}

void CFCBDlg::OnBDBgStgSet() 
{
	// TODO: ���̈ʒu�ɃR���g���[���ʒm�n���h���p�̃R�[�h��ǉ����Ă�������
	pMCC->BND.frame.SetAFrame(OnBgStg, true);
}

void CFCBDlg::PostNcDestroy() 
{
	// TODO: ���̈ʒu�ɌŗL�̏�����ǉ����邩�A�܂��͊�{�N���X���Ăяo���Ă�������
	CDialog::PostNcDestroy();
}

void CFCBDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: ���̈ʒu�Ƀ��b�Z�[�W �n���h���p�̃R�[�h��ǉ����邩�܂��̓f�t�H���g�̏������Ăяo���Ă�������
	if(!(nFlags^(MK_LBUTTON|MK_CONTROL|MK_SHIFT)))
	{
		//�q�[�v�Ɋm�ۂ��Ă��܂����Adelete�͕s�v�ł��B
		pDebugWnd = new CDebugWnd(pMCC,true);
	}
	CDialog::OnLButtonDown(nFlags, point);
}


LRESULT CFCBDlg::OnLoadCarrierMap(WPARAM wParam, LPARAM lParam)
{
	LRESULT r = TRUE;
	
	
	return r;
}

//#THAIHV170818 Add Locate Edit (S)
int const eLeft = 0, eRight = 1;
LRESULT CFCBDlg::OnProcessLocateEditMess(WPARAM wParam, LPARAM lParam)
{
	LRESULT r = TRUE;	
	int numberOfIc	= 0;			// Number of IC need to update
	bool update		= false;		// Need to update IC status
	bool updateAll	= false;		// Need to update all IC status
	int onBgStg		= -1;			// Index of frame IC
	int side		= -1;			// Side select
	unsigned short regNo;			// RegNo
	unsigned short xIdx;			// X index
	unsigned short yIdx;			// Y index
	unsigned char status;			// Status of IC
	int target;	
	int dirTarget = -1;
	bool b_ReverseAll = false;

	// Language
	int	Lang = pMCC->MD.OptionD.Language_mode ? 1 : 0;

	int mainSNo = tpc.GetGpScreen();

	switch (wParam) {
		// Case set some ICs
		case BOND_NDONE_L:
			target = eBgStsIdx;
			status = HasToBond;
			side = eLeft;
			update = true;
			break;
		case BOND_FAIL_L:
			target = eBgStsIdx;
			status = FailedToBond;
			side = eLeft;
			update = true;
			break;
		case BOND_DONE_L:
			target = eBgStsIdx;
			status = SucceededToBondByOp;
			side = eLeft;
			update = true;
			break;
		case BOND_STACK_L:
			target = eBgStsIdx;
			status = OnStack;
			side = eLeft;
			update = true;
			break;
		case BOND_SKIP_L:
			target = eBgStsIdx;
			status = HasToSkipBond;
			side = eLeft;
			update = true;
			break;
		case BOND_REVERSE_L:
			target = eBgStsIdx;
			side = eLeft;
			update = true;
			break;
		case DET_UNKN_L:
			target = eBdStsIdx;
			status = None;
			side = eLeft;
			update = true;
			break;
		case DET_BAD_L:
			target = eBdStsIdx;
			status = BadMark;
			side = eLeft;
			update = true;
			break;
		case DET_GOOD_L:
			target = eBdStsIdx;
			status = GoodMark;
			side = eLeft;
			update = true;
			break;
		case BOND_NDONE_R:
			target = eBgStsIdx;
			status = HasToBond;
			side = eRight;
			update = true;
			break;
		case BOND_FAIL_R:
			target = eBgStsIdx;
			status = FailedToBond;
			side = eRight;
			update = true;
			break;
		case BOND_DONE_R:
			target = eBgStsIdx;
			status = SucceededToBondByOp;
			side = eRight;
			update = true;
			break;
		case BOND_STACK_R:
			target = eBgStsIdx;
			status = OnStack;
			side = eRight;
			update = true;
			break;
		case BOND_SKIP_R:
			target = eBgStsIdx;
			status = HasToSkipBond;
			side = eRight;
			update = true;
			break;
		case BOND_REVERSE_R:
			target = eBgStsIdx;
			side = eRight;
			update = true;
			break;
		case DET_UNKN_R:
			target = eBdStsIdx;
			status = None;
			side = eRight;
			update = true;
			break;
		case DET_BAD_R:
			target = eBdStsIdx;
			status = BadMark;
			side = eRight;
			update = true;
			break;
		case DET_GOOD_R:
			target = eBdStsIdx;
			status = GoodMark;
			side = eRight;
			update = true;
			break;
			
			// Case set all
		case DETECT_ALL_BAD_L:
			target = eBdStsIdx;
			status = BadMark;
			side = eLeft;
			updateAll = true;
			break;
		case DETECT_ALL_BAD_R:
			target = eBdStsIdx;
			status = BadMark;
			side = eRight;
			updateAll = true;
			break;
		case DETECT_ALL_GOOD_L:
			target = eBdStsIdx;
			status = GoodMark;
			side = eLeft;
			updateAll = true;
			break;
		case DETECT_ALL_GOOD_R:
			target = eBdStsIdx;
			status = GoodMark;
			side = eRight;
			updateAll = true;
			break;
		case BOND_ALL_DONE_L:
			target = eBgStsIdx;
			status = SucceededToBondByOp;
			side = eLeft;
			updateAll = true;
			break;
		case BOND_ALL_DONE_R:
			target = eBgStsIdx;
			status = SucceededToBondByOp;
			side = eRight;
			updateAll = true;
			break;
		case BOND_ALL_DONTNEED_L:
			target = eBgStsIdx;
			status = HasToSkipBond;
			side = eLeft;
			updateAll = true;
			break;
		case BOND_ALL_DONTNEED_R:
			target = eBgStsIdx;
			status = HasToSkipBond;
			side = eRight;
			updateAll = true;
			break;
		case BOND_ALL_REVERSE_L:
			b_ReverseAll = true;
			target		= eBgStsIdx;
			side		= eLeft;
			updateAll	= true;
			break;
		case BOND_ALL_REVERSE_R:
			b_ReverseAll = true;
			target		= eBgStsIdx;
			side		= eRight;
			updateAll	= true;
			break;
		case SET_SUBST_L:
			side		= eLeft;
			updateAll	= true;
			break;
		case SET_SUBST_R:
			side		= eRight;
			updateAll	= true;
			break;
//THAIHV 20151222 (bond done)
		case BOND_ALL_LEFTDONE_L:
			dirTarget	= eLeft;
			target		= eBgStsIdx;
			side		= eLeft;
			update		= true;
			break;
		case BOND_ALL_LEFTDONE_R:
			dirTarget	= eRight;
			target		= eBgStsIdx;
			side		= eLeft;
			update		= true;
			break;
		case BOND_ALL_RIGHTDONE_L:
			dirTarget	= eLeft;
			target		= eBgStsIdx;
			side		= eRight;
			update		= true;
			break;
		case BOND_ALL_RIGHTDONE_R:
			dirTarget	= eRight;
			target		= eBgStsIdx;
			side		= eRight;
			update		= true;
			break;

// #THAIHV 20151222 (Index send) (S)
		case BLE_INDEX_L:
			side		= eLeft;
			update		= true;
			break;
		case BLE_INDEX_R:
			side		= eRight;
			update		= true;
			break;
// #THAIHV 20151222 (Index send) (E)
		// Save file
		case BLE_CAN_SAVE_FILE:
			{
				CWnd* bleWnd =NULL;
				bleWnd = FindWindow(NULL, DBLE_FRAMENAME_EDITMODE);
				r = FALSE;
				// If BND or ICS is reading data or it is AutoRun, BLE cannot save data
				if (pMCC->BND.GetTFCLockFile() /*|| pMCC->ICS.GetTFCLockFile()*/ || pMCC->GetAutoRunFlag() || pMCC->GetStepModeFlag()) {
					if (bleWnd) {
						r = bleWnd->PostMessage(BLE_CTRL, BLE_SAVE_FILE_NG, lParam);
					}
				} else {
					// FCB cannot read data during BLE writing file
					pMCC->BND.SetBLELockFile(eFILE_190_BE_LOCKED);
					//pMCC->ICS.SetBLELockFile(eFILE_390_BE_LOCKED);
					if (bleWnd) {
						// Send OK message
						r = bleWnd->PostMessage(BLE_CTRL, BLE_SAVE_FILE_OK, lParam);
					}
				}
			}
			break;
			
		case BLE_SAVE_FILE_DONE:		// If BLE finish write file
			{
				// Unlock data file
				pMCC->BND.SetBLELockFile(eFILE_NOT_BE_LOCKED);
				pMCC->ICS.SetBLELockFile(eFILE_NOT_BE_LOCKED);
				
				// TODO: Show message to notify operator load data again
				//AfxMessageBox("Complex data has recently saved by LocateEdit\nLoad data again");

				const char *LoadCplxDataAgain[][2] = {
						{ "Complex data has recently saved by BLE", "Load data again?" },
						{ "Complex data has recently saved by BLE", "Load data again�H" },
					};
				
				// Before show YesNo screen on TP call from FCBDlg, need to temporarily pause TP thread because it cannot has 2threads wait a key at the same time
				// Pause TP thread temporarily
				//pTPThread->SuspendThread();
				//if (pMCC->pTPC->YesNoPub(LoadCplxDataAgain[Lang][0], LoadCplxDataAgain[Lang][1])) {
					// Resume TP thread
					//pTPThread->ResumeThread();

					CString	FileName,FilePath;
					FileName = pTPC->DD_NameGet();
					FilePath = pTPC->DD_FileName(FileName);
					// Inform to subinfo to reload data
					if (pMCC->BND.frame.GetSubstrateMode() == eComplexMode) {
						CWnd* bleWnd =NULL;
						bleWnd = FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);
						if (bleWnd != NULL) {
							bleWnd->PostMessage(BLE_CTRL, BLE_FILE, 0);		
						}
					}
					// TODO: Need to show message "Data is loading" here
					pTPC->SetFCBDlgMsgFinishEvent(true);				//#DMV170629 Locate Edit Request event
					pMCC->pTPC->MessagePub(TRUE,FileName,Lang ?  "Data is Loading......" : "�ް��Ăяo����...");	//-- ��ԉ��
					// TFC reload data
					pMCC->DV_Data_File_Read(FilePath);
					pMCC->pTPC->MessagePub(FALSE);
					pTPC->SetFCBDlgMsgFinishEvent(false);				//#DMV170629 Locate Edit Request event
				//} else {
					// Resume TP thread
				//	pTPThread->ResumeThread();
				//}
				
			}
			break;
		case STARTUP_LOAD_L:
			side = eLeft;
			SetStatusToBLE(wParam, lParam, side);
			break;
		case STARTUP_LOAD_R:
			side = eRight;
			SetStatusToBLE(wParam, lParam, side);
			break;
		case USER_LOAD_L:
			side = eLeft;
			LoadStatusFromBLE(wParam, lParam, side);
			break;
		case USER_LOAD_R:
			side = eRight;
			LoadStatusFromBLE(wParam, lParam, side);
			break;
		case LOADMAP_L:
			side = eLeft;
			LoadMapFromBLE(wParam, lParam, side);
			break;
		case LOADMAP_R:
			side = eRight;
			LoadMapFromBLE(wParam, lParam, side);
			break;
			//#NhamNV-170905- receive BLE_LED_STATUS_CHECK fro BLE (S)
		case BLE_LED_STATUS_CHECK:
			{
				CWnd* bleWnd =NULL;
				bleWnd = FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);
				if(pMCC->GetAutoRunFlag() || pMCC->GetStepModeFlag()){
					if (bleWnd) {
						r = bleWnd->PostMessage(BLE_CTRL, BLE_LED_STATUS_CHECK_NG, 0);
					}
				}else{
					if (bleWnd) {
						r = bleWnd->PostMessage(BLE_CTRL, BLE_LED_STATUS_CHECK_OK, 0);
					}
				}
			}
			break;
			//#NhamNV-170905- receive BLE_LED_STATUS_CHECK fro BLE (E)
		default:
			break;
	}
	CWnd* bleWnd = NULL;
	bleWnd = FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);

	onBgStg = OnBgStg;

	if (update) {
		
		// Check if in autorun or step mode or state of sustrate in BgStage is not good  or current screen not in autorun and step mode -> cannot set status
		if (pMCC->GetStepModeFlag() || pMCC->GetAutoRunFlag() || (!pMCC->BND.frame.HasAFrame(onBgStg)) || !canSetScreenFromLe()) {
			if (bleWnd  && ((wParam != BLE_INDEX_L) && (wParam != BLE_INDEX_R))) {   //THAIHV 20151222 (Index send)
				// Send NG message -> Subinfo cannot set IC status
				TRACE("          [LE]CFCBDlg::On ProcessLocateEditMess()Not good cannot set\n");
				if (/*side == eLeft*/true) {
					if (pMCC->GetStepModeFlag()) {
						// Send message not good to ble because run in step mode
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_L, BLE_NG_STEPRUN);
					} else if (pMCC->GetAutoRunFlag()) {
						// Send message not good to ble because run in auto mode
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_L, BLE_NG_AUTORUN);
					} else if (!pMCC->BND.frame.HasAFrame(onBgStg)) {
						// Send message not good to ble because don't have a frame
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_L, BLE_NG_FRAME);
					} else if (!canSetScreenFromLe()) {
						// Send message not good to ble because not in autorun or teprun screen
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_L, BLE_NG_SCREEN);
					}
				} else  {
					if (pMCC->GetStepModeFlag()) {
						// Send message not good to ble because run in step mode
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_R, BLE_NG_STEPRUN);
					} else if (pMCC->GetAutoRunFlag()) {
						// Send message not good to ble because run in auto mode
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_R, BLE_NG_AUTORUN);
					} else if (!pMCC->BND.frame.HasAFrame(onBgStg)) {
						// Send message not good to ble because don't have a frame
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_R, BLE_NG_FRAME);
					} else if (!canSetScreenFromLe()) {			
						// Send message not good to ble because not in autorun or teprun screen
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_R, BLE_NG_SCREEN);
					}
				}
			}else if ((wParam == BLE_INDEX_L) || (wParam == BLE_INDEX_R)) {   //THAIHV 20151222 (Index send)
				const CString CannotSetIndex = _T("Cannot set index!");
				AfxMessageBox(CannotSetIndex);
			}
			update = false;
		} else if (wParam == BLE_INDEX_L || wParam == BLE_INDEX_R) {		//THAIHV 20151222 (Index send)
			MCC_Action_Call A(pMCC);
			pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(lParam, regNo, xIdx, yIdx);
			pMCC->BND.frame.frameD[onBgStg].SetNowRegNo(regNo);
			pMCC->BND.frame.frameD[onBgStg].SetXY(xIdx, yIdx);
			pTPC->UpdateScreen();
		} else {
			unsigned char bdSts;					// board status
//			unsigned char dsSts;					// dispense status
			unsigned char bgSts;					// bonding status
			unsigned short stackCount;				// stack count
			if (side == eLeft) {
				// Init for left side shared memory
				m_hFileMMF_L = CreateFileMapping(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,BUF_SIZE,GLOBAL_NAME_L);              
				DWORD dwError = GetLastError();
				if (!m_hFileMMF_L) {
					MessageBox(_T("Creation of file mapping left failed"));
				} else {
					m_pViewMMFFile_L = (int*)MapViewOfFile(m_hFileMMF_L, FILE_MAP_ALL_ACCESS, 0, 0, 0);		// map all file
					
					if (!m_pViewMMFFile_L) {
						MessageBox(_T("MapViewOfFile function left failed"));
						CloseHandle(m_hFileMMF_L);
					} else {
						// Get the number of IC
						numberOfIc = *(m_pViewMMFFile_L);		
				
						// Set status for each IC
						for (int i = 0; i < numberOfIc; i++) {
							int index = *(m_pViewMMFFile_L + i + 1);
							pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(index, regNo, xIdx, yIdx);
							// #DDT131021-01: Update set status for case of reverse ICs' status
							// Reverse ICs status
							if (wParam == BOND_REVERSE_L) {
								pMCC->BND.frame.frameD[onBgStg].GetIcStatus(regNo, xIdx, yIdx, bdSts, bgSts, stackCount);
								if (bgSts == HasToBond) {
									// Change from NotDone -> Done
									pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, xIdx, yIdx, target, SucceededToBondByOp, false);
								} else if (bgSts == SucceededToBond || bgSts == SucceededToBondByOp) {
									// Change from Done -> NotDone
									pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, xIdx, yIdx, target, HasToBond, false);
								} else {
									// Nothing to do
								}
							} else if (wParam == BOND_ALL_RIGHTDONE_L || wParam == BOND_ALL_RIGHTDONE_R) {  //THAIHV 20151222 (bond done)
								this->SetAllDone(dirTarget, index);
							} else {
								pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, xIdx, yIdx, target, status, false);
							}
						}
						// Send OK message to BLE --> BLE will update GUI
						if (bleWnd) {
							r = bleWnd->PostMessage(BLE_CTRL, BLE_OK_L, lParam);
							TRACE("          [LE]CFCBDlg::On ProcessLocateEditMess()OK left<r=%d>\n", r);
						}
						UnmapViewOfFile(m_pViewMMFFile_L);
						CloseHandle(m_hFileMMF_L);
					}
				}
			} else {
				// Init for right side shared memory
				m_hFileMMF_R = CreateFileMapping(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,BUF_SIZE,GLOBAL_NAME_R);              
				DWORD dwError = GetLastError();
				if (!m_hFileMMF_R) {
					MessageBox(_T("Creation of file mapping right failed"));
				} else {
					m_pViewMMFFile_R = (int*)MapViewOfFile(m_hFileMMF_R, FILE_MAP_ALL_ACCESS, 0, 0, 0);		// map all file
					
					if (!m_pViewMMFFile_R) {
						MessageBox(_T("MapViewOfFile function right failed"));
						CloseHandle(m_hFileMMF_R);
					} else {
						// Get the number of IC
						numberOfIc = *(m_pViewMMFFile_R);		
						// Set status for each IC
						for (int i = 0; i < numberOfIc; i++) {
							int index = *(m_pViewMMFFile_R + i + 1);
							pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(index, regNo, xIdx, yIdx);
							// #DDT131021-01: Update set status for case of reverse ICs' status
							// Reverse ICs status
							if (wParam == BOND_REVERSE_R) {
								pMCC->BND.frame.frameD[onBgStg].GetIcStatus(regNo, xIdx, yIdx, bdSts, bgSts, stackCount);
								if (bgSts == HasToBond) {
									// Change from NotDone -> Done
									pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, xIdx, yIdx, target, SucceededToBondByOp, false);
								} else if (bgSts == SucceededToBond || bgSts == SucceededToBondByOp) {
									// Change from Done -> NotDone
									pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, xIdx, yIdx, target, HasToBond, false);
								} else {
									// Nothing to do
								}
							} else if (wParam == BOND_ALL_RIGHTDONE_L || wParam == BOND_ALL_RIGHTDONE_R) {  //THAIHV 20151222 (bond done)
								this->SetAllDone(dirTarget, index);
							} else {
								pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, xIdx, yIdx, target, status, false);
							}
						}
						// Send OK message to BLE --> BLE will update GUI
						if (bleWnd) {
							r = bleWnd->PostMessage(BLE_CTRL, BLE_OK_R, lParam);
							TRACE("OK right\n");
						}
						UnmapViewOfFile(m_pViewMMFFile_R);
						CloseHandle(m_hFileMMF_R);
					}
				}
			}
			// Reset update variable
			update = false;
		}
	}

	if (updateAll) {
		// Check if in autorun or step mode or current screen is not autorun and step mode-> cannot set status
		if (pMCC->GetStepModeFlag() || pMCC->GetAutoRunFlag() || (!canSetScreenFromLe())) {
			if (bleWnd) {
				// Send NG message -> Subinfo cannot set IC status
				if (side == eLeft) {
					if (pMCC->GetStepModeFlag()) {
						// Send message not good to ble because run in step mode
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_L, BLE_NG_STEPRUN);
					} else if (pMCC->GetAutoRunFlag()) {
						// Send message not good to ble because run in auto mode
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_L, BLE_NG_AUTORUN);
					} else if (!canSetScreenFromLe()) {
						// Send message not good to ble because don't have a frame
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_L, BLE_NG_SCREEN);
					}
				} else  {
					if (pMCC->GetStepModeFlag()) {
						// Send message not good to ble because run in step mode
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_R, BLE_NG_STEPRUN);
					} else if (pMCC->GetAutoRunFlag()) {
						// Send message not good to ble because run in auto mode
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_R, BLE_NG_AUTORUN);
					} else if (!canSetScreenFromLe()) {
						// Send message not good to ble because don't have a frame
						r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_R, BLE_NG_SCREEN);
					}
				}
			}

		} else {
			if (wParam == SET_SUBST_L || wParam == SET_SUBST_R) {
				CString logmsg;logmsg.Format("[LE��TFC]CFCBDlg%s::OnProcess LocateEditMess()SubstSet\n", (side==eLeft)? "_L":"_R");
//				pMCC->SoftLogWriteNFL(logmsg,TRUE);
				
				// LocateEdit��Message�ԐM
				if (side == eLeft) {
					if (bleWnd) {
						r = bleWnd->PostMessage(BLE_CTRL, BLE_OK_L, lParam);
					}
				} else {
					if (bleWnd) {
						r = bleWnd->PostMessage(BLE_CTRL, BLE_OK_R, lParam);
					}
				}
				
				pTPC->SetSubstSet();				// #yk160318-1:�蓮��޽ľ�Ă�ʊ֐���

			} else {																	// Set all status
				if (!pMCC->BND.frame.HasAFrame(onBgStg)) {
					if (bleWnd) {
						if (side == eLeft) {
							// Send message not good to ble because not in autorun or teprun screen
							r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_L, BLE_NG_FRAME);
						} else {
							// Send message not good to ble because not in autorun or teprun screen
							r = bleWnd->PostMessage(BLE_CTRL, BLE_NG_R, BLE_NG_FRAME);
						}
					}
				} else {
					if (side == eLeft) {													// Set status for left side
						// Init for left side shared memory
						m_hFileMMF_L = CreateFileMapping(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,BUF_SIZE,GLOBAL_NAME_L);              
						DWORD dwError = GetLastError();
						if (!m_hFileMMF_L) {
							MessageBox(_T("Creation of file mapping left failed"));
						} else {
							m_pViewMMFFile_L = (int*)MapViewOfFile(m_hFileMMF_L, FILE_MAP_ALL_ACCESS, 0, 0, 0);		// map all file
							
							if (!m_pViewMMFFile_L) {
								MessageBox(_T("MapViewOfFile function left failed"));
							} else {
								// Get RegNo
								regNo = *(m_pViewMMFFile_L);		
								pMCC->BND.frame.frameD[OnBgStg].SetAllIcStatus(regNo, target, status, false, b_ReverseAll);
								if (bleWnd) {
									r = bleWnd->PostMessage(BLE_CTRL, BLE_OK_L, lParam);
								}
								UnmapViewOfFile(m_hFileMMF_L);
								CloseHandle(m_hFileMMF_L);
							}
						}
					} else {																// Set status on right side
						// Init for right side shared memory
						m_hFileMMF_R = CreateFileMapping(INVALID_HANDLE_VALUE,NULL,PAGE_READWRITE,0,BUF_SIZE,GLOBAL_NAME_R);              
						DWORD dwError = GetLastError();
						if (!m_hFileMMF_R) {
							MessageBox(_T("Creation of file mapping right failed"));
						} else {
							m_pViewMMFFile_R = (int*)MapViewOfFile(m_hFileMMF_R, FILE_MAP_ALL_ACCESS, 0, 0, 0);		// map all file
							
							if (!m_pViewMMFFile_R) {
								MessageBox(_T("MapViewOfFile function right failed"));
							} else {
								// Get RegNo
								regNo = *(m_pViewMMFFile_R);		
								pMCC->BND.frame.frameD[OnBgStg].SetAllIcStatus(regNo, target, status, false, b_ReverseAll);	
								if (bleWnd) {
									r = bleWnd->PostMessage(BLE_CTRL, BLE_OK_R, lParam);
								}
								UnmapViewOfFile(m_hFileMMF_R);
								CloseHandle(m_hFileMMF_R);
							}
						}
					}
				}
			}
		}
		// Reset update variable
		updateAll = false;
	}
	return r;
}
// #DUCDT131001-1: Add function to set status to BLE subinfo when it startup
/**
* Set status for BLE subinfo
*/
void CFCBDlg::SetStatusToBLE(WPARAM wParam, LPARAM lParam, int side)
{
	unsigned short regNo = 1;
	unsigned short XIdx = 1;
	unsigned short YIdx = 1;
	unsigned char bdSts;					// board status
//	unsigned char dsSts;					// dispense status
	unsigned char bgSts;					// bonding status
	unsigned short stackCount;				// stack count

	CWnd* bleWnd = NULL;
	bleWnd = FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);
	int r = true;
	int mainSNo = tpc.GetGpScreen();

	int regNumbers = pMCC->BND.frame.frameD[OnBgStg].pCplxWaferD->GetRegNumber();
	int maxIndex = 0;
	int total = 0;

	int const autoRunSNo = 110;			// auto run screen number
	int const stepRunSNo = 120;			// step run screen number
	//THAIHV 20151231 send direction
	pMCC->BND.frame.sbMapping.m_subInfo.SendDirection(/*side*/0, pMCC->BND.frame.frameD[OnBgStg].GetStageDir());

	if (/*side == eLeft*/true) {
		// Create mapping file to share memory
		m_hFileMMFSet_L = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, LOAD_SIZE, GLOBAL_NAME_LOAD_L);
		if (m_hFileMMFSet_L == NULL) {
			r = false;
			// TODO: warning
			CString msg;
			msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
			AfxMessageBox(msg);
			AfxDebugBreak();
		} else {
			// Init view file
			m_pViewMMFFileSet_L = (int*)MapViewOfFile(m_hFileMMFSet_L, FILE_MAP_ALL_ACCESS, 0, 0, 0);
			if (m_pViewMMFFileSet_L == NULL) {
				r = false;
				CloseHandle(m_hFileMMFSet_L);
				// TODO: warning
				CString msg;
				msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
				AfxMessageBox(msg);
				AfxDebugBreak();

			}
		}
		if (r) {
			//if (pMCC->GetStepModeFlag() || pMCC->GetAutoRunFlag() || (!canSetScreenFromLe())) {
				for (int idx = 0; idx < regNumbers; idx++) {
					maxIndex += pMCC->BND.frame.frameD[OnBgStg].pCplxWaferD->GetBgLocateArrayX(idx + 1) * pMCC->BND.frame.frameD[OnBgStg].pCplxWaferD->GetBgLocateArrayY(idx + 1);
				}
				for (idx = 0; idx < maxIndex; idx++) {
					// Get regNo, index X, index Y from IC index
					pMCC->BND.frame.frameD[OnBgStg].GetRegNoXY(idx, regNo, XIdx, YIdx);
					// Check valid IC
					if (pMCC->BND.frame.frameD[OnBgStg].pCplxWaferD->GetBgLocateValid(regNo, XIdx, YIdx) == 0) {
						continue;
					}
					// Get status of IC
					pMCC->BND.frame.frameD[OnBgStg].GetIcStatus(regNo, XIdx, YIdx, bdSts, bgSts, stackCount);
					if ((bdSts != None) || (bgSts != HasToBond) || (stackCount != 0)) {
						m_pViewMMFFileSet_L[4 * total + 1] = idx;
						m_pViewMMFFileSet_L[4 * total + 2] = ConvertDetectStatus(bdSts);
						m_pViewMMFFileSet_L[4 * total + 3] = ConvertBondStatus(bgSts);
						m_pViewMMFFileSet_L[4 * total + 4] = stackCount;
						total++;
					}
				}
				// Total ICs
				m_pViewMMFFileSet_L[0] = total;
				// Unmap file
				UnmapViewOfFile(m_pViewMMFFileSet_L);
			// Send message to BLE-subinfo
			if (bleWnd) {
				// OK message
				bleWnd->PostMessage(BLE_CTRL, STARTUP_LOAD_L, TRUE);
			}
		} else {
			if (bleWnd) {
				// Not good message
				bleWnd->PostMessage(BLE_CTRL, STARTUP_LOAD_L, FALSE);
			}
		}

	} else {
		// Create mapping file to share memory
		m_hFileMMFSet_R = CreateFileMapping(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE, 0, LOAD_SIZE, GLOBAL_NAME_LOAD_R);
		if (m_hFileMMFSet_R == NULL) {
			r = false;
			// TODO: warning
			CString msg;
			msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
			AfxMessageBox(msg);
			AfxDebugBreak();
		} else {
			// Init view file
			m_pViewMMFFileSet_R = (int*)MapViewOfFile(m_hFileMMFSet_R, FILE_MAP_ALL_ACCESS, 0, 0, 0);
			if (m_pViewMMFFileSet_R == NULL) {
				r = false;
				CloseHandle(m_hFileMMFSet_R);
				// TODO: warning
				CString msg;
				msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
				AfxMessageBox(msg);
				AfxDebugBreak();
				
			}
		}
		if (r) {
			//if (pMCC->GetStepModeFlag() || pMCC->GetAutoRunFlag()) {

				for (int idx = 0; idx < regNumbers; idx++) {
					maxIndex += pMCC->BND.frame.frameD[OnBgStg].pCplxWaferD->GetBgLocateArrayX(idx + 1) * pMCC->BND.frame.frameD[OnBgStg].pCplxWaferD->GetBgLocateArrayY(idx + 1);
				}
				for (idx = 0; idx < maxIndex; idx++) {
					// Get regNo, index X, index Y from IC index
					pMCC->BND.frame.frameD[OnBgStg].GetRegNoXY(idx, regNo, XIdx, YIdx);
					// Check valid IC
					if (pMCC->BND.frame.frameD[OnBgStg].pCplxWaferD->GetBgLocateValid(regNo, XIdx, YIdx) == 0) {
						continue;
					}
					// Get status of IC
					pMCC->BND.frame.frameD[OnBgStg].GetIcStatus(regNo, XIdx, YIdx, bdSts, bgSts, stackCount);
					if ((bdSts != None) || (bgSts != HasToBond) || (stackCount != 0)) {
						m_pViewMMFFileSet_R[4 * total + 1] = idx;
						m_pViewMMFFileSet_R[4 * total + 2] = ConvertDetectStatus(bdSts);
						m_pViewMMFFileSet_R[4 * total + 3] = ConvertBondStatus(bgSts);
						m_pViewMMFFileSet_R[4 * total + 4] = stackCount;
						total++;
					}
				}
				// Total ICs
				m_pViewMMFFileSet_R[0] = total;
				// Unmap file
				UnmapViewOfFile(m_pViewMMFFileSet_R);
			// Send message to BLE-subinfo
			if (bleWnd) {
				// OK message
				bleWnd->PostMessage(BLE_CTRL, STARTUP_LOAD_R, TRUE);
			}
		} else {
			if (bleWnd) {
				// Not good message
				bleWnd->PostMessage(BLE_CTRL, STARTUP_LOAD_R, FALSE);
			}
		}
	}
	return;
}

// #DUCDT131009-1: Add function to load status from BLE
/**
*Load status from BLE
*/
void CFCBDlg::LoadStatusFromBLE(WPARAM wParam, LPARAM lParam, int side)
{
	bool r = true;
	CWnd* bleWnd = NULL;
	bleWnd = FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);
	int mainSNo = tpc.GetGpScreen();
	int onBgStg = OnBgStg;

	unsigned short regNo = 1;
	unsigned short XIdx = 1;
	unsigned short YIdx = 1;
	unsigned char bdSts;					// board status
	unsigned char bgSts;					// bonding status
	// Answer allow load status or not
	if ((lParam == (DBLE_SUBINFO_ASK + DBLE_SUBINFO_BOND_MODE)) || (lParam == (DBLE_SUBINFO_ASK + DBLE_SUBINFO_DETECT_MODE))) {

		if (pMCC->GetStepModeFlag() || pMCC->GetAutoRunFlag() || (!pMCC->BND.frame.HasAFrame(onBgStg)) || !canSetScreenFromLe()) {
			if (bleWnd != NULL) {
				//if (side == eLeft) {
					bleWnd->PostMessage(BLE_CTRL, NG_LOAD_L, lParam);
				//} else {
				//	bleWnd->PostMessage(BLE_CTRL, NG_LOAD_R, lParam);
				//}
			}

		} else {
			if (bleWnd != NULL) {
				//if (side == eLeft) {
					bleWnd->PostMessage(BLE_CTRL, OK_LOAD_L, lParam);
				//} else {
				//	bleWnd->PostMessage(BLE_CTRL, OK_LOAD_R, lParam);
				//}
			}
		}	
	} else if (lParam == DBLE_SUBINFO_BOND_MODE) {			// Set bond status from BLE
		if (/*side == eLeft*/true) {
			m_hFileMMFLoadBond_L = CreateFileMapping(
				INVALID_HANDLE_VALUE,    // use paging file
				NULL,                    // default security
				PAGE_READWRITE,          // read/write access
				0,                       // maximum object size (high-order DWORD)
				MANUAL_LOAD_SIZE,        // maximum object size (low-order DWORD)
				GLOBAL_NAME_MANUAL_LOADBOND_L);					 // name of mapping object
			
			// If cannot create mapping file, show warning message and return
			if (m_hFileMMFLoadBond_L == NULL)
			{
				r = false;
				// TODO: warning
			}
			else {
				m_pViewMMFFileLoadBond_L = (int*) MapViewOfFile(m_hFileMMFLoadBond_L,   // handle to map object
					FILE_MAP_ALL_ACCESS, // read/write permission
					0,
					0,
					MANUAL_LOAD_SIZE);
				if (m_pViewMMFFileLoadBond_L == NULL)
				{
					r = false;
					// Close map file
					CloseHandle(m_hFileMMFLoadBond_L);
					// TODO: warning
					CString msg;
					msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
					AfxMessageBox(msg);
					AfxDebugBreak();
					
				}
			}
			if (r) {
				for (int idx = 0; idx < m_pViewMMFFileLoadBond_L[0]; idx++) {
					
					pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(m_pViewMMFFileLoadBond_L[idx * 2 + 1], regNo, XIdx, YIdx);
					bgSts = ConvertBondStatusFromBLE(m_pViewMMFFileLoadBond_L[idx * 2 + 2]);
					// Set status
					pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, XIdx, YIdx, eBgStsIdx, bgSts, false);
				}
				UnmapViewOfFile(m_pViewMMFFileLoadBond_L);
				CloseHandle(m_hFileMMFLoadBond_L);
			}
		} else {
			m_hFileMMFLoadBond_R = CreateFileMapping(
				INVALID_HANDLE_VALUE,    // use paging file
				NULL,                    // default security
				PAGE_READWRITE,          // read/write access
				0,                       // maximum object size (high-order DWORD)
				MANUAL_LOAD_SIZE,        // maximum object size (low-order DWORD)
				GLOBAL_NAME_MANUAL_LOADBOND_R);					 // name of mapping object
			
			// If cannot create mapping file, show warning message and return
			if (m_hFileMMFLoadBond_R == NULL)
			{
				r = false;
				// TODO: warning
			}
			else {
				m_pViewMMFFileLoadBond_R = (int*) MapViewOfFile(m_hFileMMFLoadBond_R,   // handle to map object
					FILE_MAP_ALL_ACCESS, // read/write permission
					0,
					0,
					MANUAL_LOAD_SIZE);
				if (m_pViewMMFFileLoadBond_R == NULL)
				{
					r = false;
					// Close map file
					CloseHandle(m_hFileMMFLoadBond_R);
					// TODO: warning
					CString msg;
					msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
					AfxMessageBox(msg);
					AfxDebugBreak();
					
				}
			}
			if (r) {
				for (int idx = 0; idx < m_pViewMMFFileLoadBond_R[0]; idx++) {
					
					pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(m_pViewMMFFileLoadBond_R[idx * 2 + 1], regNo, XIdx, YIdx);
					bgSts = ConvertBondStatusFromBLE(m_pViewMMFFileLoadBond_R[idx * 2 + 2]);
					// Set status
					pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, XIdx, YIdx, eBgStsIdx, bgSts, false);
				}
				UnmapViewOfFile(m_pViewMMFFileLoadBond_R);
				CloseHandle(m_hFileMMFLoadBond_R);
			}
		}
		
	} else if (lParam == DBLE_SUBINFO_DETECT_MODE) {		// Set detect status from BLE
		if (/*side == eLeft*/true) {
			m_hFileMMFLoadDetect_L = CreateFileMapping(
				INVALID_HANDLE_VALUE,    // use paging file
				NULL,                    // default security
				PAGE_READWRITE,          // read/write access
				0,                       // maximum object size (high-order DWORD)
				MANUAL_LOAD_SIZE,        // maximum object size (low-order DWORD)
				GLOBAL_NAME_MANUAL_LOADDETECT_L);					 // name of mapping object
			
			// If cannot create mapping file, show warning message and return
			if (m_hFileMMFLoadDetect_L == NULL)
			{
				r = false;
				// TODO: warning
				CString msg;
				msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
				AfxMessageBox(msg);
				AfxDebugBreak();
			}
			else {
				m_pViewMMFFileLoadDetect_L = (int*) MapViewOfFile(m_hFileMMFLoadDetect_L,   // handle to map object
					FILE_MAP_ALL_ACCESS, // read/write permission
					0,
					0,
					MANUAL_LOAD_SIZE);
				if (m_pViewMMFFileLoadDetect_L == NULL)
				{
					r = false;
					// Close map file
					CloseHandle(m_hFileMMFLoadDetect_L);
					// TODO: warning
					CString msg;
					msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
					AfxMessageBox(msg);
					AfxDebugBreak();
					
				}
			}
			if (r) {
				for (int idx = 0; idx < m_pViewMMFFileLoadDetect_L[0]; idx++) {
					
					pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(m_pViewMMFFileLoadDetect_L[idx * 2 + 1], regNo, XIdx, YIdx);
					bdSts = ConvertDetectStatusFromBLE(m_pViewMMFFileLoadDetect_L[idx * 2 + 2]);
					// Set status
					pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, XIdx, YIdx, eBdStsIdx, bdSts, false);
				}
				UnmapViewOfFile(m_pViewMMFFileLoadDetect_L);
				CloseHandle(m_hFileMMFLoadDetect_L);
			}
		} else {
			m_hFileMMFLoadDetect_R = CreateFileMapping(
				INVALID_HANDLE_VALUE,    // use paging file
				NULL,                    // default security
				PAGE_READWRITE,          // read/write access
				0,                       // maximum object size (high-order DWORD)
				MANUAL_LOAD_SIZE,        // maximum object size (low-order DWORD)
				GLOBAL_NAME_MANUAL_LOADDETECT_R);					 // name of mapping object
			
			// If cannot create mapping file, show warning message and return
			if (m_hFileMMFLoadDetect_R == NULL)
			{
				r = false;
				// TODO: warning
			}
			else {
				m_pViewMMFFileLoadDetect_R = (int*) MapViewOfFile(m_hFileMMFLoadDetect_R,   // handle to map object
					FILE_MAP_ALL_ACCESS, // read/write permission
					0,
					0,
					MANUAL_LOAD_SIZE);
				if (m_pViewMMFFileLoadDetect_R == NULL)
				{
					r = false;
					// Close map file
					CloseHandle(m_hFileMMFLoadDetect_R);
					// TODO: warning
					CString msg;
					msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
					AfxMessageBox(msg);
					AfxDebugBreak();
					
				}
			}
			if (r) {
				for (int idx = 0; idx < m_pViewMMFFileLoadDetect_R[0]; idx++) {
					
					pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(m_pViewMMFFileLoadDetect_R[idx * 2 + 1], regNo, XIdx, YIdx);
					bdSts = ConvertDetectStatusFromBLE(m_pViewMMFFileLoadDetect_R[idx * 2 + 2]);
					// Set status
					pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, XIdx, YIdx, eBdStsIdx, bdSts, false);
				}
				UnmapViewOfFile(m_pViewMMFFileLoadDetect_R);
				CloseHandle(m_hFileMMFLoadDetect_R);
			}
		}
	}
	return;
}

/**
* Convert detect status from TFC to BLE
*/
int CFCBDlg::ConvertDetectStatus(int status)
{
	int st = 0;
	switch (status) {
		case None:
			st = DBLE_DETECT_UNKNOWN;
			break;
		case BadMark:
			st = DBLE_DETECT_BAD;
			break;
		case GoodMark:
			st = DBLE_DETECT_GOOD;
			break;
		default:
			st = DBLE_DETECT_UNKNOWN;
			break;

	}
	return st;
}


/**
* Convert detect status from BLE to TFC
*/
int CFCBDlg::ConvertDetectStatusFromBLE(int status)
{
	int st = 0;
	switch (status) {
		case DBLE_DETECT_UNKNOWN:
			st = None;
			break;
		case DBLE_DETECT_BAD:
			st = BadMark;
			break;
		case DBLE_DETECT_GOOD:
			st = GoodMark;
			break;
		default:
			st = None;
			break;

	}
	return st;
}

/**
* Convert bond status from TFC to BLE
*/
int CFCBDlg::ConvertBondStatus(int status)
{
	int st = 0;
	switch (status) {
		case HasToBond:
			st = DBLE_BOND_NOTDONE;
			break;
		case FailedToBond:
			st = DBLE_BOND_FAIL;
			break;
		case SucceededToBondByOp:
		case SucceededToBond:
			st = DBLE_BOND_DONE;
			break;
		case OnStack:
			st = DBLE_BOND_STACK;
			break;
//		case HasToSkipBond:
//			st = DBLE_BOND_NONEED;
//			break;
		default:
			st = DBLE_BOND_NOTDONE;
			break;

	}
	return st;
}


/**
* Convert bond status from BLE to TFC
*/
int CFCBDlg::ConvertBondStatusFromBLE(int status)
{
	int st = 0;
	switch (status) {
		case DBLE_BOND_NOTDONE:
			st = HasToBond;
			break;
		case DBLE_BOND_FAIL:
			st = FailedToBond;
			break;
		case DBLE_BOND_DONE:
			st = SucceededToBondByOp;
			break;
		case DBLE_BOND_STACK:
			st = OnStack;
			break;
		case DBLE_BOND_NONEED:
			st = HasToSkipBond;
			break;
		default:
			st = HasToBond;
			break;

	}
	return st;
}

// #DDT(20140625): Add load map from BLE
void CFCBDlg::LoadMapFromBLE(WPARAM wParam, LPARAM lParam, int side)
{
	bool r = true;
	CWnd* bleWnd = NULL;
	bleWnd = FindWindow(NULL, DBLE_FRAMENAME_SUBINFO);

	int onBgStg = OnBgStg;

	unsigned short regNo = 1;
	unsigned short XIdx = 1;
	unsigned short YIdx = 1;
	unsigned char bgSts;					// bonding status

	if (pMCC->GetStepModeFlag() || pMCC->GetAutoRunFlag() || !pMCC->BND.frame.HasAFrame(onBgStg)) {
		r = false;
	}

	if (r && /*side == eLeft*/true) {
		m_hFileMMFLoadMap_L = CreateFileMapping(
			INVALID_HANDLE_VALUE,    // use paging file
			NULL,                    // default security
			PAGE_READWRITE,          // read/write access
			0,                       // maximum object size (high-order DWORD)
			LOADMAP_SIZE,        // maximum object size (low-order DWORD)
			GLOBAL_NAME_LOADMAP_L);	 // name of mapping object
		
		// If cannot create mapping file, show warning message and return
		if (m_hFileMMFLoadMap_L == NULL)
		{
			r = false;
			// TODO: warning
			CString msg;
			msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		else {
			m_pViewMMFLoadMap_L = (int*) MapViewOfFile(m_hFileMMFLoadMap_L,   // handle to map object
				FILE_MAP_ALL_ACCESS, // read/write permission
				0,
				0,
				LOADMAP_SIZE);
			if (m_pViewMMFLoadMap_L == NULL)
			{
				r = false;
				// Close map file
				CloseHandle(m_hFileMMFLoadMap_L);
				// TODO: warning
				CString msg;
				msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
				AfxMessageBox(msg);
				AfxDebugBreak();
				
			}
		}
		if (r) {
			for (int idx = 0; idx < m_pViewMMFLoadMap_L[0]; idx++) {
				pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(m_pViewMMFLoadMap_L[idx * 2 + 1], regNo, XIdx, YIdx);
				bgSts = ConvertBondStatusFromBLE(m_pViewMMFLoadMap_L[idx * 2 + 2]);
				if (bgSts == SucceededToBondByOp) {
					bgSts = SucceededToBond;
				}
				// Set status
				pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, XIdx, YIdx, eBgStsIdx, bgSts, false);
			}
			UnmapViewOfFile(m_pViewMMFLoadMap_L);
			CloseHandle(m_hFileMMFLoadMap_L);
			
			// Reply to BLE
			if (bleWnd) {
				bleWnd->PostMessage(BLE_CTRL, OK_LOADMAP_L, lParam);	
			}
		} else {
			if (bleWnd) {
				bleWnd->PostMessage(BLE_CTRL, NG_LOADMAP_L, lParam);	
			}
		}
	} else if (r && /*side == eRight*/false){
		m_hFileMMFLoadMap_R = CreateFileMapping(
			INVALID_HANDLE_VALUE,    // use paging file
			NULL,                    // default security
			PAGE_READWRITE,          // read/write access
			0,                       // maximum object size (high-order DWORD)
			LOADMAP_SIZE,			 // maximum object size (low-order DWORD)
			GLOBAL_NAME_LOADMAP_R);	 // name of mapping object
		
		// If cannot create mapping file, show warning message and return
		if (m_hFileMMFLoadMap_R == NULL)
		{
			r = false;
			CString msg;
			msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
			AfxMessageBox(msg);
			AfxDebugBreak();
		}
		else {
			m_pViewMMFLoadMap_R = (int*) MapViewOfFile(m_hFileMMFLoadMap_R,   // handle to map object
				FILE_MAP_ALL_ACCESS, // read/write permission
				0,
				0,
				LOADMAP_SIZE);
			if (m_pViewMMFLoadMap_R == NULL)
			{
				r = false;
				// Close map file
				CloseHandle(m_hFileMMFLoadMap_R);
				// TODO: warning
				CString msg;
				msg.Format("Error at %s(%d):%d ", __FILE__, __LINE__, GetLastError());
				AfxMessageBox(msg);
				AfxDebugBreak();
				
			}
		}
		if (r) {
			for (int idx = 0; idx < m_pViewMMFLoadMap_R[0]; idx++) {
				
				pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(m_pViewMMFLoadMap_R[idx * 2 + 1], regNo, XIdx, YIdx);
				bgSts = ConvertBondStatusFromBLE(m_pViewMMFLoadMap_R[idx * 2 + 2]);
				if (bgSts == SucceededToBondByOp) {
					bgSts = SucceededToBond;
				}
				// Set status
				pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, XIdx, YIdx, eBgStsIdx, bgSts, false);
			}
			UnmapViewOfFile(m_pViewMMFLoadMap_R);
			CloseHandle(m_hFileMMFLoadMap_R);

			// Reply to BLE
			if (bleWnd) {
				bleWnd->PostMessage(BLE_CTRL, OK_LOADMAP_R, lParam);	
			}
		} else {
			if (bleWnd) {
				bleWnd->PostMessage(BLE_CTRL, NG_LOADMAP_R, lParam);	
			}
		}
	} else {
		//if (side == eLeft) {
			bleWnd->PostMessage(BLE_CTRL, NG_LOADMAP_L, lParam);
		//} else {
		//	bleWnd->PostMessage(BLE_CTRL, NG_LOADMAP_R, lParam);
		//}
	}
	return;

}

//Bond done
void CFCBDlg::SetAllDone(int targetDir, int index)
{
	unsigned short regNo;			// RegNo
	unsigned short xIdx;			// X index
	unsigned short yIdx;			// Y index

	int onBgStg = OnBgStg;

	pMCC->BND.frame.frameD[onBgStg].GetRegNoXY(index, regNo, xIdx, yIdx);

	int xMax = pMCC->BND.frame.pCplxWaferD->GetBgLocateArrayX(regNo);
	int yMax = pMCC->BND.frame.pCplxWaferD->GetBgLocateArrayY(regNo);

	for (int y = 1; y < yIdx; y++) {
		for (int x = 1; x <= xMax; x++) {
			if (pMCC->BND.frame.pCplxWaferD->GetBgLocateValid(regNo, x, y)) {
				pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, x, y, eBgStsIdx, SucceededToBondByOp, false);
			}
		}
	}
	if (targetDir == eLeft) {
		for (int x = 1; x <= xIdx; x++) {
			if (pMCC->BND.frame.pCplxWaferD->GetBgLocateValid(regNo, x, yIdx)) {
				pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, x, yIdx, eBgStsIdx, SucceededToBondByOp, false);
			}
		}
	} else {
		for (int x = xIdx; x <= xMax; x++) {
			if (pMCC->BND.frame.pCplxWaferD->GetBgLocateValid(regNo, x, yIdx)) {
				pMCC->BND.frame.frameD[onBgStg].SetIcStatus(regNo, x, yIdx, eBgStsIdx, SucceededToBondByOp, false);
			}
		}
	}
}

int const autoRunSNo = 110;			// auto run screen number
int const stepRunSNo = 120;			// step run screen number

// #yk160222-1:LE��TFC��ĉ\��ʊ֐����쐬
BOOL CFCBDlg::canSetScreenFromLe()
{
	int mainSNo = tpc.GetGpScreen();

	BOOL r = FALSE;
	if ( (mainSNo == autoRunSNo) || (mainSNo == stepRunSNo ) || (mainSNo /*<=*/>= 250 && mainSNo <= 259) ) {	// #yk161226-1:LE��SubstSet��t��ʕs��C��
		r = TRUE;
	}
	return r;
}
//#THAIHV170818 Add Locate Edit (E)
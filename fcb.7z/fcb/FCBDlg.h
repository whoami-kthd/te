// FCBDlg.h : �w�b�_�[ �t�@�C��
//

#if !defined(AFX_FCBDLG_H__1E063847_FEEF_11D3_90F2_000000000000__INCLUDED_)
#define AFX_FCBDLG_H__1E063847_FEEF_11D3_90F2_000000000000__INCLUDED_

#include "BCR_Input.h"
#include "waferposdisp.h"

#include "DebugWnd.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFCBDlg �_�C�A���O
enum{
	WM_USER0	= WM_USER+0,
	WM_USER1,
	WM_USER2,
	WM_USER3,
	WM_USER4,
	WM_USER5
};
void ConsoleMessage( LPCTSTR pszMsg );	// �R���\�[���Ƀ��b�Z�[�W��\��

class CFCBDlg : public CDialog
{
private:
	CDebugWnd* pDebugWnd;
// �\�z
public:
	CFCBDlg(CWnd* pParent = NULL);	// �W���̃R���X�g���N�^
	
public:
	CBCR_Input	BCR_INP;
	CWaferPosDisp WPD;
	TPCtrl	*pTPC;	// ������ِ����޼ު�Ăւ��߲��
	MCCtrl	*pMCC;	// ���u�����޼ު�Ăւ��߲��
	struct MessageBuufer{
		CSemaphoreX		MemSema;	// ���b�Z�[�W�ɑ΂���r������p
		cmStd vector<CString> Str;	// ���b�Z�[�W
	} Message;
	
	LRESULT OnUserMessage0(WPARAM wParam, LPARAM lParam);	//�@հ�ްү���ޏ����֐�
	void ConsoleMessage( LPCTSTR pszMsg );	// �R���\�[���Ƀ��b�Z�[�W��\��

// �_�C�A���O �f�[�^
	//{{AFX_DATA(CFCBDlg)
	enum { IDD = IDD_FCB_DIALOG };
	CButton	m_BDBgStgSet;
	CButton	m_JoyDownRight;
	CButton	m_JoyUpRight;
	CButton	m_JoyUpLeft;
	CButton	m_JoyDownLeft;
	CButton	m_JoyUp;
	CButton	m_JoyRight;
	CButton	m_JoyLeft;
	CButton	m_JoyDown;
	CButton	m_ResetButton;
	CButton	m_StopButton;
	CButton	m_StartButton;
	CEdit	m_Console;
	int		m_SpdCtrl;
	//}}AFX_DATA

	// ClassWizard �͉��z�֐��̃I�[�o�[���C�h�𐶐����܂��B
	//{{AFX_VIRTUAL(CFCBDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV �̃T�|�[�g
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// �C���v�������e�[�V����
protected:
	HICON m_hIcon;
//#THAIHV170818 Add Locate Edit (S)
	//Add handle for shared memory file
	HANDLE m_hFileMMF_L;						// memory mapped file for left side subinfo
    int* m_pViewMMFFile_L;						// view of left side file
	HANDLE m_hFileMMF_R;						// memory mapped file for right side subinfo
    int* m_pViewMMFFile_R;						// view of right side file

	HANDLE m_hFileMMFLoadBond_L;				// memory mapped file for load bond status from left side subinfo
    int* m_pViewMMFFileLoadBond_L;				// view of left side file
	HANDLE m_hFileMMFLoadBond_R;				// memory mapped file for load bond status from right side subinfo
    int* m_pViewMMFFileLoadBond_R;				// view of right side file

	HANDLE m_hFileMMFLoadDetect_L;				// memory mapped file for load detect status from left side subinfo
    int* m_pViewMMFFileLoadDetect_L;			// view of left side file
	HANDLE m_hFileMMFLoadDetect_R;				// memory mapped file for load detect status from right side subinfo
    int* m_pViewMMFFileLoadDetect_R;			// view of right side file

	HANDLE m_hFileMMFSet_L;						// memory mapped file for left side subinfo
    int* m_pViewMMFFileSet_L;					// view of left side file
	HANDLE m_hFileMMFSet_R;						// memory mapped file for right side subinfo
    int* m_pViewMMFFileSet_R;					// view of right side file

	// #DDT(20140625): Add for load map data from BLE
	HANDLE m_hFileMMFLoadMap_L;					// memory mapped file for load bond status from left side subinfo
    int* m_pViewMMFLoadMap_L;					// view of left side file
	HANDLE m_hFileMMFLoadMap_R;					// memory mapped file for load bond status from right side subinfo
    int* m_pViewMMFLoadMap_R;					// view of right side file
	//#THAIHV170818 Add Locate Edit (E)

	// �������ꂽ���b�Z�[�W �}�b�v�֐�
	//{{AFX_MSG(CFCBDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnMcdataLoad();
	afx_msg void OnDvdataLoad();
	afx_msg void OnMcdataSave();
	afx_msg void OnDvdataSave();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnOkpb();
	afx_msg void OnCancelpb();
	afx_msg void OnSysdataSave();
	afx_msg void OnStart();
	afx_msg void OnStop();
	afx_msg void OnReset();
	afx_msg void OnBDBgStgSet();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg LRESULT OnLoadCarrierMap(WPARAM wParam, LPARAM lParam);
	//#THAIHV170818 Add Locate Edit
	afx_msg LRESULT OnProcessLocateEditMess(WPARAM wParam, LPARAM lParam);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	//#THAIHV170818 Add Locate Edit (S)
	ErrorMediator	err;				// �G���[�o��(�Ȃ�ׂ����̃N���X��pMCC���Ăт����Ȃ�����)
	void LoadStatusFromBLE(WPARAM wParam, LPARAM lParam, int side);
	void SetStatusToBLE(WPARAM wParam, LPARAM lParam, int side);
	int ConvertDetectStatus(int status);
	int ConvertBondStatus(int status);
	int ConvertDetectStatusFromBLE(int status);
	int ConvertBondStatusFromBLE(int status);
	void LoadMapFromBLE(WPARAM wParam, LPARAM lParam, int side);
	BOOL canSetScreenFromLe();
	void SetAllDone(int targetDir, int index);
	//#THAIHV170818 Add Locate Edit (E)
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ �͑O�s�̒��O�ɒǉ��̐錾��}�����܂��B

#endif // !defined(AFX_FCBDLG_H__1E063847_FEEF_11D3_90F2_000000000000__INCLUDED_)

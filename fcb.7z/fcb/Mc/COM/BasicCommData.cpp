// BasicCommData.cpp: BasicCommData �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BasicCommData.h"

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

BasicCommData::BasicCommData()
{

}

BasicCommData::~BasicCommData()
{

}

BasicCommData::BasicCommData(
		CString	name					// ���O
							 )
{
	this->myName	= name;
	this->portNo	= "COM1";
	this->boudrate	= 9600;
	this->databit	= 8;
	this->parity	= 0;
	this->evenodd	= 0;
	this->stopbit	= 0;
}

// UsUnit.h: UsUnit �N���X�̃C���^�[�t�F�C�X
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_USUNIT_H__5EEE763B_05CE_497D_9CC0_3B887C0140A8__INCLUDED_)
#define AFX_USUNIT_H__5EEE763B_05CE_497D_9CC0_3B887C0140A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include	<Ulib.h>
#include	<semaxx.h>
#include	<mcstd.h>
//#include	"CommonBghPara.h"
//#include	<swatch.h>

#define DA_MAX_COUNT		4000.0	// 12bit
#define DA_MAX_VOLT			10.0	// 0~10V
//#define DA_MAX_VOLT			5.0	// 0~5V


class UsUnit : public MCCStd
{
public:
	UsUnit();
	UsUnit(	CString name, 
			OrdinaryDAOutTBL* pVoltage,
			int errId
			);

	
	virtual ~UsUnit();


//*******************************************
//
//	private variable of UsUnit class
//
//*******************************************

private:
	CString			name;			// ���O
	CSemaphore		MemSema;		// �r������p
	bool			bStart;

	double			voltageMax;

	OrdinaryDAOut	daoutVoltage;					// DA�o��

	ErrorMediator	err;							// �G���[�o��(�Ȃ�ׂ����̃N���X��pMCC���Ăт����Ȃ�����)


//*******************************************
//
//	public Method of ConveyUnit class
//
//*******************************************
public:
	BOOL Init();	// ������

	bool	SetVoltage(int pulse);
	double	GetCmdVoltage();
	bool	US_VtoP(double volt,  int *pulse);
	bool	US_PtoV(int pulse, double *volt);
	
	////////////////
	// callBack
	//
	bool	US_DAOutFunc(double out,int step,double timeA,double timeB,int mode,bool finish);
	// �d���\��CallBack
	bool (__cdecl *pUsDispFunc)(int);
	bool	SetUsDispFunc(bool (__cdecl *pFunc)(int));

};

#endif // !defined(AFX_USUNIT_H__5EEE763B_05CE_497D_9CC0_3B887C0140A8__INCLUDED_)

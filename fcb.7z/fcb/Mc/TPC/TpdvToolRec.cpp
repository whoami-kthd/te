/*---------------------------------------------------------------------
	�^�b�`�p�l����ʊ֐��i�i��f�[�^:�X�e�[�W�`���g�j
						2013 Shuhei.Sato / Shibaura Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
// Tool�F��
//
int TPCtrl::DV_ToolRec(int step,int page)
{
	int	r=OK_END;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	for(;;){
		/////////////////////////
		// �f�[�^�ݒ�
		if(step == 0){
			if(page == 1)		{r = DVd_ToolRec1();}
				else				{r = Data1_END;}
		}
		/////////////////////////
		// �e�B�[�`���O
		else {
			if(page == 1)		{r = DVt_ToolRec1();}
			else				{r = Prev_END;		}
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}

////////////////////////////////////////////////////////////
// �y�[�W�P Tool�F���@�f�[�^�ݒ�
//
int TPCtrl::DVd_ToolRec1(){

	enum {
		SNo				= 1700,	// ���No.

		// ���ʃL�[
		KeyHome				= '0',
		KeyPrev				= '1',
		KeyTeach			= '2',
		KeyData				= '3',
		KeyData1			= '4',
		KeyData2			= '5',
		KeyData3			= '6',
		KeyData4			= '7',
		KeyData5			= '8',
		KeyData6			= '9',
		//
		GoodCodeMax			= 20,
	};
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

	tpc.GpScreenDisp(SNo);
	int r = Prev_END;
	for(;;){
		BOOL	End=FALSE;
		// ���͏���
		for (bool Restart = false; !Restart && !End;) {
			int key = KeyWait();
			// �z�X�g�ɂ���ă��b�N����Ă���ꍇ�́A�J�ڃ{�^���ȊO�͖����ɂ���B
			if(this->IsLockedByHost(key)){
				continue;
			}
			if (key) tpc.GpBeep();
			// ���x���R�ł����ύX�ł��Ȃ��悤�ɂ���(�␳�l�A�}�b�s���O���[�h)
			if (key < KeyHome || KeyData6 < key) {
				if (Lvl3EditNG(Lvl3Edit_Map)) {
					continue;
				}
			}
			switch (key) {

			case KeyPrev: End = true; r = Prev_END; break;
			case KeyHome: End = true; r = Home_END; break;
			case KeyTeach:
				{
					End = true; r = Teach1_END; break;
					break;
				}
			case KeyData1:End = true; r = Data1_END; break;
			case KeyData2:
				{
					End = true; r = Data2_END; break;
					break;
				}
			case KeyData3:
				{
					// End = true; r = Data3_END; break;
					Warn(OptionDisp[Lang]);
					break;
				}
			case KeyData4:
				// #SS131007 wafer�I�����́A��ʑJ�ڂ��Ȃ�
				if(eObject_Board != pMCC->BND.frame.GetObject()){
//				if(pMCC->BND.frame.GetUseMultiStackMode()){
					Warn(OptionDisp[Lang]);
				}
				else{
					End = TRUE; r = Data4_END;
				}
				break;
			case KeyData5:

				if(pMCC->MD.OptionF.hasAGlobalAlignment){
					End = TRUE; 
					r = Data5_END; 
				}else{
					Warn(OptionDisp[Lang]);
				}
				break;
			case KeyData6:
				break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	return(r);
}
////////////////////////////////////////////////////////////
// �y�[�W�P Tool�F���@�e�B�[�`���O
//
int TPCtrl::DVt_ToolRec1(){
	enum {
		SNo				= 1705,	// ���No.

		// ���ʃL�[
		KeyHome				= '0',
		KeyPrev				= '1',
		KeyTeach			= '2',
		KeyData				= '3',
		KeyTeach1				,	
		KeyTeach2				,	
		KeyTeach3				,	
		KeyTeach4				,	
		KeyTeach5				,	
		//
		GoodCodeMax			= 20,
	};
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

	tpc.GpScreenDisp(SNo);
	int r = Prev_END;
	for(;;){
		BOOL	End=FALSE;
		// ���͏���
		for (bool Restart = false; !Restart && !End;) {
			int key = KeyWait();
			// �z�X�g�ɂ���ă��b�N����Ă���ꍇ�́A�J�ڃ{�^���ȊO�͖����ɂ���B
			if(this->IsLockedByHost(key)){
				continue;
			}
			if (key) tpc.GpBeep();
			// ���x���R�ł����ύX�ł��Ȃ��悤�ɂ���(�␳�l�A�}�b�s���O���[�h)
			if (key < KeyHome || KeyTeach5 < key) {
				if (Lvl3EditNG(Lvl3Edit_Map)) {
					continue;
				}
			}
			switch (key) {

			case KeyPrev: End = true; r = Prev_END; break;
			case KeyHome: End = true; r = Home_END; break;
			case KeyData: End = true; r = Data1_END; break;
			case KeyTeach1:
				{
					End = true; r = Teach1_END; break;
					break;
				}
			case KeyTeach2:
				{
					End = true; r = Data2_END; break;
					break;
				}
			case KeyTeach3:
				{
					 End = true; r = Data3_END; break;
					break;
				}
			case KeyTeach4:
				// #SS131007 wafer�I�����́A��ʑJ�ڂ��Ȃ�
				if(eObject_Board != pMCC->BND.frame.GetObject()){
					Warn(OptionDisp[Lang]);
				}
				else{
					End = TRUE; r = Data4_END;
				}
				break;
			case KeyTeach5:

				if(pMCC->MD.OptionF.hasAGlobalAlignment){
					End = TRUE; 
					r = Data5_END; 
				}else{
					Warn(OptionDisp[Lang]);
				}
				break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	return(r);

}

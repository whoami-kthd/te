// ColorSetting.cpp : implementation file
//

#include "stdafx.h"
#include "LogLCheck.h"
#include "ColorSetting.h"
#include "afxdialogex.h"


// ColorSetting dialog

static  UINT SETTING_COLOR_DLG			= RegisterWindowMessage(_T("Setting Color"));
#define GRAPH_COLOR						1007
#define UPDATE_GRAPH_COLOR				1008


IMPLEMENT_DYNAMIC(ColorSetting, CDialog)

ColorSetting::ColorSetting(CWnd* pParent /*=NULL*/)
	: CDialog(ColorSetting::IDD, pParent)
{
	m_BGColor		   = RGB(0,0,0);
	m_GridColor		   = RGB(55,55,55);
	m_TextColor		   = RGB(255,255,255);
	m_LineGraphColor   = RGB(255,0,255);
	m_PointGraphColor  = RGB(255,0,0);
	m_L2MaxColor	   = RGB(150,150,0);
	m_L2MinColor	   = RGB(0,150,150);
	m_LMaxColor		   = RGB(150,100,0);
	m_LMinColor		   = RGB(0,100,100);
	m_AvgLineColor     = RGB(100,100,100);
}

ColorSetting::~ColorSetting()
{
}

void ColorSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(ColorSetting, CDialog)
	ON_BN_CLICKED(IDC_BG_SET_BTN, &ColorSetting::OnBnClickedBgSetBtn)
	ON_WM_CTLCOLOR()
	ON_REGISTERED_MESSAGE(SETTING_COLOR_DLG, OnDispColorButton)
	ON_BN_CLICKED(IDC_LMAX_SET_BTN, &ColorSetting::OnBnClickedLmaxSetBtn)
	ON_BN_CLICKED(IDC_LMIN_SET_BTN, &ColorSetting::OnBnClickedLminSetBtn)
	ON_BN_CLICKED(IDC_L2MAX_SET_BTN, &ColorSetting::OnBnClickedL2maxSetBtn)
	ON_BN_CLICKED(IDC_L2MIN_SET_BTN, &ColorSetting::OnBnClickedL2minSetBtn)
	ON_BN_CLICKED(IDC_TEXT_SET_BTN, &ColorSetting::OnBnClickedTextSetBtn)
	ON_BN_CLICKED(IDC_AVG_SET_BTN, &ColorSetting::OnBnClickedAvgSetBtn)
	ON_BN_CLICKED(IDC_LINE_GRAPH_SET_BTN, &ColorSetting::OnBnClickedLineGraphSetBtn)
	ON_BN_CLICKED(IDC_POINT_GRAPH_SET_BTN, &ColorSetting::OnBnClickedPointGraphSetBtn)
	ON_BN_CLICKED(IDC_GRID_SET_BTN, &ColorSetting::OnBnClickedGridSetBtn)
END_MESSAGE_MAP()


// ColorSetting message handlers


UINT ColorSetting::GetNameDlg()
{
	return SETTING_COLOR_DLG;
}


HBRUSH ColorSetting::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);	

	if(nCtlColor == CTLCOLOR_BTN){
		if(pWnd->m_hWnd == GetDlgItem(IDC_BG_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_BGColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_L2MAX_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_L2MaxColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_L2MIN_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_L2MinColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_LMAX_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_LMaxColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_LMIN_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_LMinColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_TEXT_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_TextColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_GRID_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_GridColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_LINE_GRAPH_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_LineGraphColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_POINT_GRAPH_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_PointGraphColor);
		}
		else if(pWnd->m_hWnd == GetDlgItem(IDC_AVG_SET_BTN)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			return ::CreateSolidBrush(m_AvgLineColor);
		}
	}
	
	return hbr;
}


LRESULT ColorSetting::OnDispColorButton(WPARAM wParam, LPARAM lParam)
{
	if(wParam == L2MAX)
	{
		m_L2MaxColor = (ULONG)lParam;
	}
	else if(wParam == L2MIN)
	{
		m_L2MinColor = (ULONG)lParam;
	}
	else if(wParam == LMAX)
	{
		m_LMaxColor = (ULONG)lParam;
	}
	else if(wParam == LMIN)
	{
		m_LMinColor = (ULONG)lParam;
	}
	else if(wParam == BG_COLOR)
	{
		m_BGColor = (ULONG)lParam;
	}
	else if(wParam == TEXT_COLOR)
	{
		m_TextColor = (ULONG)lParam;
	}
	else if(wParam == GRID_COLOR)
	{
		m_GridColor = (ULONG)lParam;
	}
	else if(wParam == LINE_GRAPH_COLOR)
	{
		m_LineGraphColor = (ULONG)lParam;
	}
	else if(wParam == POINT_GRAPH_COLOR)
	{
		m_PointGraphColor = (ULONG)lParam;
	}
	else if(wParam == AVG_LINE_COLOR)
	{
		m_AvgLineColor = (ULONG)lParam;
	}
	
	Invalidate();
	UpdateWindow();
	return 0;
}


void ColorSetting::OnBnClickedBgSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = BG_COLOR;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}

void ColorSetting::OnBnClickedLmaxSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = LMAX;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}


void ColorSetting::OnBnClickedLminSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = LMIN;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}


void ColorSetting::OnBnClickedL2maxSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = L2MAX;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}


void ColorSetting::OnBnClickedL2minSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = L2MIN;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}


void ColorSetting::OnBnClickedTextSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = TEXT_COLOR;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}


void ColorSetting::OnBnClickedAvgSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = AVG_LINE_COLOR;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}


void ColorSetting::OnBnClickedLineGraphSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = LINE_GRAPH_COLOR;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}


void ColorSetting::OnBnClickedPointGraphSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = POINT_GRAPH_COLOR;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}


void ColorSetting::OnBnClickedGridSetBtn()
{
	WPARAM	wP = GRAPH_COLOR;
	LPARAM lP = GRID_COLOR;
	AfxGetApp()->m_pMainWnd->SendMessage(UPDATE_GRAPH_COLOR, wP, lP);
}

#pragma once


// ColorSetting dialog

class ColorSetting : public CDialog
{
	DECLARE_DYNAMIC(ColorSetting)

public:
	ColorSetting(CWnd* pParent = NULL);   // standard constructor
	virtual ~ColorSetting();

// Dialog Data
	enum { IDD = IDD_COLOR_SETTING_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

private:
	COLORREF m_L2MaxColor;
	COLORREF m_LMaxColor;
	COLORREF m_L2MinColor;
	COLORREF m_LMinColor;
	COLORREF m_BGColor;
	COLORREF m_TextColor;
	COLORREF m_GridColor;
	COLORREF m_LineGraphColor;
	COLORREF m_PointGraphColor;
	COLORREF m_AvgLineColor;

	afx_msg void OnBnClickedBgSetBtn();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg LRESULT OnDispColorButton(WPARAM wParam, LPARAM lParam);

	enum
	{
		L2MAX = 0,
		L2MIN = 1,
		LMAX = 2,
		LMIN = 3,
		BG_COLOR = 4,
		TEXT_COLOR = 5,
		GRID_COLOR = 6,
		LINE_GRAPH_COLOR = 7,
		POINT_GRAPH_COLOR = 8,
		AVG_LINE_COLOR = 9
	};

public:
	UINT GetNameDlg();

	afx_msg void OnBnClickedLmaxSetBtn();
	afx_msg void OnBnClickedLminSetBtn();
	afx_msg void OnBnClickedL2maxSetBtn();
	afx_msg void OnBnClickedL2minSetBtn();
	afx_msg void OnBnClickedTextSetBtn();
	afx_msg void OnBnClickedAvgSetBtn();
	afx_msg void OnBnClickedLineGraphSetBtn();
	afx_msg void OnBnClickedPointGraphSetBtn();
	afx_msg void OnBnClickedGridSetBtn();
};

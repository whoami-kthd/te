
// LogLCheckDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LogLCheck.h"
#include "LogLCheckDlg.h"
#include "afxdialogex.h"
#include "ColorSetting.h"
#include "math.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLogLCheckDlg dialog

#define Y_SCALE_NUMBER					8
#define X_SCALE_NUMBER					22

#define IDC_MENU_SHOW_SETTING			1000
#define GRAPH_COLOR						1007
#define UPDATE_GRAPH_COLOR				1008

#define TFC_LOGLCHECK_DATA_UPDATE		1009
#define TFC_LOGLCHECK_L2MIN_UPDATE		1010
#define TFC_LOGLCHECK_L2MAX_UPDATE		1011
#define TFC_LOGLCHECK_CLEAR				1012
#define INIT_FILE_PATH					"G:\\TFC\\25_4\\project\\LogLCheck\\LOGLCHECK.INI"


static	UINT APP_RECV_DATA_UPDATE_CTRL  = RegisterWindowMessage(_T("LogLCheck"));


ColorSetting pColordlg;

CLogLCheckDlg::CLogLCheckDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CLogLCheckDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_BGColor		   = RGB(0,0,0);
	m_GridColor		   = RGB(55,55,55);
	m_TextColor		   = RGB(255,255,255);
	m_LineGraphColor   = RGB(255,0,255);
	m_PointGraphColor  = RGB(255,0,0);
	m_L2MaxColor	   = RGB(150,150,0);
	m_L2MinColor	   = RGB(0,150,150);
	m_LMaxColor		   = RGB(150,100,0);
	m_LMinColor		   = RGB(0,100,100);
	m_AvgLineColor     = RGB(100,100,100);
	
	m_CountPoint	   = 0;
	
	/* Create random number */
	for(int i=0; i<20; i++)
	{
		//arrL[i] = rand() %9 + (-4);
		arrL[i] = 0;
	}

	m_L2Min = 0;
	m_L2Max = 0;
}

void CLogLCheckDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CLogLCheckDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(IDC_MENU_SHOW_SETTING, OnMenuShowSetting)
	ON_MESSAGE(UPDATE_GRAPH_COLOR, OnUpdateGraphColor)
	ON_REGISTERED_MESSAGE(APP_RECV_DATA_UPDATE_CTRL, OnProcessTFCMessage)
END_MESSAGE_MAP()


// CLogLCheckDlg message handlers

BOOL CLogLCheckDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	ReadIniFile();
	//int cx = m_windowSize[3]  - m_windowSize[2];
	//int cy = m_windowSize[1] - m_windowSize[0];
	//SetWindowPos(&wndTopMost, m_windowSize[2], m_windowSize[0], cx, cy,  SWP_SHOWWINDOW);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLogLCheckDlg::OnPaint()
{
	CPaintDC dc(this); 
	CDC dcMem;
	CBitmap bmpMem;
	CRect rect;
	GetClientRect(&rect);
	int nRet;
	// create memory dc
	nRet = dcMem.CreateCompatibleDC(&dc);
	nRet = bmpMem.CreateCompatibleBitmap( &dc, rect.Width(), rect.Height() );
	CBitmap *pOldBmp = (CBitmap *)(dcMem.SelectObject(&bmpMem));
	dcMem.FillSolidRect(0, 0, rect.right - rect.left, rect.bottom - rect.top, m_BGColor);

	DrawGrid(&dcMem);
	DrawGraph(&dcMem);
	DrawLimitLines(&dcMem);

	CRect currentRect;
	GetWindowRect(currentRect);
	dc.BitBlt(0, 0, currentRect.Width(), currentRect.Height(), &dcMem, 0, 0, SRCCOPY);
	dcMem.SelectObject(pOldBmp);
	DeleteObject(bmpMem);
	dcMem.DeleteDC();
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLogLCheckDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CLogLCheckDlg::DrawGrid(CDC* dc)
{
	CRect rect;
	GetClientRect(&rect);
	CString textX, textYPositive, textYNegative;

	m_highGrid = (m_L2Max >= abs(m_L2Min)) ? m_L2Max : abs(m_L2Min);

	if((int)(m_highGrid*10000)%3){
		m_scale = (int)(((m_highGrid*10000)/3+1));
	}else{
		m_scale = ((m_highGrid*10000)/3);
	}
	m_scale = m_scale /10000;

	/* Scale */
	xScale = rect.right / X_SCALE_NUMBER;
	yScale = rect.bottom / Y_SCALE_NUMBER;

	/* Draw vertical axis */
	for(int i=0; i<=(X_SCALE_NUMBER-2); i++)
	{
		if(i==0)
		{
			textX.Format(_T("%d"), i);
			WriteText(dc, m_TextColor, xScale*(i+1), rect.bottom/2, textX);
		}
		else
		{
			DrawLine(dc, m_GridColor, xScale*(i+1), rect.bottom-yScale, xScale*(i+1), rect.top+yScale);

			textX.Format(_T("%d"), i);
			WriteText(dc, m_TextColor, xScale*(i+1), rect.bottom/2, textX);
		}
	}

	/* Draw horizontal axis */
	for(int j=0; j<(Y_SCALE_NUMBER/2); j++)
	{
		if(j==0)
		{
			textX.Format(_T("%d"), j);
			WriteText(dc, m_TextColor, rect.left+xScale, rect.bottom/2 +j*((rect.bottom-xScale)/Y_SCALE_NUMBER), textYPositive);
			DrawLine(dc, m_GridColor, 2*xScale, rect.bottom/2+j*yScale, 21*xScale, rect.bottom/2+j*yScale);
		}
		else
		{
			textYPositive.Format(_T("%1.2f"), j*m_scale*(-1));
			WriteText(dc, m_TextColor, rect.left+xScale, rect.bottom/2 +j*((rect.bottom-xScale)/Y_SCALE_NUMBER), textYPositive);
			DrawLine(dc, m_GridColor, 2*xScale, rect.bottom/2+j*yScale, 21*xScale, rect.bottom/2+j*yScale);		

			textYNegative.Format(_T("%1.2f"), j*m_scale);
			WriteText(dc, m_TextColor, rect.left+xScale, rect.bottom/2 -j*((rect.bottom-xScale)/Y_SCALE_NUMBER)-4, textYNegative);
			DrawLine(dc, m_GridColor, 2*xScale, rect.bottom/2-j*yScale, 21*xScale, rect.bottom/2-j*yScale);
		}
	}
}


void CLogLCheckDlg::DrawLine(CDC* dc, COLORREF color, int x1, int y1, int x2, int y2)
{
	CPen pen;
	pen.CreatePen(PS_DOT,2,color);
	CPen* PenOrg = dc->SelectObject(&pen);

	dc->MoveTo(x1,y1);
	dc->LineTo(x2,y2);

	dc->SelectObject(PenOrg);
	pen.DeleteObject();
}


void CLogLCheckDlg::WriteText(CDC* dc, COLORREF color, int x, int y, CString text)
{
	// Initializes a CFont object with the specified characteristics.
	CFont font;
	VERIFY(font.CreateFont(
	   10,                        // nHeight
	   0,                         // nWidth
	   0,                         // nEscapement
	   0,                         // nOrientation
	   FW_NORMAL,                 // nWeight
	   FALSE,                     // bItalic
	   FALSE,                     // bUnderline
	   0,                         // cStrikeOut
	   ANSI_CHARSET,              // nCharSet
	   OUT_DEFAULT_PRECIS,        // nOutPrecision
	   CLIP_DEFAULT_PRECIS,       // nClipPrecision
	   DEFAULT_QUALITY,           // nQuality
	   DEFAULT_PITCH | FF_SWISS,  // nPitchAndFamily
	   _T("Arial")));             // lpszFacename

	dc->SetTextColor(color);
	dc->TextOut(x, y, text);

	CFont* defFont = dc->SelectObject(&font);
	dc->SelectObject(defFont);
	font.DeleteObject();
}


void CLogLCheckDlg::DrawPoint(CDC* dc, COLORREF color, int x, int y)
{
	int size = 1;
	CPen	pen;
	pen.CreatePen(PS_SOLID,3,color);
	CPen* PenOrg = dc->SelectObject(&pen);

	dc->Ellipse(x-size,y-size,x+size,y+size);

	dc->SelectObject(PenOrg);
	pen.DeleteObject();
}


void CLogLCheckDlg::DrawGraph(CDC* dc)
{
	CRect rect;
	GetClientRect(&rect);
	m_CountPoint = 20;

	/* Scale */
	xScale = rect.right / X_SCALE_NUMBER;
	yScale = rect.bottom / Y_SCALE_NUMBER;

	int high = (int)((rect.bottom - (2*yScale))/(6*m_scale));
	for(int i=0; i<m_CountPoint; i++){
		DrawLine(dc, m_LineGraphColor, xScale+(i+1)*xScale, rect.bottom/2-(int)(arrL[i]*high), xScale+(i)*xScale+xScale, rect.bottom/2-(int)(arrL[i]*high));
	}
	for(int j=0; j<m_CountPoint; j++){
		DrawPoint(dc, m_PointGraphColor, xScale+(j+1)*xScale, rect.bottom/2-(int)(arrL[j]*high));
	}
}


void CLogLCheckDlg::DrawLimitLines(CDC* dc)
{
	CRect rect;
	GetClientRect(&rect);

	/* Draw L2Max line */
	DrawLine(dc, m_L2MaxColor, 2*xScale, rect.bottom/2-3*yScale, 21*xScale, rect.bottom/2-3*yScale);

	/* Draw L2Min line */
	DrawLine(dc, m_L2MinColor, 2*xScale, rect.bottom/2+3*yScale, 21*xScale, rect.bottom/2+3*yScale);

	int high = (int)((rect.bottom - (2*yScale))/(6*m_scale));

	/* Find minimum/maximum number */
	double m_LMin = arrL[0], m_LMax = arrL[0];
	for(int i=0; i<20; i++)
	{
		if(arrL[i] <= m_LMin)
		{
			m_LMin = arrL[i];
		}
		else
		{
			if(arrL[i] >= m_LMax)
			{
				m_LMax = arrL[i];
			}
		}
	}

	/* Draw LMax line */
	DrawLine(dc, m_LMaxColor, 2*xScale, rect.bottom/2-(int)(m_LMax*high), 21*xScale, rect.bottom/2-(int)(m_LMax*high));

	/* Draw LMin line */
	DrawLine(dc, m_LMinColor, 2*xScale, rect.bottom/2-(int)(m_LMin*high), 21*xScale, rect.bottom/2-(int)(m_LMin*high));

	/* Draw averger line */
	m_AvgVal = (m_LMax + m_LMin)/2;
	DrawLine(dc, m_AvgLineColor, 2*xScale, rect.bottom/2-(int)(m_AvgVal*high), 21*xScale, rect.bottom/2-(int)(m_AvgVal*high));
}


void CLogLCheckDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	xScale = cx;
	yScale = cy;
	Invalidate();
}


void CLogLCheckDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
	CDialogEx::OnGetMinMaxInfo(lpMMI);
	lpMMI->ptMinTrackSize.x = 420;
	lpMMI->ptMinTrackSize.y = 300;

	lpMMI->ptMaxTrackSize.x = 840;
	lpMMI->ptMaxTrackSize.y = 600;
}


void CLogLCheckDlg::OnContextMenu(CWnd* pWnd, CPoint point)
{
	CMenu menu;
	menu.CreatePopupMenu();
	menu.AppendMenu(MF_STRING|MF_ENABLED, IDC_MENU_SHOW_SETTING , _T("Show Color Setting"));

	CPoint pt;
	pt = point;
	ClientToScreen(&point);
	point.x = pt.x;
	point.y = pt.y;

	menu.TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, point.x, point.y, this);

	menu.DestroyMenu();
}


void CLogLCheckDlg::OnMenuShowSetting()
{
	if(pColordlg.DoModal() == IDOK)
	{
		pColordlg.ShowWindow(SW_SHOW);
	}	
}

LRESULT CLogLCheckDlg::OnUpdateGraphColor(WPARAM wParam, LPARAM lParam)
{
	COLORREF* p_Color;
	COLORREF m_Color, newColor;

	switch(lParam){
	case L2MAX:
		p_Color = &m_L2MaxColor;
		break;
	case L2MIN:
		p_Color = &m_L2MinColor;
		break;
	case LMAX:
		p_Color = &m_LMaxColor;	
		break;
	case LMIN:
		p_Color = &m_LMinColor;
		break;
	case BG_COLOR:
		p_Color = &m_BGColor;
		break;
	case TEXT_COLOR:
		p_Color = &m_TextColor;
		break;
	case GRID_COLOR:
		p_Color = &m_GridColor;
		break;
	case LINE_GRAPH_COLOR:
		p_Color = &m_LineGraphColor;
		break;
	case POINT_GRAPH_COLOR:
		p_Color =&m_PointGraphColor;
		break;
	case AVG_LINE_COLOR:
		p_Color = &m_AvgLineColor;
		break;
	default:
		return 0;
	}
	
	m_Color = *p_Color;
	CColorDialog myDLG(m_Color);

	if(myDLG.DoModal() == IDOK){
		newColor = myDLG.GetColor();
		if(newColor != m_Color){
			*p_Color = newColor;
		}
	}

	SetColorDataDisp();
	p_Color = NULL;

	Invalidate();
	UpdateWindow();
	
	return 0;
}

void CLogLCheckDlg::SetColorDataDisp()
{
	WPARAM wP;
	LPARAM lP;

	wP = L2MAX;
	lP = RGB(GetRValue(m_L2MaxColor),GetGValue(m_L2MaxColor), GetBValue(m_L2MaxColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = L2MIN;
	lP = RGB(GetRValue(m_L2MinColor),GetGValue(m_L2MinColor), GetBValue(m_L2MinColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = LMAX;
	lP = RGB(GetRValue(m_LMaxColor),GetGValue(m_LMaxColor), GetBValue(m_LMaxColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = LMIN;
	lP = RGB(GetRValue(m_LMinColor),GetGValue(m_LMinColor), GetBValue(m_LMinColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = BG_COLOR;
	lP = RGB(GetRValue(m_BGColor),GetGValue(m_BGColor), GetBValue(m_BGColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = TEXT_COLOR;
	lP = RGB(GetRValue(m_TextColor),GetGValue(m_TextColor), GetBValue(m_TextColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = GRID_COLOR;
	lP = RGB(GetRValue(m_GridColor),GetGValue(m_GridColor), GetBValue(m_GridColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = LINE_GRAPH_COLOR;
	lP = RGB(GetRValue(m_LineGraphColor),GetGValue(m_LineGraphColor), GetBValue(m_LineGraphColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = POINT_GRAPH_COLOR;
	lP = RGB(GetRValue(m_PointGraphColor),GetGValue(m_PointGraphColor), GetBValue(m_PointGraphColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	wP = AVG_LINE_COLOR;
	lP = RGB(GetRValue(m_AvgLineColor),GetGValue(m_AvgLineColor), GetBValue(m_AvgLineColor));
	pColordlg.SendMessage(pColordlg.GetNameDlg(), wP, lP);

	WriteIniFile();
}

LRESULT CLogLCheckDlg::OnProcessTFCMessage(WPARAM wParam, LPARAM lParam){
	
	switch(wParam)
	{
		case TFC_LOGLCHECK_L2MIN_UPDATE:
		{
			m_L2Min = double(lParam);
			break;
		}
		case TFC_LOGLCHECK_L2MAX_UPDATE:
		{
			m_L2Max = double(lParam);
			break;
		}
		case TFC_LOGLCHECK_DATA_UPDATE:
		{
			for(int i=19; i>0; i--){
				arrL[i] = arrL[i-1];
			}
			arrL[0] = double(lParam);

			m_CountPoint++;
			if(m_CountPoint >20){
				m_CountPoint = 20;
			}
			break;
		}
		case TFC_LOGLCHECK_CLEAR:
		{
			for(int i=0; i<20; i++){
				arrL[i] = 0;
			}
			break;
		}
		default:
			break;
	}
	
	Invalidate();
	UpdateWindow();
	return 0;
}

void CLogLCheckDlg::ReadFile(LPCTSTR filePath, LPCTSTR lpszSection, LPCTSTR lpszKey, int Data[])
{
	int		numElements = (Data == m_colors) ? 3 : 4;
	char	inBuf[40] = "", *buff = "", *bp = "";
	int		n, temp, leng;
			
	temp = GetPrivateProfileString (lpszSection, lpszKey, NULL, LPTSTR(inBuf), 40, filePath); 
	if(temp){
		if(sscanf(inBuf,"%d",&n) == 1){
			leng = (n+1)*20+1;
			buff = new char[leng];
			temp = GetPrivateProfileString (lpszSection,lpszKey, NULL, LPTSTR(buff), leng, filePath); 
			if(temp){
				bp = buff;
				bp = strchr(bp,',');
				if(bp){
					bp ++;
					for(int i = 0; i<n && i<numElements; i++){
						if(sscanf(bp,"%d",&Data[i]) != 1){
							break;
						}
						bp = strchr(bp,',');
						if(bp)	bp ++;
						else{
							i++;
							break;
						}
					}
				}
			}
			delete[] buff;
		}
	}

	//for(int i=0; i<numElements; i++){
	//	Data[i] = 0; 
	//}
}

void CLogLCheckDlg::WriteFile(LPCTSTR filePath, LPCTSTR lpszSection, LPCTSTR lpszKey, int Data[])
{
	CString	strA,strB;
	int	numElements = (Data == m_colors) ? 3 : 4;

	strA.Format(_T("%d"),numElements);
	
	for(int i=0;i<numElements;i++){
		strB.Format(_T(",%d"), Data[i]);
		strA += strB;
	}
	WritePrivateProfileString (lpszSection, lpszKey, strA, filePath);
}

void CLogLCheckDlg::ReadIniFile()
{
	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("L2Max Color"), m_colors);
	m_L2MaxColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("L2Min Color"), m_colors);
	m_L2MinColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("LMax Color"), m_colors);
	m_LMaxColor = RGB(m_colors[0], m_colors[1],m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("LMin Color"), m_colors);
	m_LMinColor = RGB(m_colors[0], m_colors[1],m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("BG Color"), m_colors);
	m_BGColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Text Color"), m_colors);
	m_TextColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Grid Color"), m_colors);
	m_GridColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("L Max Color"), m_colors);
	m_LMaxColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("L Max Color"), m_colors);
	m_LMaxColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Line Graph Color"), m_colors);
	m_LineGraphColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Point Graph Color"), m_colors);
	m_PointGraphColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Avg Line Color"), m_colors);
	m_AvgLineColor = RGB(m_colors[0], m_colors[1], m_colors[2]);

	ReadFile(_T(INIT_FILE_PATH), _T("Setting Position Window"), _T("Position Window"), m_windowSize);
}

void CLogLCheckDlg::WriteIniFile()
{
	COLORREFToArray(m_L2MaxColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("L2Max Color"), m_colors);

	COLORREFToArray(m_L2MinColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("L2Min Color"), m_colors);

	COLORREFToArray(m_LMaxColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("LMax Color"), m_colors);

	COLORREFToArray(m_LMinColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("LMin Color"), m_colors);

	COLORREFToArray(m_BGColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("BG Color"), m_colors);

	COLORREFToArray(m_TextColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Text Color"), m_colors);

	COLORREFToArray(m_GridColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Grid Color"), m_colors);

	COLORREFToArray(m_LineGraphColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Line Graph Color"), m_colors);

	COLORREFToArray(m_PointGraphColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Point Graph Color"), m_colors);

	COLORREFToArray(m_AvgLineColor);
	WriteFile(_T(INIT_FILE_PATH), _T("Setting Color"), _T("Avg Line Color"), m_colors);

	CRect rect;
	GetWindowRect(&rect);
	m_windowSize[0] = rect.top;
	m_windowSize[1] = rect.bottom;
	m_windowSize[2] = rect.left;
	m_windowSize[3] = rect.right;

	WriteFile(_T(INIT_FILE_PATH), _T("Setting Position Window"), _T("Position Window"), m_windowSize);
}


void CLogLCheckDlg::COLORREFToArray(COLORREF color)
{
	m_colors[0] = GetRValue(color);
	m_colors[1] = GetGValue(color);
	m_colors[2] = GetBValue(color);
}
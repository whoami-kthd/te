
// LogLCheckDlg.h : header file
//

#pragma once


// CLogLCheckDlg dialog
class CLogLCheckDlg : public CDialogEx
{
// Construction
public:
	CLogLCheckDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_LOGLCHECK_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

private:
	afx_msg void DrawLine(CDC* dc, COLORREF color, int x1, int y1, int x2, int y2);
	afx_msg void DrawPoint(CDC* dc, COLORREF color, int x, int y);
	afx_msg void WriteText(CDC* dc, COLORREF color, int x, int y, CString text);
	
	afx_msg void DrawGrid(CDC* dc);
	afx_msg void DrawGraph(CDC* dc);
	afx_msg void DrawLimitLines(CDC* dc);

	afx_msg void OnMenuShowSetting();
	afx_msg LRESULT OnUpdateGraphColor(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnProcessTFCMessage(WPARAM wParam, LPARAM lParam);
	void SetColorDataDisp();

	void ReadFile(LPCTSTR filePath, LPCTSTR lpszSection, LPCTSTR lpszKey, int Data[]);
	void WriteFile(LPCTSTR filePath, LPCTSTR lpszSection, LPCTSTR lpszKey,int Data[]);
	void ReadIniFile();
	void WriteIniFile();
	void COLORREFToArray(COLORREF color);

	COLORREF m_L2MaxColor;
	COLORREF m_LMaxColor;
	COLORREF m_L2MinColor;
	COLORREF m_LMinColor;
	COLORREF m_BGColor;
	COLORREF m_TextColor;
	COLORREF m_GridColor;
	COLORREF m_LineGraphColor;
	COLORREF m_PointGraphColor;
	COLORREF m_AvgLineColor;

	enum
	{
		L2MAX = 0,
		L2MIN = 1,
		LMAX = 2,
		LMIN = 3,
		BG_COLOR = 4,
		TEXT_COLOR = 5,
		GRID_COLOR = 6,
		LINE_GRAPH_COLOR = 7,
		POINT_GRAPH_COLOR = 8,
		AVG_LINE_COLOR = 9
	};

	int xScale;
	int yScale;

	double m_scale;
	double m_CountPoint;
	double arrL[20];
	double m_LMax, m_L2Max;
	double m_LMin, m_L2Min;
	double m_AvgVal;
	double m_highGrid;

	int m_colors[3];
	int m_windowSize[4];

	//ColorSetting pColordlg;

public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);
};

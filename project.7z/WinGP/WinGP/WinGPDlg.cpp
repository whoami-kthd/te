
// WinGPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WinGP.h"
#include "WinGPDlg.h"
#include "afxdialogex.h"
#include <process.h>
#include <Tlhelp32.h>
#include <string.h>
#include <iostream>
#include <sstream>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CWinGPDlg dialog
#define TFC_LOGLCHECK_DATA_UPDATE		1009
#define TFC_LOGLCHECK_L2MIN_UPDATE		1010
#define TFC_LOGLCHECK_L2MAX_UPDATE		1011
#define TFC_LOGLCHECK_CLEAR				1012


static  UINT APP_SEND_DATA_UPDATE_CTRL = RegisterWindowMessage(_T("LogLCheck"));

DWORD FindProcessId(const std::wstring& processName);

CWinGPDlg::CWinGPDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CWinGPDlg::IDD, pParent)
	, m_minString(_T(""))
	, m_maxString(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWinGPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MIN_EDIT, m_minControl);
	DDX_Control(pDX, IDC_MAX_EDIT, m_maxControl);
	DDX_Text(pDX, IDC_MIN_EDIT, m_minString);
	DDX_Text(pDX, IDC_MAX_EDIT, m_maxString);
}

BEGIN_MESSAGE_MAP(CWinGPDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ON_BTN, &CWinGPDlg::OnBnClickedOnBtn)
	ON_BN_CLICKED(IDC_OFF_BTN, &CWinGPDlg::OnBnClickedOffBtn)
	ON_BN_CLICKED(IDC_UPDATE_DATA_BTN, &CWinGPDlg::OnBnClickedUpdateDataBtn)
	ON_BN_CLICKED(IDC_CLEAR_BTN, &CWinGPDlg::OnBnClickedClearBtn)
	ON_WM_CLOSE()
END_MESSAGE_MAP()


// CWinGPDlg message handlers

BOOL CWinGPDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWinGPDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWinGPDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CWinGPDlg::OnBnClickedOnBtn()
{
    STARTUPINFO si = { sizeof(STARTUPINFO) };
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    PROCESS_INFORMATION pi;

	if(FindWindow(NULL, _T("LogLCheck")) == NULL) {
		CreateProcess(TEXT("G:\\TFC\\25_4\\project\\LogLCheck\\Debug\\LogLCheck.exe"), NULL , NULL, NULL, FALSE, CREATE_NO_WINDOW , NULL, NULL, &si, &pi);
	}
}


void CWinGPDlg::OnBnClickedOffBtn()
{
	DWORD processID = FindProcessId(TEXT("LogLCheck.exe"));

	HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, 0, processID);
    if (hProcess != NULL)
    {
        TerminateProcess(hProcess, 9);
        CloseHandle(hProcess);
    }
}



DWORD FindProcessId(const std::wstring& processName)
{
	PROCESSENTRY32 processInfo;
	processInfo.dwSize = sizeof(processInfo);

	HANDLE processesSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
	if ( processesSnapshot == INVALID_HANDLE_VALUE )
		return 0;

	Process32First(processesSnapshot, &processInfo);
	if (!processName.compare(processInfo.szExeFile) )
	{
		CloseHandle(processesSnapshot);
		return processInfo.th32ProcessID;
	}

	while (Process32Next(processesSnapshot, &processInfo) )
	{
		if ( !processName.compare(processInfo.szExeFile) )
		{
			CloseHandle(processesSnapshot);
			return processInfo.th32ProcessID;
		}
	}
	
	CloseHandle(processesSnapshot);
	return 0;
}



void CWinGPDlg::OnBnClickedUpdateDataBtn()
{
	CString m_minString, m_maxString;
	m_minControl.GetWindowText(m_minString);
	m_maxControl.GetWindowText(m_maxString);

	if((m_minString == "") || m_maxString == "") {
		MessageBox(_T("Please enter the min, max value"));
		return;
	}

	int min = _ttoi(m_minString);
	int max = _ttoi(m_maxString);

	/* Create randomNumber between min and max */
	int randomNumber;
	randomNumber= rand() % (max - min + 1) + min;

	// Send message to Receiver tool
	HWND ftdInstance = ::FindWindow(NULL, _T("LogLCheck"));
	
	// Posst message to Receiver tool
	if(ftdInstance != (HWND)NULL) {
		::PostMessage(ftdInstance, APP_SEND_DATA_UPDATE_CTRL, TFC_LOGLCHECK_L2MAX_UPDATE, max);
		::PostMessage(ftdInstance, APP_SEND_DATA_UPDATE_CTRL, TFC_LOGLCHECK_L2MIN_UPDATE, min);
		::PostMessage(ftdInstance, APP_SEND_DATA_UPDATE_CTRL, TFC_LOGLCHECK_DATA_UPDATE, randomNumber);
	}
	else {
		MessageBox(_T("Can not find LogLCheck window !!!\n\nPlease click ON button to open LogLCheck window."));
	}
}


void CWinGPDlg::OnBnClickedClearBtn()
{
	HWND ftdInstance = ::FindWindow(NULL, _T("LogLCheck"));
	
	// Posst message to Receiver tool
	if(ftdInstance != (HWND)NULL) {
		::PostMessage(ftdInstance, APP_SEND_DATA_UPDATE_CTRL, TFC_LOGLCHECK_CLEAR, 0);
	}
	else {
		MessageBox(_T("Can not find LogLCheck window !!!\n\nPlease click ON button to open LogLCheck window."));
	}

}


void CWinGPDlg::OnClose()
{
	CDialogEx::OnClose();
	
	OnBnClickedOffBtn();
}

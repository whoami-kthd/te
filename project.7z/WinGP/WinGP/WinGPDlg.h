
// WinGPDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CWinGPDlg dialog
class CWinGPDlg : public CDialogEx
{
// Construction
public:
	CWinGPDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_WINGP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
//	afx_msg void OnGetMinMaxInfo(MINMAXINFO* lpMMI);
	CEdit m_minControl;
	CEdit m_maxControl;
	CString m_minString;
	CString m_maxString;
	afx_msg void OnBnClickedOnBtn();
	afx_msg void OnBnClickedOffBtn();
	afx_msg void OnBnClickedUpdateDataBtn();
	afx_msg void OnBnClickedClearBtn();
	afx_msg void OnClose();
};

// Yanmar Confidential 20200918
/**
 * CSVデータハンドルクラス
 *
 * CSVファイルデータを操作するためのクラス。主にデバッグ用。
 * - 汎用のCSVパーサと異なり、GudianceData、DisplayDataに特化した機能がある。
 */
#pragma once

#include "PolyLib/Common.h"

#include <cstddef>
#include <iostream>
#include <iomanip>

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>

namespace yanmar { namespace PathPlan {
namespace Csv{
	static const std::string nullcol{};
	/**
	 CSVデータクラス
	 
     CSV文字列を2次元文字列配列として操作するクラス。行列インデックスの他に次のようなPathPlan CSVデータ用機能がある。
     - タイトルを指定して行取得
     - タイトルを指定して複数行取得
	 */
	class CsvData {
	public:
        using col_type = std::string;               ///< 列データ型
        using row_type = std::vector<col_type>;     ///< 行データ型(列データ列)
        using data_store = std::vector<row_type>;   ///< 全体のデータ型(行データ列)

        CsvData() = default;
        CsvData(const CsvData&) = default;
        CsvData(CsvData&&) = default;
        CsvData(const std::string& csvString) {
            parse(csvString);
        }
        CsvData(const data_store& data) :
            _data(data)
        {
        }
        CsvData(data_store&& data) :
            _data(data)
        {
        }
        ~CsvData() = default;
        
        CsvData& operator=(const std::string& csvString) {
            clear();
            parse(csvString);
            
            return *this;
        }

        /// クリア
        void clear() noexcept { return _data.clear(); }
        /// 空検査
        bool empty() const noexcept { return _data.empty(); }
        /// 戻り値のdata_store::iterator有効性検査
        bool isValid(const data_store::const_iterator& it) const noexcept {
            return (it != _data.cend());
        }

        /**
         CSV入力
         
         CSV文字列データを入力する。

         @param[in] csvString   CSVデータ
         */
		void parse(const std::string& csvString) {
			const std::string rowDelim("\r\n");
			const std::string colDelim(",");
			std::vector<std::string> rows;
			boost::split(rows, csvString, boost::is_any_of(rowDelim), boost::algorithm::token_compress_on);
			data_store guidanceData;
			for (auto& row : rows) {
				row_type columns;
				boost::split(columns, row, boost::is_any_of(colDelim), boost::algorithm::token_compress_on);
                for (auto& col : columns) {
                    boost::trim(col);
                }
				_data.push_back(columns);
			}
		}

        /**
         文字列出力
         
         内部データを指定の区切り文字(列)で接続して文字列出力する。
         - デフォルトではそれぞれカンマとLFである。

         @param[in] colDelim 列区切り文字(列)
         @param[in] rowDelim 行区切り文字(列)
         @return 出力文字列
         */
		std::string toString(const std::string& colDelim = ",", const std::string& rowDelim = "\n") const {
			std::stringstream ss;
			for (const auto& row : _data) {
                ss << boost::algorithm::join(row, colDelim) << rowDelim;
			}
			
			return ss.str();
		}
	
		/**
		 カラムデータ取得(インデックス指定)
		 
		 指定行・列インデックスのデータを指定の型に変換して取得する
		 
         @tparam[in] T 取得する型
		 @param[in] nRow 取得する行インデックス番号
         @param[in] nCol 取得する列インデックス番号
		 @return 指定行の参照
		 */
		template<typename T>
		const T& at(size_t nRow, size_t nCol) const noexcept {
			try {
				return boost::lexical_cast<T>(_data.at(nRow).at(nCol));
			} catch(...) {
				return boost::lexical_cast<T>(nullcol);
			}
		}
		
		/**
		 行取得(インデックス指定)
		 
		 行番号指定で行データを取得する
		 
		 @param[in] numRow 取得する行インデックス番号
		 @return 指定行の参照
		 */
		const row_type& row(size_t rowIndex) const noexcept {
			try {
				return _data.at(rowIndex);
			} catch(...) {
				return nullrow;
			}
		}
		
		/**
		 行参照(名前指定)
		 
		 名前指定で行データを参照する。存在しない場合、nullrowを返す。
		 
		 @param[in] strRow 項目名。FP, PPなど。
		 @return 指定行の参照
		 */
		const row_type& row(const std::string& title) const noexcept {
			auto it = find(title);
            if (!isValid(it)) {
                return nullrow;
            }

            return *it;
		}
		
		/**
		 複数行データ取得(名前指定)
		 
		 複数データを持つ項目を取得する。存在しない場合、空のdata_storeを返す。
		 
		 @param[in] name 項目名。FP, PPなど。
		 @return 指定項目の全行コピー
		 */
		data_store getRows(const std::string& name) const {
			auto it = find(name);
            if (!isValid(it)) {
                return nullstore;
            }
			auto& strCount = it->at(1);
			int nCount = boost::lexical_cast<int>(strCount);
			it++;
			auto endIt = next(it, nCount);
			data_store rows{it, endIt};
			return rows;
		}
		
        /**
         指定カラムデータ取得
         
         行、列のインデックス指定でカラムを参照する。
         
         @param[in] nRow    行インデックス
         @param[in] nCol    列インデックス
         @return    カラム内容文字列の参照
         */
        col_type& col(size_t nRow, size_t nCol) {
			return _data.at(nRow).at(nCol);
		}

        /**
         @overload
         */
        const col_type& col(size_t nRow, size_t nCol) const {
            return _data.at(nRow).at(nCol);
        }

        /**
         行タイトル検索
         
         指定のタイトル文字列をタイトル(先頭カラム)に持つ行を探索し、見つかればその行を指すイテレータを返す。
         - 見つからなければ_data::cend()を返す。戻り値のはisValid()で検査すること。

         @param[in] title 探索する行タイトル
         @return    発見した行を指すdata_store::const_iterator
         */
		data_store::const_iterator find(const std::string& title) const {
			auto it = find_if(_data.begin(), _data.end(),
							  [this, title](const row_type& vs) {
								  return (!vs.empty() && vs[0] == title);
							  });
			return it;
		}

    public:
		/// パース後データ
		data_store _data;

        const data_store nullstore;
        const row_type nullrow;
        static const row_type::value_type nullcol;
	};
	
	namespace GuidanceData {

		/**
		 GuidanceDataのPP項目クラス
			*/
		class PP {
		public:
			std::vector<std::string>& _data;
			enum class Columns : int {
				Name,
				SegType,
				RideType,
				StartLon,
				StartLat,
				EndLon,
				EndLat,
				CenterLon,
				CenterLat,
				TurnType,
				TurnRadius,
				TurnDirection,
				MoveDirection
			};
		
			template<typename T>
			T column(Columns numCol) const {
				try {
					return boost::lexical_cast<T>(_data.at(static_cast<int>(numCol)));
				} catch(...) {
					return boost::lexical_cast<T>(nullcol);
				}
			}
            
            template<typename T>
            bool compColumn(const PP& target, Columns numCol) const {
                return (column<T>(numCol) == target.column<T>(numCol));
            }
            
            std::string toString(const std::string& delim = ",") const {
                std::stringstream ss;
                for (auto& col : _data) {
                    ss << col << delim;
                }
                
                return ss.str();
            }
		};
	}
} // namespace Csv
}} // namespace yanmar::PathPlan

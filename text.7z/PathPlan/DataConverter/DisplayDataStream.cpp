// Yanmar Confidential 20200918
/**
 * ディスプレイデータのCVSフォーマット出力用クラス
 */

// #define DEBUG_LOG
#define LOG_TAG "PathPlan:DisplayDataStream"

#include "PolyLib/Common.h"
#include "DisplayDataStream.hpp"

#include <cstddef>
#include <string>
#include <vector>
#include <stdexcept>
#include <cmath>

#include "PathPlanIF.hpp"
#include "PolyLib/DisplayData.h"

using namespace std;
using namespace yanmar::PathPlan::DataConverter;

namespace yanmar { namespace PathPlan {

/**
 ディスプレイデータCSVフォーマット入力オペレータ
 
 パスプラン出力データDisplayをDisplayDataStreamに入力し、ディスプレイ用CSV文字列にフォーマットする
 */
DisplayDataStream& operator<<(yanmar::PathPlan::DisplayDataStream& os, const Display& displayData) {
	/*Writing the Start point and End point data to FIFO Path*/
	os.setStartEndPoint(displayData);
	
	/*Writing Margins information to FIFO Path*/
	os.setMargins(displayData);
	
	/*Writing PolyLines data to FIFO Path*/
	os.setPolyLinesData(displayData);
	
	/*Path data Points to platform*/
	os.setPathData(displayData);
	
	if (!displayData.MannedTracVertexs.empty()) {
		os.setManndPathData(displayData);
	}
	
	return os;
}

/**
 作業開始・終了点入力(ディスプレイ用)
 
 作業開始・終了点ををフォーマットする。
 
 @param[in,out] displayData 入力するDisplayインスタンス
 */
void DisplayDataStream::setStartEndPoint(const Display& displayData) {
	LOGD(LOG_TAG ":setStartEndPoint", "(DisplayDataStream)");
	DisplayDataStream& fout = *this;
	
	/*Writing Start point values to FIFO*/
	fout << "StartPoint" << EOL;
	fout << "," << "Lat" << "," "," << "Lon" << EOL;
	fout << "," << "Character" << "," << "Mantissa" << "," << "Character" << "," << "Mantissa" << EOL;
	fout << "," << splitFunc(displayData.stPoint) << EOL;
	
	/*Writing End point values to FIFO*/
	fout << "EndPoint" << EOL;
	fout << "," << "Lat" << "," "," << "Lon" << EOL;
	fout << "," << "Character" << "," << "Mantissa" << "," << "Character" << "," << "Mantissa" << EOL;
	fout << "," << splitFunc(displayData.edPoint) << EOL;
}

/**
 枕地ポリゴン入力(ディスプレイ用)
 
 HP, OHPのポリゴンデータをフォーマットする。
 
 @param[in,out] displayData 入力するDisplayインスタンス
 */
void DisplayDataStream::setPolyLinesData(const Display& displayData) {
	LOGD(LOG_TAG ":setPolyLinesData", "(DisplayDataStream)");
	constexpr int Obs_ptList = 4;

	DisplayDataStream& fout = *this;
	const auto& boundaryHeadlandVert = displayData.DisplayBoundaryHeadlandVert;
	const auto& obstaclesHeadlandvert = displayData.DisplayObsHeadlandvert;
	const int obstaclesNum = displayData.noObs;
	const int TotalPloy_lines = 1 + obstaclesNum;
	const int points = displayData.boundaryVernum;
	int PolyLine = 1;
	
	// fixed real format, precision 7 digits
	fout.setf(fixed);
	fout << setprecision(7);
	
	/*Writing the Field points in to the FIFO*/
	fout << "HeadlandArea" << "," << "TotalPolylines:" << "," << TotalPloy_lines << EOL;
	fout << "," << "PolyLine:" << "," << PolyLine << "," << "Points:" << "," << points << EOL;
	fout << "," << "PointList:" << EOL;
	fout << "," "," << "Lat" << "," << "Lon" << EOL;
	fout << "," "," << "Character" << "," << "Mantissa" << "," << "Character" << "," << "Mantissa" << EOL;
	
	for (const auto& ci : boundaryHeadlandVert) {
		// fixed format values writing into file
		fout << "," "," << splitFunc(ci) << EOL;
	}
	
	PolyLine++;
	
	/*Writing the Obstacle points in to FIFO path*/
	int PtlistCount = 0;
	for (int i = 0; i < obstaclesNum; i++) {
		fout << "," << "PolyLine:" << "," << PolyLine << "," << "Points:" << "," << Obs_ptList << EOL;
		fout << "," << "PointList:" << EOL;
		fout << "," "," << "Lat" << "," << "Lon" << EOL;
		fout << "," "," << "Character" << "," << "Mantissa" << "," << "Character" << "," << "Mantissa" << EOL;
		
		/*Making the Count value as zero to move to the next*/
		int Count = 0;
		
		/*Adding the PtlistCount value to start properly
		 for next Obstacle values*/
		for (auto ci = obstaclesHeadlandvert.begin() + PtlistCount; ci != obstaclesHeadlandvert.end() && Count < 4; ci++) {
			// fixed format values writing into file
			fout << "," "," << splitFunc(*ci) << EOL;
			
			Count++;
			PtlistCount++;
		}
		
		PolyLine++;
		
	}
}

/**
 マージンデータ入力(ディスプレイ用)
 
 サイドマージンのポリゴンデータをフォーマットする。
 
 @param[in,out] displayData 入力するDisplayインスタンス
 */
void DisplayDataStream::setMargins(const Display& displayData) {
	LOGD(LOG_TAG ":setMargins", "(DisplayDataStream)");
	DisplayDataStream& fout = *this;
//	const int points = 0;

	/*For Margin A*/
	fout << "MarginA" << "," << "Points:" << "," << 0 << EOL;
	fout << "," << "PointList:" << EOL;
	fout << "," "," << "Lat" << "," "," << "Lon" << EOL;
	fout << "," "," << "Character" << "," << "Mantissa" << "," << "Character" << "," << "Mantissa" << EOL;
#if 0
	for (int i = 0; i < points; i++) {
		/*copy the latitude-longitude values*/
		/*
		 lat = ci->v1[1].first;
		 lon = ci->v1[1].second;
		 SplitFunc(lat,lon,Ptval);
		 fout<<","<<Ptval[0]<<","<<Ptval[1];
		 fout<<","<<Ptval[2]<<","<<Ptval[3]<<'\n';
		 */
	}
#endif

	/*For Margin B*/
	fout << "MarginB" << "," << "Points:" << "," << 0 << EOL;
	fout << "," << "PointList:" << EOL;
	fout << "," "," << "Lat" << "," "," << "Lon" << EOL;
	fout << "," "," << "Character" << "," << "Mantissa" << "," << "Character" << "," << "Mantissa" << EOL;
#if 0
	for (int i = 0; i < points; i++) {
		/*copy the latitude-longitude values*/
		/*
		 lat = ci->v1[1].first;
		 lon = ci->v1[1].second;
		 SplitFunc(lat,lon,Ptval);
		 fout<<","<<Ptval[0]<<","<<Ptval[1];
		 fout<<","<<Ptval[2]<<","<<Ptval[3]<<'\n';
		 */
	}
#endif
}

/**
 有人トラクターパス入力

 有人トラクター用のパスデータをフォーマットする。
 
 @param[in,out] displayData 入力するDisplayインスタンス
 */
int DisplayDataStream::setManndPathData(const Display& displayData) {
	LOGD(LOG_TAG ":setManndPathData", "(ostream)");
	DisplayDataStream& os = *this;
	const auto& mannedPath = displayData.MannedTracVertexs;
	
	os << "2ndTractor" << "," << "TotalSegments:" << "," << (mannedPath.size() / 2) << EOL;
	os << "," << "#StartPoint" << "," "," << "#EndPoint" << "," "," << EOL;

	for (int i = 0; i < (int)mannedPath.size() / 2; i++) {
		const int i1 = i * 2;
		const int i2 = i1 + 1;
		auto& data1 = mannedPath[i1];
		auto& data2 = mannedPath[i2];
		
		os << std::setprecision(10);
		os << "," << data1.lat << "," << data1.lon << "," << data2.lat << "," << data2.lon << EOL;
	}

	return 0;
}

}} // yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 * ディスプレイデータのCVSフォーマット出力用クラス
 */
#pragma once

#include "OutputDataStream.hpp"

namespace yanmar { namespace PathPlan {

	/**
	 * ディスプレイデータフォーマット用文字列ストリームクラス
	 *
	 * パスプランデータをディスプレイ用のデータにフォーマットする文字列ストリームクラス。
	 *	- 小数値は fixed 7桁精度出力。
	 */
	class DisplayDataStream : public OutputDataStream {
	public:
		DisplayDataStream() : OutputDataStream() {
			*this << std::setprecision(7);
		}
		
		/*Function for writing the Header information*/
		void HeaderData(const class Display& displayData);

		// 開始終了点入力
		void setStartEndPoint(const class Display& displayData);
	
		// 外形以外のポリゴンデータ入力
		void setPolyLinesData(const class Display& displayData);
		
		// サイドマージンデータ入力
		void setMargins(const class Display& displayData);

		// パスプラン結果入力
		void setPathData(const Display& displayData) {
			OutputDataStream::setPathData(displayData.PlanPathToDisplay);
		}
		
		// 有人トラクターパス入力
		int setManndPathData(const class Display& displayData);
		
	protected:
		virtual string formatPathData(const GeoPoint& point) {
			return DataConverter::splitFunc(point);
		}
	};
	
	/// パスプラン入力パラメータ入力オペレータ
	DisplayDataStream& operator<<(DisplayDataStream& os, const class InputData& inData);
	/// パスプラン出力データ入力オペレータ
	DisplayDataStream& operator<<(DisplayDataStream& os, const class Display& displayData);

}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 * ガイダンスデータのCVSフォーマット出力用クラス
 */

//#define LOGLEVEL 5
#define LOG_TAG "PathPlan:GuidanceDataStream"

#include "PolyLib/Common.h"
#include "GuidanceDataStream.hpp"

#include <cstddef>
#include <string>
#include <vector>
#include <stdexcept>
#include <cmath>

#include "PathPlanIF.hpp"
#include "PolyLib/DisplayData.h"
#include "PolyLib/FieldPolygon.hpp"

using namespace std;
using namespace yanmar::PathPlan::DataConverter;

namespace yanmar { namespace PathPlan {

/**
 * 測地系ポリゴンの出力
 */
GuidanceDataStream& operator<<(GuidanceDataStream& os, const GeoPolygon& polygon) {
	os << fixed << std::setprecision(7);
	for (const auto& point : polygon) {
		os << ",";
		os << point << EOL;
	}
	
	return os;
}

/**
 デカルト座標系ポリゴン出力
 
 デカルト座標ポリゴンを測地座標系へ変換して出力する
 */
GuidanceDataStream& operator<<(GuidanceDataStream& os, const Polygon& polygon) {
	os << fixed << std::setprecision(7);
	for (const auto& point : polygon) {
		GeoPoint geoPoint{point};
		os << ",";
		os << os.csGeo.convert(geoPoint) << EOL;
	}
	
	return os;
}

/**
 * 入力データCSVフォーマット
 *
 * 入力データ(InputData)をガイダンス用データフォーマッタに入力する。
 *  - 単位変換のパラメータは SRC_TO_GUIDANCE を使用する。
 *      - ガイダンスデータの長さの単位はTW (トラクター幅) のみmmで、他はcmである。
 *      - パスプラン内では使用しないがGuidanceへパススルーするデータ値の整合性を保つため、内部単位(m)に変換していないInputDataを要求する。
 */
GuidanceDataStream& operator<<(GuidanceDataStream& os, const InputData& inData) {
	const Tractor& tractor0 = convertUnit(inData.tractors[0], SRC_TO_GUIDANCE);
	Tractor tractor1;
	if (2 <= inData.tractors.size()) {
		tractor1 = convertUnit(inData.tractors[1], SRC_TO_GUIDANCE);
	}
	const Implement& implement0 = tractor0.implement;
	const GNSS& gnss = tractor0.gnss;
	const ObstacleSensor& obstacleSensor = tractor0.obstacleSensor;
	const Field& field = inData.field;
    // 単位変換
	const WorkSetting& work = convertUnit(inData.work, SRC_TO_GUIDANCE);

	os << "BS,"		<< field.bs.type << EOL;	// Base Station type
	os << "LLAT,"	<< field.bs.pos.lat << EOL;	// Base Stasion Latitude
	os << "LLON,"	<< field.bs.pos.lon << EOL;	// Base Station Longitude
	// tractor parameters
	os << "TM,"		<< tractor0.model	<< EOL;	// Tractor Model name
	os << "TW,"		<< lround(convertUnit(tractor0.width, CM2MM))  << EOL; // Tractor Width (mm)  !!ここだけmm
	os << "WB,"		<< lround(tractor0.wheelbase)    << EOL; // Wheel Base (cm)
	os << "TH,"		<< lround(tractor0.height)       << EOL; // Tractor Height (cm)
	os << "TLRT,"	<< lround(gnss.lengthToRearAxle) << EOL; // Tractor Length from GNSS to Rear axle (cm)
	os << "TLF,"	<< lround(gnss.lengthToFrontEnd) << EOL; // Tractor Length from GNSS to Front end (cm)
	os << "TLR,"	<< lround(gnss.lengthToRearEnd)  << EOL; // Tractor Length from GNSS to Rear end (cm)
	os << "OLF,"	<< lround(obstacleSensor.gnssToFrontLidar) << EOL; // Obstacle sensor Length from GNSS to Front LIDAR (cm)
	os << "OLR,"	<< lround(obstacleSensor.gnssToRearLidar)  << EOL; // Obstacle sensor Length from GNSS to Rear LIDAR (cm)
	os << "YLRT,"	<< lround(tractor0.rearAxleToYawCenter)   << EOL; // Rear axle to Yaw center
	os << "TR,"		<< lround(tractor0.turnRadius)   << EOL; // Turn Radius
	// implement parameters
    // - 作業機位置が前後で項目名が異なる。前後両方などという可能性も無きにしも非ず。
    if (3 <= PATHDATAVER && implement0.pos == Param::Implement::Pos::FRONT) {
        os << "IMP_F,"  << implement0.mountType                 << EOL; // [FRONT only] Implement position (cm)
        os << "IL_F,"   << lround(implement0.length)            << EOL; // [FRONT only] Impremant Length (cm)
        os << "ILW_F,"  << lround(implement0.cultivationPos)    << EOL; // [FRONT only] Impremant Length to Working point (cm)
        os << "IM_F,"   << lround(implement0.mass)              << EOL; // [FRONT only] implement Weight (kg)
        os << "IW_F,"   << lround(implement0.width)             << EOL; // [FRONT only] Imprement Width (cm)
        os << "ILTC_F," << lround(implement0.widthOffset)       << EOL; // [FRONT only] Implement center length from Tractor center (cm)
        os << "IO_F,"   << lround(implement0.overhang)          << EOL; // [FRONT only] Implement Overhang length (cm)
    } else {
        os << "IMP,"    << implement0.mountType                 << EOL; // [REAR only] Implement position (cm)
        os << "IL,"     << lround(implement0.length)            << EOL; // [REAR only] Impremant Length (cm)
        os << "ILW,"    << lround(implement0.cultivationPos)    << EOL; // [REAR only] Impremant Length to Working point (cm)
        os << "IM,"     << lround(implement0.mass)              << EOL; // [REAR only] implement Weight (kg)
        os << "IW,"     << lround(implement0.width)             << EOL; // [REAR only] Imprement Width (cm)
        if (3 <= PATHDATAVER) {
            os << "ILTC,"   << lround(implement0.widthOffset)       << EOL; // [REAR only] Implement center length from Tractor center (cm)
            os << "IO,"     << lround(implement0.overhang)          << EOL; // [REAR only] Implement Overhang length (cm)
        }
    }
	// working parameters
	os << "WP,"     << work.workingPtoMode << EOL; // Working PTO setting {0：OFF/1：ON/2：未使用/3：未設定}
	os << "HP,"     << work.headlandPtoMode << EOL; // Headland PTO setting {0：OFF/1：ON/2：未使用/3：未設定}
	os << "HH,"     << work.headlandHitchMode << EOL; // Headland Hitch control setting {1：MANUAL/2：AUTO_REAR/3：AUTO_FRONT}
    if (3 <= PATHDATAVER) {
        os << "DS,"     << work.driveSystem << EOL; // Drive System {0：未定/1：2駆/2：オートブレーキ（２駆）/3：4駆/4：オートブレーキ/5：倍速/6：倍速＋オートブレーキ/7：旋回2駆/8：旋回2駆+オートブレーキ}
    }
    os << EOL;

	// directionPoints[0]
	os << "DP1,";
	os << field.directionPoints[0] << EOL << EOL;
	// directionPoints[1]
	os << "DP2,";
	os << field.directionPoints[1] << EOL << EOL;

	// Field ouline point list
	os << "FP," << field.outline.size() << EOL;
	os << field.outline << EOL;

	return os;
}

/**
 障害物ポリゴン入力

 障害物ポリゴンはパウンディングボックス矩形しか出力しない

 @param[in] obstacles_ 障害物ポリゴン群
 @return 自分への参照
 */
GuidanceDataStream& GuidanceDataStream::setObstacles(const Polygons_ obstacles_) {
	// Obstacle outline point list
	auto& os = *this;
	const auto& obstacles = *obstacles_;	// TODO: Polygons_を廃止したい。廃止したらPolygons&にすること。
	for (auto it = obstacles.begin(); it != obstacles.end(); ++it) {
		const int count = (int)distance(obstacles.begin(), it) + 1;	// 1 origin
		auto& polygon = *(*it);	// TODO: Polygon_を廃止したい
		os << "OP" << count << "," << polygon.size() << EOL;
		os << polygon << EOL;
	}

	return os;
}

/**
 パスプラン出力データガイダンス用CSVフォーマット
 
 Displayクラスのデータをガイダンス用CSVにフォーマットする。

 @param[in,out] os          出力先GuidanceDataStream
 @param[in]     displayData 出力データ
 @return 自分への参照
 */
GuidanceDataStream& operator<<(GuidanceDataStream& os, const Display& displayData) {
	/*Writing the Start point and End point data to FIFO Path*/
	os.setStartEndPoint(displayData);
	
	/*Path data Points to platform*/
	os.setPathData(displayData);
	
	return os;
}

/**
 作業開始・終了点入力(ガイダンス用)
 
 @param[in] displayData 入力するDisplayインスタンス
 @ingroup Display
 */
void GuidanceDataStream::setStartEndPoint(const Display& displayData) {
	LOGD(LOG_TAG "::GuidanceDataStream::setStartEndPoint", "(Display)");
	GuidanceDataStream& os = *this;
	
	/*Writing Start point values to FIFO*/
	os << "SP,";
	os << displayData.stPoint << EOL << EOL;
	
	/*Writing End point values to FIFO*/
	os << "EP,";
	os << displayData.edPoint << EOL << EOL;
}

/**
 パスデータCSV入力
 
 パスプラン結果のパスデータをCSVフォーマットする。
 
 @param[in] displayData 入力するDisplayインスタンス
 @ingroup Display
 */
void GuidanceDataStream::setPathData(const Display& displayData) {
	LOGD(LOG_TAG "::GuidanceDataStream::setPathData", "(Display)");
	
	GuidanceDataStream& os = *this;
    // fixed real format, precision 7 digits
    os << std::fixed << setprecision(7);

    OutPathData ppList = displayData.DisplayNavPath;
    // vectorなのでremove_if()メンバーは無い
    auto it = std::remove_if(ppList.begin(), ppList.end(),
                             [this](const OutPathData::value_type& v) {
                                 // ガイダンスデータ出力で比較するため文字列化
                                 const auto sEnterPoint = to_string(v.enterPoint());
                                 const auto sLeavePoint = to_string(v.leavePoint());
                                 bool retval = (sEnterPoint == sLeavePoint);
                                 if (retval) {
                                     LOGD(LOG_TAG "::GuidanceDataStream::setPathData()", "[REMOVE PP SEG] type:%d, %s", v.segmentType, sEnterPoint.c_str());
                                 }
                                 return retval;
                             });
    ppList.erase(it, ppList.end()); // 削除を忘れない!

	os << "PP" << "," << ppList.size() << EOL;
	
	// segment
    for (const auto& geoData : ppList) {
        // Start point
        GeoPoint stPoint = geoData.enterPoint();
        // End point
        GeoPoint edPoint = geoData.leavePoint();
        // Center of curve
		GeoPoint cxPoint;
        
        /*Checking whether Segment or Turn*/
        int TrcDirection = geoData.direction;
        int DirectionOfTurn = -1;
        int RideType = geoData.pathAttr.valueForGuidance();
        int TRadius = 0;
        int turnType = geoData.turnType.valueForGuidance();

        // if curve segment
        if (geoData.segmentType == SegmentType::ARCSEG) {
            const int Orient = geoData.Circ.orient;
            DirectionOfTurn = (Orient < 1) ? 0 : 1;
            TRadius = round(convertUnit(geoData.Circ.radius, M2CM));
            cxPoint = geoData.Circ.center;
        }
		// writing to file
		// header part
		os << "," << geoData.segmentType << "," << RideType << ",";
		// path part
		os << stPoint << ",";
		os << edPoint << ",";
		// turn part
		os << cxPoint << "," << turnType << "," << TRadius << "," << DirectionOfTurn << "," << TrcDirection << EOL;
	}
}

}} // yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 * ガイダンスデータフォーマット
 */
#pragma once

#include "OutputDataStream.hpp"

namespace yanmar { namespace PathPlan {

	/**
	 * ガイダンスデータフォーマット出力ストリームクラス
	 *
	 * パスプランデータをガイダンス用データにフォーマットするための文字列ストリームクラス。
	 *  - 生成時点でPATHDATAVERとIDを自身にフォーマット入力する。
	 *  - 入力にInputDataとDisplayを受け付ける。
	 *	- 小数値は fixed 7桁精度出力。
	 *
	 * @note ガイダンスデータ形式に変更が入った場合このクラスを修正する。
	 *
	 * @param[in] id データID
	 */
	class GuidanceDataStream : public OutputDataStream {
	public:
		GuidanceDataStream(const string& id, const Geodesic& aCsGeo) :
			OutputDataStream(),
			csGeo(aCsGeo)
		{
			*this << std::fixed << setprecision(7);
			*this << "PATHDATAVER," << PATHDATAVER << EOL;
			*this << "ID," << id << EOL;

		}

		// 開始終了点入力
		void setStartEndPoint(const yanmar::PathPlan::Display& displayData);
		GuidanceDataStream& setObstacles(const Polygons_ obstacles);
		// パスプラン結果入力
		void setPathData(const yanmar::PathPlan::Display& displayData);
		
		Geodesic csGeo;
	};
	
	/// パスプラン入力データ入力オペレータ
	GuidanceDataStream& operator<<(yanmar::PathPlan::GuidanceDataStream& os, const yanmar::PathPlan::InputData& inData);
	/// パスプラン生成データ入力オペレータ
	GuidanceDataStream& operator<<(yanmar::PathPlan::GuidanceDataStream& os, const yanmar::PathPlan::Display& displayData);
	/// ポリゴン入力オペレータ
	GuidanceDataStream& operator<<(yanmar::PathPlan::GuidanceDataStream& os, const yanmar::PathPlan::GeoPolygon& polygon);
	/// ポリゴンリスト入力オペレータ
	GuidanceDataStream& operator<<(yanmar::PathPlan::GuidanceDataStream& os, const yanmar::PathPlan::GeoPolygonList& polygons);
	/// GeoPoint入力オペレータ
	inline GuidanceDataStream& operator<<(yanmar::PathPlan::GuidanceDataStream& os, const yanmar::PathPlan::GeoPoint& point) {
		os << point.lat << "," << point.lon;
		return os;
	}

}} // namespace yanmar::PathPlan

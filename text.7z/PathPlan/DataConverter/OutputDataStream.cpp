// Yanmar Confidential 20200918
/**
 * データフォーマット用文字列ストリームクラス
 */

//#define LOGLEVEL 5
#define LOG_TAG "PathPlan:OutputDataStream"

#include "PolyLib/Common.h"
#include "OutputDataStream.hpp"

#include <cstddef>
#include <string>
#include <vector>
#include <stdexcept>
#include <cmath>

#include "PathPlanIF.hpp"
#include "PolyLib/DisplayData.h"

using namespace std;
using namespace yanmar::PathPlan::DataConverter;

namespace yanmar { namespace PathPlan {

namespace DataConverter {
/**
 小数分解フォーマット
 
 以下のような小数のCSV出力文字列を返す<br>
 "整数部,小数部"<br>
	- 小数部の出力は指定桁数にround()で丸める。
	- 例: decomposite(123.4563, 3) は "123,456" を返す。
	  つまり、123.465 = 123 + 465 * 10E-3。
 
 @param[in] value 出力する値
 @param[in] digits 小数部の桁数
 @return 結果文字列
 */
string decomposite(double value, int digits) {
	
	stringstream ss;
	
	if (digits == 0) {
		// 小数部無しの場合は整数に丸めて終了
		ss << (int)round(value) << ",0";
	} else {
		// 小数部、整数部取り出し
		double characteristic = 0;
		double mantissa = modf(value, &characteristic);
		// フォーマット
		int intCharactericstic = (int)characteristic;
		int scale = (int)pow(10.0, digits);
		mantissa *= scale;
		int intMantissa = (int)round(mantissa);
		ss << intCharactericstic << "," << intMantissa;
	}
	
	return ss.str();
}

} // DataConverter

/**
 * ポリゴンの入力
 */
OutputDataStream& operator<<(OutputDataStream& os, const GeoPolygon& polygon) {
	os << "," << "PointList:" << EOL;
	os << ",," << "Lat" << "," << "Lon" << EOL;
	for (const auto& point : polygon) {
		os << ",," << point.lat << "," << point.lon << EOL;
	}
	
	return os;
}

/**
 パスデータ入力(汎用)
 
 パスプラン結果のパスデータをフォーマットする。
 @note GuidaneDataはフォーマットが変更されている。
 
 @param[in,out] pathList 入力するパスデータ
 */
void OutputDataStream::setPathData(const OutPathData& pathList) {
	LOGD(LOG_TAG ":setPathData", "(OutPathData)");
	OutputDataStream& os = *this;

    // !ATTENTION: ヘッダ行を変更するとロジックでパースできなくなる
	os << "," << "#Seg-1/Turn-0" << "," << "#FP-0/DR-1/HN-2" << ",";
	os << "#StartPoint" << "," "," "," "," << "#EndPoint" << "," "," "," ",";
	os << "#CenterOfRadius" << "," "," "," "," << "#TurnType" << "," << EOL;
	
    for (const auto& geoData : pathList) {
        // Curve (already divided)
        /*Start point*/
        const GeoPoint& stPoint = geoData.point1();
        /*End point*/
        const GeoPoint& edPoint = geoData.point2();
        // skip redundancy segment
        const auto sEnterPoint = formatPathData(stPoint);
        const auto sLeavePoint = formatPathData(edPoint);
        if (sEnterPoint == sLeavePoint) {
            LOGD(LOG_TAG "::OutputDataStream::setPathData()", "[REMOVE PP SEG] type:%d, %s", geoData.segmentType, sEnterPoint.c_str());
            continue;
        }
        //
        GeoPoint center{0.0, 0.0};
        if (geoData.segmentType == SegmentType::ARCSEG) {
            center = geoData.Circ.center;
        }
        os << "," << geoData.segmentType << "," << geoData.pathAttr.valueForDisplay() << "," << sEnterPoint << "," << sLeavePoint;
        // turn part
        os << "," << formatPathData(center) << "," << geoData.turnType.valueForDisplay() << "," << EOL;
	}
}

}} // yanmar::PathPlan

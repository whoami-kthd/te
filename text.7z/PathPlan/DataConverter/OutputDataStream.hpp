// Yanmar Confidential 20200918
/**
 * データフォーマット用文字列ストリームクラス
 */
#pragma once

#include "PolyLib/Common.h"

#include <cstddef>
#include <iostream>
#include <iomanip>

#include "PolyLib/DisplayData.h"
#include "PathLib/Gauge.hpp"
#include "PathLib/PathGeneratorData.hpp"

namespace yanmar { namespace PathPlan {

	/**
	 * パスプランデータ出力フォーマット用文字列ストリームクラス
	 *
	 * パスプランデータをフォーマット出力するストリームのベースクラス。
	 */
	class OutputDataStream : public std::stringstream {
	public:
        void setPathData(const OutPathData& pathList);

	protected:
        // std::to_string()代替
        // TODO: 実機ビルド環境が対応バージョンになったら消す
        template<typename T>
        string to_string(T val) {
            std::stringstream ss;
            ss << val;
            return ss.str();
        }

        virtual string formatPathData(const GeoPoint& point) {
			std::stringstream ss;
			ss << point.x << "," << point.y;
			return ss.str();
		}
	};

	// InputData出力オペレータ
	inline OutputDataStream& operator<<(OutputDataStream& os, const OutPathData& pathList) {
		os.setPathData(pathList);
		return os;
	}
    // PathGenerator::Gauge出力オペレータ
    inline OutputDataStream& operator<<(OutputDataStream& os, const Gauge& gauge) {
        os << to_string(gauge);
        return os;
    }
    // PathGenerator::Gauge出力オペレータ
    inline OutputDataStream& operator<<(OutputDataStream& os, const PathGeneratorData::HwParam& hwParam) {
        os << to_string(hwParam);
        return os;
    }

namespace DataConverter {
	string decomposite(double value, int digits = 0);
	/// GeoPointの座標の組文字列を返す
	inline string splitFunc(const GeoPoint& point) {
		return decomposite(point.x, 7) + "," + decomposite(point.y, 7);
	}
}

}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 * ディスプレイデータのCVSフォーマット出力用クラス
 */

// #define DEBUG_LOG
#define LOG_TAG "PathPlan:SvgDataStream"

#include "PolyLib/Common.h"
#include "SvgDataStream.hpp"

#include <cstddef>
#include <string>
#include <vector>
#include <stdexcept>
#include <cmath>
#include <algorithm>

#include "PathPlanIF.hpp"
#include "PolyLib/DisplayData.h"
#include "PolyLib/Engine.hpp"

using namespace std;
using namespace yanmar::PathPlan::DataConverter;

namespace yanmar { namespace PathPlan {

namespace {

constexpr double BP_SW = 1;
constexpr double HP_SW = 1;
constexpr double SHP_SW = 1;
constexpr double RHP_SW = 0.4;
constexpr double WHP_SW = 0.4;
constexpr double EHP_SW = 0.1;
constexpr double PATH_SW = 0.5;
constexpr double ERRC_SW = 0.3;

// ポリゴン座標変換
OutVertexList transform(OutVertexList polygon) {
	for (auto& point : polygon) {
		point.y = -point.y;
	}
	return polygon;
}

// ポリゴンリスト座標変換
std::vector<OutVertexList> transform(std::vector<OutVertexList> polygons) {
	for (auto& polygon : polygons) {
		polygon = transform(polygon);
	}
	return polygons;
}

//　出力パスデータ座標変換
OutPathData transform(OutPathData pathList) {
    for_each(pathList.begin(), pathList.end(), [](OutPathData::value_type& data) {
        GeoPoint& stPoint = data.enterPoint();
        GeoPoint& edPoint = data.leavePoint();
        stPoint.y = -stPoint.y;
        edPoint.y = -edPoint.y;
    });
    return pathList;
}

// 点の座標変換
XY_Point transform(XY_Point point) {
	point.y = -point.y;
	return point;
}

// 点列の座標変換
vector<XY_Point> transform(vector<XY_Point> points) {
	for_each(points.begin(), points.end(), [](XY_Point& point) {
		point = transform(point);
	});
	return points;
}

// サークル列座標変換
vector<Circle> transform(vector<Circle> circles) {
	for_each(circles.begin(), circles.end(), [](Circle& circle) {
		circle.center.y = -circle.center.y;
	});
	return circles;
}

} // anonymous namespace

/**
 名称と値の設定
 */
	
template<typename T>
void SvgDataStream::Property::setNameValue(const string& name, const T& value) {
	ss.setf(oStream.flags());
	ss << setprecision((int)oStream.precision());
	
	ss << name << "=\"" << value << "\"";
};

template<>
void SvgDataStream::Property::setNameValue<string>(const string& name, const string& value) {
	if (name.empty() || value.empty()) {
		return;
	}
	ss.setf(oStream.flags());
	ss << setprecision((int)oStream.precision());
	
	ss << name << "=\"" << value << "\"";
}


/**
 プロパティ生成
 */
template<>
string SvgDataStream::makeProperty(const string& name, const string& value) const {
	if (name.empty() || value.empty()) {
		return string{""};
	}
	return Property{*this, name, value}.str();
}

/**
 ViewBoxプロパティ生成
 */
string SvgDataStream::makeProperty(const Svg::ViewBox& vb) const {
    LOGV(LOG_TAG "::makeProperty", "(ViewBox)");
    const SvgDataStream& os = *this;
    
    stringstream ss;
    ss.setf(os.flags());
    ss << vb.x << ", " << vb.y << ", " << vb.width << ", " << vb.height <<EOL;
    return makeProperty(" viewBox", ss.str());
}

/**
 polygonエレメント生成
 
 polygonをSVGのpolygonエレメントにフォーマットして返す
 
 @param[in] polygons フォーマットするポリゴン
 @param[in] id ID
 @param[in] color 色
 @param[in] strokeWidth 線幅
 */
string SvgDataStream::makePolygon(const OutVertexList& polygons, const string& id, const string& color, double strokeWidth) const {
	LOGV(LOG_TAG "::setPlygon", "(Polygon)");
	const SvgDataStream& os = *this;
	
	stringstream ss;
	ss.setf(os.flags());
	ss << setprecision((int)os.precision());
	ss << "<polygon " << makeProperty("id", id) << EOL
		<< makeProperty(" stroke", color) << makeProperty(" stroke-width", strokeWidth) << EOL
		<< " points=\"" << EOL;
	for (const auto& point : polygons) {
		ss << "\t" << point.x << "," << point.y << EOL;
	}
	ss << "\"/>" << EOL;
	
	return ss.str();
}

/**
 polygonエレメント生成
 
 polygonをSVGのpolygonエレメントにフォーマットして返す
 
 @param[in] polygons フォーマットするポリゴン
 @param[in] id ID
 @param[in] color 色
 @return svg文字列
 */
string SvgDataStream::makePolygon(const OutVertexList& polygons, const string& id, const string& color) const {
    LOGV(LOG_TAG "::setPlygon", "(Polygon)");
    const SvgDataStream& os = *this;
    
    stringstream ss;
    ss.setf(os.flags());
    ss << setprecision((int)os.precision());
    ss << "<polygon " << makeProperty("id", id) << EOL
        << makeProperty(" stroke", color) << EOL
        << " points=\"" << EOL;
    for (const auto& point : polygons) {
        ss << "\t" << point.x << "," << point.y << EOL;
    }
    ss << "\"/>" << EOL;
    
    return ss.str();
}

/**
 polygonエレメント生成
 
 polygonをSVGのpolygonエレメントにフォーマットして返す
 
 @param[in] polygons フォーマットするポリゴン
 @param[in] id ID
 @param[in] color 色
 @return svg文字列
 */
string SvgDataStream::makePolygon(const vector<XY_Point>& polygon, const string& id, const string& color) const {
    LOGV(LOG_TAG "::setPlygon", "(Polygon)");
    const SvgDataStream& os = *this;
    
    stringstream ss;
    ss.setf(os.flags());
    ss << setprecision((int)os.precision());
    ss << "<polygon " << makeProperty("id", id) << EOL
       << makeProperty(" stroke", color) << EOL
       << " points=\"" << EOL;
    for (const auto& point : polygon) {
        ss << "\t" << point.x << "," << point.y << EOL;
    }
    ss << "\"/>" << EOL;
    
    return ss.str();
}

/**
 マーカー生成
 
 マーカー用SVG文字列を作成して返す

 @param[in] text マーカーテキスト
 @param[in] point 表示位置
 @param[in] radius マーカー半径
 @param[in] textColor テキスト色
 @param[in] bkColor 背景色
 @return svg文字列
 */
string SvgDataStream::makeMarker(const string& text, const PathPlan::GeoPoint& point, double radius, const string& textColor, const string& bkColor, const string& opacity) const {
	const SvgDataStream& os = *this;
	stringstream ss;
	ss.setf(os.flags());
	ss << setprecision((int)os.precision());

	ss	<< "<circle"
		<< makeProperty(" cx", point.x)
		<< makeProperty(" cy", point.y)
		<< makeProperty(" r", radius)
		<< makeProperty(" fill", bkColor)
		<< makeProperty(" stroke", "none")
        << makeProperty(" opacity", opacity)
		<< "/>" << EOL;
	
	ss	<< "<text"
		<< makeProperty(" x", point.x)
		<< makeProperty(" y", point.y)
		<< makeProperty(" fill", textColor)
		<< makeProperty(" stroke", "none")
        << makeProperty(" opacity", opacity)
		<< makeProperty(" font-size", radius * 2)
		<< makeProperty(" dominant-baseline", "central")
		<< makeProperty(" text-anchor", "middle")
		<< ">" << text << "</text>" << EOL;
	
	return ss.str();
}

/**
 マーカー生成
 
 マーカー用SVG文字列を作成して返す

 @param[in] text マーカーテキスト
 @param[in] point 表示位置
 @param[in] radius マーカー半径
 @param[in] textColor テキスト色
 @param[in] bkColor 背景色
 @return svg文字列
 */
string SvgDataStream::makeColor(const string& text, const string& textColor, const string& textOpacity) const {
    const SvgDataStream& os = *this;
    stringstream ss;
    ss.setf(os.flags());
    ss << setprecision((int)2);

    ss  << makeProperty(text, textColor) << "" << makeProperty(" opacity", textOpacity);
    
    return ss.str();
}



/**
 自動運転開始・終了点入力
 
 自動運転開始・終了点をフォーマットする。
 
 @param[in] stPoint 自動運転開始点座標
 @param[in] edPoint 自動運転終了点座標
 */
void SvgDataStream::setStartEndPoint(const GeoPoint& stPoint, const GeoPoint& edPoint) {
	LOGV(LOG_TAG "::setStartEndPoint", "(SvgDataStream)");
	SvgDataStream& os = *this;

	os << makeMarker("S", transform(stPoint), 1.1, "white", "red");
	os << makeMarker("E", transform(edPoint), 0.9, "#FFF", "#000", "0.7");
}

/**
 矢印用マーカー出力
 */
void SvgDataStream::setDoubleEndedArrowMarkes() {
    LOGV(LOG_TAG "::makeDoubleEndedArrowMarkes", "(SvgDataStream)");

    SvgDataStream& os = *this;
    os << "<defs>" << EOL
        << "<marker"
        << makeProperty(" id", "deArrowStartMarker")
        << makeProperty(" markerUnits", "userSpaceOnUse")
        << makeProperty(" orient", "auto")
        << makeProperty(" refX", "0.0")
        << makeProperty(" refY", "1.0")
        << makeProperty(" markerWidth", "2.0")
        << makeProperty(" markerHeight", "2.0")
        << ">" << EOL;
    os << "<polygon"
        << R"( stroke="none")" << EOL
        << makeProperty(" points", "2.0,0.0  0.0,1.0  2.0,2.0") << "/>" << EOL
        << "</marker>" << EOL;
    os << "<marker"
        << makeProperty(" id", "arrowEndMarker")
        << makeProperty(" markerUnits", "userSpaceOnUse")
        << makeProperty(" orient", "auto")
        << makeProperty(" refX", "1.9")
        << makeProperty(" refY", "1.0")
        << makeProperty(" markerWidth", "2.0")
        << makeProperty(" markerHeight", "2.0")
        << ">" << EOL;
    os << "<polygon"
        << R"( stroke="none")" << EOL
        << makeProperty(" points", "0.0,0.0 2.0,1.0 0.0,2.0") << "/>" << EOL
        << "</marker>" << EOL;
    os << "</defs>";
}

/**
 パス始点終点マーカー出力
 */
void SvgDataStream::setPathEndMarkes() {
    LOGV(LOG_TAG "::makeDoubleEndedArrowMarkes", "(SvgDataStream)");

    SvgDataStream& os = *this;
    os << "<defs>" << EOL
        << "<marker"
        << makeProperty(" id", "PathStartMarker")
        << makeProperty(" markerUnits", "userSpaceOnUse")
        << makeProperty(" orient", "auto")
        << makeProperty(" refX", "1.0")
        << makeProperty(" refY", "1.0")
        << makeProperty(" markerWidth", "2.0")
        << makeProperty(" markerHeight", "2.0")
        << ">" << EOL;
    os << "<polygon"
        << R"( stroke="none" fill="red")" << EOL
        << makeProperty(" points", "0.0,2.0  2.0,1.0  0.0,0.0") << "/>" << EOL
        << "</marker>" << EOL;
    os << "<marker"
        << makeProperty(" id", "PathEndMarker")
        << makeProperty(" markerUnits", "userSpaceOnUse")
        << makeProperty(" orient", "auto")
        << makeProperty(" refX", "1.0")
        << makeProperty(" refY", "1.0")
        << makeProperty(" markerWidth", "2.0")
        << makeProperty(" markerHeight", "2.0")
        << ">" << EOL;
    os << "<polygon"
        << R"( stroke="none" fill="black")" << EOL
        << makeProperty(" points", "0.0,2.0  2.0,1.0  0.0,0.0") << "/>" << EOL
        << "</marker>" << EOL;
    os << "</defs>";
}

/**
 両端矢印生成
 */
string SvgDataStream::makeDoubleEndedArrow(const std::string& id, const GeoPoint& stPoint, const GeoPoint& edPoint, double width, const std::string& color, const std::string& opacity) {
    LOGV(LOG_TAG "::makeDoubleEndedArrowMarkes", "(SvgDataStream)");
    const SvgDataStream& os = *this;
    stringstream ss;
    ss.setf(os.flags());
    
    ss << "<g" << EOL
        << makeProperty(" id", id)
        << makeProperty(" stroke-width", width)
        << makeProperty(" stroke", color)
        << makeProperty(" fill", color)
        << makeProperty(" opacity", opacity)
        << ">" << EOL;
    ss << "<path"
        << makeProperty(" stroke-dasharray", "0 0.75 0.75 0")
        << makeProperty(" style", "marker-start: url(#deArrowStartMarker); marker-end: url(#arrowEndMarker)") << EOL
        << " d=\"" << EOL
        << "\tM " << stPoint.x << "," << stPoint.y << EOL
        << "\tL " << edPoint.x << "," << edPoint.y << EOL
        << R"("/>)" << EOL;
    ss << "</g>";
    
    return ss.str();
}

/**
 作業方向線分入力
 @param[in] dp1 始点
 @param[in] dp2 終点
 */
void SvgDataStream::setPathDirectionPoints(GeoPoint dp1, GeoPoint dp2) {
    SvgDataStream& os = *this;
    setDoubleEndedArrowMarkes();
    
    LineSegment seg{dp1, dp2};
    double length = seg.length();
    if (length < 10.0) {
        seg.extendBoth((10.0 - length) / 2.0);
    }

    os << makeDoubleEndedArrow("", transform(seg.enterPoint()), transform(seg.leavePoint()), 0.2, "black", "1.0") << EOL;
}

/**
 ViewBox設定
 
 頂点リストから ViewBox を算出して設定する。
 
 @param[in] polygon ポリゴン
 */
void SvgDataStream::setViewBox(const OutVertexList& polygon) {
	GeoPoint min{viewBox.x, viewBox.y};
	GeoPoint max{min + GeoPoint{viewBox.width, viewBox.height}};
	for (const auto& point : polygon) {
		const auto svgPoint = transform(point);
		min.x = std::min(min.x, svgPoint.x);
		min.y = std::min(min.y, svgPoint.y);
		max.x = std::max(max.x, svgPoint.x);
		max.y = std::max(max.y, svgPoint.y);
	}
    
    min -= {1.0, 1.0};
    max += {1.0, 1.0};
	viewBox = Svg::ViewBox{min, max};
}
	
/**
 原型外形ポリゴン入力
 
 入力パラメータで与えられた計算前の BP ポリゴン列を入力する
 
 @param[in] bps BPポリゴンリスト
 */
void SvgDataStream::setFieldOrg(const OutVertexList& bps) {
	if (!bps.empty()) {
		SvgDataStream& os = *this;
		stringstream ss;
		ss.setf(os.flags());
		ss << setprecision((int)os.precision());
		OutVertexList polygon = transform(bps);
		
		os	<< R"(<g )"
		<< makeProperty(" id", "INPUT_BP")
		<< makeProperty(" stroke", "blue")
		<< makeProperty(" fill", "none")
        << makeProperty(" stroke-width", BP_SW / 2)
		<< ">" << EOL;
		int count = 0;
		os << makePolygon(polygon, "BP" + to_string(count), "", BP_SW / 2);
		os << R"(</g>)" << EOL;
	}
}

/**
 外形ポリゴン入力
 
 BP ポリゴン列を入力する
 
 @warning viewBoxプロパティ出力も行うため、現在のところこれを最初に入力する必要がある
 
 @param[in] bps BPポリゴンリスト
 */
void SvgDataStream::setField(const std::vector<OutVertexList>& bps) {
	LOGV(LOG_TAG "::setField", "(Field)");
	SvgDataStream& os = *this;
	stringstream ss;
	ss.setf(os.flags());
	ss << setprecision((int)os.precision());

	std::vector<OutVertexList> polygons = transform(bps);
	
	ss.setf(os.flags());
	ss	<< R"(<?xml version="1.0" standalone="no"?>)" << EOL;
	ss	<< R"(<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">)" << EOL;
	ss	<< "<svg"
		<< makeProperty(" xmlns", "http://www.w3.org/2000/svg") << EOL
		<< R"(	viewBox=")" << viewBox.x << " " << viewBox.y << " " << viewBox.width << " " << viewBox.height << R"(")" << EOL
		<< makeProperty("	width", "100%") << makeProperty(" height", "100%") << EOL
		<< makeProperty("	preserveAspectRatio", "xMidYMid meet") << ">" << EOL;
	header = ss.str();
	if (!polygons.empty()) {
		os	<< R"(<g )"
			<< makeProperty(" id", "INTERNAL_BP")
			<< makeProperty(" stroke", "red")
			<< makeProperty(" fill", "none")
            << makeProperty(" stroke-width", BP_SW)
			<< ">" << EOL;
		int count = 0;
		for (const auto& polygon : polygons) {
			os << makePolygon(polygon, "BP" + to_string(count), "");
			count++;
		}
		os << R"(</g>)" << EOL;
	}
}

/**
 HPポリゴン入力

 HP のPolygonsを入力する
	
 @param[in] hps HPポリゴンリスト
 */
void SvgDataStream::setHp(const std::vector<OutVertexList>& hps) {
	LOGV(LOG_TAG "::setHp", "(Field)");
	SvgDataStream& os = *this;
	vector<OutVertexList> polygons = transform(hps);

	os	<< R"(<g )"
		<< makeProperty(" id", "HP")
		<< makeProperty(" stroke", "#0ff")
		<< makeProperty(" fill", "none")
        << makeProperty(" stroke-width", HP_SW)
		<< ">" << EOL;
	int hpCount = 0;
	for (const auto& polygon : polygons) {
		os << makePolygon(polygon, "HP" + to_string(hpCount), "");
		hpCount++;
	}
	os << R"(</g>)" << EOL;
}

/**
 SHPポリゴン入力

 SHP のPolygonsを入力する

 @param[in] shps SHPポリゴンリスト
*/
void SvgDataStream::setShp(const std::vector<OutVertexList>& shps) {
	LOGV(LOG_TAG "::setShp", "(Field)");
	SvgDataStream& os = *this;

	vector<OutVertexList> polygons = transform(shps);
	os	<< R"(<g )"
		<< makeProperty(" id", "SHP")
		<< makeProperty(" stroke", "#0f0")
		<< makeProperty(" fill", "none")
        << makeProperty(" stroke-width", SHP_SW)
		<< ">" << EOL;
	int shpCount = 0;
	for (const auto& polygon : polygons) {
		os << makePolygon(polygon, "SHP" + to_string(shpCount), "");
		shpCount++;
	}
	os << R"(</g>)" << EOL;
}

/**
 ポリゴン入力
 
 @param[in] rhp RHPポリゴン
 */
void SvgDataStream::setRhp(const std::vector<XY_Point>& rhp) {
    LOGV(LOG_TAG "::setRhp", "(RHP)");
    SvgDataStream& os = *this;
    
    auto polygon = transform(rhp);
    os  << R"(<g )"
        << makeProperty(" id", "RHP")
        << makeProperty(" stroke", "#08f")
        << makeProperty(" fill", "none")
        << makeProperty(" stroke-width", RHP_SW)
        << ">" << EOL;
    os << makePolygon(polygon, "RHP", "");
    os << R"(</g>)" << EOL;
}

/**
 ポリゴン入力
 
 @param[in] whp WHPポリゴン
 */
void SvgDataStream::setWhp(const std::vector<XY_Point>& whp) {
    LOGV(LOG_TAG "::setWhp", "(WHP)");
    SvgDataStream& os = *this;
    
    auto polygon = transform(whp);
    os  << R"(<g )"
        << makeProperty(" id", "WHP")
        << makeProperty(" stroke", "#90f")
        << makeProperty(" fill", "none")
        << makeProperty(" stroke-width", WHP_SW)
        << ">" << EOL;
    os << makePolygon(polygon, "WHP", "");
    os << R"(</g>)" << EOL;
}

/**
 ポリゴン入力
 
 @param[in] ehp EHPポリゴン
 */
void SvgDataStream::setEhp(const std::vector<XY_Point>& ehp) {
    LOGV(LOG_TAG "::setEhp", "(EHP)");
    SvgDataStream& os = *this;
    
    auto polygon = transform(ehp);
    os  << R"(<g )"
        << makeProperty(" id", "EHP")
        << makeProperty(" stroke", "#06f")
        << makeProperty(" fill", "none")
        << makeProperty(" stroke-width", EHP_SW)
        << ">" << EOL;
    os << makePolygon(polygon, "EHP", "");
    os << R"(</g>)" << EOL;
}

/**
 パスデータ入力
 
 パスプラン結果のパスデータをフォーマットする。
 
 @param[in] aPathList 入力するパスデータ
 */
void SvgDataStream::setPathData(const OutPathData& aPathList) {
	LOGV(LOG_TAG "::setPathData", "(OutPathData)");
	OutputDataStream& os = *this;
    OutPathData pathList;   // 内部使用パスデータ
    // 無効なパス削除
    for(const auto& seg : aPathList) {
        if (seg.enterPoint() != seg.leavePoint()) {
            pathList.push_back(seg);
        }
    }
	pathList = transform(pathList);    // 座標変換
    OutPathData overwriteSegs;

    os << "<g" << makeProperty(" id", "PATHDATA")
        << makeProperty(" stroke-width", PATH_SW)
        << ">" << EOL;

	int pathcount = 0;

    bool tractorOnStart = true;
    bool opened = false;
	int prevType = PathParam::Segment::RideType::UNDEFINED;
	for (const auto& geoData : pathList) {
        const GeoPoint& stPoint = geoData.enterPoint();
        const GeoPoint& edPoint = geoData.leavePoint();
        const int currType = geoData.pathAttr.getExtType();

        if (opened) {
            if (prevType != currType) {
                // close element
                os << "\"/>" << EOL;
                opened = false;
            }
        }
        
        if (!opened) {
            prevType = currType;
            os << "<path"
                << " id" << "=\"SEGMENT" << pathcount << "\""
                << makeProperty(" fill", "none");
			pathcount += 1;

            switch (currType) {
            case PathParam::Segment::RideType::WORKING:
                os << makeProperty(" stroke", "#900");
                break;
            case PathParam::Segment::RideType::NON_WORKING:
                os << makeProperty(" stroke", "#999");
                break;
            case PathParam::Segment::RideType::DUMMY:
                os << makeProperty(" stroke", "#990") <<  makeProperty(" stroke-dasharray", "2 2");
                overwriteSegs.push_back(geoData);
                break;
            case PathParam::Segment::RideType::ORBITAL_WORKING:
                os << makeColor(" stroke", "#900", "0.5") << makeProperty(" stroke-width", "0.3");
                break;
            case PathParam::Segment::RideType::ORBITAL_NON_WORKING:
                os << makeColor(" stroke", "#999", "0.5") << makeProperty(" stroke-width", "0.5");
                break;
            case PathParam::Segment::RideType::BLOCK_DIVIDER:
                os << makeProperty(" stroke", "#f6f");
                break;
            default:
                if ((currType & PathParam::Segment::RideType::COUNTER_ORBITAL) == PathParam::Segment::RideType::COUNTER_ORBITAL) {
                    os << makeColor(" stroke", "#999", "0.5") << makeProperty(" stroke-width", "0.5");
                } else {
                    os << makeProperty(" stroke", "#990");
                }
                break;
            }

            if (tractorOnStart) {
                os << makeProperty(" style", "marker-start: url(#tractor0); url(#PathStartMarker)");
                tractorOnStart = false;
            }

			os << EOL;
			os << " d=\"" << EOL;
			os << "M\t" << stPoint.x << "," << stPoint.y << EOL;
			os << "L";
            opened = true;
		}
		
		switch (currType) {
            case PathParam::Segment::RideType::WORKING:
				os << "\t" << edPoint.x << "," << edPoint.y << EOL;
				break;
            case PathParam::Segment::RideType::NON_WORKING:
            case PathParam::Segment::RideType::DUMMY:
            case PathParam::Segment::RideType::UNDEFINED:
            default:
				os << "\t" << edPoint.x << "," << edPoint.y << EOL;
				break;
		}
	}
    if (opened) {   // 念のため。
        os << "\"/>" << EOL;
        opened = false;
    }
     os << R"(</g>)" << EOL;

    // 表示用に上書きするセグメント
    // - ダミーライド等
    {
        os  << "<g" << makeProperty(" id", "OVERWRITE_SEGMENT")
            << makeProperty(" stroke-width", PATH_SW)
            << " >" << EOL;
        if (!overwriteSegs.empty()) {
            os  << "<path"
                << makeProperty(" id", "DUMMYRIDE")
                << makeProperty(" fill", "none")
                << makeProperty(" stroke", "#ffc")
                << makeProperty(" stroke-dasharray", "0 2 2 0") << EOL
                << " d=\"" << EOL;
                opened = true;
            for (const auto& seg : overwriteSegs) {
                const GeoPoint& stPoint = seg.enterPoint();
                const GeoPoint& edPoint = seg.leavePoint();
                os  << "M\t" << stPoint.x << ", " << stPoint.y << EOL
                    << "L\t" << edPoint.x << ", " << edPoint.y << EOL;
            }
            if (opened) {   // 念のため。
                os << "\"/>" << EOL;
                opened = false;
            }
        }
        os << R"(</g>)" << EOL;
    }
    
    /*start - end point*/
    if (2 < pathList.size()) {
        const GeoPoint& stPoint = pathList.front().enterPoint();
        const GeoPoint& edPoint = pathList.back().leavePoint();
        setStartEndPoint(transform(stPoint), transform(edPoint));
//        setPathEndMarkes();
    }
}

/**
 エラーパスデータ入力
 
 エラーパスデータをフォーマットする。
 
 @param[in] aPathList 入力するパスデータ
 */
void SvgDataStream::setErrorPathData(const OutPathData& aPathList) {
	LOGV(LOG_TAG "::setPathData", "(OutPathData)");
	OutputDataStream& os = *this;
	auto pathList = transform(aPathList);	// 座標変換
	
	os << "<g" << makeProperty(" id", "ERRORPATHDATA") << ">" << EOL;
	
	int pathcount = 0;
	
	for (auto geoData : pathList) {
		const GeoPoint& stPoint = geoData.enterPoint();;
		const GeoPoint& edPoint = geoData.leavePoint();;
		
		os << "<path"
			<< " id" << "=\"SEGMENT" << pathcount << "\""
			<< makeProperty(" fill", "none");
		pathcount += 1;
		
		switch (geoData.segmentType) {
            case PathParam::Turn::Type::STRAIGHT:   //  FPS/SPS を期待している
                os << makeProperty(" stroke", "blue")
                   << makeProperty(" stroke-width", "1.0");
                break;
            default:
				os << makeProperty(" stroke", "orange")
				   << makeProperty(" stroke-width", "0.5");
				break;
		}
		os << EOL;

		os << " d=\"" << EOL;
		os << "M\t" << stPoint.x << "," << stPoint.y << EOL;
		os << "L\t" << edPoint.x << "," << edPoint.y << EOL;
		os << "\"/>" << EOL;
	}

	os << R"(</g>)" << EOL;
}

/**
 エラー点入力
 
 エラー点列データをフォーマットする。
 
 @param[in] points 入力する点列
 */
void SvgDataStream::setErrorPoints(const vector<XY_Point>& points) {
	LOGV(LOG_TAG "::setErrorMarker", "(poins)");
	const double radius = 1;
	SvgDataStream& os = *this;
	auto pointList = transform(points);	// 座標変換

	os	<< R"(<g )"
		<< makeProperty(" id", "ERRORPOINTS")
		<< ">" << EOL;

	int count = 0;
	for (const auto& point : pointList) {
		os	<< "<circle"
			<< " id" << "=\"POINT" << count << "\""
			<< makeProperty(" cx", point.x)
			<< makeProperty(" cy", point.y)
			<< makeProperty(" r", radius)
			<< makeProperty(" fill", "magenta")
			<< makeProperty(" stroke", "none")
			<< makeProperty(" stroke-width", "1")
			<< "/>" << EOL;

		count += 1;
	}
	
	os << R"(</g>)" << EOL;
}

/**
 エラー円入力
 
 エラー円列データをフォーマットする。
 
 @param[in] circles 入力する円列
 */
void SvgDataStream::setErrorCircles(const vector<Circle>& circles) {
	LOGV(LOG_TAG "::setErrorCircles", "(circles)");
	SvgDataStream& os = *this;
	auto circleList = transform(circles);	// 座標変換

	os	<< R"(<g )"
		<< makeProperty(" id", "ERRORCIRCLES")
        << makeProperty(" stroke-width", ERRC_SW)
		<< ">" << EOL;

	int count = 0;
	for (const Circle& c : circleList) {
		os	<< "<circle"
		<< " id" << "=\"CIRCLE" << count << "\""
		<< makeProperty(" cx", c.center.x)
		<< makeProperty(" cy", c.center.y)
		<< makeProperty(" r", c.radius)
		<< makeProperty(" stroke", "orange")
		<< makeProperty(" fill", "none")
		<< "/>" << EOL;
	}
	
	os << R"(</g>)" << EOL;
}

// トラクター形状入力
void SvgDataStream::setSilhouette(const XY_Point& pos, const Gauge& gauge) {
    auto vb = getSvgViewBox<TRACTOR_ENTIRE>(gauge);
    SvgDataStream& os = *this;
    os  << "<defs>" << EOL
        << "<marker"
            << makeProperty(" id", "tractor0")
            << makeProperty(" markerUnits", "userSpaceOnUse")
            << makeProperty(" orient", "auto")
            << makeProperty(" refX", vb.x)
            << makeProperty(" refY", vb.y)
            << makeProperty(" markerWidth", vb.width)
            << makeProperty(" markerHeight", vb.height)
//            << makeProperty(" preserveAspectRatio", "xMinYMin slice")
        << ">" << EOL
            << "<path" << makeProperty(" class", "tractor0")
            << makeColor(" fill", "#f00", "0.5")
            << makeProperty(" stroke", "black")
            << makeProperty(" stroke-width", "0.1")
            << " d=\"" << EOL
            << "M\t" << vb.x << ", " << vb.y << EOL
            << getSvgPathSilhouette<TRACTOR_ENTIRE>(gauge) << EOL
            << "\"/>" << EOL
        << "</marker>" << EOL
        << "</defs>" << EOL;
}

// パス外形入力
void SvgDataStream::setPathExtent() {
    SvgDataStream& os = *this;
    
    os  << "<g"
        << makeProperty(" class", "PATHEXTENT")
        << makeProperty(" fill", "none")
        << makeProperty(" stroke", "black")
        << makeProperty(" stroke-width", "0.1")
        << ">" << EOL
        << "</g>" << EOL;
}

/**
 パスデータSVGダンプ
 
 圃場境界ポリゴンとパスをSVGでダンプする
    - 出力ファイルがオープンできなければ何もしない。

 @param[in] filename 出力パスファイル名
 @param[in] extents 外形ポリゴンリスト
 @param[in] hps HPポリゴンリスト
 @param[in] shps SHPポリゴンリスト
 @param[in] path パスデータ
 @param[in] error エラー情報
 */
void dumpInfoToSVG(const string& filename, const std::vector<OutVertexList>& extents, const std::vector<OutVertexList>& hps,
                   const std::vector<OutVertexList>& shps, const ErrorPathGenerator& error, const vector<XY_Point>& rhp, const vector<XY_Point>& whp, const vector<XY_Point>& ehp) {
    const auto& field = error.inData.field;
    
    ofstream svgFile(filename, ios::trunc);
    if (!svgFile) {
        return;
    }

	SvgDataStream osSvg;
	osSvg.setViewBox(field.outline);
	if (!extents.empty()) {
		osSvg.setViewBox(extents[0]);
	}
	osSvg.setFieldOrg(field.outline);
	osSvg.setField(extents);
	osSvg.setShp(shps);
	osSvg.setHp(hps);
    osSvg.setRhp(rhp);
    osSvg.setWhp(whp);
    osSvg.setEhp(ehp);
	osSvg.setStartEndPoint(field.start, field.end);
    osSvg.setStartEndPoint(error.srcPoint, error.destPoint);
    if (field.directionPoints[0] != field.directionPoints[1]) {
        osSvg.setPathDirectionPoints(field.directionPoints[0], field.directionPoints[1]);
    }
	auto pathList = Display::makePathForDisplay(error.outputPath);
	osSvg << pathList;
	osSvg.setErrorPoints(error.points);
	osSvg.setErrorCircles(error.circles);
	auto errPathList = Display::makePathForDisplay(error.path);
	osSvg.setErrorPathData(errPathList);
    XY_Point pos;
    if (!pathList.empty()) {
        pos = pathList.front().enterPoint();
    } else if (!errPathList.empty()) {
        pos = errPathList.front().enterPoint();
    } else if (!hps.empty() && !hps[0].empty()) {
        pos = hps[0].front();
    }
    osSvg.setSilhouette(transform(pos), error.gauge);
    osSvg.setPathExtent(); // dummy, just placeholder

    osSvg << "<!--" << EOL;
	osSvg << error.inDataRaw << EOL;
    osSvg << error.gauge << EOL;
    osSvg << error.hwParam << EOL;
	osSvg << "-->" << EOL;

	svgFile << osSvg.str() << endl;
	svgFile.close();
}
}} // yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 * パスプランデータのSVGフォーマット出力用クラス
 */
#pragma once

#include "OutputDataStream.hpp"
#include "PathLib/PathGeneratorError.hpp"
namespace yanmar { namespace PathPlan {

namespace Svg {
    // ViewBox構造体
    struct ViewBox {
        ViewBox() = default;
        ViewBox(double aX, double aY, double aWidth, double aHeight) :
            x(aX),
            y(aY),
            width(aWidth),
            height(aHeight)
        {}
        ViewBox(const GeoPoint& min, const GeoPoint& max) :
            x(min.x),
            y(min.y),
            width(max.x - min.x),
            height(max.y - min.y)
        {}

        double x = 0.0;
        double y = 0.0;
        double width = 0.0;
        double height = 0.0;
    };
} // namespace Svg

/**
 * SVGデータフォーマット用文字列ストリームクラス
 *
 * パスプランデータをSVGデータにフォーマットする文字列ストリームクラス。
 *	- 小数値は fixed 7桁精度出力。
 */
class SvgDataStream : public OutputDataStream {
	typedef OutputDataStream super;
	friend class SvgDataStreamProxy;

public:
	SvgDataStream() : OutputDataStream() {
		*this << std::fixed << std::setprecision(7);
	}
	
	/*Function for writing the Header information*/
	void HeaderData(const class Display& displayData);

	// ViewBox算出
	void setViewBox(const OutVertexList& polygon);
	
	// 圃場外形入力
	void setField(const std::vector<OutVertexList>& bps);

	// 原圃場外形入力
	void setFieldOrg(const OutVertexList& bps);

	// 外形以外のポリゴンデータ入力
	void setHp(const std::vector<OutVertexList>& hps);

	// 外形以外のポリゴンデータ入力

    // SHP(安全HP)
	void setShp(const std::vector<OutVertexList>& shps);
    // 平行作業包絡HP
    void setRhp(const std::vector<XY_Point>& rhp);
    // 外周作業用HP
    void setWhp(const std::vector<XY_Point>& whp);
    // 踏み荒らし判定用HP
    void setEhp(const std::vector<XY_Point>& ehp);

	// パスプラン結果入力
	void setPathData(const OutPathData& pathList);
	
	// エラーマーク入力
	void setErrorPoints(const vector<XY_Point>& points);
	// エラーサークル入力
	void setErrorCircles(const vector<Circle>& circles);
	// エラーパス入力
	void setErrorPathData(const OutPathData& errorPath);
    
    // トラクター形状入力
    void setSilhouette(const XY_Point& pos, const Gauge& gauge);
    // パス外径入力
    void setPathExtent();

    string str() {
		string str = header;
		return (str + super::str() + "</svg>\n");
	}
    
    struct Indent {
        std::vector<string> v;
        std::vector<string>::const_iterator currIt;
        std::vector<string>::const_iterator lastIt;
        std::string nullStr{""};

        Indent() = delete;
        Indent(std::vector<string> vec) :
            v(vec), currIt(v.cbegin())
        {
            if (currIt == v.cend()) {
                v.push_back(nullStr);
            }
        }
        
        const string& str() {
            if (currIt == v.cend()) {
                return v.back();
            }

            const auto& ref = *currIt;
            ++currIt;
            return ref;
        }
        
        void reset() {
            currIt = v.cbegin();
        }
    };
    
	// 開始終了点入力
	void setStartEndPoint(const GeoPoint& stPoint, const GeoPoint& edPoint);
    // 作業方向
    void setPathDirectionPoints(GeoPoint stPoint, GeoPoint edPoint);

    // 両端矢印
    string makeDoubleEndedArrow(const std::string& id, const GeoPoint& stPoint, const GeoPoint& edPoint, double width, const std::string& color, const std::string& opacity);
    // 両端矢印用鏃
    void setDoubleEndedArrowMarkes();
    // パス両端マーカー
    void setPathEndMarkes();
    
    /**
     property フォーマット
     
     SVGエレメントのプロパティ文字列を生成して返す。
     - つまり name="value" 文字列を返す。
     
     @param[in] name プロパティ名
     @param[in] value プロパティの値
     */
    template<typename T>
    string makeProperty(const string& name, const T& value) const {
        return Property{*this, name, value}.str();
    }
    
    template<typename T>
    string makeProperty(const string& name, const T& value, const string& unit) const {
        return Property{*this, name, value, unit}.str();
    }
    
    string makeProperty(const Svg::ViewBox& vb) const;
    
    struct Property {
        friend class SvgDataStreamProxy;
        const SvgDataStream& oStream;
        stringstream ss;
        
        template<typename T>
        Property(const SvgDataStream& os, const string& name, const T& value, const string& unit = "") :
            oStream(os)
        {
            setNameValue<T>(name, value);
        }
        
        template<typename T>
        void setNameValue(const string& name, const T& value);
        
        string str() const {
            return ss.str();
        }
    };

protected:
    virtual string formatPathData(const GeoPoint& point) {
        return DataConverter::splitFunc(point);
    }

private:

    string makePolygon(const OutVertexList& polygons, const string& id, const string& color, double strokeWidth) const;
    string makePolygon(const OutVertexList& polygons, const string& id, const string& color) const;
    string makePolygon(const vector<XY_Point>& polygon, const string& id, const string& color) const;
    string makeMarker(const string& text, const PathPlan::GeoPoint& point, double radius, const string& textColor, const string& bkColor, const string& textOpacity = "") const;
    string makeColor(const string& text, const string& textColor, const string& textOpacity = "") const;

	Svg::ViewBox viewBox;
	string header;
};

/// パスデータ入力オペレータ
inline SvgDataStream& operator<<(SvgDataStream& os, const OutPathData& pathList) {
	os.setPathData(pathList);
	return os;
}

void dumpInfoToSVG(const string& filename, const std::vector<OutVertexList>& extents, const std::vector<OutVertexList>& hps, const std::vector<OutVertexList>& shps, const ErrorPathGenerator& error, const vector<XY_Point>& rhp, const vector<XY_Point>& whp, const vector<XY_Point>& ehp);

}} // namespace yanmar::PathPlan

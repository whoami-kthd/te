// Yanmar Confidential 20200918

#include "FieldMatching.hpp"
#include "../Geometry/Coordinates.hpp"

namespace yanmar { namespace PathPlan {

/**
 * コンストラクタ
 */
FieldMatching::FieldMatching() {
    _angleEffect = 100;
    _prevPriority = 0.9;
    _evalLimit = 10000000000000000;
    _deepMatchAngleIn = M_PI / 12;
    _deepMatchAngleOut = M_PI / 6;
    _deepMatchAngleReturn = M_PI / 12;
    _omitIndex = -1;
    _prevIndex = -1;
    _deepMatch = false;
    _state = State::INIT;
}
FieldMatching::FieldMatching(double angleEffect, double prevPriority, double evalLimit) {
    _angleEffect = angleEffect;
    _prevPriority = prevPriority;
    _evalLimit = evalLimit;
    _deepMatchAngleIn = M_PI / 12;
    _deepMatchAngleOut = M_PI / 6;
    _deepMatchAngleReturn = M_PI / 12;
    _omitIndex = -1;
    _prevIndex = -1;
    _deepMatch = false;
    _state = State::INIT;
}
FieldMatching::FieldMatching(double angleEffect, double prevPriority, double deepMatchAngleIn, double deepMatchAngleOut, double deepMatchAngleReturn, double evalLimit) {
	_angleEffect = angleEffect;
	_prevPriority = prevPriority;
	_evalLimit = evalLimit;
	_deepMatchAngleIn = deepMatchAngleIn;
	_deepMatchAngleOut = deepMatchAngleOut;
	_deepMatchAngleReturn = deepMatchAngleReturn;
	_omitIndex = -1;
	_prevIndex = -1;
	_deepMatch = false;
	_state = State::INIT;
}

/**
 * デストラクタ
 */
FieldMatching::~FieldMatching() {
}

/**
 * 作業領域(pp圃場領域)を設定します。
 * @param[in] field 作業領域 (度単位)
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 状態不正
 */
int FieldMatching::setField(const GeoPolygon &field) {
    if (_state != State::INIT) {
        _state = State::ERROR;
        return ResultCode::ERROR_ILLEGAL_STATE;
    }
    _geoField.assign(field.begin(), field.end());
    // 緯度経度座標系からメートル単位平面座標系への座標変換
    _refPos = radiansGeoPoint(_geoField[0].lat, _geoField[0].lon);
    Cartesian converter;
    converter.setRefPos(_refPos);
    _field = Polygon_(new Polygon);
    for (auto itr = _geoField.begin(); itr != _geoField.end(); ++itr) {
        GeoPoint gp = radiansGeoPoint(itr->lat, itr->lon);
        _field->push_back(converter.convert(gp));
    }
    // 正常終了
    _state = State::READY;
    return ResultCode::SUCCESS;
}

/**
 * 作業領域(pp圃場領域)へのマッチングを実行します。
 * @param[in]  pos     トラクターの位置 (度単位)
 * @param[in]  azimuth トラクターの方位角 (北を0度、時計回りを正、ラジアン単位)
 * @param[out] segment マッチング結果 (度単位)
 * @param[out] index マッチング結果 のインデックス
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 状態不正
 */
int FieldMatching::match(const GeoPoint &pos, double azimuth, GeoSegment &segment, int *outIndex) {
    if (_state != State::READY) {
        _state = State::ERROR;
        return ResultCode::ERROR_ILLEGAL_STATE;
    }
    // 緯度経度座標系からメートル単位平面座標系への座標変換
    Cartesian converter;
    converter.setRefPos(_refPos);
    GeoPoint tractorGP = radiansGeoPoint(pos.lat, pos.lon);
    Point2D tractorPos = converter.convert(tractorGP);
    double tractorDir = PolygonUtil::normalizeRadian(M_PI_2 - azimuth);
    // 評価値が最小(最良)の辺を探索
    PolygonUtil::Segments_ segments = PolygonUtil::createSegments(_field);
    if (_prevIndex >= 0) {
        // 前回マッチング結果がある場合、先に評価しておく
        const PolygonUtil::Segment &s = segments->at(_prevIndex);
        double a;
        double e = evaluate(tractorPos, tractorDir, s, &a);
        if (_deepMatch && a > _deepMatchAngleOut) {
            // 30度を超えたら都落ち
            _omitIndex = _prevIndex;
            _prevIndex = -1;
            _deepMatch = false;
        }
    }
    double eval = _evalLimit;
    double angle = 0;
    int index = -1;
    for (int i = 0; i < segments->size(); ++i) {
        const PolygonUtil::Segment &s = segments->at(i);
        double a;
        double e = evaluate(tractorPos, tractorDir, s, &a);
        if (i == _omitIndex) {
            // マッチング角度が15度以下になるまでマッチング対象から除外 (15度以下になった場合、マッチング対象に復帰)
            if (a > _deepMatchAngleReturn) continue;
            _omitIndex = -1;
        }
        if (i == _prevIndex) {
            // 前回マッチング結果に対する優遇
            e *= _prevPriority;
        }
        if (e < eval) {
            eval = e;
            angle = a;
            index = i;
        }
    }
    if (index < 0) {
        _prevIndex = -1;
        _deepMatch = false;
        return ResultCode::WARNING_NO_MATCH;
    }
    if (index != _prevIndex) {
        // マッチング辺が切り替わった場合
        _deepMatch = false;
    }
    // _angleEffectが0のときはヒットテスト用途のためdeepMatchしない
    if (_angleEffect != 0 && angle <= _deepMatchAngleIn) {
        _deepMatch = true;
    }
    segment.first = _geoField[index];
    segment.second = _geoField[PolygonUtil::nextIndex(index, _geoField.size())];
    _prevIndex = index;
    if (outIndex) {
        *outIndex = index;
    }
    return ResultCode::SUCCESS;
}

/**
 * 作業領域(pp圃場領域)の1辺と、トラクターの位置および進行方向との関係を評価します。
 * @param[in] pos     トラクターの位置
 * @param[in] dir     トラクターの進行方向
 * @param[in] segment 作業領域(pp圃場領域)の1辺
 * @param[out] angle  マッチング角度
 * @return 評価値 (小さい方が良い評価)
 */
double FieldMatching::evaluate(const Point2D &pos, double dir, const PolygonUtil::Segment &segment, double *angle) {
    // トラクターの位置から作業領域(pp圃場領域)の1辺までの距離
    Point2D pp;
    double d = clampedPerpendicularLength(pos, segment, pp);
    // トラクターの進行方向と作業領域(pp圃場領域)の1辺との角度差
    double a = PolygonUtil::normalizeRadian(PolygonUtil::normalizeRadian(segment.angle()) - PolygonUtil::normalizeRadian(dir));
    *angle = M_PI_2 - fabs(fabs(a) - M_PI_2);
    // 評価値
    return d * d + _angleEffect * sin(*angle);
}

/**
 * 点pと線分sの距離を取得します。
 * 点から線分に下ろした垂線の足の座標が線分の範囲外の場合、近い方の端点までの距離を返します。
 * @param[in]  p  対象となる点
 * @param[in]  s  対象となる線分
 * @param[out] pp 垂線の足の座標、または近い方の端点
 * @return 点と線分の距離
 */
double FieldMatching::clampedPerpendicularLength(const Point2D &p, const PolygonUtil::Segment &s, Point2D &pp) {
    double a, b, c;
    PolygonUtil::lineFormula(s.p1, s.p2, &a, &b, &c);
    // 垂線の足の座標をppとする
    // 途中の値を再利用したいため PolygonUtil::perpendicularPoint(p, a, b, c) を使用しない
    double coef1 = a * p.x + b * p.y + c;
    double coef2 = a * a + b * b;
    double coef = coef1 / coef2;
    pp.x = p.x - coef * a;
    pp.y = p.y - coef * b;
    // 2点間の距離を以下の式で代用する
    double length = fabs(s.p2.x - s.p1.x) + fabs(s.p2.y - s.p1.y);
    double length1 = fabs(pp.x - s.p1.x) + fabs(pp.y - s.p1.y);
    double length2 = fabs(pp.x - s.p2.x) + fabs(pp.y - s.p2.y);
    // ppと線分の位置関係
    if (length1 <= length && length2 <= length) {
        // ppが線分の範囲内
        return fabs(coef1) / sqrt(coef2);
    }
    if (length1 < length2) {
        // ppはp1の外側
        pp.x = s.p1.x;
        pp.y = s.p1.y;
        return hypot(p.x - pp.x, p.y - pp.y);
    }
    // ppはp2の外側
    pp.x = s.p2.x;
    pp.y = s.p2.y;
    return hypot(p.x - pp.x, p.y - pp.y);
}

bool isClockwise(const std::vector<double> &angles) {
	double sum = 0;
	for (int i = 0; i < angles.size(); ++i) {
		int next = PolygonUtil::nextIndex(i, angles.size());
		double angle = PolygonUtil::normalizeRadian(angles[next] - angles[i]);
		sum += angle;
	}
	return (sum < 0.0);
}

void correctSamePoints(Polygon_ polygon) {
	Polygon_ tmp = Polygon_(new Polygon);
	for (int i = 0; i < polygon->size(); ++i) {
		const Point2D &p1 = polygon->at(i);
		const Point2D &p2 = polygon->at(PolygonUtil::nextIndex(i, polygon->size()));
		if (p2 == p1) continue; // 同じ点が連続した場合、前側の点を削除
		tmp->push_back(p1);
	}
	polygon->swap(*tmp);
}

/**
 * 作業領域とHPから枕地幅/サイドマージンを逆算します。
 * セグメント(field[0], field[1])に対応する枕地幅/サイドマージンがwidths[0]に設定されます。
 * HP側に対応するセグメントが見つからない場合、枕地幅/サイドマージンに負数(-1)が設定されます。
 * @param[in] field   作業領域 (度単位)
 * @param[in] hp      HP (度単位)
 * @param[out] widths fieldから生成したセグメント配列に対応する、枕地幅/サイドマージンの配列
 */
void FieldMatching::getHeadlandSideMarginWidths(const GeoPolygon &field, const GeoPolygon &hp, std::vector<double> &widths) {
	GeoPoint refPos = radiansGeoPoint(field[0].lat, field[0].lon);
	// 緯度経度座標系からメートル単位平面座標系への座標変換
	Cartesian converter;
	converter.setRefPos(refPos);
	// 作業領域
	Polygon_ outer = Polygon_(new Polygon);
	for (auto itr = field.begin(); itr != field.end(); ++itr) {
		GeoPoint gp = radiansGeoPoint(itr->lat, itr->lon);
		outer->push_back(converter.convert(gp));
	}
	// HP
	Polygon_ inner = Polygon_(new Polygon);
	for (auto itr = hp.begin(); itr != hp.end(); ++itr) {
		GeoPoint gp = radiansGeoPoint(itr->lat, itr->lon);
		inner->push_back(converter.convert(gp));
	}
	// 作業領域から辺が消失する場合、HP上に非常に近い位置の頂点が生成されることがある
	// 上記のような場合、ディスプレイデータCSVの出力精度だと緯度経度が同じになる可能性が高い
	// その結果、この関数に渡されるhpで、同じ点が連続することがあり得るため、重複を省く
	correctSamePoints(inner);
	// 作業領域とHPの回り順を時計回りに合わせる
	PolygonUtil::Segments_ segments1 = PolygonUtil::createSegments(outer);
	PolygonUtil::Segments_ segments2 = PolygonUtil::createSegments(inner);
	std::vector<double> angles1 = PolygonUtil::getAngles(segments1);
	std::vector<double> angles2 = PolygonUtil::getAngles(segments2);
	const bool clockwise1 = isClockwise(angles1);
	const bool clockwise2 = isClockwise(angles2);
	if (!clockwise1) {
		Polygon_ tmp = Polygon_(new Polygon);
		tmp->swap(*outer);
		outer->push_back(tmp->at(0));
		for (int i = 1; i < tmp->size(); ++i) {
			outer->push_back(tmp->at(tmp->size() - i));
		}
		segments1 = PolygonUtil::createSegments(outer);
		angles1 = PolygonUtil::getAngles(segments1);
	}
	if (!clockwise2) {
		Polygon_ tmp = Polygon_(new Polygon);
		tmp->swap(*inner);
		inner->push_back(tmp->at(0));
		for (int i = 1; i < tmp->size(); ++i) {
			inner->push_back(tmp->at(tmp->size() - i));
		}
		segments2 = PolygonUtil::createSegments(inner);
		angles2 = PolygonUtil::getAngles(segments2);
	}
	// 対応するセグメントの探索
	widths.clear();
	for (int i = 0; i < angles1.size(); ++i) {
		// 初期値(-1)の設定
		widths.push_back(-1);
		bool overlap = false;
		const double a1 = angles1[i];
		for (int j = 0; j < angles2.size(); ++j) {
			const double a2 = angles2[j];
			// 角度差
			const double da = PolygonUtil::normalizeRadian(a2 - a1);
			if (fabs(da) > TOLERANCE_ANGLE_2) continue;
			// 平行、かつ向きも同じ
			// 時計回りに合わせているため、segments1の進行方向を基準として右が内側
			const PolygonUtil::Segment &s1 = segments1->at(i);
			const PolygonUtil::Segment &s2 = segments2->at(j);
			const PolygonUtil::Segment s1121 = PolygonUtil::Segment(s1.p1, s2.p1);
			const PolygonUtil::Segment s1122 = PolygonUtil::Segment(s1.p1, s2.p2);
			const double da1121 = PolygonUtil::normalizeRadian(s1121.angle() - a1);
			const double da1122 = PolygonUtil::normalizeRadian(s1122.angle() - a1);
			if (da1121 > 0 || da1122 > 0) continue;
			// segments2が内側
			// overlapの判定
			bool overlap_ = (s1.contains_(PolygonUtil::perpendicularPoint(s2.p1, s1)) || s1.contains_(PolygonUtil::perpendicularPoint(s2.p2, s1)) || s2.contains_(PolygonUtil::perpendicularPoint(s1.p1, s2)) || s2.contains_(PolygonUtil::perpendicularPoint(s1.p2, s2)));
			if (overlap && !overlap_) {
				// オーバーラップありの辺が見つかっている場合、オーバーラップなしの辺は無視
				continue;
			}
			// 幅の近似計算
			double sum = 0.0;
			sum += PolygonUtil::perpendicularLength(s1.p1, s2);
			sum += PolygonUtil::perpendicularLength(s1.p2, s2);
			sum += PolygonUtil::perpendicularLength(s2.p1, s1);
			sum += PolygonUtil::perpendicularLength(s2.p2, s1);
			double d = sum * 0.25;
			if (!overlap && !overlap_) {
				// オーバーラップなし/なしの場合、広い方の幅を採用する (フェールセーフ)
				// widths[i]の初期値(-1)のため、初回は必ず以下の条件が成立する (d > 0は自明)
				if (d > widths[i]) {
					widths[i] = d;
				}
			} else if (!overlap && overlap_) {
				// オーバーラップなし/ありの場合(オーバーラップありの辺が見つかっていない状態で、オーバーラップありの辺が見つかった場合)
				// 無条件に更新 (幅の大小関係はチェックしない)
				overlap = overlap_;
				widths[i] = d;
			} else if (overlap && overlap_) {
				// オーバーラップあり/ありの場合、狭い方の幅を採用する
				// いきなりココに来る事はない(なし/ありを通ってからココに来る)ため、widths[i]が初期値(-1)のままでココに来る事はない
				if (d < widths[i]) {
					widths[i] = d;
				}
			}
		}
	}
	// 作業領域の回り順を逆転させた場合、widthsの結果も逆転させる
	if (!clockwise1) {
		std::vector<double> tmp;
		tmp.swap(widths);
		widths.push_back(tmp[0]);
		for (int i = 1; i < tmp.size(); ++i) {
			widths.push_back(tmp[tmp.size() - i]);
		}
	}
}

}} // namespace yanmar::PathPlan

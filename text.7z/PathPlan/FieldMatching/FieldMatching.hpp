// Yanmar Confidential 20200918
#ifndef FieldMatching_HPP
#define FieldMatching_HPP

#include "../PolyLib/PolygonUtil.hpp"

namespace yanmar { namespace PathPlan {

class FieldMatching {
public:

    /** 処理結果 (正常終了:0, 警告あり:正, 異常終了:負) */
    class ResultCode {
    public:
        static const int SUCCESS = 0;              ///< 正常終了
        static const int ERROR_ILLEGAL_STATE = -1; ///< 状態不正
        static const int WARNING_NO_MATCH = 1;     ///< マッチング結果なし
    };
    /** セグメント */
    typedef std::pair<GeoPoint, GeoPoint> GeoSegment;

public:

    /**
     * コンストラクタ
     * @param[in] angleEffect  角度差の影響度合 (DEFAULT=100, 0:角度差を無視して距離だけで評価)
     * @param[in] prevPriority 前回マッチング結果の優遇度合 (DEFAULT=0.9, 1:前回マッチング結果の優遇なし)
     * @param[in] deepMatchAngleIn     DeepMatchの閾値1 (DEFAULT=M_PI/12)
     * @param[in] deepMatchAngleOut    DeepMatchの閾値2 (DEFAULT=M_PI/6)
     * @param[in] deepMatchAngleReturn DeepMatchの閾値3 (DEFAULT=M_PI/12)
     * @param[in] evalLimit    評価値の最低ライン (評価値が最低ラインより悪い(大きい)辺にはマッチしない。どの辺にもマッチしない場合、WARNING_NO_MATCHを返す)
     */
    FieldMatching(double angleEffect, double prevPriority, double deepMatchAngleIn, double deepMatchAngleOut, double deepMatchAngleReturn, double evalLimit = 10000000000000000);
    FieldMatching(double angleEffect, double prevPriority, double evalLimit = 10000000000000000);
    FieldMatching();
    // void setParameter();

    /**
     * デストラクタ
     */
    ~FieldMatching();

    /**
     * 作業領域(pp圃場領域)を設定します。
     * @param[in] field 作業領域 (度単位)
     * @return ResultCode::SUCCESS             正常終了
     *         ResultCode::ERROR_ILLEGAL_STATE 状態不正
     */
    int setField(const GeoPolygon &field);

    /**
     * 作業領域(pp圃場領域)へのマッチングを実行します。
     * @param[in]  pos     トラクターの位置 (度単位)
     * @param[in]  azimuth トラクターの方位角 (北を0度、時計回りを正、ラジアン単位)
     * @param[out] segment マッチング結果 (度単位)
     * @param[out] index マッチング結果 のインデックス
     * @return ResultCode::SUCCESS             正常終了
     *         ResultCode::ERROR_ILLEGAL_STATE 状態不正
     */
    int match(const GeoPoint &pos, double azimuth, GeoSegment &segment, int *index = NULL);

    /**
     * 前回マッチング結果をクリアします。
     * @return ResultCode::SUCCESS             正常終了
     *         ResultCode::ERROR_ILLEGAL_STATE 状態不正
     */
    int clear() {
        if (_state != State::READY) {
            _state = State::ERROR;
            return ResultCode::ERROR_ILLEGAL_STATE;
        }
        _prevIndex = -1;
        return ResultCode::SUCCESS;
    }

    /**
     * 評価値の最低ラインを設定します。
     * @param[in] evalLimit 評価値の最低ライン
     */
    inline void setEvalLimit(double evalLimit) { _evalLimit = evalLimit;
    }

private:

    /** インスタンスの状態 */
    class State {
    public:
        static const int ERROR = -1; ///< エラー
        static const int INIT = 0;   ///< 初期状態
        static const int READY = 1;  ///< 作業領域(pp圃場領域)設定完了
    };

private:

    int _state; ///< インスタンスの状態

    double _angleEffect;  ///< 角度差の影響度合 (DEFAULT=100, 0:角度差を無視して距離だけで評価)
    double _prevPriority; ///< 前回マッチング結果の優遇度合 (DEFAULT=0.9, 1:前回マッチング結果の優遇なし)
    double _evalLimit;    ///< 評価値の最低ライン (評価値が最低ラインより悪い(大きい)辺にはマッチしない。どの辺にもマッチしない場合、WARNING_NO_MATCHを返す)
    double _deepMatchAngleIn;     ///< DeepMatchの閾値1 (デフォルト15度)
    double _deepMatchAngleOut;    ///< DeepMatchの閾値2 (デフォルト30度)
    double _deepMatchAngleReturn; ///< DeepMatchの閾値3 (デフォルト15度)

    GeoPolygon _geoField; ///< 緯度経度座標系の作業領域(pp圃場領域)
    GeoPoint _refPos;     ///< 緯度経度座標系からメートル単位平面座標系への座標変換の基準点 (ラジアン単位)
    Polygon_ _field;      ///< メートル単位平面座標系の作業領域(pp圃場領域)

    int _omitIndex;  ///< マッチング角度が15度以下になるまでマッチング対象から除外する辺のインデックス
    int _prevIndex;  ///< 前回マッチング結果のインデックス
    bool _deepMatch; ///< 前回マッチング結果の辺が、連続マッチング中に、マッチング角度が15度以下になったことがある場合、true (このフラグがtrueの状態でマッチング角度が30度以上になった場合、_omitIndexを更新する)

private:

    /**
     * 作業領域(pp圃場領域)の1辺と、トラクターの位置および進行方向との関係を評価します。
     * @param[in] pos     トラクターの位置
     * @param[in] dir     トラクターの進行方向
     * @param[in] segment 作業領域(pp圃場領域)の1辺
     * @param[out] angle  マッチング角度
     * @return 評価値 (小さい方が良い評価)
     */
    double evaluate(const Point2D &pos, double dir, const PolygonUtil::Segment &segment, double *angle);

    /**
     * 点pと線分sの距離を取得します。
     * 点から線分に下ろした垂線の足の座標が線分の範囲外の場合、近い方の端点までの距離を返します。
     * @param[in]  p  対象となる点
     * @param[in]  s  対象となる線分
     * @param[out] pp 垂線の足の座標、または近い方の端点
     * @return 点と線分の距離
     */
    double clampedPerpendicularLength(const Point2D &p, const PolygonUtil::Segment &s, Point2D &pp);

    /**
     * 度単位の緯度経度からラジアン単位のGeoPointを生成します。
     * @param[in] degLat 度単位の緯度
     * @param[in] degLon 度単位の経度
     * @return ラジアン単位のGeoPoint
     */
    inline static GeoPoint radiansGeoPoint(double degLat, double degLon) {
        return GeoPoint(degLat * M_PI / 180.0, degLon * M_PI / 180.0);
    }

public:

	/**
	 * 作業領域とHPから枕地幅/サイドマージンを逆算します。
	 * セグメント(field[0], field[1])に対応する枕地幅/サイドマージンがwidths[0]に設定されます。
	 * HP側に対応するセグメントが見つからない場合、枕地幅/サイドマージンに負数(-1)が設定されます。
	 * @param[in] field   作業領域 (度単位)
	 * @param[in] hp      HP (度単位)
	 * @param[out] widths fieldから生成したセグメント配列に対応する、枕地幅/サイドマージンの配列
	 */
	static void getHeadlandSideMarginWidths(const GeoPolygon &field, const GeoPolygon &hp, std::vector<double> &widths);
};

}} // namespace yanmar::PathPlan

#endif

// Yanmar Confidential 20200918
/**
 * @file Coordinates.cpp
 *
 * 座標系関連
 */

//#define ENABLE_LOG
#define LOG_TAG "PathPlan::Coordinates"

#include "Coordinates.hpp"
#include "Geometry.hpp"
#include "PolyLib/Common.h"
#include "PathPlanConstant.hpp"
#include "PathPlanIF.hpp"

#define _USE_MATH_DEFINES
#include <cmath>
#include <vector>
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

namespace yanmar { namespace PathPlan {

// 座標系

CoordinateSystem::CoordinateSystem(const GeoPoint& aRefPos) {
	setRefPos(aRefPos);
}

/**
 座標系変換基準点設定
 
 座標系変換(測地系<->デカルト系)するための基準点をラジアンで与える。
    - 予め計算可能な内部使用値も算出しておくため、勝手にrefPosに設定してはいけない。

 @param[in] aRefPos 基準点(ラジアン)
 */
void CoordinateSystem::setRefPos(const GeoPoint& aRefPos) noexcept {
	refPos = aRefPos;
	ref_chi = sqrt(1 - ECCEN_SQU * pow(sin(aRefPos.lat), 2));
	Xr = (SEMI_AXIS / ref_chi) * cos(aRefPos.lat) * cos(aRefPos.lon);
	Yr = (SEMI_AXIS / ref_chi) * cos(aRefPos.lat) * sin(aRefPos.lon);
	Zr = ((SEMI_AXIS * (1 - ECCEN_SQU)) / ref_chi) * sin(aRefPos.lat);
}

/// 平面(デカルト座標)
GeoPointList& Cartesian::convertList(GeoPointList& list) const {
	LOGV(LOG_TAG ":Cartesian", "Cartesian::convertList");
	LOGV(LOG_TAG ":Cartesian", "refPos = (%g, %g) ref =(%g, %g, %g)\n", refPos.lat, refPos.lon, Xr, Yr, Zr);
	
	/*To store the Z coordinate values*/
	vector<Point3D> list3d(list.size());
	
	/*Convert latitude, longitude, height in WGS84 to ECEF X,Y,Z*/
	list3d.clear();
	for (const auto& point : list) {
		const double chi = sqrt(1 - ECCEN_SQU * pow(sin(point.lat), 2));
		const double X = (SEMI_AXIS / chi) * cos(point.lat) * cos(point.lon);
		
		const double Y = (SEMI_AXIS / chi) * cos(point.lat) * sin(point.lon);
		
		const double Z = ((SEMI_AXIS * (1 - ECCEN_SQU)) / chi) * sin(point.lat);
		
		/*copying the data of X,Y,Z into the vector and array*/
		LOGV(LOG_TAG ":Cartesian", "WGS(%g, %g) -> ECEF(%g, %g, %g)\n", point.lat, point.lon, X, Y, Z);
		list3d.emplace_back(X, Y, Z);
	}
	
	/*convert ECEF coordinates to local east, north, up (x,y,z)*/
	list.clear();
	for (auto& point : list3d) {
		const double e = -sin(refPos.lon) * (point.x - Xr) + cos(refPos.lon) * (point.y - Yr);
		
		const double n = -sin(refPos.lat) * cos(refPos.lon) * (point.x - Xr) - sin(refPos.lat) * sin(refPos.lon) * (point.y - Yr) + cos(refPos.lat) * (point.z - Zr);
		
		const double u = cos(refPos.lat) * cos(refPos.lon) * (point.x - Xr) + cos(refPos.lat) * sin(refPos.lon) * (point.y - Yr) + sin(refPos.lat) * (point.z - Zr);
		/*copying the x,y coordinates to the vector*/
		(void)u;
		LOGV(LOG_TAG ":Cartesian", "ECEF(%g, %g, %g) -> ECU(%g, %g, %g)\n", point.x, point.y, point.z, e, n, u);
		list.emplace_back(e, n);
	}
	
#ifdef TXT_FILE_ENABLE
	ofstream ofs;
	ofs.open("LatlongToENU.txt");
	ofs << "LatlongToENU Values " << endl;
	for (auto& point : list)
	{
		ofs << std::setprecision(15) << point.lat << "|";
		ofs << std::setprecision(15) << point.lon << endl;
	}
	ofs.close();
#endif
	
	return list;
}

GeoPoint& Cartesian::convertPoint(GeoPoint& point) const {
	LOGV(LOG_TAG ":Cartesian", "Cartesian::convertPoint(%g, %g)\n", point.lat, point.lon);
	LOGV(LOG_TAG ":Cartesian", "refPos = (%g, %g) ref =(%g, %g, %g)\n", refPos.lat, refPos.lon, Xr, Yr, Zr);
	/*Convert latitude, longitude, height in WGS84 to ECEF X,Y,Z*/
	const double chi = sqrt(1 - ECCEN_SQU * pow(sin(point.lat), 2));
	const double X = (SEMI_AXIS / chi) * cos(point.lat) * cos(point.lon);
	const double Y = (SEMI_AXIS / chi) * cos(point.lat) * sin(point.lon);
	const double Z = ((SEMI_AXIS * (1 - ECCEN_SQU)) / chi) * sin(point.lat);
	/*To store the Z coordinate values*/
	Point3D point3D(X, Y, Z);
	
	/*copying the data of X,Y,Z into the vector and array*/
	LOGV(LOG_TAG ":Cartesian", "WGS(%g, %g) -> ECEF(%g, %g, %g)\n", point.lat, point.lon, X, Y, Z);
	
	/*convert ECEF coordinates to local east, north, up (x,y,z)*/
	const double e = -sin(refPos.lon) * (point3D.x - Xr) + cos(refPos.lon) * (point3D.y - Yr);
	const double n = -sin(refPos.lat) * cos(refPos.lon) * (point3D.x - Xr) - sin(refPos.lat) * sin(refPos.lon) * (point3D.y - Yr) + cos(refPos.lat) * (point3D.z - Zr);
	const double u = cos(refPos.lat) * cos(refPos.lon) * (point3D.x - Xr) + cos(refPos.lat) * sin(refPos.lon) * (point3D.y - Yr) + sin(refPos.lat) * (point3D.z - Zr);
	(void)u;
	LOGV(LOG_TAG ":Cartesian", "ECEF(%g, %g, %g) -> ECU(%g, %g, %g)\n", point3D.x, point3D.y, point3D.z, e, n, u);
	
	point = GeoPoint(e, n);
	return point;
}

/// 測地系曲面
GeoPointList& Geodesic::convertList(GeoPointList& list) const {
	LOGV(LOG_TAG ":Geodesic", "Geodesic::convertList()");
	LOGV(LOG_TAG ":Geodesic", "refPos = (%g, %g) ref =(%g, %g, %g)\n", refPos.lat, refPos.lon, Xr, Yr, Zr);
	
	/*Convert latitude, longitude, height in WGS84 to ECEF X,Y,Z*/
	for (auto& point : list) {
		convertPoint(point);
	}
	
#ifdef TXT_FILE_ENABLE
	ofstream ofs;
	ofs.open("LatlongToENU.txt");
	ofs << "LatlongToENU Values " << endl;
	for (const auto& point : list)
	{
		ofs << std::setprecision(15) << point.lat << "|";
		ofs << std::setprecision(15) << point.lon << endl;
	}
	ofs.close();
#endif
	
	return list;
}

GeoPoint& Geodesic::convertPoint(GeoPoint& point) const {
	LOGV(LOG_TAG ":Geodesic", "Geodesic::convertPoint(%g, %g)", refPos.lat, refPos.lon);
	LOGV(LOG_TAG ":Geodesic", "refPos = (%g, %g) ref =(%g, %g, %g)\n", refPos.lat, refPos.lon, Xr, Yr, Zr);
	
	/*ENU Values*/
	const double e1 = point.lat;
	const double n1 = point.lon;
	const double u1 = 0.0;
	
	/*Calculating X,Y,Z*/
	const double X = -sin(refPos.lon) * e1 - cos(refPos.lon) * sin(refPos.lat) * n1 + cos(refPos.lon) * cos(refPos.lat) * u1 + Xr;
	const double Y = cos(refPos.lon) * e1 - sin(refPos.lon) * sin(refPos.lat) * n1 + cos(refPos.lat) * sin(refPos.lon) * u1 + Yr;
	const double Z = cos(refPos.lat) * n1 + sin(refPos.lat) * u1 + Zr;
	
	const double r2 = (pow(X, 2) + pow(Y, 2));
	const double r = sqrt(r2);
	const double F = 54 * pow(SEMI_MINOR, 2) * pow(Z, 2);
	const double G = (r2 + (1 - ECCEN_SQU) * pow(Z, 2) - (ECCEN_SQU * E2));
	const double c = (ECCEN_SQU * ECCEN_SQU * F * r2) / (G * G * G);
	const double s = pow((1 + c + sqrt((c * c) + (2 * c))), 0.33333333);
	const double P = F / (3 * pow((s + 1 / s + 1), 2) * G * G);
	const double Q = sqrt(1 + 2 * ECCEN_SQU * ECCEN_SQU * P);
	
	const double ro = (-(ECCEN_SQU * P * r) / (1 + Q)) + sqrt((SEMI_AXIS * SEMI_AXIS / 2) * (1 + 1 / Q) - ((1 - ECCEN_SQU) * P * pow(Z, 2)) / (Q * (1 + Q)) - P * r2 / 2);
	
	const double tmp = pow((r - (ECCEN_SQU * ro)), 2);
	//	const double U = sqrt(tmp + pow(Z, 2));
	const double V = sqrt(tmp + (1 - ECCEN_SQU) * pow(Z, 2));
	const double zo = (pow(SEMI_MINOR, 2) * Z) / (SEMI_AXIS * V);
	//	const double h = U * (1 - pow(SEMI_MINOR, 2) / (SEMI_AXIS * V));
	
	/*Values of Latitude and Longitude*/
	const double phi = atan((Z + SEC_ECCEN_SQU * zo) / r);
	const double lambda = atan2(Y, X);
	
	/*Storing the phi and lambda values*/
	point = GeoPoint{phi, lambda};
	Degree::convert(point);
	return point;
}
}} // yanmar::PathPlan


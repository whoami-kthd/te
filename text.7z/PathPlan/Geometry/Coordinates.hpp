// Yanmar Confidential 20200918
/**
 * @file Coordinates.hpp
 *
 * 座標系関連
 */
#pragma once

#include "PathPlanIF.hpp"

#include <string>
#include <vector>

namespace yanmar { namespace PathPlan {

/// Reciprocal flattering (1/f:逆扁平率 WGS84準拠)
static constexpr double RCP_FLAT = 1/298.257223563;	// 0.0033528106647474805

/// First Eccentricity squared
static constexpr double ECCEN_SQU = ((2 * RCP_FLAT) - 1/(298.257223563 * 298.257223563)); //0.0066943799901413165;

/// Earth semi major axis in meters (WGS84 長半径)
static constexpr double SEMI_AXIS = 6378137.0;

/// Semi-minor axis (WGS84 短半径)
static constexpr double SEMI_MINOR = (SEMI_AXIS * (1 - RCP_FLAT)); //6356752.314245179

/// pow(SEMI_AXIS,2) - pow(SEMI_MINOR,2)
static constexpr double E2 = 2.723316061075547E11;

/// (RCP_FLAT * (2 - RCP_FLAT) / pow((1-RCP_FLAT),2))
static constexpr double SEC_ECCEN_SQU = 0.006739496742276434;

/**
 * 座標系操作クラス(ベース)
 */
class CoordinateSystem{
public:
	CoordinateSystem() = default;
	explicit CoordinateSystem(const GeoPoint& aRefPos);
	virtual ~CoordinateSystem() = default;
	void setRefPos(const GeoPoint& aRefPos) noexcept;
	
	virtual CoordinateSystem* getInstance(const GeoPoint& refPos) const = 0;
	
	GeoPointList& convert(GeoPointList& list) const {
		return convertList(list);
	}
	GeoPoint& convert(GeoPoint& point) const {
		return convertPoint(point);
	}
	GeoSegment& convert(GeoSegment& segment) const {
		segment[0] = convertPoint(segment[0]);
		segment[1] = convertPoint(segment[1]);
		return segment;
	}
	
private:
	virtual GeoPointList& convertList(GeoPointList& list) const = 0;
	virtual GeoPoint& convertPoint(GeoPoint& point) const = 0;
	
public:
	GeoPoint refPos;
	
protected:
	double ref_chi = 0.0;
	double Xr = 0.0;
	double Yr = 0.0;
	double Zr = 0.0;
};

/**
 * 座標系操作クラス(デカルト平面系)
 */
class Cartesian : public CoordinateSystem{
public:
	explicit Cartesian(const GeoPoint& aRefPos = GeoPoint()) :
		CoordinateSystem(aRefPos)
	{}
	virtual Cartesian* getInstance(const GeoPoint& aRefPos) const {
		return new Cartesian(aRefPos);
	};

private:
	virtual GeoPointList& convertList(GeoPointList& list) const;
	virtual GeoPoint& convertPoint(GeoPoint& point) const;
};

/**
 * 座標系操作クラス(測地系曲面)
 */
class Geodesic : public CoordinateSystem{
public:
	explicit Geodesic(const GeoPoint& aRefPos = GeoPoint()) :
		CoordinateSystem(aRefPos)
	{}
	virtual Geodesic* getInstance(const GeoPoint& aRefPos) const {
		return new Geodesic(aRefPos);
	};

private:
	virtual GeoPointList& convertList(GeoPointList& list) const;
	virtual GeoPoint& convertPoint(GeoPoint& point) const;
};

static Cartesian CARTESIAN; ///< デカルト平面座標系
static Geodesic GEODESIC;	///< 測地曲面座標系

}} // yanmar::PathPlan

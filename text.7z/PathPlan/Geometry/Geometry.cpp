// Yanmar Confidential 20200918
/**
 * @file Geometry.cpp
 *
 * 幾何操作モジュール。
 */
//#define LOGLEVEL 5
#define LOG_TAG "PathPlan:Geometry"

#include "Geometry.hpp"
#include "PolyLib/Common.h"
#include "PathPlanIF.hpp"

#include <cmath>
using namespace std;

namespace yanmar { namespace PathPlan {

/**
 度数からラジアンへ変換
 
 list内の要素を度数からラジアン変換する。
 
 @param[in,out] list 度数値のGeoPointList
 @return 渡されたGeoPointListの参照
 */
GeoPointList& Radian::convertList(GeoPointList& list) const {
	for (auto& point : list) {
		point = convert(point);
	}
	
	return list;
}

/**
 ラジアンから度数へ変換
 
 list内の要素をラジアンから度数へ変換する。
 
 @param[in,out] list ラジアン値のGeoPointList
 @return 渡されたGeoPointListの参照
 */
GeoPointList& Degree::convertList(GeoPointList& list) const {
	for (auto& point : list) {
		point = convert(point);
	}
	
	return list;
}

/// Ciecle nullオブジェクト
const Circle Circle::nullobj;

/**
 角距離比較
 
 Circle 回転方向に従った方向に、中心点cに対する角度 Pnt - c - Pnt1 と Pnt - c - Pnt2 のどちらが成す角が小さいかを返す。
 - 与えられた点が円周上にあるかどうかは考慮しない。必要があれば別途判定すること。
 - 同値の場合FIRST優先。
 
 @param[in] Pnt 基準点
 @param[in] Pnt1 点1
 @param[in] Pnt2 点2
 @return 結果
 @retval NextPoint::FIRST  :Pnt1が近い
 @retval NextPoint::SECOND :Pnt2が近い
 */
int Circle::isNextPoint(const GeoPoint& Pnt, const GeoPoint& Pnt1, const GeoPoint& Pnt2) const {
	LOGV(LOG_TAG "::Circle::isNextPoint", "(ref, first, second)");

	// 同位置ならばPnt1が早い
	if (isIsometric(Pnt1, Pnt) || isIsometric(Pnt1, Pnt2)) {
		return Circle::NextPoint::FIRST;
	}

	const Vector2D centerVec = center;
	// angle of refernce point
	double RefPntAng = centerVec.getAngleTo(Pnt);
	// angle of first point
	double FrstPntAng = centerVec.getAngleTo(Pnt1);
	// angle of second point
	double ScndPntAng = centerVec.getAngleTo(Pnt2);
	
	return isNextAngle(RefPntAng, FrstPntAng, ScndPntAng);
}

/**
 角距離比較
 
 基準角から Circle の回転方向に従った方向に回転したとき、角1、角2のどちらが近いかを返す。
 - 等距離の場合は角1が優先。等距離比較に許容差あり。@see isIsometric()
 
 @param[in] RefPntAng 基準角
 @param[in] FrstPntAng 角1
 @param[in] ScndPntAng 角2
 @return 結果
 @retval NextPoint::FIRST  :角1が近い
 @retval NextPoint::SECOND :角2が近い
 */
int Circle::isNextAngle(double RefPntAng, double FrstPntAng, double ScndPntAng) const {
	LOGV(LOG_TAG "::Circle:isNextAngle", "(ref:%g, 1st:%g, 2nd:%g), orient:%d", RefPntAng, FrstPntAng, ScndPntAng, orient);
	const double AngBtwnFrstNRefPnt = Radian::distance(RefPntAng, FrstPntAng, orient);	// angle between first point and reference point
	const double AngBtwnScndNRefPnt = Radian::distance(RefPntAng, ScndPntAng, orient);	// angle between second point and reference point

	if ((AngBtwnFrstNRefPnt < AngBtwnScndNRefPnt) || isIsometric(AngBtwnFrstNRefPnt, AngBtwnScndNRefPnt)) {
		// point Pnt1 is next point from reference point
		LOGV(LOG_TAG ":Circle", "isNextAngle FIRST");
		return NextPoint::FIRST;
	} else {
		// point Pnt2 is next point from reference point
		LOGV(LOG_TAG ":Circle", "isNextAngle SECOND");
		return NextPoint::SECOND;
	}
}

/**
 円同士の交点取得
 
 円同士の交点を返す。交差していない場合、戻り値は不定。

 @param[in] circle 相手の円
 @return std::pair<XY_Point, XY_Point> 交点のペア
 */
std::pair<GeoPoint, GeoPoint> Circle::getIntersectPoints(const Circle& circle) const {
	// 交差2点の角度
	// - 互いの中心方向(cAngle)に対する角度(±bAngle)
	const auto angles = getIntersectAngles(circle);
	double bAngle = angles.first;
	double tRadius = radius;
	double cAngle;

	// ±90度以下の方を使う(1度はマージン)
	if (angles.first < Radian::convert(91)) {
		// 自身円で計算する
		cAngle = Vector2D{center}.getAngleTo(circle.center);
	} else {
		// 相手円で計算する
		tRadius = circle.radius;
		bAngle = angles.second;
		cAngle = Vector2D{circle.center}.getAngleTo(center);
	}
	// 交点座標
	const GeoPoint p1 = circle.center + GeoPoint(tRadius) * Vector2D(cos(cAngle - bAngle), sin(cAngle - bAngle));
	const GeoPoint p2 = circle.center + GeoPoint(tRadius) * Vector2D(cos(cAngle + bAngle), sin(cAngle + bAngle));

	LOGD(LOG_TAG, "Circles intersecs: (%g, %g) R:%g, -> (%g, %g) R:%g, dist:%g, th:%g",
		 center.x, center.y, radius, circle.center.x, circle.center.y, circle.radius, distance(circle), Degree::convert(cAngle));
	LOGD(LOG_TAG, " intersecs points: (%g, %g), (%g, %g): th1:%g, th2:%g", p1.x, p1.y, p2.x, p2.y, Degree::convert(cAngle - bAngle), Degree::convert(cAngle + bAngle));

	return std::pair<GeoPoint, GeoPoint>{p1, p2};
}
	
/**
 円同士の交点角度取得
 
 円同士の交点の角度を返す。互いの中心の方向に対する差(±ラジアン)で返す。
 - 交差していない場合、戻り値は不定。
 
 @param[in] circle 相手の円
 @return std::pair<XY_Point, XY_Point> 交点の角度ペア。first = 自分の角度、second = 相手の角度。
 */
std::pair<double, double> Circle::getIntersectAngles(const Circle& circle) const {
	// 交差2点の角度
	// - 互いの中心方向(cAngle)に対する角度(±angle)
	const double dist2 = distance2(circle);
	const double dist = distance(circle);
	// 自分の角度
	const double angle1 = acos((pow(circle.radius, 2) - dist2 - pow(radius, 2)) / (2.0 * radius * dist));
	// 相手の角度
	const double angle2 = acos((pow(radius, 2) - dist2 - pow(circle.radius, 2)) / (2.0 * circle.radius * dist));
	
	return std::pair<double, double>{angle1, angle2};
}

}} // yanmar::PathPlan

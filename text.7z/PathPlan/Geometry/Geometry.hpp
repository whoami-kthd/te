// Yanmar Confidential 20200918
/**
 * @file Geometry.hpp
 *
 * 幾何操作モジュール。
 * - GeoPoint, GeoPointList はインターフェースで使用しているためPathPlanIF.hppで定義されている。
 */
#pragma once

#include <string>
#include <vector>
#include <array>
#include <cmath>

#include "PathPlanConstant.hpp"
#include "PathPlanIF.hpp"

namespace yanmar { namespace PathPlan {

// Intersection
namespace Intersection {
    static constexpr int YES = 1;	///< must be 1 !ATTENTION: 値の比較には使用禁止。NOと比較すること。
	static constexpr int NO = 0;
	static constexpr double MARGIN = 0.01;
}

namespace RotateDirection {
    static constexpr int UNDEFINED = 0;
	static constexpr int ANTICLOCKWISE = 1;
	static constexpr int CLOCKWISE = -1;

    /// 値の反転
    static inline constexpr
    int invert(int orient) { return -orient; }
}

namespace VortexType {
    static constexpr int CYCLONE = Param::Work::Pattern::CYCLONE;
    static constexpr int ANTICYCLONE = Param::Work::Pattern::ANTICYCLONE;
    
    /// 値の反転
    static inline constexpr
    int invert(int vortex) { return -vortex; }
}

/**
 * 角度単位変換クラス
 *
 * 現在は度数とラジアン間の変換しか考慮していないので入力側の単位は決め打ち。
 */
class AngleUnit{
public:
	/// 度-ラジアン変換係数
	static constexpr double TO_RADIAN_FACTOR = (M_PI / 180);
	/// ラジアン-度変換係数
	static constexpr double TO_DEGREE_FACTOR = (180 / M_PI);
	/// 度-ラジアン変換
	static constexpr double toRadian(double angle) { return (angle * TO_RADIAN_FACTOR); }
	/// ラジアン-度変換
	static constexpr double toDegree(double angle) { return (angle * TO_DEGREE_FACTOR); }

	GeoPointList& convert(GeoPointList& list) const {
		return convertList(list);
	}
	const GeoPoint& convert(GeoPoint& point) const {
		return convertPoint(point);
	}
	const GeoSegment& convert(GeoSegment& segment) const {
		segment[0] = convertPoint(segment[0]);
		segment[1] = convertPoint(segment[1]);
		return segment;
	}
	double convert(double angle) const {
		return convertAngle(angle);
	}

private:
	virtual GeoPointList& convertList(GeoPointList& list) const = 0;
	virtual GeoPoint& convertPoint(GeoPoint& point) const = 0;
	virtual double convertAngle(double angle) const = 0;
};

/**
 * 角度単位変換クラス(ラジアン)
 */
class Radian : public AngleUnit {
private:
	virtual GeoPointList& convertList(GeoPointList& list) const;
	virtual GeoPoint& convertPoint(GeoPoint& point) const { return Radian::convert(point); }
	virtual double convertAngle(double degree) const { return Radian::convert(degree); }

public:
	using AngleUnit::convert;
	static constexpr double convert(double degree) { return AngleUnit::toRadian(degree); }
	/**
	 * 度数からラジアンへ変換
	 *
	 * @param[in] point 度数値のGeoPoint
	 * @return ラジアン値のGeoPoint
	 */
	static GeoPoint& convert(GeoPoint& point) { point *= GeoPoint{TO_RADIAN_FACTOR}; return point; }
	
	/**
	  相対角度
	 
	  二つの角度のorient向きに測った差の絶対値を返す。入力範囲は ±2π。
	
	  @param[in] src 開始角度
	  @param[in] dst 終了角度
	  @param[in] orient 回転方向
	  @return 角度 [0, 2π)
	 */
	static double distance(double src, double dst, int orient) {
		return (orient == RotateDirection::CLOCKWISE) ? distance(dst, src) : distance(src, dst);
	}

	/// 角度距離(反時計回り -PI <= angle <= PI)
	static double distance(double org, double dst) {
		double distance = dst - org;
		if (distance < 0.0) {
			distance += (2 * M_PI);
		}
		
		return distance;
	}
};

/**
 * 角度単位変換クラス(度数)
 */
class Degree : public AngleUnit {
private:
	virtual GeoPointList& convertList(GeoPointList& list) const;
	virtual GeoPoint& convertPoint(GeoPoint& point) const { return Degree::convert(point); }
	virtual double convertAngle(double radian) const { return Degree::convert(radian); }

public:
	using AngleUnit::convert;
	static constexpr double convert(double radian) { return AngleUnit::toDegree(radian); }
	/**
	 * ラジアンから度数へ変換
	 *
	 * @param[in] point ラジアンのGeoPoint
	 * @return 度数値のGeoPoint
	 */
	static GeoPoint& convert(GeoPoint& point) { point *= GeoPoint{TO_DEGREE_FACTOR}; return point; }

	/// 角度距離 (-PI <= angle <= PI)
	static double distance(double src, double dst, int orient) {
		return (orient == RotateDirection::CLOCKWISE) ? distance(dst, src) : distance(src, dst);
	}

	/// 角度距離
	static double distance(double src, double dst) {
		double distance = dst - src;
		if (distance < 0.0) {
			distance += 360.0;
		}
		
		return distance;
	}
};

// 関数の引数で変換先の指示用に使うインスタンス
static constexpr Degree DEGREE{};	///< 度数オブジェクト
static constexpr Radian RADIAN{};	///< ラジアンオブジェクト

/**
 * 2次元ベクトルクラス
 *
 * x,y成分を保持する2次元ベクトルクラス。GeoPointと可換であり、成分ごとの四則演算とベクトル操作関数を持つ。
 */
class Vector2D : public GeoPoint {
public:
	constexpr Vector2D(double x, double y) :
		GeoPoint(x, y)
	{}

	constexpr Vector2D(double x = 0.0) :
		GeoPoint(x)
	{}

	constexpr Vector2D(const GeoPoint& aVec) :
		GeoPoint(aVec)
	{}

	/// 2点間のベクトル生成
	Vector2D(const GeoPoint& org, const GeoPoint& dst) :
		GeoPoint(dst - org)
	{}
	
	/// 角度と長さから生成
	static Vector2D fromAngle(double angle, double value = 1.0) {
		return Vector2D(value) * Vector2D(cos(angle), sin(angle));
	}

	/// 反転ベクトル取得
	Vector2D operator-() const {
		return Vector2D{-x, -y};
	}
	
	/// ベクトル角度取得
	double getAngle() const {
		return atan2(y, x);
	}

	/// ベクトル角度取得(自分から)
	double getAngleTo(Vector2D aVec) const {
		aVec -= *this;
		return aVec.getAngle();
	}

	/// ベクトル角度取得(原点指定)
	double getAngleFrom(const Vector2D& aVec) const {
		Vector2D tmp = *this - aVec;
		return tmp.getAngle();
	}

	/// 絶対値化
	Vector2D abs() const {
		return Vector2D{std::abs(x), std::abs(y)};
	}
	
	/// x,y入れ替え
	Vector2D swapAxis() const {
		return Vector2D(y, x);
	}

	/// ベクトルの大きさ(原点からの距離)
	double getLength() const {
		return hypot(x, y);
	}

	/// 単位ベクトル取得
	Vector2D getUnitVector() const {
		Vector2D tmp{*this};
		tmp /= getLength();
		return tmp;
	}
	
	/// 単位ベクトル化
	void normalize() {
		*this /= getLength();
	}
    
    /// 内積(ドット積)取得
    double getDotProduct(const Vector2D& aVec) const {
        return (x * aVec.x + y * aVec.y);
    }
    
    /**
     正規化済み内積(ドット積)取得
     自身と相手の単位ベクトル同士の内積を求める
     */
    double getDotProductNormalized(const Vector2D& aVec) const {
        return (getDotProduct(aVec) / (getLength() * aVec.getLength()));
    }

    /// クロス積(ベクトル積)取得
    /// thisに対するaVecの外積。外積は逆にすると結果が異なるので注意。
    double getCrossProduct(const Vector2D& aVec) const {
        return (x * aVec.y - y * aVec.x);
    }

    /**
     正規化済み外積取得
     
     自身と相手の単位ベクトル同士の外積を求める
     */
    double getCrossProductNormalized(const Vector2D& aVec) const {
        return (getCrossProduct(aVec) / (getLength() * aVec.getLength()));
    }

    /**
	 平行検査
	 
	 外積利用・許容差float epsilon以内
	 */
	bool isParallel(const Vector2D& aVec, double tol = std::numeric_limits<float>::epsilon()) const	{
        return (std::abs(getCrossProduct(aVec)) <= tol);
	}

	/**
	 直交検査
	 
	 内積利用・許容差float eplsilon以内
	 */
	bool isOrthogonal(const Vector2D& aVec, double tol = std::numeric_limits<float>::epsilon()) const	{
		return (std::abs(getDotProduct(aVec)) <= tol);
	}

    /**
     直交ベクトル取得
     
     @param[in] dir 回転方向
         @arg CLOCKWIZE = 1;
         @arg ANTICLOCKWIZE = -1;
     */
    Vector2D getOrthogonal(double dir) const {
        return Vector2D{-y, x} * Vector2D{dir};
    }
    
    constexpr static double CLOCKWIZE = 1.0;
    constexpr static double ANTICLOCKWIZE = -1.0;
};

/**
 単位ベクトルクラス
 */
class UnitVector2D : public Vector2D {
public:
	UnitVector2D(const GeoPoint& org) :
		Vector2D(org)
	{
		normalize();
	}

	UnitVector2D(const GeoPoint& org, const GeoPoint& dst) :
		Vector2D(org, dst)
	{
		normalize();
	}

    /**
     並行検査
     
     外積利用・許容差float eplsilon以内
     */
    bool isParallel(const Vector2D& aVec, double tol = std::numeric_limits<float>::epsilon()) const	{
        return (std::abs(getCrossProduct(aVec)) <= tol);
    }

    /**
     正規化済み外積取得
     
     自身と相手の単位ベクトル同士の外積を求める
     */
    double getCrossProductNormalized(const UnitVector2D& aVec) const {
        return getCrossProduct(aVec);
    }
};

/**
 座標回転クラス
 
 予め回転中心座標と回転角を与えて2次元回転行列を保持させるクラス。
 */
class Rotater {
public:
	constexpr Rotater() :
		rotateAngle(0.0)
	{}
	
	constexpr Rotater(double angle) :
		rotateAngle(angle)
	{}
	
	Rotater(double angle, const GeoPoint& point) :
		rotateAngle(angle),
		rotor{{{cos(angle), sin(angle)}, {-sin(angle), cos(angle)}}},
		origin(point)
	{}

	/// 中心点設定
	void setOrigin(const GeoPoint& point) {
		origin = point;
	}
	
	/// 回転角設定
	void setAngle(double angle) {
		rotateAngle = angle;
		rotor = {{{cos(angle), sin(angle)}, {-sin(angle), cos(angle)}}};
	}

	/// 逆回転設定
	void setReverse() {
		setAngle(-rotateAngle);
	}

	/// 座標回転(origin中心)
	GeoPoint rotate(GeoPoint pos) const {
		return rotateByOrigin(pos - origin) + origin;
	}
    
    /// 座標回転(原点中心)
	GeoPoint rotateByOrigin(const Vector2D& pos) const {
        const double x = pos.getDotProduct(rotor[0]);
        const double y = pos.getDotProduct(rotor[1]);
        return GeoPoint{x, y};
    }

    double rotateAngle;
	std::array<Vector2D, 2> rotor;
	GeoPoint origin;
};

/**
 ターン円クラス
 
 デフォルトの回転方向は未定義(UNDEFINED)で、validate()でfalseが返る。
 */
struct Circle {
	struct Orient {
		static constexpr int UNDEFINED = 0;
		static constexpr int CLOCKWISE = RotateDirection::CLOCKWISE;
		static constexpr int ANTICLOCKWISE = RotateDirection::ANTICLOCKWISE;
	};
	struct NextPoint {
		static constexpr int FIRST = 0;
		static constexpr int SECOND = 1;
	};

	explicit Circle(const GeoPoint& aCenter = GeoPoint(0, 0), double aR = 0.0, int aRotdir = Orient::UNDEFINED) :
		center(aCenter),
		radius(aR),
		orient(aRotdir)
	{}

	Circle(const Circle& circle) :
		center(circle.center),
		radius(circle.radius),
		orient(circle.orient)
	{}

	/// 数値有効チェック
	bool validate() const{
		return (center.isFinite() && std::isfinite(radius) &&
				(orient == Orient::CLOCKWISE || orient == Orient::ANTICLOCKWISE));
	}

	/// 逆回転演算子
	Circle operator-() const {
		Circle circle(*this);
		circle.orient = -orient;
		return circle;
	}

	void set(const GeoPoint& aCenter, double aRadius) {
		center = aCenter;
		radius = aRadius;
	}
	
	void set(const GeoPoint& center, double aRadius, int aOrient) {
		set(center, aRadius);
		orient = aOrient;
	}
	
	/**
	 円同士の間隔
	
	 二円の間隔を返す。二円が接している場合には0、円が重なっている場合は負の値を返す。
	 */
	double interval(const Circle& dest) const {
		return (center.distance(dest.center) - (radius + dest.radius));
	}

	/**
	 円と点の間隔
	 
	 円周と点との間隔を返す。点が円周上にあるとき0になり、円内にある場合は負の値になる。
	 */
	double interval(const GeoPoint& dest) const {
		return (center.distance(dest) - radius);
	}

	/// 円の中心間の距離
	double distance(const Circle& dest) const {
		return center.distance(dest.center);
	}

	/// 円の中心と点の距離
	double distance(const GeoPoint& dest) const {
		return center.distance(dest);
	}

	/// 中心間の距離の二乗
	double distance2(const Circle& dest) const {
		return center.distance2(dest.center);
	}
	
	/// 中心と点の距離の二乗
	double distance2(const GeoPoint& dest) const {
		return center.distance2(dest);
	}

	// 順序判定
	int isNextPoint(const GeoPoint& Pnt, const GeoPoint& Pnt1, const GeoPoint& Pnt2) const;
	int isNextAngle(double RefPntAng, double FrstPntAng, double ScndPntAng) const;
	int isInSight(double FrstPntAng) const;

	/**
	 交差判定
	 
	 円自体の重なりがあるかどうかを返す。円周に交点があるかどうかではない。接する場合は交差しない。
	 */
	int checkIntersection(const Circle& circle) const {
		return (center.distance(circle.center) < (radius + circle.radius)) ? Intersection::YES : Intersection::NO;
	}

	/**
	 交差判定
	 
	 点が円内にあるかどうかを返す。円周上にあるかどうかではない。円周上の点は交差しない。
	 */
	int checkIntersection(const GeoPoint& point) const {
		return (center.distance(point) < radius) ? Intersection::YES : Intersection::NO;
	}

	/**
	 接触判定
	 
	 点が円に接する(円周上にある)かどうかを返す。マージンがある。
	 */
	bool isContact(const GeoPoint& point, double tolerance = std::numeric_limits<float>::epsilon() * 10.0) const {
		return isIsometric(center.distance(point), radius, tolerance);
	}

	/**
	 円同士の交点
	 */
	std::pair<GeoPoint, GeoPoint> getIntersectPoints(const Circle& circle) const;

	/**
	 円同士の交差する角度
	 */
	std::pair<double, double> getIntersectAngles(const Circle& circle) const;
	
	GeoPoint center;
	double radius;
	int orient;
	
	static const Circle nullobj;
};

/**
 指定方向へシフト
 座標に対してvecの値を加える。
 @param[in] vec シフト方向
 @return シフト後のインスタンス
 */
template<typename T>
T getShifted(T p, const Vector2D& vec) noexcept {
    p += vec;
   
    return p;
}

/**
 指定方向へシフト(距離つき)
 座標に対してvecの値を加える。
 @param[in] vec シフト方向
 @param[in] val シフト距離
 @return シフト後のインスタンス
 */
template<typename T>
T getShifted(T p, Vector2D vec, double val) noexcept {
    if (val != 0.0)
    {
        vec.normalize();
        vec *= val;
        p = getShifted(p, vec);
    }
    
    return p;
}

/**
 三角形の各対辺の長さとその合計を返す
 */
inline
std::array<double, 4> getOppositLengths(const GeoPoint& p0, const GeoPoint& p1, const GeoPoint& p2) {
    const double a = p1.distance(p2);
    const double b = p2.distance(p0);
    const double c = p0.distance(p1);
    const double s0 = (a + b + c);
    return {a, b, c, s0};
}

/**
 内心
 
 三角形の内心を求める
 */
inline
GeoPoint getIncenter(const GeoPoint& p0, const GeoPoint& p1, const GeoPoint& p2, std::array<double, 4> lengths) {
    const double& a = lengths[0];
    const double& b = lengths[1];
    const double& c = lengths[2];
    const double& s0 = lengths[3];
    // (a・xa + b・xb + c・xc )/(a + b + c), (a・ya + b・yb + c・yc )/(a + b + c)
    const GeoPoint p = (p0 * Vector2D{a} + p1 * Vector2D{b} + p2 * Vector2D{c}) / Vector2D{s0};
    return p;
}

/**
 内心
 
 三角形の内心を求める
 */
inline
GeoPoint getIncenter(const GeoPoint& p0, const GeoPoint& p1, const GeoPoint& p2) {
    const auto lengths = getOppositLengths(p0, p1, p2);
    // 内心座標
    const GeoPoint p = getIncenter(p0, p1, p2, lengths);
    return p;
}

/**
 内接円
 
 三角形の内接円を求める
 */
inline
Circle getIncircle(const GeoPoint& p0, const GeoPoint& p1, const GeoPoint& p2) {
    const auto lengths = getOppositLengths(p0, p1, p2);
    const double& a = lengths[0];
    const double& b = lengths[1];
    const double& c = lengths[2];
    const double& s0 = lengths[3];

    // 内心座標
    const GeoPoint p = getIncenter(p0, p1, p2, lengths);
    // 内接円の半径
    const double s1 = s0 / 2.0;
    const double r = sqrt((s1 - a) * (s1 - b) * (s1 - c) / s1);

    return Circle{p, r};
}

/// 等価判定
inline
bool isIsometric(const Circle& lhs, const Circle& rhs) {
	return ((lhs.orient == rhs.orient) &&
			isIsometric(lhs.radius, rhs.radius) &&
			isIsometric(lhs.center, rhs.center));
}

/**
 * 垂線長
 *
 * 直角三角形の直角をなす一辺と斜辺から、残りの辺の長さを求める。
 */
inline
double leg(double hypot, double leg1) {
    const double d = (hypot * hypot) - (leg1 * leg1);
    return (d < 0.0) ? 0.0 : sqrt(d);
}

/**
 * 下限正規化
 *
 * boundを下回るval値をbound以上にrange単位で調整する。
 * bound以上であれば何もしない。
 * @see normalize
 */
template<typename T>
T normalizeInc(T bound, T range, T val) {
	if (bound <= val) {
		return val;
	}

	return normalizeInc(bound, range, val + range);
}

/**
 * 上限正規化
 *
 * boundを超えるval値をbound以下にrange単位で調整する。
 * bound以下であれば何もしない。
 * @see normalize
 */
template<typename T_>
T_ normalizeDec(T_ bound, T_ range, T_ val) {
	if (val <= bound) {
		return val;
	}

	return normalizeDec(bound, range, val - range);
}

/**
 * 範囲正規化
 *
 * valを ラップアラウンドする値 　[lower_bound, upper_bound] の範囲にrange単位で正規化する。
 * - 例えばラジアンを 0 <= val <= π の範囲に正規化する場合 normalize(normalize(0, π, π, val) などとする。
 * - val 以外が定数であることを期待している。valも定数であればコンパイル時定数となる可能性がある。
 * - はみ出す量がrange未満であればコード効率が最良である。それ以上でも動作はする。
 *
 * @param[in] lower_bound	下限値
 * @param[in] upper_bound	上限値
 * @param[in] range	値の幅
 * @param[in] val	正規化する値
 * @return 正規化後の値
 */
template<typename T_>
T_ normalize(const T_ lower_bound, const T_ upper_bound, const T_ range, const T_& val) {
	if (val < lower_bound) {
		return normalizeInc(lower_bound, range, val);
	} else if (upper_bound < val) {
		return normalizeDec(upper_bound, range, val);
	} else {
		return val;
	}
}

/**
 内積
 3点が成す二つのベクトル (p0, p1) と (p1, p2) の内積を返す。
 */
inline static
double dotProduct(const GeoPoint& p0, const GeoPoint& p1, const GeoPoint& p2) {
    const Vector2D eVec{p0, p1};
    const Vector2D lVec{p1, p0};
    return eVec.getDotProduct(lVec);
}

/**
 外積
 3点で成す二つのベクトル  (p0, p1) と (p1, p2) の外積を返す。
*/
inline static
double crossProduct(const GeoPoint& p0, const GeoPoint& p1, const GeoPoint& p2) {
    const Vector2D eVec{p0, p1};
    const Vector2D lVec{p1, p0};
    return eVec.getCrossProduct(lVec);
}

}} // yanmar::PathPlan

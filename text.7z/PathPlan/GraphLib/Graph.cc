// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] CREATION OF GRAPH AND SHORTEST PATH ALGORITHM                  */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company      :      KPIT TECHNOLOGIES LTD, BANGALORE                     */
/* Client       :      YANMAR Co. Ltd, JAPAN                                */
/* Author       :      MANUJ SHARMA,SACHIN BHISIKAR                         */
/*                     (YANMAR PathPlanning Team )                          */
/* Version      :      1.1                                                  */
/* The purpose of the graph data class is to provide auxiliary              */
/* functionality to other classes. The graph class is used by other classes */
/* for creating adjacency graphs and calculating graph functionalities like */
/* shortest path algorithms.                                                */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140124                  -              Initial version                 */
/* 20140430                  -              Version   1.1                   */
/*                                                                          */
/****************************************************************************/

//#define DEBUG_LOG
#define LOG_TAG "PathPlan::Graph"

#include "Graph.h"

#include <algorithm>

using namespace std;

namespace yanmar { namespace PathPlan {

// VTypes
constexpr int Graph::DELETED;
constexpr int Graph::SINGLE;
constexpr int Graph::DOUBLE;

/**
 コンストラクタ
 */
Graph::Graph() :
	vertices(0)
{
	vertices.reserve(NO_OF_VERTICES);
}

/**
 頂点数取得

 現在保持している頂点数を返す
 
 @return 頂点数
 */
int Graph::NumVertices() const
{
	return (int)vertices.size();
}

/**
 エッジ存在判定

 指定頂点uが頂点vへ向かうエッジを持つかどうかを返す。
 
 @param[in] u 始点頂点
 @param[in] v 宛先頂点

 @return u-v間エッジ存在
 @retval true: u-v間エッジあり
 @retval false: u-v間エッジなし
 */
bool Graph::IsEdge(int u, int v) const
{
	LOGV(LOG_TAG, "IsEdge");

	auto it = find(u, v);
	return (it != end(u));
}

/**
 This function returns whether the vertex
 is having more than two double edges.

 @param[in] u   index of target virtex
 @retval true   if u has double edge
 @retval false  otherwise
 */
bool Graph::IsDoubleVertex(int u) const
{
	LOGV(LOG_TAG, "IsDoubleVertex");
	bool retval = false;
	int count = 0;

	for (auto value : vertices[u]) {
		if (value.second == DOUBLE) {
			count += 1;
			retval = (2 <= count);
			if (retval) {
				break;
			}
		}
	}

	return retval;
}

/**
 エッジタイプ取得
 
 エッジu-vのエッジタイプ{DOUBLE,SINGLE}を返す。エッジが見つからない場合、DELETEDを返す。頂点uが存在しない場合の動作は未定義。
 
 @param[in] u 始点頂点
 @param[in] v 宛先頂点

 @return エッジタイプ
 @retval DELETED = 0
 @retval SINGLE = 1
 @retval DOUBLE = 2
 */
int Graph::EdgeType(int u, int v) const
{
	LOGV(LOG_TAG, "EdgeType");
	int ret = DELETED;

	auto it = find(u, v);
	if (it != end(u)) {
		ret = it->second;
	}

	return ret;
}

/**
 エッジ追加
 
 wの重みを持った頂点u-v間のエッジを追加する。まだ頂点uを持っていなければ自動的に追加する。

 @param[in] u 始点頂点
 @param[in] v 宛先頂点
 @param[in] w 頂点vの重み
 @return val : void
 */
void Graph::AddEdge(int u, int v, int w)
{
	LOGV(LOG_TAG, "AddEdge");

	if ((int)vertices.size() <= u) {
		LOGV(LOG_TAG, "add new list [%d]", u);
		vertices.resize(u + 1);
	}
	vertices[u].emplace_back(v, w);
}


/**
 エッジ削除

 頂点uが持つ隣接頂点vへのエッジを削除する。
 - std::List なので削除しても他の要素への参照やiteratorは無効にならない。

 @param[in] u 始点頂点
 @param[in] v 宛先頂点
 */
void Graph::RemoveEdge(int u, int v)
{
	LOGV(LOG_TAG, "RemoveEdge(v,u)");

	vertices[u].remove_if([v](VertexList::value_type& value) { return (value.first == v); });
}

/**
 頂点削除

 グラフから頂点を削除する。すなわち、指定頂点を参照するエッジを全て削除する。

 @param[in] u 削除する頂点
 */
void Graph::RemoveVertex(int u) {
	LOGV(LOG_TAG, "RemoveVertex");

	// Uをクリア
	vertices[u].clear();
	// 全体からUの参照元を削除
	for (auto& vlist : vertices) {
		vlist.remove_if([u](IntegerPair& value) {return (value.first == u);});
	}
}

/**
 エッジ検索
 
 頂点uが持つ頂点vへのエッジを検索する。
	- 頂点uが無い場合はout_of_range例外を投げる。
	- エッジが見つからない場合はend(u)を返す。
 
 @param[in] u 始点頂点
 @param[in] v 宛先頂点
 
 return u-vへのエッジを指すイテレータ
 */
Graph::VertexList::const_iterator Graph::find(int u, int v) const {
	if (!hasVertex(u)) {
		throw out_of_range("PP-E-999");
	}
	
	return find_if(begin(u), end(u),
				   [v](const VertexList::value_type& value) { return (value.first == v); });
}

/*
 This function is shortest path algorithm that uses Bellman Ford algorithm.
 @param :
 int s: start vertex
 vector<int> &dist: distance matrix
 vector<int> &pred: returned path
 @return val : void
 */
void Graph::SingleSourceShortestBF(int s, vector<int> &dist, vector<int> &pred) const {
	LOGV(LOG_TAG, "SingleSourceShortestBF");

	int n = NumVertices();
	pred.assign(n, -1);
	dist.assign(n, 99999);
	dist[s] = 0;

	for (int i = 1; i <= n; i++) {
		bool failOnUpdate = (i == n);
		bool leaveEarly = true;

		for (int u = 0; u < n; u++) {
			for (auto ci = begin(u); ci != end(u); ++ci) {
				int v = ci->first;
				int newLen = dist[u];
				newLen += ci->second;
				if (newLen < dist[v]) {
					if (failOnUpdate) {
						cout << "Graph has negative cycle";
					}
					dist[v] = newLen;
					pred[v] = u;
					leaveEarly = false;
				}
			}
		}
		if (leaveEarly) {
			break;
		}
	}
}

/*
 This function construct the shortest path from node s to node t,once
 shortest path algorithms like SingleSourceShortestBF and
 SingleSourceShortest have populated the pred variable.The shortest path
 is returned in path variable.
 @param :
 int s: start vertex
 int t: end vertex
 vector <int> &pred: pred path array
 list<int> &path: returned path
 @return val : void
 */
void Graph::ConstructShortestPath(int s, int t, vector<int> &pred, list<int> &path) const {
	LOGV(LOG_TAG, "ConstructShortestPath");

	path.clear();
	if (t < 0 || t >= (int)pred.size() || s < 0 || s >= (int)pred.size()) {
		return;
	}

	path.push_front(t);
	while (t != s) {
		t = pred[t];
		if (t == -1) {
			path.clear();
			return;
		}
		path.push_front(t);
	}

}

}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] CREATION OF GRAPH AND SHORTEST PATH ALGORITHM                  */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company                :            xxxx xxxxxxxxxxxx xxxx xxxxxxxxx     */
/* Client                 :            YANMAR Co. Ltd, JAPAN                */
/* Author                 :            MANUJ SHARMA,SACHIN BHISIKAR         */
/*                                     ( YANMAR PathPlanning Team )         */
/* Version                :            1.1                                  */
/*                                                                          */
/* The purpose of the graph data class is to provide auxiliary              */
/* functionality to other classes. The graph class is used by other classes */
/* for creating adjacency graphs and calculating graph functionalities like */
/* shortest path algorithms.                                                */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140124                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/*                                                                          */
/****************************************************************************/
#pragma once

#include "PathPlanIF.hpp"

#include <iostream>
#include <list>
#include <vector>
#include <queue>
#include <string>
#include <fstream>
#include <sstream>
#include <math.h>
#include "PolyLib/Common.h"

namespace yanmar { namespace PathPlan {
/*
 adjacency data structure.It contains the adjacency edge information in the
 form of a adjacent vertices with a weight value
 which is defined by Vtype
 */

/**
 頂点グラフクラス
 
 頂点グラフを管理し、経路探索を行う。
	- ある頂点の隣接する頂点へのリスト頂点インデックスで管理する。
	  つまり構造はネットリストでありリンクリストではない。
	- 例えば vertices[u] は頂点インデックスuに隣接する頂点のリスト。リストの要素は頂点インデックスvと属性。
 */
class Graph {
public:
	/// 頂点の上限
	// - Graphクラス自体に上限はない
	static constexpr int NO_OF_VERTICES = 2050;
	
	/**
	 グラフ頂点データクラス
	 
	 隣接頂点インデックスと重みのペア
	 */
	using IntegerPair = std::pair<int, int>;
	/// 隣接頂点のリスト
	using VertexList = std::list<IntegerPair>;
	/// 隣接頂点リストのリスト
	std::vector<VertexList> vertices;

	// VTypes
	// - ノード間エッジのタイプ
	static constexpr int DELETED = 0;
	static constexpr int SINGLE = 1;
	static constexpr int DOUBLE = 2;

	/*Default constructor*/
	Graph();
	/*copy constructor*/
	Graph(const Graph& graph) = default;
	/*Destructor*/
	~Graph() = default;
	/*This function returns the number of vertices.*/
	int NumVertices() const;
	bool hasVertex(int u) const {
		return (u < NumVertices());
	}
	/*Finds the connection between vertex numbers*/
	bool IsEdge(int u, int v) const;
	/*Finds the connection between vertex numbers*/
	bool IsEdge(int u, int v, int w) const;
	/*Returns EdgeWeight*/
	int EdgeWeight(int u, int v) const;
	/* Checks vertex is having more than two double edges.*/
	bool IsDoubleVertex(int u) const;
	/*Returns EdgeType*/
	int EdgeType(int u, int v) const;
	/*Add New Edge*/
	void AddEdge(int u, int v, int w);
	/*Remove Edge*/
	void RemoveEdge(int u, int v);
	/*Remove vertex*/
	void RemoveVertex(int u);

	// get iterators
	VertexList::iterator begin(int u) {
		return vertices[u].begin();
	}
	
	VertexList::const_iterator begin(int u) const {
		return cbegin(u);
	}
	
	VertexList::const_iterator cbegin(int u) const {
		return vertices[u].cbegin();
	}
	
	VertexList::reverse_iterator rbegin(int u) {
		return vertices[u].rbegin();
	}
	
	VertexList::const_reverse_iterator rbegin(int u) const {
		return vertices[u].crbegin();
	}
	
	VertexList::const_reverse_iterator crbegin(int u) const {
		return vertices[u].crbegin();
	}
	
	VertexList::iterator end(int u) {
		return vertices[u].end();
	}
	
	VertexList::const_iterator end(int u) const {
		return cend(u);
	}
	
	VertexList::const_iterator cend(int u) const {
		return vertices[u].cend();
	}
	
	VertexList::reverse_iterator rend(int u) {
		return vertices[u].rend();
	}

	VertexList::const_reverse_iterator rend(int u) const {
		return vertices[u].crend();
	}
	
	VertexList::const_reverse_iterator crend(int u) const {
		return vertices[u].crend();
	}
	
	void remove(int index, const VertexList::value_type& value) {
		vertices[index].remove(value);
	}

	VertexList::const_iterator find(int u, int v) const;
	
	/*shortest path algorithm that uses Bellman Ford algorithm*/
	void SingleSourceShortestBF(int s, std::vector<int> &dist, std::vector<int> &pred) const;
	/*Shortest path algorithms*/
	void ConstructShortestPath(int s, int t, std::vector<int> &pred, std::list<int> &path) const;
};
}} // namespace yanmar::PathPlan

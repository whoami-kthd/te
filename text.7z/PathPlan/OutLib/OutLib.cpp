// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] CREATION  OF NAVIGATION PATH ALGORITHM                         */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company      :      xxxx xxxxxxxxxxxx xxxx xxxxxxxxx                     */
/* Client       :      YANMAR Co. Ltd, JAPAN                                */
/* Author       :      MANUJ SHARMA,SACHIN BHISIKAR                         */
/*                     (YANMAR PathPlanning Team )                          */
/* Version      :      1.1                                                  */
/* The purpose of out lib class is to plan which region has to be traversed */
/* first.Also it plans a path in each region. This functionality is also    */
/* responsible for generating a full navigation graph and path planning on  */
/* this navigation graph. It generates the type of pattern like skipped     */
/* pattern, adjacent pattern in the region. This functionality is also      */
/* responsible for creating a path through headland area connecting two     */
/* regions and creating a dummy ride if there is any need for this.         */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140124                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/*                                                                          */
/****************************************************************************/
//#define DEBUG_LOG
#define LOG_TAG "PathPlan:OutLib"

#include "PolyLib/Common.h"
#include "OutLib.h"

#include <map>

namespace yanmar { namespace PathPlan {

/** 長さ(距離) */
inline double length(const Point2D &p1, const Point2D &p2) {
	double x = p2.x - p1.x;
	double y = p2.y - p1.y;
	return hypot(x, y);
}

/*Constructor of the class
 @param:No Parameters
 @return val:No return value
 */
OutField::OutField() :
	ploughDirection(0)
{
	outQ = new OutQueue[NO_OF_POINTS];
	OutPolyN = 0;
	bVertexLen = 0;
	outNodePath = NULL;
	OutVertexList StartEndPoints;
}

// コピーコンストラクタ
OutField::OutField(const OutField &obj) {
	OutPolyN = obj.OutPolyN;
	bVertexLen = obj.bVertexLen;
	gtemp = obj.gtemp;
	outNodePath = obj.outNodePath;

	outQ = new OutQueue[OutPolyN];

	for (int j = 0; j < OutPolyN; j++) {
		outQ[j].assign(obj.outQ[j].begin(), obj.outQ[j].end());
	}
}

OutField::~OutField() {
	delete[] outQ;
	delete[] outNodePath;
}

void OutField::copyVertices(const OutVertexList& FVert, OutVertexList& HVert) {
	outFieldVertices.assign(FVert.begin(), FVert.end());
	headLineVertices.assign(HVert.begin(), HVert.end());
}

void OutField::processRegionSequence() {
	/* Remove the zero size list */
	processQueue();
}

// 作業パスの頂点を処理する
// outNodePathに作業パスの頂点を追加する
// outNodePathは作業領域ごとに分かれるため、各作業領域に作業パスを振り分けるイメージになっている
// このため、作業パスの両端が、同じ作業領域に接続されている場合にしか追加してくれない
// 作業領域と非作業領域に接続される作業パスはスキップされてしまう
void OutField::distributeSweepVertices(int OrigFieldVerLen) {

	// 圃場+障害物の頂点数 = 作業領域+非作業領域の頂点数
	bVertexLen = OrigFieldVerLen;

	// Create node path list with a size equal to the number of adjacency graph nodes.
	// OutNodeList consists of array of four outEdges.
	// First one consists the type of the turn, start position SP or end position EP.
	// The rest of three consists the intersection(x,y) of the path with the boundary line.
	// The rest two consists the coordinates of the segment with which it is intersecting

	outNodePath = new OutNodeList[OutPolyN + 1];

	// 作業パスの本数分ループ
	for (int i = 0; i < sweepVertices.size() / 2; ++i) {
		// 始点と終点のインデックスと座標
		int i1 = i * 2;
		int i2 = i * 2 + 1;
		Point2D p1 = sweepVertices[i1];
		Point2D p2 = sweepVertices[i2];

		Point2D p1_1, p1_2;
		bool flag1 = false;
		for (int j = 0; j < OutPolyN && !flag1; ++j) {
			// ポリゴンjを探索して、p1が乗っている辺を探索
			for (int k = 0; k < outQ[j].size(); ++k) {
				int jk1 = outQ[j][k].first;
				int jk2 = outQ[j][k].second;
				p1_1 = outFieldVertices[jk1];
				p1_2 = outFieldVertices[jk2];
				double d = fabs(length(p1, p1_1) + length(p1, p1_2) - length(p1_1, p1_2));
				if (d < TOLERANCE) {
					// p1がp1_1とp1_2の間にある場合
					flag1 = true;
					break;
				}
			}
		}
		Point2D p2_1, p2_2;
		bool flag2 = false;
		for (int j = 0; j < OutPolyN && !flag2; ++j) {
			// ポリゴンjを探索して、p2が乗っている辺を探索
			for (int k = 0; k < outQ[j].size(); ++k) {
				int jk1 = outQ[j][k].first;
				int jk2 = outQ[j][k].second;
				p2_1 = outFieldVertices[jk1];
				p2_2 = outFieldVertices[jk2];
				double d = fabs(length(p2, p2_1) + length(p2, p2_2) - length(p2_1, p2_2));
				if (d < TOLERANCE) {
					// p2がp2_1とp2_2の間にある場合
					flag2 = true;
					break;
				}
			}
		}

        if (!flag1) {
            for (int j = 0; j < headLineVertices.size(); ++j) {
                if (headLineVertices[j] == p1) {
                    int count = 0;
                    for (auto itr = gtemp.begin(j); itr != gtemp.end(j); ++itr) {
                        ++count;
                    }
                    if (count != 2) {
                        throw runtime_error(ErrorCode::FATAL);
                    }
                    auto itr = gtemp.begin(j);
                    p1_1 = headLineVertices[itr->first];
                    ++itr;
                    p1_2 = headLineVertices[itr->first];
                    flag1 = true;
                    break;
                }
            }
        }
        if (!flag2) {
            for (int j = 0; j < headLineVertices.size(); ++j) {
                if (headLineVertices[j] == p2) {
                    int count = 0;
                    for (auto itr = gtemp.begin(j); itr != gtemp.end(j); ++itr) {
                        ++count;
                    }
                    if (count != 2) {
                        throw runtime_error(ErrorCode::FATAL);
                    }
                    auto itr = gtemp.begin(j);
                    p2_1 = headLineVertices[itr->first];
                    ++itr;
                    p2_2 = headLineVertices[itr->first];
                    flag2 = true;
                    break;
                }
            }
        }

		if (flag1 && flag2) {
			tData td1;
			td1.setIndex(OrigFieldVerLen + i1); // NavFieldVertexのインデックス
			td1.pathAttr = PathAttr::RideType::WORKING; // フィールドパス(作業パス)
			td1.point() = p1.toFloat();
			td1.pointEdge1() = p1_1.toFloat();
			td1.pointEdge2() = p1_2.toFloat();
			outNodePath[0].push_back(td1);
			tData td2;
			td2.setIndex(OrigFieldVerLen + i2); // NavFieldVertexのインデックス
            td1.pathAttr = PathAttr::RideType::WORKING; // フィールドパス(作業パス)
			td2.point() = p2.toFloat();
			td2.pointEdge1()  = p2_1.toFloat();
			td2.pointEdge2()  = p2_2.toFloat();
			outNodePath[0].push_back(td2);
		}
	}
}

void OutField::setWorkingOrders(const std::vector<WorkingOrder> &workingOrders) {
	_workingOrders.assign(workingOrders.begin(), workingOrders.end());
}

// たぶんココがメイン
// PathDataに渡すためのデータfinalNodePathを生成してる
// pattern:
//   UNIDIRECTION
//   BIDIRECTION
// numSkipPath:
void OutField::createSkippedPath(int pattern, int numSkipPath, int numSkipNoFish, bool canBackward, int progressType, int rotation)
{
	// 作業パスの頂点(2個で1セット)が全て入っている(第1ソートキー:x座標の昇順、第2ソートキー:y座標の昇順)
	// 左端から右方向(作業進捗方向)に、各作業ライン内では下から上の方向に並んでいる(プラウで作業機が右の場合、そのまま使える順番)
	OutNodeList swapList;
	swapList.assign(outNodePath[0].begin(), outNodePath[0].end());

	if (!canBackward) {
		// バック不可の場合、フィッシュテールターンしないスキップ数を採用
        numSkipPath = std::max(numSkipPath, numSkipNoFish);
	}
	vortexPattern = false;
	if (pattern == yanmar::PathPlan::Param::Work::Pattern::UNIDIRECTION) {
		// 単方向(プラウ)
		createPloughPatternPath(swapList, numSkipNoFish, canBackward);
	} else if (pattern == yanmar::PathPlan::Param::Work::Pattern::CYCLONE || pattern == yanmar::PathPlan::Param::Work::Pattern::SEMICYCLONE ||
			   pattern == yanmar::PathPlan::Param::Work::Pattern::ANTICYCLONE || pattern == yanmar::PathPlan::Param::Work::Pattern::SEMIANTICYCLONE) {
		// 渦巻き(草刈機)
		vortexPattern = true;
		if (progressType == yanmar::PathPlan::Param::Work::ProgressType::BLOCK) {
			// ブロック単位の場合、FieldPolygonの指示通りにパスを接続
			createFieldPolygonPath(swapList, canBackward);
		} else {
			createVortexPatternPath(swapList);
		}
		if (rotation == yanmar::PathPlan::Param::Work::Pattern::Rotation::CLOCKWISE) {
			// 時計回りの場合、1本目は左端の作業ラインを上向きに走る
			workStartIndex = swapList.begin()->getIndex();
		} else {
			// 反時計回りの場合、1本目は左端の作業ラインを下向きに走る
			auto itr = swapList.begin();
			const double x = itr->point().x;
			++itr;
			while (itr != swapList.end()) {
				if (itr->point().x != x) break;
				workStartIndex = itr->getIndex();
				++itr;
			}
		}
		// 作業ラインが変わるごとに、作業方向の上下を反転(作業ライン内の頂点の並びを反転)させる
		joinPathNodes(swapList);
	} else if (numSkipPath > 0) {
		// スキップ数が1以上の場合
		createChunkedPatternPath(swapList, numSkipPath, progressType);
		// 作業ラインが変わるごとに、作業方向の上下を反転(作業ライン内の頂点の並びを反転)させる
		joinPathNodes(swapList);
	} else {
		// 無人機単独、有人機が中央追走の場合
		// 作業ラインが変わるごとに、作業方向の上下を反転(作業ライン内の頂点の並びを反転)させる
		joinPathNodes(swapList);
	}

	outNodePath[0].assign(swapList.begin(), swapList.end());

	// 自動運転の開始位置から作業開始地点へのナビゲーションパス
	OutNodeList startPointPath;
	processStartPosition(swapList, startPointPath);

	// 最後の作業パスの後側の点と作業終了位置が異なる場合、ダミーライドを生成
	// 作業終了位置から自動運転の終了位置へのナビゲーションパス
	OutNodeList endPointPath;
	processEndPosition(swapList, endPointPath);

	// 作業パスと作業パスの間に、作業パス間をつなぐためのデータを挿入
	processHeadLandPath(swapList);

	finalNodePath.insert(finalNodePath.end(), startPointPath.begin(), startPointPath.end());
	finalNodePath.insert(finalNodePath.end(), swapList.begin(), swapList.end());
	finalNodePath.insert(finalNodePath.end(), endPointPath.begin(), endPointPath.end());

	// 与えられた作業パスに対して、作業機の幅一杯まで塗り潰せるように、作業パスの端点をずらす
	shiftWorkingPath();
	debugPrint();
}
void OutField::createPathAB()
{
	// ABパス生成
	// sweepVerticesからfinalNodePathを生成
	for (int i = 0; i < sweepVertices.size() / 2; ++i) {
		// 始点と終点のインデックスと座標
		int i1 = i * 2;
		int i2 = i * 2 + 1;
		Point2D p1 = sweepVertices[i1];
		Point2D p2 = sweepVertices[i2];

		tData td1;
		td1.pathAttr = PathAttr::RideType::WORKING;
		td1.nodeType = tData::NodeType::PATHNODE_1;
		td1.point() = p1.toFloat();
		finalNodePath.push_back(td1);

		tData td2;
		td2.pathAttr = PathAttr::RideType::WORKING;
		td2.nodeType = tData::NodeType::PATHNODE_2;
		td2.point() = p2.toFloat();
		finalNodePath.push_back(td2);
	}
}

/*
 This function checks if any headland vertex lies in
 between two sweep vertices.If yes, it inserts that vertex
 @param:
 OutNodeList& swapList : list of sweep vertices
 @return val: void
 */
void OutField::processHeadLandPath(OutNodeList& swapList) {
	/*
	 Process path if it has to pass through further headland area
	 If so add those nodes to pre-existing path.Note after this no more
	 preprocessing on swapList as even-odd structure is disturbed here
	 */
	// 作業パスの前側
	auto next1st = swapList.begin();
	auto prev1st = next1st;
	// 作業パスの後側
	++next1st;
	while (next1st != swapList.end()) {
		// 1個前の作業パスの後側
		auto prev2nd = next1st;
		// 次の作業パスの前側
		++next1st;
		if (next1st == swapList.end()) {
			break;
		}
		// 1個前の作業パスの後側の頂点のインデックス値と次の作業パスの前側の頂点のインデックス値を渡して
		// その間をつなぐナビゲーションパス用の頂点のインデックスを追加した、インデックス値のリストを返してもらう
		// 時計回りと反時計回りの二通りを探索 (走行距離の短い方がregionTraversalPath1となる)
		list<int> regionTraversalPath1;
		list<int> regionTraversalPath2;
		connectNode2Way(prev2nd->getIndex(), next1st->getIndex(), regionTraversalPath1, regionTraversalPath2);
		if (vortexPattern) {
			const Point2D p1 = headLineVertices[prev1st->getIndex()];
			const Point2D p2 = headLineVertices[prev2nd->getIndex()];
			const Point2D p3 = headLineVertices[*(++regionTraversalPath1.begin())];
			const Point2D n1 = headLineVertices[next1st->getIndex()];
			if (n1.x != p1.x) {
				PolygonUtil::Segment s1 = PolygonUtil::Segment(p1, p2);
				PolygonUtil::Segment s2 = PolygonUtil::Segment(p2, p3);
				if (PolygonUtil::normalizeRadian(s2.angle() - s1.angle()) > 0) {
					regionTraversalPath1.swap(regionTraversalPath2);
				}
			}
		} else if (createDummyRide) {
			if (checkRunSideMargin(regionTraversalPath1)) {
				if (checkRunSideMargin(regionTraversalPath2)) {
					throw runtime_error(ErrorCode::NodeConnection::SIDE_MARGIN);
					// TODO:ダミーライドの生成を検討
				}
				regionTraversalPath1.swap(regionTraversalPath2);
			}
		}

		if (regionTraversalPath1.size() > 2) {
			// 間に頂点が追加されている場合
			// 最初の要素(1個前の作業パスの後側の頂点のインデックス値)を削除
			// 最後の要素(次の作業パスの前側の頂点のインデックス値)を削除
			regionTraversalPath1.remove(next1st->getIndex());
			regionTraversalPath1.remove(prev2nd->getIndex());

			for (auto itr = regionTraversalPath1.begin(); itr != regionTraversalPath1.end(); ++itr) {
				tData t;
				t.setIndex(*itr);
				t.pathAttr = PathAttr::RideType::NON_WORKING; // ヘッドランドナビゲーション
				t.point() = headLineVertices[t.getIndex()];
				swapList.insert(next1st, t);
			}
		}
		prev1st = next1st;
		++next1st;
	}
}

/*
 This function generates the shortest path from given
 start & end vertices
 @param:
 int s : start vertex
 int d : end vertex
 @return val: void
 */
void OutField::processSingleSource(int s, int d, list<int> &regionTraversalPath) {
	vector<int> dist;
	vector<int> pred;

	regionTraversalPath.clear();
	/*gtemp.SingleSourceShortest(s,dist,pred);*/
	/*changes for Inter-region graph*/

	gtemp.SingleSourceShortestBF(s, dist, pred);
	gtemp.ConstructShortestPath(s, d, pred, regionTraversalPath);
}

/*
 This function Merge the existing data with the given vector values.
 @param: None
 @return val: void
 */
void OutField::addQueue(std::vector<OutPair> newQ, Graph& g1) {
	vector<OutPair> lowerPoly1, UpperPoly1;
	vector<OutPair> lowerPoly2, UpperPoly2;
	/*
	 very first polygon just copy
	 */
	if (OutPolyN == 0) {
		outQ[0] = newQ;
		OutPolyN++;
		return;
	}

	// TODO: 以下のコードは使用されない可能性あり
	int rflag = 1;
	int i = 0, j = 0, k = 0;
	for (; i < newQ.size(); i++) {
		for (; j < OutPolyN; j++) {
			for (; k < outQ[j].size(); k++) {
				if ((outQ[j][k].first == newQ[i].second) && (outQ[j][k].second == newQ[i].first)) {

					LOGV(LOG_TAG, "g1 first:%d,  g1 second:%d", g1.IsDoubleVertex(newQ[i].first), g1.IsDoubleVertex(newQ[i].second));

					if (g1.IsDoubleVertex(newQ[i].first) || g1.IsDoubleVertex(newQ[i].second)) {
						continue;
					} else {
						rflag = 0;
						goto out;
					}
				}
			}
		}
	}

	/*
	 didn't find anything,add the vector list to existing list
	 and return without merging
	 */
	out:
	if (rflag) {
		outQ[OutPolyN] = newQ;
		OutPolyN++;
		return;
	} else {
		//else merge
		//remove found edge from the vector

		UpperPoly1.insert(UpperPoly1.end(), newQ.begin(), newQ.begin() + i);
		lowerPoly1.insert(lowerPoly1.end(), newQ.begin() + i, newQ.end());

		if (!lowerPoly1.empty())
			lowerPoly1.erase(lowerPoly1.begin());

		UpperPoly2.insert(UpperPoly2.end(), outQ[j].begin(), outQ[j].begin() + k);
		lowerPoly2.insert(lowerPoly2.end(), outQ[j].begin() + k, outQ[j].end());

		if (!lowerPoly2.empty())
			lowerPoly2.erase(lowerPoly2.begin());

		lowerPoly1.insert(lowerPoly1.end(), UpperPoly1.begin(), UpperPoly1.end());
		UpperPoly2.insert(UpperPoly2.end(), lowerPoly1.begin(), lowerPoly1.end());
		UpperPoly2.insert(UpperPoly2.end(), lowerPoly2.begin(), lowerPoly2.end());
		outQ[j] = UpperPoly2;
	}
}

/*
 This function process the outQ and removes the zero size outQ
 @param: None
 @return val: void
 */
void OutField::processQueue() {
	OutQueue *tempQ = new OutQueue[OutPolyN];
	int newIndex = 0;
	for (int j = 0; j < OutPolyN; j++) {
		if (!outQ[j].empty()) {
			tempQ[newIndex++] = outQ[j];
		}
	}

	if (OutPolyN != newIndex) {
		OutPolyN = newIndex; /* new count of poly regions*/

		for (int j = 0; j < OutPolyN; j++) {
			outQ[j] = tempQ[j];
		}
	}
	delete[] tempQ;
}



/**
 * スキップパターン生成(1ブロック)
 *
 * 指定イテレータから1ブロックをスキップパターンに並べ替える。
 *
 * @param[in, out] itBlock ソート対象ブロックを指すiterator
 * @param[in] end iteratorのend
 * @param[in] blockSize 処理するブロックサイズ
 * @param[in] skip スキップ数
 * @return BlockSize分進んだiterator
 */
OutNodeList::iterator reorderInBlock(OutNodeList::iterator itBlock, OutNodeList::iterator end, int blockSize, int skip) {
	const int step = skip + 1;
	vector<vector<OutNodeList::value_type>> tmpList2(step);
	auto itr = itBlock;
	for (int i = 0; i < blockSize; ++i) {
		double x = itr->point().x;
		while (itr != end && itr->point().x == x) {
			tmpList2[i % step].push_back(*itr);
			++itr;
		}
	}
	vector<OutNodeList::value_type> tmpList = tmpList2[0];
	for (int i = skip; i > 0; --i) {
		tmpList.insert(tmpList.end(), tmpList2[i].begin(), tmpList2[i].end());
	}
	for (auto tmp : tmpList) {
		*itBlock = tmp;
		++itBlock;
	}
	return itBlock;
}

/**
 * ブロック単位のスキップパターン生成
 *
 * 作業パスのリストをスキップ数に応じたブロック単位のパターンに並べ替える。
 * - 作業パスがブロックサイズ未満の場合は何もしない。
 * - 作業パス総数がブロックサイズで割り切れない場合、末尾ブロックはブロック数を拡大して処理する。
 *
 * @param[in, out] psthList 対象のパスリスト(要素は偶数でなければならない)
 * @param[in] skiplen スキップ数。非対応のスキップ数では何もしない。
 */
void OutField::createChunkedPatternPath(OutNodeList& pathList, int skip, int progressType) {

	if (skip < 1) {
		// スキップ数が0(以下)の場合は処理しない
		return;
	}

	// ブロック数の計算
	int blockSize = skip * 2 + 3;

	// 作業パスのライン数
	int lineCount = 0;
	auto itr = pathList.begin();
	while (itr != pathList.end()) {
		++lineCount;
		double x = itr->point().x;
		int vertexCount = 0;
		while (itr != pathList.end() && itr->point().x == x) {
			++vertexCount;
			++itr;
		}
		if (vertexCount % 2 != 0) {
			// 垂直でないセグメントがある、または頂点数が偶数個ではない
			return;
		}
	}

	if (lineCount < blockSize) {
		// 作業パスのライン数がブロックサイズ未満の場合
		// スキップ数を維持できる最初の1本か2本だけ作業する
		const int step = skip + 1;
		vector<vector<OutNodeList::value_type>> tmpList(step);
		auto itr = pathList.begin();
		for (int i = 0; itr != pathList.end(); ++i) {
			double x = itr->point().x;
			while (itr != pathList.end() && itr->point().x == x) {
				tmpList[i % step].push_back(*itr);
				++itr;
			}
		}
		pathList.clear();
		for (int i = 0; i < tmpList[0].size(); ++i) {
			pathList.push_back(tmpList[0][i]);
		}
		return;
	}

	if (progressType == yanmar::PathPlan::Param::Work::ProgressType::NORMAL) {
		// ブロック単位の処理をしない場合
		blockSize = lineCount;
	}

	// reorder whole list
	auto itBlock = pathList.begin();
	while (itBlock != pathList.end()) {
		lineCount -= blockSize;
		if (lineCount < blockSize) {
			// 端数は直前のブロックに含めて処理する
			blockSize += lineCount;
			lineCount = 0;
		}
		itBlock = reorderInBlock(itBlock, pathList.end(), blockSize, skip);
	}
}

void OutField::createVortexPatternPath(OutNodeList& pathList) {
    vector<vector<OutNodeList::value_type>> tmpList2;
    auto itr = pathList.begin();
    while (itr != pathList.end()) {
        const double x = itr->point().x;
        vector<OutNodeList::value_type> tmpList;
        int vertexCount = 0;
        while (itr != pathList.end() && itr->point().x == x) {
            tmpList.push_back(*itr);
            ++vertexCount;
            ++itr;
        }
        if (vertexCount % 2 != 0) {
            // 垂直でないセグメントがある、または頂点数が偶数個ではない
            // TODO:
            return;
        }
        tmpList2.push_back(tmpList);
    }
    int index0 = 0;
    int index1 = (int)tmpList2.size() - 1;
    pathList.clear();
    while (index0 < vortexCount) {
        vector<OutNodeList::value_type> tmpList3 = tmpList2[index0];
        pathList.insert(pathList.end(), tmpList3.begin(), tmpList3.end());
        ++index0;
        if (index0 > index1) {
            return;
        }
        vector<OutNodeList::value_type> tmpList4 = tmpList2[index1];
        pathList.insert(pathList.end(), tmpList4.begin(), tmpList4.end());
        --index1;
        if (index0 > index1) {
            return;
        }
    }
    int indexD = index1 + 1;
    while (index0 <= index1) {
        vector<OutNodeList::value_type> tmpList5 = tmpList2[index0];
        pathList.insert(pathList.end(), tmpList5.begin(), tmpList5.end());
        ++index0;
        if (index0 > index1) {
            // 最後の作業パスはペアになるダミーライドがないのでココで抜ける
            break;
        }
        // ダミーライドの追加
        ++indexD;
        if (indexD >= tmpList2.size()) {
            break;
        }
        vector<OutNodeList::value_type> tmpList6 = tmpList2[indexD];
        for (auto itr = tmpList6.begin(); itr != tmpList6.end(); ++itr) {
            itr->pathAttr = PathAttr::RideType::DUMMY;
        }
        pathList.insert(pathList.end(), tmpList6.begin(), tmpList6.end());
    }
}

void OutField::createFieldPolygonPath(OutNodeList& pathList, bool canBackward) {
    vector<vector<OutNodeList::value_type>> tmpList2;
    auto itr = pathList.begin();
    while (itr != pathList.end()) {
        const double x = itr->point().x;
        vector<OutNodeList::value_type> tmpList;
        int vertexCount = 0;
        while (itr != pathList.end() && itr->point().x == x) {
            tmpList.push_back(*itr);
            ++vertexCount;
            ++itr;
        }
        if (vertexCount % 2 != 0) {
            // 垂直でないセグメントがある、または頂点数が偶数個ではない
            throw runtime_error(ErrorCode::FATAL);
        }
        tmpList2.push_back(tmpList);
    }
    pathList.clear();
    for (auto workingOrder = _workingOrders.begin(); workingOrder != _workingOrders.end(); ++workingOrder) {
        vector<OutNodeList::value_type> tmpList = tmpList2[workingOrder->index];
        if (workingOrder->dummy) {
            for (auto tmp = tmpList.begin(); tmp != tmpList.end(); ++tmp) {
                tmp->pathAttr = PathAttr::RideType::DUMMY;
            }
        }
        pathList.insert(pathList.end(), tmpList.begin(), tmpList.end());
    }
}

/*
 This function joins two sweep vertices and creates a path
 @param:
 OutNodeList& swapList : list of sweep vertices
 @return val: void
 */
void OutField::joinPathNodes(OutNodeList& swapList) {
	// 作業パスの最初の頂点のインデックス値(NavFieldVertex)が作業開始位置のインデックスと一致する場合、1本目は反転しない
	// 作業パスの最初の頂点のインデックス値(NavFieldVertex)が作業開始位置のインデックスと一致しない場合、1本目から反転させる
	bool bSwap = swapList.begin()->getIndex() != workStartIndex;
	auto itr = swapList.begin();

	while (itr != swapList.end()) {
		vector<OutNodeList::value_type> tmpList;
		auto tmp = itr;
		double x = tmp->point().x;
		while (tmp != swapList.end() && tmp->point().x == x) {
			// x座標が同じものをテンポラリにコピー
			tmpList.push_back(*tmp);
			++tmp;
		}
		if (bSwap) {
			// 逆順の場合、テンポラリから逆順にコピーバック
			for (auto tmp = tmpList.rbegin(); tmp != tmpList.rend(); ++tmp) {
				*itr = *tmp;
				++itr;
			}
		} else {
			// 正順の場合、進めたイテレータをコピーバック
			itr = tmp;
		}
		// 1回ごとに方向を入れ替える
		bSwap = !bSwap;
	}

	for (auto itr = swapList.begin(); itr != swapList.end(); ++itr) {
		auto p1 = itr;
		++itr;
		if (itr == swapList.end()) {
			break;
		}
		auto p2 = itr;
		p1->nodeType = tData::NodeType::PATHNODE_1;
		p2->nodeType = tData::NodeType::PATHNODE_2;
	}
}

/**
 * 単方向作業(プラウ耕)用に作業パスを並び替えます。
 * 作業方向は全て同じ方向(上または下)で揃えます。
 * 作業進捗方向、未来側の作業パスをダミーライドで戻ります。
 */
void OutField::createPloughPatternPath(OutNodeList& swapList, int numSkipNoFish, bool canBackward) {
	bool up = (swapList.begin()->getIndex() == workStartIndex);
	std::vector<OutNodeList> lines;
	{
		double prev = swapList.begin()->point().x;
		OutNodeList line;
		for (auto itr = swapList.begin(); itr != swapList.end(); ++itr) {
			if (itr->point().x == prev) {
				line.push_back(*itr);
			} else {
				lines.push_back(line);
				line.clear();
				line.push_back(*itr);
				prev = itr->point().x;
			}
		}
		lines.push_back(line);
	}

	int skip = numSkipNoFish + 2;
	if (skip > lines.size() - 1 && canBackward) {
		skip = (int)lines.size() - 1;
	}
	// バック不可の場合、スキップ数の変更不可

	swapList.clear();
	for (int i = 0; i < lines.size() - 1; ++i) {
		OutNodeList line = lines[i];
		if (up) {
			swapList.insert(swapList.end(), line.begin(), line.end());
		} else {
			swapList.insert(swapList.end(), line.rbegin(), line.rend());
		}
		if (i == lines.size() - 2) {
			// 最後の1本手前の作業パスを作業した時点で終了する
			// 最後の1本手前の作業パスの後にはダミーライドを追加しない
			// 最後の作業パスは作業しないっぽい
			break;
		}
		if (i + skip > lines.size() - 1) {
			if (!canBackward) {
				// バック不可の場合、スキップが維持できなくなった時点で終了
				break;
			}
			--skip;
		}
		OutNodeList dummy = lines[i + skip];
		for (auto itr = dummy.begin(); itr != dummy.end(); ++itr) {
			itr->pathAttr = PathAttr::RideType::DUMMY;
		}
		if (up) {
			swapList.insert(swapList.end(), dummy.rbegin(), dummy.rend());
		} else {
			swapList.insert(swapList.end(), dummy.begin(), dummy.end());
		}
	}
#if 0
// 最後の作業ラインは作業しないっぽい？
	OutNodeList lastLine = lines.back();
	if (up) {
		swapList.insert(swapList.end(), lastLine.begin(), lastLine.end());
	} else {
		swapList.insert(swapList.end(), lastLine.rbegin(), lastLine.rend());
	}
#endif

	for (auto itr = swapList.begin(); itr != swapList.end(); ++itr) {
		auto p1 = itr;
		++itr;
		if (itr == swapList.end()) {
			break;
		}
		auto p2 = itr;
		p1->nodeType = tData::NodeType::PATHNODE_1;
		p2->nodeType = tData::NodeType::PATHNODE_2;
	}
}

// この時点では、GPSユニットが枕地のラインに一致する位置から、GPSユニットが枕地のラインに一致する位置まで、を作業パスとしているが
// 実際は、作業機の前側左右のどちらかが枕地のラインを超えた位置から、作業機の後側左右両端が枕地のラインを超える位置まで、作業しなければならない
// そのため、作業パスの端点をずらす
void OutField::shiftWorkingPath()
{
	for (auto itr = finalNodePath.begin(); itr != finalNodePath.end(); ++itr) {
		// 元の座標を残しておく
		itr->pointOrg() = itr->point();
	}

	// ----------------------------------------------------------------
	// 作業パスの端点を作業機までの長さ分ずらすのは、ガイダンス側がやることになったため、以下の処理は実施しない
	// また必要になることがありそうなので、コードはそのまま残しておく
	return;
	// ----------------------------------------------------------------
/*
	for (auto itr = finalNodePath.begin(); itr != finalNodePath.end(); ++itr) {
		auto p1 = itr;
		auto p2 = itr;
		++p2;
		if (p2 == finalNodePath.end()) {
			return;
		}
		if (p1->pn.first != PATHNODE_1 || p2->pn.first != PATHNODE_2 || p1->v1[0].x != p2->v1[0].x) {
			// p1, p2は作業パスの前後の頂点データではない
			continue;
		}
		// p1, p2は作業パスの前後の頂点データ
		if (p1->e1.first == START_NAVIGATION || p2->e1.first == END_NAVIGATION) {
			// 自動運転の開始位置から作業開始位置までのナビゲーションパス生成用のダミー作業パス、または
			// 作業終了位置から自動運転の終了位置までのナビゲーションパス生成用のダミー作業パスの場合
			// 端点をずらさない(処理なし)
			continue;
		}
		if (p1->e1.first == START_EXTENSION || p2->e1.first == END_EXTENSION) {
			// 作業開始位置(1本目の作業パス)の手前に調整用の空走りを追加するためのダミー作業パス、または
			// 作業終了位置(最後の作業パス)の後ろに回避用の空走りを追加するためのダミー作業パスの場合
			// 座標計算はPathDataでやるので処理なし
			// というか、もう片方の頂点が、1本目の作業パスの前側の頂点(START_EXTENSIONの場合のp2)や
			// 最後の作業パスの後側の頂点(END_EXTENSIONの場合のp1)なので、変更不可
			continue;
		}

		// 作業パスが上向き(1.0)か下向き(-1.0)か
		double dir = (p2->v1[0].y - p1->v1[0].y) > 0.0 ? 1.0 : -1.0;

		// 枕地のラインがx軸と為す角度
		double angle1 = fabs(atan2(p1->v1[2].y - p1->v1[1].y, p1->v1[2].x - p1->v1[1].x));
		double angle2 = fabs(atan2(p2->v1[2].y - p2->v1[1].y, p2->v1[2].x - p2->v1[1].x));

		// 前後とも、_gps2ImplementEndの分だけ行き過ぎてから作業を開始/終了する
		// 前側は、_cultivationWidth*fabs(tan(angle1))*0.5だけ手前から作業を開始する
		// 後側は、_cultivationWidth*fabs(tan(angle2))*0.5だけ行き過ぎてから作業を終了する
		p1->v1[0].y += (_gps2ImplementEnd + _implementLength * 0.5 - fabs(tan(angle1)) * _cultivationWidth * 0.5) * dir;
		p2->v1[0].y += (_gps2ImplementEnd + _implementLength * 0.5 + fabs(tan(angle2)) * _cultivationWidth * 0.5) * dir;
	}
*/
}

void OutField::processStartPosition(OutNodeList& swapList, OutNodeList& startPointPath)
{
	startPointPath.clear();
	if (driveStartIndex < 0) {
		// ユーザが指定したスタート位置から作業開始位置までの距離が短い場合
		// 最初の作業パスの手前に空走りを追加するためのダミーデータを生成
		auto p1 = swapList.begin();
		auto p2 = p1;
		++p2;
		tData dummy;
		dummy.setIndex(START_EXTENSION); // このダミーのインデックス値をPathData側でチェックする
		// p1, p2と一直線にならない座標ならなんでも良い
		dummy.point().x = p1->point().x + (p2->point().y - p1->point().y) / length(p1->point(), p2->point());
		dummy.point().y = p1->point().y + (p2->point().x - p1->point().x) / length(p1->point(), p2->point());
		startPointPath.push_back(dummy);
		return;
	}
	// ユーザが指定したスタート位置から最も近いSHP上の点に、ダミーの作業パスノードを生成
	tData t0;
	t0.setIndex(START_NAVIGATION); // このダミーのインデックス値をPathData側でチェックする
	t0.nodeType = tData::NodeType::PATHNODE_1;
	t0.point() = driveStart;
	startPointPath.push_back(t0);
	t0.setIndex(driveStartIndex);
	t0.nodeType = tData::NodeType::PATHNODE_2;
	startPointPath.push_back(t0);
	// ナビゲーションパスが必要か判定
	if (driveStartIndex == workStartIndex) {
		// 自動運転開始位置のインデックスが作業開始位置のインデックスと同じ場合
		return;
	}
	// 自動運転開始位置のインデックスが作業開始位置のインデックスと異なる場合
	// ナビゲーションパス用のデータを生成
	list<int> regionTraversalPath;
	processSingleSource(driveStartIndex, workStartIndex, regionTraversalPath);
	// 末尾は作業開始位置のインデックスなので削除
	regionTraversalPath.pop_back();
	for (auto itr = regionTraversalPath.begin(); itr != regionTraversalPath.end(); ++itr) {
		tData t;
		t.setIndex(*itr);
		t.point() = headLineVertices[t.getIndex()];
		startPointPath.push_back(t);
	}
}

/*
 This function generates the path from the end vertex of
 last cultivation region to the End point
 (Position of Tractor after cultivation)

 @param:
 OutNodeList& swapList : vertices list of region
 int lastEp : last vertex of the region
 OutNodeList& endPointPath : generate path
 @return val:bool false : fail, true : success
 */
// 旧仕様では「サイドマージンを走ってはいけない」というルールがあった
// また、処理済みの作業パスは、エッジがグラフから削除される
// そのため、全ての作業パスが処理されると、上下の枕地領域間を移動できなくなってしまう
// これを回避するため、ダミーライドを生成するという仕様があった
// 新仕様ではサイドマージンを走っても良いので、ダミーライドの仕様は廃止している
void OutField::processEndPosition(OutNodeList& swapList, OutNodeList& endPointPath) {
	endPointPath.clear();
	if (driveEndIndex < 0 || swapList.size() < 3) {
		// エンド位置が指定されていない場合、または
		// 作業パスが1本(頂点が2個)しかない場合
		// 最後の作業パスの後ろに空走りを追加するためのダミーデータを生成して終了
		auto p1 = swapList.rbegin();
		auto p2 = p1;
		++p2;
		tData dummy;
		dummy.setIndex(END_EXTENSION); // このダミーのインデックス値をPathData側でチェックする
		// p1, p2と一直線にならない座標ならなんでも良い
		dummy.point().x = p1->point().x + (p2->point().y - p1->point().y) / length(p1->point(), p2->point());
		dummy.point().y = p1->point().y + (p2->point().x - p1->point().x) / length(p1->point(), p2->point());
		endPointPath.push_back(dummy);
		return;
	}
	// 作業終了位置の頂点インデックス
	int workEndIndex = swapList.rbegin()->getIndex();
	// ナビゲーションパスが必要か判定
	if (workEndIndex == driveEndIndex) {
		// 作業終了位置のインデックスが自動運転終了位置のインデックスと同じ場合
		// ユーザが指定したエンド位置から最も近いSHP上の点に、ダミーの作業パスノードを生成して終了
		processEndPosition_driveEnd(endPointPath);
		return;
	}
	// 作業終了位置のインデックスが自動運転終了位置のインデックスと異なる場合
	// ナビゲーションパス用のデータを生成
	list<int> regionTraversalPath1;
	list<int> regionTraversalPath2;
	// 時計回りと反時計回りの二通りを探索 (走行距離の短い方がregionTraversalPath1となる)
	connectNode2Way(workEndIndex, driveEndIndex, regionTraversalPath1, regionTraversalPath2);
	// ダミーライドフラグの判定
	if (!createDummyRide || vortexPattern) {
		// ダミーライドフラグがfalse(サイドマージン走行OK)の場合
		// 走行距離の短いregionTraversalPath1を採用
		// 先頭は作業終了位置のインデックスなので削除
		regionTraversalPath1.pop_front();
		for (int index : regionTraversalPath1) {
			tData t;
			t.setIndex(index);
			t.pathAttr = PathAttr::RideType::NON_WORKING; // ヘッドランドナビゲーション
			t.point() = headLineVertices[index];
			endPointPath.push_back(t);
		}
		// ユーザが指定したエンド位置から最も近いSHP上の点に、ダミーの作業パスノードを生成して終了
		processEndPosition_driveEnd(endPointPath);
		return;

	}
	// ダミーライドフラグがtrue(サイドマージン走行NG)の場合
	// ダミーライドを(仮)生成
	auto itr = swapList.rbegin();
	double lastLineX = itr->point().x;
	double prevLineX = itr->point().x;
	// 最後の作業ラインをスキップして
	// 1回前の作業ライン(スキップパターンがあるので、1個手前とは限らない)を見つける
	while (itr != swapList.rend()) {
		if (itr->point().x != lastLineX) {
			prevLineX = itr->point().x;
			break;
		}
		++itr;
	}
	if (prevLineX == lastLineX) {
		// 作業ラインが1本しかない場合、ダミーライドの生成が出来ない
		list<int> regionTraversalPath;
		if (!checkRunSideMargin(regionTraversalPath1)) {
			// regionTraversalPath1がサイドマージンを走らない場合
			regionTraversalPath.assign(regionTraversalPath1.begin(), regionTraversalPath1.end());
		} else if (!checkRunSideMargin(regionTraversalPath2)) {
			// regionTraversalPath2はサイドマージンを走らない場合
			regionTraversalPath.assign(regionTraversalPath2.begin(), regionTraversalPath2.end());
		} else {
			// どっち回りでもサイドマージンを走ってしまう場合
			// 短い方のパスを採用して、あとはPathLibに任せる
			regionTraversalPath.assign(regionTraversalPath1.begin(), regionTraversalPath1.end());
		}
		// 先頭は作業終了位置のインデックスなので削除
		regionTraversalPath.pop_front();
		for (int index : regionTraversalPath) {
			tData t;
			t.setIndex(index);
			t.pathAttr = PathAttr::RideType::NON_WORKING; // ヘッドランドナビゲーション
			t.point() = headLineVertices[index];
			endPointPath.push_back(t);
		}
		// ユーザが指定したエンド位置から最も近いSHP上の点に、ダミーの作業パスノードを生成して終了
		processEndPosition_driveEnd(endPointPath);
		return;
	}
	// ダミーライドの対象となる作業ラインのコピーを生成
	OutNodeList dummyRide;
	list<int> regionTraversalPathDR;
	auto itrDR_rbegin = itr;
	while (itr != swapList.rend()) {
		if (itr->point().x != prevLineX) {
			break;
		}
		dummyRide.push_back(*itr);
		regionTraversalPathDR.push_back(itr->getIndex());
		++itr;
	}
	auto itrDR_rend = itr;
	// 新しい作業終了位置
	int newEndIndex = dummyRide.begin()->getIndex();
	if (newEndIndex == driveEndIndex) {
		// 新しい作業終了位置が自動運転の終了位置と合致する場合
		// 元の作業ラインをダミーライドに変更
		for (auto itrDR = itrDR_rbegin; itrDR != itrDR_rend; ++itrDR) {
			itrDR->pathAttr = PathAttr::RideType::DUMMY;
		}
		// コピーしておいた作業ラインを追加
		swapList.insert(swapList.end(), dummyRide.rbegin(), dummyRide.rend());
		// 最後の作業パスの後ろに空走りを追加するためのダミーデータを生成して終了
		processEndPosition_driveEnd(endPointPath);
		return;
	}
	// 新しい作業終了位置が自動運転の終了位置と合致しない場合
	// 新しい作業終了位置から自動運転の終了位置まで移動するためのナビゲーションパスを生成する
	list<int> regionTraversalPath3;
	list<int> regionTraversalPath4;
	// 時計回りと反時計回りの二通りを探索 (走行距離の短い方がregionTraversalPath3となる)
	connectNode2Way(newEndIndex, driveEndIndex, regionTraversalPath3, regionTraversalPath4);
	// 元の作業終了位置から、ダミーライド作業パスの始点までの頂点インデックス
	list<int> regionTraversalPathAdd;
	processSingleSource(workEndIndex, dummyRide.rbegin()->getIndex(), regionTraversalPathAdd);
	// 元の作業終了位置から、ダミーライド作業パスの終点までの走行距離を算出
	double dd = distance(regionTraversalPathAdd) + distance(regionTraversalPathDR);
	// 4種類のナビゲーションパスに対して、それぞれの走行距離を算出
	const double DISTANCE_ERROR = 1000000.0;
	double d1 = DISTANCE_ERROR;
	double d2 = DISTANCE_ERROR;
	double d3 = DISTANCE_ERROR;
	double d4 = DISTANCE_ERROR;
	if (!checkRunSideMargin(regionTraversalPath1)) {
		// regionTraversalPath1がサイドマージンを走らない場合、走行距離を計算
		d1 = distance(regionTraversalPath1);
	}
	if (!checkRunSideMargin(regionTraversalPath2)) {
		// regionTraversalPath2がサイドマージンを走らない場合、走行距離を計算
		d2 = distance(regionTraversalPath2);
	}
	if (!checkRunSideMargin(regionTraversalPath3)) {
		// regionTraversalPath3がサイドマージンを走らない場合、走行距離を計算
		d3 = distance(regionTraversalPath3) + dd;
	}
	if (!checkRunSideMargin(regionTraversalPath4)) {
		// regionTraversalPath4がサイドマージンを走らない場合、走行距離を計算
		d4 = distance(regionTraversalPath4) + dd;
	}
	// サイドマージンを走らない、走行距離の短いパスを選択
	// サイドマージンを走る場合は走行距離がDISTANCE_ERRORとなるため、d1 < d2, d3 < d4は当てにならない
	list<int> regionTraversalPath;
	if (d1 == DISTANCE_ERROR && d2 == DISTANCE_ERROR && d3 == DISTANCE_ERROR && d4 == DISTANCE_ERROR) {
		// 全てのパスでサイドマージンを走ってしまう場合 (ユーザの指定したエンド位置がサイドマージンにある場合など)
		// ダミーライドを生成しない、短い方のパスを採用して、あとはPathLibに任せる
		regionTraversalPath.assign(regionTraversalPath1.begin(), regionTraversalPath1.end());
	} else if (std::min(d3, d4) < std::min(d1, d2)) {
		// d3,d4のどちらか短い方が、d1,d2のどちらか短い方よりも、短い場合
		// 元の作業ラインをダミーライドに変更
		for (auto itrDR = itrDR_rbegin; itrDR != itrDR_rend; ++itrDR) {
			itrDR->pathAttr = PathAttr::RideType::DUMMY;
		}
		// コピーしておいた作業ラインを追加
		swapList.insert(swapList.end(), dummyRide.rbegin(), dummyRide.rend());
		if (d3 < d4) {
			regionTraversalPath.assign(regionTraversalPath3.begin(), regionTraversalPath3.end());
		} else {
			regionTraversalPath.assign(regionTraversalPath4.begin(), regionTraversalPath4.end());
		}
	} else {
		if (d1 < d2) {
			regionTraversalPath.assign(regionTraversalPath1.begin(), regionTraversalPath1.end());
		} else {
			regionTraversalPath.assign(regionTraversalPath2.begin(), regionTraversalPath2.end());
		}
	}
	// 先頭は作業終了位置のインデックスなので削除
	regionTraversalPath.pop_front();
	for (int index : regionTraversalPath) {
		tData t;
		t.setIndex(index);
		t.pathAttr = PathAttr::RideType::NON_WORKING; // ヘッドランドナビゲーション
		t.point() = headLineVertices[index];
		endPointPath.push_back(t);
	}
	// ユーザが指定したエンド位置から最も近いSHP上の点に、ダミーの作業パスノードを生成して終了
	processEndPosition_driveEnd(endPointPath);
}
void OutField::processEndPosition_driveEnd(OutNodeList& endPointPath)
{
	tData t0;
	t0.setIndex(driveEndIndex);
	t0.nodeType = tData::NodeType::PATHNODE_1;
	t0.point() = driveEnd;
	endPointPath.push_back(t0);
	t0.setIndex(END_NAVIGATION); // このダミーのインデックス値をPathData側でチェックする
	t0.nodeType = tData::NodeType::PATHNODE_2;
	endPointPath.push_back(t0);
}

bool OutField::checkRunSideMargin(list<int> regionTraversalPath)
{
	auto itr = regionTraversalPath.begin();
	while (itr != regionTraversalPath.end()) {
		auto itr1 = itr;
		auto itr2 = ++itr;
		if (itr2 != regionTraversalPath.end() && *itr1 < workingAreaSize && *itr2 < workingAreaSize) {
			Point2D p1 = headLineVertices[*itr1];
			Point2D p2 = headLineVertices[*itr2];
			PolygonUtil::Segment s = PolygonUtil::Segment(p1, p2);
			double angleY = fabs(fabs(s.angle()) - M_PI_2);
			if (angleY < sideMarginAngle) {
				return true;
			}
		}
	}
	return false;
}

void OutField::connectNode2Way(int start, int end, list<int> &path1, list<int> &path2)
{
	auto list0 = gtemp.vertices[start];
	if (list0.size() != 2) {
		throw runtime_error(ErrorCode::NodeConnection::CONNECT_NODE);
	}
	connectNode(start, list0.front().first, end, path1);
	connectNode(start, list0.back().first, end, path2);
	if (distance(path2) < distance(path1)) {
		path1.swap(path2);
	}
}
void OutField::connectNode(int i0, int i1, int ie, list<int> &path)
{
	const int SIZE = (int) gtemp.vertices.size();
	path.clear();
	path.push_back(i0);
	path.push_back(i1);
	while (i1 != ie) {
		auto next = gtemp.vertices[i1];
		if (next.size() != 2) {
			throw runtime_error(ErrorCode::NodeConnection::CONNECT_NODE);
		}
		int i2f = next.front().first;
		int i2b = next.back().first;
		if (i2f == i0) {
			i0 = i1;
			i1 = i2b;
		} else if (i2b == i0) {
			i0 = i1;
			i1 = i2f;
		} else {
			throw runtime_error(ErrorCode::NodeConnection::CONNECT_NODE);
		}
		path.push_back(i1);
		if (path.size() > SIZE) {
			throw runtime_error(ErrorCode::NodeConnection::CONNECT_NODE);
		}
	}
}
double OutField::distance(list<int> &path)
{
	double d = 0.0;
	if (path.size() < 2) {
		return d;
	}
	auto itr1 = path.begin();
	auto itr2 = itr1;
	while (++itr2 != path.end()) {
		d += length(headLineVertices[*itr1], headLineVertices[*itr2]);
		itr1 = itr2;
	}
	return d;
}

void OutField::getEdgePoints(const Point2D &p, tData &t)
{
	// ポリゴンjを探索して、pが乗っている辺を探索
	for (int i = 0; i < OutPolyN; ++i) {
		for (int j = 0; j < outQ[i].size(); ++j) {
			Point2D p1 = outFieldVertices[outQ[i][j].first];
			Point2D p2 = outFieldVertices[outQ[i][j].second];
			double d = fabs(length(p, p1) + length(p, p2) - length(p1, p2));
			if (d < TOLERANCE) {
				// pがp1とp2の間にある場合
				t.pointEdge1() = p1.toFloat();
				t.pointEdge2() = p2.toFloat();
			}
		}
	}
}

void OutField::debugPrint()
{
#ifdef DEBUG_LOG
	ofstream myFile;
	myFile.open(LOG_DIR "OutField_Vertex.txt");
	for (int i = 0; i < headLineVertices.size(); ++i) {
		myFile << i << " " << headLineVertices[i].x << " " << headLineVertices[i].y << endl;
	}
	myFile.close();
	myFile.open(LOG_DIR "OutField_Node.txt");
	for (auto itr = finalNodePath.begin(); itr != finalNodePath.end(); ++itr) {
		myFile << itr->getIndex() << " " << itr->point().x << " " << itr->point().y << endl;
	}
	myFile.close();
#endif // DEBUG_LOG
}

}} // namespace yanmar::PathPlan

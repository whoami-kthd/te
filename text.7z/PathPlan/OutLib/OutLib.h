// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] CREATION  OF NAVIGATION PATH ALGORITHM                         */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company                :            xxxx xxxxxxxxxxxx xxxx xxxxxxxxx     */
/* Client                 :            YANMAR Co. Ltd, JAPAN                */
/* Author                 :            MANUJ SHARMA,SACHIN BHISIKAR         */
/*                                     ( YANMAR PathPlanning Team )         */
/* Version                :            1.1                                  */
/*                                                                          */
/* The purpose of out lib class is to plan which region has to be traversed */
/* first.Also it plans a path in each region. This functionality is also    */
/* responsible for generating a full navigation graph and path planning on  */
/* this navigation graph. It generates the type of pattern like skipped     */
/* pattern, adjacent pattern in the region. This functionality is also      */
/* responsible for creating a path through headland area connecting two     */
/* regions and creating a dummy ride if there is any need for this.         */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140110                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/*                                                                          */
/****************************************************************************/
#ifndef _OUTLIB_H_
#define _OUTLIB_H_

/*Macro for path length(paths which are removed)*/
#define MINDISTSWEEP 2

#include "PathPlanIF.hpp"
#include "PathPlanConstant.hpp"

#include <iostream>
#include <list>
#include <vector>
#include <array>
#include <deque>
#include <algorithm>

#include "PathLib/Segment.hpp"
#include "GraphLib/Graph.h"
#include "PolyLib/PolygonUtil.hpp"
#include "Geometry/Geometry.hpp"


enum DummyIndex {
	START_NAVIGATION = -1,
	START_EXTENSION = -2,
	END_NAVIGATION = -3,
	END_EXTENSION = -4,
};

enum TurnT {
	SP, EP
};

namespace yanmar { namespace PathPlan {
using namespace std;

typedef pair<int, int> OutPair;
typedef vector<OutPair> OutQueue;

typedef GeoPoint OutVertex;
typedef vector<OutVertex> OutVertexList;

/*No of points for polygon of the demarcated region*/
#define NO_OF_POINTS 1000

/**
 ノードデータクラス

 OutLibが出力するノードリストの要素クラス。
 @note 元ソースではPathGeneratorの出力するノードデータとしても使用していたが保守性に問題があるため廃止。
 */
struct tData {

    // 現在のところパスノードに走行方向の指定はない
//    static constexpr int FORWARD = Param::Path::Segment::Direction::FORWARD;
//    static constexpr int REVERSE = Param::Path::Segment::Direction::REVERSE;

    // Ride Type
    // - 作業/非作業指定。ダミーライドがあるので作業パス=作業ありではない
    using RideType = PathAttr::RideType;
//    static constexpr int FP = PathAttr::RideType::WORKING;
//    static constexpr int DR = PathAttr::RideType::DUMMY;
//    static constexpr int HN = PathAttr::RideType::NON_WORKING;

    // パスノード種別定数
	// If a particular node is part of working path or not
	struct NodeType {
		static constexpr int UNDEFINED = 0;     ///< 未定義
		static constexpr int PATHNODE_1 = 1;    ///< 作業パス入口
		static constexpr int PATHNODE_2 = 2;    ///< 作業パス出口
	};
    struct WhiskerType {
        static constexpr int NONE = Param::Path::WhiskerType::NONE;
        static constexpr int FORWARD = Param::Path::WhiskerType::FORWARD;
        static constexpr int BACKWARD = Param::Path::WhiskerType::BACKWARD;
        static constexpr int BOTH = Param::Path::WhiskerType::BOTH;
    };

	tData() = default;
	tData(const tData&) = default;

	int getIndex() const {
		return index;
	}

	void setIndex(int aIindex) {
		index = aIindex;
	}

    // 座標データリスト
    // - 特に理由のない限り直接アクセスせずに各アクセサを利用を推奨
    array<OutVertex, 4>& virtices() noexcept { return v1; }
    
    OutVertex& point() noexcept { return v1[0]; }               //!< 頂点座標
    const OutVertex& point() const noexcept { return v1[0]; }   //!< 頂点座標
    OutVertex& pointEdge1() noexcept { return v1[1]; }              //!< 所属辺の前側頂点座標
    const OutVertex& pointEdge1() const noexcept { return v1[1]; }  //!< 所属辺の前側頂点座標
    OutVertex& pointEdge2() noexcept { return v1[2]; }              //!< 所属辺の後側頂点座標
    const OutVertex& pointEdge2() const noexcept { return v1[2]; }  //!< 所属辺の後側頂点座標
    OutVertex& pointOrg() noexcept { return v1[3]; }                //!< 補正前頂点座標
    const OutVertex& pointOrg() const noexcept { return v1[3]; }    //!< 補正前頂点座標
    LineSegment getEdge() const { return LineSegment{pointEdge1(), pointEdge2()}; } //!< 所属辺セグメント

    /// 自分の頂点インデックス
    int index = -1;
    /// パスノード種別(パスノードの1番目か2番目か)
    int nodeType = NodeType::UNDEFINED;
    /// パス属性 @see PathAttr
    PathAttr pathAttr{PathAttr::RideType::WORKING};

private:
	/**
     座標リスト
     
     ノードとノードに関連する座標。直接アクセスせずにアクセサ利用を推奨。
        - [0]:頂点座標
        - [1],[2]:所属辺の端点座標(パスの出力に使うときはパスセグメントだった)
        - [3]:加工前の頂点座標
     */
	array<OutVertex, 4> v1;
};

// Adjacency node list for OutField output
typedef list<tData> OutNodeList;

class OutField {
public:
	/** 作業順序 */
	class WorkingOrder {
	public:
		/** 作業パスのx座標 */
		double x = 0;
		/** 作業パスのインデックス */
		int index = -1;
		/** ダミーライドフラグ */
		bool dummy = false;
		/** 中割りフラグ */
		bool divide = false;
	};

private:
	// 作業領域+非作業領域の頂点数
	int bVertexLen;
	std::vector<WorkingOrder> _workingOrders;

public:
	// 作業領域の頂点数 (非作業領域の頂点数は含まない)
	int workingAreaSize;
	/** 作業開始位置(左端の作業パスの上端/下端で、UIで設定したスタート位置に近い方の頂点インデックス) */
	int workStartIndex;
	/** 自動運転の開始位置(作業領域+作業パスの頂点で、UIで設定したスタート位置に最も近い点の頂点インデックス) */
	int driveStartIndex;
	/** 自動運転の終了位置(作業領域+作業パスの頂点で、UIで設定したエンド位置に最も近い点の頂点インデックス) */
	int driveEndIndex;
	/** 自動運転の開始位置の座標 */
	Point2D driveStart;
	/** 自動運転の終了位置の座標 */
	Point2D driveEnd;

	// ダミーライドを生成する/しない
	bool createDummyRide;
	// サイドマージンの角度閾値
	double sideMarginAngle = M_PI / 180.0 * 10.0;

	// 作業領域+非作業領域の頂点(FieldVertex)
	OutVertexList outFieldVertices;
	// 作業パスの頂点
	OutVertexList sweepVertices;
	// 作業領域+非作業領域+作業パスの頂点(NavFieldVertex)
	OutVertexList headLineVertices;

	// 作業機の位置(1:右、2:中央、4:左)
	int ploughDirection;

	// 作業領域+非作業領域の数(領域分割を含む)
	int OutPolyN;

	/* Graph for moving around the regions and headland */
	// NavFieldVertexのグラフ+作業パスのエッジ
	Graph gtemp;

	// 作業領域+非作業領域のエッジ
	/*A vector consisting of polygon of the demarcated region*/
	OutQueue *outQ;

	/*A list consisting of all the data about the intersection
	 points for each region */
	/* Also this list corresponds directly to the list outQ */
	OutNodeList *outNodePath;

	/*Final path creation for the path planner*/
	OutNodeList finalNodePath;
	int vortexCount = 0;
	bool vortexPattern = false;
	bool isCombine = false;

public:
	// デフォルトコンストラクタ
	OutField();
	// コピーコンストラクタ
	OutField(const OutField &obj);
	~OutField();

	// FieldPolygonから呼ばれる
	// マージしつつ、頂点間の接続情報を作る？
	/*This function Merge the existing data with the given vector values.*/
	void addQueue(vector<OutPair> newQ, Graph& g1);

	// 以下のデータをメンバー変数にコピーする
	// 作業領域+非作業領域の頂点
	// 作業領域+非作業領域+作業パスの頂点
	// 作業パスの間隔
	// 不明、とりあえず1固定で動いてる
	void copyVertices(const OutVertexList& FVert, OutVertexList& HVert);

	void processRegionSequence();

	// outNodePathに作業パスの頂点を追加する
	// outNodePathは作業領域ごとに分かれるため、各作業領域に作業パスを振り分けるイメージになっている
	void distributeSweepVertices(int OrigFieldVerLen);

	// PathDataに渡すためのデータfinalNodePathを生成してる
	void createSkippedPath(int pattern, int numSkipPath, int numSkipNoFish, bool canBackward, int progressType, int rotation);
	void createPathAB();
	void setWorkingOrders(const std::vector<WorkingOrder> &workingOrders);

private:
	void debugPrint();


	/*This function checks if any headland vertex lies in
	 between two sweep vertices.If yes, it inserts that vertex*/
	void processHeadLandPath(OutNodeList& swapList);


	/*This function generates the shortest path from given
	 start & end vertices */
	void processSingleSource(int s, int d, list<int> &regionTraversalPath);


	/*Newly added functions*/
	/*This function process the outQ and removes the zero size outQ*/
	void processQueue();

	/*This function generates the path from the end vertex of
	 last cultivation region to the End point
	 (Position of Tractor after cultivation)
	 */
	void processEndPosition(OutNodeList& swapList, OutNodeList& endPointPath);
	void processEndPosition_driveEnd(OutNodeList& endPointPath);
	void processStartPosition(OutNodeList& swapList, OutNodeList& startPointPath);

	void getEdgePoints(const Point2D &p, tData &t);

	/*This function joins two sweep vertices and creates a path*/
	void joinPathNodes(OutNodeList& swapList);


	/*Generate the plough pattern paths*/
	void createPloughPatternPath(OutNodeList& swapList, int numSkipNoFish, bool canBackward);

	// スキップ数に応じたブロックパターン生成
	void createChunkedPatternPath(OutNodeList& pathList, int skipLen, int progressType);

	// 渦巻きパス生成
	void createVortexPatternPath(OutNodeList& pathList);
	void createFieldPolygonPath(OutNodeList& pathList, bool canBackward);

	/** 与えられた作業パスに対して、作業機の幅一杯まで塗り潰せるように、作業パスの端点をずらす */
	void shiftWorkingPath();

	/** ノード(頂点インデックス)のリストが、サイドマージンを走ってないかチェックします。 */
	bool checkRunSideMargin(list<int> regionTraversalPath);

	/** グラフ上をstartからendまで繋ぐノード(頂点インデックス)のリストを2通り生成します。 */
	void connectNode2Way(int start, int end, list<int> &path1, list<int> &path2);
	void connectNode(int i0, int i1, int ie, list<int> &path);
	double distance(list<int> &path);

};
}} // namespace yanmar::PathPlan
#endif

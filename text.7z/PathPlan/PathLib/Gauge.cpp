// Yanmar Confidential 20200918
/**
 @file Gauge.cpp
 
 パス生成ゲージクラス
 */

#include "Gauge.hpp"

#include <cassert>

#include "PathLib.h"
#include "PathExtent.hpp"
#include "../DataConverter/SvgDataStream.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

#undef LOG_TAG
#define LOG_TAG "PathPlan::Gauge"

    /**
     Gaugeコンストラクタ
     
     FieldPolygonが計算で使用した値とInputDataの入力値のうちPathGeneratorが必要とするものを保持し、
     内部使用値を予め計算する。
     
     @param[in] hPara   FiledPolygon出力パラメータ
     @param[in] inData  パスプラン入力パラメータ
     */
    Gauge::Gauge(const FpGauge& hPara, const InputData& inData) :
        fpGauge(hPara),
        turnRadius(inData.tractors[0].turnRadius),
        actWidth(std::max(inData.tractors[0].width, inData.tractors[0].implement.width)),
        cultivationPos(inData.tractors[0].gnss.lengthToRearEnd + inData.tractors[0].implement.cultivationPos),
        permitBackward(inData.work.canBackward),
        entireDimension(inData.tractors[0])
    {
        // InputData入力値
        const auto& aTractor = inData.tractors[0];
        const auto& aImplement = aTractor.implement;
        const auto& gnss = aTractor.gnss;
        const auto& aWorkSetting = inData.work;
        const auto& aField = inData.field;

        // 作業機
        implement = aImplement;

        // 圃場
        field.hasConcave = hasConcave(aField);
        
        // トラクター
        tractor.length = gnss.lengthToFrontEnd + gnss.lengthToRearEnd;
        tractor.width = aTractor.width;
        tractor.frontLength = gnss.lengthToFrontEnd;
        tractor.noseLength = gnss.lengthToFrontEnd;
        tractor.rearLength = gnss.lengthToRearEnd;
        tractor.tailLength = gnss.lengthToRearEnd;
        if (implement.pos == Param::Implement::Pos::FRONT) {
            tractor.noseLength += implement.length;
        } else if (implement.pos == Param::Implement::Pos::REAR) {
            tractor.tailLength += implement.length;
        }
        tractor.shoulderLength = aTractor.wheelbase - gnss.lengthToRearAxle;
        tractor.lumbarLength = gnss.lengthToRearAxle;
        // フットプリントが変化する(ヒッチアップなどで)
        tractor.variableFootPrint = aImplement.canBackward && (aWorkSetting.headlandHitchMode == Param::Work::HitchMode::AUTO_REAR);
        cultivationPos = implement.cultivationPos;
        if (implement.pos == Param::Implement::Pos::FRONT) {
            cultivationPos += gnss.lengthToFrontEnd;
        } else if (implement.pos == Param::Implement::Pos::REAR) {
            cultivationPos += gnss.lengthToRearEnd;
            tractor.tailOverhang = cultivationPos - gnss.lengthToRearAxle;
        }
        
        // 内部事前算出値
        halfActWidth = actWidth * 0.5;
        halfTractorWidth = tractor.width * 0.5;
        actSHD = halfActWidth + clearance.BP;
        actHPD = std::min(halfActWidth + clearance.HP, turnRadius - clearance.HP);
        outerRadius = getOuterRadius(turnRadius);
        innerRadius = getInnerRadius(turnRadius);
        outerRadiusSBD = outerRadius + clearance.tolBP;  // BPと直接判定する値
        innerRadiusSBD = clipFloor(MIN_ARC_RADIUS, innerRadius - clearance.tolBP);
        
        // トラクター・作業機合計寸法
        entireDimension = EntireDimensions{aTractor};

        curve.bare = getCurveParamBare(turnRadius);    // トラクターのみのカーブ内径/外径

        // 凹角ターンサークルメトリクス
        {
            const double minInnerRadius = getInnerRadius(turnRadius);
            curveConcave.turnRadius = std::max(turnRadius, (turnRadius - minInnerRadius + clearance.BP));   // initilaze first!
            curveConcave.std = getCurveParamStd(curveConcave.turnRadius);
            curveConcave.sbd.outerRadius = curveConcave.std.outerRadius + clearance.tolBP;
            curveConcave.sbd.innerRadius = clipFloor(MIN_ARC_RADIUS, (minInnerRadius - clearance.tolBP));
            curveConcave.bare = getCurveParamBare(curveConcave.turnRadius);
            // 内径と安全マージンを考慮しても、まだ内側に余裕がある場合のシフト量
            curveConcave.maxShift = std::max(0.0, (curveConcave.std.innerRadius - clearance.BP));
        }
        // - オフセット有り用(左側)
        {
            // - ターンサークルフリップした場合に備え外径差で旋回半径を測る
            const double outerRadiusDiff = getOuterRadius(turnRadius, RotateDirection::CLOCKWISE) - turnRadius;
            concaveBP.left.turnRadiusMin = outerRadiusDiff + clearance.BP + TOL_ZERO_PNT_ONE_CM;
            concaveBP.left.turnRadius = std::max(turnRadius, concaveBP.left.turnRadiusMin);
            concaveBP.left.maxShift = std::max(0.0, concaveBP.left.turnRadius - concaveBP.left.turnRadiusMin);
        }
        // - オフセット有り用(右側)
        {
            // - ターンサークルフリップした場合に備え外径差で旋回半径を測る
            const double outerRadiusDiff = getOuterRadius(turnRadius, RotateDirection::ANTICLOCKWISE) - turnRadius;
            concaveBP.right.turnRadiusMin = outerRadiusDiff + clearance.BP + TOL_ZERO_PNT_ONE_CM;
            concaveBP.right.turnRadius = std::max(turnRadius, concaveBP.right.turnRadiusMin);
            concaveBP.right.maxShift = std::max(0.0, concaveBP.left.turnRadius - concaveBP.right.turnRadiusMin);
        }
        
        // 終端前進セグメント合計最短限界
        truncateLength.start = PathGenerator::START_NAV_TERM;
        truncateLength.start = std::max(truncateLength.start, (tractor.tailLength + clearance.BP));
        truncateLength.end = PathGenerator::END_NAV_TERM;
        truncateLength.end = std::max(truncateLength.end, (tractor.noseLength + clearance.BP));
        
        // WorkPath 作業パスの取扱
        {
            if (aWorkSetting.workPattern == PathPlan::Param::Work::Pattern::CYCLONE) {
                // 渦巻きのとき
                // ターンを含む
                workPath.types = WorkPath::Type::COMBINED_SIMPLEX;
                // 渦巻きの作業パス長下限撤廃
                workPath.length.min = 0.0;
            }

            // 作業パス
            workPath.overlap = aWorkSetting.overlapWidth;
            workPath.interval = implement.cultivationWidth - aWorkSetting.overlapWidth;
            // ヒッチアップダウンマージン無効
            // - 外周作業ありの時のみ有効
            workPath.compensateLength = (aWorkSetting.headland.process != Param::Work::Headland::Process::NOP) ? aWorkSetting.hitchUpDownMargin : 0.0;
        }

        // 作業パス脚
        // - 寸法から求める FPSはトラクター後方の長さ、SPSは前方の長さ
        if (implement.pos == Param::Implement::Pos::FRONT) {
            // これはコンバイン用
            // - 刈取り前の稲を踏まない長さで統一
            minFpsLegLength = 4.5;  //std::max(tractor.tailLength, tractor.noseLength) + turnModifier.legMargin;
            minSpsLegLength = minFpsLegLength;
        } else if (implement.pos == Param::Implement::Pos::REAR) {
            // - トラクターの場合、作業位置に統一
            const double minLegLength = cultivationPos;
            minSpsLegLength = minLegLength;
            minFpsLegLength = minLegLength;
        }
        // - 最低値保証
        minFpsLegLength = std::max(minFpsLegLength, MIN_ESCAPE_FROM_WORKPATH);
        minSpsLegLength = std::max(minSpsLegLength, MIN_ESCAPE_FROM_WORKPATH);

        // 作業パス
        workPath.pattern = aWorkSetting.workPattern;
        workPath.expandLength = tractor.tailOverhang;
        workPath.leg.type = aWorkSetting.workPath.leg.type; // これはSystemParameterではなく通常のパラメータ
        // workPath.leg.front.preBackLength = minFpsLegLength; // 定数なので初期化に任せる
        aWorkSetting.workPath.leg.front.preBack.get(workPath.leg.front.preBackLength); // DISABILEDでないときのみgetされる

        // 外周(枕地)処理
        // - 枕地仕上げなしの場合のみ脚の折りたたみにより作業パス延長可能
        if (aWorkSetting.headland.process != Param::Work::Headland::Process::NOP) {
            // 外周処理あり
            workPath.types = WorkPath::Type::RASTER_SWEEP;
            headland.process = aWorkSetting.headland.process;
            headland.pattern = aWorkSetting.headland.pattern;
            headland.rotation = aWorkSetting.headland.rotation;
            headland.transitOrbitMargin = aWorkSetting.hitchUpDownMargin + 0.5;
            if (headland.pattern == Param::Work::Headland::Pattern::ANTICYCLONE) {
                // HP基準外向渦巻
                headland.orbitalOrigin = Gauge::Headland::OrbitalOrigin::HP;
            } else {
                // HP基準内向渦巻
                // - 内向きでも最内周基準とする
                headland.orbitalOrigin = Gauge::Headland::OrbitalOrigin::HP;
            }
            // 周回作業用バック可否
            // - 作業設定のcanBackwardはラスター作業のパラメータなのでここでは使わない
            headland.permitBackward = implement.canBackward;
            // R-Oギャップ(暫定処置?)
            headland.gapMin = std::max(std::abs(implement.cultivationWidthOffset) - (implement.cultivationWidth / 2.0), 0.0);   // 最小隙間
            headland.gapMax = headland.gapMin + workPath.interval; // 最悪値
            // 周回作業ありの時は作業領域拡大しない
            workPath.leg.type = WorkPath::Leg::Type::STRAIGHT;
            // バックウィスカー前進長
            headland.whisker.preReverseLength = std::max(minSpsLegLength, cultivationPos);

            // 周回辺の端の扱い
            // 周回の開始・終了点の計算時にこの長さ未満は辺の端点を使用する
            headland.orbitalEdge.headSleshold = turnRadius * 2.0;
            headland.orbitalEdge.tailSleshold = turnRadius * 2.0;
        } else {
            // 外周処理なし
            // - パス脚折畳み(ドン突き)にはバックが必要
            if (workPath.leg.type == WorkPath::Leg::Type::FOLD && !implement.canBackward) {
                LOGD(LOG_TAG "::Gauge()", "[WARN] LEGFOLD with BACKWARD UNAVAILBLE IMPLEMENT.");
                PGASSERT(false, ErrorCode::Input::GENERAL);
                // バック不可作業機でどんつき要求はUIの設定ミスなのでassertのみ。
            }
        }
        
        // ターンパラメータ
        // - オプションパラメータが指定されていればオプションパラメータで上書き
        // fishtail turn pre-backward curve
        turn.fishtail.preBackLength = 2.0;
        aWorkSetting.turn.fishtail.preBack.get(turn.fishtail.preBackLength);
        // fishtail tangent angle limit
        if (aWorkSetting.turn.fishtail.seekAngle1.mode != OptionDouble::DISABLED) {
            turn.fishtail.maxAngle = Radian::convert(aWorkSetting.turn.fishtail.seekAngle1.value);
        }
        turn.fishtail.maxAngleTan = std::tan(turn.fishtail.maxAngle);

        // Alpha turn
        turn.alpha.enterLeg = minFpsLegLength;
        turn.alpha.leaveLeg = 0.0; //minSpsLegLength;
        // alpha turn pre-backward curve
        // turn.alpha.preBackLength = 2.0;  // デフォルト値は定数なので初期値に任せる。他のパラメータからデフォルト値を作る場合はここで指定する。
        aWorkSetting.turn.alpha.preBack.get(turn.alpha.preBackLength);
        // alpha turn post-backward curve
        // turn.alpha.postBackLength = 0.0;　// デフォルト値は定数なので初期値に任せる
        aWorkSetting.turn.alpha.postBack.get(turn.alpha.postBackLength);

        // plain turn pre-backward curve
        // turn.plain.backwardWhisker.preBackLength = minSpsLegLength;  定数なので初期値に任せる
        aWorkSetting.turn.plain.whisker.backward.preBack.get(turn.plain.backwardWhisker.preBackLength);

#if USE_OLD_SYSTEM_PARAMESTERS
        /// バックターンのバック前前進長
        backturnPreBack = aWorkSetting.backturnPreBack;
        if (!backturnPreBack.fixed) {
            backturnPreBack.length = 0.0;
        }
        /// バックターンのウィスカー最小長
        turnModifier.backturn = aWorkSetting.backturn;
        if (!turnModifier.backturn.whisker.forward.fixed) {
            turnModifier.backturn.whisker.forward.length = 0.0;
        }
        if (!turnModifier.backturn.whisker.backward.fixed) {
            turnModifier.backturn.whisker.backward.length = 0.0;
        }

        const double length = std::max(tractor.tailLength, tractor.noseLength);
        turnModifier.backturnLeg.length = std::min(length, turnRadius);

        // ターン調整パラメータ
        headland.turn = Headland::TurnShape{minFpsLegLength};
        headland.turn.alpha.leaveLeg = 0.0;
        headland.turn.alpha.preBackLength = preReverseLength;   // デフォルトと異なる可能性がある

        // 作業位置を合わせるための前進距離: 旋回半径 - 作業幅オフセット + 作業幅 * 0.5 + GNSS2作業中心
        whisker.forwardLength = turnRadius - implement.cultivationWidthOffset - (0.5 * implement.cultivationWidth) + implement.cultivationPos;
        // 前進時、圃場端にぶつからない距離: 旋回時外径 - GNSS2フロント
        whisker.forwardLengthMin = outerRadius - tractor.noseLength;
        // 作業位置を合わせるための後進距離: 旋回半径 - 作業幅オフセット + 作業幅 * 0.5 + GNSS2作業中心
        whisker.backwardLength = turnRadius - implement.cultivationWidthOffset + (0.5 * implement.cultivationWidth) - implement.cultivationPos;
        // 後進時、圃場端にぶつからない距離: 旋回時外径 - GNSS2作業機後端
        whisker.backwardLengthMin = outerRadius - tractor.tailLength;
#endif  // USE_OLD_SYSTEM_PARAMESTERS
    }

    /**
     周回作業周回数計算
     
     指定枕地幅dで周回可能な回数を返す。オフセット考慮のため周回方向も指定する。
     - オフセット対応のため、時計回りと反時計回りで異なる。
     - 最外周を周回できるクリアランスと行程幅(パス間隔)から産出する。
     
     @param[in] d           枕地幅(meter)
     @param[in] rotaiton    周回方向
     @param[in] minConcaveAngle ポリゴンの外側の角度の最小値 (ただし、凹頂点がない場合は0)
     
     @return 周回数
     */
    double Gauge::mesureOrbitalLaps(double d, int rotation, double minConcaveAngle) const {
        if (d < SAFTY_MARGIN) {
            // 安全マージンに足りない場合周回不能
            return 0;
        }
		// 旋回半径よりも作業機の方が大きいような場合は破綻するかも
		// 周回方向を考慮した旋回時外径
		const double outerR = getOuterRadius(turnRadius, rotation);
		// 周回方向を考慮した作業幅外径
		const double outerRc = turnRadius + implement.cultivationWidthOffset * rotation + implement.cultivationWidth * 0.5;
		// 外周作業不可能な幅 = 旋回時外径 - 作業幅外径 + 安全マージン
		// TODO:周回パスの生成に失敗したせいで安全マージンを増やしてリトライしている場合、Engineが増やした安全マージンを使いたい
		double impossibleW = outerR - outerRc + clearance.BP;
		if (minConcaveAngle > 0) {
			// 凹頂点がある場合
			// 周回走行可能な最外周ライン(GNSS位置)からBPまでの距離
			double gnss2bp = turnRadius - (getInnerRadius(turnRadius, -rotation) - clearance.BP) * std::sin(minConcaveAngle * 0.5);
			// 作業幅がGNSS位置から外側にハミ出す幅
			double gnss2cw = implement.cultivationWidthOffset * rotation + implement.cultivationWidth * 0.5;
			// 外周作業不可能な幅 = gnss2bp - gnss2cw
			impossibleW = max(impossibleW, gnss2bp - gnss2cw);
		}
		// 外周作業可能な幅 = d - 外周作業不可能な幅
		double possibleW = d - impossibleW;
		// 周回数 = floor(外周作業可能な幅 / パス間隔 - 許容誤差)
		return floor(possibleW / workPath.interval - TOLERANCE_2);

        const double outerClerance = std::max(getOuterRadius(turnRadius, rotation), getInnerRadius(turnRadius, rotation)) - turnRadius;
        d -= clearance.BP;
        d -= outerClerance;
        d -= std::abs(implement.cultivationWidthOffset);
//        double insideBias = getOrbitalClearance(field.hasConcave, rotation);
//        d += (offsetSign(rotation) == offsetSign(insideBias)) ? insideBias : -insideBias;
        // 周回数算出
        const double realLap = d / workPath.interval;
        // 切り下げて返す
        const double laps = floor(realLap);

        LOGD(LOG_TAG "::mesureOrbitalLaps", "raw:%g, return:%g", realLap, laps);
        return laps;
    }
    
    /**
     周回作業周回幅計算
     
     指定周回数に対応する合計周回幅(枕地幅)を返す。
     - オフセット対応のため、時計回りと反時計回りで幅が異なる。

     @param[in] laps    周回数
     @param[in] rotaiton    周回方向

     @return 合計周回幅(枕地幅)
     */
    double Gauge::mesureOrbitalWidth(int laps, int rotation) const {
        
        double d = getOuterSBD(turnRadius, rotation);
        d += (0.5 + laps) * workPath.interval;
        d -= rotation * implement.cultivationWidthOffset;   // 外側にオフセットしている場合減る。内側の場合増える。
        d -= workPath.overlap;  // 最内周がHPと指定量重なるように減らす
        
        return d;
    }

    /**
     指定半径・旋回方向でのouterRadiusを返す
     
     @param[in] radius  旋回半径
     @param[in] orient  旋回方向　RotateDirection
     */
    double Gauge::getOuterRadius(double radius, int orient) const noexcept {
        assert(0.0 <= radius);
        const auto metrics = getCurveOuterPoints(orient);  // 時計回りまたは反時計回りの寸法セットを取得
        const auto front = metrics.front;
        const auto rear = metrics.rear;
        const double frontOuterT = hypot(front.tr.width + radius, front.tr.length);
        const double frontOuterI = hypot(front.im.width + radius, front.im.length);
        const double rearOuterT = hypot(rear.tr.width + radius, rear.tr.length);
        const double rearOuterI = hypot(rear.im.width + radius, rear.im.length);
        const double retval = std::max(std::max(frontOuterT, frontOuterI), std::max(rearOuterT, rearOuterI));

        return retval;
    }

    /**
     指定半径でトラクターのみのouterRadiusを返す
     
     @param[in] radius  旋回半径
     @param[in] orient  旋回方向　RotateDirection
     */
    double Gauge::getOuterRadiusBare(double radius, int orient) const noexcept {
        assert(0.0 <= radius);
        const auto metrics = getCurveOuterPoints(orient);  // 時計回りまたは反時計回りの寸法セットを取得

        const double foRadius = hypot(metrics.front.tr.width + radius, metrics.front.tr.length); // 車体前端角
        const double roRadius = hypot(metrics.rear.tr.width + radius, metrics.rear.tr.length);   // 車体の後端角
        return std::max(foRadius, roRadius);
    }

    /**
     指定半径でのinnerRadiusを返す
     
     交差判定用のinner radiusを返す。radiusを生成するために使用してはいけない。
     
     @param[in] radius  旋回半径
     @param[in] orient  旋回方向　RotateDirection
     */
    double Gauge::getInnerRadius(double radius, int orient) const noexcept {
        assert(0.0 <= radius);
        const auto metrics = getCurveInnerPoints(orient);  // 時計回りまたは反時計回りの寸法セットを取得
        const double maxInner = max({metrics.front.tr.width, metrics.rear.tr.width, metrics.rear.im.width});
        return clipFloor(MIN_ARC_RADIUS, (radius - maxInner));
    }

    /**
     指定半径でのトラクターのみのinnerRadiusを返す
     
     交差判定用のinner radiusを返す。radiusを生成するために使用してはいけない。
     
     @param[in] radius  旋回半径
     @param[in] orient  旋回方向　RotateDirection
     */
    double Gauge::getInnerRadiusBare(double radius, int orient) const noexcept {
        assert(0.0 <= radius);
        const auto metrics = getCurveInnerPoints(orient);  // 時計回りまたは反時計回りの寸法セットを取得
        const double maxInner = max(metrics.front.tr.width, metrics.rear.tr.width);

        return clipFloor(MIN_ARC_RADIUS, (radius - maxInner));
    }

    /**
     周回パスクリアランス
     周回パスの第1周目の基準辺からの距離を取得する。
     
     @param[in] hasConcave  凹角有無
         @arg true  凹角有り
         @arg false 凹角無し
     */
    double Gauge::getOrbitalClearance(bool hasConcave, double rotation) const {
        double clearance = 0.0;
        
        if (headland.orbitalOrigin == Gauge::Headland::OrbitalOrigin::HP) {
            // 内側合わせ
            // - 内側合わせの場合に最初の周回をHP上から始めるため、clearanceは反対側の値を反転して使う。
            const double innerDir = rotation;
            const double outerDir = -rotation;
            const double halfculW = implement.cultivationWidth / 2.0;
            clearance = (implement.cultivationWidthOffset) + (outerDir * halfculW) + (innerDir * workPath.overlap);
            LOGD(LOG_TAG "::getOrbitalClearance", "orbital inside bias: %g", clearance);
        } else {
            // 外側合わせ
            const double outShd = getOuterSBD(turnRadius, rotation);
            const double inShd = getInnerSBD(turnRadius, -rotation);
            // クリアランスをturnRadius未満にした場合、凹角がある辺でパスが平行にならない
            clearance = (hasConcave) ? std::max(inShd, outShd) : outShd;
        }
        
        return clearance;
    }

    /**
     ターンパラメータの設定
     内部ターンパラメータを有効なオプションパラメータ値で上書きする。
     - DISABLEな項目値では何もしない
     */
    void Gauge::TurnParam::setOption(WorkSetting::TurnParam& param) noexcept {
        param.fishtail.preBack.get(fishtail.preBackLength);
        param.alpha.preBack.get(alpha.preBackLength);
        param.alpha.preBack.get(alpha.postBackLength);
    }

    // デバッグログ出力用
    string to_string(const Gauge& gauge) {
        std::stringstream ss;
        ss << std::fixed << setprecision(15)
        << "[Gauge]" << EOL
        << "radius:\t"              << gauge.turnRadius << EOL
        << "tractor.length:\t"          << gauge.tractor.length << EOL
        << "tractor.width :\t"          << gauge.tractor.width << EOL
        << "tractor.frontLength :\t"    << gauge.tractor.frontLength << EOL
        << "tractor.noseLength  :\t"    << gauge.tractor.noseLength << EOL
        << "tractor.rearLength  :\t"    << gauge.tractor.rearLength << EOL
        << "tractor.tailLength  :\t"    << gauge.tractor.tailLength << EOL
        << "tractor.tailOverhang:\t"    << gauge.tractor.tailOverhang << EOL
        << "implement.pos:\t"                       << gauge.implement.pos << EOL
        << "implement.length:\t"                    << gauge.implement.length << EOL
        << "implement.width :\t"                    << gauge.implement.width << EOL
        << "implement.widthOffset:\t"               << gauge.implement.widthOffset << EOL
        << "implement.cultivationWidth:\t"          << gauge.implement.cultivationWidth << EOL
        << "implement.cultivationWidthOffset:\t"    << gauge.implement.cultivationWidthOffset << EOL
        << "fpGauge.margin:\t"              << gauge.fpGauge.margin << EOL
        << "fpGauge.headLandRasters:\t"     << gauge.fpGauge.headLandRasters << EOL
        << "actWidth:\t"            << gauge.actWidth << EOL
        << "outerRadius:\t"         << gauge.outerRadius << EOL
        << "innerRadius:\t"         << gauge.innerRadius << EOL
        << "cultivationPos:\t"      << gauge.cultivationPos << EOL
        << "permitBackward:\t"      << gauge.permitBackward << EOL
        
        << "halfActWidth:\t"        << gauge.halfActWidth << EOL
        << "actSHD:\t"              << gauge.actSHD << EOL
        << "actHPD:\t"              << gauge.actHPD << EOL
        << "innerRadiusSBD:\t"      << gauge.innerRadiusSBD << EOL
        << "outerRadiusSBD:\t"      << gauge.outerRadiusSBD << EOL

        << "innerRadius(bare):\t"   << gauge.curve.bare.innerRadius << EOL
        << "outerRadius(bare):\t"   << gauge.curve.bare.outerRadius << EOL

        << "front_left (body):\t"   << to_string(gauge.entireDimension.left().front.tr) << EOL
        << "rear_left  (body):\t"   << to_string(gauge.entireDimension.left().rear.tr) << EOL
        << "rear_right (body):\t"   << to_string(gauge.entireDimension.right().rear.tr) << EOL
        << "front_right(body):\t"   << to_string(gauge.entireDimension.right().front.tr) << EOL
        << "front_left (im)  :\t"   << to_string(gauge.entireDimension.left().front.im) << EOL
        << "rear_left  (im)  :\t"   << to_string(gauge.entireDimension.left().rear.im) << EOL
        << "rear_right (im)  :\t"   << to_string(gauge.entireDimension.right().rear.im) << EOL
        << "front_right(im)  :\t"   << to_string(gauge.entireDimension.right().front.im) << EOL

        << "minFpsLegLength:\t" << gauge.minFpsLegLength << EOL
        << "minSpsLegLength:\t" << gauge.minSpsLegLength << EOL

        << "workPath.types   :\t"           << (int)gauge.workPath.types << EOL
        << "workPath.overlap :\t"           << gauge.workPath.overlap << EOL
        << "workPath.interval:\t"           << gauge.workPath.interval << EOL
        << "workPath.compensateLength:\t"   << gauge.workPath.compensateLength << EOL
        << "workPath.expandLength:\t"       << gauge.workPath.expandLength << EOL
        << "workPath.leg.type:\t"           << gauge.workPath.leg.type << EOL
        << "workPath.leg.front.preBack:\t"  << gauge.workPath.leg.front.preBackLength << EOL

        << "turn.fishtail.preBack:\t"       << gauge.turn.fishtail.preBackLength << EOL
        << "turn.fishtail.maxAngle:\t"       << gauge.turn.fishtail.maxAngle << EOL
        << "turn.fishtail.maxAngleTan:\t"       << gauge.turn.fishtail.maxAngleTan << EOL

        << "turn.alpha.enterLeg:\t"         << gauge.turn.alpha.enterLeg << EOL
        << "turn.alpha.preBack:\t"          << gauge.turn.alpha.preBackLength << EOL
        << "turn.alpha.postBack:\t"         << gauge.turn.alpha.postBackLength << EOL
        << "turn.alpha.leaveLeg:\t"         << gauge.turn.alpha.leaveLeg << EOL

        << "turn.plain.enterLeg:\t"                 << gauge.turn.plain.enterLeg << EOL
        << "turn.plain.backwardWhisker.preBack:\t"  << gauge.turn.plain.backwardWhisker.preBackLength << EOL
        << "turn.plain.leaveLeg:\t"                 << gauge.turn.plain.leaveLeg << EOL

        << "headland.pattern :\t"       << gauge.headland.pattern << EOL
        << "headland.process :\t"       << gauge.headland.process << EOL
        << "headland.rotation:\t"       << gauge.headland.rotation << EOL
        << "headland.orbitalOrigin:\t"  << (int)gauge.headland.orbitalOrigin << EOL

        << "clearance.BP   :\t" << gauge.clearance.BP << EOL
        << "clearance.tolBP:\t" << gauge.clearance.tolBP << EOL
        << "clearance.HP   :\t" << gauge.clearance.HP << EOL
        << "clearance.RSE  :\t" << gauge.clearance.RSE << EOL
        // 凹角ターンパラメータ(左側)
        << "concaveBP.left.turnRadiusMin :\t" << gauge.concaveBP.left.turnRadiusMin << EOL
        << "concaveBP.left.maxShift      :\t" << gauge.concaveBP.left.maxShift << EOL
        << "concaveBP.left.turnRadius    :\t" << gauge.concaveBP.left.turnRadius << EOL
        // 凹角ターンパラメータ(右側)
        << "concaveBP.right.turnRadiusMin:\t" << gauge.concaveBP.right.turnRadiusMin << EOL
        << "concaveBP.right.maxShift     :\t" << gauge.concaveBP.right.maxShift << EOL
        << "concaveBP.right.turnRadius   :\t" << gauge.concaveBP.right.turnRadius << EOL
        
        << "field.hasConcave:\t" << gauge.field.hasConcave << EOL
        << endl;
        
        return ss.str();
    }
    
    string to_string(const Gauge::Dimensions& dim, const string& caption) {
        std::stringstream ss;
        ss << std::fixed << setprecision(15)
            << caption << dim.length << ", " << dim.width;
        
        return ss.str();
    }
    
    /**
     作業機込みトラクター図形
     X軸向きのトラクター・作業機全体の図形をSVGのpath要素で返す。
     */
    template<>
    string getSvgPathSilhouette<TRACTOR_ENTIRE>(const Gauge& gauge, int index) {
        // トラクターバウンディングボックス
        std::vector<XY_Point> tr{
            // 初期位置はGNSS位置にあるものとする
            // ロアリンク位置に移動
            { -gauge.tractor.rearLength, 0.0},
            // トラクター外周
            { 0.0, -gauge.halfTractorWidth},
            { gauge.tractor.length, 0.0},
            { 0.0, gauge.tractor.width},
            { -gauge.tractor.length, 0.0},
            { 0.0, -gauge.halfTractorWidth}
        };
        
        // 作業機バウンディングボックス
        const double w = gauge.implement.width;
        const double len = gauge.implement.length;
        std::vector<XY_Point> implr;
        std::vector<XY_Point> implf;
        if (gauge.implement.pos == Param::Implement::Pos::REAR) {
            const auto dim = gauge.entireDimension.rear();
            std::vector<XY_Point> impl{
                // 初期位置はロアリンク位置にあるものとする
                { 0.0,  -dim.left.im.width},
                { -len,  0.0},
                {  0.0,  w},
                {  len,  0.0},
                {  0.0, -dim.right.im.width}
            };
            implr = std::move(impl);
        } else if (gauge.implement.pos == Param::Implement::Pos::FRONT) {
            const auto dim = gauge.entireDimension.front();
            std::vector<XY_Point> impl{
                // 初期位置は車体先端中心にあるものとする
                {  0.0, -dim.left.im.width},
                {  len,  0.0},
                {  0.0,  w},
                { -len,  0.0},
                {  0.0, -dim.right.im.width}
            };
            implf = std::move(impl);
        }

        // 出力
        std::stringstream ss;
        ss << std::fixed << std::setprecision(7);

        SvgDataStream::Indent indentl{{"l\t", "\n\t"}};
        SvgDataStream::Indent indentm{{"m\t", "\n\t"}};
        // 車体
        for (const auto& p : tr) {
            ss << indentl.str() << p.x << "," << p.y;
        }
        // 作業機(後)
        if (!implr.empty()) {
            ss << EOL;
            indentl.reset();
            for (const auto& p : implr) {
                ss << indentl.str() << p.x << "," << p.y;
            }
        }
        // 作業機(前)
        if (!implf.empty()) {
            ss << EOL;
            indentl.reset();
            indentm.reset();
            ss << indentm.str() << 0.0 << "," << gauge.tractor.length << EOL;
            for (const auto& p : implf) {
                ss << indentl.str() << p.x << "," << p.y;
            }
        }

        return ss.str();
    }

    /**
     作業機込みトラクターViewBox
     X軸向きのトラクター・作業機全体のViewBoxを返す。
     */
    template<>
    Svg::ViewBox getSvgViewBox<TRACTOR_ENTIRE>(const Gauge& gauge, int index) {
        Svg::ViewBox vb;

        // 基準位置
        const auto rl = gauge.entireDimension.rearLeft();
        vb.x = rl.maxLengthTI();
        vb.y = rl.maxWidthTI();

         // 長さ+幅
        const auto left = gauge.entireDimension.left();
        const auto right = gauge.entireDimension.right();
        vb.width = left.maxLengthTI() + right.maxLengthTI();
        vb.height = left.maxWidthTI() + right.maxWidthTI();

        // 出力
        return vb;
    }

}} // namespace yanmar::PathPlan

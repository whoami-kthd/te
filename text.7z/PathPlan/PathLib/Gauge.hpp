// Yanmar Confidential 20200918
/**
 @file Gauge.hpp
 
 パス生成ゲージクラス
 */
#pragma once

#include <string>

#include "PathPlanIF.hpp"
#include "Geometry/Geometry.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

namespace Svg {
    struct ViewBox;
}

    /// ターン限界許容差
    // - FieldPolygonでSAFTY_MARGIN(= margin = actSBD) から控除している値
    static constexpr double torelace = 0.01;
    /// 最小作業パス脱出長
    // - ECU都合0.5m + マージン
    static constexpr double MIN_ESCAPE_FROM_WORKPATH = 1.0;
    /// BPクリアランス
    static constexpr double SAFTY_MARGIN = 1.0;
    /// Uターン適用幅マージン
    static constexpr double TOL_U_TURN_WIDTH = 0.000001;	// 旋回直径に対する許容幅
    ///< ターン内径最小値(交差判定不良を防ぐため0にしない)
    static constexpr double MIN_ARC_RADIUS = 0.005;

    /**
     FieldPolygon内で生成する限界値クラス
     
     FiledPlolygon内で計算に使用した値を伝達するためのクラス。
     */
    struct FpGauge {
        // floatなのは歴史的理由による
        float turnRadius = 0.0;    ///< 旋回半径
        float maxWidth = 0.0;      ///< トラクター実行幅(トラクターの幅、または作業機の幅の大きい方)
        float gps2CultivationPos = 0.0;	///< 後部長(GNSSユニットの位置から作業位置までの長さ)
        float margin = 0.0;		///< 安全マージン(Safe Boundary Distance = SBD;トラクターと圃場外形間の最小距離)
        float outerRadius = 0.0;	///< 旋回円外半径(旋回半径で旋回したときの中心からの最大距離)
        float innerRadius = 0.0;	///< 旋回円内半径(旋回半径で旋回したときの中心からの最小距離。作業機の幅が大きい場合、マイナスになることがある)
        float canBackward = false;
        int headLandRasters = 0.0;  ///< 枕地の最大(作業進捗)行程数
        double whpDiff = 0.0;  ///< HPと外周作業用HPとの差
    };
    
    /**
     パス生成限界値クラス
     
     トラクターとその他マージン値によるパス生成時の限界値を保持するクラス
     */
    struct Gauge {
        friend class PathGenerator;
        friend class PathValidator;
        friend class PathFPS;
        friend class PathSPS;
        friend string to_string(const Gauge& gauge);
        
        struct Dimensions
        {
            Dimensions() = default;
            Dimensions(double w, double l) :
                width(w), length(l)
            {}
            Dimensions(const Dimensions& dim) = default;

            double width = 0.0;
            double length = 0.0;
        };
        
    public:
        Gauge() = default;
        Gauge(const Gauge& gauge) = default;
        Gauge(const FpGauge& hPara, const InputData& inData);
        
        // 枕地周回幅計算
        double mesureOrbitalLaps(double d, int rotation, double minConcaveAngle) const;
        double mesureOrbitalWidth(int lap, int rotation) const;

        // 作業機込みの半径
        double getOuterRadius(double radius, int orient) const noexcept;
        double getInnerRadius(double radius, int orient) const noexcept;
        // トラクターのみの半径
        double getOuterRadiusBare(double radius, int orient) const noexcept;
        double getInnerRadiusBare(double radius, int orient) const noexcept;

        double getOuterRadius(double radius) const noexcept {
            return std::max(getOuterRadius(radius, RotateDirection::CLOCKWISE), getOuterRadius(radius, RotateDirection::ANTICLOCKWISE));
        }
        double getInnerRadius(double radius) const noexcept {
            return std::min(getInnerRadius(radius, RotateDirection::CLOCKWISE), getInnerRadius(radius, RotateDirection::ANTICLOCKWISE));
        }
        double getOuterRadiusBare(double radius) const noexcept {
            return std::max(getOuterRadiusBare(radius, RotateDirection::CLOCKWISE), getOuterRadiusBare(radius, RotateDirection::ANTICLOCKWISE));
        }
        double getInnerRadiusBare(double radius) const noexcept {
            return std::min(getInnerRadiusBare(radius, RotateDirection::CLOCKWISE), getInnerRadiusBare(radius, RotateDirection::ANTICLOCKWISE));
        }

        /// U Turn外型高さ
        double getMinTurnHeight() const noexcept {
            return minFpsLegLength + getOuterRadius(turnRadius);
        }

        /// HOOK Turn外型高さ
        double getMaxTurnHeight() const noexcept {
            return minFpsLegLength + (turnRadius * 2.0) + getOuterRadius(turnRadius);
        }

        struct CurveParam {
            CurveParam() = default;
            CurveParam(double iRadius, double oRadius) :
                innerRadius(iRadius), outerRadius(oRadius)
            {}

            double innerRadius = 0.0;
            double outerRadius = 0.0;
        };

        /// 内径を求める
        /// 半径 radius に対し控除分を差し引き、内側の境界半径を求める。
        /// MIN_ARC_RADIUS 未満にはならない。これで旋回半径を生成してはいけない。
        static double makeInnerRadius(double radius, double hw) noexcept {
            return clipFloor(MIN_ARC_RADIUS, (radius - hw));
        }
        
        // クリアランスを加える
        // cpから指定のクリアランス込みの境界半径CurveParamを生成して返す。(内径はさらに小さくなることに注意)
        CurveParam addClearance(CurveParam cp, double clearance) const noexcept {
            cp.innerRadius = makeInnerRadius(cp.innerRadius, clearance);
            cp.outerRadius += clearance;
            return cp;
        }
        CurveParam getCurveParamStd() const noexcept { return getCurveParamStd(turnRadius); }
        CurveParam getCurveParamStd(double radius) const noexcept {
            const double innerRadius = getInnerRadius(radius);
            const double outerRadius = getOuterRadius(radius);
            return {innerRadius, outerRadius};
        }
        CurveParam getCurveParamStd(double radius, double orient) const noexcept {
            const double innerRadius = getInnerRadius(radius, orient);
            const double outerRadius = getOuterRadius(radius, orient);
            return {innerRadius, outerRadius};
        }
        CurveParam getCurveParamSBD() const noexcept { return {innerRadiusSBD, outerRadiusSBD}; }
        CurveParam getCurveParamSBD(double radius) const noexcept {
            const double innerRadius = getInnerRadius(radius);
            const double outerRadius = getOuterRadius(radius);
            return {innerRadius, outerRadius};
        }
        CurveParam getCurveParamSBD(double radius, double orient) const noexcept {
            CurveParam cp = getCurveParamStd(radius, orient);
            return addClearance(cp, clearance.tolBP);
        }
        const CurveParam& getCurveParamBare() const noexcept { return curve.bare; }
        CurveParam getCurveParamBare(double radius) const noexcept {
            const double innerRadius = getInnerRadiusBare(radius);
            const double outerRadius = getOuterRadiusBare(radius);
            return {innerRadius, outerRadius};
        }
        CurveParam getCurveParamBare(double radius, double orient) const noexcept {
            const double innerRadius = getInnerRadiusBare(radius, orient);
            const double outerRadius = getOuterRadiusBare(radius, orient);
            return {innerRadius, outerRadius};
        }

        double getOrbitalClearance(bool hasConcave, double rotation) const;

    public:
        /// クリアランス(各境界へ最小距離)
        struct {
            double BP = SAFTY_MARGIN;
            double tolBP = SAFTY_MARGIN - torelace;
            double HP = 0.1;
            double RSE = 0.0;   ///< 作業済み領域踏み荒らし判定用マージンとして使用
            double stopEndMargin = 0.2;         ///< パス終端前方に対してBPクリアランスに加えるマージン
            double stopBP = BP + stopEndMargin; ///< パス終端前方の合計BPクリアランス
        } clearance;

        // 入力設定値
        // - FieldPolygon出力値
        FpGauge fpGauge;
        // - FieldPolygon出力値のコピー
        double turnRadius = 0.0;    ///< 旋回半径
        double actWidth = 0.0;      ///< トラクター実効幅(トラクターの幅、または作業機の幅の大きい方)
        double cultivationPos = 0.0;    ///< 作業位置:GNSSユニットの位置から作業位置までの長さ
        double outerRadius = 0.0;    ///< 旋回円外半径(旋回半径で旋回したときの中心からの最大距離) @deprecated オフセット非対応のため
        double innerRadius = 0.0;    ///< 旋回円内半径(旋回半径で旋回したときの中心からの最小距離。作業機の幅が大きい場合、マイナスになることがある) @deprecated オフセット非対応のため
        // - InputData設定値
        struct {
            double width = 0.0;
            double length = 0.0;
            double frontLength = 0.0;   ///< GPからトラクター車体先端までの長さ
            double noseLength = 0.0;	///< 前部長(GNSSユニットの位置から前部作業機先端までの長さ)
            double rearLength = 0.0;    ///< GPからトラクター車体後端までの長さ
            double tailLength = 0.0;	///< 後部長(GNSSユニットの位置から後部作業機後端までの長さ)
            double tailOverhang = 0.0;  ///< (ヒッチアップ時の)後輪軸から作業位置までの長さ)
            double shoulderLength = 0.0;    ///< 肩部長(GPから前輪車軸までの長さ)
            double lumbarLength = 0.0;      ///< 腰部長(GPから後輪車軸までの長さ)
            bool variableFootPrint = false; ///< (ヒッチアップなどで)フットプリントが変化するかどうか
        } tractor;         ///< トラクター寸法

        Implement implement;       ///< 作業機寸法

        bool permitBackward = false;	///< バック移動許可フラグ

        // 内部使用値
        double halfActWidth = 0.0;      ///< 実効幅の半分(各種計算に使う)
        double halfTractorWidth = 0.0;	///< トラクター幅の半分(各種計算に使う)
        double actSHD = 0.0;            ///< Safe Head-land Distance = BP - SHP の辺の距離(実寸)
        double actHPD = 0.0;            ///< HP に対する最小距離
        double outerRadiusSBD = 0.0;	///< BPクリアランス判定用outerRadius(許容差控除済)
        double innerRadiusSBD = 0.0;	///< BPクリアランス判定用innerradius(許容差控除済)

        // 実寸法セット
        struct TractorDimensionSet {
        public:
            Dimensions tr;
            Dimensions im;
            Dimensions wp;

            double maxWidthTI() const noexcept { return std::max(tr.width, im.width); }
            double maxLengthTI() const noexcept { return std::max(tr.length, im.length); }
            Dimensions getMaxTI() const { return {maxWidthTI(), maxLengthTI()}; }
        };

        // 全象限寸法
        template<typename T>
        struct DimQuadrants_t {
            using value_type = T;
            struct LeftRight {
                const value_type& left;
                const value_type& right;

                double maxWidthT() const noexcept { return std::max(left.tr.width, right.tr.width); }
                double maxWidthTI() const noexcept { return std::max(left.maxWidthTI(), right.maxWidthTI()); }
                double maxLengthT() const noexcept { return std::max(left.tr.length, right.tr.length); }
                double maxLengthTI() const noexcept { return std::max(left.maxLengthTI(), right.maxLengthTI()); }
                Dimensions getMaxTI() const { return {maxWidthTI(), maxLengthTI()}; }
            };
            struct FrontRear {
                const value_type& front;
                const value_type& rear;

                double maxWidthT() const noexcept { return std::max(front.tr.width, rear.tr.width); }
                double maxWidthTI() const noexcept { return std::max(front.maxWidthTI(), rear.maxWidthTI()); }
                double maxLength() const noexcept { return std::max(front.tr.length, rear.tr.length); }
                double maxLengthTI() const noexcept { return std::max(front.maxLengthTI(), rear.maxLengthTI()); }
                Dimensions getMaxTI() const { return {maxWidthTI(), maxLengthTI()}; }
                double getMaxWpWidth() const noexcept { return std::max(front.wp.width, rear.wp.width); }
            };

            DimQuadrants_t() = default;
            DimQuadrants_t(const DimQuadrants_t&) = default;
            explicit DimQuadrants_t(const value_type& qt) :
                dims(qt, qt, qt, qt)
            {}
            DimQuadrants_t(const value_type& fl, const value_type& rl, const value_type& rr, const value_type& fr) :
                dims{fl, rl, rr, fr}
            {}
            
            template<typename U>
            inline static
            const U& as_const(U& src) { return const_cast<const U&>(src); }

            const value_type& frontLeft() const noexcept { return dims[0]; }
            const value_type& rearLeft() const noexcept { return dims[1]; }
            const value_type& rearRight() const noexcept { return dims[2]; }
            const value_type& frontRight() const noexcept { return dims[3]; }

            value_type& frontLeft() noexcept { return const_cast<value_type&>(as_const(*this).frontLeft()); }
            value_type& rearLeft() noexcept { return const_cast<value_type&>(as_const(*this).rearLeft()); }
            value_type& rearRight() noexcept { return const_cast<value_type&>(as_const(*this).rearRight()); }
            value_type& frontRight() noexcept { return const_cast<value_type&>(as_const(*this).frontRight()); }
            
            const LeftRight front() const { return {frontLeft(), frontRight()}; }
            const LeftRight rear() const { return {rearLeft(), rearRight()}; }
            const FrontRear left() const { return {frontLeft(), rearLeft()}; }
            const FrontRear right() const { return {frontRight(), rearRight()}; }

            // バック方向の寸法にする
            void makeBackward() {
                std::swap(dims[0], dims[2]);
                std::swap(dims[1], dims[3]);
            }

        public:
            std::array<value_type, 4>  dims;
        };

        /**
         全体寸法
         車体・作業機・作業位置の合成寸法を管理する。
         - 管理するだけで矩形の合成をしたりはしない。
         - 左右オフセット対応のため、4象限(fronLeft、rearLeft, rearRight, frontRight)に分かれている。
         @see HalfSideDimensions
         */
        struct EntireDimensions : public DimQuadrants_t<TractorDimensionSet> {

            DimQuadrants_t<Dimensions> getTr() const {
                return {frontLeft().tr, rearLeft().tr, rearRight().tr, frontRight().tr};
            }

            DimQuadrants_t<Dimensions> getIm() const {
                return {frontLeft().im, rearLeft().im, rearRight().im, frontRight().im};
            }

            DimQuadrants_t<Dimensions> getWp() const {
                return {frontLeft().wp, rearLeft().wp, rearRight().wp, frontRight().wp};
            }
            
            void setTr(const Tractor& aTr) noexcept
            {
                const double hw = aTr.width * 0.5;
                const double frontLength = aTr.gnss.lengthToFrontEnd;
                const double reaeLength = aTr.gnss.lengthToRearEnd;
                
                frontLeft().tr = {hw, frontLength};
                frontRight().tr = {hw, frontLength};
                rearLeft().tr = {hw, reaeLength};
                rearRight().tr = {hw, reaeLength};
            }
            
            void setIm(const Tractor& aTr) noexcept
            {
                const Implement& aIm = aTr.implement;
                const double hw = aIm.width * 0.5;
                const double offset = aIm.widthOffset;
                
                // TODO: もし複数になったらiterationすること
                if (aIm.pos == Param::Implement::Pos::FRONT) {
                    const double frontLength = aTr.gnss.lengthToFrontEnd + aIm.length;
                    frontLeft().im = {hw - offset, frontLength};
                    frontRight().im = {hw + offset, frontLength};
                    rearLeft().im = {0.0, 0.0};
                    rearRight().im = {0.0, 0.0};
                } else {
                    // 互換性のためデフォルトで後方とする
                    const double rearLength = aTr.gnss.lengthToRearEnd + aIm.length;
                    frontLeft().im = {0.0, 0.0};
                    frontRight().im = {0.0, 0.0};
                    rearLeft().im = {hw - offset, rearLength};
                    rearRight().im = {hw + offset, rearLength};
                }
            }
            
            void setWp(const Tractor& aTr) noexcept
            {
                const Implement& aIm = aTr.implement;
                const double hw = aIm.cultivationWidth * 0.5;
                const double offset = aIm.cultivationWidthOffset;
                
                // TODO: もし複数になったらiterationすること
                if (aIm.pos == Param::Implement::Pos::FRONT) {
                    const double frontLength = aTr.gnss.lengthToFrontEnd + aIm.cultivationPos;
                    frontLeft().wp = {hw - offset, frontLength};
                    frontRight().wp = {hw + offset, frontLength};
                    rearLeft().wp = {0.0, 0.0};
                    rearRight().wp = {0.0, 0.0};
                } else {
                    // 互換性のためデフォルトで後方とする
                    const double rearLength = aTr.gnss.lengthToRearEnd + aIm.cultivationPos;
                    frontLeft().wp = {0.0, 0.0};
                    frontRight().wp = {0.0, 0.0};
                    rearLeft().wp = {hw - offset, rearLength};
                    rearRight().wp = {hw + offset, rearLength};
                }
            }

        public:
            EntireDimensions() = default;
            EntireDimensions(const EntireDimensions&) = default;
            explicit EntireDimensions(const Tractor& aTr) {
                setTr(aTr);
                setIm(aTr);
                setWp(aTr);
            }
            
            // バック方向の寸法を得る
            EntireDimensions getBackwardDim() const noexcept {
                EntireDimensions retval{*this};
                retval.makeBackward();
                return retval;
            }
        } entireDimension;

        /**
         内側寸法取得
         
         指定旋回方向に対する内側寸法を返す
         */
        const EntireDimensions::FrontRear getCurveInnerPoints(int orient = RotateDirection::CLOCKWISE) const {
            if (orient == RotateDirection::CLOCKWISE) {
                return entireDimension.right();
            } else {
                return entireDimension.left();
            }
        }
        
        /**
         外側寸法取得
         
         指定旋回方向に対する外側寸法を返す
         */
        const EntireDimensions::FrontRear getCurveOuterPoints(int orient = RotateDirection::CLOCKWISE) const {
            if (orient == RotateDirection::CLOCKWISE) {
                return entireDimension.left();
            } else {
                return entireDimension.right();
            }
        }

        double getOuterSBD(double radius, int orient) const noexcept { return getOuterRadius(radius, orient) - radius + clearance.BP; }
        double getInnerSBD(double radius, int orient) const noexcept { return radius - getInnerRadius(radius, orient) + clearance.BP; }
        
//        Dimensions frontOuterPoint;     ///< GPからトラクター前方の最遠点(無符号)
        double defaultPreBeckLength = 2.0;    ///< バック前の予備直進長(GPから後輪軸までの長さ?)
        double minFpsLegLength = 0.0;   ///< 作業後脱出直進長(FPS)
        double minSpsLegLength = 0.0;   ///< 作業前進入直進長(SPS)
        
        bool checkFPSLegLength(double legLength) const noexcept {
            return ((minFpsLegLength - 0.01) <= legLength);
        }
        
        bool checkSPSLegLength(double legLength) const noexcept {
            return ((minSpsLegLength - 0.01) <= legLength);
        }

        ///
        struct {
            /// トラクターのみのターンメトリクス
            CurveParam bare{0.0, 0.0};
            // 作業機込みターンメトリクス(現在Gauge直下にある)
            // CurveParam std{0.0, 0.0}; 未使用
        } curve;

        /// 凹角のターンメトリクス　@deprecated ConcaveParam
        struct {
            double turnRadius = 0.0;
            CurveParam std = {0.0, 0.0};    ///< トラクター作業機合成内外径
            CurveParam sbd = {0.0, 0.0};    ///< BPクリアランス付き合成内径
            CurveParam bare = {0.0, 0.0};   ///< トラクターのみの内径外径
            double maxShift  = 0.0;

            CurveParam getCurveParamStd() const noexcept { return std; }
            CurveParam getCurveParamSBD() const noexcept { return sbd; }
            const CurveParam& getCurveParamBare() const noexcept { return bare; }
        } curveConcave;

        /**
         凹角ターンメトリクス
         - BP用なので半径値は安全マージンを含む。
         - 実旋回半径はトラクターパラメータかinnerRadiusの何れか大きい方。
         */
        struct ConcaveParam {
            double turnRadius = 0.0;    ///< 実旋回半径
            double turnRadiusMin = 0.0; ///< 最小限界旋回半径
            double maxShift  = 0.0;     ///< 旋回半径に対するシフト可能量(0以上。不足していても負にはならず、実旋回半径が増えている。)
        };
        /**
         BP凹角用パラメータ
         */
        struct {
            ConcaveParam left;
            ConcaveParam right;
        } concaveBP;

        /// 終端短縮長
        struct {
            double start = 0.0;
            double end = 0.0;
        } truncateLength;

        /// 終端セグメント最短限界
        struct {
            double start = 0.0;
            double end = 1.0;   ///< 脱出パス脚からの延長量
        } termMin;

        /// 終端前進セグメント合計最短限界
        struct {
            double start = 1.0;
            double end = 10.0;
        } tailForwardMin;

        /// 作業パス動作
        /// ラスター作業パス用のパラメータであるが、作業セグメントに関しては周回作業でも共通。
        struct WorkPath{
            enum class Type {
                RASTER_SWEEP,       ///< ラスター走査(平行作業パス)を使用
                COMBINED_SIMPLEX,   ///< ターン内も作業パスがある(渦巻き)
            } types = Type::RASTER_SWEEP;

            /// ラスター作業パターン
            int pattern = Param::Work::Pattern::BIDIRECTION;
            
            /// 長さ制限
            struct {
                /** 最小作業パス長(ECU都合)
                 これより短い作業パスはensureWorhPath()で非作業パス化する。0.0の場合はこの非作業パス化も当然働かない。
                 */
                double min = 2.0;
                // double max = numeric_limits<int>::max();
                double preserveDummyRide = 1.0;  ///< Type::COMBINED_SIMPLEX のとき、DummyRideパスのままにするパスの最小長さ条件
            } length;

            /**
             オーバーラップ幅

             作業パスのオーバーラップ幅。負の場合は作業工程間の隙間を表す。
             */
            double overlap = 0.0;

            /**
             工程間隔
             
             作業パスの間隔。作業幅からオーバーラップ幅を引いたものであって作業工程間の隙間ではない。
             */
            double interval = 0.0;

            /**
             ヒッチ動作ラグ補償長
             
             ヒッチアップ/ダウン実動作のタイムラグを考慮して作業パスをHP領域外へ延長しておくマージン長(現在は両端共通)
             - 初期値は InputData::WorkSetting::hitchUpDownMargin を受け取る。その後、条件により変化する。
             */
            double compensateLength = 0.0;

            /**
             作業領域長
             行きすぎてからバックすることで平行作業パスの前後を伸ばす(所謂どんつき)
             */
            double expandLength = 0.0;

            /**
             作業パス脚に関連する設定構造体
             */
            struct Leg {
                using Type = WorkSetting::WorkPath::Leg::Type;
                Leg() = default;
                Leg(double pre, double post) :
                    preBackLength(pre),
                    postBackLength(post)
                {}
                double preBackLength = 0.0;
                double postBackLength = 0.0;
            };
            /**
             パス脚の設定
             @note これは作業パスの設定なので、ターンからみた場合脚が前後逆になる
             */
            struct Legs {
                using Type = WorkSetting::WorkPath::Leg::Type;
                int type = Type::STRAIGHT;
                Leg front = {2.0, 0.0};
                Leg rear;
                // 延長処理パラメータ
                double length = 0.0;
                double foldSleshold = 0.2;
                double step = 0.1;
            } leg;
        } workPath;
        
#if USE_OLD_SYSTEM_PARAMESTERS
        /// ターン修飾
        struct TurnModifier {
            double legMargin = 0.2;    ///< パス脚に加えるマージン
            
            /// バックターンの調整値
            WorkSetting::Backturn backturn;
            WorkPath::Leg backturnLeg;
        } turnModifier;
#endif  // USE_OLD_SYSTEM_PARAMESTERS
        
        /// 枕地作業
        struct Headland {
            /// 枕地作業有無
            int process = Param::Work::Headland::Process::NOP;
            /// 枕地作業種類別
            int pattern = Param::Work::Headland::Pattern::ANTICYCLONE;
            /// 枕地周回方向
            int rotation = RotateDirection::ANTICLOCKWISE;
            /// 遷移周回パスの内周マージン
            double transitOrbitMargin = 0.5;
            /// バック可能
            bool permitBackward = true;
            /// 周回パス開始基準辺
            enum class OrbitalOrigin : int {
                BP, ///< 圃場外形
                HP, ///< 平行(ラスター)作業領域
                WP  ///< 作業可能領域
            } orbitalOrigin = OrbitalOrigin::HP;
            double gapMin = 0.0;
            double gapMax = 0.0;
            double infraRaster = 0.0;
            double coverRaster = 0.0;
            struct {
                double headLeg = 0.0;
                double tailLeg = 0.0;
            } workPath;

            struct {
                bool enable = true;
                double lengthStep = 0.1;
                double lengthLimit = 1000.0;
                double preReverseLength = 2.0;
            } whisker;
            
            // 周回辺の取り扱い
            // - 周回の始点・終点を決める際に辺の端点まで使うことにするマージン
            struct {
                // 始点からこの長さまでは始点を使用する(この辺全体を使用する)
                double headSleshold = 5.0;
                // 終点からこの長さまでは終点を使用する(この辺を使わない)
                double tailSleshold = 5.0;
            } orbitalEdge;
            
            const double outerDir() const noexcept { return -rotation; }
            const double innerDir() const noexcept { return rotation; }
        };
        Headland headland;

        WorkSetting::TurnParam turnParam;
        // ターン調整パラメータ
        struct TurnParam {
            TurnParam() = default;
            explicit TurnParam(double leg) :
                fishtail(leg),
                plain(leg),
                alpha(leg)
            {};
            
            void setOption(WorkSetting::TurnParam& param) noexcept;
            
            // フィッシュテールターン
            struct FishTail {
                FishTail() = default;
                FishTail(double leg) :
                    enterLeg(leg),
                    leaveLeg(leg)
                {}
                double enterLeg = 0.0;
                // 進入カーブ後バック前のヨーアライン用準備直進
                double preBackLength = 2.0;
                double leaveLeg = 0.0;
                // 角度探索現界
                // フィッシュテール切り返し傾斜角の最大値。直角を基準(0度)とした相対値。
                double maxAngle = Radian::convert(45.0);
                double maxAngleTan = std::tan(Radian::convert(45.0));   // 念の為初期化。コンストラクタでmaxAngleから計算した値が入る。
            } fishtail;

            // プレーンターン
            struct Plain {
                Plain() = default;
                Plain(double leg) :
                    enterLeg(leg),
                    leaveLeg(leg)
                {}
                double enterLeg = 0.0;
                double leaveLeg = 0.0;
                struct Whisker {
                    double preBackLength = 2.0;
                } backwardWhisker;
            } plain;
            
            // αターン
            struct Alpha {
                Alpha() = default;
                Alpha(double leg) :
                    enterLeg(leg),
                    leaveLeg(leg)
                {}
                double enterLeg = 0.0;
                double preBackLength = 2.0;
                double postBackLength = 0.0;
                double leaveLeg = 0.0;
            } alpha;
        } turn;

        /**
         圃場に関する追加の値
         */
        struct {
            // 凹角あり
            bool hasConcave = false;
        } field;
        
#if USE_OLD_SYSTEM_PARAMESTERS
        /// バックターンのバック前前進長
        ParamLength backturnPreBack;

        /// 作業パス出入口カーブに付加するヒゲの長さ
        struct Whisker {
            double forwardLength = 0.0;
            double forwardLengthMin = 0.0;
            double backwardLength = 0.0;
            double backwardLengthMin = 0.0;
        } whisker;
#endif  // USE_OLD_SYSTEM_PARAMESTERS
    };

    string to_string(const Gauge& gauge);

    string to_string(const Gauge::Dimensions& dim, const string& caption = "");

    struct TRACTOR_ENTIRE {};

    template<typename T>
    string getSvgPathSilhouette(const Gauge& gauge, int index = 0);

    template<>
    string getSvgPathSilhouette<TRACTOR_ENTIRE>(const Gauge& gauge, int index);

    template<typename T>
    Svg::ViewBox getSvgViewBox(const Gauge& gauge, int index = 0);

    template<>
    Svg::ViewBox getSvgViewBox<TRACTOR_ENTIRE>(const Gauge& gauge, int index);

}} // namespace yanmar::PathPlan

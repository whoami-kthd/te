// Yanmar Confidential 20200918
/**
 @file IteratorBinder.cpp
 
 イテレーターユーティリティ
 */

#include "IteratorUtils.hpp"

#include "PathGeneratorError.hpp"

namespace yanmar { namespace PathPlan {

#pragma mark - TriIterator: an iterator for unification 3 boundaries(BP, HP)
#undef LOG_TAG
#define LOG_TAG "PathPlan::TriIterator"
    //
    // TriIterator definitions
    //
    
    /**
     圃場境界データ入力イテレータ
     
     BP,HPの各ポリゴンの頂点を走査しBoundaryを出力するためのイテレータ
     - std::iteratorの要件は完全には満たしていない
     */
    BoundaryInputIterator::BoundaryInputIterator(const Polygon& abp, const Polygon& ahp) :
        bp(abp.begin()),
        hp(ahp.begin())
    {
        if (abp.size() != ahp.size()) {
            ErrorPathGenerator err{ErrorCode::PathGeneration::Boundary::MISMATCH};
            err.setDescription("[EXCEPTION:PATH_GENERATION_MAKE_BOUNDARY] BP and HP polygon was mismatch.", "::TriIterator");
            throw err;
        }
    }
    
    BoundaryInputIterator::BoundaryInputIterator(const Polygon::const_iterator& extents, const Polygon::const_iterator& hlps) :
        bp(extents),
        hp(hlps)
    {}

}} // namespace yanmar::PathPlan

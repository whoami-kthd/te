// Yanmar Confidential 20200918
/**
 @file IteratorUtils.hpp
 
 イテレータ集合操作ユーティリティクラス
 */
#pragma once

#include "PathPlanIF.hpp"

#include "OutLib/OutLib.h"

namespace yanmar { namespace PathPlan {

#pragma mark - IteratorTrain: Provides moves contiguous 3 iterators set as previous, center and next with container boundary.
    /**
     連続した3つの要素を指す集合イテレーター
     
     いずれのイテレーターの位置もコンテナの範囲をはみ出さない移動操作を提供する
     */
    template<typename T>
    class IteratorTrain
    {
    protected:
        using BaseContainer = T;
        using BaseIt = typename BaseContainer::iterator;
        
        using iterator = typename std::array<BaseIt, 3>::iterator;
        using const_iterator = typename std::array<BaseIt, 3>::const_iterator;
        
    public:
        /**
         コンストラクタ
         
         指定コンテナの先頭から三つを指すように初期化する。すなわち、コンテナの[begin() = prev, curr, next .... end()]である。
         - 初期化時に無効な位置のイテレータはend()を指す。
         */
        explicit IteratorTrain(BaseContainer& nodeList) :
            IteratorTrain(nodeList, nodeList.begin())
        {}
        
        /**
         コンストラクタ
         
         指定コンテナの指定位置から三つを指すように初期化する。すなわち、コンテナの[firstIt = prev, curr, next .... end()]である。
         - 初期化時に無効な位置のイテレータはend()を指す。
         */
        IteratorTrain(BaseContainer& nodeList, const BaseIt& firstIt) :
            beginIt(nodeList.begin()), endIt(nodeList.end())
        {
            setIt(firstIt);
        }

    protected:
        /**
         コンストラクタ
         
         派生クラス向け部分初期化
         */
        IteratorTrain(const BaseIt& aBeginIt, const BaseIt& aEndIt) :
            beginIt(aBeginIt), endIt(aEndIt)
        {
            // nop
        }
    
    public:
        // copyable
        IteratorTrain(const IteratorTrain&) = default;
        
        /**
         指定イテレーター位置に初期化
         
         与えられたイテレーターからも三つ連続する位置を指すイテレーターで初期化する。
         - コンストラクタで与えたコンテナを指さないイテレーターを指定した場合の動作は未定義。
         */
        virtual void setIt(const BaseIt& firstIt) {
            BaseIt it = firstIt;
            auto itr = data.begin();
            while (it != endIt && itr != data.end()) {
                *itr = it;
                itr++;
                it++;
            }
            while (itr != data.end()) {
                *itr = endIt;
                itr++;
            }
        }

        /**
         末尾位置設定
         コンテナ末尾の連続する要素を指すように初期化する。
         */
        virtual void setTail() {
            BaseIt it = std::next(beginIt, std::distance(beginIt, endIt) - 2);
            setIt(it);
        }

        /**
         境界検査(末尾)
         
         いずれかのイテレーターがend()であればtrueを返す。
         */
        bool isEnd() const {
            return (std::any_of(data.rbegin(), data.rend(),
                                [this](const BaseIt& it) { return (it == endIt); }));
        }
        
        /**
         境界検査(末尾)
         
         指定イテレーターがend()であればtrueを返す。
         */
        bool isEnd(const BaseIt& it) const { return (it == endIt); }

        /**
         末尾判定
         
         範囲の末尾にを指している場合trueを返す。
         */
        bool isBack() const { return (!isEnd() && isEnd(next(nextIt()))); }

        /**
         末尾判定
         
         指定イテレータが末尾の要素(back())を指す場合trueを返す。
         */
        bool isBack(const BaseIt& it) const { return (!isEnd() && isEnd(next(it))); }
        
        // イテレーター前方移動
        IteratorTrain& operator++() {
            if (!isEnd()) {
                setIt(currIt());
            }
            
            return *this;
        }
        
        // イテレーター前方移動
        IteratorTrain operator++(int) {
            IteratorTrain tmp = *this;
            if (!isEnd()) {
                setIt(currIt());
            }
            
            return tmp;
        }
        
        // イテレーター群のアクセス
        BaseIt& operator[](const size_t i) noexcept {
            return data[i];
        }
        /// 後方イテレーター参照
        const BaseIt& prevIt() const noexcept { return data[0]; }
        /// 中央イテレーター参照
        const BaseIt& currIt() const noexcept { return data[1]; }
        /// 前方イテレーター参照
        const BaseIt& nextIt() const noexcept { return data[2]; }

    protected:
        /// コンテナ有効範囲(先頭)
        BaseIt beginIt;
        /// コンテナ有効範囲(末尾)
        BaseIt endIt;
        /// イテレーター集合の配列
        std::array<BaseIt, 3> data;
    };

#pragma mark - CyclicIteratorTrain: Provides cyclic forward moves to contiguous 3 iterators.
    template<typename T>
    class CyclicIteratorTrain : public IteratorTrain<T> {
        using super = IteratorTrain<T>;
        using BaseContainer = typename super::BaseContainer;
        using BaseIt = typename super::BaseIt;

        using iterator = typename super::iterator;
        using const_iterator = typename super::const_iterator;

    public:
        using IteratorTrain<T>::IteratorTrain;

        /**
         コンストラクタ
         
         指定コンテナの指定位置から三つを指すように初期化する。すなわち、コンテナの[firstIt = prev, curr, next .... end()]である。
         - 初期化時に無効な位置のイテレータはend()を指す。
         */
        CyclicIteratorTrain(BaseContainer& nodeList, const BaseIt& firstIt) :
            super(nodeList.begin(), nodeList.end())
        {
            setIt(firstIt);
        }
        
        /**
         指定イテレーター位置に初期化
         
         与えられたイテレーターからも三つ連続する位置を指すイテレーターで初期化する。
         - コンストラクタで与えたコンテナを指さないイテレーターを指定した場合の動作は未定義。
         */
        virtual void setIt(const BaseIt& firstIt) {
            BaseIt it = firstIt;
            for (auto& itr : super::data) {
                itr = it;
                if (it != super::endIt) {
                    it = nextCyclic(super::beginIt, super::endIt, it);
                }
            }
        }

        /**
         境界検査(末尾)
         
         いずれかのイテレーターがend()であればtrueを返す。
         */
        bool isEnd() const {
            return false;
        }
        
        // イテレーター前方移動
        CyclicIteratorTrain& operator++() {
            for (auto& it : super::data) {
                it = nextCyclic(super::beginIt, super::endIt, it);
            }
            
            return *this;
        }
        
        // イテレーター前方移動
        CyclicIteratorTrain operator++(int) {
            auto tmp = *this;
            ++(*this);
            
            return tmp;
        }
    };

#pragma mark - BounadryInputIterator: an iterator to retrieve Boundary element from BP and HP virtex list.
    /**
     圃場境界データ入力イテレータ
     
     BP,HPの各ポリゴンの頂点を走査しBoundaryを出力するためのイテレータ
     - イテレーターの要件を完全には満たしてはいない
     */
    class BoundaryInputIterator : public std::iterator_traits<std::forward_iterator_tag>
    {
        using Polygon = OutVertexList;

    public:
        using value_type        = Boundary;
        using difference_type   = ptrdiff_t;
        using pointer           = Boundary*;
        using reference         = Boundary&;
        using iterator_category = std::forward_iterator_tag;
        
    public:
        BoundaryInputIterator() = default;
        BoundaryInputIterator(const BoundaryInputIterator&) = default;
        BoundaryInputIterator(const Polygon& abp, const Polygon& ahp);
        BoundaryInputIterator(const Polygon::const_iterator& extents, const Polygon::const_iterator& hlps);
        
        Polygon::const_iterator bp;
        Polygon::const_iterator hp;
        
        Polygon::value_type bpValue() const {
            return *bp;
        }
        
        Polygon::value_type hpValue() const {
            return *hp;
        }
        
        BoundaryInputIterator& operator+=(difference_type n) {
            bp += n;
            hp += n;
            return *this;
        }
        
        BoundaryInputIterator& operator++() {
            bp++;
            hp++;
            return *this;
        }

        BoundaryInputIterator operator++(int) {
            auto tmp = *this;
            bp++;
            hp++;
            return tmp;
        }

        Boundary boundary(int bndFlg, int nodeIndex) const {
            return Boundary{*bp, *hp, bndFlg, nodeIndex};
        }
        
    private:
        value_type operator*() const = delete;
    };
    
    inline bool operator==(const BoundaryInputIterator& lhs, const BoundaryInputIterator& rhs) {
        return (lhs.bp == rhs.bp);
    }
    
    inline bool operator!=(const BoundaryInputIterator& lhs, const BoundaryInputIterator& rhs) {
        return !(lhs == rhs);
    }

}} // namespace yanmar::PathPlan

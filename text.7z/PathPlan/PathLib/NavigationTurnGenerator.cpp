// Yanmar Confidential 20200918
/**
 @file NavigationTurnGenerator.cpp

 PathGeneartorクラス実装ファイル(PathLib.cppの一部)
 
 ナビゲーションパス生成処理
 */

/// @internal @defgroup PathGenerator  PathGenerator interface

//#define LOGLEVEL 5

#include "PolyLib/Common.h"
#include "PathLib.h"

#include <cstdlib>
#include <string>
#include <stdexcept>
#include <ostream>
#include <utility>
#include <algorithm>

#include "PolyLib/PolygonUtil.hpp"
#include "DataConverter/OutputDataStream.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

using namespace Param::Path;
using namespace SegmentType;
using namespace VertexType;
using namespace RotateDirection;
using namespace ResultCode;
using namespace PathGeneratorData;

namespace PathParam = yanmar::PathPlan::Param::Path;    // Segmentなどが曖昧になるため識別用

//
// PathGenerator definition
//
#pragma mark - PathGenerator:: Navigation path creation
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathGenerator"

/**
 FPSターンパス最適化
 
 FPSから指定のサークルに渡るターンパスを生成して返す。
	- 必要があれば補助サークルを追加して切り返す
		- 補助サークルを使用してもHCPに追加しない(追加するとインデックスが狂う)

 @param[in] index 現ターンサークルを指すHTCインデックス

 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeFpsTurnPath(int index) {
	LOGV(LOG_TAG "::optimizeFpsTurnPath", "(HCP[FPS] -> HCP[%d])", index);
    auto& HCP = traverseInfo.HCP;

    if (index <= HCP.fpsIndex()) {
        // インデックス不正
		ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
		err.setDescription("[ASSERT] invalid index", "optimizeFpsTurnPath()");
		throw err;
	}
    
    if (index == HCP.spsIndex()) {
        // 対SPSを許容しない(optimizeFpsSpsTurnPath()を使うこと)
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid index(SPS)", "optimizeFpsTurnPath()");
        throw err;
    }
    
    TurnPath turnPath;

	HeadlandTurnCircle& nextHtc = HCP[index];
	const Circle& nextCirc = nextHtc.Circ;
	PathFPS tmpFPS = traverseInfo.fps;
	Circle& currCirc = tmpFPS.Circ;

	LOGV(LOG_TAG "::optimizeFpsTurnPath", "traverse HCP[FPS]%s -> HCP[%d]%s", to_string(currCirc).c_str(), index, to_string(nextCirc).c_str());
    if (currCirc.checkIntersection(nextCirc) != Intersection::NO) {
		LOGD(LOG_TAG "::optimizeFpsTurnPath", "HTC(%d) overlap.", nextHtc.nodeIndex);
		// ターンサークルが重なっている
        if (currCirc.orient == nextCirc.orient) {
            LOGD(LOG_TAG "::optimizeFpsTurnPath", "[INFO] Turn circles are collides and has same orient.");
			// 回転が同じ
			// FPSパスから半径内のターンサークルはフィッシュテールを作る(バック可の場合のみ)
            const int tangentDir = getTangentDirection(tmpFPS.getPoint(), tmpFPS.Circ, nextCirc);
            LOGD(LOG_TAG "::optimizeFpsTurnPath", "tangentDir:%d", tangentDir);
            // パスから半径内のターンサークルは再配置する
            if (!gauge.permitBackward || (tangentDir != TangentDir::REVERSE)) {
                // 前進する
                turnPath = pathAssembler.getValidatedPath(tmpFPS, nextCirc);
            } else {
                // フィッシュテールを作る(バック可の場合のみ)
                turnPath = pathAssembler.getValidatedPath(tmpFPS, nextCirc, gauge.turn.fishtail.preBackLength);
            }
        } else {
            LOGD(LOG_TAG "::optimizeFpsTurnPath", "[INFO] Turn circles are collides and has against orient.");
            turnPath.invalidate();
        }
	} else {
		// ターンサークルが遠い場合
		LOGD(LOG_TAG "::optimizeFpsTurnPath", "HTC(%d) no overlap.", nextHtc.nodeIndex);
        turnPath = pathAssembler.getValidatedPath(tmpFPS, nextCirc);
	}

    if (!turnPath.isValid()) {
        if (!gauge.permitBackward) {
            // バック不可
            LOGD(LOG_TAG "::optimizeFpsTurnPath", "[COMPACTION] aux turn circle was not capable.");
        } else {
            // コンパクション試行
            // - 補助サークル取得
            tmpFPS.setAuxTurnCircle(true);
            Circle auxCirc = tmpFPS.getAuxTurnCircle();
            LOGD(LOG_TAG "::optimizeFpsTurnPath", "[COMPACTION] Insert aux turn circle:%s", to_string(auxCirc).c_str());
            turnPath = pathAssembler.getValidatedPath(tmpFPS, auxCirc, nextCirc);
        }
    }

    if (turnPath.isValid()) {
        LOGD(LOG_TAG "::optimizeFpsTurnPath", "[INFO] Valid");
        // 成功したのでFPS更新
        traverseInfo.fps = tmpFPS;
        HCP.update(tmpFPS);
    } else {
		LOGV(LOG_TAG "::optimizeFpsTurnPath", "no valid tangent from FPS leaving turn arc.");
	}

	return turnPath;
}

/**
 FPSターンパス最適化(開始ナビゲーション)
 
 開始ナビゲーションのFPSから指定のサークルに渡るターンパスを生成して返す。
 
 @param[in] index 現ターンサークルを指すHTCインデックス
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeFpsSpsTurnPath(int index) {
    LOGV(LOG_TAG "::optimizeFpsSpsTurnPath", "(HCP[FPS] -> HCP[%d(SPS)])", index);
    auto& HCP = traverseInfo.HCP;

    if (index <= HCP.fpsIndex()) {
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid index", "optimizeFpsTurnPath()");
        throw err;
    }

    if (index != HCP.spsIndex()) {
        // 対コーナーを許容しない(optimizeFpsTurnPath()を使うこと)
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid index(not SPS)", "optimizeFpsTurnPath()");
        throw err;
    }
    TurnPath turnPath;
    
    const HeadlandTurnCircle& nextHtc = HCP[index];
    const Circle& nextCirc = nextHtc.Circ;
    PathFPS tmpFPS = traverseInfo.fps;
    Circle& currCirc = tmpFPS.Circ;
    PathSPS tmpSPS = traverseInfo.sps;
    
    LOGV(LOG_TAG "::optimizeFpsSpsTurnPath", "traverse HCP[FPS]%s -> HCP[%d]%s", to_string(currCirc).c_str(), index, to_string(nextCirc).c_str());
    if (currCirc.checkIntersection(nextCirc) != Intersection::NO) {
        LOGD(LOG_TAG "::optimizeFpsSpsTurnPath", "HTC(%d) overlap.", nextHtc.nodeIndex);
        // ターンサークルが重なっている
        const int tangentDir = getTangentDirection(tmpFPS.getPoint(), tmpFPS.Circ, nextCirc);
        if (!gauge.permitBackward || (tangentDir != TangentDir::REVERSE)) {
            // 前進する
            turnPath = pathAssembler.getValidatedPathForward(tmpFPS, tmpSPS);
        } else {
            LOGD(LOG_TAG "::optimizeFpsSpsTurnPath", "[INFO] Turn circles are collides and has same orient.");
            // フィッシュテールを作る(バック可の場合のみ)
            // - 通常ターンの試行後なのでここでは足の長さを揃えない
            turnPath = pathAssembler.getValidatedPathReverse(tmpFPS, tmpSPS);
        }
    } else {
        // ターンサークルが遠い場合
        LOGD(LOG_TAG "::optimizeFpsSpsTurnPath", "HTC(%d) no overlap.", nextHtc.nodeIndex);
        turnPath = pathAssembler.getValidatedPathForward(tmpFPS, tmpSPS);
    }
    
    if (!turnPath.isValid()) {
        if (!gauge.permitBackward) {
            // コンパクション不可
            LOGD(LOG_TAG "::optimizeFpsSpsTurnPath", "[WARN] aux turn circle was not capable.");
        } else {
            // コンパクション試行
            Vector2D delta(tmpFPS.getPoint(), tmpSPS.getPoint());
            delta.abs();
            const double pathGap = delta.x;
            if (delta.y < pathGap) {
                // ほぼ水平の場合はコンパクトにならない
                // TODO: 条件の高精度化
                // - 実際にコンパクトになるかどうかをチェックできればベスト
                LOGD(LOG_TAG "::optimizeFpsSpsTurnPath", "[WARN] compaction was no effect. points were too close: %g / %g", delta.x, delta.y);
            } else {
                // - 補助サークル取得
                const int pth = (tmpFPS.leavePoint().y < tmpSPS.enterPoint().y) ? -tmpFPS.dir : tmpFPS.dir;
                // FPS-SPS間なのでターンサークルフリップの代わりに幅を考慮した補助ターンサークル位置で試す(フリップは外側から)
                double turnDistance = gauge.turnRadius;
                if (gauge.turnRadius < (pathGap - TOL_ONE_CM)) {
                    turnDistance += (gauge.turnRadius - pathGap + TOL_ONE_CM);
                }
                if (pth == 1) {
                    tmpFPS.setAuxTurnCircle(true, turnDistance);
                    LOGD(LOG_TAG "::optimizeFpsSpsTurnPath", "Insert FPS aux turn circle:%s", to_string(tmpFPS.getAuxTurnCircle()).c_str());
                } else {
                    tmpSPS.setAuxTurnCircle(true, turnDistance);
                    LOGD(LOG_TAG "::optimizeFpsSpsTurnPath", "Insert SPS aux turn circle:%s", to_string(tmpSPS.getAuxTurnCircle()).c_str());
                }
                turnPath = pathAssembler.getValidatedPathReverse(tmpFPS, tmpSPS);
            }
        }
    }
    
    if (turnPath.isValid()) {
        // 成功したのでSPS更新
        traverseInfo.sps = tmpSPS;
        // 成功したのでFPS更新
        traverseInfo.fps = tmpFPS;
        HCP.update(tmpFPS);
        HCP.update(tmpSPS);
    } else {
        LOGV(LOG_TAG "::optimizeFpsSpsTurnPath", "no valid tangent from FPS leaving turn arc.");
    }
    
    return turnPath;
}
    
/**
 FPS-SPSターンパス最適化(終了ナビゲーション)
 
 終了ナビゲーションのFPSからSPS渡る終了ナビゲーションパスを生成して返す。
    - 終端なのでSPSへは進入点に向かって接線を引く
 
 @param[in] index 現ターンサークルを指すHTCインデックス
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeFpsSpsTurnPathEndNav(int index) {
    LOGV(LOG_TAG "::optimizeFpsSpsTurnPathEndNav", "(HCP[FPS] -> HCP[%d(SPS)])", index);
    auto& HCP = traverseInfo.HCP;
    
    if (index <= HCP.fpsIndex()) {
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid index", "optimizeFpsTurnPath()");
        throw err;
    }
    
    if (index != HCP.spsIndex()) {
        // 対コーナーを許容しない(optimizeFpsTurnPath()を使うこと)
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid index(not SPS)", "optimizeFpsTurnPath()");
        throw err;
    }
    
    const PathFPS tmpFPS = traverseInfo.fps;
    const PathSPS tmpSPS = traverseInfo.sps;
    
    LOGV(LOG_TAG "::optimizeFpsSpsTurnPathEndNav", "traverse HCP[FPS]%s -> HCP[%d](SPS)%s", to_string(tmpFPS.Circ).c_str(), index, to_string(tmpSPS.Circ).c_str());
    TurnPath turnPath = optimizeFpsTurnPathHalfway(tmpFPS, tmpSPS.getPoint());
    
    if (turnPath.isValid()) {
        LOGV(LOG_TAG "::optimizeFpsTurnPathStartNav", "Valid Navigation path.");
        // 成功したのでSPS更新
        traverseInfo.sps = tmpSPS;
        // 成功したのでFPS更新
        traverseInfo.fps = tmpFPS;
        HCP.update(tmpFPS);
        HCP.update(tmpSPS);
        // FPS-SPS 間なので成功
    } else {
        LOGV(LOG_TAG "::optimizeFpsSpsTurnPathEndNav", "no valid tangent from FPS leaving turn arc.");
        // クリアして返さないと途中までで使用される
        turnPath.clear();
    }
    
    return turnPath;
}

/**
 FPSターンパス最適化(開始ナビゲーション)
 
 開始ナビゲーションのFPSから指定のサークルに渡るターンパスを生成して返す。
 
 @param[in] index 現ターンサークルを指すHTCインデックス
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeFpsTurnPathStartNav(int index) {
    LOGV(LOG_TAG "::optimizeFpsTurnPathStartNav", "(HCP[FPS] -> HCP[%d])", index);
    auto& HCP = traverseInfo.HCP;
    
    if (index <= HCP.fpsIndex()) {
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid index", "optimizeFpsTurnPath()");
        throw err;
    }
    
    TurnPath turnPath;
    
    const HeadlandTurnCircle& nextHtc = HCP[index];
    const Circle& nextCirc = nextHtc.Circ;
    PathFPS tmpFPS = traverseInfo.fps;
    Circle& currCirc = tmpFPS.Circ;
    PathSPS tmpSPS = traverseInfo.sps;
    
    LOGV(LOG_TAG "::optimizeFpsTurnPathStartNav", "traverse HCP[FPS]%s -> HCP[%d]%s", to_string(currCirc).c_str(), index, to_string(nextCirc).c_str());
    if (currCirc.checkIntersection(nextCirc) != Intersection::NO) {
        LOGD(LOG_TAG "::optimizeFpsTurnPathStartNav", "HTC(%d) overlap - start navigation will be retry.", nextHtc.nodeIndex);
        // ターンサークルが重なっている
        // 開始ナビゲーションなので失敗させる(上からリトライする)
        return turnPath;
    }
    
    // ターンサークルが遠い場合
    LOGD(LOG_TAG "::optimizeFpsTurnPathStartNav", "HTC(%d) no overlap.", nextHtc.nodeIndex);

    // 開始ナビゲーションの開始点からのパス
    const PathAssembler::EndPoint startPoint{tmpFPS.getPoint()};
    if (index == HCP.spsIndex()) {
        turnPath = pathAssembler.getValidatedPath(startPoint, tmpSPS);
        if (turnPath.status == PathGenerator::FAILURE_TERM_END) {
            traverseInfo.truncation.disableHead();
        }
    } else {
        turnPath = pathAssembler.getValidatedPath(startPoint, nextCirc);
    }
    
    if (turnPath.isValid()) {
        LOGV(LOG_TAG "::optimizeFpsTurnPathStartNav", "Valid start Navigation path.");
        if (index == HCP.spsIndex()) {
            // 成功したのでSPS更新
            traverseInfo.sps = tmpSPS;
        }
        // 成功したのでFPS更新
        traverseInfo.fps = tmpFPS;
        HCP.update(tmpFPS);
        HCP.update(tmpSPS);
    } else {
        LOGV(LOG_TAG "::optimizeFpsTurnPathStartNav", "no valid tangent from FPS leaving point.");
    }
    
    return turnPath;
}

/**
 FPSターンパス最適化(終了ナビゲーション)
 
 終了ナビゲーションのFPSから指定のサークルに渡るターンパスを生成して返す。
 
 @param[in] index 現ターンサークルを指すHTCインデックス
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeFpsTurnPathEndNav(int index) {
    LOGV(LOG_TAG "::optimizeFpsTurnPathEndNav", "(HCP[FPS] -> HCP[%d])", index);

    TurnPath turnPath = optimizeFpsTurnPath(index);
    if (turnPath.isValid()) {
        LOGD(LOG_TAG "::optimizeFpsTurnPathEndNav", "[INFO] Valid");
        return turnPath;
    }

    // 失敗したらコーナー進入点を終点として引いてみる
    const auto lastTS = turnPath.getLastTangent();
    turnPath.clear();

    const PathFPS& tmpFPS = traverseInfo.fps;

    LOGD(LOG_TAG "::optimizeFpsSpsTurnPathEndNav", "traverse HCP[FPS]%s -> HCP[%d] halfway end:%s", to_string(tmpFPS.Circ).c_str(), index, to_string(lastTS.point2()).c_str());
    turnPath = optimizeFpsTurnPathHalfway(tmpFPS, lastTS.point2());
    if (turnPath.isValid()) {
        LOGD(LOG_TAG "::optimizeFpsTurnPathEndNav", "[INFO] Valid halfway.");
        // 失敗は失敗である
        turnPath.invalidate();
    } else {
        LOGV(LOG_TAG "::optimizeFpsTurnPathEndNav", "no valid tangent from FPS leaving turn arc.");
        // クリアして返さないと途中までで使用される
        assert(turnPath.empty());
    }
    
    return turnPath;
}

/**
 FPSターンパス取得(終了ナビゲーション終端)
 
 FPSから指定点に渡る終了ナビゲーション終端のターンパスを生成して返す。
 
 @param[in] fps FPS
 @param[in] destPoint 終了ナビゲーション終点
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeFpsTurnPathHalfway(const PathFPS& fps, const XY_Point& destPoint) {
    LOGD(LOG_TAG "::getTurnPath", "(FPS, %s)", to_string(destPoint, "endpoint:").c_str());
    TurnPath turnPath;
    const Circle& currCirc = fps.Circ;
    
    if (currCirc.checkIntersection(destPoint) != Intersection::NO) {
        LOGD(LOG_TAG "::getTurnPath", "destPoint overlap. FPS - minimal end navigation.");
        // 終端がターンサークル内
        // - FPS脚までを期待しているのでここで最小ナビゲーションパスを返したりしてはいけない。
        return turnPath;
    }
    
    // ターンサークルが遠い場合
    LOGD(LOG_TAG "::getTurnPath", "destPoint not overlap. End navigation FPS to end point.");
    const PathAssembler::EndPoint endPoint{destPoint};
    turnPath = pathAssembler.getValidatedPath(fps, endPoint);
    if (!turnPath.isValid()) {
        if (!gauge.permitBackward) {
            // コンパクション不可
            LOGD(LOG_TAG "::getTurnPath", "[WARN] aux turn circle was not capable.");
        } else {
            // コンパクション試行
            // - 補助サークル取得
            LOGD(LOG_TAG "::getTurnPath", "END_NAV: Insert FPS aux turn circle:%s", to_string(fps.getAuxTurnCircle()).c_str());
            const auto auxCirc = fps.getAuxTurnCircle();
            const PathAssembler::EndPoint endPoint{destPoint};
            turnPath = pathAssembler.getValidatedPath(fps, auxCirc, endPoint);
        }
    }

    if (!turnPath.isValid()) {
        turnPath.clear();
    }
    
    return turnPath;
}

/**
 SPSターンパス最適化
 
 indexで指定されたHCPからSPSへ渡るターンパスを生成して返す。
	- 必要があれば補助サークルを追加して切り返す
		- 補助サークルを使用してもHCPに追加しない(追加するとインデックスが狂う)
	- 指定ターンサークルとSPSターンサークルでフィッシュテールが形成されるときは、SPS側のターンサークル位置を現ターンサークルへ揃えようとする。
		- 配置により揃えられない場合がある
	- 現ターンサークルはフリップする場合がある。その場合、pathBufferの最後のセグメント(進入接線)を更新する。

 @note indexがFPSターンサークル(=0)の場合には対応していない。FPS側で処理されるはずである。
 
 @param[in, out]    eTS 現ターンサークル進入接線
 @param[in] index   現ターンサークルを指すHTCインデックス

 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeSpsTurnPath(LineSegment& eTS, int index) {
    auto& HCP = traverseInfo.HCP;
	LOGV(LOG_TAG "::optimizeSpsTurnPath", "(HCP[%d] -> HCP[SPS(%d)])", index, HCP.spsIndex());
    
	if (index <= HCP.fpsIndex() || index == HCP.spsIndex()) {
		ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
		err.setDescription("[ASSERT] invalid index", "optimizeSpsTurnPath()");
		throw err;
	}

	TurnPath turnPath;
	HeadlandTurnCircle& currHtc = HCP[index];
	Circle currCirc = currHtc.Circ;
	PathSPS tmpSPS = traverseInfo.sps;
	Circle& nextCirc = tmpSPS.Circ;
	
	LOGV(LOG_TAG "::optimizeSpsTurnPath", "current %s - next %s", to_string(currCirc).c_str(), to_string(nextCirc).c_str());
    if (currCirc.checkIntersection(nextCirc) != Intersection::NO) {
		LOGD(LOG_TAG "::optimizeSpsTurnPath", "HTC(%d) overlap.", currHtc.nodeIndex);
		// ターンサークルが重なっている
		if (currCirc.orient == nextCirc.orient) {
			// 回転が同じ
            const int tangentDir = getTangentDirection(eTS.point2(), currCirc, nextCirc);
            LOGD(LOG_TAG "::optimizeSpsTurnPath", "tangentDir:%d", tangentDir);
            // 接線を引いてみる
            // - コーナー脱出接線を引いてみる
            PathSegment PS = getTangent(eTS, currCirc, nextCirc, tangentDir);
            if (PS.isValid()) {
                // 進入接線との交差があれば両接線とターンサークルが更新される
                // - ここでのフリップは進入時点のeTSの確定用
                LineSegment TS = PS;
                flipTurnCircle(currCirc, eTS, TS);
                if (tangentDir != TangentDir::REVERSE) {
                    turnPath = pathAssembler.getValidatedPath(eTS, currCirc, TS, tmpSPS);
                } else if (gauge.permitBackward) {
                    turnPath = pathAssembler.getValidatedPath(eTS, currCirc, tmpSPS);
                } else {
                    LOGD(LOG_TAG "::optimizeSpsTurnPath", "[INFO] failed by inhibit backward.");
                    turnPath.invalidate();
                }
            } else {
                LOGD(LOG_TAG "::optimizeSpsTurnPath", "[INFO] no valid tangent");
            }
        } else {
            // 回転が逆のターンサークルと重なってはいけない
            LOGD(LOG_TAG "::optimizeSpsTurnPath", "[INFO] Turn circles collided and has against orient.");
            turnPath.invalidate();
        }
	} else {
        // ターンサークルが遠い場合
        LOGD(LOG_TAG "::optimizeSpsTurnPath", "HTC(%d) no overlap.", currHtc.nodeIndex);
        
        // コーナーからSPSサークルの間でパスを引いてみる
        // - コーナー脱出接線を引いてみる
        PathSegment PS = getTangent(eTS, currCirc, nextCirc, TangentDir::FORWARD);
        if (PS.isValid()) {
            LineSegment lTS = PS;
            // ターンパス取得
            // - currCircをフリップする可能性がある、その場合、eTSも変更される。lTSは出力に含まれるので変更されない。
            turnPath = pathAssembler.getValidatedPath(eTS, currCirc, lTS, tmpSPS);
        } else {
            LOGD(LOG_TAG "::optimizeSpsTurnPath", "[INFO] no valid tangent");
            turnPath.invalidate();
        }
    }

    if (!turnPath.isValid()) {
        // 失敗した場合
        // - コンパクションしてみる
        if (!gauge.permitBackward) {
            LOGD(LOG_TAG "::optimizeSpsTurnPath", "[COMPACTION] aux turn circle was not capable.");
            turnPath.invalidate();
        } else {
            currCirc = currHtc.Circ;
            tmpSPS.setAuxTurnCircle(true);
            Circle auxCirc = tmpSPS.getAuxTurnCircle();
            // 行き先が補助ターンサークルに変わったので進入接線の再算出が必要
            PathSegment PS = getTangent(eTS, currCirc, auxCirc);
            if (!PS.isValid()) {
                LOGD(LOG_TAG "::optimizeSpsTurnPath", "[COMPACTION] no valid tangent.");
                turnPath.invalidate();
            } else {
                LineSegment iTS = PS;
                if (!tmpSPS.isFishtailAvailable(iTS)) {
                    LOGD(LOG_TAG "::optimizeSpsTurnPath", "[COMPACTION] insafficient turn angle.\n %s\n %s\n DP:%g, CP:%g, orient:%d",
                                                                to_string(eTS, "eTS    :").c_str(), to_string(tmpSPS.getSegmentWithLeg(), "SPS+LEG:").c_str(),
                                                                iTS.getDotProduct(tmpSPS.getSegmentWithLeg()), iTS.getCrossProduct(tmpSPS.getSegmentWithLeg()), tmpSPS.Circ.orient);
                    turnPath.invalidate();
                } else {
                    LOGD(LOG_TAG "::optimizeSpsTurnPath", "[COMPACTION] Insert aux turn circle:%s", to_string(auxCirc).c_str());
                    // 進入接線との交差があれば両接線とターンサークルが更新される
                    flipTurnCircle(currCirc, eTS, iTS);
                    turnPath = pathAssembler.getValidatedPath(eTS, currCirc, iTS, auxCirc, tmpSPS);
                }
            }
        }
    }
	
    if (turnPath.isValid()) {
        LOGD(LOG_TAG "::optimizeSpsTurnPath", "Valid turn path.");
        // 成功
        // フリップしたかもしれないcurrCircに更新
        currHtc.Circ = currCirc;
        pathSpanStack.updateTurnPathLast(eTS.point2(), currCirc);
        turnPath.terminate();
        HCP[index].Circ = currCirc;
        // 成功したのでSPS更新
        traverseInfo.sps = tmpSPS;
        HCP.update(tmpSPS);
    } else {
		LOGV(LOG_TAG "::optimizeSpsTurnPath", "no valid tangent to SPS entering turn arc.");
	}
	
	return turnPath;
}

/**
 SPSターンパス最適化(開始ナビゲーション開始)
 
 indexで指定されたHCPから始まり、SPSへ渡るターンパスを生成して返す。
 - index位置のカーブセグメントは含まない
 - 必要があればSPSに補助サークルを追加して切り返す
    - 補助サークルを使用してもHCPに追加しない(追加するとインデックスが狂う)
 
 @note indexがFPS(開始点)の場合には対応していない。FPS側で処理されるはずである。
 
 @param[in] index 現ターンサークルを指すHTCインデックス
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeSpsTurnPathStart(int index) {
    auto& HCP = traverseInfo.HCP;
    LOGV(LOG_TAG "::optimizeSpsTurnPathStart", "(HCP[%d] -> HCP[SPS(%d)])", index, HCP.spsIndex());
    
    if (index <= HCP.fpsIndex() || index == HCP.spsIndex()) {
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid index", "optimizeSpsTurnPathStart()");
        throw err;
    }
    
    TurnPath turnPath;
    const HeadlandTurnCircle& currHtc = HCP[index];
    const Circle& currCirc = currHtc.Circ;
    PathSPS tmpSPS = traverseInfo.sps;
    Circle& nextCirc = tmpSPS.Circ;
    
    LOGV(LOG_TAG "::optimizeSpsTurnPathStart", "current %s - next %s", to_string(currCirc).c_str(), to_string(nextCirc).c_str());
    PathSegment PS = getTangent(currCirc, nextCirc, TangentDir::FORWARD);
    if (PS.isValid()) {
        // この接線で開始してみる
        const PathAssembler::EndPoint startPoint{PS.point1()};
        turnPath = pathAssembler.getValidatedPath(startPoint, tmpSPS);
        if (turnPath.status == PathGenerator::FAILURE_TERM_END) {
            traverseInfo.truncation.disableHead();
        }
    } else {
        // 接線が引けない
        LOGD(LOG_TAG "::optimizeSpsTurnPathStart", "[INFO] no valid tangent.");
        turnPath.invalidate();
    }
   
    return turnPath;
}

/**
 SPSターンパス最適化(終了ナビゲーション)
 
 indexで指定されたHCPからSPS進入点へ向かう直線パスを生成して返す。
	- 終了ナビゲーションの終端生成用なのでSPSターンサークルは使用せず、SPSカーブ以降は生成しない。
	- 現ターンサークルはフリップする場合がある。その場合、pathBufferの最後のセグメント(進入接線)を更新する。
	- indexがFPSの場合は対応していない。(assert)

 @param[in] eTS 現ターンサークル進入接線
 @param[in] index 現ターンサークルを指すHTCインデックス
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeSpsTurnPathEnd(const LineSegment& eTS, int index) {
	LOGV(LOG_TAG "::optimizeSpsTurnPathEnd", "(%d)", index);
    auto& HCP = traverseInfo.HCP;
    
    if (index <= HCP.fpsIndex() || index == HCP.spsIndex()) {
		ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
		err.setDescription("[ASSERT] invalid index", "optimizeSpsTurnPathEnd()");
		throw err;
	}

	XY_Point enterPoint = eTS.point2();
	TurnPath turnPath;
	HeadlandTurnCircle& currHtc = HCP[index];
	Circle currCirc = currHtc.Circ;
    PathSPS tmpSPS = traverseInfo.sps;
	Circle& nextCirc = tmpSPS.Circ;
	
	LOGV(LOG_TAG "::optimizeSpsTurnPathEnd", "current %s - next %s", to_string(currCirc).c_str(), to_string(nextCirc).c_str());
	if (currCirc.checkIntersection(nextCirc) != Intersection::NO) {
		LOGD(LOG_TAG "::optimizeSpsTurnPathEnd", "HTC(%d) overlap.", currHtc.nodeIndex);
		// ターンサークルが重なっている
        // - 失敗で返す(前のspanの末尾短縮は別途必要)
        turnPath.invalidate();
	} else {
		// ターンサークルが遠い場合
		LOGV(LOG_TAG "::optimizeSpsTurnPathEnd", "HTC(%d) no overlap.", currHtc.nodeIndex);
		
		// コーナーからSPSへのパスを引いてみる
		// - コーナー進入接線
		LineSegment eTS2 = eTS;
		// - コーナー脱出接線を引いてみる
        PathSegment PS = getTangent(eTS2, currCirc, nextCirc, TangentDir::FORWARD);
        if (PS.isValid()) {
            // 進入接線との交差があれば両接線とターンサークルが更新される
            // - ここでのフリップは進入時点のeTSの確定用
            LineSegment lTS = PS;
            flipTurnCircle(currCirc, eTS2, lTS);
            // ターンパス取得
            PathAssembler::EndPoint endPoint{tmpSPS.enterPoint()};
            turnPath = pathAssembler.getValidatedPath(eTS2, currCirc, endPoint);
        } else {
            LOGV(LOG_TAG "::optimizeSpsTurnPathEnd", "no valid tangent.");
        }
    
		if (turnPath.isValid()) {
			// 成功
            // フリップされたかもしれないcurrCircに更新
            currHtc.Circ = currCirc;
            pathSpanStack.updateTurnPathLast(eTS2.point2(), currCirc);
			LOGV(LOG_TAG "::optimizeSpsTurnPathEnd", "SPS - end of end navigation");
        }
    }
	
	if (turnPath.isValid()) {
        // 成功したのでSPS更新
        traverseInfo.sps = tmpSPS;
        HCP.update(tmpSPS);
    } else {
		LOGV(LOG_TAG "::optimizeSpsTurnPathEnd", "no valid tangent to SPS.");
	}
	
	return turnPath;
}

/**
 HP脱出脚長設定(FPS)
 
 FPS作業パス脚の最小脱出長を設定する
 - 最小脱出長とはgetEscapeLength()で得られる長さ
 - 最小長とはgauge.minFpsLeglength
 
 @note
 パスから辺との角度の小さい側へ旋回したとき、次の接線(作業パス - コーナー間の接線)でEHPを踏む場合が多くなるため、
 パス脚の終端位置でEHPを完全に脱出するまで脚を伸ばし、接線をHP辺からなるべく離す。
 - パス脚の長さは、実効幅でHPを踏まない長さが理想であるが、上限は次のHPコーナーと並ぶまでである。すでに調整済みの可能性もあるので短縮はしない。
 - 角度の大きい向きの旋回では基本的に発生しないはずであるし、枕地幅が不足する可能性が高いので何もしない。

 @return 処理結果
 @retval SUCCESS    HP脱出長に設定
 @retval FAILURE    最小パス脚長に設定
 */
int PathGenerator::setEscapeLeg(PathFPS& fps) {
    const double minLen = fps.leg.minLength;
    double reqLen = fps.leg.minLength;
    Vector2D vl = fps.getVector();
    Vector2D vhtp = fps.getNextCornerVector();
    if (vl.getDotProduct(vhtp) < 0.0) {
        // FPSから出て旋回角が小さい方のターン
        const double nextCornerLen = abs(vhtp.y);
        const double maxLen = max(minLen, nextCornerLen);
        const double minEscapeLen = fps.getEscapeLength(gauge.halfActWidth);
        LOGD(LOG_TAG "::setEscapeLeg(FPS)", "FPS ESCAPE LEG LENGTH: clip(%g, %g, %g)", minLen, minEscapeLen, maxLen);
        reqLen = clip(minLen, minEscapeLen, maxLen);
    }

    fps.setHeadLeg(reqLen);
    fps.extended = (minLen < reqLen);
    
    return (fps.extended) ? SUCCESS : FAILURE;
}

/**
 HP脱出脚長設定(SPS)
 
 SPS作業パス脚の最小脱出長を設定する
 @see setEscapeLeg(PathFPS& fps)

 @return 処理結果
 @retval SUCCESS    HP脱出長に設定
 @retval FAILURE    最小パス脚長に設定
 */
int PathGenerator::setEscapeLeg(PathSPS& sps) {
    const double minLen = sps.leg.minLength;
    double reqLen = sps.leg.minLength;
    sps.extended = false;

    Vector2D vl = sps.getVector();
    Vector2D vhtp = sps.getPrevCornerVector();
    if (0.0 < vl.getDotProduct(vhtp)) {
        // SPSへ入る旋回角が小さい方のターン
        const double nextCornerLen = abs(vhtp.y);
        const double maxLen = max(minLen, nextCornerLen);
        const double minEscapeLen = sps.getEscapeLength(gauge.halfActWidth);
        LOGD(LOG_TAG "::setEscapeLeg(SPS)", "SPS ESCAPE LEG LENGTH: clip(%g, %g, %g)", minLen, minEscapeLen, maxLen);
        reqLen = clip(minLen, minEscapeLen, maxLen);
    }
 
    sps.setHeadLeg(reqLen);
    sps.extended = (minLen < reqLen);

    return (sps.extended) ? SUCCESS : FAILURE;
}

/**
 スキップターンサークルリスト初期化
 
 ターンパス両端のパス脚(FPS/SPSの脚)で到達できるターンサークルのリストを生成する。
 */
void PathGenerator::initHcpSkipList(HLTCList& hcp, PathFPS& fps, PathSPS& sps) {
    
    if (gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
        gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE) {
        // オフセット作業機(回り耕、すなわち草刈機の場合のみ)
        // - 平行作業パスセグメント端調整のためナビゲーションパス生成のエラーになる場合を区別する
        // パス脚を元の位置から生やして計測する
        auto fps1 = fps;
        fps1.leg.minLength += fps1.leg.orgLength + TOL_ZERO_PNT_ONE_CM;
        auto sps1 = sps;
        sps1.leg.minLength += sps1.leg.orgLength + TOL_ZERO_PNT_ONE_CM;

        sps1.setMinimalLeg();
        hcp.update(sps1);
        
        // FPS脚を伸ばして届くターンサークルをリストアップ
        prepareSkipTurnCircle(hcp, fps1, sps1);

        fps1.setMinimalLeg();
        hcp.update(fps1);

        // SPS脚を伸ばして届くターンサークルをリストアップ
        prepareSkipTurnCircle(hcp, sps1, fps1);
    }

    sps.setMinimalLeg();
    hcp.update(sps);
    
    // FPS脚を伸ばして届くターンサークルをリストアップ
    prepareSkipTurnCircle(hcp, fps, sps);

    fps.setMinimalLeg();
    hcp.update(fps);

    // SPS脚を伸ばして届くターンサークルをリストアップ
    prepareSkipTurnCircle(hcp, sps, fps);
}

/**
 作業パス脚調整
 
 HCP[]の情報に基づいて作業パス脚を延長する
 ターンパス両端のパス脚(FPS/SPSの脚)の長さを調節する。
 
 @return 生成結果
 @retval true   調整した
 @retval false  調整しなかった
 */
bool PathGenerator::applyPathLegs(PathGenerator::PathSpan& pathSpan) {
  	LOGV(LOG_TAG "::applyPathLegs", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    bool result = false;
    
    auto& hcp = pathSpan.HCP;
    int fpsResult = FAILURE;
    int spsResult = FAILURE;

    while (hcp.isSkip()) {
        // 開始ナビゲーションの場合はFPSターンが無いので不要
        if (hcp.fpsTarget.isAvailable()) {
            // FPS脚を指定位置まで伸ばす
            const auto fpsTarget = hcp.fpsTarget.at();
            FPS.setHeadLeg(fpsTarget.length);
            hcp.setIgnoresFps(fpsTarget.index);
            hcp.update(FPS);
            fpsResult = SUCCESS;
        }

        // 終了ナビゲーションの場合はSPSターンが無いので不要
        if (hcp.spsTarget.isAvailable()) {
            // SPS脚を指定位置まで伸ばす
            const auto spsTarget = hcp.spsTarget.at();
            SPS.setHeadLeg(spsTarget.length);
            hcp.setIgnoresSps(spsTarget.index);
            hcp.update(SPS);
            spsResult = SUCCESS;
        }
        
        // 次のパターンを指す
        hcp.nextSkip();

        result = (fpsResult == SUCCESS) || (spsResult == SUCCESS);
        if (result) {
            // どちらかが適用された
            break;
        }
    }

    LOGV(LOG_TAG "::applyPathLegs", "FPS LEG LENGTH: %gm: %s", FPS.getHeadLeg().length(), to_string(FPS).c_str());
    LOGV(LOG_TAG "::applyPathLegs", "SPS LEG LENGTH: %gm: %s", SPS.getHeadLeg().length(), to_string(SPS).c_str());
//    LOGD(LOG_TAG "::applyPathLegs", "RESULT: %d,%d", fpsResult, spsResult);
    return result;
}

// パス間ナビゲーション用セレクタ関数クラス
using SelectorFunc = std::function<PathSpanStack& (PathSpanStack&, PathSpanStack&)>;

/**
 パス間ナビゲーション用セレクタ

 完成しているので道のりの短い方を返す
 
 @param[in] lhs 比較元
 @param[in] rhs 比較先
 
 @return 評価の高い側のPathSpanStack
 */
PathSpanStack& selector_int(PathSpanStack& lhs, PathSpanStack& rhs) {
    if (lhs.empty()) {
        return rhs;
    } else if (rhs.empty()) {
        return lhs;
    }

    return (lhs.milage < rhs.milage) ? lhs : rhs;
}

/**
 開始ナビゲーション用セレクタ
 
 開始点に近い側から始まり、より短い方を返す
 
 @param[in] lhs 比較元
 @param[in] rhs 比較先

 @return 評価の高い側のPathSpanStack
 */
PathSpanStack& selector_startnav(PathSpanStack& lhs, PathSpanStack& rhs) {
    if (lhs.empty()) {
        return rhs;
    } else if (rhs.empty()) {
        return lhs;
    }

    auto lEnter = lhs.enterHcpIndex();
    auto rEnter = rhs.enterHcpIndex();
    return ((lEnter < rEnter) ||
            (lEnter == rEnter && lhs.milage < rhs.milage)) ? lhs : rhs;
}

/**
 終了ナビゲーション用セレクタ
 
 終了点により近いコーナーまで到達し、より短い方を返す
    - 引数のどちらかが空の場合、反対側を返す。両方が空の場合でもrhsを返す。
 
 @param[in] lhs 比較元
 @param[in] rhs 比較先
 
 @return 評価の高い側のPathSpanStack
 */
PathSpanStack& selector_endnav(PathSpanStack& lhs, PathSpanStack& rhs) {
    if (lhs.empty()) {
        return rhs;
    } else if (rhs.empty()) {
        return lhs;
    }

    auto lLeave = lhs.leaveHcpIndex();
    auto rLeave = rhs.leaveHcpIndex();
    return ((rLeave < lLeave) ||
            (rLeave == lLeave && lhs.milage < rhs.milage)) ? lhs : rhs;
}

/**
 ターンパス最適化

 HCP[]を辿るパスを生成する。
	- 省略可能なターン(HCP[n])があれば跳ばしてパスを引く。
		- reduceTurn()と異なり、途中のターンでも削除する。
	- ターン削除等の都合で再度先頭から処理を行う必要が生じた場合、処理を中断しRETRYを返す。

 @note	ターン削減にはエラーとなるターンを削除する役割がある。
		HCP[]に格納されているターンポイントはパス始点から終点への空間位置関係には依らないため、
		位置関係によって枕地領域からはみ出すターンになる場合がある。

 @return 生成結果
 @retval SUCCESS パス生成完了
 @retval RETRY 要再試行
 */
int PathGenerator::createNavigationPath() {
	LOGV(LOG_TAG "::createNavigationPath", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    auto& HCP = traverseInfo.HCP;
    
    int result = SUCCESS;

    LOGD(LOG_TAG "::createNavigationPath", "[Reduction Turn Path:%p] INPUT", this);
	if (traverseInfo.boundaryType == BoundaryType::OBSTACLE) {
		LOGD(LOG_TAG "::createNavigationPath", "Obstacle around.");
	}
    LOGD(LOG_TAG "::createNavigationPath", "%s", dumpHltcList(HCP).c_str());

	pathBuffer.clear();
    
    vector<PathSpanStack> completedPathList;
    PathSpanStack halfwayPath;

    // パス候補の選択関数準備
    SelectorFunc select_best;
    if (traverseInfo.mode == PathGeneratorData::TraverseInfo::Mode::START_NAV) {
        select_best = selector_startnav;
        // 最小開始ナビゲーションパス準備
        PathSpan ps{traverseInfo.HCP.getMinimalStartNavRange()};
        auto path = pathAssembler.getMinimalEnterPath(SPS, gauge.termMin.start);
        ps.append(path);
        halfwayPath.push_back(ps);
        halfwayPath.turnType = path.turnType;
        halfwayPath.completeSegment();
        halfwayPath.calcMilage();
    } else if (traverseInfo.mode == PathGeneratorData::TraverseInfo::Mode::END_NAV) {
        select_best = selector_endnav;
        // 最小終了ナビゲーションパス準備
        // - 後でどんつき処理を通るので仮生成である
        PathSpan ps{traverseInfo.HCP.getMinimalEndNavRange()};
        auto path = pathAssembler.getMinimalLeavePath(FPS, gauge.termMin.end, false);
        ps.append(path);
        halfwayPath.push_back(ps);
        halfwayPath.turnType = path.turnType;
        halfwayPath.completeSegment();
        halfwayPath.calcMilage();
    } else if (traverseInfo.mode == PathGeneratorData::TraverseInfo::Mode::INTER_PATH) {
        select_best = selector_int;
    }
    
    // traverse turn circles
	TurnPath turnPath{};	// 一時ターンパス
    traverseInfo.HCP.initSkip();
    traverseInfo.HCP.initRange();
	PathSpan pathSpan{traverseInfo.HCP};
	while (pathSpan.isInHcpRange()) {
        LOGD(LOG_TAG "::createNavigationPath", "pathStack:SPANNING %s TRY next span [%d - %d]", dumpPathSpanList(pathSpanStack).c_str(), pathSpan.range.first, pathSpan.range.second);
        pathSpan.success = false;
		pathSpan = getFarthestPath(pathSpan);
        HCP = pathSpan.HCP;
		if (pathSpan.isSuccess()) {
			// 成功したので一つ進める
			LOGD(LOG_TAG "::createNavigationPath", "pathStack:push span[%d - %d]", pathSpan.range.first, pathSpan.range.second);
			pathSpan.save();
			pathSpanStack.push_back(pathSpan);

            const auto lastCorner = pathSpan.srcCorner();
            pathSpan.shiftRange(HCP.range.second);
			if (!pathSpanStack.empty() && !(pathSpan.range.first < HCP.range.second)) {
                // 完成した
                // 終点を追加し、セグメントを完成させる
                pathSpanStack.completeSegment(SPS.enterPoint());
                pathSpanStack.calcMilage();      // パス長を求める
                LOGD(LOG_TAG "::createNavigationPath", "pathStack:SPANNING %s COMPLETED", dumpPathSpanList(pathSpanStack).c_str());
                completedPathList.push_back(pathSpanStack);
                // 他の候補を探す
                pathSpanStack.pop_back();
                if (!pathSpanStack.empty()) {
                    // 一つ戻して探索続行
                    pathSpan = pathSpanStack.back();
                    pathSpanStack.pop_back();
                    LOGD(LOG_TAG "::createNavigationPath", "pathStack:pop  span[%d - %d] SEEK MORE ROUTE", pathSpan.range.first, pathSpan.range.second);
                    pathSpan.decRange();
                    if (!pathSpanStack.empty()) {
                        pathSpanStack.back().restore();
                        pathSpan.HCP = pathSpanStack.back().HCP;
                    } else {
                        pathSpan.HCP = traverseInfo.HCP;
                    }
                } else {
                    // これ以上戻せない
                    LOGD(LOG_TAG "::createNavigationPath", "pathStack:SPANNING [NONE] END OF SEEK ANOTHER ROUTE");
                    break;
                }
            }
		} else {
			// この区間で失敗した場合
            LOGD(LOG_TAG "::createNavigationPath", "pathStack:SPANNING %s FAILED", dumpPathSpanList(pathSpanStack).c_str());
            if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
                // 終了ナビゲーションは途中まででも良い方を残す
                // - pathSpanStackはバックトラック用なので変更しないこと。
                PathSpanStack tmpPathSpanStack = pathSpanStack;
                if (pathSpan.hasHalfwaySpan()) {
                    // 途中まで成功したパスがある場合は加える。(成功ではないのでまだpathSpanStackに積まれていない)
                    auto halfwaySpan = pathSpan.getHalfwaySpan();
                    tmpPathSpanStack.push_back(halfwaySpan);
                } else {
                    // 最後の区間が全く成功していないので末尾短縮をかける
                    if (!tmpPathSpanStack.empty()) {
                        tmpPathSpanStack.completeSegment();
                        tmpPathSpanStack.terminate();
                        tmpPathSpanStack.trimTail(gauge.truncateLength.end);
                    }
                }
                
                // 途中まで辿れたパス保存
                if (!tmpPathSpanStack.empty()) {
                    tmpPathSpanStack.completeSegment();
                    tmpPathSpanStack.terminate();
                    if (!tmpPathSpanStack.empty()) {
                        tmpPathSpanStack.calcMilage(FPS.leavePoint());      // パス長を求める
                        halfwayPath = select_best(halfwayPath, tmpPathSpanStack);  // 高評価の側を格納
                    }
                }

                if (!traverseInfo.truncation.tail) {
                    // 終了ナビゲーション探索強制終了
                    break;
                }
            }

            if (!pathSpanStack.empty()) {
                // 失敗したので一つ戻す
                pathSpan = pathSpanStack.back();
				pathSpanStack.pop_back();
				LOGD(LOG_TAG "::createNavigationPath", "pathStack:pop  span[%d - %d]", pathSpan.range.first, pathSpan.range.second);
                pathSpan.decRange();
				if (!pathSpanStack.empty()) {
					pathSpanStack.back().restore();
                    pathSpan.HCP = pathSpanStack.back().HCP;
                } else {
                    pathSpan.HCP = traverseInfo.HCP;
                }
			} else {
				// これ以上戻せない
                // - 開始ナビゲーションの場合、前のターンポイントを捨てて再試行
                if ((traverseInfo.mode == TraverseInfo::Mode::START_NAV) && traverseInfo.skipFrontNode()) {
                    pathSpan = PathSpan{{traverseInfo.HCP.range}};
                    pathSpan.HCP = traverseInfo.HCP;
                    pathSpanStack.clear();
                } else {
                    LOGD(LOG_TAG "::createNavigationPath", "pathStack:SPANNING [NONE] END OF SEEK ROUTE");
                    break;
                }
			}
		}
	}
	
    if (!completedPathList.empty()) {
        LOGD(LOG_TAG "::createNavigationPath", "PATH CANDIDATES: %d\n%s", (int)completedPathList.size(), dumpCandidates(completedPathList).c_str());
        // 完成したパスが複数ある場合、最良のものを選択
        auto* bestPath = &completedPathList.back();
        for (auto& path : completedPathList) {
            bestPath = &(select_best(*bestPath, path));
        }

        // 生成したパスを出力パスに追加
        auto& psStack = *bestPath;
        LOGD(LOG_TAG "::createNavigationPath", "ADOPT COMPLETE PATH: %s", dumpPathSpanList(*bestPath).c_str());
        pathBuffer.pushTurnPath(psStack);
        pathBuffer.completeSegment();
        pathBuffer.terminate(pathBuffer.leavePoint());
        pathBuffer.open();
        if (traverseInfo.mode == PathGeneratorData::TraverseInfo::Mode::END_NAV) {
            // 末尾短縮
            // - 成功した終了ナビゲーションパス末尾は生成時に短縮済みなので、終点を追加することで末尾は短縮分のセグメントになっている。
            pathBuffer.pop_back();
        }
        pathBuffer.terminate(pathBuffer.leavePoint());
        // DEBUG ASSERT
        PPASSERT((traverseInfo.mode == PathGeneratorData::TraverseInfo::Mode::START_NAV) || (pathBuffer.getEnterPoint() == FPS.leavePoint()), ErrorCode::PathGeneration::FATAL);
        PPASSERT((traverseInfo.mode == PathGeneratorData::TraverseInfo::Mode::END_NAV) || (pathBuffer.getLeavePoint() == SPS.enterPoint()), ErrorCode::PathGeneration::FATAL);
    } else {
        pathBuffer.clear(); // 念の為
        if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
            LOGD(LOG_TAG "::createNavigationPath", "ADOPT MINIMAL START_NAV");
            // 開始ナビゲーション生成失敗
            // - 最小ナビゲーションパス
            pathBuffer.assign(halfwayPath);
            pathBuffer.terminate();
        } else if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
            // 終了ナビゲーションパス未完成
            LOGD(LOG_TAG "::createNavigationPath", "ADOPT HALFWAY PATH: %s", dumpPathSpanList(halfwayPath).c_str());
            pathBuffer.assign(halfwayPath);
            pathBuffer.completeSegment();
            pathBuffer.terminate();
        } else {
            // エラー終了
            if (gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
                gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE) {
                // オフセット作業機(回り耕、すなわち草刈機の場合のみ)
                // - 平行作業パスセグメント端調整のためナビゲーションパス生成のエラーになる場合を区別する
                ErrorPathGenerator err{FPS, SPS, ErrorCode::PathGeneration::NaviPath::WITH_OFFSET};
                err.setDescription("OFFSET IMPLEMENT caused navigation path generatioin error.", "::optimizeTurnPath");
                err.circles = HCP;
                throw err;
            } else {
                ErrorPathGenerator err{FPS, SPS, ErrorCode::PathGeneration::NaviPath::GENERAL};
                err.setDescription("navigation path generatioin error in travers turn points.", "::optimizeTurnPath");
                err.circles = HCP;
                throw err;
            }
        }
    }

    // 無効なセグメントを削除
    removeVoidSegemnt(pathBuffer);

    // 開始ナビゲーション開始端処理
    if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
        ensureHeadForward(pathBuffer);
    }
    // 終了ナビゲーションパス末端処理
    if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
        ensureTailForward(pathBuffer);
    }
    
	pathSpanStack.clear();	// クリアを忘れない

	LOGV(LOG_TAG "::createNavigationPath", "[Reduction Turn Path:%p] OUTPUT", this);
    LOGV(LOG_TAG "::createNavigationPath", "%s", dumpHltcList(HCP).c_str());

    return result;
}

/**
 コーナーターンパス最適化
 
 指定のターンサークル間を渡るターンパスを生成して返す。生成できなければ空のパスを返す。
 - currCirc ターンサークルは位置を変更する可能性がある(障害物のコーナーを除く)
 
 @param[in] eTS 現ターンサークルに進入する接線
 @param[in] currCirc 現ターンサークル
 @param[in] nextCirc 行先ターンサークル
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeCornerTurnPath(LineSegment& eTS, Circle& currCirc, const Circle& nextCirc) {
    LOGV(LOG_TAG "::optimizeCornerTurnPath", "(T,C,C)");
    if (isIsometric(currCirc.radius, 0.0)) {
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid current turn circle", "optimizeCornerTurnPath()");
        throw err;
    }
    
    TurnPath turnPath;
    Circle tmpCirc = currCirc;
    
    // 脱出接線
    PathSegment PS = getTangent(eTS, tmpCirc, nextCirc, TangentDir::FORWARD);
    if (!PS.isValid()) {
        return turnPath;
    }

    LineSegment lTS = PS;
    
    // 進入接線との交差があれば更新される
    flipTurnCircle(tmpCirc, eTS, lTS);
    // 指定接線でターンパス取得
    turnPath = pathAssembler.getValidatedPath(eTS, tmpCirc, lTS, nextCirc);
    if (turnPath.isValid()) {
        // フリップしたかもしれないので更新する
        currCirc = tmpCirc;
    }
    
    return turnPath;
}

/**
 コーナーターンパス最適化(開始ナビゲーション)
 
 指定のターンサークル間接線から始まるターンパスを生成して返す。
    - 開始ナビゲーション途中開始用、
    - currCirc ターンサークルは位置を変更する可能性がある(障害物のコーナーを除く)
 
 @param[in] currCirc 現ターンサークル
 @param[in] nextCirc 行先ターンサークル
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeCornerTurnPath(Circle& currCirc, const Circle& nextCirc) {
    LOGV(LOG_TAG "::optimizeCornerTurnPath", "(T,C,C)");
    if (isIsometric(currCirc.radius, 0.0)) {
        ErrorPathGenerator err{ErrorCode::PathGeneration::FATAL};
        err.setDescription("[ASSERT] invalid current turn circle", "optimizeCornerTurnPath()");
        throw err;
    }
    
    TurnPath turnPath;
    
    // 接線取得
    PathSegment PS = getTangent(currCirc, nextCirc, TangentDir::FORWARD);
    if (PS.isValid()) {
        LineSegment lTS = PS;
        // 指定接線でターンパス取得
        turnPath = pathAssembler.getValidatedPath(lTS, nextCirc);
    }
    
    return turnPath;
}

/**
 コーナーターンパス最適化(終了ナビゲーション)
 
 指定のターンサークル間を渡るターンパスを生成して返す。
    - 失敗した場合、指定ターンサークルへの接線で終了を試みる。終了ナビゲーション途中終了用。
    - 途中終了も失敗した場合空のパスが返る。
    - currCirc ターンサークルは位置を変更する可能性がある(障害物のコーナーを除く)
 
 @param[in] eTS 現ターンサークルに進入する接線
 @param[in] currCirc 現ターンサークル
 @param[in] nextCirc 行先ターンサークル
 
 @return 生成したターンパス
 */
PathGenerator::TurnPath PathGenerator::optimizeCornerTurnPathEndNav(LineSegment& eTS, Circle& currCirc, const Circle& nextCirc) {
    LOGV(LOG_TAG "::optimizeCornerTurnPathEndNav(T,C,C)", "");
    
    TurnPath turnPath = optimizeCornerTurnPath(eTS, currCirc, nextCirc);
    if (turnPath.isValid()) {
        LOGV(LOG_TAG "::optimizeCornerTurnPathEndNav(T,C,C)", "[INFO] SUCCESS");
        return turnPath;
    }

    if (!turnPath.empty()) {
        // 生成に失敗した場合、終点への接線で試行
        LOGD(LOG_TAG "::optimizeCornerTurnPathEndNav(T,C,C)", "try halfway end.");
        turnPath.clear();
        Circle tmpCirc = currCirc;
        PathSegment PS = getTangent(eTS, tmpCirc, nextCirc, TangentDir::FORWARD);
        if (PS.isValid()) {
            PathAssembler::EndPoint endPoint{PS.point2()};
            turnPath = pathAssembler.getValidatedPath(eTS, currCirc, endPoint);
            if (turnPath.isValid()) {
                LOGV(LOG_TAG "::optimizeCornerTurnPathEndNav(T,C,C)", "[INFO] SUCCESS (halfway)");
                // フリップしたかもしれないので更新する
                currCirc = tmpCirc;
                turnPath.invalidate();
            } else {
                LOGV(LOG_TAG "::optimizeCornerTurnPathEndNav(T,C,C)", "[INFO] FAILED");
            }
        }
    } else {
        LOGV(LOG_TAG "::optimizeCornerTurnPathEndNav(T,C,C)", "[INFO] FAILED");
    }
    
    return turnPath;
}

/**
 最長パス取得

 pathSpanのrange指定のターンポイントの範囲で先頭のものから渡れる最も遠いポイントへのパスを返す。
	- 生成できなかった場合には空のパス区間を返す(empty() == true)

 @param[in,out] pathSpan 入力パス区間
 @return 生成したパス区間
 */
PathGenerator::PathSpan PathGenerator::getFarthestPath(PathGenerator::PathSpan pathSpan) {
	LOGV(LOG_TAG "::getFarthestPath", "seek range (%d - %d)", pathSpan.range.first, pathSpan.range.second);
    PPASSERT(!pathSpan.isSuccess(), ErrorCode::PathGeneration::FATAL);
    PPASSERT(!pathSpan.hasHalfwaySpan(), ErrorCode::PathGeneration::FATAL);
    
    auto& HCP = traverseInfo.HCP;
    
    // 区間が空の場合は即失敗
    if (pathSpan.empty()) {
        return pathSpan;
    }

    const int curr = pathSpan.range.first;
    int last = pathSpan.range.first;
    // 障害物周囲はスキップしない
    int next = (traverseInfo.boundaryType == BoundaryType::FIELD) ? pathSpan.range.second : min(pathSpan.range.second, curr + 1);

	for (; last < next; next--) {
        pathSpan.HCP.initSkip();
        pathSpan.HCP.curr = curr;
        pathSpan.HCP.next = next;
        while (!pathSpan.isSuccess() && applyPathLegs(pathSpan)) {
            LOGD(LOG_TAG "::getFarthestPath", "try traverse HCP[%d] - HCP[%d]", pathSpan.range.first, next);
            LOGD(LOG_TAG "::getFarthestPath", "[HCP CONDITIONS]%s", dumpHltcList(pathSpan.HCP).c_str());
            
            HCP = pathSpan.HCP;
            if (curr == HCP.fpsIndex() && !pathSpan.HCP[next].flags.test(HeadlandTurnCircle::IGNORED_BY_FPS)) {
                // FPS最適化試行
                if (next == HCP.spsIndex()) {
                    getFpsSpsTurnPath(pathSpan, next);
                } else {
                    if (pathSpan.HCP[next].flags.test(HeadlandTurnCircle::IGNORED_BY_FPS)) {
                        LOGD(LOG_TAG "::getFarthestPath", "skip HCP[%d]", next);
                    } else {
                        getFpsTurnPath(pathSpan, next);
                    }
                }
            } else if (next < HCP.spsIndex()) {
                // 一般HCP
                if (pathSpan.HCP[next].flags.test(HeadlandTurnCircle::IGNORED_BY_FPS) || pathSpan.HCP[next].flags.test(HeadlandTurnCircle::IGNORED_BY_SPS)) {
                    LOGD(LOG_TAG "::getFarthestPath", "skip HCP[%d]", next);
                } else {
                    getCornerTurnPath(pathSpan, curr, next);
                }
            } else if (next == HCP.spsIndex()) {
                if (!pathSpan.HCP[next].flags.test(HeadlandTurnCircle::IGNORED_BY_SPS)) {
                    // SPS最適化試行
                    PathSegment eTS = getLastTangent();	// 最後の進入接線(最後のセグメントではない)
                    getSpsTurnPath(pathSpan, eTS, curr);
                } else {
                    LOGD(LOG_TAG "::getFarthestPath", "skip HCP[%d]", next);
                }
            } else {
                LOGE(LOG_TAG "::getFarthestPath", "[ERROR] range (%d - %d) out of range HCP[%d - %d]", curr, next, HCP.fpsIndex(), HCP.spsIndex());
            }
        }
		
		if (pathSpan.isSuccess()) {
			LOGD(LOG_TAG "::getFarthestPath", "SUCCESS traverse HCP[%d] - HCP[%d]", curr, next);
			// 渡れたので終了
			break;
		}
	}
	
	pathSpan.range.second = next;
	return pathSpan;
}

/**
 ターンパス生成条件適用(FPS)
 
 条件をFPSに適用する

 @param[in,out] hcp     HCPリスト
 @param[in,out] fps     FPS
 @param[in,out] condition   条件フラグセット
 @return 設定結果:設定済み条件のビットをリセットした条件フラグセット
 */
PathGenerator::TryCondition::Flags PathGenerator::applyCondition(HLTCList& hcp, PathFPS& fps, TryCondition::Flags condition) {
    if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
        fps.Circ.radius = 0.0;
    } else {
        if (condition.test(TryCondition::FPS::ALTTC)) {
            LOGV(LOG_TAG "::applyConditionFPS", "FPS TC FLIPPED");
            condition.reset(TryCondition::FPS::ALTTC);
            fps.alternateTurnCircle();
        }
    }
    fps.setTurnCircle(fps.Circ.orient, fps.Circ.radius);
    hcp.update(fps);
    
    return condition;
}

/**
 ターンパス生成条件適用(SPS)
 
 条件をSPSに適用する
 
 @param[in,out] hcp         HCPリスト
 @param[in,out] sps         FPS
 @param[in,out] condition   条件フラグセット
 @return 設定結果:設定済み条件のビットをリセットした条件フラグセット
 */
PathGenerator::TryCondition::Flags PathGenerator::applyCondition(HLTCList& hcp, PathSPS& sps, TryCondition::Flags condition) {
    if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
        sps.Circ.radius = 0.0;
    } else {
        if (condition.test(TryCondition::SPS::ALTTC)) {
            condition.reset(TryCondition::SPS::ALTTC);
            LOGV(LOG_TAG "applyConditionSPS", "SPS TC FLIPPED");
            sps.alternateTurnCircle();
        }
    }
    sps.setTurnCircle(sps.Circ.orient, sps.Circ.radius);
    hcp.update(sps);
    
    return condition;
}

/**
 FPSターンパス取得
 
 FPSターンパス最適化エラーハンドルラッパー
 - FPSのターンサークル向きを調整しながらリトライする
 
 @see optimizeFpsTurnPath

 @param[in] pathSpan 区間
 @param[in] index    行先コーナーインデックス
 @return 成否
 */
bool PathGenerator::getFpsTurnPath(PathGenerator::PathSpan& pathSpan, int index) {
    LOGV(LOG_TAG "::getFpsTurnPath", "HCP[FPS] - HCP[%d]", index);
    auto& HCP = traverseInfo.HCP;
    
    TurnPath turnPath;
    turnPath.pushTurnPath(traverseInfo.fps.leavePoint());    // 失敗しても始点を必ず返す
    
    PathFPS tmpFPS = traverseInfo.fps;
    auto saveHCP = pathSpan.HCP;
    
    for (unsigned int tries = 0; tries < TryCondition::END_OF_VALUE; tries++) {
        // setup condisions
        traverseInfo.fps = tmpFPS;
        HCP = saveHCP;
        TryCondition::Flags currCondision = applyCondition(HCP, traverseInfo.fps, tries);
        if (currCondision.any()) {
            LOGV(LOG_TAG "::getFpsTurnPath", "COND(%s) SKIP", TryCondition::Flags{tries}.to_string().c_str());
            continue;
        }
        
        try {
            LOGD(LOG_TAG "::getFpsTurnPath", "COND(%s) TRY", TryCondition::Flags{tries}.to_string().c_str());
            if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
                turnPath = optimizeFpsTurnPathStartNav(index);
            } else if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
                turnPath = optimizeFpsTurnPathEndNav(index);
                if (turnPath.status == FAILURE) {
                    pathSpan.saveHalfway(turnPath, index);
                } else if (turnPath.status == FAILURE_TERM_END) {
                    traverseInfo.truncation.disableTail();
                }
            } else {
                turnPath = optimizeFpsTurnPath(index);
            }
        } catch (std::exception& e) {
            // nothing to do
            LOGD(LOG_TAG "::getFpsTurnPath/End", "[EXCEPTION] in optimizeFpsTurnPath: %s", e.what());
        }
        
        if (turnPath.isValid()) {
            break;
        }
        
        if (traverseInfo.boundaryType != BoundaryType::FIELD) {
            LOGD(LOG_TAG "::getFpsTurnPath", "COND(%s) NO RETRY on OHP", TryCondition::Flags{tries}.to_string().c_str());
            break;
        }
    }
    
    if (turnPath.isValid()) {
        LOGD(LOG_TAG "::getFpsTurnPath", "HCP[FPS] - HCP[%d] SUCCESS", index);
        pathSpan.append(turnPath);
        pathSpan.HCP = HCP;
        pathSpan.success = true;
    } else {
        LOGD(LOG_TAG "::getFpsTurnPath", "HCP[FPS] - HCP[%d] FAILED", index);
        traverseInfo.fps = tmpFPS;
        pathSpan.success = false;
    }
    
    return pathSpan.success;
}

/**
 コーナーターンパス取得
 
 コーナーターンパス最適化エラーハンドルラッパー
 
 @see optimizeCornerTurnPath

 @param[in,out] pathSpan 区間
 @param[in] curr    現コーナーインデックス
 @param[in] next    行先コーナーインデックス
 @return 成否
 */
bool PathGenerator::getCornerTurnPath(PathGenerator::PathSpan& pathSpan, int curr, int next) {
    LOGV(LOG_TAG "::getCornerTurnPath", "HCP[%d] - HCP[%d]", curr, next);
    auto& HCP = traverseInfo.HCP;

    TurnPath turnPath;
    PathSegment eTS = getLastTangent();
    auto& currCirc = HCP[curr].Circ;
    auto& nextCirc = HCP[next].Circ;

    try {
        if (eTS.isValid()) {
            // 侵入接線あり
            if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
                turnPath = optimizeCornerTurnPathEndNav(eTS, currCirc, nextCirc);
                if (!turnPath.isValid()) {
                    pathSpan.saveHalfway(turnPath, next);
                }
            } else {
                turnPath = optimizeCornerTurnPath(eTS, currCirc, nextCirc);
            }
        } else {
            // 侵入接線なし
            turnPath = optimizeCornerTurnPath(currCirc, nextCirc);
        }
    } catch (std::exception& e) {
        // nothing to do
        LOGD(LOG_TAG "::getCornerTurnPath", "[EXCEPTION] in optimizeCornerTurnPath: %s", e.what());
    } catch (...) {
        // nothing to do
        LOGE(LOG_TAG "::getCornerTurnPath", "[EXCEPTION] in optimizeCornerTurnPath/End");
    }
    
    if (turnPath.isValid()) {
        LOGD(LOG_TAG "::getCornerTurnPath", "HCP[%d] - HCP[%d] SUCCESS", curr, next);
        // 成功したので更新する
        pathSpan.append(turnPath);
        if (eTS.isValid()) {
            pathSpanStack.updateTurnPathLast(eTS.point2(), currCirc);
        }
        pathSpan.HCP = HCP;
        pathSpan.success = true;
    } else {
        LOGD(LOG_TAG "::getCornerTurnPath", "HCP[%d] - HCP[%d] FAILED", curr, next);
        HCP = pathSpan.HCP;
        pathSpan.success = false;
    }

    return pathSpan.success;
}

/**
 FPSターンパス取得(対SPS)
 
 FPSからSPSターンパス最適化エラーハンドルラッパー
 - FPSとSPSのターンサークル向きを調整しながらリトライする
 
 @see optimizeFpsTurnPath

 @param[in,out] pathSpan 区間
 @param[in] index    行先コーナーインデックス(SPS)
 @return 成否
 */
bool PathGenerator::getFpsSpsTurnPath(PathGenerator::PathSpan& pathSpan, int index) {
    LOGV(LOG_TAG "::getFpsSpsTurnPath", "HCP[FPS] - HCP[SPS(%d)]", index);
    auto& HCP = traverseInfo.HCP;

    TurnPath turnPath;
    turnPath.pushTurnPath(traverseInfo.fps.leavePoint());    // 失敗しても始点を必ず返す
    
    PathFPS tmpFPS = traverseInfo.fps;
    PathSPS tmpSPS = traverseInfo.sps;
    auto saveHCP = pathSpan.HCP;
    
    for (unsigned int tries = 0; tries < TryCondition::END_OF_VALUE; tries++) {
        // setup condisions
        traverseInfo.fps = tmpFPS;
        traverseInfo.sps = tmpSPS;
        HCP = saveHCP;
        TryCondition::Flags currCondision = applyCondition(HCP, traverseInfo.fps, tries);
        currCondision = applyCondition(HCP, traverseInfo.sps, currCondision);
        if (currCondision.any()) {
            LOGV(LOG_TAG "::getFpsSpsTurnPath", "COND(%s) SKIP", TryCondition::Flags{tries}.to_string().c_str());
            continue;
        }
        
        try {
            LOGD(LOG_TAG "::getFpsSpsTurnPath", "COND(%s) TRY", TryCondition::Flags{tries}.to_string().c_str());
            if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
                LOGD(LOG_TAG "::getFpsSpsTurnPath", "make START_NAV");
                turnPath = optimizeFpsTurnPathStartNav(index);
            } else if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
                LOGD(LOG_TAG "::getFpsSpsTurnPath", "make END_NAV");
                turnPath = optimizeFpsSpsTurnPathEndNav(index);
            } else {
                LOGD(LOG_TAG "::getFpsSpsTurnPath", "make INTER_WORKPATH");
                turnPath = optimizeFpsSpsTurnPath(index);
            }
        } catch (std::exception& e) {
            // nothing to do
            LOGD(LOG_TAG "::getFpsSpsTurnPath", "[EXCEPTION] in optimizeFpsTurnPath: %s", e.what());
        } catch (...) {
            // nothing to do
            LOGE(LOG_TAG "::getFpsSpsTurnPath", "[EXCEPTION] in optimizeFpsTurnPath");
        }
        
        if (turnPath.isValid()) {
            break;
        }
        
        if (traverseInfo.boundaryType != BoundaryType::FIELD) {
            LOGD(LOG_TAG "::getFpsSpsTurnPath", "COND(%s) NO RETRY on OHP", TryCondition::Flags{tries}.to_string().c_str());
            break;
        }
    }
    
    if (turnPath.isValid()) {
        LOGD(LOG_TAG "::getFpsSpsTurnPath", "HCP[FPS] - HCP[SPS(%d)] SUCCESS", index);
        pathSpan.append(turnPath);
        pathSpan.HCP = HCP;
        pathSpan.success = true;
    } else {
        LOGD(LOG_TAG "::getFpsSpsTurnPath", "HCP[FPS] - HCP[SPS(%d)] FAILED", index);
        traverseInfo.sps = tmpSPS;
        traverseInfo.fps = tmpFPS;
        pathSpan.HCP = saveHCP;
        pathSpan.success = false;
    }
    
    return pathSpan.success;
}

/**
 SPSターンパス取得
 
 SPSターンパス最適化エラーハンドルラッパー
    - SPSのターンサークル向きを調整しながらリトライする
 
 @see optimizeSpsTurnPath
 
 @param[in,out] pathSpan 区間
 @param[in] eTS     進入接線
 @param[in] index   出発コーナーインデックス
 @return 成否
 */
bool PathGenerator::getSpsTurnPath(PathGenerator::PathSpan& pathSpan, PathSegment& eTS, int index) {
    LOGV(LOG_TAG "::getSpsTurnPath", "(HCP[%d] - HCP[SPS])", index);
    auto& HCP = traverseInfo.HCP;

    TurnPath turnPath;

    PathSPS saveSPS = traverseInfo.sps;
    auto saveHCP = pathSpan.HCP;

    for (unsigned int tries = 0; tries < TryCondition::END_OF_VALUE; tries++) {
        // setup condisions
        traverseInfo.sps = saveSPS;
        HCP = saveHCP;
        try {
            TryCondition::Flags currCondision = applyCondition(HCP, traverseInfo.sps, tries);
            if (currCondision.any()) {
                LOGV(LOG_TAG "::getSpsTurnPath", "COND(%s) SKIP", TryCondition::Flags{tries}.to_string().c_str());
                continue;
            }

            LOGD(LOG_TAG "::getSpsTurnPath", "COND(%s) TRY", TryCondition::Flags{tries}.to_string().c_str());
            if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
                if (eTS.isValid()) {
                    LOGD(LOG_TAG "::getSpsTurnPath", "make START_NAV (continued)");
                    // 侵入接線あり
                    turnPath = optimizeSpsTurnPath(eTS, index);
                } else {
                    // 侵入接線なし
                    // - 有効な接線が引けなかったのでこれ以前のノードはスキップしてここから開始している
                    LOGD(LOG_TAG "::getSpsTurnPath", "make START_NAV (started halfway)");
                    turnPath = optimizeSpsTurnPathStart(index);
                }
            } else if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
                LOGD(LOG_TAG "::getSpsTurnPath", "make END_NAV");
                turnPath = optimizeSpsTurnPathEnd(eTS, index);
                if (!turnPath.isValid() && !turnPath.empty()) {
                    pathSpan.saveHalfway(turnPath, index);
                }
            } else {
                LOGD(LOG_TAG "::getSpsTurnPath", "make INTER_WORKPATH");
                turnPath = optimizeSpsTurnPath(eTS, index);
            }
        } catch (std::exception& e) {
            // nothing to do
            LOGE(LOG_TAG "::getSpsTurnPath", "[EXCEPTION] in optimizeSpsTurnPath/End: %s", e.what());
        } catch (...) {
            // nothing to do
            LOGE(LOG_TAG "::getSpsTurnPath", "[EXCEPTION] in optimizeSpsTurnPath/End");
        }
        
        if (turnPath.isValid()) {
            break;
        }
        
        if (traverseInfo.boundaryType != BoundaryType::FIELD) {
            LOGD(LOG_TAG "::getSpsTurnPath", "COND(%s) NO RETRY on OHP", TryCondition::Flags{tries}.to_string().c_str());
            break;
        }
    }
    
    if (turnPath.isValid()) {
        LOGD(LOG_TAG "::getSpsTurnPath", "HCP[%d] - HCP[SPS] SUCCESS", index);
        pathSpan.append(turnPath);
        pathSpan.HCP = HCP;
        pathSpan.success = true;
    } else {
        LOGD(LOG_TAG "::getSpsTurnPath", "HCP[%d] - HCP[SPS] FAILED", index);
        if (turnPath.empty()) {
            // この区間が引けなかったので直前の区間まででの末尾短縮を行う必要がある
        }
        traverseInfo.sps = saveSPS;
        pathSpan.HCP = saveHCP;
        pathSpan.success = false;
    }

    return pathSpan.success;
}

/**
 開始ナビゲーション
 ナビゲーション先頭前進最短長保証
 
 開始ナビゲーションの先頭を切り詰め、以下の内容を保証する。
 - 先頭のセグメントが前進直線
 - 先頭から直進セグメントが3つ連続するとき、[前進・後退・前進]であれば、後退を削除して一つの前進セグメントに統合する。
 - 最初のカーブまでの直線前進長は最小パス脚以上

 @param[in,out] startNav completeSegment()済み終了ナビゲーション
 */
void PathGenerator::ensureHeadForward(TurnPath& startNav) const {
    LOGV(LOG_TAG "::ensureHeadForward", "()");
    
    startNav.open();
    while (1 <= startNav.size() &&
           SegTest::test(startNav.front(), SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, SegmentDir::REVERSE)) {
        // 先頭カーブまたはバックは無条件で削除
        startNav.erase(startNav.cbegin());
    }

    auto& seg0 = startNav.front();
    if (seg0.segmentType == SegmentType::LINESEG) {
        if (3 <= startNav.size()) {
            IteratorTrain<TurnPath> trit(startNav);
            if (!trit.isEnd()) {
                auto& seg0 = *trit.prevIt();
                auto& seg1 = *trit.currIt();
                auto& seg2 = *trit.nextIt();
                if (SegTest::test(seg0, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, SegmentDir::FORWARD) &&
                    SegTest::test(seg1, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, SegmentDir::REVERSE) &&
                    SegTest::test(seg2, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, SegmentDir::FORWARD)) {
                    // 冒頭直線が無駄に折り返している
                    if (seg1.length() < seg0.length()) {
                        // -一本の前進に統合
                        seg2.enterPoint() = seg0.enterPoint();
                    }
                    startNav.erase(startNav.cbegin(), trit.nextIt());
                }
            }
        }

        // セグメント一本だけのとき
        if (startNav.size() == 1) {
            // - 長さ保証して終わり
            const double diff = gauge.minFpsLegLength - seg0.length();
            if (0.0 < diff) {
                seg0.extendHead(diff);
            }
        }
    }
    
    startNav.terminate(startNav.back().leavePoint());
}

/**
 終了ナビゲーション末尾前進最短長保証
 
 終了ナビゲーションの末尾を切り詰め、以下の内容を保証する。
    - 最後のセグメントが直線
    - 最後の後退セグメントの後に連続する前進セグメントの合計が10.0m以上(バック後の前進が短い場合バック自体が無駄である)
    - 後退セグメントが無い場合長さについて保証対象外
    - 2セグメントしか無い場合、最小終了ナビゲーションかそれ以上の長さである。
 
 @param[in,out] endNav completeSegment()済み終了ナビゲーション
 */
void PathGenerator::ensureTailForward(TurnPath& endNav) const {
    LOGV(LOG_TAG "::ensureTailForward", "()");

    endNav.open();
    while (1 <= endNav.size() &&
           (endNav.back().segmentType == SegmentType::ARCSEG ||
            SegTest::test(endNav.back(), SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, SegmentDir::REVERSE))) {
        // 末尾カーブまたはバックは無条件で削除
        endNav.pop_back();
    }

    if (2 < endNav.size()) {
        IteratorTrain<TurnPath> trit(endNav);
        trit.setTail();
        if (!trit.isEnd()) {
            auto& seg0 = *trit.prevIt();
            auto& seg1 = *trit.currIt();
            auto& seg2 = *trit.nextIt();
            if (SegTest::test(seg0, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, SegmentDir::FORWARD) &&
                SegTest::test(seg1, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, SegmentDir::REVERSE) &&
                SegTest::test(seg2, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, SegmentDir::FORWARD)) {
                // 先頭直線が無駄に折り返している
                if (seg1.length() < seg0.length()) {
                    // - 一本の前進に統合
                    seg2.leavePoint() = seg0.leavePoint();
                }
                endNav.erase(trit.currIt(), endNav.cend());
            }
        }
    }

    double minLength = gauge.tailForwardMin.end;
    while (2 < endNav.size()) {
        // 最後のバックセグメントを探す
        // - 後退セグメントが無い場合は処理しない
        auto rsegIt = endNav.findLastTangent(TangentDir::REVERSE);
        if (rsegIt == endNav.end()) {
            // 後退セグメント無し
            break;
        }

        // バックセグメント後の長さ算出
        const double restLen = endNav.milageAt(next(rsegIt), endNav.cend());
        const double termLen = endNav.terminalLength();
        // バックセグメント後の長さ算出
        LOGD(LOG_TAG "::ensureTailForward", "[END NAV] milage from last reverse: %g m, (%d / %d segs)", restLen, (int)abs(distance(endNav.end(), rsegIt)), (int)endNav.size());
        LOGD(LOG_TAG "::ensureTailForward", "[END NAV] terminal line: %g m", termLen);
        if (restLen < minLength || termLen < gauge.termMin.end) {
            // 短い場合はターン進入前で終了させる
            endNav.erase(rsegIt, endNav.end());
            if (endNav.size() < 2) {
                LOGD(LOG_TAG "::ensureTailForward", "[END NAV] too few segments.");
                // 脚のみ又は空になった
                // - 処理終了
                break;
            }
            // 直前は後退前直進のはずなので捨てる
            endNav.pop_back();
            
            // 前の前進直線セグメントを探索
            auto fsegIt = endNav.findLastTangent(TangentDir::FORWARD);
            if (fsegIt == endNav.end()) {
                LOGD(LOG_TAG "::ensureTailForward", "[END NAV] there's no FORWARD tangent.");
                // 前進セグメント無し
                // - 処理終了
                endNav.clear();
                break;
            }
            endNav.erase(fsegIt, endNav.end());

            // 末尾短縮
            endNav.trimTail(gauge.truncateLength.end);
            if (!endNav.isValid()) {
                LOGD(LOG_TAG "::ensureTailForward", "[END NAV] tail trancation failed.");
                // 短縮失敗したのでこれ以上処理できない
                break;
            }
        } else {
            // 長さ十分
            break;
        }
    }
    
    // 全体の最小長は保証する
    if (!ensureMinimalEndNav(endNav)) {
        endNav.terminate(endNav.back().leavePoint());
    }
}

/**
 終了ナビゲーション最短保証
 
 パスが最小終了ナビゲーション制限を満たさない場合は終了ナビゲーションで置き換える
 - 最小終了ナビゲーションを満たしている場合は何もしない
 
 @param[in,out] endNav 終了ナビゲーション(未終端で与える)

 @return 処理結果
 @retval true   :最小ナビゲーションパスに置換した(終端済)
 @retval false  :無処理
 */
bool PathGenerator::ensureMinimalEndNav(TurnPath& endNav) const {
    LOGV(LOG_TAG "::ensureMinimalEndNav", "()");
    
    bool retval = false;
    // ensure minimal
    if ((endNav.size() < 2) ||
        ((endNav.size() == 2) && (endNav[1].segmentType != SegmentType::LINESEG || endNav[1].length() < gauge.termMin.end))) {
        LOGD(LOG_TAG "::ensureMinimalEndNav", "[END NAV] make minimal endnav.");
        endNav = pathAssembler.getMinimalLeavePath(traverseInfo.fps, gauge.termMin.end, false);
        endNav.completeSegment();
        retval = true;
    }
    
    return retval;
}

/**
 対面パス接続
 
 FPSとSPSが枕地を挟んだ対面にある場合のターンパス生成。
 標準ターンはこの場合をカバーしていない。
 @see createStandardTurnPath()
 */
int PathGenerator::createOppositeTurnPath() {
	LOGV(LOG_TAG "::createOppositeTurnPath", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;

    // Update FPS
	FPS.Circ.radius = gauge.turnRadius;
	FPS.foot.x = FPS.leavePoint().x;
	FPS.foot.y = FPS.leavePoint().y + FPS.dir * gauge.minFpsLegLength;
	FPS.Circ.center.x = FPS.foot.x + (-traverseInfo.rotation * FPS.dir) * gauge.turnRadius;
	FPS.Circ.center.y = FPS.foot.y;
	FPS.Circ.orient = traverseInfo.rotation;

	// Update SPS
	SPS.Circ.radius = gauge.turnRadius;
	SPS.foot.x = SPS.enterPoint().x;
	SPS.foot.y = SPS.enterPoint().y + SPS.dir * gauge.minSpsLegLength;
	SPS.Circ.center.x = SPS.foot.x + (traverseInfo.rotation * SPS.dir) * gauge.turnRadius;
	SPS.Circ.center.y = SPS.foot.y;
	SPS.Circ.orient = traverseInfo.rotation;

    PathSegment PS = getTangent(FPS.getHeadLeg(), FPS.Circ, SPS.Circ, TangentDir::FORWARD);
    if (PS.isValid()) {
        LineSegment TS = PS;
        pathBuffer.pushTurnPath(FPS.leavePoint());
        pathBuffer.pushTurnPath(FPS.getPoint(), FPS.Circ);
        pathBuffer.pushTurnPath(TS.point1());
        pathBuffer.pushTurnPath(TS.point2(), SPS.Circ);
        pathBuffer.pushTurnPath(SPS.getPoint());
        pathBuffer.pushTurnPath(SPS.enterPoint());
        pathBuffer.terminate();

        // DEBUG ASSERT
        PPASSERT(pathBuffer.getEnterPoint() == FPS.leavePoint(), ErrorCode::PathGeneration::FATAL);
        PPASSERT(pathBuffer.getLeavePoint() == SPS.enterPoint(), ErrorCode::PathGeneration::FATAL);
    }
    
	return 0;
}

}} // namespace yanmar::PathPlan

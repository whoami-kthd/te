// Yanmar Confidential 20200918
/** @file OrbitalPathGenerator
 PathGeneartorクラス実装ファイル(PathLib.cppの一部)

 圃場領域の外周に沿って周回するパス生成処理
 */
/// @internal @defgroup PathGenerator  PathGenerator interface

//#define LOGLEVEL 5

#include "PolyLib/Common.h"
#include "PathLib.h"

#include <cstdlib>
#include <string>
#include <stdexcept>
#include <ostream>
#include <utility>
#include <algorithm>

#include "PolyLib/PolygonUtil.hpp"
#include "IteratorUtils.hpp"
#include "DataConverter/OutputDataStream.hpp"

namespace yanmar { namespace PathPlan {
    using namespace std;
    
    using namespace SegmentType;
    using namespace VertexType;
    using namespace RotateDirection;
    using namespace VortexType;
    using namespace PathGeneratorData;

//
// PathGenerator definition
//
#pragma mark - PathGenerator:: orbital path creation
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathGenerator"

    /**
     渦巻辺生成
     指定基準辺を元に指定のパラメータの渦巻き辺を得る。
     - CYCLONEならば指定基準辺から内側に、ANTICYCLONEならば外側に向かう辺の列を生成する。
     - 基準辺リストはポリゴンをなしていると期待している。辺の順序がparams.rotationの方向と異なる場合は期待する結果を返さない。
     @see OrbitalPathParam
     @param[in] baseEdgeList    基準辺リスト
     @param[in] params  その他パラメーター cf. OrbitalPathParam
     */
    vector<PathSegment> getVortexEdges(const vector<LineSegment>& baseEdgeList, const OrbitalPathParam& params) {
        vector<PathSegment> edgeList;
        if (baseEdgeList.empty()) {
            return edgeList;
        }
        
        // 渦巻き辺を全て求める
        for (int lap = 0; lap < params.count; lap++) {
            // シフト量(向き付き)
            const double shiftValue = params.getShiftValue(lap);
            LOGD(LOG_TAG "getVortexEdges", "shiftVal:%g", shiftValue);
            for (auto& edge : baseEdgeList) {
                const auto seg = getCollateralSegment(edge, shiftValue);
                edgeList.push_back(PathSegmentWork{seg});
                edgeList.back().pathAttr = PathAttr::RideType::ORBITAL_WORKING;
            }
        }

        LOGV(LOG_TAG "::getVortexEdges", "[BASE EDGES]\n%s", Svg::to_path_d(edgeList).c_str());

        return edgeList;
    }
    
    /**
     渦巻辺生成(外側基準)
     基準ポリゴン辺の内側せ接する渦巻き辺を得る。
     - 基準辺リストは右回りポリゴンをなしているものとする。
     @see OrbitalPathParam
     @param[in] baseEdgeList         境界ポリゴン
     @param[in] params  その他パラメーター cf. OrbitalPathParam
     */
    vector<PathSegment> getVortexEdgesOutsideOrigin(vector<LineSegment> baseEdgeList, const OrbitalPathParam& params) {
        OrbitalPathParam tmpParams = params;
        
        if (params.pattern == ANTICYCLONE) {
            // 基準辺の外側(内オリジン)で生成されるのでCYCLONEで生成して反転する
            tmpParams.pattern = Param::Work::Headland::Pattern::ANTICYCLONE;
            tmpParams.rotation = -tmpParams.rotation;
        }
        
        if (tmpParams.rotation == ANTICLOCKWISE) {
            // 入力は常に時計回り
            // 実際に使用するパラメータで判定する
            reverse(baseEdgeList);
        }
        
        auto edgeList = getVortexEdges(baseEdgeList, tmpParams);
        
        if (params.pattern == ANTICYCLONE) {
            // 基準辺の外側(内オリジン)で生成されるのでCYCLONEで生成して反転する
            reverse(edgeList);
        }
        
        return edgeList;
    }

    /**
     進入辺検索
     
     segでedgeList内へ侵入する辺を探索し、イテレータで返す
     */
    template<typename T>
    typename vector<T>::iterator findEnterEdge(const LineSegment& seg, vector<T>& edgeList, const vector<XY_Point>& whp)
    {
        const auto whpEdgeList = getEdgeList(whp, whp.cbegin());
        auto resultIt = edgeList.end();
        double nearestDistance = -1.0;
        LOGD(LOG_TAG "::findEnterEdge", "srcSeg:%s", to_string(seg).c_str());
        for (auto it = edgeList.begin(); it != edgeList.end(); it++) {
            const auto orgEdge = *it;
            auto edge = orgEdge;
            LineSegment srcSeg = seg;
            LOGV(LOG_TAG "::findEnterEdge", "edgeList[%d] %s", (int)std::distance(edgeList.begin(), it), to_string(edge).c_str());
            if (connectEntering(srcSeg, edge)) {
                // TODO:完全には救えていないが、現状だと明らかに取り違えるケースがあるため暫定対応
                // エッジ側の線分外で交差する場合、はみ出た長さを追加して判定する
                double add = 0;
                double edgeLen = orgEdge.length();
                // edge.enterPoint() : 求めた交点
                double d2Enter = orgEdge.enterPoint().distance(edge.enterPoint());
                double d2Leave = orgEdge.leavePoint().distance(edge.enterPoint());
                if (d2Enter > edgeLen) {
                    // 求めた交点はorgEdge.leavePoint()の外側、はみ出た分を追加する
                    add = d2Leave;
					// はみ出た分のセグメントがwhpEdgeListと交差する場合、その侵入辺は使用不可
					LineSegment extSeg = orgEdge;
					extSeg.enterPoint() = edge.leavePoint();
					auto it = whpEdgeList.begin();
					for (; it != whpEdgeList.end(); ++it) {
						auto whpEdge = *it;
						if (it->checkIntersection(extSeg) != Intersection::NO) {
							add = 1000000;
							break;
						}
					}
                }
                if (d2Leave > edgeLen) {
                    // 求めた交点はorgEdge.enterPoint()の外側、はみ出た分を追加する
                    add = d2Enter;
					// はみ出た分のセグメントがwhpEdgeListと交差する場合、その侵入辺は使用不可
					LineSegment extSeg = orgEdge;
					extSeg.leavePoint() = edge.leavePoint();
					auto it = whpEdgeList.begin();
					for (; it != whpEdgeList.end(); ++it) {
						auto whpEdge = *it;
						if (it->checkIntersection(extSeg) != Intersection::NO) {
							add = 1000000;
							break;
						}
					}
                }
                const double distance = seg.leavePoint().distance(srcSeg.leavePoint()) + add;
                LOGD(LOG_TAG "::findEnterEdge", "hit! distance:%g", distance);
                if (nearestDistance < 0.0 || distance < nearestDistance) {
                    resultIt = it;
                    nearestDistance = distance;
                }
            }
        }
        LOGD(LOG_TAG "::findEnterEdge", "size:%d, enter index:%d, distance:%g", (int)edgeList.size(), (int)std::distance(edgeList.begin(), resultIt), nearestDistance);
        return resultIt;
    }

    /**
     脱出辺検索
     
     edgeList内からsegで脱出する辺を探索し、イテレータで返す
     */
    template<typename T>
    typename vector<T>::iterator findLeaveEdge(const LineSegment& seg, vector<T>& edgeList, const vector<XY_Point>& whp)
    {
        const auto whpEdgeList = getEdgeList(whp, whp.cbegin());
        auto resultIt = edgeList.rend();
        double nearestDistance = -1.0;
        LOGD(LOG_TAG "::findLeaveEdge", "srcSeg:%s", to_string(seg).c_str());
        for (auto rit = edgeList.rbegin(); rit != edgeList.rend(); rit++) {
            const auto orgEdge = *rit;
            auto edge = orgEdge;
            LineSegment destSeg = seg;
            LOGV(LOG_TAG "::findLeaveEdge", "edgeList[%d] %s", (int)std::distance(edgeList.begin(), rit.base()) - 1, to_string(edge).c_str());
            if (connectLeaving(edge, destSeg)) {
                // TODO:完全には救えていないが、現状だと明らかに取り違えるケースがあるため暫定対応
                // エッジ側の線分外で交差する場合、はみ出た長さを追加して判定する
                double add = 0;
                double edgeLen = orgEdge.length();
                // edge.leavePoint() : 求めた交点
                double d2Enter = orgEdge.enterPoint().distance(edge.leavePoint());
                double d2Leave = orgEdge.leavePoint().distance(edge.leavePoint());
                if (d2Enter > edgeLen) {
                    // 求めた交点はorgEdge.leavePoint()の外側、はみ出た分を追加する
                    add = d2Leave;
					// はみ出た分のセグメントがwhpEdgeListと交差する場合、その脱出辺は使用不可
					LineSegment extSeg = orgEdge;
					extSeg.enterPoint() = edge.leavePoint();
					auto it = whpEdgeList.begin();
					for (; it != whpEdgeList.end(); ++it) {
						auto whpEdge = *it;
						if (it->checkIntersection(extSeg) != Intersection::NO) {
							add = 1000000;
							break;
						}
					}
                }
                if (d2Leave > edgeLen) {
                    // 求めた交点はorgEdge.enterPoint()の外側、はみ出た分を追加する
                    add = d2Enter;
					// はみ出た分のセグメントがwhpEdgeListと交差する場合、その脱出辺は使用不可
					LineSegment extSeg = orgEdge;
					extSeg.leavePoint() = edge.leavePoint();
					auto it = whpEdgeList.begin();
					for (; it != whpEdgeList.end(); ++it) {
						auto whpEdge = *it;
						if (it->checkIntersection(extSeg) != Intersection::NO) {
							add = 1000000;
							break;
						}
					}
                }
                const double distance = seg.enterPoint().distance(destSeg.enterPoint()) + add;
                if (nearestDistance < 0.0 || distance < nearestDistance) {
                    LOGD(LOG_TAG "::findLeaveEdge", "hit! distance:%g", distance);
                    resultIt = rit;  // reverse_itearatorはひとつ前を指す
                    nearestDistance = distance;
                }
            }
        }
        
        LOGD(LOG_TAG "::findLeaveEdge", "size:%d, enter index:%d, distance:%g", (int)edgeList.size(), (int)std::distance(edgeList.begin(), resultIt.base()) - 1, nearestDistance);
        return (resultIt == edgeList.rend()) ? edgeList.end() : std::prev(resultIt.base()); // reverse_iteratorはひとつ末尾側の要素を指す
    }

    /**
     交差辺検索
     edgeList内からpointが乗っている辺を探索し、イテレータで返す
     */
    template<typename T, typename U>
    typename vector<T>::iterator findFirstHitEdge(vector<T>& edgeList, const U& target)
    {
        auto resultIt = edgeList.end();
        for (auto it = edgeList.begin(); it != edgeList.end(); it++) {
            auto edge = *it;
            LOGV(LOG_TAG "::findFirstHitEdge", "HIT! %s on edgeList[%d] %s", to_string(target).c_str(), (int)std::distance(edgeList.begin(), it), to_string(edge).c_str());
            if (edge.checkIntersection(target) != Intersection::NO) {
                resultIt = it;
                break;
            }
        }

        LOGD(LOG_TAG "::findFirstHitEdge", "HIT! %s on edgeList[%d] %s", to_string(target).c_str(), (int)std::distance(edgeList.begin(), resultIt), to_string(*resultIt).c_str());
        return resultIt;
    }
    
    template<typename T, typename U>
    typename vector<T>::iterator findLastHitEdge(vector<T>& edgeList, const U& target)
    {
        auto resultIt = edgeList.rend();
        for (auto it = edgeList.rbegin(); it != edgeList.rend(); it++) {
            const auto& edge = *it;
            if (edge.checkIntersection(target) != Intersection::NO) {
                LOGV(LOG_TAG "::findLastHitEdge", "HIT! %s on edgeList[%d] %s", to_string(target).c_str(), (int)std::distance(edgeList.begin(), it.base()) - 1, to_string(edge).c_str());
                resultIt = it;
                break;
            }
        }

        
        auto it = (resultIt == edgeList.rend()) ? edgeList.end() : std::prev(resultIt.base());
        LOGD(LOG_TAG "::findLastHitEdge", "HIT! %s on edgeList[%d] %s", to_string(target).c_str(), (int)std::distance(edgeList.begin(), it), to_string(*it).c_str());
        return it;
    }

    template<typename T>
    inline static
    vector<T> getFirstLap(const vector<T>& edgeList, int edgeCount)
    {
        vector<T> firstLap;
        const auto ite = std::next(edgeList.cbegin(), edgeCount);
        for (auto it = edgeList.cbegin(); it != ite; it++) {
            auto pseg = *it;
            pseg.pathAttr = PathAttr::RideType::ORBITAL_NON_WORKING;
            firstLap.push_back(pseg);
        }
        
        return firstLap;
    }

    template<typename T>
    inline static
    vector<T> getFinalLap(const vector<T>& edgeList, int edgeCount)
    {
        vector<T> firstLap;
        for (auto it = std::prev(edgeList.cend(), edgeCount); it != edgeList.cend(); it++) {
            auto pseg = *it;
            pseg.pathAttr = PathAttr::RideType::ORBITAL_NON_WORKING;
            firstLap.push_back(pseg);
        }
        
        return firstLap;
    }

    /**
     OR遷移パス辺取得
     一周分の周回パス辺から指定のセグメントへ脱出する周回パス辺を返す。
     - 指定に従い各辺をシフトする。
     - 先頭から脱出する辺までの短い方向への辺のリストを返す。
     - 元の辺リストに対して逆回りの辺を返すときは、元の辺リストから遷移パスへの接続のための追加の辺を入れて返す。
     @param[in] edgeList        周回辺のリスト
     @param[in] dstSeg          周回バス脱出先セグメント
     @param[in] shiftdir        シフト方向
     @param[in] shiftLenFw          シフト幅
     @param[in] shiftLenFirst   最初の辺のシフト幅
     @param[in] shiftLenBw          逆回りのシフト幅
     @param[in] shiftLen2R          旋回直径のシフト幅
     @param[in] permitBackward  バック許可フラグ
     @param[in] params                  周回パス生成パラメータ
     */
    template<typename T>
    vector<T> getOrTransitEdgeList(vector<T> edgeList, const LineSegment& dstSeg, double shiftdir, double shiftLenFw, double shiftLenFirst, double shiftLenBw, double shiftLen2R, bool permitBackward, OrbitalPathParam& params, const vector<XY_Point>& whp)
    {
        const vector<T> orgEdgeList = edgeList;
        auto resultIt = findLeaveEdge(dstSeg, edgeList, whp);
        if (resultIt == edgeList.end()) {
            // 交差が見つからない
            ErrorPathGenerator err(ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
            err.setDescription("[EXCEPTION:ORBITAL] can't find Orbital - Raster transit segment.", "::makeEdgeList");
            throw err;
        }
        auto edge = *resultIt;
        auto lengths = getDivisionLengths(static_cast<LineSegment>(edge), dstSeg);
        // 周回長全体
        const double lapMilage = getMileage(edgeList);
        // ここまでの周回長
        double past = getMileage<T>(edgeList.begin(), resultIt);
        double fwMileage = past + lengths.first;
        // ここからの周回長
        const double bwMileage = lapMilage - fwMileage;
        LOGD(LOG_TAG "::getOrTransitEdgeList", "[ORBIT DIVISION] forward:backward = %g:%g", fwMileage, bwMileage);
        if (!permitBackward || fwMileage <= bwMileage) {
            // バック不可の場合は必ず順方向
            if (resultIt->getVector().getDotProductNormalized(dstSeg.getVector()) < -M_SQRT1_2) {
                // エッジとdstSegの角度が135度より大きい場合
                shiftLenFw = shiftLen2R;
            }
            // 順方向遷移パス
            edgeList.erase(std::next(resultIt), edgeList.end());
            auto itr = edgeList.begin();
            if (itr != edgeList.end()) {
                // 1本目だけ専用のシフト量を使用する
                auto& edge = *itr;
                edge.shift(edge.getEnterVector().getOrthogonal(shiftdir), shiftLenFirst);
                ++itr;
            }
            for (; itr != edgeList.end(); ++itr) {
                auto& edge = *itr;
                edge.shift(edge.getEnterVector().getOrthogonal(shiftdir), shiftLenFw);
            }
            if (permitBackward) {
                // バック許可
                vector<LineSegment> tmp;
                if (edgeList.size() == 1) {
                    tmp.push_back(orgEdgeList.back());
                } else if (edgeList.size() > 1) {
                    tmp.push_back(edgeList[edgeList.size() - 2]);
                }
                tmp.push_back(edgeList.back());
                tmp.push_back(dstSeg);
                if (joinCorner(tmp)) {
                    if (tmp[1].getVector().getDotProduct(edgeList.back().getVector()) < 0) {
                        // エッジの向きが反転した場合
                        // 最後のエッジが削除可能か判定する
                        tmp.pop_back(); // 1本目の内側作業パス
                        tmp.pop_back(); // 最後のエッジ
                        tmp.push_back(dstSeg); // 1本目の内側作業パス
                        if (edgeList.size() == 1 && joinCorner(tmp) && tmp[0].length() - orgEdgeList.back().length() < shiftLenFirst) {
                            // エッジが1本しかない
                            // かつ、エッジを削除して最後の外周作業パスと1本目の内側作業パスを接続した場合に
                            // 最後の外周作業パスに付けるパス足的な何かの長さが足りない場合
                            edgeList.back().shift(edgeList.back().getEnterVector().getOrthogonal(shiftdir), shiftLenBw - shiftLen2R * 0.5 - shiftLenFirst);
                        } else {
                            edgeList.pop_back();
                        }
                    } else if (params.pattern == Param::Work::Headland::Pattern::CYCLONE && (tmp[1].length() < shiftLen2R || tmp[1].getVector().getDotProductNormalized(dstSeg.getVector()) < -M_SQRT1_2)) {
                        // 最後のエッジが短い場合
                        // または、最後のエッジがdstSegと交差する角度が45度より小さい場合
                        // シフト量を減らす
                        const double shiftTemp = (edgeList.size() == 1) ? shiftLenFirst : shiftLenFw;
                        edgeList.back().shift(edgeList.back().getEnterVector().getOrthogonal(shiftdir), shiftLenBw - shiftLen2R * 0.5 - shiftTemp);
                    } else if (params.pattern == Param::Work::Headland::Pattern::ANTICYCLONE && tmp[1].length() < 5) {
                        // 最後のエッジが短い場合
                        edgeList.pop_back();
                    }
                }
            } else if (edgeList.size() == 1) {
                // バック不可、かつエッジが1本の場合、外周作業パス、エッジ、内側作業パスでコーナーを生成して旋回可能か判定する
                vector<T> tmpEdgeList = orgEdgeList;
                vector<LineSegment> tmp;
                tmp.push_back(tmpEdgeList.back());
                tmp.push_back(edgeList[0]);
                tmp.push_back(dstSeg);
                if (joinCorner(tmp)) {
                    if (tmp[1].getVector().getDotProduct(edgeList[0].getVector()) < 0 || tmp[1].length() < shiftLen2R) {
                        // joinCornerしたらエッジの向きが反転した、またはエッジが短い場合
                        // OR遷移パスの接続が困難と予想されるため1周回って入る
                        for (auto& edge : tmpEdgeList) {
                            edge.shift(edge.getEnterVector().getOrthogonal(shiftdir), shiftLenFw);
                        }
                        edgeList.swap(tmpEdgeList);
                    }
                }
            }
        } else {
            // 逆方向遷移パス
            auto itr = edgeList.begin();
            if (itr != edgeList.end()) {
                // 逆方向は1本目だけ専用のシフト量を使用する
                auto& edge = *itr;
                edge.shift(edge.getEnterVector().getOrthogonal(shiftdir), shiftLenFirst);
                ++itr;
            }
            for (; itr != edgeList.end(); ++itr) {
                auto& edge = *itr;
                edge.shift(edge.getEnterVector().getOrthogonal(shiftdir), shiftLenBw);
            }
            if (0.0 < shiftLenBw) {
                // シフトする時は端点がつながらないので次の辺を経由する
                auto addSeg = edgeList.front();
                edgeList.erase(edgeList.begin(), resultIt);
                edgeList.push_back(addSeg);
            } else {
                edgeList.erase(edgeList.begin(), resultIt);
            }
            reverse(edgeList);
            // 周回逆走属性を付加
            for_each(edgeList.begin(), edgeList.end(),
                    [](PathSegment& p) {
                        p.pathAttr.setExtAttr(PathAttr::RideType::COUNTER_ORBITAL);
                    });
            params.transitRotation = RotateDirection::invert(params.rotation);

            // 最後の外周作業パスと1本目の内側作業パスが交差する、かつ角度が浅い場合の救済処理
            if (edgeList.size() > 0) {
                vector<LineSegment> tmp;
                if (edgeList.size() == 1) {
                    // 最後の外周作業パス
                    tmp.push_back(orgEdgeList.back());
                } else {
                    // 末尾から2本目のエッジ
                    tmp.push_back(edgeList[edgeList.size() - 2]);
                }
                // 最後のエッジ
                tmp.push_back(edgeList.back());
                // 端点をつなぐ
                if (joinCorner(tmp)) {
                    // 最後のエッジと1本目の内側作業パスの交点を求める
                    auto cp = getCrossPoint(tmp[1], dstSeg);
                    double de = tmp[1].enterPoint().distance(cp);
                    double dl = tmp[1].leavePoint().distance(cp);
                    if ((!tmp[1].isAside(cp) && de < dl) || de < shiftLenBw) {
                        // シフト後のエッジとは交点が求まらない、かつ交点が最後のエッジの始点側の範囲外の場合
                        // または、最後のエッジに十分な長さがない場合
                        if (shiftLen2R == 0) shiftLen2R = shiftLenBw;
                        // シフト量を2Rに増やす
                        auto itr = edgeList.begin();
                        auto& edge = *itr;
                        edge.shift(edge.getVector().getOrthogonal(-shiftdir), (shiftLen2R - shiftLenFw) * 2 - shiftLenFirst);
                        ++itr;
                        for (; itr != edgeList.end(); ++itr) {
                            auto& edge = *itr;
                            edge.shift(edge.getVector().getOrthogonal(-shiftdir), (shiftLen2R - shiftLenFw) * 2 - shiftLenBw);
                        }
                        // tmpのシフト量も2Rに増やして繋ぎ直す
                        if (edgeList.size() == 2) {
                            tmp[0].shift(tmp[0].getVector().getOrthogonal(-shiftdir), (shiftLen2R - shiftLenFw) * 2 - shiftLenFirst);
                        } else if (edgeList.size() > 2) {
                            tmp[0].shift(tmp[0].getVector().getOrthogonal(-shiftdir), (shiftLen2R - shiftLenFw) * 2 - shiftLenBw);
                        }
                        tmp[1].shift(tmp[1].getVector().getOrthogonal(-shiftdir), (shiftLen2R - shiftLenFw) * 2 - shiftLenBw);
                        joinCorner(tmp);
                        // 最後のエッジと1本目の内側作業パスを接続するためのセグメントを追加する
                        auto addSeg = edgeList.back();
                        addSeg.enterPoint() = tmp[1].enterPoint();
                        addSeg.extendHead(-shiftLenBw);
                        auto tmpSeg = dstSeg;
                        tmpSeg.extendHead(shiftLenBw);
                        addSeg.leavePoint() = tmpSeg.enterPoint();
                        if (addSeg.length() > shiftLenBw && edgeList.back().getVector().getDotProduct(addSeg.getVector()) > 0 && addSeg.getVector().getDotProduct(dstSeg.getVector()) > 0) {
                            edgeList.push_back(addSeg);
                        } else {
                            // 追加するエッジに十分な長さがない
                            // または、最後のエッジと追加するエッジが90度以上曲がる
                            // または、追加するエッジと1本目の内側作業パスが90度以上曲がる
                            vector<T> tmpEdgeList = orgEdgeList;
                            auto leaveEdge = findLeaveEdge(dstSeg, tmpEdgeList, whp);
                            addSeg = *nextCyclic(tmpEdgeList, leaveEdge);
                            edgeList.push_back(addSeg);
                        }
                    }
                }
            }
        }

        return edgeList;
    }

    template<typename T>
    vector<T> getRoTransitEdgeList(vector<T> edgeList, const LineSegment& srcSeg, double shiftdir, bool permitBackward, OrbitalPathParam& params, const vector<XY_Point>& whp)
    {
        const vector<T> orgEdgeList = edgeList;
        double shiftLenFw = params.trEdgeMargin.shiftLenFw;
        double minInside = params.trEdgeMargin.shiftLenMin;
        double shiftLenBw = params.trEdgeMargin.shiftLenBw;

        auto resultIt = findEnterEdge(srcSeg, edgeList, whp);
        if (resultIt == edgeList.end()) {
            // 交差が見つからない
            ErrorPathGenerator err(ErrorCode::PathGeneration::Orbital::RASTER_ORBITAL_TRANSIT);
            err.setDescription("[EXCEPTION:ORBITAL] can't find Raster - Orbital transit segment.", "::makeEdgeList");
            throw err;
        }
        auto edge = *resultIt;
        auto lengths = getDivisionLengths(static_cast<LineSegment>(edge), srcSeg);
        // 周回長全体
        const double lapMilage = getMileage(edgeList);
        // ここまでの周回長
        double past = getMileage<T>(edgeList.begin(), resultIt);
        double fwMileage = past + lengths.first;
        // ここからの周回長
        const double bwMileage = lapMilage - fwMileage;
        LOGD(LOG_TAG "::getRoTransitEdgeList", "[ORBIT DIVISION] forward:backward = %g:%g", fwMileage, bwMileage);
        if (permitBackward && resultIt == edgeList.begin() && lengths.first < 10) {
            edgeList.clear();
            return edgeList;
        }
        if (permitBackward && fwMileage <= bwMileage) {
            // R-O(逆方向)の遷移パス (後半を消して逆走する) (最後の辺を利用して逆走から周回作業に繋げる)
            params.transitRotation = -params.rotation;
            params.trEdgeAlt = OrbitalPathParam::TransitAltitude::HIGH;
            auto addSeg = edgeList.back();
            addSeg.shift(addSeg.getVector().getOrthogonal(-shiftdir), shiftLenFw);
            edgeList.erase(std::next(resultIt), edgeList.end());
            auto itr = edgeList.begin();
            // 外周作業パス1本目と平行に逆走するエッジは旋回半径の2倍だけシフトする
            itr->shift(itr->getVector().getOrthogonal(-shiftdir), shiftLenBw);
            ++itr;
            for (; itr != edgeList.end(); ++itr) {
                if (itr == resultIt) {
                    if (itr->getVector().getDotProductNormalized(srcSeg.getVector()) > M_SQRT1_2) {
                        // srcSegと交差するエッジ=最後のエッジ=reverse後の最初のエッジが
                        // srcSegと交差する角度が45度より小さい場合 (reverse後だと交差する角度が135度より大きい場合)
                        itr->shift(itr->getVector().getOrthogonal(-shiftdir), shiftLenFw + shiftLenBw);
                        LineSegment lseg1 = LineSegment(srcSeg.leavePoint(), itr->getVector().getOrthogonal(-shiftdir), shiftLenBw);
                        LineSegment lseg2 = *itr;
                        auto cp = getCrossPoint(lseg1, lseg2);
                        itr->leavePoint() = cp;
                        // 遷移エッジ遠い
                        params.trEdgeAlt = OrbitalPathParam::TransitAltitude::HIGH;
                        break;
                    } else {
                        // 遷移エッジ近い
                        params.trEdgeAlt = OrbitalPathParam::TransitAltitude::LOW;
                    }
                }
                itr->shift(itr->getVector().getOrthogonal(-shiftdir), shiftLenFw);
            }
            edgeList.insert(edgeList.begin(), addSeg);
            reverse(edgeList);
            if (edgeList.size() == 1) {
                // エッジが1本しか残っていない場合
                if (permitBackward) {
                    auto cp = getCrossPoint(srcSeg, edgeList[0]);
                    if (!edgeList[0].isAside(cp) && edgeList[0].leavePoint().distance(cp) < edgeList[0].enterPoint().distance(cp)) {
                        // シフト後のエッジとは交点が求まらない、かつ交点が1本目の外周作業パス側の範囲外の場合、外周作業パスに接続する (RO遷移なし)
                        // TODO:不等号が逆の場合はエッジの追加が必要かも
                        edgeList.clear();
                    }
                } else {
                    // バック不可、かつエッジが1本の場合、内側作業パス、エッジ、外周作業パスでコーナーを生成して旋回可能か判定する
                    vector<LineSegment> tmp;
                    tmp.push_back(srcSeg);
                    tmp.push_back(edgeList[0]);
                    tmp.push_back(orgEdgeList.front());
                    if (joinCorner(tmp) && tmp[1].length() < shiftLenBw) {
                        // RO遷移パスの接続が困難と予想されるため1周回って出る
                        vector<T> tmpEdgeList = orgEdgeList;
                        for (auto& edge : tmpEdgeList) {
                            edge.shift(edge.getVector().getOrthogonal(-shiftdir), shiftLenBw);
                        }
                        reverse(tmpEdgeList);
                        edgeList.insert(edgeList.end(), tmpEdgeList.begin(), tmpEdgeList.end());
                    }
                }
            } else {
                // エッジが2本以上残っている場合、シフト後のエッジを先頭から2本取得
                auto edge1 = edgeList[0];
                auto edge2 = edgeList[1];
                // エッジの端点をつなぐ
                auto cp = getCrossPoint(edge1, edge2);
                edge1.leavePoint() = cp;
                edge2.enterPoint() = cp;
                // 内側作業パスと1本目のエッジの交点を求める
                auto cp1 = getCrossPoint(srcSeg, edge1);
                if (!edge1.isAside(cp1) && edge1.leavePoint().distance(cp1) < edge1.enterPoint().distance(cp1)) {
                    // シフト後のエッジとは交点が求まらないので2本目のエッジにつなぐ
                    edgeList.erase(edgeList.begin(), std::next(edgeList.begin()));
                } else if (LineSegment(cp1, cp).getVector().getDotProduct(edgeList[0].getVector()) < 0) {
                    // 1本目のエッジが反転してしまう場合も2本目のエッジにつなぐ
                    edgeList.erase(edgeList.begin(), std::next(edgeList.begin()));
                } else if (cp1.distance(cp) < shiftLenBw && edgeList.size() != 3) {
                    // 1本目のエッジが短い場合、2本目のエッジのシフト量を増やす
                    // ただし、エッジが3本(内側作業パスと交差するエッジ、1本目の外周作業パスと平行に逆走するエッジ、反転に使用するエッジ)の場合、2本目のエッジのシフト量はすでに増やしているので、それ以上は増やさない
                    edgeList[1].shift(edgeList[1].getVector().getOrthogonal(shiftdir), shiftLenBw - shiftLenFw);
                }
            }
        } else {
            // R-O(順方向)の遷移パス
            params.transitRotation = params.rotation;
            // - バック不可の場合は大きい方を使用
            params.trEdgeAlt = OrbitalPathParam::TransitAltitude::LOW;
            if (!permitBackward) {
                params.trEdgeAlt = OrbitalPathParam::TransitAltitude::HIGH; // 遠い
                shiftLenFw = std::max(shiftLenFw, shiftLenBw);
            }
            // 順方向なので前半を消す
            edgeList.erase(edgeList.begin(), resultIt);
            for (auto& edge : edgeList) {
                edge.shift(edge.getVector().getOrthogonal(-shiftdir), shiftLenFw);
            }
            if (edgeList.size() == 1) {
                // エッジが1本しか残っていない場合
                if (permitBackward) {
                    auto cp = getCrossPoint(srcSeg, edgeList[0]);
                    if (!edgeList[0].isAside(cp) && edgeList[0].leavePoint().distance(cp) < edgeList[0].enterPoint().distance(cp)) {
                        // シフト後のエッジとは交点が求まらない、かつ交点が1本目の外周作業パス側の範囲外の場合、外周作業パスに接続する (RO遷移なし)
                        edgeList.clear();
                    }
                } else {
                    // バック不可、かつエッジが1本の場合、内側作業パス、エッジ、外周作業パスでコーナーを生成して旋回可能か判定する
                    vector<LineSegment> tmp;
                    tmp.push_back(srcSeg);
                    tmp.push_back(edgeList[0]);
                    tmp.push_back(orgEdgeList.front());
                    if (joinCorner(tmp)) {
                        if (tmp[1].getVector().getDotProduct(edgeList[0].getVector()) < 0 || tmp[1].length() < shiftLenBw) {
                            // joinCornerしたらエッジの向きが反転した、またはエッジが短い場合
                            // RO遷移パスの接続が困難と予想されるため1周回って出る
                            vector<T> tmpEdgeList = orgEdgeList;
                            for (auto& edge : tmpEdgeList) {
                                edge.shift(edge.getVector().getOrthogonal(-shiftdir), shiftLenBw);
                            }
                            edgeList.insert(edgeList.end(), tmpEdgeList.begin(), tmpEdgeList.end());
                        }
                    }
                }
            } else {
                // エッジが2本以上残っている場合、シフト後のエッジを先頭から2本取得
                auto edge1 = edgeList[0];
                auto edge2 = edgeList[1];
                // エッジの端点をつなぐ
                auto cp = getCrossPoint(edge1, edge2);
                edge1.leavePoint() = cp;
                edge2.enterPoint() = cp;
                // 内側作業パスと1本目のエッジの交点を求める
                auto cp1 = getCrossPoint(srcSeg, edge1);
                if (!edge1.isAside(cp1)) {
                    // シフト後のエッジとは交点が求まらないので2本目のエッジにつなぐ
                    edgeList.erase(edgeList.begin(), std::next(edgeList.begin()));
                }
            }
        }
        return edgeList;
    }

    template<typename T>
    vector<T> getCollateralEdgeList(vector<T> edgeList, double d) {
        vector<T> retval;
        for_each(edgeList.begin(), edgeList.end(),
                 [&](T& seg) {
                    auto newseg = T{getCollateralSegment(seg, d)};
                    retval.push_back(newseg);
                 });

        return retval;
    }

    /**
     *  周回辺生成(先)
     *  周回パスの渦巻き辺のリストを受け取り、開始ナビゲーション辺とO-R遷移パス辺を追加する。
     *
     * @param[in] seg                  周回パス脱出セグメント(ラスターパス先頭セグメント)
     * @param[in] polygon           周回パス辺リスト
     * @param[in] firstvornerNode    周回開始頂点
     * @param[in] params             周回パス生成パラメータ
     */
    vector<PathSegment> PathGenerator::makeEdgeListPreOrbital(LineSegment& seg, vector<PathSegment> edgeList, int edgeCount, OrbitalPathParam& params) const {
        // 周回接線の準備
        vector<PathSegment> startNaviEdgeList;

        // コーナー接続
        if (!joinCorner(edgeList, edgeCount)) {
            // 周回パスが生成できない
            LOGE(LOG_TAG "::makeEdgeListPreOrbital", "[JOIN CORNER FAILED1]\n%s", Svg::to_path_d(edgeList).c_str());
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::RASTER_ORBITAL_TRANSIT);
            err.setDescription("[EXCEPTION:ORBITAL] can't create orbital path.", "::makeEdgeList");
            throw err;
        }
        
        // 先頭辺の調整
        auto firstEdgeIt = edgeList.end();
        if (!inputPathNodeList.empty()) {
            // 1周目をコピー
            startNaviEdgeList = getFirstLap(edgeList, edgeCount);
            joinCorner(startNaviEdgeList, edgeCount);
            // スタートライン
            auto startLine = traverseInfo.orbital.startLine;
            // - スタートラインと交差する最初の辺まで削除
            LOGD(LOG_TAG "::makeEdgeListPreOrbital", "start line: %s", to_string(startLine).c_str());
            for (double extend = 0.0; extend < 100.0; extend += 0.5) {
                // 最内周はWHPの内側になる場合がある
                auto startLine2 = startLine;
                startLine2.extendBoth(extend);
                firstEdgeIt = findFirstHitEdge(startNaviEdgeList, startLine2);
                if (firstEdgeIt != startNaviEdgeList.end()) {
                    LOGD(LOG_TAG "::makeEdgeListPreOrbital", "startLine: %s", Svg::to_path(startLine2).c_str());
                    break;
                }
            }

            if (params.pattern == Param::Work::Pattern::ANTICYCLONE) {
                LOGD(LOG_TAG "::makeEdgeListPreOrbital", "START FROM CORNER: add start navigation later.");
                // 先外周作業で外向き
                // 運転開始位置からの開始ナビゲーションパスを生成するため不要
                startNaviEdgeList.clear();
            } else if (firstEdgeIt == startNaviEdgeList.begin()) {
                LOGD(LOG_TAG "::makeEdgeListPreOrbital", "START FROM CORNER");
                startNaviEdgeList.clear();
            } else if (firstEdgeIt != startNaviEdgeList.end()) {
                auto& firstEdge = *firstEdgeIt; // 後で直接いじるため non-const reference
                auto nextEdgeIt = std::next(firstEdgeIt);
                const auto lengths = getDivisionLengths(static_cast<LineSegment>(firstEdge), startLine);
                LOGD(LOG_TAG "::makeEdgeListPreOrbital", "firstSeg: %s; div:%g, %g", to_string(firstEdge).c_str(), lengths.first, lengths.second);
                if (lengths.first < gauge.headland.orbitalEdge.headSleshold) {
                    // この辺全て使用
                    LOGV(LOG_TAG "::makeEdgeListPreOrbital", "USE WHOLE: within %g from enter.", gauge.truncateLength.start);
                    if (firstEdgeIt != startNaviEdgeList.begin()) {
                        startNaviEdgeList.erase(startNaviEdgeList.begin(), firstEdgeIt);
                    } else {
                        LOGD(LOG_TAG "::makeEdgeListPreOrbital", "NONE OF LAP");
                        startNaviEdgeList.clear();
                    }
                } else if (lengths.second < gauge.headland.orbitalEdge.tailSleshold) {
                    // 次の辺から使用
                    LOGV(LOG_TAG "::makeEdgeListPreOrbital", "USE NEXT: within %g to leave.", gauge.truncateLength.end);
                    if (nextEdgeIt != startNaviEdgeList.end()) {
                        startNaviEdgeList.erase(startNaviEdgeList.begin(), nextEdgeIt);
                    } else {
                        LOGD(LOG_TAG "::makeEdgeListPreOrbital", "NONE OF LAP");
                        startNaviEdgeList.clear();
                    }
                } else {
                    // この辺の途中から開始
                    firstEdge.pathAttr = PathAttr::RideType::ORBITAL_NON_WORKING;
                    firstEdge.extendHead(-lengths.first);
                    LOGV(LOG_TAG "::makeEdgeListPreOrbital", "START FROM MIDDLE of %g", lengths.first);
                    startNaviEdgeList.erase(startNaviEdgeList.begin(), firstEdgeIt);
                }
            } else {
                LOGE(LOG_TAG "::makeEdgeListPreOrbital", "start pos unable to apply");
                startNaviEdgeList.clear();
            }
        }
        //  最終周
        // O-R遷移
        vector<PathSegment> transitEdgeList = (params.pattern == CYCLONE) ? getFinalLap(edgeList, edgeCount) : getFinalLap(edgeList, edgeCount);
        setTurnType(transitEdgeList, TurnType::NAVIGATION);
        const PathAttr transitEdgeAttr = transitEdgeList.front().pathAttr;
        if (!joinCorner(transitEdgeList)) {
            // コーナー形成に失敗
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
            err.setDescription("[EXCEPTION:ORBITAL] can't connect edges.", "::makeEdgeListPreOrbital");
            throw err;
        }

        // 遷移パス辺の調整
        // - 遷移に容易な位置を周回する
        bool directTransitStart = false;
        {
            LineSegment destSeg{seg};
            LOGD(LOG_TAG "::makeEdgeListPreOrbital", "Raser enter seg : orbital edge\n%s", Svg::to_path(seg).c_str());
            LOGD(LOG_TAG "::makeEdgeListPreOrbital", "transitEdgeList base\n%s", Svg::to_path(transitEdgeList).c_str());
            if (params.pattern == CYCLONE) {
                // 内向き渦巻は外側にシフトする
                double shiftLen = gauge.minFpsLegLength + gauge.turnRadius + gauge.fpGauge.whpDiff + TOL_ONE_CM;
                double shiftLen2R = gauge.minFpsLegLength + gauge.turnRadius * 2.0 + gauge.fpGauge.whpDiff + TOL_ONE_CM;
                if (!gauge.implement.canBackward) {
                    shiftLen = std::max(shiftLen, shiftLen2R);
                }
                double shiftLenFirst = shiftLen;    // OR遷移パス1本目のセグメント用
                double shiftdir = -params.rotation;
                const auto& eSeg = edgeList.front();
                const auto& lSeg = edgeList.back();
                const int OwEndCornerOrient = getCornerOrient(lSeg, eSeg);
                directTransitStart = ((params.rotation != OwEndCornerOrient) && gauge.implement.canBackward);
                if (directTransitStart) {
                    LOGD(LOG_TAG "::makeEdgeListPreOrbital", "Orbital working end at concave corner.");
                    // 凹角でOR遷移パスに移行する場合最初の辺は内周近くを走るようにする
                    Vector2D sVec{0.0, gauge.workPath.expandLength};
                    const auto& firstSeg = transitEdgeList.front();
                    shiftLenFirst = gauge.minSpsLegLength * std::abs(firstSeg.getVector().getUnitVector().getCrossProduct(sVec));
                }
                // 遷移辺 (とりあえず順方向、逆方向のシフト量は同じ)
                transitEdgeList = getOrTransitEdgeList(transitEdgeList, destSeg, shiftdir, shiftLen, shiftLenFirst, shiftLen, shiftLen2R, gauge.headland.permitBackward, params, hwParam.whp);
                if (directTransitStart && !transitEdgeList.empty()) {
                    // 凹角の場合、周回作業終了セグメントのウィスカー補正値を設定しておく
                    adjustWorkingEndWhisker(seg, edgeList, transitEdgeList, params);
                }
            } else {
                // 外向き渦巻は内側にシフトする
                double shiftLen = gauge.turnRadius * 2.0 + TOL_ONE_CM;
                double shiftdir = params.rotation;
                if (!gauge.implement.canBackward) {
                    const double shiftlenNb= gauge.getOuterRadius(gauge.turnRadius) + gauge.turnRadius * 2.0 + gauge.minFpsLegLength + gauge.fpGauge.whpDiff + TOL_ONE_CM;
                    shiftLen = std::max(shiftlenNb, shiftLen);
                }
                // 遷移パスは(外周作業用HP＋トラクターの幅)より内側を走行しない
                shiftLen = std::min(shiftLen, params.interval * (params.count - 1) - params.clearance - gauge.halfTractorWidth * 2.0);
                // 順方向、および逆方向1本目のシフト量は0 (最外周をそのまま走る)
                transitEdgeList = getOrTransitEdgeList(transitEdgeList, destSeg, shiftdir, 0, 0, shiftLen, 0, gauge.headland.permitBackward, params, hwParam.whp);
            }

            if (transitEdgeList.empty()) {
                // transitEdgeListが空の場合、1本目の内側作業パスを使用
                auto lastOwSeg = edgeList.back();
                auto firstRwSeg = PathSegment(seg);
                if (connectAny(lastOwSeg, firstRwSeg)) {
                    lastOwSeg.enterPoint() = edgeList.back().leavePoint();
                    lastOwSeg.pathAttr = transitEdgeAttr;
                    if (!lastOwSeg.isNegrective()) {
                        transitEdgeList.insert(transitEdgeList.cbegin(), lastOwSeg);
                    }
                }
            } else {
                if (!directTransitStart) {
                    // 周回作業パスの終点とOR遷移パスの間をさ非作業パスで接続
                    auto lastOwSeg = edgeList.back();
                    auto lastOwSegOrg = lastOwSeg;
                    auto firstTrSeg = transitEdgeList.front();
                    if (connectAny(lastOwSeg, firstTrSeg)) {
                        lastOwSeg.enterPoint() = edgeList.back().leavePoint();
                        lastOwSeg.pathAttr = firstTrSeg.pathAttr;
                        if (!lastOwSeg.isNegrective()) {
                            transitEdgeList.insert(transitEdgeList.cbegin(), lastOwSeg);
                        }
                    }
                }
            }
        }
        LOGD(LOG_TAG "::makeEdgeListPreOrbital", "transitEdgeList\n%s", Svg::to_path(transitEdgeList).c_str());
        
//      PGASSERT(edgeList.back().checkConnection(transitEdgeList.front()) == Line::Connection::SMOOTH, "O-R transit path connection error.");
        // 作業開始点調整
        if (params.pattern == Param::Work::Pattern::ANTICYCLONE) {
            if (startNaviEdgeList.empty()) {
                // 先頭が作業セグメントの場合、コーナーでないのでオーバーラップ量を調整しておく
                adjustWorkingStartPoint(edgeList, params);
            } else {
                // 先頭がナビゲーションの場合、ウィスカー補正値を設定しておく
                adjustWorkingStartWhisker(seg, startNaviEdgeList, edgeList, params);
            }
        }
        startNaviEdgeList.insert(startNaviEdgeList.cend(), edgeList.cbegin(), edgeList.cend());
        edgeList = std::move(startNaviEdgeList);
        edgeList.insert(edgeList.cend(), transitEdgeList.cbegin(), transitEdgeList.cend());

        if (!joinCorner(edgeList)) {
            // コーナー形成に失敗
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
            err.setDescription("[EXCEPTION:ORBITAL] can't connect edges.", "::makeEdgeListPreOrbital");
            throw err;
        }
        LOGD(LOG_TAG "::makeEdgeListPreOrbital", "EdgeList\n%s", Svg::to_path(edgeList).c_str());
        return edgeList;
    }

    /**
     周回辺の終点調整
     周回作業が後、かつ外向き渦巻で、終了点が指定されていたら指定の周回辺リストをゴールラインで打ち切るように調整する。
     - cf. traverseInfo.orbital.goalLine
     @param[in] edgeList           周回パス辺リスト
     @param[in] firstvornerNode    周回開始頂点
     @param[in] params             周回パス生成パラメータ
    */
    void PathGenerator::adjustPostAnticycloneEndPoint(vector<PathSegment>& edgeList, int edgeCount, OrbitalPathParam& params) const {
        // 最終辺の調整
        auto finalEdgeIt = edgeList.end();
        if (!inputPathNodeList.empty() && hwParam.endPointAvailable &&
            params.pattern == Param::Work::Headland::Pattern::ANTICYCLONE) {
            // ゴールラインと交差する最後の辺で終了
            auto goalLine = traverseInfo.orbital.goalLine;
            LOGD(LOG_TAG "::adjustObitalEndPoint", "end pos: %s", to_string(goalLine).c_str());
            finalEdgeIt = findLastHitEdge(edgeList, goalLine);
            params.halfway = false;
            if (finalEdgeIt != edgeList.end()) {
                // 終了辺発見
                const auto finalSeg = *finalEdgeIt;
                // 終了辺の残りの長さを判定
                auto lengths = getDivisionLengths(static_cast<LineSegment>(finalSeg), goalLine);
                bool edgeHalfway = true;
                if (lengths.second < gauge.headland.orbitalEdge.tailSleshold) {
                    LOGD(LOG_TAG "::adjustObitalEndPoint", "end pos is corner");
                    // 終了点は次のコーナーなので残す
                    finalEdgeIt++;
                    edgeHalfway = false;
                } else if (lengths.first < gauge.headland.orbitalEdge.headSleshold) {
                    // 終了点は前のコーナーなので削除
                    // - finalEdgeItがこの辺を指している
                    edgeHalfway = false;
                } else {
                    // 終了点はこの辺上なので残す
                    finalEdgeIt++;
                    edgeHalfway = true;
                }

                // 一周以上は処理しない
                auto eraseCount = std::distance(finalEdgeIt, edgeList.end());
                if (edgeCount <= eraseCount) {
                    // 一周したので削除無し
                    finalEdgeIt = edgeList.end();
                    edgeHalfway = false;
                }

                // 周回打ち切りフラグを返す
                if ((finalEdgeIt != edgeList.end() || edgeHalfway)) {
                    // 削除する辺があるか、辺の途中で終了する
                    LOGD(LOG_TAG "::adjustObitalEndPoint", "Post orbital: halfway lap");
                    // 周回は途中で打ち切りになる
                    params.halfway = true;
                } else {
                    LOGD(LOG_TAG "::adjustObitalEndPoint", "Post orbital: complete lap.");
                }

                // 終了辺より後ろを削除
                edgeList.erase(finalEdgeIt, edgeList.end());
                // 最終辺の途中で打ち切り処理
                if (params.halfway) {
                    auto& lastEdge = edgeList.back();
                    lastEdge.extendTail(-lengths.second);
                }
            } else {
                // 終了辺発見できず
                LOGD(LOG_TAG "::adjustObitalEndPoint", "goal line has no cross with any edge");
                params.halfway = false;
            }
        }
    }

    /**
     *  周回辺生成(後)
     *  周回パスの渦巻き辺のリストを受け取り、R-O遷移パス辺の追加と最終周の調整をする。
     *　- R-O遷移パスは指定の周回方向に次のコーナーまで、ただし、コーナー直後の場合その直近のコーナーから開始する。
     *　- 最終周はゴールラインで打ち切る。cf. traverseInfo.orbital.goalLine
     * @param[in] seg                  周回パス脱出セグメント(ラスターパス先頭セグメント)
     * @param[in] edgeList           周回パス辺リスト
     * @param[in] firstvornerNode    周回開始頂点
     * @param[in] params             周回パス生成パラメータ
     */
    vector<PathSegment> PathGenerator::makeEdgeListPostOrbital(LineSegment& seg, vector<PathSegment> edgeList, int edgeCount, OrbitalPathParam& params) const {
        // 周回接線の準備
        vector<PathSegment> startNaviEdgeList;
        vector<PathSegment> transitEdgeList;

        // コーナー接続
        if (!joinCorner(edgeList, edgeCount)) {
            // 周回パスが生成できない
            LOGE(LOG_TAG "::makeEdgeList", "[JOIN CORNER FAILED]\n%s", Svg::to_path_d(edgeList).c_str());
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::RASTER_ORBITAL_TRANSIT);
            err.setDescription("[EXCEPTION:ORBITAL] can't create orbital path.", "::makeEdgeList");
            throw err;
        }

        // 終点調整
        adjustPostAnticycloneEndPoint(edgeList, edgeCount, params);

        // R-O遷移パス
        transitEdgeList = (params.pattern == CYCLONE) ? getFinalLap(edgeList, (int)edgeCount) : getFirstLap(edgeList, (int)edgeCount);
        setTurnType(transitEdgeList, TurnType::NAVIGATION);
        //  開始辺の調整
        LineSegment srcSeg = seg;
        {   // パラメータ準備
            // - 順方向マージン ヒッチアップダウンマージンを踏むので少し外側を走る
            params.trEdgeMargin.shiftLenMin = gauge.halfTractorWidth + gauge.workPath.compensateLength + gauge.headland.transitOrbitMargin;
            if (gauge.headland.permitBackward) {
                params.trEdgeMargin.shiftLenFw = params.trEdgeMargin.shiftLenMin;
            } else {
                params.trEdgeMargin.shiftLenFw = gauge.turnRadius + gauge.minSpsLegLength;
            }
            // - 逆方向マージン 外周作業への接続時、Uターン気味になるので、もう少し外側を走る
            params.trEdgeMargin.shiftLenBw = gauge.turnRadius * 2;
        }
        // 遷移パスエッジ生成
        transitEdgeList = getRoTransitEdgeList(transitEdgeList, srcSeg, params.rotation, gauge.headland.permitBackward, params, hwParam.whp);
        if (params.pattern == Param::Work::Pattern::ANTICYCLONE) {
            // 先頭が作業セグメントの場合、コーナーでないのでオーバーラップ量を調整しておく
            adjustWorkingStartWhisker(seg, transitEdgeList, edgeList, params);
        }
        // - 遷移パスエッジ追加
        transitEdgeList.insert(transitEdgeList.cend(), edgeList.cbegin(), edgeList.cend());
        edgeList = std::move(transitEdgeList);
        
        if (!joinCorner(edgeList)) {
            // 周回パスが生成できない
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::RASTER_ORBITAL_TRANSIT);
            err.setDescription("[EXCEPTION:ORBITAL] can't create orbital path.", "::makeEdgeList");
            throw err;
        }
        if (params.pattern == ANTICYCLONE) {
            // 外周作業が後、かつ外周が内外の場合
            // 最後のエッジを出口側まで走行した時にトラクターの前側がBPに衝突するような場合、必要な分だけエッジを切り詰めたい
            // ただし、入口側についてはバックウィスカーが宜しくやってくれるはずなので、トラクターの後方は衝突判定を無視したい
            auto edge = edgeList.back();
            // TODO:適当な判定方法が分からなかったため、力技で実装
            // 最低でもトラクター幅の1/2は余裕があるはず、そこからtailLengthの分だけ短くすれば衝突しないはず、伸ばす必要はないので0より大きくはしない
            edge.extendHead(std::min(0.0, gauge.tractor.width * 0.5 - gauge.tractor.tailLength));
            double shorten = 0;
            while (edge.length() > 0.1 && checkBoundaryIntersection(edge, BoundaryType::Kind::Mask::SBP) == Intersection::YES) {
                // トラクターの前方が衝突しなくなるまで、10cm刻みで切り詰める
                edge.extendTail(-0.1);
                shorten -= 0.1;
            }
            edgeList.back().extendTail(shorten - TOL_ONE_CM);
        }
        
        return edgeList;
    }

    /**
     渦巻辺リスト生成
     圃場ポリゴンからparamに従って周回パス生成用の渦巻き辺のリストを生成する。
     - 各辺はコーナーで接続してある。
     
     @param[in] seg                周回パス進入または脱出セグメント
     @param[in] polygon            圃場ポリゴン
     @param[in] firstvornerNode    周回開始頂点
     @param[in] params             周回パス生成パラメータ
     */
    vector<PathSegment> PathGenerator::makeEdgeList(LineSegment& seg, BoundaryPolygon polygon, int firstCornerNode, OrbitalPathParam& params) const {
        // 周回接線の準備
        vector<PathSegment> startNaviEdgeList;
        vector<PathSegment> edgeList;
        vector<PathSegment> transitEdgeList;
        // 周回開始頂点
        // TODO: ラスター脱出点は辺の中間が有り得るので調整が必要
        // - 中間から進入した辺は周回開始辺とせず、開始辺を次にずらす必要がある
        const auto startIt = findNode(polygon, firstCornerNode);
        if (gauge.headland.orbitalOrigin == Gauge::Headland::OrbitalOrigin::HP) {
            auto baseEdgeList = getEdgeList(hwParam.whp, hwParam.whp.cbegin());
            if (gauge.headland.process == Param::Work::Headland::Process::PRE && hwParam.startIndex < 0) {
                auto resultIt = findLeaveEdge(seg, baseEdgeList, vector<XY_Point>());
                if (resultIt != baseEdgeList.end()) {
                    std::rotate(baseEdgeList.begin(), resultIt, baseEdgeList.end());
                    // note: rotateしたのでresultItの指す要素は変更を受けている
                }
            }
            if (gauge.headland.process == Param::Work::Headland::Process::POST && hwParam.startIndex < 0) {
                // 内側作業が終了する辺から始まるように調整する場合の始点ノードを探索する
                double nearest = numeric_limits<double>::max();
                auto resultIt = baseEdgeList.end();
                for (auto itr = baseEdgeList.begin(); itr != baseEdgeList.end(); ++itr) {
                    // TODO:whpとhpのノードで比較しているため、取り違える可能性がある
                    double d = itr->point1().distance(startIt->HP);
                    if (d < nearest) {
                        nearest = d;
                        resultIt = itr;
                    }
                }
                if (resultIt != baseEdgeList.end()) {
                    // ANTICLOCKWISEの場合、baseEdgeListをreverseするので
                    // そのまま放置すれば、内側作業が終了する辺の次の辺から外周作業を開始してくれる
                    if (params.rotation == CLOCKWISE) {
                        // CLOCKWISEの場合、内側作業が終了する辺の次の辺から外周作業を開始するため
                        // resultItをひとつ進める
                        resultIt = nextCyclic(baseEdgeList, resultIt);
                    }
                    std::rotate(baseEdgeList.begin(), resultIt, baseEdgeList.end());
                    // note: rotateしたのでresultItの指す要素は変更を受けている
                }
            }
            params.baseEdgeList = baseEdgeList;
        } else {
            params.baseEdgeList = getEdgeListBP(polygon, startIt);
        }
        auto& baseEdgeList = params.baseEdgeList;
        params.edgeCount = (int)baseEdgeList.size();
        const auto edgeCount = params.edgeCount;
        if (gauge.headland.orbitalOrigin == Gauge::Headland::OrbitalOrigin::HP) {
            //  HPは内側にもできるが今の所外側固定
            edgeList = getVortexEdgesInsideOrigin(baseEdgeList, params);
        } else if (gauge.headland.orbitalOrigin == Gauge::Headland::OrbitalOrigin::BP) {
            // BPは内側にしかできない
            edgeList = getVortexEdgesOutsideOrigin(baseEdgeList, params);
        }
        
        if (edgeList.empty()) {
            // 周回パスが生成できない
            LOGE(LOG_TAG "::makeEdgeList", "empty edgeList");
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::GENERAL);
            err.setDescription("[EXCEPTION:ORBITAL] can't create orbital path.", "::makeEdgeList");
            throw err;
        }

        // 遷移パス用辺の付加
        if (gauge.headland.process == Param::Work::Headland::Process::PRE) {
            LOGD(LOG_TAG "::makeEdgeList", "make O-R transit");
            edgeList = makeEdgeListPreOrbital(seg, edgeList, (int)edgeCount, params);
        } else if (gauge.headland.process == Param::Work::Headland::Process::POST) {
            LOGD(LOG_TAG "::makeEdgeList", "make R-O transit");
            edgeList = makeEdgeListPostOrbital(seg, edgeList, (int)edgeCount, params);
        }

        return edgeList;
    }
    
    /**
     周回パス生成
     指定のエッジリストに対しコーナーのターンをつけたパスを返す。
     
     @param[in] edgeList           周回辺リスト
     @param[in] params             周回パス生成パラメータ
     */
    TurnPath PathGenerator::createOrbitalPath(const vector<PathSegment>& edgeList, OrbitalPathParam& params) {
        // 辺とパラメータから周回バス生成
        // - 辺を元にコーナーにターンを作る
        auto turnPath = getOrbitalPath(edgeList, params);
        
        turnPath.validate();
        return turnPath;
    }

    /**
     渦巻辺生成(内側基準)
     基準ポリゴン辺の外側に接する渦巻き辺を得る。
     - 基準辺リストは右回りポリゴンをなしているものとする。

     @see OrbitalPathParam
     @param[in] baseEdgeList         基準辺リスト(時計回り)
     @param[in] params  その他パラメーター cf. OrbitalPathParam
     */
    vector<PathSegment> PathGenerator::getVortexEdgesInsideOrigin(vector<LineSegment> baseEdgeList, const OrbitalPathParam& params) const {

        OrbitalPathParam tmpParams = params;
        
        if (params.pattern == CYCLONE) {
            // 基準辺の内側(外オリジン)で生成されるのでANTICYCLONEで生成して反転する
            tmpParams.pattern = Param::Work::Headland::Pattern::ANTICYCLONE;
            tmpParams.rotation = -tmpParams.rotation;
            tmpParams.clearance = -tmpParams.clearance;
        }

        if (tmpParams.rotation == ANTICLOCKWISE) {
            // 入力は常に時計回り
            // 実際に使用するパラメータで判定する
            reverse(baseEdgeList);
        }

        auto edgeList = getVortexEdges(baseEdgeList, tmpParams);

        if (params.pattern == CYCLONE) {
            // 基準辺の外側(内オリジン)で生成されるのでCYCLONEで生成して反転する
            reverse(edgeList);
        }

        return edgeList;
    }

    /** @ingroup PathGenerator
     周回パス生成(外向き)
     指定のセグメント間をターンで接続したパスを返す。
     - 特に周回パスでなくても生成できるが、周回パスのバック可否の制限を受ける。cf. headland.permitBackward

     @param[in] edgeList 接続するセグメントのリスト。
     @return 生成したパス
     */
    TurnPath PathGenerator::getOrbitalPath(const vector<PathSegment>& edgeList, OrbitalPathParam& params) {
        LOGV(LOG_TAG "::getOrbitalPath()", "EdgeList:\n%s", Svg::to_path(edgeList).c_str());

        TurnPath turnPath;

        if (edgeList.size() <= 2) {
            return turnPath;
        }
        
        PathSegment enterLeg = getHeadLeg(edgeList.front(), gauge.minSpsLegLength);
        enterLeg.pathAttr.rideType = Param::Path::Segment::RideType::NON_WORKING;
        enterLeg.turnType = Param::Path::Turn::Type::NAVIGATION;
        turnPath.pushTurnPath(enterLeg);
        turnPath.terminateAuto();

        // 各コーナーを作る
        for (auto it = edgeList.begin(); it != edgeList.end(); ++it) {
            auto it1 = next(it);
            auto seg0 = *it;
            auto seg1 = *it1;
            if (!seg0.pathAttr.isWorking()) {
                seg0.turnType = Param::Path::Turn::Type::NAVIGATION;
            } else {
                seg0.turnType = Param::Path::Turn::Type::UNDEFINED;
            }
            if (!seg1.pathAttr.isWorking()) {
                seg1.turnType = Param::Path::Turn::Type::NAVIGATION;
            } else {
                seg1.turnType = Param::Path::Turn::Type::UNDEFINED;
            }
            LOGD(LOG_TAG "::getOrbitalPath", "make corner turn at[%d] %s", (int)std::distance(edgeList.begin(), it), to_string(seg0.enterPoint()).c_str());

            if (it1 == edgeList.end()) {
                // 最終辺を追加
                seg0.enterPoint() = turnPath.leavePoint();
                LOGD(LOG_TAG "::getOrbitalPath", "last seg\n<path fill=\"none\" stroke=\"black\" d=\"%s\"/>",
                     Svg::to_path_d(seg0).c_str());
                if (!seg0.isNegrective()) {
                    turnPath.pushTurnPath(seg0);
                }
                break;
            }
            
            LOGD(LOG_TAG "::getOrbitalPath", "\n<path fill=\"none\" stroke=\"black\" d=\"\n%s%s\n\"/>",
                 Svg::to_path_d(seg0).c_str(), Svg::to_path_d(seg1).c_str());
            
            if (seg0.checkConnection(seg1) == Line::Connection::SMOOTH) {
                LOGD(LOG_TAG "::getOrbitalPath", "NO TURN because in-line.");
                // 一直線上にある場合、ターンは生成しない
                // - ウィスカーがあるので現在の出口から繋ぐ
                seg0.enterPoint() = turnPath.leavePoint();
                turnPath.pushTurnPath(seg0);
                if (seg0.pathAttr.isWorking()) {
                    // 作業パス出口なので標準パス脚長さで追加
                    seg1 = getFromHead(seg1, gauge.minFpsLegLength);
                }
                turnPath.pushTurnPath(seg1);
            } else {
                LOGD(LOG_TAG "::getOrbitalPath", "MAKE TURN");
                // コーナーでターンパス生成
                auto&& path = pathAssembler.getValidatedCornerTurnPath(seg0, seg1, gauge.headland.permitBackward, gauge.headland.rotation);
                if (path.status == TurnPath::FAILURE_TOO_CLOSE_CORNERS) {
                    LOGE(LOG_TAG "::getOrbitalPath", "[EXCEPTION] FAILURE_TOO_CLOSE_CORNERS");
                    ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE);
                    err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] CORNER DISTANCE TOO CLOSE.", "::getOrbitalPath");
                    throw err;
                }
                LOGV(LOG_TAG "::getOrbitalPath", "made path:\n%s", Svg::to_path(path).c_str());
                path.open();
                turnPath.open();
                if (path.empty()) {
                    LOGE(LOG_TAG "::getOrbitalPath", "MAKE CORNER TURN FAILED");
                    break;
                }
                // 脱出辺セグメント結合
                int result = SUCCESS;
                if (1 < turnPath.size()) {
                    if (path.turnType.std() == TurnType::ALPHA) {
                        LOGD(LOG_TAG "::getOrbitalPath", "ALPHA TURN");
                        result = pathAssembler.connectTurnToTurn(turnPath, seg0, path);
                        if (result == SUCCESS) {
                            // 接続成功
                            LOGD(LOG_TAG "::getOrbitalPath", "ALPHA TURN: connectTurnToTurn() succeeded");
                        } else if (result == ResultCode::ConnectPath::FAILURE_CONNECT) {
                            LOGE(LOG_TAG "::getOrbitalPath", "[EXCEPTION] ALPHA : connect error");
                            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE);
                            err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] CORNER DISTANCE TOO CLOSE.", "::getOrbitalPath");
                            throw err;
                        } else {
                            auto enterSeg = path.front();
                            result = pathAssembler.connectTurnToSegment(turnPath, enterSeg, gauge.headland.permitBackward);
                            if (result == SUCCESS) {
                                LOGD(LOG_TAG "::getOrbitalPath", "ALPHA TURN: connectTurnToSegment() succeeded");
                                turnPath.back().pathAttr = seg0.pathAttr;
                                turnPath.back().turnType = seg0.turnType;
                            }
                        }
                    } else if (path.turnType.std() == TurnType::PLAIN) {
                        LOGD(LOG_TAG "::getOrbitalPath", "PLAIN TURN");
                        result = pathAssembler.connectTurnToTurn(turnPath, seg0, path);
                        if (result == SUCCESS) {
                            // 接続成功
                            LOGD(LOG_TAG "::getOrbitalPath", "PLAIN TURN: connectTurnToTurn() succeeded");
                        } else if (result == ResultCode::ConnectPath::SUCCESS_BACKWARD) {
                            LOGD(LOG_TAG "::getOrbitalPath", "PLAIN TURN: connectTurnToTurn() used reverse seg");
                            if (checkBoundaryIntersection(turnPath.getLastSegment(), BoundaryType::Kind::Mask::SBP) != Intersection::NO) {
                                LOGE(LOG_TAG "::getOrbitalPath", "[EXCEPTION] UNABLE TO CONNECT WITHIN LEGS");
                                ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE);
                                err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] CORNER DISTANCE TOO CLOSE.", "::getOrbitalPath");
                                throw err;
                            }
                        } else if (!(result == ResultCode::ConnectPath::FAILURE_OVERLAP ||
                                     result == ResultCode::ConnectPath::FAILURE_BACKWARD||
                                     result == ResultCode::ConnectPath::FAILURE_CONNECT)) {
                            LOGD(LOG_TAG "::getOrbitalPath", "PLAIN TURN: try connectTurnToSegment()");
                            result = pathAssembler.connectTurnToTurn(turnPath, path, gauge.headland.permitBackward);
                            if (result == SUCCESS) {
                                LOGD(LOG_TAG "::getOrbitalPath", "PLAIN TURN: connectTurnToSegment() succeeded");
                                // 接続成功
                            } else {
                                // ターンの接続失敗はコーナー間が狭い上にバックできないためである
                                result = ResultCode::ConnectPath::FAILURE_OVERLAP;
                            }
                        } else {
                            LOGE(LOG_TAG "::getOrbitalPath", "[EXCEPTION] CORNER TURN CONENCT GENERAL");
                            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE);
                            err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] CORNER DISTANCE TOO CLOSE.", "::getOrbitalPath");
                            throw err;
                        }
                    } else {
                        LOGD(LOG_TAG "::getOrbitalPath", "OTHER TURN");
                        auto enterSeg = path.front();
                        result = pathAssembler.connectTurnToTurn(turnPath, seg0, path);
                        if (result != SUCCESS) {
                            LOGD(LOG_TAG "::getOrbitalPath", "OTHER TURN: connectTurnToTurn() succeeded");
                        } else {
                            result = pathAssembler.connectTurnToSegment(turnPath, enterSeg, true);
                            if (result == SUCCESS) {
                                LOGD(LOG_TAG "::getOrbitalPath", "OTHER TURN: connectTurnToSegment() succeeded");
                                // 接続成功
                                turnPath.pushTurnPath(enterSeg);
                                turnPath.back().pathAttr = seg0.pathAttr;
                                turnPath.back().turnType = seg0.turnType;
                            } else {
                                // ターンの接続失敗はコーナー間が狭い上にバックできないためである
                                result = ResultCode::ConnectPath::FAILURE_OVERLAP;
                            }
                        }
                    }
                } else {
                    LOGD(LOG_TAG "::getOrbitalPath", "FIRST TURN");
                    // 前のターンパス脱出セグメント
                    auto fromSeg = turnPath.back();
                    // 次のターンパス進入セグメント
                    auto toSeg = path.front();
                    const auto segpos = inlinePosition(fromSeg, toSeg);
                    if (segpos == InlinePos::LLMM) {
                    auto leaveSeg = seg0;
                    leaveSeg.enterPoint() = turnPath.leavePoint();
                    leaveSeg.leavePoint() = path.enterPoint();
                    turnPath.pushTurnPath(leaveSeg);
                    } else if (segpos == InlinePos::LMLM) {
                        fromSeg.leavePoint() = toSeg.enterPoint();
                    } else {
                        LOGE(LOG_TAG "::getOrbitalPath", "[EXCEPTION] CORNER TURN CONENCT GENERAL (first)");
                        ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE);
                        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] CORNER DISTANCE TOO CLOSE.", "::createPostOrbitalPath");
                        throw err;
                    }
                }

                // エラー判定
                if ((result & 0xff) != ResultCode::ConnectPath::SUCCESS) {
                    if (result == ResultCode::ConnectPath::FAILURE_OVERLAP ||
                        result == ResultCode::ConnectPath::FAILURE_BACKWARD) {
                        // コーナー間が狭い場合回復不能エラー
                        LOGV(LOG_TAG "::getOrbitalPath", "[EXCEPTION] CONNECT CORNER TURNS:\n%s", Svg::to_path(path).c_str());
                        ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE);
                        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] Orbital path corner too close.", "::createPostOrbitalPath");
                        throw err;
                    } else {
                        // 通常エラー
                        LOGE(LOG_TAG "::getOrbitalPath", "[EXCEPTION] CORNER TURN GENERATION");
                        ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::GENERAL);
                        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] Orbital path corner turn genration.", "::createPostOrbitalPath");
                        throw err;
                    }
                }
                // ターンパス追加
                turnPath.pushTurnPath(path);
                // チェック
                try {
                    PathValidator::validateSegmentPropaties(turnPath);
                    auto beginIt = std::prev(turnPath.end(), std::min(turnPath.size(), path.size()));
                    auto endIt = turnPath.end();
                    PathValidator::validatePointVector(beginIt, endIt);
                } catch (...) {
                    LOGV(LOG_TAG "::getOrbitalPath", "PATH:\n%s", Svg::to_path(path).c_str());
                    throw;
                }
                if (checkBoundaryIntersection(path, BoundaryType::Kind::Mask::SBP) != Intersection::NO) {
                    LOGE(LOG_TAG "::getOrbitalPath", "[EXCEPTION] CORNER TURN GENERATION: path:\n%s", Svg::to_path(path).c_str());
                    ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Orbital::GENERAL);
                    err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] CORNER TURN GENERATION.", "::createPostOrbitalPath");
                    throw err;
                }
            }

//#ifdef DEBUG
            try {
                PathValidator::validateSegmentPropaties(turnPath);
                PathValidator::validatePointVectorInside(turnPath);
            } catch (...) {
//                LOGE(LOG_TAG, "PATH:\n%s", Svg::to_path_d(path).c_str());
                throw;
            }
//#endif // DEBUG
        }
        
        turnPath.completeSegment();
        turnPath.terminate(turnPath.leavePoint());
        return turnPath;
    }

    /**
     周回作業パス始点オーバーラップ調整
     @param[in] orbialEdgeList  周回辺
     @param[in] params                   パラメータ
     */
    void PathGenerator::adjustWorkingStartPoint(vector<PathSegment>& orbialEdgeList, const OrbitalPathParam& params) const {
        if (orbialEdgeList.size() < params.edgeCount) {
            LOGD(LOG_TAG "::adjustWorkingStartPoint", "[ERROR] orbital was lass than 1 lap.");
            return;
        }
        auto itl = orbialEdgeList.begin();
        auto lSeg = *itl;
        auto ite = std::next(itl, params.edgeCount - 1);
        auto eSeg = *ite;
        if (!connectAny(eSeg, lSeg)) {
            LOGD(LOG_TAG "::adjustWorkingStartPoint", "[ERROR] next lap edge is invalid.");
            return;
        }
        // 先頭をウィスカー分伸ばす
        const auto eLeg = getFromTail(eSeg, 1.0);
        const auto lLeg = getFromHead(lSeg, 1.0);
        const auto lengths = pathAssembler.getWtCrossLengths(eLeg, lLeg);
        orbialEdgeList.front().extendHead(lengths.second);
    }

    /**
     周回パスの途中に存在する作業開始点のウィスカー量調整
     @param[in] noworkEdges   遷移周回辺リスト
     @param[in] workEdges       作業周回辺リスト
     @param[in] params              パラメータ
     */
    void PathGenerator::adjustWorkingStartWhisker(LineSegment& seg, vector<PathSegment>& noworkEdges, vector<PathSegment>& workEdges, const OrbitalPathParam& params) const {
        if (workEdges.size() < params.edgeCount) {
            LOGD(LOG_TAG "::adjustWorkingStartWhisker", "[ERROR] orbital was lass than 1 lap.");
            return;
        }

        auto itl = workEdges.begin();
        auto lSeg = *itl;
        auto ite = std::next(itl, params.edgeCount - 1);
        auto eSeg0 = *ite;
        auto eSeg1 = noworkEdges.empty() ? seg : noworkEdges.back();
        // 遷移パスとのウィスカーは本来の位置とし異なるので不足分を求めておく
        try {
            auto ePx0 = getCrossPoint(eSeg0, lSeg);
            auto ePx1 = getCrossPoint(eSeg1, lSeg);
            double addLen = ePx0.distance(ePx1);
            Vector2D pVec{ePx1, ePx0};
            double dp = lSeg.getEnterVector().getDotProduct(pVec);
            addLen = std::copysign(addLen, -dp);
            LOGD(LOG_TAG "::adjustWorkingStartWhisker", "\n eSeg0: %s\n lSeg1: %s\n  lSeg: %s\n  ePx0: %s\n  ePx1: %s",
                Svg::to_path_d(eSeg0).c_str(),
                Svg::to_path_d(eSeg1).c_str(),
                Svg::to_path_d(lSeg).c_str(),
                Svg::to_point(ePx0).c_str(),
                Svg::to_point(ePx1).c_str());

            workEdges.front().whisker.headAdjustLength = addLen;
            LOGD(LOG_TAG "::adjustWorkingStartWhisker", "AdjustLength: %0.7g", addLen);
        } catch (...) {
            LOGE(LOG_TAG "::adjustWorkingStartWhisker", "[ERROR] no cress edges");
        }
    }

    /**
     周回パスの途中に存在する作業終了点のウィスカー量調整
     周回パス中、作業セグメントからコーナーで直接非作業パスへの接続では本来の周回パスのコーナーで接続しないためウィスカーの長さが期待値とならない。そのウィスカへー長さの補正値を求めてセグメントに設定する。
     @param[in] workEdges       作業周回辺リスト
     @param[in] noworkEdges   遷移周回辺リスト
     @param[in] params  周回パス生成パラメータ
     */
    void PathGenerator::adjustWorkingEndWhisker(LineSegment& seg, vector<PathSegment>& workEdges, vector<PathSegment>& noworkEdges, const OrbitalPathParam& params) const {
        if (workEdges.size() < params.edgeCount) {
            LOGD(LOG_TAG "::adjustWorkingEndWhisker", "[ERROR] orbital was lass than 1 lap.");
            return;
        }

        auto eSeg = workEdges.back();
        auto itl = std::prev(workEdges.end(), params.edgeCount);
        auto lSeg0 = *itl;
        auto lSeg1 = noworkEdges.empty() ? seg : noworkEdges.front();
        // 遷移パスとのウィスカーは本来の位置と異なるので不足分を求めておく
        try {
            auto lPx0 = getCrossPoint(eSeg, lSeg0);
            auto lPx1 = getCrossPoint(eSeg, lSeg1);
            double addLen = lPx0.distance(lPx1);
            Vector2D pVec{lPx1, lPx0};
            double dp = eSeg.getLeaveVector().getDotProduct(pVec);
            addLen = std::copysign(addLen, dp);
            LOGD(LOG_TAG "::adjustWorkingEndWhisker", "\n eSeg: %s\n lSeg1: %s\n  lSeg: %s\n  lPx0: %s\n  lPx1: %s",
                 Svg::to_path_d(eSeg).c_str(),
                 Svg::to_path_d(lSeg0).c_str(),
                 Svg::to_path_d(lSeg1).c_str(),
                 Svg::to_point(lPx0).c_str(),
                 Svg::to_point(lPx1).c_str());

            workEdges.back().whisker.tailAdjustLength = addLen;
            LOGD(LOG_TAG "::adjustWorkingEndWhisker", "AdjustLength: %0.7g", addLen);
        } catch (...) {
            LOGE(LOG_TAG "::adjustWorkingEndWhisker", "[ERROR] no cress edges");
        }
    }

}} // namespace yanmar::PathPlan

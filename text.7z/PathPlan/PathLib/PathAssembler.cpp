// Yanmar Confidential 20200918
/**
 @file PathAssembler.cpp
 
 パス組み立てクラス実装ファイル
 
 セグメントを組み合わせてターンパスを生成するクラス実装
 */
/// @internal @defgroup PathAssembler

//#define TXT_FILE_ENABLE
//#define LOGLEVEL 5

#include "PolyLib/Common.h"
#include "PathAssembler.hpp"

#include <cstdlib>
#include <string>
#include <utility>
#include <algorithm>
    
#include "PathPlanConstant.hpp"
#include "Segment.hpp"
#include "PathLib.h"
#include "PolyLib/Context.hpp"
#include "PolyLib/PolygonUtil.hpp"
#include "Geometry/Geometry.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

using namespace Param::Path;
using namespace SegmentType;
using namespace RotateDirection;
using namespace ResultCode;
using namespace PathGeneratorData;

//
// PathAssembler definition
//
#pragma mark - PathAssemblerIf
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathAssemblerIf"

namespace {
    /**
     線と線に接する円
     交差する直線間に接するターンサークルを返す。
     - 引数の2線分は交差している必要はなく、直線とみなして算出する。
     - 直線が交差しない場合エラーを返す。
     - 引数のターン方向が実際のターン方向と同じであれば前進で結ぶターンサークルを返す。逆方向で与えた場合は後退で結ぶターンサークルを返す。
     @param[in] eTS                 進入接線
     @param[in] lTS                 脱出接線
     @param[in] crossOrient ターン方向
     */
    Circle getInterTurnCircle(const LineSegment& eTS, const LineSegment& lTS, double radius, int crossOrient) {
        Circle circle{};
        auto eSeg = getCollateralSegment(eTS, radius * crossOrient);
        auto lSeg = getCollateralSegment(lTS, radius * crossOrient);

        try {
            const XY_Point pc = getCrossPoint(eSeg, lSeg);
            circle = Circle{pc, radius, crossOrient};
        } catch (...) {
            
        }

        return circle;
    }
    /**
         線と線に接する円(前進方向)
         2線分間を前進して接続するターンサークルを返す。
         - 2線分が交差しない場合エラーを返す
         @param[in] eTS                 進入接線
         @param[in] lTS                 脱出接線
         @param[in] crossOrient ターン方向
     */
    Circle getInterTurnCircleForward(const LineSegment& eTS, const LineSegment& lTS, double radius, int crossOrient) {
        return getInterTurnCircle(eTS, lTS, radius, crossOrient);
    }
    /**
     線と線に接する円(後退方向)
     2線分間をバックで接続するターンサークルを返す。
     - 2線分が交差しない場合エラーを返す
     @param[in] eTS                 進入接線
     @param[in] lTS                 脱出接線
     @param[in] crossOrient ターン方向
     */
    Circle getInterTurnCircleBackward(const LineSegment& eTS, const LineSegment& lTS, double radius, int crossOrient) {
        return getInterTurnCircle(eTS, lTS, radius, -crossOrient);
    }

    ArcSegment getInterArcSegment(const LineSegment& eTS, const LineSegment& lTS, double radius, int crossOrient) {
        Circle C0 = getInterTurnCircleBackward(eTS, lTS, radius, crossOrient);
        const Vector2D eoVec = lTS.getLeaveVector().getOrthogonal(crossOrient).getUnitVector();
        const Vector2D loVec = eTS.getLeaveVector().getOrthogonal(crossOrient).getUnitVector();
        const XY_Point enterPoint = getShifted(C0.center, eoVec * Vector2D{C0.radius});
        const XY_Point leavePoint = getShifted(C0.center, loVec * Vector2D{C0.radius});
        return ArcSegment{enterPoint, leavePoint, C0};
    }
} // anonimous namaspace

/**
 コンストラクタ
 */
PathAssembler::PathAssembler(ContextIF& aContext, const Gauge& aGauge, const PathValidator& aValidator) :
    PathAssemblerIf(aContext, aGauge),
    validator(aValidator)
{}


#pragma mark - Assemble TurnPath

    /**
     接線とカーブ取得(前進)
     
     指定ターンサークル間の接線を求め、接線とその行先のカーブのターンパスを返す。
        - セグメント構成
            -# LINE currCirc - nextCirc間接線
            -# ARC  行先カーブ(OPEN)

     @note TODO: ほぼ重なるターンサークル間で後退接線は予備直進の無駄が大きい。
                 ターンサークル間距離が近いということは、ターンサークル省略可能性が高いはずである。
                 ただし、現在は障害物周囲のターンサークル省略がない。

     @param[in] eTS         始点サークルへの進入接線
     @param[in] currCirc    接線始点のターンサークル
     @param[in] nextCirc    接線行先のターンサークル

     @return ターンパス
     */
    TurnPath PathAssemblerIf::getForwardTangentAndCurve(const LineSegment& eTS, const Circle& currCirc, const Circle& nextCirc) const {
        LOGV(LOG_TAG "::getForwardTangentAndCurve(T,C,C)", "");
        TurnPath turnPath;
        // 前進の接線を引く
        PathSegment PS = getTangent(eTS, currCirc, nextCirc, TangentDir::FORWARD);
        
        if (PS.isValid()) {
            // Update turn path
            turnPath.emplace_back(PS.point1());
            turnPath.emplace_back(PS.point2(), nextCirc);
            turnPath.validate();
            PGASSERT(turnPath.size() == 2, ErrorCode::PathGeneration::FATAL);
        } else {
            turnPath.invalidate();
        }
        
        return turnPath;
    }
    
    /**
     後退接線とカーブ取得
     
     指定ターンサークル間の後退接線を求めターンパスを返す。
     - ターンサークルの重なりを検査せず実行する
     - 逆方向の回転でターンサークルが重なっていたら不正な結果を出力する
     - ターンサークル間の接線が短すぎる場合失敗する(1mm未満)
     - セグメント構成
        -# LINE 後退前予備直進
        -# LINE 後退接線
        -# ARC  行先カーブ(open)
     
     @param[in] eTS         始点サークルへの進入接線
     @param[in] currCirc    接線始点のターンサークル
     @param[in] nextCirc    接線行先のターンサークル
     @param[in] tailLen     後退前の予備直進長さ
     
     @return ターンパス
     */
    TurnPath PathAssemblerIf::getReverseTangentAndCurve(const LineSegment& eTS, const Circle& currCirc, const Circle& nextCirc, double tailLen) const {
        LOGV(LOG_TAG "::getReverseTangentAndCurve(P,C,C)", "");

        if (!gauge.permitBackward) {
            // バック移動禁止
            ErrorPathGenerator err(ErrorCode::PathGeneration::INCLUDE_BACKWARD);
            err.setDescription("[EXCEPTION:PATH_GENERATION] can't generate reverse segment without backward permission.", "::getReverseTangentAndCurve");
//            throw err;
        }

        TurnPath turnPath;
        if (currCirc.orient != nextCirc.orient) {
            // 回転が逆
            LOGV(LOG_TAG "::getTangentAndCurve", "failed by against orient");
            turnPath.invalidate();
        }

        if (currCirc.checkIntersection(nextCirc) == Intersection::NO) {
            // 重なっていない
            LOGV(LOG_TAG "::getTangentAndCurve", "failed by turn circles are not intersect.");
            turnPath.invalidate();
        }

        if (getTangentDirection(eTS.point2(), currCirc, nextCirc) != TangentDir::REVERSE) {
            // 前進の接線
            LOGV(LOG_TAG "::getTangentAndCurve", "failed by first tangent is forward.");
            turnPath.invalidate();
        }
        
        // バックの接線を引く
        PathSegment PS = getTangent(eTS, currCirc, nextCirc, TangentDir::REVERSE);
        if (!PS.isValid()) {
            LOGD(LOG_TAG "::getTangentAndCurve", "no valid tangent.");
            turnPath.invalidate();
            return turnPath;
        }
        
        // TODO: 小さな後退接線には予備直進は不要ではないか。接線自体省略するか微小な前進に置き換えることはできないか。
        const LineSegment TS = PS;
        if (TS.length() < TOL_MICRO) {
            // 短すぎるものは失敗させる
            // - もし0ならばそもそも延長できず、準備直進が生成できない
            LOGD(LOG_TAG "::getTangentAndCurve", "too short tangent.");
            turnPath.invalidate();
            return turnPath;
        }

        ReverseSegment RvsSG = TS;
        RvsSG.extendHead(tailLen);
        // Update turn path
        turnPath.emplace_back(TS.point1());
        turnPath.emplace_back(RvsSG.point1(), RvsSG.direction);
        turnPath.emplace_back(RvsSG.point2(), nextCirc);
        PGASSERT(turnPath.size() == 3, ErrorCode::PathGeneration::FATAL);
        
        turnPath.validate();
        return turnPath;
    }

    /**
     接線とカーブ取得
     
     指定ターンサークル間の接線を求め、フィッシュテールターンパスを返す。
     - 主に補助ターンサークル使用時のフィッシュテール生成用。
     - 進入接線はcurrCircに対して正しく接線であること。(assertあり)
     - セグメント構成
         -# ARC  出発カーブ
         -# LINE 準備直進
         -# LINE 後退接線
         -# ARC  補助カーブ
         -# LINE 脱出接線
         -# ARC  行先カーブ(OPEN)


     @param[in] eTS      出発ターンサークルへの進入接線
     @param[in] currCirc 出発ターンサークル
     @param[in] auxCirc  補助ターンサークル
     @param[in] nextCirc 行先ターンサークル
     
     @return ターンパス
     */
    TurnPath PathAssemblerIf::getTangentAndCurve(const LineSegment& eTS, const Circle& currCirc, const Circle& auxCirc, const Circle& nextCirc) const {
        LOGV(LOG_TAG "::getTangentAndCurve(T,C,C,C)", "");
        TurnPath turnPath;

        XY_Point enterPoint = eTS.point2();
        PGASSERT(currCirc.isContact(enterPoint), ErrorCode::PathGeneration::FATAL); // 進入接線が接続していない
        
        // 先頭のカーブ
        turnPath.emplace_back(enterPoint, currCirc);

        // 前カーブ出口から接線+補助カーブ
        turnPath.invalidate();
        TurnPath&& enterPath = getReverseTangentAndCurve(eTS, currCirc, auxCirc, gauge.turn.fishtail.preBackLength);
        if (enterPath.isValid()) {
            turnPath.pushTurnPath(enterPath);
            // 補助カーブ出口から接線+次のカーブ
            TurnPath&& leavePath = getForwardTangentAndCurve(turnPath.getLastTangent(), auxCirc, nextCirc);
            if (leavePath.isValid()) {
                turnPath.pushTurnPath(leavePath);
                turnPath.validate();
                PGASSERT(turnPath.size() == 6, ErrorCode::PathGeneration::FATAL);
            } else {
                turnPath.invalidate();
            }
        }

        return turnPath;
    }
    
    /**
     フィッシュテールターンパス生成(ディスパッチ)
     
     ターンサークル、補助ターンサークル設定済みの作業パスセグメントを受け取り、その間にフィッシュテールターンパスを生成して返す。
     - バック移動禁止状態で呼び出された場合、例外を投げる
     - 作業パスの補助ターンサークルの有無によりディスパッチする。セグメント数はそれぞれ異なる。
     
     @see   getFishTailPathBoth(const PathFPS& fps, const PathSPS& sps, double tailLen),
            getFishTailPathFPS(const PathFPS& fps, const PathSPS& sps, double tailLen),
            getFishTailPathSPS(const PathFPS& fps, const PathSPS& sps, double tailLen),
            getFishTailPath(const PathFPS& fps, const PathSPS& sps, double tailLen)
     
     @param[in] fps     脱出作業パス(FPS)
     @param[in] sps     行先作業パス(SPS)
     @param[in] tailLen 後退前予備直進長さ @see Gauge::preReverseLength
     
     @return 生成したフィッシュテールターンパス
     */
    TurnPath PathAssemblerIf::getTurnPath(const PathFPS& fps, const PathSPS& sps, double tailLen) const {
        LOGV(LOG_TAG "::getTurnPath", "(FPS, SPS, %0.7g)", tailLen);
        
        if (!gauge.permitBackward) {
            // バック移動禁止
            ErrorPathGenerator err(fps, sps, ErrorCode::PathGeneration::INCLUDE_BACKWARD);
            err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] path includes reverse segment without backward permission.", "::getFithtailTurnPath(3)");
            throw err;
        }
        
        TurnPath turnPath;
        
        // FPSカーブ出口から中間カーブ
        if (fps.isAuxTurnCirclePresent()) {
            // FPS側に補助ターンサークル有り
            if (sps.isAuxTurnCirclePresent()) {
                // FPS,SPS両方に補助ターンサークル有り
                turnPath = getFishTailPathBoth(fps, sps, tailLen);
            } else {
                // FPS側のみに補助ターンサークル有り
                turnPath = getFishTailPathFPS(fps, sps, tailLen);
            }
        } else {
            if (sps.isAuxTurnCirclePresent()) {
                // SPS側のみに補助ターンサークル有り
                turnPath = getFishTailPathSPS(fps, sps, tailLen);
            } else {
                // 補助ターンサークル無し
                turnPath = getFishTailPath(fps, sps, tailLen);
            }
        }
        
        return turnPath;
    }

    /**
     フィッシュテールターンパス生成(両側)
     
     ターンサークル、補助ターンサークル設定済みの作業パスセグメントを受け取り、その間にフィッシュテールターンパスを生成して返す。
     - 補助ターンの存在はテストしない。
     - 作業パス間隔と位置がフィッシュテールターン生成不可能な場合不正なターンパスを返す。
     - セグメント構成
         -# LINE FPS脚
         -# ARC  FPSカーブ
         -# LINE 中間接線
         -# ARC  FPS補助カーブ
         -# LINE 準備直進
         -# LINE 後退接線
         -# ARC  FPS補助カーブ
         -# LINE 準備直進
         -# LINE 後退接線
         -# ARC  SPSカーブ
         -# LINE SPS脚
         -# LINE SPS進入点(OPEN)
     
     @param[in] fps     脱出作業パス(FPS)
     @param[in] sps     行先作業パス(SPS)
     @param[in] tailLen 後退前予備直進長さ @see Gauge::preReverseLength
     
     @return 生成したフィッシュテールターンパス
     */
    TurnPath PathAssemblerIf::getFishTailPathBoth(const PathFPS& fps, const PathSPS& sps, double tailLen) const {
        LOGV(LOG_TAG "::getFishTailPathBoth(FPS, SPS, rLen)", "Both work pathes have aux circle");
        // FPS,SPSともに補助ターンサークル有り

        TurnPath turnPath;
        // 前作業パス出口
        turnPath.emplace_back(fps.point1());
        // FPSカーブ
        turnPath.emplace_back(fps.getPoint(), fps.Circ);
        
        Circle viaCircle = fps.getAuxTurnCircle();
        const auto leg = fps.getHeadLeg();
        TurnPath&& tangent1 = getReverseTangentAndCurve(leg, fps.Circ, viaCircle, tailLen);
        if (tangent1.isValid()) {
            auto iTS = tangent1.getSegment<LineSegment>(0);
            Circle circle{fps.Circ};
            if (tryUnite(leg, iTS)) {
                tangent1[0].point1() = iTS.point1();
            }
            turnPath.pushTurnPath(tangent1);
            // SPS側にも補助ターンサークル有り
            Circle viaCircle2 = sps.getAuxTurnCircle();
            // FPS中間カーブ出口からSPS中間カーブ
            auto rTS = tangent1.getSegment<LineSegment>(1);
            TurnPath&& tangent2 = getForwardTangentAndCurve(rTS, viaCircle, viaCircle2);
            if (tangent2.isValid()) {
                tangent2.back().collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                turnPath.pushTurnPath(tangent2);
                // SPS中間カーブ出口からSPSカーブ
                TurnPath&& tangent3 = getReverseTangentAndCurve(tangent2.getLastTangent(), viaCircle2, sps.Circ, tailLen);
                if (tangent3.isValid()) {
                    const auto leg = sps.getHeadLeg();
                    auto iTS = tangent3.getSegment<LineSegment>(1);
                    Circle circle{sps.Circ};
                    if (tryUnite(iTS, leg)) {
                        tangent3[1].point2() = iTS.point1();
                    }
                    turnPath.pushTurnPath(tangent3);
                    turnPath.pushTurnPath(sps.getPoint());
                    turnPath.terminate(sps.enterPoint());
                    turnPath.validate();
                    PGASSERT(turnPath.size() == 11, ErrorCode::PathGeneration::FATAL);
                    // set collision targets
                    // フィッシュテール部はHP交差を検査しない
                    turnPath[0].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
                    turnPath[1].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                    turnPath[2].collisionBoundary = BoundaryType::Kind::FOR_IGNORE;
                    turnPath[3].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                    turnPath[4].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                    turnPath[5].collisionBoundary = BoundaryType::Kind::FOR_INTER_CORNER;
                    turnPath[7].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                    turnPath[6].collisionBoundary = BoundaryType::Kind::FOR_IGNORE;
                    turnPath[8].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                    turnPath[9].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                    turnPath[10].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
                    
                    // SPSパス入口
                    turnPath.completeSegment();
                    PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
                    PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
                }
            }
        }
        
        return turnPath;
    }
    
    /**
     フィッシュテールターンパス生成(FPS側)
     
     ターンサークル、補助ターンサークル設定済みの作業パスセグメントを受け取り、その間にフィッシュテールターンパスを生成して返す。
     - 補助ターンの存在はテストしない。
     - 作業パス間隔が旋回直径より広いことを期待している。
     - セグメント構成
         -# LINE FPS脚
         -# ARC  FPSカーブ
         -# LINE 準備直進
         -# LINE 後退接線
         -# ARC  補助カーブ
         -# LINE 中間接線
         -# ARC  SPSカーブ
         -# LINE SPS脚
         -# LINE SPS進入点(OPEN)

     @param[in] fps     脱出作業パス(FPS)
     @param[in] sps     行先作業パス(SPS)
     @param[in] tailLen 後退前予備直進長さ @see Gauge::preReverseLength
     
     @return 生成したフィッシュテールターンパス
     */
    TurnPath PathAssemblerIf::getFishTailPathFPS(const PathFPS& fps, const PathSPS& sps, double tailLen) const {
        LOGV(LOG_TAG "::getFishTailPathFPS((FPS, SPS, rLen)", "FPS has aux circle");
        // FPS側のみに補助ターンサークル有り

        TurnPath turnPath;
        // 前作業パス出口
        turnPath.emplace_back(fps.point1());
        // FPSカーブ
        turnPath.emplace_back(fps.getPoint(), fps.Circ);
        
        Circle viaCircle = fps.getAuxTurnCircle();
        TurnPath&& tangent1 = getReverseTangentAndCurve(fps.getHeadLeg(), fps.Circ, viaCircle, tailLen);
        if (tangent1.isValid()) {
            turnPath.pushTurnPath(tangent1);
            // 中間カーブ出口からSPSカーブ
            TurnPath&& tangent2 = getForwardTangentAndCurve(tangent1.getLastTangent(), viaCircle, sps.Circ);
            if (tangent2.isValid()) {
                auto leg = sps.getHeadLeg();
                auto iTS = tangent2.getSegment<LineSegment>(0);
                // ターン幅
                if (tryUnite(iTS, const_cast<const LineSegment&>(leg))) {
                    LOGD(LOG_TAG "::getFishTailPathFPS(FPS, SPS, rLen)", "[WARN] negrective SPS circle");
                } else if (flipTurnCircle(tangent2[1].Circ, iTS, leg)) {
                    LOGD(LOG_TAG "::getFishTailPathFPS(FPS, SPS, rLen)", "[WARN] need flip SPS circle");
                }
                tangent2[1].point1() = iTS.point2();
                turnPath.pushTurnPath(tangent2);
                turnPath.emplace_back(leg.point1());
                turnPath.terminate(leg.point2());
                turnPath.validate();
                PGASSERT(turnPath.size() == 9, ErrorCode::PathGeneration::FATAL);
                // set collision targets
                turnPath[0].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
                turnPath[1].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                turnPath[2].collisionBoundary = BoundaryType::Kind::FOR_IGNORE;
                turnPath[3].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                turnPath[4].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                turnPath[5].collisionBoundary = BoundaryType::Kind::FOR_INTER_CORNER;
                turnPath[6].collisionBoundary = BoundaryType::Kind::FOR_DEFAULT;
                turnPath[7].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
                
                // SPSパス入口
                turnPath.completeSegment();
                PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
                PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
            }
        }
        
        return turnPath;
    }

    /**
     フィッシュテールターンパス生成(SPS)
     
     ターンサークル、補助ターンサークル設定済みの作業パスセグメントを受け取り、その間にフィッシュテールターンパスを生成して返す。
     - 補助ターンの存在はテストしない。
     - 作業パス間隔が旋回直径より広いことを期待している。
     - セグメント構成
         -# LINE FPS脚
         -# ARC  FPSカーブ
         -# LINE 中間接線
         -# ARC  補助カーブ
         -# LINE 準備直進
         -# LINE 後退接線
         -# ARC  SPSカーブ
         -# LINE SPS脚
         -# LINE SPS進入点(OPEN)
     
     @param[in] fps     脱出作業パス(FPS)
     @param[in] sps     行先作業パス(SPS)
     @param[in] tailLen 後退前予備直進長さ @see Gauge::preReverseLength
     
     @return 生成したフィッシュテールターンパス
     */
    TurnPath PathAssemblerIf::getFishTailPathSPS(const PathFPS& fps, const PathSPS& sps, double tailLen) const {
        LOGV(LOG_TAG "::getFishTailPathSPS(FPS, SPS, rLen)", "SPS has aux circle");

        TurnPath turnPath;
        // 前作業パス出口
        turnPath.emplace_back(fps.point1());
        // FPSカーブ
        turnPath.emplace_back(fps.getPoint(), fps.Circ);

        // SPS側のみに補助ターンサークル有り
        Circle viaCircle = sps.getAuxTurnCircle();
        if (isIsometric(fps.Circ.center, viaCircle.center, TOL_ONE_CM)) {
            viaCircle.center = fps.Circ.center;
        }
        // FPSカーブ出口から中間カーブ
        TurnPath tmpPath = getForwardTangentAndCurve(fps.getHeadLeg(), fps.Circ, viaCircle);
        if (tmpPath.isValid()) {
            const auto leg = fps.getHeadLeg();
            auto iTS = tmpPath.getSegment<LineSegment>(0);
            Circle circle{fps.Circ};
            if (tryUnite(leg, iTS)) {
                LOGV(LOG_TAG "::getFishTailPathSPS(FPS, SPS, rLen)", "negrentive SPS aux circle");
                tmpPath[0].point1() = iTS.point1();
            }
            turnPath.pushTurnPath(tmpPath);
            // 中間カーブ出口からSPSカーブ
            TurnPath&& tangent2 = getReverseTangentAndCurve(iTS, viaCircle, sps.Circ, tailLen);
            if (tangent2.isValid()) {
                turnPath.pushTurnPath(tangent2);
                turnPath.pushTurnPath(sps.getPoint());
                turnPath.terminate(sps.enterPoint());
                turnPath.validate();
                PGASSERT(turnPath.size() == 9, ErrorCode::PathGeneration::FATAL);
                // set collision targets
                turnPath[0].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
                turnPath[1].collisionBoundary = BoundaryType::Kind::FOR_DEFAULT;
                turnPath[2].collisionBoundary = BoundaryType::Kind::FOR_INTER_CORNER;
                turnPath[3].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                turnPath[4].collisionBoundary = BoundaryType::Kind::FOR_IGNORE;
                turnPath[5].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                turnPath[6].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
                turnPath[7].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
            
                // SPSパス入口
                turnPath.completeSegment();
                PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
                PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
            }
        }
        
        return turnPath;
    }

    /**
     フィッシュテールターンパス生成(直接)
     
     ターンサークル、補助ターンサークル設定済みの作業パスセグメントを受け取り、その間を直接交代接線で繋ぐフィッシュテールターンパスを生成して返す。
     - 補助ターンサークルは無視する。
     - 作業パス間隔が広い場合不正なターンパスを返す可能性がある。
     - セグメント構成
         -# LINE FPS脚
         -# ARC  FPSカーブ
         -# LINE 準備直進
         -# LINE 後退接線
         -# ARC  SPSカーブ
         -# LINE SPS脚
         -# LINE SPS進入点(OPEN)
     
     @param[in] fps     脱出作業パス(FPS)
     @param[in] sps     行先作業パス(SPS)
     @param[in] tailLen 後退前予備直進長さ @see Gauge::preReverseLength
     
     @return 生成したフィッシュテールターンパス
     */
    TurnPath PathAssemblerIf::getFishTailPath(const PathFPS& fps, const PathSPS& sps, double tailLen) const {
        LOGV(LOG_TAG "::getFishTailPath(FPS, SPS, rLen)", "regular fishtail");

        TurnPath turnPath;
        // 前作業パス出口
        turnPath.emplace_back(fps.point1());
        // FPSカーブ
        turnPath.emplace_back(fps.getPoint(), fps.Circ);

        // 補助ターンサークル無し
        // FPSカーブ出口からSPSカーブ
        TurnPath&& tangent = getReverseTangentAndCurve(fps.getHeadLeg(), fps.Circ, sps.Circ, tailLen);
        if (tangent.isValid()) {
            turnPath.pushTurnPath(tangent);
            turnPath.pushTurnPath(sps.getPoint());
            turnPath.terminate(sps.enterPoint());
            turnPath.validate();
            PGASSERT(turnPath.size() == 7, ErrorCode::PathGeneration::FATAL);
            // set collision targets
            turnPath[0].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
            turnPath[1].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[2].collisionBoundary = BoundaryType::Kind::FOR_IGNORE;
            turnPath[3].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[4].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[5].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
            
            // SPSパス入口
            turnPath.completeSegment();
            PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
        }
        
        return turnPath;
    }

    /**
     カーブ - 終了点間ターンパス生成(終了ナビゲーション用)
     
     指定のターンサークルから指定点へ向かう カーブ + 脱出接線 の交差検証済みターンパスを生成して返す。
     -# ARC     始点カーブ
     -# LINE    脱出接線
     -# LINE    終点(TERM)
     
     @param[in] eTS         進入接線
     @param[in] currCirc    脱出しようとするターンサークル
     @param[in] destPoint   目標点
     
     @return 生成したターンパス
     */
    TurnPath PathAssemblerIf::getTurnPath(const LineSegment& eTS, const Circle& currCirc, const XY_Point& destPoint) const {
        TurnPath turnPath;
        
        PathSegment PS = getTangent(eTS, currCirc, Circle{destPoint, 0.0});
        if (PS.isValid()) {
            LineSegment lTS = PS;
            turnPath.pushTurnPath(eTS.point2(), currCirc);
            turnPath.pushTurnPath(lTS);
            PGASSERT(turnPath.size() == 3, ErrorCode::PathGeneration::FATAL);

            turnPath.validate();
        }

        return turnPath;
    }

    /**
     αターンB
     2接線間を結ぶαターンBパスを生成して返す。
     - セグメント構成1
         -# LINE 進入接線脚
         -# ARC  前進カーブ
         -# LINE バック前準備直進
         -# ARC  後退カーブ
         -# LINE 終点(TERM)
     */
    TurnPath PathAssemblerIf::getAlphaBTurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const {
        LOGD(LOG_TAG "::getAlphaBTurnPath", "()")

        TurnPath turnPath;
        turnPath.invalidate();
        
        if (isParallel(eTS, lTS)) {
            // 平行では生成できない
            return turnPath;
        }
        
        // TODO: eSegとlSegのチェック
        // 交差が進行方向に存在する等
        
        // 実際のターン方向(時計回りか反時計回りか)
        const int crossOrient = getCornerOrient(eTS, lTS);
        
        LOGD(LOG_TAG "::getAlphaBTurnPath", "\n<path fill=\"none\" stroke=\"green\" d=\"\n%s\n%s\n\"/>",
             Svg::to_path_d(eTS).c_str(), Svg::to_path_d(lTS).c_str());
        
        // 交点を求める
        const XY_Point px = getCrossPoint(eTS, lTS);
        // ターン出入口点
        XY_Point ePx{px};
        XY_Point lPx{px};
        // 仮の進入・脱出セグメント
        const Vector2D eVec = eTS.getEnterVector();
        const Vector2D lVec = lTS.getLeaveVector();
        LineSegment euSeg{eVec, px, 1.0};
        LineSegment luSeg{px, lVec, 1.0};
        
        // ターン出入口(作業パスの端点でもある)
        ePx = getCrossPoint(eTS, lTS);
        lPx = ePx;
        auto extLengths = getWtCrossLengths(euSeg, luSeg);
            // 前後個別にONにする
            if (whiskerMode.mode.test(WhiskerMode::Mode::Index::FORWARD)) {
                LOGD(LOG_TAG "::getAlphaBTurnPath", "has forward whisker")
                ePx = euSeg.extendTail(extLengths.first).leavePoint();
                extLengths.first += whiskerMode.adjustLength.forward;
            } else {
                LOGD(LOG_TAG "::getAlphaBTurnPath", "no forward whisker")
                extLengths.first = 0.0;
            }
            if (whiskerMode.mode.test(WhiskerMode::Mode::Index::BACKWARD)) {
                LOGD(LOG_TAG "::getAlphaBTurnPath", "has backward whisker")
                lPx = luSeg.extendHead(extLengths.second).enterPoint();
                extLengths.second += whiskerMode.adjustLength.backward;
            } else {
                LOGD(LOG_TAG "::getAlphaBTurnPath", "no  backward whisker")
                extLengths.second = 0.0;
            }

        // ターンパス生成
        // - 進入接線から脱出接線へ直接バックカーブする
        {
            auto lC = getCornerTurnCircle(eTS, lTS, gauge.turnRadius, crossOrient, VertexType::CONCAVE);
            LineSegment eseg = getTangent(px, -lC);
            LineSegment fwSeg{eseg.enterPoint(), eseg.getVector(), eseg.length() + gauge.turn.alpha.preBackLength};
            // 直線バックセグメント
            ReverseSegment bwSeg{fwSeg.leavePoint(), eseg.leavePoint()};
            // 脱出接線
            LineSegment lseg = getTangent(-lC, px);
            LOGD(LOG_TAG "::getAlphaBTurnPath", "\n%s\n%s\n%s\n%s",
                 Svg::to_path(fwSeg).c_str(),
                 Svg::to_path(bwSeg).c_str(),
                 Svg::to_circle(lC, "red").c_str(),
                 Svg::to_path(lseg).c_str());

            // フォーワードウィスカー/進入パス脚
            {
                const double fwExtLength = extLengths.first;
                // 進入パス脚候補
                LineSegment legBase = getForwardWhiskerLegB(eseg, fwExtLength, gauge.turn.alpha.preBackLength);
                // 交点からカーブ入口まで
                turnPath.pushTurnPath(legBase.enterPoint());
                turnPath.pushTurnPath(PathSegment{legBase.leavePoint(), SegmentDir::REVERSE});
                turnPath.pushTurnPath(eseg.leavePoint());
            }
        
            // バックカーブ
            turnPath.pushTurnPath(eseg.leavePoint(), lC, SegmentDir::REVERSE);
        
            // バックワードウィスカー/脱出パス脚
            {
                const double bwExtLength = extLengths.second;
                // 脱出パス脚候補
                // カーブ出口から交点までの基本パス脚
                LineSegment lleg{lseg.enterPoint(), px};
                auto legBase = getBackWhiskerLeg(lleg, bwExtLength, gauge.turn.alpha.postBackLength);
                lPx = legBase.leavePoint();

                // パス構築
                // - バックセグメント
                if (lleg.enterPoint() != legBase.enterPoint()) {
                    turnPath.pushTurnPath(lseg.enterPoint(), SegmentDir::REVERSE);
                }
                // - パス脚(脱出接線)
                turnPath.pushTurnPath(legBase.enterPoint());
                turnPath.setTurnType(Turn::Type::ALPHA);
                // ターン脱出点
                turnPath.pushTurnPath(PathSegmentWork{lPx, SegmentDir::FORWARD});
            }
        }

        // パス完成
        turnPath.completeSegment();
        turnPath.terminate();
        turnPath.validate();
    
        return turnPath;
    }

    /**
     αターンFB
     2接線間を結ぶαターンFBを生成して返す。
     - セグメント構成
         -# LINE 進入接線脚
         -# LINE バック前準備直進
         -# ARC  後退カーブ
         -# LINE 終点(TERM)
     */
    TurnPath PathAssemblerIf::getAlphaFbTurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const {
        LOGV(LOG_TAG "::getAlphFbTurnPath", "()");

        TurnPath turnPath;
        turnPath.invalidate();
        
        if (isParallel(eTS, lTS)) {
            // 平行では生成できない
            return turnPath;
        }
        
        // TODO: eSegとlSegのチェック
        // 交差が進行方向に存在する等
        
        // 実際のターン方向(時計回りか反時計回りか)
        const int crossOrient = getCornerOrient(eTS, lTS);
        
        LOGD(LOG_TAG "::getAlphFbTurnPath", "\n%s\n%s\n",
             Svg::to_path(eTS).c_str(), Svg::to_path(lTS).c_str());
        
        // 交点を求める
        const XY_Point px = getCrossPoint(eTS, lTS);
        // ターン出入口点
        XY_Point ePx{px};
        XY_Point lPx{px};
        // 仮の進入・脱出セグメント
        const Vector2D eVec = eTS.getEnterVector();
        const Vector2D lVec = lTS.getLeaveVector();
        LineSegment euSeg{eVec, px, 1.0};
        LineSegment luSeg{px, lVec, 1.0};
        
        // ターン出入口(作業パスの端点でもある)
        ePx = getCrossPoint(eTS, lTS);
        lPx = ePx;
        auto extLengths = getWtCrossLengths(euSeg, luSeg);
        // 前後個別にONにする
        if (whiskerMode.mode.test(WhiskerMode::Mode::Index::FORWARD)) {
            LOGD(LOG_TAG "::getAlphFbTurnPath", "has forward whisker")
            ePx = euSeg.extendTail(extLengths.first).leavePoint();
            extLengths.first += whiskerMode.adjustLength.forward;
        } else {
            LOGD(LOG_TAG "::getAlphFbTurnPath", "no forward whisker")
            extLengths.first = 0.0;
        }
        if (whiskerMode.mode.test(WhiskerMode::Mode::Index::BACKWARD)) {
            LOGD(LOG_TAG "::getAlphFbTurnPath", "has backward whisker")
            lPx = luSeg.extendHead(extLengths.second).enterPoint();
            extLengths.second += whiskerMode.adjustLength.backward;
        } else {
            LOGD(LOG_TAG "::getAlphFbTurnPath", "no  backward whisker")
            extLengths.second = 0.0;
        }
        
        // 進入接線
        // - 進入接線のパス脚分延長部分(現在は進入・脱出接線の交点から)
        const LineSegment eseg{ePx, eVec, gauge.turn.alpha.enterLeg};
        
        //        const auto& whiskerParam = gauge.turnModifier.backturn.whisker;
        // C1中心点
        auto c1point = XY_Point{eseg.leavePoint(), eVec.getOrthogonal(1), crossOrient * gauge.turnRadius};
        Circle eC{c1point, gauge.turnRadius, crossOrient};
        // C2 = C1でスタート
        Circle lC = eC;
        // C1中心と脱出接線との距離
        // - 脱出接線の右にあるか左にあるかで符号が異なる
        Vector2D vc{lTS.enterPoint(), eC.center};
        const double cp = lTS.getEnterVector().getCrossProduct(vc);
        double dc = lTS.distance(eC.center);   // 点と直線との距離
        dc *= -crossOrient * offsetSign(cp);
        const double d = lC.radius - dc;
        // C2中心を脱出接線の入口方向へシフト
        const double l = leg((eC.radius + lC.radius), d);
        lC.center = XY_Point{lC.center, lTS.getEnterVector(), -l};
        // C2中心を脱出接線高さの差分シフト
        lC.center = XY_Point(lC.center, lTS.getEnterVector().getOrthogonal(1), -crossOrient * d);
        // C1対C2接点
        Vector2D c2vec{eC.center, lC.center};
        const XY_Point pc{lC.center, c2vec, -lC.radius};

        const double hEnter = px.distance(eseg.leavePoint());
        const double hLeave = px.distance(pc);
        if (TOL_TEN_CM < (hLeave - hEnter)) {
            // バック前準備直進
            const LineSegment fwSeg{pc, c2vec.getOrthogonal(eC.orient), gauge.turn.alpha.preBackLength};
            // 直線バックセグメント
            ReverseSegment bwSeg{fwSeg};
            bwSeg.exchange();
            // 脱出接線
            LineSegment lseg = getTangent(-lC, px);
            
            LOGD(LOG_TAG "::getAlphFbTurnPath", "FORWARD THEN BACK")
            LOGD(LOG_TAG "::getAlphFbTurnPath", "PATH:\n%s\n%s\n%s\n%s\n%s\n%s",
                 Svg::to_path(eseg).c_str(),
                 Svg::to_circle(eC, "red").c_str(),
                 Svg::to_path(fwSeg).c_str(), Svg::to_path(bwSeg).c_str(),
                 Svg::to_circle(lC, "red").c_str(),
                 Svg::to_path(lseg).c_str());
            
            // ターンパス生成
            // フォーワードウィスカー/進入パス脚
            {
                const double fwExtLength = extLengths.first;
                // 進入パス脚候補
                // - FBのフォーワードウィスカーはバックカーブ前ではないのでpreBackは不要
                LineSegment legBase = getForwardWhiskerLegFb(eseg, fwExtLength);
                // 交点からカーブ入口まで
                turnPath.pushTurnPath(legBase.enterPoint());
                turnPath.pushTurnPath(PathSegment{legBase.leavePoint(), SegmentDir::REVERSE});
            }
            // フォーワードカーブ入口
            turnPath.pushTurnPath(eseg.leavePoint(), eC);
            if (TOL_ONE_CM < gauge.turn.alpha.preBackLength) {
                // バック前準備直進
                turnPath.pushTurnPath(fwSeg.enterPoint());
                turnPath.pushTurnPath(bwSeg.enterPoint(), SegmentDir::REVERSE);
            }
            // バックカーブ入口
            turnPath.pushTurnPath(bwSeg.leavePoint(), lC, SegmentDir::REVERSE);

            // バックワードウィスカー/脱出パス脚
            {
                const double bwExtLength = extLengths.second;
                // 脱出パス脚候補
                // カーブ出口から交点までの基本パス脚
                LineSegment lleg{lseg.enterPoint(), px};
                auto legBase = getBackWhiskerLeg(lleg, bwExtLength, gauge.turn.alpha.postBackLength);
                lPx = legBase.leavePoint();

                // パス構築
                // - バックセグメント
                if (lleg.enterPoint() != legBase.enterPoint()) {
                    turnPath.pushTurnPath(lseg.enterPoint(), SegmentDir::REVERSE);
                }
                // - パス脚(脱出接線)
                turnPath.pushTurnPath(legBase.enterPoint());
                turnPath.setTurnType(Turn::Type::ALPHA);
                // ターン脱出点
                turnPath.pushTurnPath(PathSegmentWork{lPx, SegmentDir::FORWARD});
            }

            turnPath.setTurnType(Turn::Type::ALPHA);
            
            // パス完成
            turnPath.completeSegment();
            turnPath.terminate();
            turnPath.validate();
        }
        
        return turnPath;
    }

    /**
     αターンA
     2接線間を結ぶαターンAを生成して返す。
     - 進入・脱出接線は交差せず、前進カーブで脱出接線と交差する。交差している場合、空のinvalidなパスを返す。
     - セグメント構成
         -# LINE 進入接線脚
         -# ARC  前進カーブ
         -# LINE バック前準備直進
         -# ARC  後退カーブ
         -# LINE 終点(TERM)
     */
    TurnPath PathAssemblerIf::getAlphaATurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const {
        LOGV(LOG_TAG "::getAlphaATurnPath", "(eTS,lTS)\n%s\n%s", Svg::to_path(eTS).c_str(), Svg::to_path(lTS).c_str())

        TurnPath turnPath;
        turnPath.invalidate();

        // ターン方向
        const double crossOrient = getCornerOrient(eTS, lTS);
        // 交点
        const XY_Point px = getCrossPoint(eTS, lTS);
        // 進入接線終点位置位置関係
        const double edp = eTS.getDotProductTo(px);
        // 脱出接線進入点位置関係
//        const double ldp = lTS.getDotProductFrom(px);
        // バックカーブ前準備前進
        const double preBackLen = gauge.turn.alpha.preBackLength;
        // バックカーブ後準備後進
//        const double postBackLen = gauge.turn.alpha.postBackLength;

        if (0.0 < edp) {
            // αターン(A)

            // 進入カーブ
            Circle C1 = getLeaveTurnCircle(eTS, gauge.turnRadius, crossOrient);
    
            // 進入接線が脱出接戦に到達していない(pre-emptive αターン(A))
            // C1脱出点 = lTSの垂線との接点
            Vector2D lVec = lTS.getLeaveVector();
            Vector2D lVecInvert = -lVec.getUnitVector();
            auto p = getShifted(C1.center, lVecInvert * Vector2D{C1.radius});
            
            // カーブ1
            PathSegment aSeg1{eTS.leavePoint(), C1};
            aSeg1.leavePoint() = p;

            // 中間接線(仮)
            // - C1 はlSegに交差している
            Vector2D iVec = lVecInvert.getOrthogonal(crossOrient);
            // - 長さを0にすると計算に使えない
            PathSegment iSegFw{LineSegment{p, iVec, std::max(1.0, preBackLen)}};
            LOGV(LOG_TAG "::makeTurn", "iSeg\n%s", Svg::to_path(iSegFw).c_str())
            // カーブ2(backward)
            PathSegment aSeg2{getInterArcSegment(iSegFw, lTS, gauge.turnRadius, crossOrient), SegmentDir::REVERSE};
            aSeg2.Circ.orient = -aSeg2.Circ.orient;
            aSeg2.exchange();
            aSeg2.direction = SegmentDir::REVERSE;
            LOGV(LOG_TAG "::makeTurn", "aSeg2\n%s", Svg::to_path(aSeg2).c_str())

            // 中間接線(確定)
            // - 生の接線長
            const double iSegLen = p.distance(aSeg2.enterPoint());
            // - 前進長は最短preBackLen
            const double fwLen = std::max(iSegLen, preBackLen);
            // - 前進接線(preBack)
            iSegFw = getFromHead(iSegFw, fwLen);
            // - 後退長(0以上)
            const double bwLen = std::max(0.0, preBackLen - iSegLen);
            auto iSegRev = getReflected(iSegFw, bwLen);

            // 脱出接線
            PathSegment lSeg{LineSegment{aSeg2.leavePoint(), lVec, 1.0}};
           
            // 進入パス脚
            turnPath.pushTurnPath(eTS);
            // 第1カーブ
            turnPath.pushTurnPath(aSeg1);
            // 中間接戦
            turnPath.pushTurnPath(iSegFw);
            // PreBack
            turnPath.pushTurnPath(iSegRev);
            // 第2カーブ
            turnPath.pushTurnPath(aSeg2);
            // 脱出パス脚
            turnPath.pushTurnPath(lSeg);
            
            turnPath.setTurnType(Turn::Type::ALPHA);
            turnPath.terminateAuto();
            turnPath.validate();
        }

        return turnPath;
    }

    /**
     バックターンパス生成
     2接線間を結ぶバックターンパスのうち、FBを優先して生成して返す。コーナ角度とトラクターの寸法により、FBーの生成条件に合致しない場合のみFBを返す。
     @see getAlphaTurnBPath, getAlphaTurnFbPath

     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線
     @retval 生成したターンパス
     */
    TurnPath PathAssemblerIf::getBackTurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const {
        LOGV(LOG_TAG "::getBackTurnPath", "()");

        TurnPath turnPath = getAlphaBTurnPath(eTS, lTS, whiskerMode);
        if (!turnPath.isValid()) {
            turnPath = getAlphaFbTurnPath(eTS, lTS, whiskerMode);
        }
        
        return turnPath;
    }

    /**
     プレーンターンパス生成
     
     コーナーを構成する2接線を前進のみの単一カーブでターンするパスを返す。
     - 引数のセグメントは直線を表しているものとし、ターンパスは端点を結ばない。また、2接線の端点を接続しておく必要もない。
     - 規定の長さのパス脚の付いたターンパスを返す。
     - セグメント構成
         -# LINE 進入接線脚  始点は規定のパス脚始点
         -# ARC  前進カーブ
         -# LINE 脱出接線脚  終点は規定のパス脚終点
         -# TERM
     
     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線
     @retval 生成したターンパス
     */
    TurnPath PathAssemblerIf::getPlainTurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const {
        LOGV(LOG_TAG "::getPlainTurnPath", "()");
        TurnPath turnPath;
        
        try {
            // 実際のターン方向(時計回りか反時計回りか)
            const int crossOrient = getCornerOrient(eTS, lTS);
            const bool concave = whiskerMode.isConcave(crossOrient);
            const auto ecLine = getCollateralSegment(eTS, crossOrient * gauge.turnRadius);
            const auto lcLine = getCollateralSegment(lTS, crossOrient * gauge.turnRadius);
            const XY_Point ep = getCrossPoint(ecLine, lcLine);
            Circle C1{ep, gauge.turnRadius, crossOrient};
            LOGV(LOG_TAG "::getPlainTurnPath", "[INFO] concave:%d; edges :\n%s\n%s", concave, Svg::to_path_d(eTS).c_str(), Svg::to_path_d(lTS).c_str());

            // ターン進入側脚
            auto eSeg = getTangent(eTS.enterPoint(), C1);
            if (!isCollinear(eTS, eSeg)) {
                // 向きが一致しない場合、ターンサークル接点がターン進入点より手前にある
                // - 正しい向きにパス脚を付け直す
                auto tmpSeg = getTangent(C1, eTS.leavePoint());
                eSeg = getHeadLeg(tmpSeg, gauge.minFpsLegLength);
            }
            LineSegment eLeg{eSeg.getVector(), eSeg.leavePoint(), gauge.minFpsLegLength};
            if (concave && whiskerMode.mode.test(WhiskerMode::Mode::Index::FORWARD)) {
                // 作業パスの場合は前のコーナーがパス脚より遠いこと
                const double dp = eLeg.getDotProductFrom(eTS.enterPoint());
                if (dp < 0.0) {
                    LOGE(LOG_TAG "::getPlainTurnPath", "[ERROR] PREV CORNER TOO CLOSE :\n%s\n%s", Svg::to_path_d(eTS).c_str(), Svg::to_path_d(lTS).c_str());
                    turnPath.invalidate(TurnPath::FAILURE_TOO_CLOSE_CORNERS);
                    return turnPath;
                }
            }
            // ターン脱出側脚
            auto lSeg = getTangent(C1, lTS.leavePoint());
            if (!isCollinear(lTS, lSeg)) {
                // 向きが一致しない場合、ターンサークル接点が脱出点を追い越している
                // - 正しい向きにパス脚を付け直す
                auto tmpSeg = getTangent(lTS.enterPoint(), C1);
                lSeg = getTailLeg(tmpSeg, gauge.minSpsLegLength);
            }
            LineSegment lLeg{lSeg.enterPoint(), lSeg.getVector(), gauge.minSpsLegLength};
            if  (concave && whiskerMode.mode.test(WhiskerMode::Mode::Index::BACKWARD)) {
                // 作業パスの場合は次のコーナーがパス脚より遠いこと
                const double dp = lLeg.getDotProductTo(lTS.leavePoint());
                if (dp < 0.0) {
                    LOGD(LOG_TAG "::getPlainTurnPath", "[ERROR] NEXT CORNER TOO CLOSE :\n%s\n%s", Svg::to_path_d(eTS).c_str(), Svg::to_path_d(lTS).c_str());
                    turnPath.invalidate(TurnPath::FAILURE_TOO_CLOSE_CORNERS);
                    return turnPath;
                }
            }
            // ウィスカー
            std::pair<TurnPath, TurnPath> whiskers;
            if (whiskerMode.mode.test(WhiskerMode::Mode::Index::CROSS)) {
                whiskers = getWhiskers(eLeg, lLeg, whiskerMode);
                // 個別にクリア
                if (!whiskerMode.mode.test(WhiskerMode::Mode::Index::FORWARD)) {
                    whiskers.first.clear();
                }
                if (!whiskerMode.mode.test(WhiskerMode::Mode::Index::BACKWARD)) {
                    whiskers.second.clear();
                }
            }
            // パス生成
            // - 進入パス脚
            if (!whiskers.first.empty()) {
                turnPath.pushTurnPath(whiskers.first);
            } else {
                turnPath.pushTurnPath(eLeg.enterPoint());
            }
            // - カーブ
            turnPath.pushTurnPath(eLeg.leavePoint(), C1, SegmentDir::FORWARD);
            // パス脚
            if (!whiskers.second.empty()) {
                turnPath.pushTurnPath(whiskers.second);
                turnPath.completeSegment();
            } else {
                turnPath.pushTurnPath(lLeg.enterPoint());
                turnPath.completeSegment(lLeg.leavePoint());
            }
            turnPath.setTurnType(Turn::Type::PLAIN);
            if (!whiskers.first.empty() || !whiskers.second.empty()) {
                LOGD(LOG_TAG "::getPlainTurnPath", "HAS WHISKER");
                turnPath.modTurnType(Turn::Type::Flag::LEGFOLD);
            }
            turnPath.terminate(turnPath.leavePoint());
            turnPath.validate();
        } catch(...) {
            LOGD(LOG_TAG "::makeStrictRasterPathNode", "[WARN] edge was parallel to workpath\n%s\n%s",
                 Svg::to_path(eTS).c_str(), Svg::to_path(lTS).c_str());
            return turnPath;
        }

        return turnPath;
    }	

#pragma mark - PathAssember
#define LOG_TAG "PathPlan::PathAssemblerIf"

    /**
     αターンパス生成
     
     2接線間を結ぶバックターンパスを生成して検査して返す。(終端済み)
     検査結果が無効であった場合、単一カーブを使用するかどうかを引数で指定する。
     - フォールバックを行なった場合のセグメント構成
        cf. PathAssemblerIf::getBackTurnPath
     - フォールバックを行なった場合のセグメント構成
        cf. PathAssemblerIf::getPlainTurnPath
     
     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線
     @param[in] orient  旋回方向
     @param[in] permitFallback  バックターン生成失敗の場合に単一カーブを使用するかどうか
     @retval 生成したターンパス(終端済み)
     */
    TurnPath PathAssembler::getValidatedAlphaTurnPath(const PathSegment& eTS, const PathSegment& lTS, bool permitFallback, const WhiskerMode_t& aWhiskerMode) const {
        LOGV(LOG_TAG "::getValidatedAlphaTurnPath", "()");
        
        WhiskerMode_t whiskerMode = aWhiskerMode;
        if (whiskerMode.mode.test(WhiskerMode::Mode::Index::FORWARD)) {
            // ターンの前進ウィスカー補正値
            whiskerMode.adjustLength.forward = eTS.whisker.tailAdjustLength;
        }
        if (whiskerMode.mode.test(WhiskerMode::Mode::Index::BACKWARD)) {
            // ターンの後退ウィスカー補正値
            whiskerMode.adjustLength.backward = lTS.whisker.headAdjustLength;
        }

        TurnPath turnPath;
        
        //　フィッシュテールターン試行
        if (!turnPath.isValid()) {
            const auto eVec = eTS.getEnterVector().getUnitVector();
            const auto lVec = lTS.getEnterVector().getUnitVector();
            const double cp = eVec.getDotProduct(lVec);
            LOGD(LOG_TAG "::getValidatedAlphaTurnPath", "dp: %0.7g, angle:%0.7g(%0.7g deg)", cp, eVec.getAngleTo(lVec), AngleUnit::toDegree(eVec.getAngleTo(lVec)));
            if (cp < -0.7071 && validator.checkSPSLegLength(lTS)) {
                auto lSeg = getFromTail(lTS, gauge.minSpsLegLength);
                LineSegment eSeg = eTS;
                justifyTail(lSeg, eSeg);
                LOGD(LOG_TAG "::getValidatedAlphaTurnPath", "try Fishtail: \n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
                     Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
                turnPath = getFishTailTurnPath(eSeg, lSeg, getCornerOrient(eTS, lTS));
                turnPath.terminate();
                if (turnPath.isValid()) {
                    try {
                        validator.validatePointVectorInside(turnPath);
                        if (validator.checkBoundaryIntersection(turnPath, PathPlan::BoundaryType::Kind::FOR_SEEK_WHISKER_LENGTH) != Intersection::NO) {
                            turnPath.invalidate();
                        }
                    } catch(...) {
                        turnPath.invalidate();
                    }
                }
            }
        }

        // プレーンターン試行
        if (!turnPath.isValid() && permitFallback) {
            LOGD(LOG_TAG "::getValidatedAlphaTurnPath", "try plain");
            turnPath = getPlainTurnPath(eTS, lTS, whiskerMode);
            turnPath.terminate();
            // 検査
            try {
                validator.validatePointVectorInside(turnPath);
                if (validator.checkBoundaryIntersection(turnPath, PathPlan::BoundaryType::Kind::FOR_SEEK_WHISKER_LENGTH) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        // αターン(B)試行
        if (!turnPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedAlphaTurnPath", "try B");
            turnPath = getAlphaBTurnPath(eTS, lTS, whiskerMode);
            turnPath.terminate();
            try {
                validator.validatePointVectorInside(turnPath);
                if (validator.checkBoundaryIntersection(turnPath, PathPlan::BoundaryType::Kind::FOR_SEEK_WHISKER_LENGTH) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        // αターン(FB)試行
        if (!turnPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedAlphaTurnPath", "try FB");
            turnPath = getAlphaFbTurnPath(eTS, lTS, whiskerMode);
            {
                turnPath.terminate();
                try {
                    validator.validatePointVectorInside(turnPath);
                    if (validator.checkBoundaryIntersection(turnPath, PathPlan::BoundaryType::Kind::FOR_SEEK_WHISKER_LENGTH) != Intersection::NO) {
                        turnPath.invalidate();
                    }
                } catch(...) {
                    turnPath.invalidate();
                }
            }
        }

        
        return turnPath;
    }

    /**
     コーナーターンパス生成
     
     コーナーを構成する2接線間を結ぶターンを返す。
     バックターンが不可能な場合、プレーンターンにフォールバックする。
     - フォールバックを行なった場合のセグメント構成
     cf. PathAssemblerIf::getBackTurnPath
     - フォールバックを行なった場合のセグメント構成
     -# LINE 進入接線脚
     -# ARC  前進カーブ
     -# LINE 終点(open)
     
     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線
     @param[in] orient  旋回方向
     @param[in] permitBackward  バック許可フラグ
     @retval 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedCornerTurnPath(const PathSegment& eTS, const PathSegment& lTS, bool permitBackward, int orient) const {
        LOGV(LOG_TAG "::getValidatedCornerTurnPath", "()");
        TurnPath turnPath;

        if (eTS.pathAttr.isCounterOrbital()) {
            // 逆走しているセグメントの場合は反転する必要がある
            orient = RotateDirection::invert(orient);
        }
        
        if (isInline(eTS, lTS)) {
            LOGD(LOG_TAG "::getValidatedCornerTurnPath()", " flip");
            turnPath = getFishTailTurnPath(eTS, lTS, orient);
            // フォールバックはあり得ないのですぐ返す
            return turnPath;
        }
        
        WhiskerMode_t whiskerMode = WhiskerMode::NONE;
        whiskerMode.rotation = orient;  // 凹角かどうかの判別用
        const int cornerOrient = getCornerOrient(eTS, lTS);
        if (permitBackward) {
            whiskerMode.mode.set(WhiskerMode::Mode::Index::CROSS);
            const bool fw = (eTS.pathAttr.rideType == PathAttr::RideType::WORKING);
            whiskerMode.mode.set(WhiskerMode::Mode::Index::FORWARD, fw);
            if (fw) {
                // 前進ウィスカーはターン入口側 = 進入セグメントの末尾側
                whiskerMode.adjustLength.forward = eTS.whisker.tailAdjustLength;
            }
            const bool bw = (lTS.pathAttr.rideType == PathAttr::RideType::WORKING);
            whiskerMode.mode.set(WhiskerMode::Mode::Index::BACKWARD, bw);
            if (bw) {
                // 後退ウィスカーはターン出口 = 脱出セグメントの先頭側
                whiskerMode.adjustLength.backward = lTS.whisker.headAdjustLength;
            }
            // 現在CONCAVEは凹角対応はない
            // - 使用する場合は遷移パスの逆回りで誤動作しないように考慮する。
//            if ((fw || bw) && (orient != gauge.headland.rotation)) {
//                whiskerMode.mode.set(WhiskerMode::Mode::Index::CONCAVE);
//            }

            // バックターン生成
            // - 凸角のみ適用
            if (permitBackward && cornerOrient == orient) {
                turnPath = getValidatedAlphaTurnPath(eTS, lTS, whiskerMode);
            }
        }

        if (!turnPath.isValid()) {
            // プレーンターンにフォールバック
            turnPath = getValidatedPlainTurnPath(eTS, lTS, whiskerMode);
        }
        
        return turnPath;
    }

    /**
     ラスター進入ターンパス生成
     2接線間を結ぶターンパスを生成して検査して返す。(終端済み)
        - αターン(B,FB)、プレーンターン、フィッシュテールまたはフックターンを試す。
        - lTSはラスター作業パスのパス脚である必要がある
     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線
     @param[in] orient  旋回方向
     @param[in] permitFallback  バックターン生成失敗の場合に単一カーブを使用するかどうか
     @retval 生成したターンパス(終端済み)
     */
    TurnPath PathAssembler::getValidatedEnterRasterTurnPath(const PathSegment& eTS, const PathSegment& lTS, const WhiskerMode_t& aWhiskerMode) const {
        LOGV(LOG_TAG "::getValidatedEnterRasterTurnPath", "()");
        
        WhiskerMode_t whiskerMode = aWhiskerMode;
        if (whiskerMode.mode.test(WhiskerMode::Mode::Index::FORWARD)) {
            // ターンの前進ウィスカー補正値
            whiskerMode.adjustLength.forward = eTS.whisker.tailAdjustLength;
        }
        if (whiskerMode.mode.test(WhiskerMode::Mode::Index::BACKWARD)) {
            // ターンの後退ウィスカー補正値
            whiskerMode.adjustLength.backward = lTS.whisker.headAdjustLength;
        }

        TurnPath turnPath;
        
        //　フィッシュテールターン試行
        if (!turnPath.isValid()) {
            const auto eVec = eTS.getEnterVector().getUnitVector();
            const auto lVec = lTS.getEnterVector().getUnitVector();
            const double cp = eVec.getDotProduct(lVec);
            const double cornerOrient = getCornerOrient(eTS, lTS);
            Circle tc = getEnterTurnCircle(lTS, gauge.turnRadius, cornerOrient);
            LOGD(LOG_TAG "::getValidatedEnterRasterTurnPath", "dp: %0.7g, angle:%0.7g(%0.7g deg)", cp, eVec.getAngleTo(lVec), AngleUnit::toDegree(eVec.getAngleTo(lVec)));
            if (cp < 0.5 && ((lTS.distance(tc.center) < tc.radius) || validator.checkSPSLegLength(lTS))) {
                // @TODO: 条件が冗長なので要整理
                // - getInterSegmentTurnPath()とgetHookTurnPath()内の適用範囲も確認すること
                auto lSeg = getFromTail(lTS, gauge.minSpsLegLength);
                LineSegment eSeg = eTS;
                justifyTail(lSeg, eSeg);
                if (gauge.headland.permitBackward) {
                    LOGD(LOG_TAG "::getValidatedEnterRasterTurnPath", "try Fishtail/Flat: \n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
                         Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
                    if (isRasterEnterLeaveAvailable(eSeg, lSeg)) {
                        turnPath = getInterSegmentTurnPath(eSeg, lSeg);
                    } else {
                        LOGD(LOG_TAG "::getValidatedEnterRasterTurnPath", "Failed: inroad to EHP");
                    }
                } else {
                    LOGD(LOG_TAG "::getValidatedEnterRasterTurnPath", "try Hook: \n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
                         Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
                    LineSegment iTS{eSeg.leavePoint(), lSeg.enterPoint()};
                    turnPath = getHookTurnPath(eSeg, iTS, lSeg);
                }
                if (!turnPath.isTerminated()) {
                    turnPath.terminate(lSeg.enterPoint());
                }
                if (turnPath.isValid()) {
                    try {
                        validator.validatePointVectorInside(turnPath);
                        validator.validateSegmentPropaties(turnPath);
                        validator.validateIntersectionWithShp(turnPath);
                        if (validator.checkBoundaryIntersection(turnPath, BoundaryType::Kind::FOR_ENTER_RASTER_TURN) != Intersection::NO) {
                            turnPath.invalidate();
                        }
                    } catch(...) {
                        turnPath.invalidate();
                    }
                }
            }
        }

        // αターン(B,FB)試行
        if (!turnPath.isValid() && gauge.headland.permitBackward) {
            LOGD(LOG_TAG "::getValidatedEnterRasterTurnPath", "try ALPHA");
            turnPath = getValidatedAlphaTurnPath(eTS, lTS, whiskerMode);
            turnPath.terminate();
            try {
                validator.validatePointVectorInside(turnPath);
                if (validator.checkBoundaryIntersection(turnPath, PathPlan::BoundaryType::Kind::FOR_ENTER_RASTER_TURN) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        // プレーンターン試行
        if (!turnPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedEnterRasterTurnPath", "try PLAIN");
            turnPath = getPlainTurnPath(eTS, lTS, whiskerMode);
            turnPath.terminate();
            // 検査
            try {
                validator.validatePointVectorInside(turnPath);
                if (validator.checkBoundaryIntersection(turnPath, PathPlan::BoundaryType::Kind::FOR_ENTER_RASTER_TURN) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        return turnPath;
    }


    /**
     ラスター脱出ターンパス生成
     OR遷移パスの最初のターン、即ちラスター作業パスの最後のセグメントから周回(遷移)パスへ入る最初のターンを生成する。
        - αターン(B,FB)、プレーンターン、フィッシュテールまたはフックターンを試す。
        - eTSはラスター作業パスのパス脚である必要がある
        - lTSは忖度しない。
     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線
     @param[in] orient  旋回方向
     @param[in] permitFallback  バックターン生成失敗の場合に単一カーブを使用するかどうか
     @retval 生成したターンパス(終端済み)
     */
    TurnPath PathAssembler::getValidatedLeaveRasterTurnPath(const PathSegment& eTS, const PathSegment& lTS, const TransitTurnParams& params) const {
        LOGV(LOG_TAG "::getValidatedLeaveRasterTurnPath", "()");
        
        WhiskerMode_t whiskerMode = params;
        if (whiskerMode.mode.test(WhiskerMode::Mode::Index::FORWARD)) {
            // ターンの前進ウィスカー補正値
            whiskerMode.adjustLength.forward = eTS.whisker.tailAdjustLength;
        }
        if (whiskerMode.mode.test(WhiskerMode::Mode::Index::BACKWARD)) {
            // ターンの後退ウィスカー補正値
            whiskerMode.adjustLength.backward = lTS.whisker.headAdjustLength;
        }

        TurnPath turnPath;
        
        //　フィッシュテールターン試行
        if (!turnPath.isValid()) {
            const auto eVec = eTS.getEnterVector().getUnitVector();
            const auto lVec = lTS.getEnterVector().getUnitVector();
            const double dp = eVec.getDotProduct(lVec);
            const double cornerOrient = getCornerOrient(eTS, lTS);
            Circle tc = getEnterTurnCircle(eTS, gauge.turnRadius, cornerOrient);
            LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "dp: %0.7g, angle:%0.7g(%0.7g deg)", dp, eVec.getAngleTo(lVec), AngleUnit::toDegree(eVec.getAngleTo(lVec)));
//            if (0.9962 < dp && gauge.checkFPSLegLength(eTS)) {
//                // 平行に近い
//                auto lpSrc = eTS.leavePoint();
//                auto lpDest = eTS.leavePoint();
//                LineSegment iTS{lpSrc, lpDest};
//                double cp = eTS.getCrossProduct(iTS);
//                if (offsetSign(cp) == -gauge.headland.rotation) {
//                    // 符号が一致するので
//                }
//            } else
            if (dp < -0.5 && ((lTS.distance(tc.center) <= tc.radius) || validator.checkFPSLegLength(eTS))) {
                // @TODO: 条件が冗長なので要整理
                // - getInterSegmentTurnPath()とgetHookTurnPath()内の適用範囲も確認すること
                auto eSeg = getFromHead(eTS, gauge.minFpsLegLength);
                LineSegment lSeg = lTS;
                
                // αターン(A) (pre-emptive)
                if (params.avoidAwp && gauge.headland.permitBackward) {
                    LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "try Alpha avoid inroad AWP.:\n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
                         Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
                    // 既耕作領域を踏まないようにαターンを使用
                    // - このモードで失敗したら上から枕地を広げてリトライする
                    // パス脚
                    PathSegment eSeg{getFromTail(eTS, gauge.minFpsLegLength)};
                    turnPath = getValidatedAlphaTurnPath7(eTS, lTS, whiskerMode);
                    try {
                        validator.validatePointVectorInside(turnPath);
                    } catch(...) {
                        turnPath.invalidate();
                    }
                    if (!turnPath.isValid()) {
                        // 踏み荒らし禁止
                        LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "Alpha turn failed.");
                        ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::Orbital::RASTER_ORBITAL_TRANSIT);
                        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] Orbital - Raster transit turn failed.", "::getValidatedRasterLeaveTurnPath");
                        throw err;
                    }
                }
                // フィッシュテールフォールバック
                if (!turnPath.isValid()) {
                    justifyHead(eSeg, lSeg);
                    if (gauge.headland.permitBackward) {
                        LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "try Fishtail/Flat inter segs: \n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
                             Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
                        if (isRasterEnterLeaveAvailable(eSeg, lSeg)) {
                            turnPath = getInterSegmentTurnPath(eSeg, lSeg);
                            LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "fishtail path:\n%s", Svg::to_path_d(turnPath).c_str());
                        } else {
                            LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "failed: inroad to EHP");
                        }
                    } else {
                        LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "try Hook: \n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
                             Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
                        LineSegment iTS{eSeg.leavePoint(), lSeg.enterPoint()};
                        turnPath = getHookTurnPath(eSeg, iTS, lSeg);
                    }
                    turnPath.setTurnType(PathParam::Turn::Type::NAVIGATION);
                    turnPath.terminate(lSeg.leavePoint());
                    if (turnPath.isValid()) {
                        try {
                            validator.validatePointVectorInside(turnPath);
                            validator.validateSegmentPropaties(turnPath);
                            if (validator.checkBoundaryIntersection(turnPath, BoundaryType::Kind::FOR_LEAVE_RASTER_TURN) != Intersection::NO) {
                                turnPath.invalidate();
                            }
                        } catch(...) {
                            turnPath.invalidate();
                        }
                    }
                }
            }
        }

        // αターン(B,FB)試行
        if (!turnPath.isValid() && gauge.headland.permitBackward) {
            LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "try B");
            turnPath = getValidatedAlphaTurnPath(eTS, lTS, whiskerMode);
            turnPath.terminate();
            try {
                validator.validatePointVectorInside(turnPath);
            } catch(...) {
                turnPath.invalidate();
            }
        }
        
        // プレーンターン試行
        if (!turnPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedLeaveRasterTurnPath", "try plain");
            turnPath = getValidatedPlainTurnPath(eTS, lTS, whiskerMode);
            turnPath.terminate();
            // 検査
            try {
                validator.validatePointVectorInside(turnPath);
                if (validator.checkBoundaryIntersection(turnPath, BoundaryType::Kind::FOR_LEAVE_RASTER_TURN) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        return turnPath;
    }

    /**
     周回開始ナビゲーションパス生成
     自動運転開始点から周回パスに入るターンパスを生成する。
        - プレーンターン一つのみで直接入ろうとする。
        - BPのみと交差判定する。HPへの進入は無視する。
     @param[in] srcPoint    接線始点
     @param[in] eTS         行先セグメント
     @retval 生成したターンパス(終端済み)
     */
    TurnPath PathAssembler::getValidatedOribitalEnterPath(const EndPoint& srcPoint, const PathSegment& eTS) const {
        LOGV(LOG_TAG "::getValidatedOribitalEnterPath", "()");
        TurnPath turnPath;

        auto orient = offsetSign(eTS.getCrossProductFrom(srcPoint));
        LineSegment leg = getHeadLeg(eTS, gauge.minSpsLegLength + gauge.termMin.start);
        Circle eC = getEnterTurnCircle(leg, gauge.turnRadius, orient);
        auto ts = getTangent(srcPoint, eC);
        PathSegment aSeg{ts.leavePoint(), eC};
        // 始点がBPに抵触しない位置に調整
        auto extSeg = ensureNoCollisionHeadward(ts, gauge.headland.whisker.lengthStep, 1.0, BoundaryType::Kind::FOR_STARTNAV_PRE_ORBITAL);
        if (extSeg.isNegrective()) {
            return turnPath;
        }
        LOGV(LOG_TAG "::createPreOrbitalPath", "orgSeg: %s\n adjSeg: %s", Svg::to_path(ts).c_str(), Svg::to_path(extSeg).c_str());
        ts.enterPoint() = extSeg.enterPoint();

        turnPath.pushTurnPath(PathSegment{ts});
        turnPath.pushTurnPath(aSeg);
        turnPath.pushTurnPath(PathSegment{leg});
        turnPath.setTurnType(PathParam::Turn::Type::NAVIGATION);
        turnPath.validate();
        turnPath.terminateAuto();

        try {
            validator.validatePointVectorInside(turnPath);
            // HP踏み荒らしはケアしない
            if (validator.checkBoundaryIntersection(turnPath, BoundaryType::Kind::FOR_STARTNAV_PRE_ORBITAL) != Intersection::NO) {
                turnPath.invalidate();
            }
        } catch(...) {
            turnPath.invalidate();
        }
        
        LOGV(LOG_TAG "::createPreOrbitalPath", "Add Start Nav:\n%s", Svg::to_path_d(turnPath).c_str());
        return turnPath;
    };

    /**
     αターン生成
     αターンB、FBの順に試行して検査済みαターンを返す。
     - パスは終端済みであり、終端のセグメントにはlTSの属性をコピーする。
     
     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線。末尾セグメントに属性をコピーする。
     @retval 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedAlphaTurnPath(const PathSegment& eTS, const PathSegment& lTS, const WhiskerMode_t& whiskerMode) const {
        LOGV(LOG_TAG "::getValidatedAlphaTurnPath", "()");

        // αターンB試行
        // - αターンBは寸法によらず生成自体は可能である。
        TurnPath turnPath = getAlphaBTurnPath(eTS, lTS, whiskerMode);
        // 検査
        try {
            validator.validatePointVectorInside(turnPath);
            if (checkBoundary(eTS, turnPath, lTS, PathPlan::BoundaryType::Kind::FOR_BACKTURN1) != Intersection::NO) {
                turnPath.invalidate();
            }
        } catch(...) {
            turnPath.invalidate();
        }

        // αターンFB試行
        if (!turnPath.isValid()) {
            turnPath = getAlphaFbTurnPath(eTS, lTS, whiskerMode);
            // 検査
            try {
                validator.validatePointVectorInside(turnPath);
                if (checkBoundary(eTS, turnPath, lTS, PathPlan::BoundaryType::Kind::FOR_BACKTURN1) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        if (turnPath.isValid()) {
            // セグメント属性をコピー
            turnPath.applyExtAttr(eTS.pathAttr.getExtType());
            turnPath.back().segmentType = lTS.segmentType;
            turnPath.back().pathAttr = lTS.pathAttr;
        }

        return turnPath;
    }

    /**
     αターン生成
     αターンA、B、FBの順に試行して検査済みαターンを返す。
     - パスは終端済みであり、終端のセグメントにはlTSの属性をコピーする。
     - コーナーが形成されないので作業パスは非サポート
     
     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線。末尾セグメントに属性をコピーする。
     @retval 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedAlphaTurnPath7(const PathSegment& eTS, const PathSegment& lTS, const WhiskerMode_t& whiskerMode) const {
        LOGV(LOG_TAG "::getValidatedAlphaTurnPath7", "()");
        TurnPath turnPath;
        turnPath.invalidate();
        
        // αターンA試行
        // - コーナーが形成されないので作業パスの場合はAをスキップ
        if (!eTS.pathAttr.isWorking() && !lTS.pathAttr.isWorking()) {
            turnPath = getAlphaATurnPath(eTS, lTS, whiskerMode);
            try {
                validator.validatePointVectorInside(turnPath);
                if (validator.checkBoundaryIntersection(turnPath, PathPlan::BoundaryType::Kind::FOR_LEAVE_RASTER_TURN) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        // αターンB試行
        // - αターンBは寸法によらず生成自体は可能である。
        if (!turnPath.isValid()) {
            turnPath = getAlphaBTurnPath(eTS, lTS, whiskerMode);
            // 検査
            try {
                validator.validatePointVectorInside(turnPath);
                if (checkBoundary(eTS, turnPath, lTS, PathPlan::BoundaryType::Kind::FOR_LEAVE_RASTER_TURN) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        // αターンFB試行
        if (!turnPath.isValid()) {
            turnPath = getAlphaFbTurnPath(eTS, lTS, whiskerMode);
            // 検査
            try {
                validator.validatePointVectorInside(turnPath);
                if (checkBoundary(eTS, turnPath, lTS, PathPlan::BoundaryType::Kind::FOR_LEAVE_RASTER_TURN) != Intersection::NO) {
                    turnPath.invalidate();
                }
            } catch(...) {
                turnPath.invalidate();
            }
        }

        if (turnPath.isValid()) {
            // セグメント属性をコピー
            turnPath.applyExtAttr(eTS.pathAttr.getExtType());
            turnPath.back().segmentType = lTS.segmentType;
            turnPath.back().pathAttr = lTS.pathAttr;
        }

        return turnPath;
    }

    /**
     プレーンターンパス生成
     
     コーナーを構成する2接線を結ぶプレーンターンパスを有効性検査を行って返す。
     - セグメント構成
         -# LINE 進入接線脚  ただし、始点は規定のパス脚始点である。
         -# ARC  前進カーブ
         -# LINE 脱出接線脚(open) 終点はlTSの終点である。
     
     @param[in] eTS 進入接線
     @param[in] lTS 脱出接線
     @retval 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPlainTurnPath(const PathSegment& eTS, const PathSegment& lTS, const WhiskerMode_t& whiskerMode) const {
        LOGV(LOG_TAG "::getValidatedPlainTurnPath", "()");
        // パス生成
        TurnPath turnPath = getPlainTurnPath(eTS, lTS, whiskerMode);
        if (!turnPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedPlainTurnPath", "INVALID");
            return turnPath;
        }
        // 検査
        try {
            validator.validatePointVectorInside(turnPath);
            // 検査
            if (checkBoundary(eTS, turnPath, lTS, PathPlan::BoundaryType::Kind::FOR_BACKTURN1) != Intersection::NO) {
                LOGD(LOG_TAG "::getValidatedPlainTurnPath", "INVALID");
                turnPath.invalidate();
            }
        } catch(...) {
            turnPath.invalidate();
        }

        turnPath.open();
        // 属性反映
        turnPath.applyExtAttr(eTS.pathAttr.getExtType());
        // - 脱出点
        turnPath.terminate(turnPath.leavePoint());
        return turnPath;
    }

    TurnPath PathAssembler::getCornerTurnPath(const LineSegment& eTS, const LineSegment& iTS, const LineSegment& lTS) const {
        LOGV(LOG_TAG "::getCornerTurnPath",
             "\n<path fill=\"none\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
             Svg::to_path_d(eTS).c_str(),
             Svg::to_path_d(lTS).c_str());
        
        TurnPath turnPath;
        // 直線上にある場合
        if (isLineAhead(eTS, lTS)) {
            LOGD(LOG_TAG "::getCornerTurnPath", "[ERROR] COLLINEAR");
            turnPath.pushTurnPath(eTS.enterPoint());
            turnPath.pushTurnPath(iTS.enterPoint());
            turnPath.pushTurnPath(lTS.enterPoint());
            return turnPath;
        }
        // 90度以上曲がること
        if (!isAcute(eTS, lTS)) {
            LOGD(LOG_TAG "::getCornerTurnPath", "[ERROR] NOT ACUTE ANGLE");
            return turnPath;
        }
        // クランクしないこと
        if (turnDirection(eTS, iTS) != turnDirection(iTS, lTS)) {
            LOGD(LOG_TAG "::getCornerTurnPath", "[ERROR] CLANK");
            return turnPath;
        }
        
        Circle C1, C2;
        if (iTS.length() < gauge.turnRadius) {
            LOGD(LOG_TAG "::getCornerTurnPath", "[INFO] make zero-radius bend");
            // 脱出カーブの方がコーナーの外側でなければならない
            const int cornerOrient = getCornerOrient(eTS, iTS);
            C1 = getLeaveTurnCircle(eTS, gauge.turnRadius, cornerOrient);
            C2 = getEnterTurnCircle(lTS, gauge.turnRadius, cornerOrient);
        } else {
            LOGD(LOG_TAG "::getCornerTurnPath", "[INFO] make double bend");
            C1 = getCornerTurnCircle(eTS, iTS, gauge.turnRadius, getCornerOrient(eTS, iTS), VertexType::CONVEX);
            C2 = getCornerTurnCircle(iTS, lTS, gauge.turnRadius, getCornerOrient(iTS, lTS), VertexType::CONVEX);
        }
        LineSegment cSeg{C1.center, C2.center};
        auto distance = C1.distance(C2);
        auto iSeg1 = getTangent(iTS.enterPoint(), C1);
        auto iSeg2 = getTangent(C2, iTS.leavePoint());
        if (distance < TOL_ONE_CM) {
            LOGD(LOG_TAG "::getFishTailTurnPath", "[INFO] U TURN");
            // U TURN
            auto eSeg = getTangent(eTS.enterPoint(), C1);
            auto lSeg = getTangent(C1, lTS.leavePoint());
        } else if (isCollateral(cSeg, iTS)) {
            LOGD(LOG_TAG "::getFishTailTurnPath", "[INFO] FLAT TURN");
            // FLAT TURN
            auto eSeg = getTangent(eTS.enterPoint(), C1);
            auto iTC = getForwardTangentAndCurve(eSeg, C1, C2);
            auto lSeg = getTangent(C2, lTS.leavePoint());
            turnPath.pushTurnPath(eSeg.enterPoint());
            turnPath.pushTurnPath(eSeg.leavePoint(), C1);
            turnPath.pushTurnPath(iTC);
            turnPath.pushTurnPath(lSeg.enterPoint());
        } else {
            LOGD(LOG_TAG "::getFishTailTurnPath", "[INFO] FISHTAIL TURN");
            // FISHTAHL TURN
            auto eSeg = eTS;
            auto iSeg = iTS;
            auto lSeg = getTangent(C2, lTS.leavePoint());

            // 進入接線
            eSeg = getTangent(eSeg.enterPoint(), C1);
            // 切り返し接線とカーブ
            auto iTC = getReverseTangentAndCurve(eSeg, C1, C2, gauge.turn.fishtail.preBackLength);
            turnPath.pushTurnPath(eSeg.enterPoint());
            turnPath.pushTurnPath(eSeg.leavePoint(), C1);
            turnPath.pushTurnPath(iTC);
            turnPath.pushTurnPath(lSeg.enterPoint());
            LOGD(LOG_TAG "::getFishTailTurnPath", "\n%s",Svg::to_path(turnPath).c_str());
        }
        
        turnPath.completeSegment();
        turnPath.validate();
        return turnPath;
    }

    /**
     ターンパス生成
     
     指定の線分間を結ぶターンパスを返す。
     各線分は接続されている必要はないがターンの端点は指定の線分の端点を返す。
     
     @param[in] eTS 進入セグメント
     @param[in] eTS 脱出セグメント
     */
    TurnPath PathAssembler::getInterSegmentTurnPath(const LineSegment& eTS, const LineSegment& lTS) const {
        LOGV(LOG_TAG "::getInterSegmentTurnPath",
             "\n<path fill=\"none\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
             Svg::to_path_d(eTS).c_str(),
             Svg::to_path_d(lTS).c_str());
        
        TurnPath turnPath;
        LineSegment iTS{eTS.leavePoint(), lTS.enterPoint()};
        // 直線上にある場合
        if (isLineAhead(eTS, lTS)) {
            LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] COLLINEAR");
            turnPath.pushTurnPath(eTS.enterPoint());
            turnPath.pushTurnPath(lTS.enterPoint());
            return turnPath;
        }
        // 長さがあること
        if (eTS.length() == 0.0 || lTS.length() == 0.0) {
            LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] 0 length eTS or lTS");
            return turnPath;
        }
        // 90度以上曲がること
        if (!isAcute(eTS, lTS)) {
            LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] NOT ACUTE ANGLE");
            return turnPath;
        }
        // クランクしないこと
        if (turnDirection(eTS, iTS) != turnDirection(iTS, lTS)) {
            LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] CLANK");
            return turnPath;
        }

        const double cornerOrient = getCornerOrient(iTS, lTS);
        Circle C1 = getLeaveTurnCircle(eTS, gauge.turnRadius, cornerOrient);
        Circle C2 = getEnterTurnCircle(lTS, gauge.turnRadius, cornerOrient);
        LOGD(LOG_TAG "::getInterSegmentTurnPath", "\n%s\n%s", Svg::to_circle(C1).c_str(), Svg::to_circle(C2).c_str());
        
        LineSegment cSeg{C1.center, C2.center};
        auto distance = C1.distance(C2);
        auto iSeg1 = getTangent(iTS.enterPoint(), C1);
        auto iSeg2 = getTangent(C2, iTS.leavePoint());
        if (distance < TOL_ONE_CM) {
            LOGD(LOG_TAG "::getInterSegmentTurnPath", "[INFO] U TURN");
            // U TURN
            auto eSeg = getTangent(eTS.enterPoint(), C1);
            if (eSeg.length() < TOL_MIN_SEG) {
                LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] SHORT ENTER SEG");
                return turnPath;
            }
            eSeg = getFromTail(eSeg, gauge.minFpsLegLength);
            auto lSeg = getTangent(C1, lTS.leavePoint());
            if (lSeg.length() < TOL_MIN_SEG) {
                LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] SHORT LEAVE SEG");
                return turnPath;
            }
            turnPath.pushTurnPath(eSeg.enterPoint());
            turnPath.pushTurnPath(eSeg.leavePoint(), C1);
            turnPath.pushTurnPath(lSeg.enterPoint());
            turnPath.pushTurnPath(lSeg.leavePoint());
            // ターンタイプ設定
            // - まるごとNAVIGATION
            turnPath.setTurnType(PathParam::Turn::Type::NAVIGATION);
            turnPath.validate();
        } else {
            // 事前にフラット/フィッシュテール適用可否判別は難しいので実際に作ってみる
            auto eSeg = getTangent(eTS.enterPoint(), C1);
            if (eSeg.length() < TOL_MIN_SEG) {
                LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] SHORT ENTER SEG");
                return turnPath;
            }
            eSeg = getFromTail(eSeg, gauge.minFpsLegLength);
            auto lSeg = getTangent(C2, lTS.leavePoint());
            if (lSeg.length() < TOL_MIN_SEG) {
                LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] SHORT LEAVE SEG");
                return turnPath;
            }
            if (!C1.checkIntersection(lSeg.enterPoint()) && !C2.checkIntersection(eSeg.leavePoint())) {
                // FLAT TURN
                auto iTC = getForwardTangentAndCurve(eSeg, C1, C2);
                if (iTC.isValid()) {
                    turnPath.pushTurnPath(eSeg.enterPoint());
                    turnPath.pushTurnPath(eSeg.leavePoint(), C1);
                    turnPath.pushTurnPath(iTC);
                    turnPath.pushTurnPath(lSeg.enterPoint());
                    // ターンタイプ設定
                    turnPath.setTurnType(PathParam::Turn::Type::NAVIGATION);
                    const auto& arc1 = turnPath[1];
                    const auto& arc2 = turnPath[3];
                    if (!turnPath.hasReverseSeg() && arc1.checkIntersection(arc2) == Intersection::NO) {
                        LOGD(LOG_TAG "::getInterSegmentTurnPath", "[INFO] FLAT TURN");
                        turnPath.validate();
                    } else {
                        turnPath.clear();
                    }
                }
            }
            if (!turnPath.isValid() && gauge.headland.permitBackward) {
                LOGD(LOG_TAG "::getInterSegmentTurnPath", "[INFO] FISHTAIL TURN");
                // FISHTAHL TURN
                auto eSeg = getTangent(eTS.enterPoint(), C1);
                if (eSeg.length() < TOL_MIN_SEG) {
                    LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] SHORT ENTER SEG");
                    return turnPath;
                }
                eSeg = getFromTail(eSeg, gauge.minFpsLegLength);
                auto lSeg = getTangent(C2, lTS.leavePoint());
                if (lSeg.length() < TOL_MIN_SEG) {
                    LOGD(LOG_TAG "::getInterSegmentTurnPath", "[ERROR] SHORT LEAVE SEG");
                    return turnPath;
                }

                // 切り返し接線とカーブ
                auto iTC = getReverseTangentAndCurve(eSeg, C1, C2, gauge.turn.fishtail.preBackLength);
                turnPath.pushTurnPath(eSeg.enterPoint());
                turnPath.pushTurnPath(eSeg.leavePoint(), C1);
                turnPath.pushTurnPath(iTC);
                turnPath.pushTurnPath(lSeg.enterPoint());
                // ターンタイプ設定
                // - まるごとNAVIGATION
                turnPath.setTurnType(PathParam::Turn::Type::NAVIGATION);
                turnPath.validate();
            }
        }

        turnPath.completeSegment();
        return turnPath;
    }


    /**
     フィッシュテールターンパス
     
     指定の線分間を結ぶターンパスを返す。
     各線分は接続されている必要はないがターンの端点は指定の線分の端点を返す。
     
     @param[in] eTS 進入セグメント
     @param[in] eTS 脱出セグメント
     */
    TurnPath PathAssembler::getFishTailTurnPath(const LineSegment& eTS, const LineSegment& lTS, int orient) const {
        LOGV(LOG_TAG "::getFishTailTurnPath", "(rotaion:%d) ZERO-RADIUS BEND RETURN"
             "\n<path fill=\"none\" stroke=\"black\" d=\"\n"
             "\tM\t%0.7g,%0.7g\tL\t%0.7g,%0.7g\n"
             "\tM\t%0.7g,%0.7g\tL\t%0.7g,%0.7g\n\"/>",
             orient,
             eTS.point1().x, -eTS.point1().y, eTS.point2().x, -eTS.point2().y,
             lTS.point1().x, -lTS.point1().y, lTS.point2().x, -lTS.point2().y);
        
        TurnPath turnPath;
        // 90度以上曲がること
        if (!isAcute(eTS, lTS)) {
            LOGD(LOG_TAG "::getFishTailTurnPath", "[ERROR] NOT ACUTE ANGLE");
            return turnPath;
        }

        // 脱出カーブの方がコーナーの外側でなければならない
        Circle C1 = getLeaveTurnCircle(eTS, gauge.turnRadius, orient);
        Circle C2 = getEnterTurnCircle(lTS, gauge.turnRadius, orient);

        // 進入接線
        auto eSeg = getTangent(eTS.enterPoint(), C1);
        // 脱出接線
        auto lSeg = getTangent(C2, lTS.leavePoint());
        // 切り返し接線とカーブ
        auto iTC = getReverseTangentAndCurve(eSeg, C1, C2, gauge.turn.fishtail.preBackLength);

        // パス構築
        turnPath.pushTurnPath(eSeg.enterPoint());
        turnPath.pushTurnPath(eSeg.leavePoint(), C1);
        turnPath.pushTurnPath(iTC);
        turnPath.pushTurnPath(lSeg.enterPoint());
        turnPath.completeSegment(lSeg.leavePoint());
        turnPath.terminate(lSeg.leavePoint());
        LOGD(LOG_TAG "::getFishTailTurnPath", "%s", Svg::to_path_d(turnPath).c_str());
        
        turnPath.validate();
        return turnPath;
    }
    
    /**
     フックターンパス
     
     指定の線分間を結ぶターンパスを返す。
     各線分は接続されている必要はないがターンの端点は指定の線分の端点を返す。
     - 指定セグメントの初期状態でターンサークル間接線が得られない場合、進入セグメントを接線を延長して接線を探索する。
       セグメントを短縮する方向では探索しない。

     @param[in] eTS 進入セグメント
     @param[in] iTS 中間セグメント
     @param[in] eTS 脱出セグメント
     */
    TurnPath PathAssembler::getHookTurnPath(const LineSegment& eTS, const LineSegment& iTS, const LineSegment& lTS) const {
        // TODO: バック不可作業機用。実装未完了。
        LOGV(LOG_TAG "::getHookTurnPath", "(3) AUTO SELECT TURN SHAPE depends length of inter tangent segment."
             "\n<path fill=\"none\" stroke=\"black\" d=\"\n%s\n%s\n%s\n\"/>",
             Svg::to_path_d(eTS).c_str(), Svg::to_path_d(iTS).c_str(), Svg::to_path_d(lTS).c_str());
        
        TurnPath turnPath;
        // 直線上にある場合
        if (isLineAhead(eTS, lTS)) {
            LOGD(LOG_TAG "::getHookTurnPath", "[ERROR] COLLINEAR");
            turnPath.pushTurnPath(eTS.enterPoint());
            turnPath.pushTurnPath(iTS.enterPoint());
            turnPath.pushTurnPath(lTS.enterPoint());
            return turnPath;
        }
        // 90度以上曲がること
        if (!isAcute(eTS, lTS)) {
            LOGD(LOG_TAG "::getHookTurnPath", "[ERROR] NOT ACUTE ANGLE");
            return turnPath;
        }
        // クランクしないこと
        if (turnDirection(eTS, iTS) != turnDirection(iTS, lTS)) {
            LOGD(LOG_TAG "::getHookTurnPath", "[ERROR] CLANK");
            return turnPath;
        }
        
        const int cornerOrient = getCornerOrient(eTS, iTS);
        const double radius = gauge.turnRadius;
        // ターンサークルベース
        auto C1 = getLeaveTurnCircle(eTS, radius, cornerOrient);
        auto C2 = getEnterTurnCircle(lTS, radius, cornerOrient);
        double distance = lTS.distance(C1.center);  // 直線との距離
        double diff = 0.0;//(radius * 2.0) - distance;
        double step = 0.2;
        double limit = (radius * 2.5) + step;
        LineSegment eSeg{eTS};
        PathSegment iTC;
        LineSegment lSeg{lTS};
        // 初期長さ調整
        if (!isAcute(eSeg, iTS)) {
            // 進入側を伸ばして揃える
            if (!justifyTail(lSeg, eSeg)) {
                LOGD(LOG_TAG "::getHookTurnPath", "[ERROR] ");
                return turnPath;
            }
        }
        
        // C1中心と脱出直線の距離でターン形状が決まる
        if (isIsometric(radius, distance, TOL_MICRO)) {
            LOGD(LOG_TAG "::getHookTurnPath", "[INFO] U TURN");
            // U TURN
            auto eSeg = getTangent(eTS.enterPoint(), C1);
            auto lSeg = getTangent(C1, lTS.leavePoint());
        } else if (radius < distance) {
            LOGD(LOG_TAG "::getHookTurnPath", "[INFO] FLAT TURN");
            // FLAT TURN
            C2 = getEnterTurnCircle(lTS, radius, cornerOrient);
            auto eSeg = getTangent(eTS.enterPoint(), C1);
            auto iPath = getForwardTangentAndCurve(eSeg, C1, C2);
            auto lSeg = getTangent(C2, lTS.leavePoint());
            turnPath.pushTurnPath(eSeg.enterPoint());
            turnPath.pushTurnPath(eSeg.leavePoint(), C1);
            turnPath.pushTurnPath(iPath);
            turnPath.pushTurnPath(lTS.enterPoint());
            turnPath.pushTurnPath(lTS.leavePoint());
        } else {
            LOGD(LOG_TAG "::getHookTurnPath", "[INFO] HOOK TURN");
            C2 = getEnterTurnCircle(lTS, radius, -cornerOrient);
            // 探索
            {
                for (double extLen = diff; extLen < limit; extLen += step) {
                    eSeg = eTS;
                    eSeg.extendTail(extLen);
                    C1 = getLeaveTurnCircle(eSeg, radius, cornerOrient);
                    iTC = getTangent(eSeg, C1, C2);
                    if (iTC.isValid()) {
                        LOGD(LOG_TAG "::getHookTurnPath", "[INFO] extend %gm", extLen);
                        break;
                    }
                }
            }
            
            if (!iTC.isValid()) {
                // 有効な接線が得られない
                LOGD(LOG_TAG "::getHookTurnPath", "[ERROR] TANGENT UNAVAILABLE");
                LOGD(LOG_TAG "::getHookTurnPath",
                     "\n<g fill=\"none\" stroke=\"black\" stroke-width=\"0.1\">\n"
                     "<path d=\"%s\"/>\n"
                     "<circle cx=\"%g\" cy=\"%g\" r=\"%g\" stroke=\"red\"/>\n"
                     "<path d=\"%s\"/>\n"
                     "<circle cx=\"%g\" cy=\"%g\" r=\"%g\" stroke=\"red\"/>\n"
                     "<path d=\"%s\"/>\n"
                     "</g>",
                     Svg::to_path_d(eTS).c_str(),
                     C1.center.x, -C1.center.y, C1.radius,
                     Svg::to_path_d(iTC).c_str(),
                     C2.center.x, -C2.center.y, C2.radius,
                     Svg::to_path_d(lSeg).c_str());
                return turnPath;
            }
            
            // HOOK TURN
            LOGD(LOG_TAG "::getHookTurnPath",
                 "\n<g fill=\"none\" stroke=\"black\" stroke-width=\"0.1\">\n"
                 "<path d=\"%s\"/>\n"
                 "<circle cx=\"%g\" cy=\"%g\" r=\"%g\" stroke=\"red\"/>\n"
                 "<path d=\"%s\"/>\n"
                 "<circle cx=\"%g\" cy=\"%g\" r=\"%g\" stroke=\"red\"/>\n"
                 "<path d=\"%s\"/>\n"
                 "</g>",
                 Svg::to_path_d(eTS).c_str(),
                 C1.center.x, -C1.center.y, C1.radius,
                 Svg::to_path_d(iTC).c_str(),
                 C2.center.x, -C2.center.y, C2.radius,
                 Svg::to_path_d(lSeg).c_str());
            turnPath.pushTurnPath(eSeg.enterPoint());
            turnPath.pushTurnPath(eSeg.leavePoint(), C1);
            turnPath.pushTurnPath(iTC.enterPoint());
            turnPath.pushTurnPath(iTC.leavePoint(), C2);
            turnPath.pushTurnPath(lSeg.enterPoint());
            turnPath.pushTurnPath(lSeg.leavePoint());
        }
        
        turnPath.completeSegment();
        turnPath.terminate();
        turnPath.validate();
        return turnPath;
    }

    /**
     耕跡交差用延長長取得

     コーナーに侵入しようとする二つの交差する作業パスセグメントに対し、ウィスカーを構成するために必要な延長量を返す。
     - 交差しない場合どちらも0.0のペアを返す。
     - 耕跡がコーナーの内側にオフセットしている場合、長さの差分は負になる。
     @param[in] eseg 進入作業パスセグメント
     @param[in] lseg 脱出作業パスセグメント
     @return  延長量のペア
     */
    std::pair<double, double> PathAssembler::getWtCrossLengths(const LineSegment& eseg, const LineSegment& lseg) const
    {
        if (isParallel(eseg, lseg)) {
            // 平行では算出できない
            return {0.0, 0.0};
        }

        const double wpInterval = gauge.workPath.interval;
        const double offsetDir = offsetSign(-gauge.implement.cultivationWidthOffset);
        const double wtOffset = std::abs(gauge.implement.cultivationWidthOffset);
        const int cornerOrient = getCornerOrient(eseg, lseg);
        const int outsideDir =  -cornerOrient;
        // シフト量(符号付き)
        const double eSegOffset0 = offsetDir * wtOffset;
        // -　一つ外側のパスはoffsetDirと逆の符号の場合がある。なぜならば「外側」のパスだから。
        const double eSegOffset1 = eSegOffset0 + outsideDir * wpInterval;

        // 脚の交点
        // - 進入側耕跡: 作業幅オフセット方向
        auto eWtSeg0 = getCollateralSegment(eseg, eSegOffset0);
        // - 次周進入側耕跡: ターン方向に対する一つ外側(凹角もあるので圃場の外周向きではないことに注意)
        auto eWtSeg1 = getCollateralSegment(eseg, eSegOffset1);
        // - 脱出側耕跡: 作業幅オフセット方向
        auto lWtSeg = getCollateralSegment(lseg, offsetDir * wtOffset);
        // - 進入側起点
        const auto eP0 = eWtSeg0.leavePoint();
        // - 進入側交点(ウィスカー先端)
        const auto ePx = getCrossPoint(eWtSeg0, lWtSeg);
        // - 脱出側起点
        const auto lP0 = lWtSeg.enterPoint();
        // - 脱出側交点(ウィスカー先端)
        const auto lPx = getCrossPoint(eWtSeg1, lWtSeg);
        // 延長量
        // - 前(進入側)
        double ed = eP0.distance(ePx);
        {
            // 延長長さの符号設定
            const Vector2D esVec = eWtSeg0.getLeaveVector();
            const Vector2D edVec{eP0, ePx};
            const double dp = esVec.getDotProduct(edVec);
            ed = std::copysign(ed, dp);
        }
        // - 後(脱出側)
        double ld = lP0.distance(lPx);
        {
            // 延長長さの符号設定
            const Vector2D lsVec = lWtSeg.getEnterVector();
            const Vector2D ldVec{lPx, lP0};
            const double dp = lsVec.getDotProduct(ldVec);
            ld = std::copysign(ld, dp);
        }

        LOGD(LOG_TAG "::getWtCrossLengths", "\n  eTS: %s\n  lTS: %s\n eWt0: %s\n eWt1: %s\n lWt : %s\n  eP0: %s\n  ePx: %s\n  lP0: %s\n  lPx: %s\n edld: %0.7g, %07g (m)",
             Svg::to_path_d(eseg).c_str(),
             Svg::to_path_d(lseg).c_str(),
             Svg::to_path_d(eWtSeg0).c_str(),
             Svg::to_path_d(eWtSeg1).c_str(),
             Svg::to_path_d(lWtSeg).c_str(),
             Svg::to_point(eP0).c_str(),
             Svg::to_point(ePx).c_str(),
             Svg::to_point(lP0).c_str(),
             Svg::to_point(lPx).c_str(),
             ed, ld
             );
        
        return {ed, ld};
    }

    /**
     ウィスカー生成(プレーンターン用))
     
     前後パス脚を取り、それぞれのウィスカーパスを生成して返す。
     - ウィスカー長はクロスウィスカー長を上限とし、かつ指定境界とのクリアランスが確保できる長さに制限する。
     - 与えるパス脚はそれぞれ正しく基本パス脚、即ち作業パス端点からカーブの接点まである必要がある。
     - ウィスカー長限界にどの圃場境界を使うか指定できる whiskerMode.targetFlg
     - first セグメント構成
        -# LINE 前進セグメント(パス脚)
        -# LINE 後退セグメント(OPEN)
     - second セグメント構成
        -# LINE 前進セグメント(元のパス脚。バック前準備前進)
        -# LINE 後退セグメント
        -# LINE 前進パス脚(OPEN)
     
     @param[in] eLeg 前パス脚
     @param[in] iLeg 後パス脚
     @param[in,out] whiskerMode  ウィスカーモード参照
     @return ウィスカーのペア
     */
    std::pair<TurnPath, TurnPath> PathAssemblerIf::getWhiskers(const LineSegment& eLeg, const LineSegment& lLeg, const WhiskerMode_t& whiskerMode) const
    {
        LOGV("::getWhiskers", "()");
        std::pair<TurnPath, TurnPath> whiskers;
        BoundaryType::Kind::Set targetFlag = whiskerMode.bndFlag;
        // パス脚からの延長量
        auto lengths = getWtCrossLengths(eLeg, lLeg);
        // 補正値を加える
        lengths.first += whiskerMode.adjustLength.forward;
        lengths.second += whiskerMode.adjustLength.backward;
        // - 前(進入側)
        double ed = lengths.first;
        // - 後(脱出側)
        double ld = lengths.second;
        LOGD("::getWhiskers", "[WHISKER] targetBnd: 0x%02lx; length %.07g : %.07g", whiskerMode.bndFlag.to_ulong(), lengths.first, lengths.second);
        {   // 前進ウィスカー
            auto& path = whiskers.first;
            // 最長探索
            const double limit = ed + gauge.minSpsLegLength;
            const double step = -0.2;
            auto eseg = seekExtendTailMax(eLeg, step, limit, targetFlag);
            LineSegment crus{eseg.getVector(), eseg.leavePoint(), gauge.minSpsLegLength};
            // 作業パス脱出点
            const XY_Point ep0 = crus.enterPoint();
            // 作業パス脚脱出点(ここからバック)
            const XY_Point ep1 = eseg.leavePoint();
            
            path.pushTurnPath(ep0);
            path.pushTurnPath(ep1, SegmentDir::REVERSE);
        }

        {   // 後退ウィスカー
            auto& path = whiskers.second;
            double const preBackLength = gauge.turn.plain.backwardWhisker.preBackLength;
            
            // 最長探索
            const double limit = ld + gauge.turn.plain.leaveLeg;
            const double step = -0.2;
            const auto fwSeg = getFromHead(lLeg, preBackLength);
            auto bwSeg = seekExtendHeadMax(lLeg, step, limit, targetFlag);  // 注: ReverseSegmentではない。
            // 元のパス脚始点(カーブ終点)
            const XY_Point& lp0 = lLeg.enterPoint();
            // ウィスカー根本(バック始点)
            const XY_Point& lp1 = fwSeg.leavePoint();
            // ウィスカー先端(バック終点)
            auto lSeg = getFromHead(bwSeg, gauge.turn.plain.leaveLeg);

            path.pushTurnPath(lp0);
            path.pushTurnPath(lp1, SegmentDir::REVERSE);
            path.pushTurnPath(PathSegment{lSeg});
        }
        
        return whiskers;
    }

    /**
     フォーワードウィスカー用パス脚セグメント取得
     現在のパス脚(lleg)に対し、作業パスを指定長(extLength)を上限として延長するパス脚セグメントを返す。
     - 現パス脚は有効なパス脚、つまり作業パス脱出点とカーブ入口を結ぶセグメントである必要がある。
     - 作業パス延長量が現パス脚内で吸収できる場合は終点は変化しない。
     - 作業パス延長量が現パス脚内で吸収できない場合は終点が前方へ移動し、カーブ入口までバックする必要がある。
     - 結果は最小パス脚を保証する。
     - BPクリアランスが足りない場合、延長量を減らして試行し、有効な最大長で返す。
     - 現パス脚長が最小に不足している場合、パス脚終点は作業パス進入点を超える。
     @param[in] eleg        現パス脚
     @param[in] extLength   作業パス延長量。正負とも可能。
     @return パス脚セグメント
     */
    LineSegment PathAssemblerIf::getForwardWhiskerLegFb(const LineSegment& eleg, double extLength) const {
        return getForwardWhiskerLegB(eleg, extLength, 0.0);
    }

    /**
     フォーワードウィスカー用パス脚セグメント取得
     現在のパス脚(lleg)に対し、作業パスを指定長(extLength)を上限として延長するパス脚セグメントを返す。
        -
     - 現パス脚は有効なパス脚、つまり作業パス脱出点とカーブ入口を結ぶセグメントである必要がある。
     - 作業パス延長量が現パス脚内で吸収できる場合は終点は変化しない。
     - 作業パス延長量が現パス脚内で吸収できない場合は終点が前方へ移動し、カーブ入口までバックする必要がある。
     - 結果は最小パス脚を保証する。
     - BPクリアランスが足りない場合、延長量を減らして試行し、有効な最大長で返す。
     - 現パス脚長が最小に不足している場合、パス脚終点は作業パス進入点を超える。
     @param[in] eleg        現パス脚
     @param[in] extLength   作業パス延長量。正負とも可能。
     @return パス脚セグメント
     */
    LineSegment PathAssemblerIf::getForwardWhiskerLegB(const LineSegment& leg, double extLength, double preBackLength) const {
        LineSegment retLeg = leg;
        const double minLegLen = gauge.minFpsLegLength;
        
        // コーナー(進入脱出交点)から最小必要パス脚を立てる
        // - 標準パス脚長と始点距離とカーブ脱出点距離の差が正であれば一旦バックする必要がある
        // コーナーまでの進入接線長
        const double etsLen = leg.length();
        // バック前準備前進込みの進入接線長
        const double etsTotalLen = etsLen + preBackLength;
        // 必要作業パス脚先端距離(コーナーから先端までの距離)
        const double eltLen = minLegLen + extLength;
        // 必要進入接線長(バック前準備前進含む)
        const double reqLength = std::max(etsTotalLen, eltLen);
        // パス脚生成
        // - バック前準備前進先端まで
        retLeg = getFromHead(leg, reqLength);
        // 進入点移動
        // - 延長量が負の場合はパス脚進入側は伸びる
        retLeg.extendHead(-extLength);
        
        return retLeg;
    }

    /**
     αターンバックワードウィスカー用パス脚セグメント取得
     現在の脱出パス脚(lleg)に対し、作業パスを指定長(extLength)延長する場合のパス脚セグメントを返す。
     - llegは調整前の有効な作業パス脚、つまりバックカーブ終点と作業パス進入点を結ぶセグメントである必要がある。
     - 結果のセグメントの始点はleg始点をlegの延長方向に最小postBackLengthの長さ分移動したものである。短縮方向に移動することはない。
     - 結果のセグメントの終点はlleg終点をどちらの方向にも移動する可能性がある。
     - 結果のセグメントの最小長は(最小パス脚長 + postBackLength)である。
     - 適応延長フラグがtrueのとき、BPクリアランスが足りなければ延長量を減らして試行し、有効な最大長で返す。
     - ただし、延長量を負にはしない。
     - 現パス脚長が最小に不足している場合、パス脚終点は作業パス進入点を超える場合がある。
     @param[in] lleg            現パス脚
     @param[in] extLength       作業パス延長量。正負とも可能。
     @param[in] postBackLength  バックカーブ後の車体軸アライン用準備直進長
     @param[in] adaptive        適応延長フラグ
     @return パス脚セグメント
     */
    LineSegment PathAssemblerIf::getBackWhiskerLeg(const LineSegment& leg, double extLength, double postBackLength) const {
        LineSegment retLeg = leg;
        const double minLegLen = gauge.turn.alpha.leaveLeg;

        // 作業パス脱出点に標準パス脚を立てると考える
        // コーナーまでの進入接線長
        const double etsLen = leg.length();
        // バック前準備前進込みの進入接線長
        const double etsTotalLen = etsLen + postBackLength;
        // 必要作業パス脚先端距離(コーナーから先端までの距離)
        const double eltLen = minLegLen + extLength;
        // 必要進入接線長(バック前準備前進含む)
        const double reqLength = std::max(etsTotalLen, eltLen);
        // パス脚生成
        // - バック前準備前進先端まで
        retLeg = getFromTail(leg, reqLength);
        // 進入点移動
        // - 延長量が負の場合はパス脚進入側は伸びる
        retLeg.extendTail(-extLength);
        return retLeg;
    }

    /**
     前進ヒゲ作成
     */
    TurnPath PathAssembler::getWhiskerForward(const LineSegment& lseg, double length) const
    {
        TurnPath turnPath;
        
        // 予備直進は付けない
        auto seg1 = seekExtendTailMax(lseg, gauge.workPath.leg.step, length);
        LineSegment seg2 = ReverseSegment{seg1.leavePoint(), lseg.leavePoint()};
        
        turnPath.pushTurnPath(PathSegment{seg1});
        turnPath.pushTurnPath(PathSegment{seg2});

        return turnPath;
    }

    /**
     後退ヒゲ作成
     ターンパスを返す。
     - セグメント構成
         - LINE (後退前準備直進)
         - LINE (後退)
         - LINE (OPEN)
     
     */
    TurnPath PathAssembler::getWhiskerBackward(const LineSegment& lseg, double length) const
    {
        TurnPath turnPath;

        // 出口側セグメント
        // - 始点側を伸ばす
        auto seg3 = seekExtendHeadMax(lseg, -gauge.workPath.leg.step, length);
        // バック部分
        ReverseSegment seg2{lseg.enterPoint(), seg3.enterPoint()};
        seg2.extendHead(gauge.workPath.leg.rear.preBackLength);
        // バック前予備前進
        LineSegment seg1{lseg.enterPoint(), seg2.enterPoint()};

        turnPath.pushTurnPath(PathSegment{seg1});
        turnPath.pushTurnPath(PathSegment{seg2});
        turnPath.pushTurnPath(PathSegment{seg3});

        return turnPath;
    }
    
    /**
     最小開始ナビゲーションパスを得る
     
     指定SPSに対する、最小開始ナビゲーションパスを得る
     @param[in] sps     ナビゲーションパスを生成するSPS
     @param[in] length  パス延長量
     @return 最小開始ナビゲーションパス
     @see getMinimalEnterPath(LineSegment leg, double length, bool fold)
     */
    TurnPath PathAssemblerIf::getMinimalEnterPath(PathSPS sps, double length) const {
        LOGV(LOG_TAG "::getMinimalEnterPath", "(SPS)");
        PathGenerator::TurnPath turnPath;
        
        sps.setHeadLeg(gauge.minSpsLegLength);
        auto leg = sps.getHeadLeg();

        return getMinimalEnterPath(leg, length);
    }

    /**
     最小開始ナビゲーションパス
     指定パス脚に対応する最小開始ナビゲーションパスを得る。
     - 指定のパス脚は正しくパス脚セグメントである必要がある。内部では延長のみ行う。
     - セグメント構成
         -# LINE    fpsパス脚
         -# LINE    終了点(OPEN/TERMINATED)
     @param[in] leg              パス脚
     @param[in] length       延長セグメント長
     @return 最小開始ナビゲーションパス
     */
    TurnPath PathAssemblerIf::getMinimalEnterPath(LineSegment leg, double length) const {
        LOGV(LOG_TAG "::getMinimalEnterPath", "(leg)");
        PathGenerator::TurnPath turnPath;
        
        leg.extendHead(length);
        turnPath.emplace_back(leg);
        turnPath.terminate(leg.point2());
        turnPath.setTurnType(TurnType::STARTNAV_MIN);
        turnPath.validate();
        
        return turnPath;
    }
    
    /**
     最小終了ナビゲーションパス取得
     指定のFPSパスから脱出する、最小終了ナビゲーションパスを得る。
     @param[in] fps     ナビゲーションパスを生成するFPS
     @param[in] length  延長セグメント長
     @param[in] fold    延長分を折り返すかどうか
         @arg    true    折り返す
         @arg    fold    折り返さない
     @return 最小終了ナビゲーションパス
     @see getMinimalLeavePath(LineSegment leg, double length, bool fold)
     */
    TurnPath PathAssembler::getMinimalLeavePath(PathFPS fps, double length, bool fold) const {
        fps.setHeadLeg(fps.leg.minLength);
        const auto leg = fps.getHeadLeg();
        return getMinimalLeavePath(leg, length, fold);
    }

   /**
    最小終了ナビゲーションパス取得
    指定パス脚に対応する最小終了ナビゲーションパスを得る。
    - 指定のパス脚は正しくパス脚セグメントである必要がある。内部では延長のみ行う。
    - fold指定でバックにより延長する。内部で折り返しの要否について判定はしない。
    - セグメント構成1(折り返し無し)
        -# LINE    fpsパス脚
        -# LINE    終了点(OPEN/TERMINATED)
    - セグメント構成2(折り返しあり)
        -# LINE    パス脚
        -# LINE (REVERSE) 延長セグメント
        -# LINE    終了点(OPEN/TERMINATED)
    @param[in] leg              パス脚
    @param[in] length       延長セグメント長
    @param[in] fold           延長分を折り返すかどうか
        @arg    true    折り返す
        @arg    fold    折り返さない
    @return 最小終了ナビゲーションパス
    */
    TurnPath PathAssembler::getMinimalLeavePath(LineSegment leg, double length, bool fold) const {
        LOGV(LOG_TAG "::getMinimalLeavePath(FPS)", "");
        PathGenerator::TurnPath turnPath;

        turnPath.setTurnType(TurnType::ENDNAV_MIN);
        if (fold && gauge.implement.canBackward) {
            turnPath.pushTurnPath(PathSegment{leg});
            const auto bwSeg = getReflected(leg, length);
            turnPath.pushTurnPath(bwSeg); // 最小長分バック
            turnPath.modTurnType(Turn::Type::Flag::LEGFOLD);
        } else {
            leg.extendTail(length); // 最小長分延長
            turnPath.pushTurnPath(leg);
        }

        turnPath.terminate();	// 終了点
        turnPath.validate();
        turnPath.applyTurnType();
        return turnPath;
    }

    /**
     最小終了ナビゲーションパス生成
     パス脚長に延長分のセグメントを加える。前進で延長した場合にBPに対するクリアランスが不足するならば延長分は折り返してバックにする。
     @see getMinimalLeavePath(LineSegment, double, bool))
     @param[in] leaveLeg    元にする最小パス脚
     @return 最小終了ナビゲーションパス
     */
    TurnPath PathAssembler::getMinimalLeavePath(const LineSegment& leaveLeg) const {
        LOGV(LOG_TAG "::getMinimalLeavePath(lseg)", "");
//        auto leg = getFromHead(leaveLeg, gauge.minFpsLegLength);
        auto leg = leaveLeg;
        // gauge.clearance.stopBPとは値が同じでも意味が異なる。混同すると変更があった際にバグるであろう。
        leg.extendTail(gauge.termMin.end + gauge.clearance.stopEndMargin);
        const bool fold = (validator.checkBoundaryIntersection(leg, PathPlan::BoundaryType::Kind::FOR_WORKPATH_LEG) != Intersection::NO);
        return getMinimalLeavePath(leaveLeg, gauge.termMin.end, fold);
    }


#pragma mark - Assemble TurnPath
    /**
     ターンパス生成
     
     指定の接線とターンサークルからターンパスを生成して返す。終端点を付加しない。
     
     @param[in] eTS      進入接線
     @param[in] currCirc 目標点
     @param[in] lTS      脱出接線
     
     @return 生成したターンパス
     */
    TurnPath PathAssemblerIf::makeTurnPath(const LineSegment& eTS, const Circle& currCirc, const LineSegment& lTS) const {
        TurnPath turnPath;
        
        turnPath.emplace_back(eTS);
        turnPath.emplace_back(eTS.point2(), currCirc);
        turnPath.pushTurnPath(lTS);
        
        turnPath.validate();
        return turnPath;
    }


#pragma mark - Assemble and Validete TurnPath

    /**
     コーナーターンパス生成
     
     検査済みターンパスを生成して返す。
     -# LINE    接線
     -# ARC     カーブ入口(OPEN)
     
     @param[in] eTS      現ターンサークルに進入する接線
     @param[in] nextCirc 行先ターンサークル
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const LineSegment& eTS, const Circle& nextCirc) const {
        LOGV(LOG_TAG "::getValidatedPath(T,C)", "");
        TurnPath turnPath;
        
        // 接線の交差
        const int tsCollision = checkBoundary(eTS, BoundaryType::Kind::FOR_INTER_CORNER);
        
        // カーブは終点不明なのでまだテストできない
        LOGD(LOG_TAG "::getValidatedPath(T,C)", "Path collides to field boundary:status (eTS) = (0x%x)", tsCollision);
        if (tsCollision == Intersection::NO) {
            turnPath.emplace_back(eTS.point1());
            turnPath.emplace_back(eTS.point2(), nextCirc);
            turnPath.validate();
            PGASSERT(turnPath.size() == 2, ErrorCode::PathGeneration::FATAL);
        }
        
        return turnPath;
    }

    /**
     FPSターンパス生成
     
     FPSからコーナーへの検査済みターンパスを生成して返す。
     -# LINE      FPS脚
     -# ARC       FPS脱出カーブ
     -# LINE      接線
     -# ARC(OPEN) カーブ入口
     
     @see TurnPath PathAssembler::getValidatedPath(const XY_Point& enterPoint, const Circle& currCirc) const
     
     @param[in] fps 脱出しようとするFPS
     @param[in] nextCirc 行先のターンサークル
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const PathFPS& fps, const Circle& nextCirc) const {
        LOGV(LOG_TAG "::getValidatedPath(FPS,C)", "");
        
        TurnPath turnPath;
        turnPath.pushTurnPath(fps.leavePoint());
        turnPath.pushTurnPath(fps.getPoint(), fps.Circ);
        TurnPath tmpPath = getForwardTangentAndCurve(fps.getHeadLeg(), fps.Circ, nextCirc);
        if (!tmpPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedPath(FPS,C)", "no valid tangent.");
            turnPath.invalidate();
            return turnPath;
        }
        turnPath.pushTurnPath(tmpPath);

        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int lTS = Intersection::NO;
            
            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) && (lTS == Intersection::NO));
            }
        } collisions;
        
        const auto eTS = fps.getHeadLeg().extendHead(-TOL_ONE_CM);
        const auto eAS = turnPath.getSegment<ArcSegment>(1);
        const auto lTS = turnPath.getSegment<LineSegment>(2);
        // auto eAS = turnPath.getSegment<ArcSegment>(3);   // 入口なのでまだ検査できない
        
        // 対境界
        collisions.eTS = checkBoundary(eTS, BoundaryType::Kind::FOR_WORKPATH_LEG);
        if (collisions.isValid()) { collisions.eAS = checkBoundary(eAS, BoundaryType::Kind::FOR_DEFAULT); }
        if (collisions.isValid()) { collisions.lTS = checkBoundary(lTS, BoundaryType::Kind::FOR_INTER_CORNER); }
        // 対セグメント
        if (collisions.isValid()) { collisions.lTS += fps.checkIntersection(lTS) << 1; }
        
        LOGD(LOG_TAG "::getValidatedPath(FPS,C)", "Collision to field boundary:status(LEG, eAS, lTS) = (0x%x, 0x%x, 0x%x)", collisions.eTS, collisions.eAS, collisions.lTS);
        if (collisions.isValid()) {
            LOGV(LOG_TAG "::getValidatedPath(FPS,C)", "Valid turn path.");
            turnPath.validate();
            PGASSERT(turnPath.size() == 4, ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
        }

        return turnPath;
    }

    /**
     FPSターンパス生成
     
     FPSから指定のターンサークルへの交差検証済みターンパスを生成して返す。
     -# LINE      FPS脚
     -# ARC       FPS脱出カーブ
     -# LINE      準備直進
     -# LINE      後退接線
     -# ARC(OPEN) コーナーカーブ入口
     
     @param[in] fps      脱出しようとするFPS
     @param[in] nextCirc 行先のターンサークル
     @param[in] tailLen  準備直進長
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const PathFPS& fps, const Circle& nextCirc, double tailLen) const {
        LOGV(LOG_TAG "::getValidatedPath(FPS,C,tailLen)", "");
        
        TurnPath turnPath;
        turnPath.emplace_back(fps.getHeadLeg());
        turnPath.emplace_back(fps.getPoint(), fps.Circ);
        TurnPath&& tmpPath = getReverseTangentAndCurve(fps.getHeadLeg(), fps.Circ, nextCirc, tailLen);
        turnPath.pushTurnPath(tmpPath);
        
        PGASSERT(turnPath.size() == 5, ErrorCode::PathGeneration::FATAL);
        
        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int rTS = Intersection::NO;

            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) && (rTS == Intersection::NO));
            }
        } collisions;
        
        auto eTS = turnPath.getSegment<LineSegment>(0);
        eTS.extendHead(-TOL_ONE_CM);
        const auto eAS = turnPath.getSegment<ArcSegment>(1);
//      const auto lTS = turnPath.getSegment<LineSegment>(2);   // 準備直進なのでまだ検査不要
        const auto rTS = turnPath.getSegment<LineSegment>(3);
//      const auto lAS = turnPath.getSegment<ArcSegment>(4);    // 入口だけなのでまだ検査できない
        
        PGASSERT(rTS.direction == TangentDir::REVERSE, ErrorCode::PathGeneration::FATAL);
        
        // 対境界
        collisions.eTS = checkBoundary(eTS, BoundaryType::Kind::FOR_WORKPATH_LEG);
        collisions.eAS = checkBoundary(eAS, BoundaryType::Kind::FOR_FISHTAIL);
        collisions.rTS = checkBoundary(rTS, BoundaryType::Kind::FOR_FISHTAIL);
        
        if (collisions.isValid()) {
            // 対セグメント
            collisions.eTS += fps.checkIntersection(rTS) << 1;
        }
        
        LOGD(LOG_TAG "::getValidatedPath(FPS,C,tailLen)", "Collision to field boundary:status(eTS, eAS, rTS) = (0x%x, 0x%x, 0x%x)", collisions.eTS, collisions.eAS, collisions.rTS);
        if (collisions.isValid()) {
            LOGV(LOG_TAG "::getValidatedPath(FPS,C,tailLen)", "Valid turn path.");
            turnPath.validate();
            PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.size() == 5, ErrorCode::PathGeneration::FATAL);
        }

        return turnPath;
    }

    /**
     コーナーターンパス生成
     
     指定のターンサークルと接線群から元サークルの円弧を確定し、 サークル間接線 + 行先カーブ(入口) のターンパスを生成して返す。
     -# LINE      接線
     -# ARC(OPEN) カーブ入口
     
     @param[in] eTS      現ターンサークルに進入する接線
     @param[in] currCirc 現ターンサークル
     @param[in] lTS      行先ターンサークルに渡る接線
     @param[in] nextCirc 行先ターンサークル
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const LineSegment& eTS, const Circle& currCirc, const LineSegment& lTS, const Circle& nextCirc) const {
        LOGV(LOG_TAG "::getValidatedPath(T,C,T,C)", "");
        TurnPath turnPath;
        turnPath.emplace_back(lTS.point1());
        turnPath.emplace_back(lTS.point2(), nextCirc);
        PGASSERT(turnPath.size() == 2, ErrorCode::PathGeneration::FATAL);

        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int lTS = Intersection::NO;
            
            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) && (lTS == Intersection::NO));
            }
        } collisions;
        
        // カーブの交差
        ArcSegment eAS(eTS.point2(), lTS.point1(), currCirc);
        collisions.eAS = checkBoundary(eAS, BoundaryType::Kind::FOR_DEFAULT);
        // 接線の交差
        collisions.lTS = checkBoundary(lTS, BoundaryType::Kind::FOR_INTER_CORNER);

        if (collisions.isValid()) {
            // 接線同士の交差
            collisions.eTS += eTS.checkIntersection(lTS) << 1;
        }

        // カーブのセグメント
        LOGD(LOG_TAG "::getValidatedPath(T,C,T,C)", "Path collides to field boundary:status (eTS, Arc, lTS) = (0x%x, 0x%x, 0x%x)", collisions.eTS, collisions.eAS, collisions.lTS);
        if (collisions.isValid()) {
            turnPath.validate();
        }

        return turnPath;
    }

    /**
     SPS ターンパス生成(開始ナビゲーション始端)
     
     指定点からSPSへの接線を求め、検査済みターンパスを生成して返す。
     -# LINE    接線
     -# ARC     カーブ
     -# LINE    SPSパス脚入口
     -# LINE    SPS進入点(open/TERM)
     
     @param[in] srcPoint    現ターンサークルに進入する接線
     @param[in] sps         行先SPSターンサークル
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const EndPoint& srcPoint, const PathSPS& sps) const {
        LOGV(LOG_TAG "::getValidatedPath(EP,SPS)", "");
        TurnPath turnPath;

        const XY_Point& enterPoint(srcPoint);
        auto PS = getTangent(enterPoint, sps.Circ, TangentDir::FORWARD);
        if (!PS.isValid()) {
            LOGD(LOG_TAG "::getValidatedPath(EP,SPS)", "[INFO] failed getTangent(): minimal end nav.");
            // 失敗させる(上からリトライする)
            // - 最小ナビゲーションパスを返す(セグメント数が想定と異なるのでvalid()で返さないこと)
            turnPath = getMinimalEnterPath(sps, gauge.termMin.start);
            turnPath.invalidate();
            return turnPath;
        }
        
        if (PS.length() < (gauge.truncateLength.start + gauge.termMin.start)) {
            // 接線が短すぎる
            LOGD(LOG_TAG "::getValidatedPath(EP,SPS)", "[INFO] Too short start nav first line segment: length:%g", PS.length());
            // 失敗させる(上からリトライする)
            // - 最小ナビゲーションパスを返す(セグメント数が想定と異なるのでvalid()で返さないこと)
            turnPath = getMinimalEnterPath(sps, gauge.termMin.start);
            turnPath.invalidate(PathGenerator::FAILURE_TERM_END);
            return turnPath;
        }

        if (sps.checkIntersection(PS) != Intersection::NO) {
            // SPS(足を含む)と交差している
            LOGD(LOG_TAG "::getValidatedPath(EP,SPS)", "[INFO] Tangent was crossed with SPS");
            // 失敗させる(TCフリップは上から行う)
            // - 最小ナビゲーションパスを返す(セグメント数が想定と異なるのでvalid()で返さないこと)
            turnPath = getMinimalEnterPath(sps, gauge.termMin.start);
            turnPath.invalidate();
            return turnPath;
        }

        StartnavStartSegment startSeg{PS};
        if (checkBoundary(startSeg) != Intersection::NO) {
            // HPと交差している
            LOGD(LOG_TAG "::getValidatedPath(EP,SPS)", "[INFO] Tangent was crossed with HP");
            // 失敗させる(TCフリップは上から行う)
            // - 最小ナビゲーションパスを返す(セグメント数が想定と異なるのでvalid()で返さないこと)
            turnPath = getMinimalEnterPath(sps, gauge.termMin.start);
            turnPath.invalidate();
            return turnPath;
        }

        LineSegment& eTS = PS;
        // 開始点からの直線なので短縮
        const double tolLen = gauge.tractor.tailLength + gauge.clearance.BP;
        eTS.extendHead(-tolLen);
        turnPath = getValidatedPath(eTS, sps);
        if (turnPath.isValid()) {
            turnPath.completeSegment(); // completeを忘れない
            auto& beginTS = turnPath[0];
            beginTS.extendHead(-(gauge.truncateLength.start - tolLen));
            PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.size() == 4, ErrorCode::PathGeneration::FATAL);
        }

        return turnPath;
    }

    /**
     コーナーターンパス生成(開始ナビゲーション始端)
     
     指定点からターンサークルへの接線を求め、検査済みターンパスを生成して返す。
     - セグメント構成
         -# LINE    接線
         -# ARC     カーブ入口
     
     @param[in] srcPoint    接線始点
     @param[in] nextCirc    行先ターンサークル
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const EndPoint& srcPoint, const Circle& nextCirc) const {
        LOGV(LOG_TAG "::getValidatedPath(EP,C)", "");
        TurnPath turnPath;

        const XY_Point& enterPoint(srcPoint);
        auto PS = getTangent(enterPoint, nextCirc, TangentDir::FORWARD);
        if (!PS.isValid()) {
            LOGD(LOG_TAG "::getValidatedPath(EP,C)", "failed getTangent(): minimal end nav.");
            // 接線取得失敗
            turnPath.invalidate();
            return turnPath;
        }
        if (PS.length() < (gauge.truncateLength.start + gauge.termMin.start)) {
            LOGD(LOG_TAG "::getValidatedPath(EP,C)", "Too short start nav first line segment: length:%g", PS.length());
            // 接線が短すぎる
            turnPath.invalidate(PathGenerator::FAILURE_TERM_END);
            return turnPath;
        }
        
        StartnavStartSegment startSeg{PS};
        if (checkBoundary(startSeg) != Intersection::NO) {
            // HPと交差している
            LOGD(LOG_TAG "::getValidatedPath(EP,SPS)", "[INFO] Tangent was crossed with HP");
            turnPath.invalidate();
            return turnPath;
        }

        LineSegment eTS = PS;
        const double tolLen = gauge.tractor.tailLength + gauge.clearance.BP;
        eTS.extendHead(-tolLen);
        turnPath = getValidatedPath(eTS, nextCirc);
        if (turnPath.isValid()) {
            turnPath.completeSegment(); // completeを忘れない
            auto& eTS = turnPath[0];
            eTS.extendHead(-(gauge.truncateLength.start - tolLen));
            PGASSERT(turnPath.size() == 2, ErrorCode::PathGeneration::FATAL);
        }

        return turnPath;
    }

    /**
     SPSターンパス生成
     
     手前のコーナーカーブからのSPSターンパスを生成して返す。
     - コンパクションはしない。
     - セグメント構成
        -# LINE 進入接線
        -# ARC  SPS進入カーブ
        -# LINE SPSパス脚
        -# LINE SPS進入点(OPEN)
     - 呼び出し時点では手前のコーナーへの進入セグメント eTS までは確定していること。コーナーからの脱出接線 iTS は SPSに向かっては未検査で良い。
     - 補助ターンサークルが必要になった場合、prevCircをフリップする場合がある。フリップした場合にはprevEtsも更新する。
     
     @note SPSは手前のターンサークル込みで処理をする必要がある。ただし、直前がFPSである場合は対応していない。FPS側で処理すること。
     
     @param[in,out] prevEts 前のターンサークルに進入する接線
     @param[in,out] prevCirc 前のターンサークル
     @param[in] iTS prevCircからSPSターンサークル間接線。SPSに対しては未検査で良い。
     @param[in] sps 行先SPS
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(LineSegment& prevEts, Circle& prevCirc, LineSegment& iTS, const PathSPS& sps) const {
        LOGV(LOG_TAG "::getValidatedPath(T,C,T,SPS)", "");
        TurnPath turnPath;
        
        struct {
            int pTS = Intersection::NO;
            int pAS = Intersection::NO;
            
            bool isValid() const {
                return ((pTS == Intersection::NO) && (pAS == Intersection::NO));
            }
        } collisions;
        
        
        // 進入点
        auto enterPoint = prevEts.point2();
        // 進入接線(SPS脚)
        LineSegment leg = sps.getHeadLeg();
        leg.extendTail(-TOL_ONE_CM);
        
        // SPS+パス脚との交差
        int spsCollision = sps.checkIntersection(iTS);
        if (spsCollision != Intersection::NO) {
            // 足と接線が交差するということはターン方向が正しくない
            // これは補助ターンサークルでは救えない
            LOGD(LOG_TAG "::getValidatedPath(T,C,T,SPS)", "Tangent to SPS intersects SPS (includes leg). %s vs %s", to_string(iTS, "TS").c_str(), to_string(sps.getSegmentWithLeg(), "SPS+LEG").c_str());
            // リトライは呼び出し元から
            turnPath.invalidate();
            return turnPath;
        }
        
        if (tryUnite(prevEts, const_cast<const LineSegment&>(iTS))) {
            LOGD(LOG_TAG "::getValidatedPath(T,C,T,SPS)", "[WARN] negrective corner");
        } else if (flipTurnCircle(prevCirc, prevEts, iTS)) {
            // SPS進入接線とパス脚の交差があれば両接線とターンサークルが更新される
            LOGD(LOG_TAG "::getValidatedPath(T,C,T,SPS)", "[WARN] FLIP corner circle");
        }
        // コーナーパス取得
        auto cornerPath = getValidatedPath(prevEts, prevCirc, iTS);
        
        if (cornerPath.isValid()) {
            const ArcSegment pAS = cornerPath.getSegment<ArcSegment>(0);
            if (collisions.isValid()) { collisions.pTS += sps.checkIntersection(prevEts); }
            if (collisions.isValid()) { collisions.pAS += sps.checkIntersection(pAS);     }
        }
        
        if (!cornerPath.isValid() || !collisions.isValid()) {
            LOGD(LOG_TAG "::getValidatedPath(T,C,T,SPS)", "Invalid sps turn (corner curve:%d; SP curve:%d)", cornerPath.status, collisions.isValid());
            turnPath.invalidate();
        } else {
            // 成功
            LOGD(LOG_TAG "::getValidatedPath(T,C,T,SPS)", "Valid SPS curve.");
            turnPath = getValidatedPath(iTS, sps);
        }
        
        return turnPath;
    }

    /**
     SPSターンパス生成(コンパクト)
     
     指定のターンサークル群と接線群とSPSからフィッシュテールつきのターンパスを生成して返す。
     - セグメント構成
        -# LINE SPS進入接線
        -# ARC  補助カーブ
        -# LINE 準備直進
        -# LINE 後退接線
        -# ARC  SPS進入カーブ
        -# LINE SPSパス脚
        -# LINE SPS進入点(OPEN)
     - 前のコーナーターンサークルと補助ターンサークルが交差していた場合、生成に失敗する。
     - 有効なパスが生成できなければ空のパスを返す
     
     @param[in] prevEts 前のターンサークルに進入する接線
     @param[in] prevCirc 前のターンサークル
     @param[in] iTS prevCircから補助ターンサークル間接線
     @param[in] auxCirc 補助ターンサークル
     @param[in] sps 行先SPS
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const LineSegment& prevEts, const Circle& prevCirc, const LineSegment& iTS, const Circle& auxCirc, const PathSPS& sps) const {
        LOGV(LOG_TAG "::getValidatedPath(T,C,T,C,SPS)", "");
        PGASSERT(prevCirc.isContact(prevEts.point2()), ErrorCode::PathGeneration::FATAL);
        PGASSERT(prevCirc.isContact(iTS.point1()), ErrorCode::PathGeneration::FATAL);

        TurnPath turnPath;
        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int spsPath = Intersection::NO;
            
            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) && (spsPath == Intersection::NO));
            }
        } collisions;
        
        // コーナーカーブ出口から + 接線 + 補助カーブ + 予備直進 + バック接線 + SPSカーブ + SPS脚
        auto spsPath = getValidatedPath(iTS, auxCirc, sps);
        if (!spsPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedPath(T,C,T,C,SPS)", "INVALID: cant't get sps path");;
            turnPath.invalidate();
            return turnPath;
        }

        // 前コーナーの進入接線(prevEts)とカーブ(prevCirc)の検査
        // - 前コーナー脱出接線(iTS)はgetValidatedPath()内で検査されている。
        const auto rTS = spsPath.getSegment<LineSegment>(2);
        const auto lAS = spsPath.getSegment<ArcSegment>(3);
        const auto spsLeg = sps.getSegmentWithLeg();

        ArcSegment prevAS{prevEts.point2(), iTS.point1(), prevCirc};
        // 対境界
        if (collisions.isValid()) { collisions.eTS = checkBoundary(prevEts, BoundaryType::Kind::FOR_INTER_CORNER); }
        if (collisions.isValid()) { collisions.eAS = checkBoundary(prevAS, BoundaryType::Kind::FOR_INTER_CORNER); }
        // 対セグメント
        if (collisions.isValid()) { collisions.eTS += prevEts.checkIntersection(rTS) << 1; }
        if (collisions.isValid()) { collisions.eTS += prevEts.checkIntersection(lAS) << 2; }
        if (collisions.isValid()) { collisions.eTS += prevEts.checkIntersection(spsLeg) << 3; }
        if (collisions.isValid()) { collisions.eAS += prevAS.checkIntersection(rTS) << 1; }
        if (collisions.isValid()) { collisions.eAS += prevAS.checkIntersection(spsLeg) << 3; }

        if (collisions.isValid()) {
            LOGV(LOG_TAG "::getValidatedPath(T,C,T,C,SPS)", "Valid SPS curve (with aux turn circle)");
            turnPath.emplace_back(iTS);
            turnPath.pushTurnPath(spsPath);
            turnPath.terminate();
            turnPath[0].collisionBoundary = BoundaryType::Kind::FOR_INTER_CORNER;
            turnPath[1].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[2].collisionBoundary = BoundaryType::Kind::FOR_IGNORE;
            turnPath[3].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[4].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[5].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
            turnPath.validate();
           
            PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.size() == 7, ErrorCode::PathGeneration::FATAL);
        } else {
            LOGD(LOG_TAG "::getValidatedPath(T,C,T,C,SPS)", "INVALID: (eTS, eAS, spsPath) = (0x%x, 0x%x, 0x%x)", collisions.eTS, collisions.eAS, collisions.spsPath);
            turnPath.invalidate();
        }
        
        return turnPath;
    }

    /**
     コーナーターンパス生成
     
     指定のターンサークルと接線群からカーブの円弧を確定し、カーブ + 脱出接線 のターンパスを生成して返す。
     - 有効なパスが生成できなければ空のパスを返す。
     - パスの交差の検査内容は以下の通り。
         - eTS対lTSの交差
         - lTsと境界の交差
         - currCircカーブの境界との交差
     - セグメント構成
         -# ARC  カーブセグメント
         -# LINE 脱出接線
         -# LINE 終点(OPEN)
     
     @param[in] eTS 現ターンサークルに進入する接線
     @param[in] currCirc 現ターンサークル
     @param[in] lTS 現ターンサークルから脱出する接線
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const LineSegment& eTS, const Circle& currCirc, const LineSegment& lTS) const {
        LOGV(LOG_TAG "::getValidatedPath(T,C,T)", "");
        TurnPath path;
        
        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int lTS = Intersection::NO;
            int eTS_lTS = Intersection::NO;

            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) && (lTS == Intersection::NO) && (eTS_lTS == Intersection::NO));
            }
        } collisions;
        
        struct {
            int enter = 0;
            int leave = 0;

            bool isValid() const {
                return ((enter == Segment2D::Connection::SMOOTH) && (leave == Segment2D::Connection::SMOOTH));
            }
        } connections;
        
        // カーブのセグメント
        ArcSegment AS(eTS.point2(), lTS.point1(), currCirc);
        // カーブの交差
        collisions.eAS = checkBoundary(AS, BoundaryType::Kind::FOR_DEFAULT);
        
        if (!eTS.isNegrective()) {
            // 接線同士の交差
            collisions.eTS_lTS = eTS.checkIntersection(lTS);
            // 進入接線とカーブの接続
            connections.enter = eTS.checkConnection(AS);
        }
        
        if (!lTS.isNegrective()) {
            // 脱出接線の交差
            collisions.lTS = checkBoundary(lTS);
            // カーブ対脱出接線の接続
            connections.leave = AS.checkConnection(lTS);
        }
        
        LOGD(LOG_TAG "::getValidatedPath(T,C,T)", "Path collides to field boundary:status (eTS, Arc, lTS, eTS-lTS) = (0x%x, 0x%x, 0x%x, 0x%x)", collisions.eTS, collisions.eAS, collisions.lTS, collisions.eTS_lTS);
        LOGD(LOG_TAG "::getValidatedPath(T,C,T)", "Path connection status: (eTS-Arc, Arc-lTS) = (0x%x, 0x%x)", connections.enter, connections.leave);
        if (connections.isValid() && collisions.isValid()) {
            path.emplace_back(eTS.point2(), currCirc);
            path.emplace_back(lTS);
            path.terminate();
            path.validate();
        } else {
            LOGD(LOG_TAG "::getValidatedPath(T,C,T)", "FAILED");
        }
        
        return path;
    }

    /**
     コーナーターンパス生成(終了ナビゲーション終端)
     
     終了ナビゲーション終端 の カーブ + 脱出接線 からなるターンパスを生成して返す。
     - 終端を短縮して返す
     - セグメント構成
         -# LINE 脱出接線
         -# LINE 終点(OPEN)
     
     @param[in] eTS         現ターンサークルに進入する接線
     @param[in] currCirc    現ターンサークル
     @param[in] endPoint    現ターンサークルから脱出する接線
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const LineSegment& eTS, const Circle& currCirc, const EndPoint& endPoint) const {
        LOGV(LOG_TAG "::getValidatedPath(T,C,P)", "");
        TurnPath turnPath;
        
        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int lTS = Intersection::NO;
            
            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) && (lTS == Intersection::NO));
            }
        } collisions;
        
        const XY_Point& destPoint{endPoint};
        PathSegment PS = getTangent(eTS, currCirc, destPoint);
        if (!PS.isValid()) {
            LOGV(LOG_TAG "::getValidatedPath(T,C,P)", "no valid tangent.");
            turnPath.invalidate();
            return turnPath;
        }

        if (PS.length() < (gauge.truncateLength.end + TOL_ONE_CM)) {
            LOGV(LOG_TAG "::getValidatedPath(T,C,P)", "Too short end nav end line segment: length:%g", eTS.length());
            turnPath.invalidate();
            return turnPath;
        }
        
        // 脱出接線
        EndnavEndSegment lTS = PS;

        // 接線同士の交差
        if (collisions.isValid() && !eTS.isNegrective()) {
            collisions.eTS += eTS.checkIntersection(lTS) << 1;
            if (!collisions.isValid() && tryUnite(eTS, lTS)) {
                // カーブセグメントの長さを0にする
                LOGD(LOG_TAG "::getValidatedPath(T,C,P)", "[INFO] force connect line segments with ignore curve:\n %s\n %s", to_string(eTS, "eTS").c_str(), to_string(lTS, "lTS").c_str());
                collisions.eTS = Intersection::NO;
            }
        }

        // カーブのセグメント
        ArcSegment eAS(eTS.point2(), lTS.point1(), currCirc);

        // 境界交差検査
        // -カーブの交差
        if (collisions.isValid() && !eAS.isNegrective()) {
            collisions.eAS = checkBoundary(eAS, BoundaryType::Kind::FOR_DEFAULT);
        }
        // -脱出接線の交差
        if (collisions.isValid()) { collisions.lTS = checkBoundary(lTS); };
        
        LOGD(LOG_TAG "::getValidatedPath(T,C,P)", "Path collides to field boundary:status (eTS, eAS, lTS) = (0x%x, 0x%x, 0x%x)", collisions.eTS, collisions.eAS, collisions.lTS);
        if (collisions.isValid()) {
            LineSegment lTS = PS;
            lTS.extendTail(-gauge.truncateLength.end);
            turnPath.pushTurnPath(lTS); // 終点も追加する
            turnPath.validate();
        } else {
            turnPath.invalidate();
        }
        
        return turnPath;
    }

    /**
     SPSターンパス生成
     
     進入接線とSPSから検査済みSPSターンパスを生成して返す。
     - セグメント構成
         -# LINE 進入接線
         -# ARC  SPSカーブ
         -# LINE SPSパス脚
         -# LINE SPS進入点(OPEN/TERMINATED)
     
     @param[in] eTS SPSに進入する接線
     @param[in] sps 行き先SPS
     
     @return 生成したターンパス TurnPath
     */
    TurnPath PathAssembler::getValidatedPath(LineSegment eTS, const PathSPS& sps) const {
        LOGV(LOG_TAG "::getValidatedPath(T,SPS)", "");
        
        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int lTS = Intersection::NO;

            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) && (lTS == Intersection::NO));
            }
        } collisions;
        
        // 接線の交差
        collisions.eTS = checkBoundary(eTS, BoundaryType::Kind::FOR_INTER_CORNER);
        
        const LineSegment leg = sps.getHeadLeg();
        
        // 接線対SPSの交差
        if (collisions.isValid()) {
            collisions.eTS += leg.checkIntersection(eTS) << 1;
            if (!collisions.isValid() && tryUnite(eTS, leg)) {
                // カーブセグメントの長さを0にする
                LOGD(LOG_TAG "::getValidatedPath(T,SPS)", "[INFO] force connect line segments with ignore curve:\n %s\n %s", to_string(eTS, "eTS").c_str(), to_string(sps.getHeadLeg(), "leg").c_str());
                collisions.eTS = Intersection::NO;
            }
        }
        
        // カーブのセグメント
        ArcSegment eAS(eTS.point2(), leg.point1(), sps.Circ);
        if (collisions.isValid()) {
            if (!eAS.isNegrective()) {
                // カーブの交差
                collisions.eTS = checkBoundary(eTS, BoundaryType::Kind::FOR_INTER_CORNER);
                // カーブの交差
                collisions.eAS = checkBoundary(eAS, BoundaryType::Kind::FOR_DEFAULT);
            }
            // SPSパス脚の交差
            LineSegment tmpleg{leg};
            tmpleg.extendTail(-TOL_ONE_CM);
            collisions.lTS = checkBoundary(sps.getSegmentWithLeg(), BoundaryType::Kind::FOR_WORKPATH_LEG);
        }
        
        if (collisions.isValid()) {
            if (!eAS.isNegrective()) {
                collisions.eTS += sps.checkIntersection(eTS) << 1;
            }
        }
        
        TurnPath turnPath;
        LOGD(LOG_TAG "::getValidatedPath(T,SPS)", "Path collides to field boundary:status (eTS, eAS, lTS) = (0x%x, 0x%x, 0x%x)", collisions.eTS, collisions.eAS, collisions.lTS);
        turnPath.emplace_back(eTS);
        turnPath.emplace_back(eAS);
        turnPath.pushTurnPath(sps.getHeadLeg());
        turnPath.terminate();

        if (collisions.isValid()) {
            turnPath.validate();
            PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.size() == 4, ErrorCode::PathGeneration::FATAL);
        } else {
            turnPath.invalidate();
        }
        
        return turnPath;
    }

    /**
     FPS フィッシュテールターンパス生成
     
     FPSから補助ターンサークルを使用して脱出する検証済みターンパスを生成して返す。
        -# LINE FPS脚
        -# ARC  FPSカーブ
        -# LINE 準備直進
        -# LINE 後退接線
        -# ARC  補助カーブ
        -# LINE 脱出接線始点(OPEN/TERMINAL)
        .
     - FPSに対する脱出接線の角度が90度未満でない場合無効
     - 補助ターンサークル以外を指定すると失敗する場合がある
     
     @see TurnPath PathAssembler::getValidatedPath(const LineSegment& eTS, const Circle& currCirc, const Circle& auxCirc, const Circle& nextCirc) const
     
     @param[in] fps      脱出しようとするFPS
     @param[in] auxCirc  fpsの補助ターンサークル
     @param[in] nextCirc 行先のターンサークル
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const PathFPS& fps, const Circle& auxCirc, const Circle& nextCirc) const {
        LOGV(LOG_TAG "::getValidatedPath(FPS,C,C)", "");
        TurnPath turnPath;
        turnPath.pushTurnPath(fps.leavePoint());
        
        if (!isTangentAvailable(auxCirc, nextCirc)) {
            return turnPath;
        }

        // 脚のチェック
        auto tmpPath = getTangentAndCurve(fps.getHeadLeg(), fps.Circ, auxCirc, nextCirc);
        if (!tmpPath.isValid()) {
            LOGV(LOG_TAG "::getValidatedPath(FPS,C,C)", "INVALID: failed getTangentAndCurve().");
            return turnPath;
        }
        
        turnPath.pushTurnPath(tmpPath);
        
        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int rTS = Intersection::NO;
            int lAS = Intersection::NO;
            int lTS = Intersection::NO;
            
            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) &&
                        (rTS == Intersection::NO) &&
                        (lAS == Intersection::NO) && (lTS == Intersection::NO) );
            }
        } collisions;
        
        auto eTS = turnPath.getSegment<LineSegment>(0);
        eTS.extendHead(-TOL_ONE_CM);
        const auto eAS = turnPath.getSegment<ArcSegment>(1);
        //  const auto iTS = turnPath.getSegment<LineSegment>(2); // 準備直進なので不要
        const auto rTS = turnPath.getSegment<LineSegment>(3);
        const auto lAS = turnPath.getSegment<ArcSegment>(4);    // 入口だけなのでまだ検査できない
        auto lTS = turnPath.getSegment<LineSegment>(5);
        
        // 90度以上曲がらない場合切り返しを許可しない
        if (!fps.isFishtailAvailable(lTS)) {
            LOGD(LOG_TAG "::getValidatedPath(FPS,C,C)", "INVALID: insafficient turn angle.");
            turnPath.invalidate();
            return turnPath;
        }
        
        // 対境界
        if (collisions.isValid()) { collisions.eTS = checkBoundary(eTS, BoundaryType::Kind::FOR_WORKPATH_LEG); }
        if (collisions.isValid()) { collisions.eAS = checkBoundary(eAS, BoundaryType::Kind::FOR_FISHTAIL);     }
        if (collisions.isValid()) { collisions.rTS = checkBoundary(rTS, BoundaryType::Kind::FOR_FISHTAIL);     }
        if (collisions.isValid()) { collisions.lAS = checkBoundary(lAS, BoundaryType::Kind::FOR_FISHTAIL);     }
        if (collisions.isValid()) { collisions.lTS = checkBoundary(lTS, BoundaryType::Kind::FOR_INTER_CORNER); }
        
        // 対セグメント
        if (collisions.isValid()) { collisions.eTS += fps.checkIntersection(rTS) << 1; }
        if (collisions.isValid()) { collisions.eTS += fps.checkIntersection(lAS) << 2; }
        if (collisions.isValid()) { collisions.eTS += fps.checkIntersection(lTS) << 3; }
//        if (collisions.isValid()) { collisions.eAS += eAS.checkIntersection(lTS) << 1; }
        
        LOGD(LOG_TAG "::getValidatedPath(FPS,C,C)", "Collisions status(fpsLS, fpsAS, rTS, lAS, lTS) = (0x%x, 0x%x, 0x%x, 0x%x, 0x%x)",
                                                    collisions.eTS, collisions.eAS, collisions.rTS, collisions.lAS, collisions.lTS);
        if (collisions.isValid()) {
            turnPath[0].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
            turnPath[1].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[2].collisionBoundary = BoundaryType::Kind::FOR_IGNORE;
            turnPath[3].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[4].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[5].collisionBoundary = BoundaryType::Kind::FOR_INTER_CORNER;
            turnPath.validate();
        } else {
            LOGD(LOG_TAG "::getValidatedPath(FPS,C,C)", "INVALID");
            turnPath.invalidate();
        }
        
        if (turnPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedPath(FPS,C,C)", "VALID");
            PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
        }
        return turnPath;
    }

    /**
     FPS フィッシュテールターンパス生成(終了ナビゲーション用)
     
     FPSから終了点まで補助ターンサークルを使用して脱出する検証済みターンパスを生成して返す。
     - セグメント構成
         -# LINE FPS脚
         -# ARC  FPSカーブ
         -# LINE 準備直進
         -# LINE 後退接線
         -# ARC  補助カーブ
         -# LINE 脱出接線
         -# LINE 終了点(OPEN/TERMINAL)
     - FPSに対する脱出接線の角度が90度未満でない場合無効
     - 補助ターンサークル以外を指定すると失敗する場合がある
     @warning 末尾短縮するため、終了ナビゲーション以外の用途で使用してはいけない
     @param[in] fps      脱出しようとするFPS
     @param[in] auxCirc  fpsの補助ターンサークル
     @param[in] endPoint 行先のターンサークル
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const PathFPS& fps, const Circle& auxCirc, const EndPoint& endPoint) const {
        LOGV(LOG_TAG "::getValidatedPath(FPS,C,P)", "");
        TurnPath turnPath;
        turnPath.pushTurnPath(fps.leavePoint());
        
        Circle nextCirc{endPoint, 0.0};
        auto tmpPath = getTangentAndCurve(fps.getHeadLeg(), fps.Circ, auxCirc, nextCirc);
        if (!tmpPath.isValid()) {
            LOGV(LOG_TAG "::getValidatedPath(FPS,C,P)", "INVALID: getTangent.");
            return turnPath;
        }

        turnPath.pushTurnPath(tmpPath);
        
        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int iTS = Intersection::NO;
            int rTS = Intersection::NO;
            int lAS = Intersection::NO;
            int lTS = Intersection::NO;
            
            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) &&
                        (iTS == Intersection::NO) && (rTS == Intersection::NO) &&
                        (lAS == Intersection::NO) && (lTS == Intersection::NO) );
            }
        } collisions;
        
        auto eTS = turnPath.getSegment<LineSegment>(0);
        eTS.extendHead(-TOL_ONE_CM);
        const auto eAS = turnPath.getSegment<ArcSegment>(1);
        const auto iTS = turnPath.getSegment<LineSegment>(2);   // バック前準備直進に含まれるが、終了ナビゲーションは生成後検査に引っかかってもリトライしないので早期検出のため。
        const auto rTS = turnPath.getSegment<LineSegment>(3);
        const auto lAS = turnPath.getSegment<ArcSegment>(4);    // 入口だけなのでまだ検査できない
        EndnavEndSegment lTS = turnPath.getSegment<LineSegment>(5); // EndnavEndSegmentで受けないと正しくチェックされない
        
        // 90度以上曲がらない場合切り返しを許可しない
        if (!fps.isFishtailAvailable(lTS)) {
            LOGD(LOG_TAG "::getValidatedPath(FPS,C,P)", "insafficient turn angle.");
            turnPath.invalidate();
            return turnPath;
        }
        // 末尾短縮可能かどうか
        if (lTS.length() < (gauge.termMin.start + TOL_ONE_CM)) {
            LOGV(LOG_TAG "::getValidatedPath(FPS,C,P)", "insafficient last tangent length.");
            turnPath.invalidate();
            return turnPath;
        }
        
        // 対境界
        if (collisions.isValid()) { collisions.eTS = checkBoundary(eTS, BoundaryType::Kind::FOR_WORKPATH_LEG); }
        if (collisions.isValid()) { collisions.eAS = checkBoundary(eAS, BoundaryType::Kind::FOR_FISHTAIL);     }
        if (collisions.isValid()) { collisions.iTS = checkBoundary(iTS, BoundaryType::Kind::FOR_FISHTAIL);     }
        if (collisions.isValid()) { collisions.rTS = checkBoundary(rTS, BoundaryType::Kind::FOR_FISHTAIL);     }
        if (collisions.isValid()) { collisions.lAS = checkBoundary(lAS, BoundaryType::Kind::FOR_FISHTAIL);     }
        if (collisions.isValid()) { collisions.lTS = checkBoundary(lTS); }  // これは終了ナビゲーション最終接線(EndnavEndSegment)
            
        // 対セグメント
        if (collisions.isValid()) { collisions.eTS += fps.checkIntersection(rTS) << 1; }
        if (collisions.isValid()) { collisions.eTS += fps.checkIntersection(lAS) << 2; }
        if (collisions.isValid()) { collisions.eTS += fps.checkIntersection(lTS) << 3; }
//      if (collisions.isValid()) { collisions.eAS += eAS.checkIntersection(lTS) << 1; }
        
        LOGD(LOG_TAG "::getValidatedPath(FPS,C,P)", "Collisions status(fpsLS, fpsAS, rTS, lAS, lTS) = (0x%x, 0x%x, 0x%x, 0x%x, 0x%x)",
                                                    collisions.eTS, collisions.eAS, collisions.rTS, collisions.lAS, collisions.lTS);
        if (!collisions.isValid()) {
            LOGD(LOG_TAG "::getValidatedPath(FPS,C,C)", "INVALID");
            turnPath.invalidate();
        } else {
            turnPath.validate();
        }
        
        if (turnPath.isValid()) {
            LOGV(LOG_TAG "::getValidatedPath(FPS,C,P)", "VALID");
            // 末尾短縮
            lTS.extendTail(-PathGenerator::END_NAV_TERM);
            turnPath.pop_back();
            turnPath.pop_back();
            turnPath.pushTurnPath(lTS.point1());
            turnPath.terminate(lTS.point2());
            PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.size() == 7, ErrorCode::PathGeneration::FATAL);
        }

        return turnPath;
    }
    
    /**
     FPS - SPS 間ターンパス生成(フィッシュテールのみ)
     
     指定のFPS,SPSからフィッシュテールターンパスを生成して返す。
     - フィッシュテールはそれぞれの補助ターンサークル、またはFPS-SPSターンサークル同士で形成する。
     - セグメント構成
         - 補助ターンサークルが無い場合
             -# LINE FPS脚
             -# ARC  FPSカーブ
             -# LINE 準備直進
             -# LINE 後退接線
             -# ARC  SPSカーブ
             -# LINE 脱出接線始点(OPEN)
         - FPSのみに補助ターンサークルがある場合
             -# LINE FPS脚
             -# ARC  FPSカーブ
             -# LINE 準備直進
             -# LINE 後退接線
             -# ARC  補助カーブ
             -# LINE 中間接線
             -# ARC  SPSカーブ
             -# LINE SPS脚
             -# LINE SPS進入点(OPEN)
         - SPSのみに補助ターンサークルがある場合
             -# LINE FPS脚
             -# ARC  FPSカーブ
             -# LINE 中間接線
             -# ARC  補助カーブ
             -# LINE 準備直進
             -# LINE 後退接線
             -# ARC  SPSカーブ
             -# LINE SPS脚
             -# LINE SPS進入点(OPEN)
         - 両方に補助ターンサークルがある場合
             -# LINE FPS脚
             -# ARC  FPSカーブ
             -# LINE 中間接線
             -# ARC  FPS補助カーブ
             -# LINE 準備直進
             -# LINE 後退接線
             -# ARC  FPS補助カーブ
             -# LINE 準備直進
             -# LINE 後退接線
             -# ARC  SPSカーブ
             -# LINE SPS脚
             -# LINE SPS進入点(OPEN)
     
     @see TurnPath PathAssembler::getValidatedPath(const XY_Point& enterPoint, const Circle& currCirc, const Circle& auxCirc, const Circle& nextCirc) const
     
     @param[in] fps 脱出FPS
     @param[in] sps 行先SPS
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPathReverse(const PathFPS& fps, const PathSPS& sps) const {
        LOGV(LOG_TAG "::getValidatedPathReverse(FPS,SPS)", "");
        TurnPath turnPath;
        
        if (fps.Circ.orient != sps.Circ.orient) {
            LOGD(LOG_TAG "::getValidatedPathReverse(FPS,SPS)", "[INFO] Turn circles collided and has against orient.");
            turnPath.invalidate();
            return turnPath;
        }

        if (!gauge.permitBackward) {
            LOGD(LOG_TAG "::getValidatedPathReverse(FPS,SPS)", "[INFO] failed by inhibit backward.");
            turnPath.invalidate();
            return turnPath;
        }
        
        // ターンパス取得
        turnPath = getTurnPath(fps, sps, gauge.turn.fishtail.preBackLength);
        if (!turnPath.isValid() || turnPath.empty()) {
            LOGD(LOG_TAG "::getValidatedPathReverse(FPS,SPS)", "failed get turnpath");
            return turnPath;
        }

        // 検査
        turnPath.completeSegment();
        PGASSERT(3 <= turnPath.size(), ErrorCode::PathGeneration::FATAL);   // valid()なので満たしているはず
        // FPS脚
        {
            auto fpsLeg = turnPath.getSegment<LineSegment>(0);
            fpsLeg.extendHead(-TOL_ONE_CM);
            if (checkBoundary(fpsLeg, BoundaryType::Kind::FOR_WORKPATH_LEG) != Intersection::NO) {
                LOGD(LOG_TAG "::getValidatedPathReverse(FPS,SPS)", "Collision to field boundary turnPath[0]:%s", to_string(fpsLeg).c_str());
                turnPath.invalidate();
                return turnPath;
            }
        }
        // 中間セグメント
        for (auto it = next(turnPath.cbegin()); it != prev(turnPath.cend(), 2); ++it) {
            // 境界交差検査
            const GenSegment& currSeg = *it;
            if (checkBoundary(currSeg, it->collisionBoundary) != Intersection::NO) {
                LOGD(LOG_TAG "::getValidatedPathReverse(FPS,SPS)", "Collision to field boundary turnPath[%d]:%s", (int)distance(turnPath.cbegin(), it), to_string(currSeg).c_str());
                turnPath.invalidate();
                return turnPath;
            }
        }
        // SPS脚
        {
            auto spsLeg = turnPath.getSegment<LineSegment>((int)turnPath.size() - 2);
            spsLeg.extendTail(-TOL_ONE_CM);
            if (checkBoundary(spsLeg, BoundaryType::Kind::FOR_WORKPATH_LEG) != Intersection::NO) {
                LOGD(LOG_TAG "::getValidatedPathReverse(FPS,SPS)", "Collision to field boundary turnPath[%d]:%s", (int)turnPath.size() - 1, to_string(spsLeg).c_str());
                turnPath.invalidate();
                return turnPath;
            }
        }

        // セグメント交差検査
        int collisions = 0;
        // - FPS/SPS間なので検査対象は大きく限定される。
        if (fps.isAuxTurnCirclePresent() && sps.isAuxTurnCirclePresent()) {
            //　両方はありえないので検査しない
        } else if (fps.isAuxTurnCirclePresent() && !sps.isAuxTurnCirclePresent() ) {
            // FPS側にフィッシュテール
            auto fpsLeg = turnPath.getSegment<LineSegment>(0);
            fpsLeg.point1() = fps.enterPoint();
            // const auto fpsAS  = turnPath.getSegment<ArcSegment>(1);
            // const auto pTS1   = turnPath.getSegment<LineSegment>(2);  // 準備直進は検査不要
            const auto rTS    = turnPath.getSegment<LineSegment>(3);
            const auto aAS    = turnPath.getSegment<ArcSegment>(4);
            const auto iTS    = turnPath.getSegment<LineSegment>(5);
            const auto spsAS  = turnPath.getSegment<ArcSegment>(6);
            auto spsLeg = turnPath.getSegment<LineSegment>(7);
            spsLeg.point2() = sps.leavePoint();
            
            if (collisions == 0) { collisions = fpsLeg.checkIntersection(rTS) << 0; }
            if (collisions == 0) { collisions = rTS.checkIntersection(iTS)    << 1; }
            if (collisions == 0) { collisions = rTS.checkIntersection(spsAS)  << 2; }
            if (collisions == 0) { collisions = rTS.checkIntersection(spsLeg) << 3; }
            if (collisions == 0) { collisions = aAS.checkIntersection(spsAS)  << 4; }
            if (collisions == 0) { collisions = aAS.checkIntersection(spsLeg) << 5; }
            if (collisions == 0) { collisions = iTS.checkIntersection(spsLeg) << 6; }
        } else if (!fps.isAuxTurnCirclePresent() && sps.isAuxTurnCirclePresent()) {
            // SPS側にフィッシュテール
            auto fpsLeg = turnPath.getSegment<LineSegment>(0);
            fpsLeg.point1() = fps.enterPoint();
            const auto fpsAS  = turnPath.getSegment<ArcSegment>(1);
            const auto iTS    = turnPath.getSegment<LineSegment>(2);
            const auto aAS    = turnPath.getSegment<ArcSegment>(3);
            // const auto pTS    = turnPath.getSegment<LineSegment>(4);  // 準備直進は検査不要
            const auto rTS    = turnPath.getSegment<LineSegment>(5);
            // const auto spsAS  = turnPath.getSegment<ArcSegment>(6);
            auto spsLeg = turnPath.getSegment<LineSegment>(7);
            spsLeg.point2() = sps.leavePoint();

            if (collisions == 0) { collisions = fpsLeg.checkIntersection(iTS) << 0;   }
            if (collisions == 0) { collisions = fpsLeg.checkIntersection(aAS) << 1;   }
            if (collisions == 0) { collisions = fpsLeg.checkIntersection(rTS) << 2;   }
            if (collisions == 0) { collisions = fpsAS.checkIntersection(aAS)  << 3;   }
            if (collisions == 0) { collisions = fpsAS.checkIntersection(rTS)  << 4;   }
            if (collisions == 0) { collisions = iTS.checkIntersection(rTS)    << 5;   }
            if (collisions == 0) { collisions = rTS.checkIntersection(spsLeg) << 6;   }
        } else {
            auto fpsLeg = turnPath.getSegment<LineSegment>(0);
            fpsLeg.point1() = fps.enterPoint();
            // const auto fpsAS  = turnPath.getSegment<ArcSegment>(1);
            // const auto pTS   = turnPath.getSegment<LineSegment>(2);  // 準備直進は検査不要
            const auto rTS    = turnPath.getSegment<LineSegment>(3);
            // const auto spsAS  = turnPath.getSegment<ArcSegment>(4);
            auto spsLeg = turnPath.getSegment<LineSegment>(5);
            spsLeg.point2() = sps.leavePoint();

            if (collisions == 0) { collisions = fpsLeg.checkIntersection(rTS) << 0;   }
            if (collisions == 0) { collisions = rTS.checkIntersection(spsLeg) << 1;   }
        }
        
        if (collisions != 0) {
            LOGD(LOG_TAG "::getValidatedPathReverse(FPS,SPS)", "Collision within segements status:0x%x", collisions);
            turnPath.invalidate();
        }

        if (turnPath.isValid()) {
            PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
            // セグメント数は生成でチェック済み
        }
        return turnPath;
    }

    /**
     FPS - SPS 間ターンパス生成
     
     指定のFPS,SPSから交差検証済みターンパスを生成して返す。
     - 前進のみ接線のみを使用し、コンパクションは行わない。バックが必要な場合は失敗する。
     - セグメント
        -# LINE FPS脚
        -# ARC  FPSカーブ
        -# LINE 中間接線
        -# ARC  SPSカーブ
        -# LINE SPS脚
        -# LINE SPS進入点(OPEN)
     
     @param[in] fps 出発作業パス(FPS)
     @param[in] sps 行先作業パス(SPS)
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPathForward(const PathFPS& fps, const PathSPS& sps) const {
        LOGV(LOG_TAG "::getValidatedPathForward(FPS,SPS)", "");
        TurnPath turnPath;
        turnPath.pushTurnPath(fps.leavePoint());
        turnPath.pushTurnPath(fps.getPoint(), fps.Circ);
        
        if ((fps.Circ.checkIntersection(sps.Circ) != Intersection::NO) && (fps.Circ.orient != sps.Circ.orient)) {
            turnPath.invalidate();
            return turnPath;
        }
        
        if (!gauge.permitBackward) {
            turnPath.invalidate();
            return turnPath;
        }
        
        const int tangentDir = getTangentDirection(fps.getPoint(), fps.Circ, sps.Circ);
        if (tangentDir == TangentDir::REVERSE) {
            LOGV(LOG_TAG "::getValidatedPathForward(FPS,SPS)", "tangentDir:%d", tangentDir);
            turnPath.invalidate();
            return turnPath;
        }
        
        struct {
            int fpsLS = Intersection::NO;
            int fpsAS = Intersection::NO;
            int tanLS = Intersection::NO;
            int spsAS = Intersection::NO;
            int spsLS = Intersection::NO;

            bool isValid() const {
                return ((fpsLS == Intersection::NO) && (fpsAS == Intersection::NO) &&
                        (tanLS == Intersection::NO) &&
                        (spsAS == Intersection::NO) && (spsLS == Intersection::NO) );
            }
        } collisions;
        
        auto tmpPath = getForwardTangentAndCurve(fps.getHeadLeg(), fps.Circ, sps.Circ);
        if (!tmpPath.isValid()) {
            LOGV(LOG_TAG "::getValidatedPathForward(FPS,SPS)", "no valid tangent.");
            turnPath.invalidate();
            return turnPath;
        }
        turnPath.pushTurnPath(tmpPath);
        turnPath.pushTurnPath(sps.getHeadLeg());
        turnPath.terminate();
        turnPath.completeSegment();

        auto eTS = turnPath.getSegment<LineSegment>(0);
        auto eAS = turnPath.getSegment<ArcSegment>(1);
        auto iTS = turnPath.getSegment<LineSegment>(2);
        auto lAS = turnPath.getSegment<ArcSegment>(3);
        auto lTS = turnPath.getSegment<LineSegment>(4);
        
        // 対境界
        collisions.fpsLS = checkBoundary(eTS, BoundaryType::Kind::FOR_WORKPATH_LEG);
        collisions.fpsAS = checkBoundary(eAS, BoundaryType::Kind::FOR_DEFAULT);
        collisions.tanLS = checkBoundary(iTS, BoundaryType::Kind::FOR_INTER_CORNER);
        collisions.spsAS = checkBoundary(lAS, BoundaryType::Kind::FOR_DEFAULT);
        collisions.spsLS = checkBoundary(lTS, BoundaryType::Kind::FOR_WORKPATH_LEG);

        if (collisions.isValid()) {
            // 対FPS
            collisions.fpsLS += fps.checkIntersection(lTS) << 1;
            collisions.fpsLS += fps.checkIntersection(lAS) << 2;
            // 対SPS
            collisions.tanLS += sps.checkIntersection(iTS) << 1;
        }
        
        LOGD(LOG_TAG "::getValidatedPathForward(FPS,SPS)", "Collision to field boundary:status(fpsLS, fpsAS, tanTS, spsAS, spsLS) = (%d, %d, %d, %d, %d)",
             collisions.fpsLS, collisions.fpsAS, collisions.tanLS, collisions.spsAS, collisions.spsLS);
        if (collisions.isValid()) {
            LOGV(LOG_TAG "::getValidatedPathForward(FPS,SPS)", "Valid turn path.");
            turnPath.validate();
            PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
            PGASSERT(turnPath.size() == 6, ErrorCode::PathGeneration::FATAL);
        } else {
            turnPath.invalidate();
        }

        return turnPath;
    }
    
    /**
     FPS - 終了点間ターンパス生成(終了ナビゲーション用)
     
     指定のFPSから指定点へ向かう交差検証済みターンパスを生成して返す。
        - コンパクションは行わない
        - セグメント
            -# LINE    FPS脚
            -# ARC     FPSカーブ
            -# LINE    脱出接線
            -# LINE    終点(OPEN/TERM)
     
     @param[in] fps         脱出しようとするFPS
     @param[in] destPoint   目標点
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const PathFPS& fps, const EndPoint& destPoint) const {
        LOGV(LOG_TAG "::getValidatedPath(FPS,P)", "");
        TurnPath turnPath;
        
        // 接線を引いてみる
        const auto&& tmpPath = getTurnPath(fps.getHeadLeg(), fps.Circ, destPoint);
        if (!tmpPath.isValid()) {
            LOGV(LOG_TAG "::getValidatedPath(FPS,P)", "failed getTurnPath()");
            return turnPath;
        }

        turnPath.pushTurnPath(fps.leavePoint());
        turnPath.pushTurnPath(tmpPath);

        auto eTS = turnPath.getSegment<LineSegment>(0);
        const auto& eAS = turnPath.getSegment<ArcSegment>(1);
        EndnavEndSegment lTS = turnPath.getSegment<LineSegment>(2);
        
        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int lTS = Intersection::NO;

            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) && (lTS == Intersection::NO));
            }
        } collisions;

        // 接線で終了
        eTS.extendHead(-TOL_ONE_CM);	// HPコリジョン避け
        // 対境界
        collisions.eTS = checkBoundary(eTS, BoundaryType::Kind::FOR_WORKPATH_LEG);
        if (collisions.isValid()) { collisions.eAS = checkBoundary(eAS); }
        // - 終了点への最終直線
        if (collisions.isValid()) { collisions.lTS = checkBoundary(lTS); }

        // 対セグメント
        if (collisions.isValid()) {
            collisions.eTS += fps.checkIntersection(lTS) << 1;
        }

        LOGV(LOG_TAG "::getValidatedPath(FPS,P)", "Collision to field boundary:status(LEG, eAS, lTS) = (%d, %d, %d)", collisions.eTS, collisions.eAS, collisions.lTS);
        if (collisions.isValid()) {
            if (lTS.length() < (PathGenerator::END_NAV_TERM + gauge.termMin.end)) {
                LOGV(LOG_TAG "::getValidatedPath(FPS,P)", "[INFO] Too short end nav last line segment: length: %0.7g", lTS.length());
                turnPath.clear();
            } else {
                lTS.extendTail(-PathGenerator::END_NAV_TERM);
                turnPath.pop_back();
                turnPath.pop_back();
                turnPath.pushTurnPath(lTS);
                turnPath.terminate();
                turnPath.validate();
                PGASSERT(turnPath.getEnterPoint() == fps.leavePoint(), ErrorCode::PathGeneration::FATAL);
                PGASSERT(turnPath.size() == 4, ErrorCode::PathGeneration::FATAL);
            }
        } else {
            turnPath.invalidate();
        }
        
        return turnPath;
    }

    /**
     SPSフィッシュテールターンパス生成
     
     指定のターンサークルと接線から、カーブ + 準備直進 + 後退接線 + カーブ + 脱出接線(入口) の交差検証済みターンパスを生成して返す。
     -# ARC  補助カーブ
     -# LINE 準備直進
     -# LINE 後退接線
     -# ARC  SPS進入カーブ
     -# LINE SPSパス脚
     -# LINE SPS進入点(OPEN)
     
     - パスが無効な場合は空のパスを返す
     - SPSに対する進入接線の角度が90度未満でない場合無効
     - 補助ターンサークル以外を指定すると失敗する場合がある
     
     @see TurnPath PathAssembler::getValidatedPath(const XY_Point& enterPoint, const Circle& currCirc, const Circle& auxCirc, const Circle& nextCirc) const
     
     @param[in] eTS     auxCircに対する進入接線
     @param[in] auxCirc spsの補助ターンサークル
     @param[in] sps     進入しようとするSPS
     
     @return 生成したターンパス
     */
    TurnPath PathAssembler::getValidatedPath(const LineSegment& eTS, const Circle& auxCirc, const PathSPS& sps) const {
        LOGV(LOG_TAG "::getValidatedPath(T,C,SPS)", "");
        TurnPath turnPath;
        
        // 90度以上曲がらない場合切り返しを許可しない
        LineSegment leg{sps.getHeadLeg()};
        if (!sps.isFishtailAvailable(eTS)) {
            LOGD(LOG_TAG "::getValidatedPath(T,C,SPS)", "INVALID: insafficient turn angle.\n %s\n %s\n DP:%g, CP:%g, orient:%d",
                                                        to_string(eTS, "eTS    :").c_str(), to_string(sps.getSegmentWithLeg(), "SPS+LEG:").c_str(),
                                                        eTS.getDotProduct(sps.getSegmentWithLeg()), eTS.getCrossProduct(sps.getSegmentWithLeg()), sps.Circ.orient);
            turnPath.invalidate();
            return turnPath;
        }
        
        if (eTS.checkIntersection(sps.getSegmentWithLeg()) != Intersection::NO) {
            LOGD(LOG_TAG "::getValidatedPath(T,C,SPS)", "INVALID: eTS crossed on SPS.");
            turnPath.invalidate();
            return turnPath;
        }

        Circle tmpCirc{sps.Circ};
        tmpCirc.radius = 0.0;
        tmpCirc.center = leg.point2();
        turnPath = getTangentAndCurve(eTS, auxCirc, sps.Circ, tmpCirc);
        if (!turnPath.isValid()) {
            LOGD(LOG_TAG "::getValidatedPath(T,C,SPS)", "INVALID: there's no any tangent");
            turnPath.invalidate();
            return turnPath;
        }
        
        // パス終端
        turnPath.pop_back();
        turnPath.terminate(sps.enterPoint());
        PGASSERT(turnPath.getLeavePoint() == sps.enterPoint(), ErrorCode::PathGeneration::FATAL);
        PGASSERT(turnPath.size() == 6, ErrorCode::PathGeneration::FATAL);

        struct {
            int eTS = Intersection::NO;
            int eAS = Intersection::NO;
            int rTS = Intersection::NO;
            int lAS = Intersection::NO;
            int lTS = Intersection::NO;
            
            bool isValid() const {
                return ((eTS == Intersection::NO) && (eAS == Intersection::NO) &&
                        (rTS == Intersection::NO) &&
                        (lAS == Intersection::NO) && (lTS == Intersection::NO) );
            }
        } collisions;
 
        const auto eAS = turnPath.getSegment<ArcSegment>(0);
//      const auto iTS = turnPath.getSegment<LineSegment>(1);
        const auto rTS = turnPath.getSegment<LineSegment>(2);
        const auto lAS = turnPath.getSegment<ArcSegment>(3);
        auto lTS = turnPath.getSegment<LineSegment>(4);
        lTS.extendTail(-TOL_ONE_CM);    // テスト用HPコリジョン避け
        
        
        // 対境界
        if (collisions.isValid()) { collisions.eTS = checkBoundary(eTS, BoundaryType::Kind::FOR_INTER_CORNER);  }
        if (collisions.isValid()) { collisions.eAS = checkBoundary(eAS, BoundaryType::Kind::FOR_FISHTAIL);      }
        if (collisions.isValid()) { collisions.rTS = checkBoundary(rTS, BoundaryType::Kind::FOR_FISHTAIL);      }
        if (collisions.isValid()) { collisions.lAS = checkBoundary(lAS, BoundaryType::Kind::FOR_FISHTAIL);      }
        if (collisions.isValid()) { collisions.lTS = checkBoundary(lTS, BoundaryType::Kind::FOR_WORKPATH_LEG);  }
        
        if (collisions.isValid()) { collisions.eTS += eTS.checkIntersection(rTS) << 1; }
//      if (collisions.isValid()) { collisions.eTS += eTS.checkIntersection(lAS) << 2; }
        if (collisions.isValid()) { collisions.eTS += sps.checkIntersection(eTS) << 3; }
        if (collisions.isValid()) { collisions.eAS += sps.checkIntersection(eAS) << 1; }
        if (collisions.isValid()) { collisions.rTS += sps.checkIntersection(eTS) << 1; }
        
        if (collisions.isValid()) {
            turnPath[0].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[1].collisionBoundary = BoundaryType::Kind::FOR_IGNORE;
            turnPath[2].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[3].collisionBoundary = BoundaryType::Kind::FOR_FISHTAIL;
            turnPath[4].collisionBoundary = BoundaryType::Kind::FOR_WORKPATH_LEG;
            turnPath.validate();
            
            PGASSERT(turnPath.size() == 6, ErrorCode::PathGeneration::FATAL);
        } else {
            LOGD(LOG_TAG "::getValidatedPath(T,C,SPS)", "INVALID: has collision: (eTS, eAS, rTS, lAS, lTS) = (0x%x, 0x%x, 0x%x, 0x%x, 0x%x)",
                                                        collisions.eTS, collisions.eAS, collisions.rTS, collisions.lAS, collisions.lTS);
            turnPath.invalidate();
        }
        
        return turnPath;
    }
    
    
#pragma mark - Assemble and Validete TurnPath

    /**
     境界交差チェック(開始ナビゲーションパス開始接線)
     
     @param[in] startSeg    開始ナビゲーションパス開始セグメント
     @param[in] targetFlag  対象境界指定フラグ
     
     @return 検査結果
     @retval Intersection::NO 交差なし
     @retval その他    交差あり
     */
    int PathAssembler::checkBoundary(StartnavStartSegment startSeg, BoundaryType::Kind::Set targetFlag) const {
        // 先にEHP検査
        int retval = validator.checkBoundaryIntersection(startSeg, PathPlan::BoundaryType::Kind::Mask::HP | PathPlan::BoundaryType::Kind::Mask::EHP);
        if (retval == Intersection::NO) {
            // 後方コリジョン避け
            startSeg.extendHead(-(gauge.tractor.tailLength + gauge.clearance.tolBP));
            retval = validator.checkBoundaryIntersection(startSeg, targetFlag) << 1;
        }
        
        return retval;
    }

    /**
     境界交差チェック(終了ナビゲーション終端接線)
     
     @param[in] endSeg 終了ナビゲーションパス終了セグメント
     @param[in] targetFlag 対象境界指定フラグ
     
     @return 検査結果
     @retval Intersection::NO 交差なし
     @retval その他    交差あり
     */
    int PathAssembler::checkBoundary(EndnavEndSegment endSeg) const {
        // 先にEHP検査
        int retval = validator.checkBoundaryIntersection(endSeg, BoundaryType::Kind::FOR_ENDNAV_END_SEG);
        if (retval == Intersection::NO) {
            // 前方コリジョン避け
            // -
            const double tolLen = gauge.truncateLength.end;
            endSeg.extendTail(-tolLen);
            retval = validator.checkBoundaryIntersection(endSeg, BoundaryType::Kind::Mask::ALL) << 1;
        }
        
        return retval;
    }

    /**
     ラスター進入/退出ターン可能テスト
     パス脚間にターンを生成して良いかどうかを返す。
     - eTSとlTSの間にEHPを跨いでいるかどうかをテストする。実際にターンを生成して踏むかどうかではない。
     @param[in] eTS 進入パス脚
     @param[in] lTS 脱出パス脚
     @retval true   ターン可
     @retval false  ターン不可
     */
    bool PathAssembler::isRasterEnterLeaveAvailable(const LineSegment& eTS, const LineSegment& lTS) const {
        LineSegment iTS{eTS.leavePoint(), lTS.enterPoint()};
        return (validator.checkIntersectionEhp(iTS) == Intersection::NO);
    }

    /**
     線分を境界まで伸長
     @param[in] seg        処理対象LineSegment
     @param[in] targetFlag ターゲット境界フラグ
     @return 処理後セグメント
     */
    LineSegment PathAssembler::extendHeadToBoundary(const LineSegment& seg, BoundaryType::Kind::Set targetFlag) const {
        return seekExtendHeadMax(seg, gauge.headland.whisker.lengthStep, gauge.headland.whisker.lengthLimit, targetFlag);
    }
    
    LineSegment PathAssembler::seekExtendHeadMax(const LineSegment& seg, double step, double limit, BoundaryType::Kind::Set targetFlag) const {
        LOGV(LOG_TAG "::seekExdendHeadMax", "()");
        if (seg.isNegrective() || limit <= 0.0) {
            LOGV(LOG_TAG "::seekExdendHeadMax", "Not extend\nsrcSeg: %s", to_string(seg).c_str());
            return seg;
        }
        
        // TODO: 最短のBPまでの延長量にする
        limit = std::min(limit, 1000.0);
        
        auto resultSeg = seg;
        if (signbit(step)) {
            // stepが負のとき、最大から減らしていく
            for (double extendLen = limit; step < extendLen; extendLen += step) {
                auto eseg = seg;
                eseg.extendHead(std::max(extendLen, 0.0));
                if (checkBoundary(eseg, targetFlag) == Intersection::NO) {
                    LOGD(LOG_TAG "::seekExdendHeadMax", "extend %0.7g to %0.7g\nsrcSeg: %s", seg.length(), eseg.length(), to_string(seg).c_str());
                    resultSeg = eseg;
                    break;
                }
            }
        } else {
            // stepが正のとき、0.0から増やしていく。
            const double end = limit + step;
            for (double extendLen = 0.0; extendLen < end; extendLen += step) {
                auto eseg = seg;
                eseg.extendHead(std::min(extendLen, limit));
                if (checkBoundary(eseg, targetFlag) != Intersection::NO) {
                    LOGD(LOG_TAG "::seekExdendHeadMax", "extend %0.7g to %0.7g\nsrcSeg: %s", seg.length(), resultSeg.length(), to_string(seg).c_str());
                    break;
                }
                resultSeg = eseg;
            }
        }
        
        return resultSeg;
    }

    /**
     線分を境界未満まで短縮
     指定線分のhead側を指定境界に抵触しない長さに縮めて返す。
      - stepずつminLenまで試行する。境界に抵触しない長さが見つからない場合、長さ0のセグメントを返す。
     
     @param[in] seg         処理対象LineSegment
     @param[in] step        短縮ステップ長
     @param[in] minLen      セグメントの最小長
     @param[in] targetFlag  ターゲット境界フラグ
     @return 処理後セグメント
     */
    LineSegment PathAssembler::ensureNoCollisionHeadward(const LineSegment& seg, double step, double minLen, BoundaryType::Kind::Set targetFlag) const {
        LOGV(LOG_TAG "::seekShortenHeadMax", "()");
        if (seg.isNegrective()) {
            LOGD(LOG_TAG "::seekShortenHeadMax", "Undable to shortend\nsrcSeg: %s", to_string(seg).c_str());
            return seg;
        }

        if (checkBoundary(seg, targetFlag) == Intersection::NO) {
            LOGD(LOG_TAG "::seekShortenHeadMax", "No need shortend: %0.7g\nsrcSeg: %s", seg.length(), to_string(seg).c_str());
            return seg;
        }

        LineSegment resultSeg = seg;
        resultSeg.enterPoint() = resultSeg.leavePoint();

        double orgLen = seg.length();
        double limit = minLen;
        double newLen = 0.0;
        for (newLen = orgLen - step; limit <= newLen; newLen -= step) {
            auto eseg = getFromTail(seg, newLen);
            if (checkBoundary(eseg, targetFlag) == Intersection::NO) {
                LOGD(LOG_TAG "::seekShortenHeadMax", "shortend %0.7g to %0.7g\nsrcSeg: %s", orgLen, newLen, to_string(seg).c_str());
                resultSeg = eseg;
                break;
            }
        }
        
        return resultSeg;
    }

    /**
     線分を境界まで伸長
     @param[in,out] seg        処理対象LineSegment
     @param[in]     targetFlag ターゲット境界フラグ
     @return 処理後セグメント
     */
    LineSegment PathAssembler::extendTailToBoundary(const LineSegment& seg, BoundaryType::Kind::Set targetFlag) const {
        return seekExtendTailMax(seg, gauge.headland.whisker.lengthStep, gauge.headland.whisker.lengthLimit, targetFlag);
    }

    /**
     線分を指定値まで伸長
     指定のセグメントsegをstep単位で伸長し、境界に抵触しない最大の長さのセグメントを返す。
        - 縮める方向には探索できない。
        - 全く伸ばせない場合は元のセグメントが帰るが、伸ばさない状態で抵触している可能性がある。
     @param[in] seg         処理対象LineSegment
     @param[in] step        延長試行ステップ長
     @param[in] limit       最大延長量
     @param[in] targetFlag  ターゲット境界フラグ
     @return 処理後セグメント
     */
    LineSegment PathAssembler::seekExtendTailMax(const LineSegment& seg, double step, double limit, BoundaryType::Kind::Set targetFlag) const {
        if (seg.isNegrective() || limit <= 0.0) {
            return seg;
        }

        // TODO: 最短のBPまでの延長量にする
        limit = std::min(limit, 1000.0);
        
        auto resultSeg = seg;
        if (signbit(step)) {
            // stepが負のとき、最大から減らしていく
            for (double extendLen = limit; step < extendLen; extendLen += step) {
                auto eseg = seg;
                eseg.extendTail(std::max(extendLen, 0.0));
                if (checkBoundary(eseg, targetFlag) == Intersection::NO) {
                    LOGD(LOG_TAG "::seekExdendTailMax()", "%0.7g to %0.7g", seg.length(), eseg.length());
                    resultSeg = eseg;
                    break;
                }
            }
        } else {
            // stepが正のとき、0.0から増やしていく。
            const double end = limit + step;
            for (double extendLen = 0.0; extendLen < end; extendLen += step) {
                auto eseg = seg;
                eseg.extendTail(std::min(extendLen, limit));
                if (checkBoundary(eseg, targetFlag) != Intersection::NO) {
                    LOGD(LOG_TAG "::seekExdendTailMax()", "%0.7g to %0.7g", seg.length(), eseg.length());
                    break;
                }
                resultSeg = eseg;
            }
        }
        
        return resultSeg;
    }

    /**
     線分取得(末尾から)
     指定のセグメントの始点側を変更して、指定の境界に抵触しない最長のものを返す。
     @param[in] seg         処理対象LineSegment
     @param[in] targetFlag  ターゲット境界フラグ
     @return 処理後セグメント
     */
    PathSegment PathAssembler::getFromTailToBoundary(PathSegment seg, BoundaryType::Kind::Set targetFlag) const {
        assert(seg.segmentType == SegmentType::LINESEG);

        const auto points = validator.boundarySet.getCrossPointsHeadward(seg, targetFlag);
        auto minIt = findNearest(points, seg.leavePoint());
        if (minIt == points.cend()) {
            return seg;
        }

        seg.enterPoint() = *minIt;
        auto extSeg = seekExtendHeadMax(seg, -0.1, seg.length());
        seg.enterPoint() = extSeg.enterPoint();
        seg.leavePoint() = extSeg.leavePoint();

        return seg;
    }


    /**
     ターン接続
     指定のターンを指定の行き先セグメントに接続する。
     - 行き先セグメントは変更不可能で、ターン側の脱出セグメント(パス脚)を調整する。
     @param[in] turnPath    処理対象ターンパス
     @param[in] enterSeg      行先セグメント
     @param[in] useReverseSeg      バックで接続を試みる
     @return 処理結果
     @retval SECCESS    成功
     @retval FAILURE    失敗
     */
    int PathAssemblerIf::connectTurnToSegment(TurnPath& turnPath, const PathSegment& enterSeg, bool useReverseSeg) const {
        int result = ResultCode::FAILURE;
        // 現在のターンパス脱出セグメント
        auto leaveSeg = turnPath.back();
        // 現在のターンパス脱出セグメントのひとつ前のセグメント
        const auto& leaveSeg0 = *std::prev(turnPath.cend(), 2);
        leaveSeg.leavePoint() = enterSeg.enterPoint();
        turnPath.pop_back();
        if (leaveSeg.checkConnection(enterSeg) == Segment2D::Connection::REFLECTED) {
            // 向きが反転した場合、追い越している
            if (leaveSeg.pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING &&
                enterSeg.pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING) {
                // 非作業パス同士の場合、接続してみる
                auto iSeg = leaveSeg;
                iSeg.leavePoint() = enterSeg.leavePoint();
                if (enterSeg.checkConnection(iSeg) == Segment2D::Connection::SMOOTH &&
                    iSeg.checkConnection(enterSeg) == Segment2D::Connection::SMOOTH) {
                    LOGD(LOG_TAG "::connectTurnToSegment", "CONNECT by MERGED LEG");
                    // 合成で解決(パス脚同士の共通部分で接続できた)
                    leaveSeg = iSeg;
                    result = ResultCode::SUCCESS;
                } else if (gauge.headland.permitBackward &&
                           leaveSeg.direction == SegmentDir::FORWARD &&
                           enterSeg.direction == SegmentDir::FORWARD) {
                    // バック可能なので反転部分をバックにしてみる
                    LOGD(LOG_TAG "::connectTurnToSegment", "CONNECT by REVERSE SEG");
                    if (leaveSeg0.segmentType == SegmentType::ARCSEG ||
                        leaveSeg0.pathAttr.isWorking()) {
                        LOGD(LOG_TAG "::connectTurnToSegment", "ADD pre-back seg");
                        // ひとつ前がカーブまたは作業セグメントなのでバック前準備直進が必要
                        // この構造はlegFolding(いわゆるどんつき)と同じ。
                        const double preBackLength = std::max(gauge.defaultPreBeckLength, gauge.minFpsLegLength);
                        auto preBackSeg = getHeadLeg(leaveSeg, preBackLength);
                        preBackSeg.exchange();  // prebackなので反対向き
                        preBackSeg.direction = leaveSeg0.direction;
                        leaveSeg.enterPoint() = preBackSeg.leavePoint();
                        turnPath.pushTurnPath(preBackSeg);
                        LOGD(LOG_TAG "::connectTurnToSegment", "pre-back seg and back Seg:\n\%s\n%s",
                             Svg::to_path_d(preBackSeg).c_str(), Svg::to_path_d(leaveSeg).c_str());
                    }
                    // leavesegは反転しておりバックセグメント
                    leaveSeg.direction = SegmentDir::REVERSE;
                    // 中間セグメントはNAVIGATIONとする
                    leaveSeg.turnType = PathParam::Turn::Type::NAVIGATION;
                    result = ResultCode::SUCCESS;
                } else {
                    result = ResultCode::FAILURE;
                }
            } else if (leaveSeg.pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING &&
                       enterSeg.pathAttr.rideType == PathParam::Segment::RideType::WORKING) {
                // 行先が作業パス
                // - 脱出パス脚を縮めることしかできない
                auto newLeg = leaveSeg;
                newLeg.leavePoint() = enterSeg.enterPoint();
                if (leaveSeg0.pathAttr.rideType == PathParam::Segment::RideType::WORKING && gauge.checkSPSLegLength(newLeg.length())) {
                    LOGD(LOG_TAG "::connectTurnToSegment", "Path leave leg too short:\n\%s",
                         Svg::to_path_d(newLeg).c_str());
                    // 直前が作業パスのときは最小パス脚長未満にできない
                    result = ResultCode::FAILURE;
                } else {
                    leaveSeg = newLeg;
                    result = ResultCode::SUCCESS;
                }
            }
        } else {
            result = ResultCode::SUCCESS;
        }
        turnPath.pushTurnPath(leaveSeg);
        
        return result;
    }

    /**
     ターン接続
     指定のターンパス同士を接続する状態にして返す。
     - 中間セグメントから辺の属性を得る。
     @param[in] fromPath    処理対象ターンパス
     @param[in] interSeg    中間セグメント(ターン生成した辺など)
     @param[in] toPath         処理対象ターンパス
     @param[in] useReverseSeg      バックで接続を試みる
     @return 処理結果
     @retval SECCESS    成功
     @retval FAILURE    失敗
     */
    int PathAssemblerIf::connectTurnToTurn(TurnPath& fromPath, const PathSegment& interSeg, TurnPath& toPath, bool useReverseSeg) const {
        LOGD(LOG_TAG "::connectTurnToTurn", "(no gap, reverse = %d)", (int)useReverseSeg);

        int result = ResultCode::FAILURE;
        // 前のターンパス脱出セグメント
        auto fromSeg = fromPath.back();
        // 次のターンパス進入セグメント
        auto toSeg = toPath.front();

        if (fromSeg.isNegrective()) {
            auto fromSeg2 = *std::prev(fromPath.cend(), 2);
            if (!isInline(fromSeg2, toSeg)) {
                LOGD(LOG_TAG "::connectTurnToTurn", "NOT INLINE:\n%s\n%s",
                     Svg::to_path(fromPath).c_str(), Svg::to_path(toPath).c_str());
                return ResultCode::ConnectPath::FAILURE_CONNECT;
            }
        } else {
            if (!isInline(fromSeg, toSeg)) {
                LOGD(LOG_TAG "::connectTurnToTurn", "NOT INLINE:\n%s\n%s",
                     Svg::to_path(fromPath).c_str(), Svg::to_path(toPath).c_str());
                return ResultCode::ConnectPath::FAILURE_CONNECT;
            }
        }

        const auto segpos = inlinePosition(fromSeg, toSeg);
        if (segpos == InlinePos::LLMM) {
            // 隙間があるので間を繋ぐ
            // ターン間セグメント
            auto iSeg = interSeg;
            iSeg.enterPoint() = fromSeg.leavePoint();
            iSeg.leavePoint() = toSeg.enterPoint();
            fromPath.pushTurnPath(iSeg);
            result = ResultCode::SUCCESS;
        } else {
            if (interSeg.pathAttr.isWorking()) {
                // 作業パスの入る隙間が無い場合は即エラー
                LOGE(LOG_TAG "::getOrbitalPath", "[EXCEPTION] CONNECT CORNER TURNS:\n%s\n%s",
                     Svg::to_path(fromPath).c_str(), Svg::to_path(toPath).c_str());
                result = ResultCode::ConnectPath::FAILURE_OVERLAP;
            } else {
                result = ResultCode::FAILURE;
//              result = connectTurnToTurn(fromPath, toPath, useReverseSeg);
            }
        }
        
        return result;
    }

    /**
     ROターン接続
     指定のターンパス同士を指定の中間セグメントで接続する状態にして返す。
     - 中間セグメントから辺の属性を得る。
     - 行先がαターンだった場合、最初のセグメントは長さを担保しなければならないため、中間セグメントの方を最小化する。
     @param[in] fromPath    処理対象ターンパス
     @param[in] interSeg    中間セグメント(ターン生成した辺など)
     @param[in] toPath         処理対象ターンパス
     @param[in] useReverseSeg      バックで接続を試みる
     @return 処理結果
     @retval SECCESS    成功
     @retval FAILURE    失敗
     */
    int PathAssemblerIf::connectTurnToTurnRO(TurnPath& fromPath, const PathSegment& interSeg, TurnPath& toPath, bool useReverseSeg) const {
        LOGD(LOG_TAG "::connectTurnToTurnRO", "(no gap, reverse = %d)", (int)useReverseSeg);
        assert(!interSeg.pathAttr.isWorking());

        int result = ResultCode::FAILURE;
        // 前のターンパス脱出セグメント
        auto fromSeg = fromPath.back();
        // 次のターンパス進入セグメント
        auto toSeg = toPath.front();

        if (fromSeg.isNegrective()) {
            auto fromSeg2 = *std::prev(fromPath.cend(), 2);
            if (!isInline(fromSeg2, toSeg)) {
                LOGD(LOG_TAG "::connectTurnToTurnRO", "NOT INLINE:\n%s\n%s",
                     Svg::to_path(fromPath).c_str(), Svg::to_path(toPath).c_str());
                return ResultCode::ConnectPath::FAILURE_CONNECT;
            }
        } else {
            if (!isInline(fromSeg, toSeg)) {
                LOGD(LOG_TAG "::connectTurnToTurnRO", "NOT INLINE:\n%s\n%s",
                     Svg::to_path(fromPath).c_str(), Svg::to_path(toPath).c_str());
                return ResultCode::ConnectPath::FAILURE_CONNECT;
            }
        }
        
        const double dp = fromSeg.getDotProduct(toSeg);
        if (dp < 0.0) {
            LOGD(LOG_TAG "::connectTurnToTurnRO", "COUNTER VECTOR:\n%s\n%s",
                 Svg::to_path(fromPath).c_str(), Svg::to_path(toPath).c_str());
            return ResultCode::ConnectPath::FAILURE_CONNECT;
        }

        const auto segpos = inlinePosition(fromSeg, toSeg);
        if (segpos == InlinePos::LLMM) {
            // 隙間があるので間を繋ぐ
            // ターン間セグメント
            if (toSeg.turnType == TurnType::ALPHA && !interSeg.pathAttr.isWorking()) {
                LOGD(LOG_TAG "::connectTurnToTurnRO", "Alpha turn, connect with interseg");
                toSeg.enterPoint() = fromSeg.leavePoint();
                if (toSeg.length() < 2.0 + 0.1) {
                    toSeg = getFromHead(toSeg, 2.1);
                    toPath[1].enterPoint() = toSeg.leavePoint();
                    toSeg.extendHead(-0.1);
                    auto iSeg = interSeg;
                    LOGD(LOG_TAG "::connectTurnToTurnRO", "connect with interseg: %0.7g, %0.7g, %0.7g",
                         fromSeg.length(), iSeg.length(), toSeg.length());
                    iSeg.enterPoint() = fromSeg.leavePoint();
                    iSeg.leavePoint() = toSeg.enterPoint();
                    fromPath.pushTurnPath(iSeg);
                    toPath.front() = toSeg;
                } else {
                    auto iSeg = interSeg;
                    toSeg.extendHead(-TOL_TEN_CM);
                    iSeg.enterPoint() = fromSeg.leavePoint();
                    iSeg.leavePoint() = toSeg.enterPoint();
                    fromPath.pushTurnPath(iSeg);
                    toPath.front() = toSeg;
                }
            } else {
                auto iSeg = interSeg;
                iSeg.enterPoint() = fromSeg.leavePoint();
                iSeg.leavePoint() = toSeg.enterPoint();
                LOGD(LOG_TAG "::connectTurnToTurnRO", "connect with interseg: %0.7g, %0.7g, %0.7g",
                     fromSeg.length(), iSeg.length(), toSeg.length());
                fromPath.pushTurnPath(iSeg);
            }
            result = ResultCode::SUCCESS;
        } else {
            if (interSeg.pathAttr.isWorking()) {
                // 作業パスの入る隙間が無い場合は即エラー
                LOGD(LOG_TAG "::connectTurnToTurnRO", "[EXCEPTION] CONNECT CORNER TURNS:\n%s\n%s",
                     Svg::to_path(fromPath).c_str(), Svg::to_path(toPath).c_str());
                result = ResultCode::ConnectPath::FAILURE_OVERLAP;
            } else {
                result = ResultCode::FAILURE;
//              result = connectTurnToTurn(fromPath, toPath, useReverseSeg);
            }
        }
        
        return result;
    }



    namespace {
        struct Preserve{
            static constexpr int NONE = 0;      // いずれでもない
            static constexpr int PATHLEG = 1;   // 作業パス脚の長さ維持
            static constexpr int PREBACK = 2;   // バック前の長さ維持
            static constexpr int BACKWARD = 3;  // バックセグメントである場合の長さ維持
            int leaveLegType = NONE;
            double minLeaveLegLength = 0.0;
            int enterLegType = NONE;
            double minEnterLegLength = 0.0;
        } preserve;
    }

    /**
     ターン接続
     脱出ターンパスから進入ターンパス間を接続するように各ターンパスを変更して結果を返す。
     - ターン同士の端点(セグメント)が重なっていない場合、間に非作業でTurnType = NAVIGATION(5)のセグメントを挿入する。
     - ターン同士の端点が重なっている場合、必要なセグメントの端点を変更して接続を試みる。
     - 但し、セグメントは以下の場合には変更できない。
         - 作業セグメント
         - バックセグメント
     - 但し、以下のセグメントは端点の変更時にそれぞれの最小長を維持しようとする。
         - パス脚(作業パスの前後)
         - バックのカーブ前の準備直進(preBack)
     @param[in,out] fromPath    脱出ターンパス
     @param[in,out] toPath         進入ターンパス
     @param[in] useReverseSeg      バックで接続を試みるかどうか
     @return 処理結果
     @retval SECCESS    成功
     @retval FAILURE    失敗
     */
    int PathAssemblerIf::connectTurnToTurn(TurnPath& fromPath, TurnPath& toPath, bool useReverseSeg) const {
        LOGD(LOG_TAG "::connectTurnToTurn", "(no gap, reverse = %d)", (int)useReverseSeg);

        int result = ResultCode::FAILURE;
        // 前のターンパス脱出セグメント
        auto& leaveSeg = fromPath.back();
        // 次のターンパス進入セグメント
        auto& enterSeg = toPath.front();

        Preserve preserve;

        preserve.minLeaveLegLength = gauge.defaultPreBeckLength;    // デフォルト値
        // バックセグメントの長さは変更しない
        if (leaveSeg.direction == SegmentDir::REVERSE) {
            preserve.leaveLegType = Preserve::BACKWARD;
        }
        if (preserve.leaveLegType == Preserve::NONE && leaveSeg.pathAttr.isWorking()) {
            // 作業パスならばバック前準備直進長はパス脚長である
            preserve.leaveLegType = Preserve::PATHLEG;
            preserve.minLeaveLegLength = gauge.minFpsLegLength;
        }
        if (preserve.leaveLegType == Preserve::NONE && 2 <= fromPath.size()) {
            // 現在のターンパス脱出セグメントのひとつ前のセグメント
            const auto& leaveSeg0 = *std::prev(fromPath.cend(), 2);
            if (leaveSeg0.pathAttr.isWorking()) {
                // 直前が作業パスならばこれはパス脚である
                // - パス脚最小長にする
                if (gauge.minFpsLegLength < leaveSeg.length()) {
                    leaveSeg = getFromHead(leaveSeg, gauge.minFpsLegLength);
                }
                // - パス脚長保持する
                preserve.minLeaveLegLength = gauge.minFpsLegLength;
                preserve.leaveLegType = Preserve::PATHLEG;
            } else if (leaveSeg0.segmentType == SegmentType::ARCSEG) {
                // バックカーブならばpostBack直進が必要。前進のカーブの場合は次のセグメント次第。
                if (leaveSeg0.direction == SegmentDir::REVERSE) {
                    // デフォルトではあるが一応代入
                    preserve.minLeaveLegLength = gauge.defaultPreBeckLength;
                }
                preserve.leaveLegType = Preserve::PREBACK;
            }
        }
        // 作業パスまたはバックセグメントなら長さは変更しない
        if (enterSeg.pathAttr.isWorking() || enterSeg.direction == SegmentDir::REVERSE) {
            preserve.enterLegType = Preserve::BACKWARD;
        }
        if (preserve.enterLegType == Preserve::NONE && 2 <= toPath.size()) {
            // 次のターンパス進入セグメントのひとつ次のセグメント
            const auto& enterSeg0 = *std::next(toPath.cbegin());
            if (enterSeg0.pathAttr.isWorking()) {
                // 次が作業パスならばこれはパス脚である
                // - パス脚長保持する
                if (gauge.minSpsLegLength < enterSeg.length()) {
                    enterSeg = getFromTail(enterSeg, gauge.minFpsLegLength);
                }
                preserve.minEnterLegLength = gauge.minSpsLegLength;
                preserve.enterLegType = Preserve::PATHLEG;
            } else if (enterSeg0.segmentType == SegmentType::ARCSEG && enterSeg0.direction == SegmentDir::REVERSE) {
                // 次がバックのカーブならばバック前直進長
                preserve.minEnterLegLength = gauge.defaultPreBeckLength;
                preserve.enterLegType = Preserve::PREBACK;
            }
        }
            
        const auto segpos = inlinePosition(leaveSeg, enterSeg);
        switch(segpos) {
            case InlinePos::LMLM:
            {
                // 隙間無し - 進入セグメントを切り詰めて直接繋ぐ
                if (preserve.leaveLegType == Preserve::NONE) {
                    LOGD(LOG_TAG "::connectTurnToTurn", "CONNECT TRUNCATE ENTERSEG");
                    leaveSeg.leavePoint() = enterSeg.leavePoint();
                    result = ResultCode::SUCCESS;
                } else if (preserve.enterLegType == Preserve::NONE) {
                    LOGD(LOG_TAG "::connectTurnToTurn", "CONNECT TRUNCATE LEAVESEG");
                    enterSeg.enterPoint() = leaveSeg.leavePoint();
                    result = ResultCode::SUCCESS;
                } else {
                    goto MMLL;
                }
                break;
            }
            case InlinePos::LMML:
            {
                LOGD(LOG_TAG "::connectTurnToTurn", "CONNECT TRUNCATE LEAVESEG");
                // 隙間無し - 脱出セグメントを切り詰めて直接繋ぐ
                if (preserve.leaveLegType == Preserve::NONE) {
                    leaveSeg.leavePoint() = enterSeg.enterPoint();
                    result = ResultCode::SUCCESS;
                } else {
                    // 脱出セグメントが切り詰められない場合、バックして繋ぐ
                    goto MMLL;
                }
                break;
            }
            case InlinePos::MLLM:
            {
                LOGD(LOG_TAG "::connectTurnToTurn", "CONNECT INTERSECTED");
                // 隙間無し - 進入セグメントを切り詰めて繋ぐ
                if (preserve.enterLegType == Preserve::NONE) {
                    enterSeg.enterPoint() = leaveSeg.leavePoint();
                    result = ResultCode::SUCCESS;
                } else {
                    // 進入セグメントが切り詰められない場合、バックして繋ぐ
                    goto MMLL;
                }
                break;
            }
            case InlinePos::MLML:
            {
                LOGD(LOG_TAG "::connectTurnToTurn", "CONNECT INTERSECTED");
                // 隙間無し - 両方を合成して一本のセグメントで直接繋ぐ
                if (preserve.leaveLegType == Preserve::NONE && preserve.enterLegType == Preserve::NONE) {
                    enterSeg.enterPoint() = leaveSeg.enterPoint();
                    fromPath.pop_back();
                    result = ResultCode::SUCCESS;
                } else {
                    // 削れないのでバックで繋ぐ
                    goto MMLL;
                }
                break;
            }
            case InlinePos::MMLL:
            MMLL:
            {
                LOGD(LOG_TAG "::connectTurnToTurn", "CONNECT REQ REVERSE SEG");
                if (gauge.headland.permitBackward) {
                    // 追越し - バックで繋ぐ必要がある
                    LOGD(LOG_TAG "::connectTurnToTurn", "CONNECT by REVERSE SEG");
                    const auto leaveSegOrg = leaveSeg;
                    const auto enterSegOrg = enterSeg;
                    if (preserve.leaveLegType == Preserve::PATHLEG ||
                        preserve.leaveLegType == Preserve::PREBACK) {
                        LOGD(LOG_TAG "::connectTurnToTurn", "ADD pre-back seg");
                        // ひとつ前がカーブまたは作業セグメントなのでバック前準備直進が必要
                        // この構造はlegFolding(いわゆるどんつき)と同じ。
                        leaveSeg = getFromHead(leaveSegOrg, preserve.minLeaveLegLength);
                    } else {
                        // 念の為に残す
                        leaveSeg = getFromTail(leaveSegOrg, 0.1);
                    }
                    LOGD(LOG_TAG "::connectTurnToTurn", "pre-back seg length:%g", leaveSeg.length());
                    enterSeg = getFromTail(enterSegOrg, 0.1);
                    // 中間セグメント
                    // - 中間セグメントは常に非作業パス。作業パスを挟む時はこの関数は使用しない。
                    auto iSeg = leaveSeg;
                    iSeg.exchange();
                    iSeg.leavePoint() = enterSeg.enterPoint();
                    // 中間セグメントはNAVIGATIONとする
                    iSeg.turnType = PathParam::Turn::Type::NAVIGATION;
                    iSeg.pathAttr.rideType = PathParam::Segment::RideType::NON_WORKING;
                    const double dp = leaveSeg.getDotProductTo(enterSeg.enterPoint());
                    const double distance = iSeg.length();
                    if (dp < 0.0 && 0.2 < distance) {
                        LOGD(LOG_TAG "::connectTurnToTurn", "connect backward");
                        iSeg.direction = SegmentDir::REVERSE;
                        fromPath.pushTurnPath(iSeg);
                    } else {
                        // 結果前進でつなぐことになった
                        leaveSeg = getFromHead(leaveSegOrg, 0.2);
                        enterSeg = getFromTail(enterSegOrg, 0.2);
                        const double dp = leaveSeg.getDotProductTo(enterSeg.enterPoint());
                        if (dp < 0.0) {
                            LOGD(LOG_TAG "::connectTurnToTurn", "connect backward");
                            iSeg.direction = SegmentDir::REVERSE;
                        } else {
                            LOGD(LOG_TAG "::connectTurnToTurn", "connect forward");
                            iSeg.direction = SegmentDir::FORWARD;
                        }
                        iSeg.enterPoint() = leaveSeg.leavePoint();
                        iSeg.leavePoint() = enterSeg.enterPoint();
                        fromPath.pushTurnPath(iSeg);
                    }
                    LOGD(LOG_TAG "::connectTurnToTurn", "pre-back seg and back Seg:\n\%s\n%s",
                         Svg::to_path_d(iSeg).c_str(), Svg::to_path_d(leaveSeg).c_str());
                    result = ResultCode::SUCCESS;
                } else {
                    LOGD(LOG_TAG "::connectTurnToTurn", "FAILED by INHIBIT BACKWARD");
                    result = ConnectPath::FAILURE_BACKWARD;
                }
                break;
            }
        }

        return result;
    }

    /**
     ROターン接続
     脱出ターンパスから進入ターンパス間を接続するように各ターンパスを変更して結果を返す。
     - ターン同士の端点(セグメント)が重なっていない場合、間に非作業でTurnType = NAVIGATION(5)のセグメントを挿入する。
     - ターン同士の端点が重なっている場合、必要なセグメントの端点を変更して接続を試みる。
     - 但し、セグメントは以下の場合には変更できない。
         - 作業セグメント
         - バックセグメント
     - 但し、以下のセグメントは端点の変更時にそれぞれの最小長を維持しようとする。
         - パス脚(作業パスの前後)
         - バックのカーブ前の準備直進(preBack)
     @param[in,out] fromPath    脱出ターンパス
     @param[in,out] toPath         進入ターンパス
     @param[in] useReverseSeg      バックで接続を試みるかどうか
     @return 処理結果
     @retval SECCESS    成功
     @retval FAILURE    失敗
     */
    int PathAssemblerIf::connectTurnToTurnRO(TurnPath& fromPath, TurnPath& toPath, bool useReverseSeg) const {
        LOGD(LOG_TAG "::connectTurnToTurnRO", "(no gap, reverse = %d)", (int)useReverseSeg);

        int result = ResultCode::FAILURE;
        // 前のターンパス脱出セグメント
        auto& leaveSeg = fromPath.back();
        // 次のターンパス進入セグメント
        auto& enterSeg = toPath.front();

        // 脚同士のベクトルが逆の場合、接続不可
        const double dp = leaveSeg.getDotProduct(enterSeg);
        if (dp < 0.0) {
            LOGD(LOG_TAG "::connectTurnToTurnRO", "COUNTER VECTOR:\n%s\n%s",
                 Svg::to_path(fromPath).c_str(), Svg::to_path(toPath).c_str());
            return ResultCode::ConnectPath::FAILURE_CONNECT;
        }
        
        Preserve preserve;

        preserve.minLeaveLegLength = gauge.defaultPreBeckLength;    // デフォルト値
        // バックセグメントの長さは変更しない
        if (leaveSeg.direction == SegmentDir::REVERSE) {
            preserve.leaveLegType = Preserve::BACKWARD;
        }
        if (preserve.leaveLegType == Preserve::NONE && leaveSeg.pathAttr.isWorking()) {
            // 作業パスならばバック前準備直進長はパス脚長である
            preserve.leaveLegType = Preserve::PATHLEG;
            preserve.minLeaveLegLength = gauge.minFpsLegLength;
        }
        if (preserve.leaveLegType == Preserve::NONE && 2 <= fromPath.size()) {
            // 現在のターンパス脱出セグメントのひとつ前のセグメント
            const auto& leaveSeg0 = *std::prev(fromPath.cend(), 2);
            if (leaveSeg0.pathAttr.isWorking()) {
                // 直前が作業パスならばこれはパス脚である
                // - パス脚最小長にする
                if (gauge.minFpsLegLength < leaveSeg.length()) {
                    leaveSeg = getFromHead(leaveSeg, gauge.minFpsLegLength);
                }
                // - パス脚長保持する
                preserve.minLeaveLegLength = gauge.minFpsLegLength;
                preserve.leaveLegType = Preserve::PATHLEG;
            } else if (leaveSeg0.segmentType == SegmentType::ARCSEG) {
                // バックカーブならばpostBack直進が必要。前進のカーブの場合は次のセグメント次第。
                if (leaveSeg0.direction == SegmentDir::REVERSE) {
                    // デフォルトではあるが一応代入
                    preserve.minLeaveLegLength = gauge.defaultPreBeckLength;
                }
                preserve.leaveLegType = Preserve::PREBACK;
            }
        }
        // 作業パスまたはバックセグメントなら長さは変更しない
        if (enterSeg.pathAttr.isWorking() || enterSeg.direction == SegmentDir::REVERSE) {
            preserve.enterLegType = Preserve::BACKWARD;
        }
        if (preserve.enterLegType == Preserve::NONE && 2 <= toPath.size()) {
            // 次のターンパス進入セグメントのひとつ次のセグメント
            const auto& enterSeg0 = *std::next(toPath.cbegin());
            if (enterSeg0.pathAttr.isWorking()) {
                // 次が作業パスならばこれはパス脚である
                // - パス脚長保持する
                if (gauge.minSpsLegLength < enterSeg.length()) {
                    enterSeg = getFromTail(enterSeg, gauge.minFpsLegLength);
                }
                preserve.minEnterLegLength = gauge.minSpsLegLength;
                preserve.enterLegType = Preserve::PATHLEG;
            } else if (enterSeg0.direction == SegmentDir::REVERSE) {
                // 次がバックのカーブならばバック前直進長
                preserve.minEnterLegLength = gauge.defaultPreBeckLength;
                preserve.enterLegType = Preserve::PREBACK;
            }
        }
            
        const auto segpos = inlinePosition(leaveSeg, enterSeg);
        switch(segpos) {
            case InlinePos::LMLM:
            {
                // 隙間無し - 進入セグメントを切り詰めて直接繋ぐ
                if (preserve.leaveLegType == Preserve::NONE) {
                    LOGD(LOG_TAG "::connectTurnToTurnRO", "CONNECT TRUNCATE ENTERSEG");
                    leaveSeg.leavePoint() = enterSeg.leavePoint();
                    result = ResultCode::SUCCESS;
                } else if (preserve.enterLegType == Preserve::NONE) {
                    LOGD(LOG_TAG "::connectTurnToTurnRO", "CONNECT TRUNCATE LEAVESEG");
                    enterSeg.enterPoint() = leaveSeg.leavePoint();
                    result = ResultCode::SUCCESS;
                } else {
                    goto MMLL;
                }
                break;
            }
            case InlinePos::LMML:
            {
                LOGD(LOG_TAG "::connectTurnToTurnRO", "CONNECT TRUNCATE LEAVESEG");
                // 隙間無し - 脱出セグメントを切り詰めて直接繋ぐ
                if (preserve.leaveLegType == Preserve::NONE) {
                    leaveSeg.leavePoint() = enterSeg.enterPoint();
                    result = ResultCode::SUCCESS;
                } else {
                    // 脱出セグメントが切り詰められない場合、バックして繋ぐ
                    goto MMLL;
                }
                break;
            }
            case InlinePos::MLLM:
            {
                LOGD(LOG_TAG "::connectTurnToTurnRO", "CONNECT INTERSECTED");
                // 隙間無し - 進入セグメントを切り詰めて繋ぐ
                if (preserve.enterLegType == Preserve::NONE) {
                    enterSeg.enterPoint() = leaveSeg.leavePoint();
                    result = ResultCode::SUCCESS;
                } else {
                    // 進入セグメントが切り詰められない場合、バックして繋ぐ
                    goto MMLL;
                }
                break;
            }
            case InlinePos::MLML:
            {
                LOGD(LOG_TAG "::connectTurnToTurnRO", "CONNECT INTERSECTED");
                // 隙間無し - 両方を合成して一本のセグメントで直接繋ぐ
                if (preserve.leaveLegType == Preserve::NONE && preserve.enterLegType == Preserve::NONE) {
                    enterSeg.enterPoint() = leaveSeg.enterPoint();
                    fromPath.pop_back();
                    result = ResultCode::SUCCESS;
                } else {
                    // 削れないのでバックで繋ぐ
                    goto MMLL;
                }
                break;
            }
            case InlinePos::MMLL:
            MMLL:
            {
                LOGD(LOG_TAG "::connectTurnToTurnRO", "CONNECT REQ REVERSE SEG");
                if (gauge.headland.permitBackward) {
                    // 追越し - バックで繋ぐ必要がある
                    LOGD(LOG_TAG "::connectTurnToTurnRO", "CONNECT by REVERSE SEG");
                    const auto leaveSegOrg = leaveSeg;
                    const auto enterSegOrg = enterSeg;
                    if (preserve.leaveLegType == Preserve::PATHLEG ||
                        preserve.leaveLegType == Preserve::PREBACK) {
                        LOGD(LOG_TAG "::connectTurnToTurnRO", "ADD pre-back seg");
                        // ひとつ前がカーブまたは作業セグメントなのでバック前準備直進が必要
                        // この構造はlegFolding(いわゆるどんつき)と同じ。
                        leaveSeg = getFromHead(leaveSegOrg, preserve.minLeaveLegLength);
                    } else {
                        // 念の為に残す
                        leaveSeg = getFromTail(leaveSegOrg, 0.1);
                    }
                    LOGD(LOG_TAG "::connectTurnToTurnRO", "pre-back seg length:%g", leaveSeg.length());
                    if (enterSeg.turnType == PathParam::Turn::Type::ALPHA) {
                        enterSeg = getFromTail(enterSegOrg, 2.0);
                    } else {
                        enterSeg = getFromTail(enterSegOrg, 0.1);
                    }
                    // 中間セグメント
                    // - 中間セグメントは常に非作業パス。作業パスを挟む時はこの関数は使用しない。
                    auto iSeg = leaveSeg;
                    iSeg.exchange();
                    iSeg.leavePoint() = enterSeg.enterPoint();
                    // 中間セグメントはNAVIGATIONとする
                    iSeg.turnType = PathParam::Turn::Type::NAVIGATION;
                    iSeg.pathAttr.rideType = PathParam::Segment::RideType::NON_WORKING;
                    const double dp = leaveSeg.getDotProductTo(enterSeg.enterPoint());
                    const double distance = iSeg.length();
                    if (dp < 0.0 && 0.2 < distance) {
                        LOGD(LOG_TAG "::connectTurnToTurnRO", "connect backward: %0.7g, %0.7g, %0.7g", leaveSeg.length(), iSeg.length(), enterSeg.length());
                        iSeg.direction = SegmentDir::REVERSE;
                        fromPath.pushTurnPath(iSeg);
                    } else {
                        // 結果前進でつなぐことになった
                        leaveSeg = getFromHead(leaveSegOrg, 0.2);
                        if (enterSeg.turnType != PathParam::Turn::Type::ALPHA) {
                            enterSeg = getFromTail(enterSegOrg, 0.2);
                        }
                        iSeg.enterPoint() = leaveSeg.leavePoint();
                        iSeg.leavePoint() = enterSeg.enterPoint();
                        const double dp = leaveSeg.getDotProductTo(enterSeg.enterPoint());
                        if (dp < 0.0) {
                            LOGD(LOG_TAG "::connectTurnToTurnRO", "connect backward");
                            iSeg.direction = SegmentDir::REVERSE;
                        } else {
                            LOGD(LOG_TAG "::connectTurnToTurnRO", "connect forward");
                            iSeg.direction = SegmentDir::FORWARD;
                        }
                        LOGD(LOG_TAG "::connectTurnToTurnRO", "connect forward: %0.7g, %0.7g, %0.7g", leaveSeg.length(), iSeg.length(), enterSeg.length());
                        fromPath.pushTurnPath(iSeg);
                    }
                    LOGD(LOG_TAG "::connectTurnToTurnRO", "pre-back seg and back Seg:\n\%s\n%s",
                         Svg::to_path_d(iSeg).c_str(), Svg::to_path_d(leaveSeg).c_str());
                    result = ResultCode::SUCCESS;
                } else {
                    LOGD(LOG_TAG "::connectTurnToTurnRO", "FAILED by INHIBIT BACKWARD");
                    result = ConnectPath::FAILURE_BACKWARD;
                }
                break;
            }
        }

        return result;
    }

}} // namespace yanmar::PathPlan


// Yanmar Confidential 20200918
/**
 @file PathAssembler.hpp
 
 パス組み立てクラスヘッダーファイル
 
 セグメントを組み合わせてターンパスを生成するクラス
 **/
#pragma once

#include "PathPlanIF.hpp"
#include "PathPlanConstant.hpp"

#include <utility>

#include "PolyLib/Context.hpp"
#include "Geometry/Geometry.hpp"
#include "Segment.hpp"
#include "Gauge.hpp"
#include "PathGeneratorData.hpp"
#include "PathValidator.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;
using namespace PathGeneratorData;
class ContextIF;

static constexpr int VALID = 0;
static constexpr int INVALID = -1;

/**
 パス組み立てクラス
 
 セグメントを組み合わせてターンパスを生成するクラス
 */
class PathAssemblerIf {
    friend struct Gauge;

public:
    // constructor
    PathAssemblerIf(ContextIF& aContext, const Gauge& aGauge):
        context(aContext),
        gauge(aGauge)
    {}

    /// パス端点座標クラス
    struct EndPoint : public XY_Point {
        explicit EndPoint(const XY_Point& point) :
            XY_Point(point)
        {}
    };

protected:
    ///////////////////
    ContextIF& context;    ///< パス生成コンテキスト
    const Gauge& gauge;    ///< パス生成用ゲージ(限界値や制限値)
    
public:
    /*
     * 接線とカーブパス計算関数群
     */
    TurnPath getForwardTangentAndCurve(const LineSegment& eTS, const Circle& currCirc, const Circle& nextCirc) const;
    TurnPath getReverseTangentAndCurve(const LineSegment& eTS, const Circle& currCirc, const Circle& nextCirc, double tailLen) const;
    TurnPath getTangentAndCurve(const LineSegment& eTS, const Circle& currCirc, const Circle& auxCirc, const Circle& nextCirc) const;
    TurnPath getTangentAndCurve(const WorkPath&    eTS, const Circle& currCirc, const Circle& auxCirc, const Circle& nextCirc) const = delete;  // FPS/SPSを与えたときの呼び出しを禁止する(以下同じ)
    TurnPath getTangentAndCurve(const XY_Point& PntP, const Circle& nextCirc) const;
    TurnPath getTurnPath(const PathFPS& fps, const PathSPS& sps, double tailLen) const;    // 固定フィッシュテールターン生成(ディスパッチ)
    TurnPath getFishTailPathBoth(const PathFPS& fps, const PathSPS& sps, double tailLen) const; // 固定フィッシュテールターン生成(両側にフィッシュテール)
    TurnPath getFishTailPathFPS(const PathFPS& fps, const PathSPS& sps, double tailLen) const;  // 固定フィッシュテールターン生成(FPS側フィッシュテール)
    TurnPath getFishTailPathSPS(const PathFPS& fps, const PathSPS& sps, double tailLen) const;  // 固定フィッシュテールターン生成(SPS側フィッシュテール)
    TurnPath getFishTailPath(const PathFPS& fps, const PathSPS& sps, double tailLen) const;     // 固定フィッシュテールターン生成(直接)
    TurnPath getTurnPath(const LineSegment& eTS, const Circle& currCirc, const XY_Point& destPoint) const;

    TurnPath getBackTurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const;    // パックターン
    TurnPath getAlphaBTurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const;    // αターンB
    TurnPath getAlphaFbTurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const;    // αターンFB
    TurnPath getAlphaATurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const;     // αターンA
    TurnPath getPlainTurnPath(const LineSegment& eTS, const LineSegment& lTS, const WhiskerMode_t& whiskerMode) const;   // プレーンターン

    TurnPath getMinimalEnterPath(PathSPS sps, double length) const;
    TurnPath getMinimalEnterPath(LineSegment leg, double length) const;

    TurnPath makeTurnPath(const LineSegment& eTS, const Circle& currCirc, const LineSegment& lTS) const;

    virtual std::pair<double, double> getWtCrossLengths(const LineSegment& eseg, const LineSegment& lseg) const { return {0.0, 0.0}; }
    virtual LineSegment extendHeadToBoundary(const LineSegment& seg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const { return seg; }
    virtual LineSegment extendTailToBoundary(const LineSegment& seg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const { return seg; }
    virtual LineSegment seekExtendHeadMax(const LineSegment& seg, double step, double limit, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const { return seg; }
    virtual LineSegment seekExtendTailMax(const LineSegment& seg, double step, double limit, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const { return seg; }
    int connectTurnToSegment(TurnPath& turnPath, const PathSegment& enterSeg, bool useReverseSeg = false) const;
    int connectTurnToTurn(TurnPath& fromPath, const PathSegment& interSeg, TurnPath& toPath, bool useReverseSeg = false) const;
    int connectTurnToTurnRO(TurnPath& fromPath, const PathSegment& interSeg, TurnPath& toPath, bool useReverseSeg = false) const;
    int connectTurnToTurn(TurnPath& fromPath, TurnPath& toPath, bool useReverseSeg = false) const;
    int connectTurnToTurnRO(TurnPath& fromPath, TurnPath& toPath, bool useReverseSeg = false) const;

    std::pair<TurnPath, TurnPath> getWhiskers(const LineSegment& eLeg, const LineSegment& lLeg, const WhiskerMode_t& whiskerMode) const;
    LineSegment getForwardWhiskerLegFb(const LineSegment& leg, double extLength) const;
    LineSegment getForwardWhiskerLegB(const LineSegment& leg, double extLength, double postBackLength) const;
    LineSegment getBackWhiskerLeg(const LineSegment& leg, double extLength, double postBackLength) const;
};

    
/**
 パス組み立てクラス
 
 セグメントを組み合わせてターンパスを生成するクラス
 */
class PathAssembler : public PathAssemblerIf {
    friend struct Gauge;
    using super = PathAssemblerIf;

public:
    // constructor
    PathAssembler(ContextIF& aContext, const Gauge& aGauge, const PathValidator& aValidator);

private:
    const PathValidator& validator;

public:
    TurnPath getMinimalLeavePath(PathFPS fps, double length, bool fold) const;
    TurnPath getMinimalLeavePath(LineSegment leg, double length, bool fold) const;
    TurnPath getMinimalLeavePath(const LineSegment& leaveLeg) const;

    // 検査済みパス取得関数群
    //  - 進入接線 - 脱出接線
    TurnPath getValidatedPath(const LineSegment& eTS, const Circle& nextCirc) const;
    TurnPath getValidatedPath(const PathFPS& fps, const Circle& nextCirc) const;
    TurnPath getValidatedPath(const PathFPS& fps, const Circle& nextCirc, double tailLen) const;
    TurnPath getValidatedPath(LineSegment eTS, const PathSPS& sps) const;
    TurnPath getValidatedPath(const WorkPath&    eTS, const Circle& nextCirc) const = delete;
    //  -
    TurnPath getValidatedPath(const LineSegment& eTS, const Circle& currCirc, const LineSegment& lTS, const Circle& nextCirc) const;
    TurnPath getValidatedPath(const WorkPath&    eTS, const Circle& currCirc, const LineSegment& lTS, const Circle& nextCirc) const = delete;
    TurnPath getValidatedPath(const LineSegment& eTS, const Circle& currCirc, const LineSegment& lTS) const;
    TurnPath getValidatedPath(const WorkPath&    eTS, const Circle& currCirc, const LineSegment& lTS) const = delete;
    TurnPath getValidatedPathForward(const PathFPS& fps, const PathSPS& sps) const;
    TurnPath getValidatedPathReverse(const PathFPS& fps, const PathSPS& sps) const;
    TurnPath getValidatedPath(const WorkPath& eTS, const WorkPath& sps) const = delete;
    TurnPath getValidatedPath(LineSegment& prevEts, Circle& prevCirc, LineSegment& iTS, const PathSPS& sps) const;
    TurnPath getValidatedPath(const WorkPath&   eTS, Circle& prevCirc, const LineSegment& iTS, const PathSPS& sps) const = delete;
    TurnPath getValidatedPath(const EndPoint& point, const PathSPS& sps) const;     // 始点 - SPS
    TurnPath getValidatedPath(const EndPoint& point, const Circle& prevCirc) const; // 始点 - コーナー
    TurnPath getValidatedPath(const LineSegment& eTS, const Circle& currCirc, const EndPoint& point) const;   // コーナー - 終点
    TurnPath getValidatedPath(const PathFPS& fps, const EndPoint& point) const;     // FPS - 終点
    // 補助ターンサークル対応
    TurnPath getValidatedPath(const LineSegment& prevEts, const Circle& prevCirc, const LineSegment& iTS, const Circle& auxCirc, const PathSPS& sps) const;
    TurnPath getValidatedPath(const WorkPath&    wpath,   const Circle& prevCirc, const LineSegment& iTS, const Circle& auxCirc, const PathSPS& sps) const = delete;
    TurnPath getValidatedPath(const PathFPS&     fps,     const Circle& auxCirc,  const Circle&      nextCirc) const;
    TurnPath getValidatedPath(const PathFPS&     fps,     const Circle& auxCirc,  const EndPoint&    endPoint) const;
    TurnPath getValidatedPath(const LineSegment& eTS, const Circle& auxCirc,  const PathSPS& sps) const;
    TurnPath getValidatedPath(const WorkPath&    eTS, const Circle& auxCirc,  const PathSPS& sps) const = delete;
    TurnPath getValidatedPath(const WorkPath&    eTS, const Circle& currCirc, const Circle&  auxCirc, const Circle& nextCirc) const = delete;

    enum FallbackMode {
        AUTO = 0,
        FORCE = 1,
        ERROR = 2
    };
    TurnPath getValidatedCornerTurnPath(const PathSegment& eTS, const PathSegment& lTS, bool permitBackward, int orient) const;
    TurnPath getValidatedLeaveRasterTurnPath(const PathSegment& eTS, const PathSegment& lTS, const TransitTurnParams& params) const;   // ラスター作業パス脱出用ターンパス生成(B,FB自動試行及びフィッシュテール)
    TurnPath getValidatedEnterRasterTurnPath(const PathSegment& eTS, const PathSegment& lTS, const WhiskerMode_t& whiskerMode) const;   // ラスター作業パスからの侵入用ターンパス生成(B,FB自動試行及びフィッシュテール)
    TurnPath getValidatedOribitalEnterPath(const EndPoint& point, const PathSegment& eTS) const;   // 開始点から周回パス進入ターンパス作業パスからの侵入用ターンパス生成(B,FB自動試行及びフィッシュテール)
    
    TurnPath getValidatedAlphaTurnPath(const PathSegment& eTS, const PathSegment& lTS, bool permaitFallback, const WhiskerMode_t& whiskerMode) const;   // αターンパス生成(B,FB自動試行及びフィッシュテール)
    TurnPath getValidatedAlphaTurnPath(const PathSegment& eTS, const PathSegment& lTS, const WhiskerMode_t& whiskerMode) const;   // αターンパス生成(B,FB自動試行)
    TurnPath getValidatedAlphaTurnPath7(const PathSegment& eTS, const PathSegment& lTS, const WhiskerMode_t& whiskerMode) const;   // αターンパス生成(A,B,FB自動試行)
    TurnPath getValidatedPlainTurnPath(const PathSegment& eTS, const PathSegment& lTS, const WhiskerMode_t& whiskerMode) const;

    TurnPath getFishTailTurnPath(const LineSegment& eTS, const LineSegment& lTS, int rotation) const;
    TurnPath getCornerTurnPath(const LineSegment& eTS, const LineSegment& iTS, const LineSegment& lTS) const;
    TurnPath getInterSegmentTurnPath(const LineSegment& eTS, const LineSegment& lTS) const;
    TurnPath getHookTurnPath(const LineSegment& eTS, const LineSegment& iTS, const LineSegment& lTS) const;

    std::pair<TurnPath, TurnPath> getWhiskers(const LineSegment& eLeg, const LineSegment& lLeg) const;
    TurnPath getWhiskerForward(const LineSegment& lseg, double length) const;
    TurnPath getWhiskerBackward(const LineSegment& lseg, double length) const;
    
    /*
     * ターンパス有効性検査
     *  - pathValidatorへ委譲
     */

    // 引数用クラス
    class StartnavStartSegment : public LineSegment {
    public:
        StartnavStartSegment(const LineSegment& lSeg) :
            LineSegment(lSeg)
        {}
    };

    class EndnavEndSegment : public LineSegment {
    public:
        EndnavEndSegment(const LineSegment& lSeg) :
            LineSegment(lSeg)
        {}
    };
    
    // 圃場境界交差検査
    // - PathValidatorに委譲
    int checkBoundary(const LineSegment& lineSeg, BoundaryType::Kind::Set targetFlag = PathPlan::BoundaryType::Kind::Mask::ALL) const {
        return validator.checkBoundaryIntersection(lineSeg, targetFlag);
    }
    int checkBoundary(StartnavStartSegment startSeg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const;
    int checkBoundary(EndnavEndSegment endSeg) const;
    int checkBoundary(const ArcSegment& arcSeg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const {
        return validator.checkBoundaryIntersection(arcSeg, targetFlag);
    }
    int checkBoundary(const GenSegment& gseg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const {
        if (gseg.segmentType == SegmentType::ARCSEG) {
            return checkBoundary(static_cast<ArcSegment>(gseg), targetFlag);
        } else {
            return checkBoundary(static_cast<LineSegment>(gseg), targetFlag);
        }
    }
    int checkBoundary(LineSegment eSeg, const TurnPath& turnPath, LineSegment lSeg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const {
        int retval = Intersection::NO;
        // 進入接線
        eSeg.leavePoint() = turnPath.enterPoint();
        if (checkBoundary(eSeg, PathPlan::BoundaryType::Kind::FOR_BACKTURN1)) {
            return Intersection::YES;
        }
        // 脱出接線
        lSeg.enterPoint() = turnPath.leavePoint();
        if (checkBoundary(lSeg, PathPlan::BoundaryType::Kind::FOR_BACKTURN1)) {
            return Intersection::YES;
        }
        // ターン内部
        for (const auto& seg : turnPath) {
            retval = checkBoundary(seg, PathPlan::BoundaryType::Kind::FOR_BACKTURN1);
            if (retval != Intersection::NO) {
                break;
            }
        }
        
        return retval;
    }

    int isFishtailAvialble(const LineSegment& eTS, const PathSPS& sps) const {
        if (dirY(eTS.point1(), eTS.point2()) == dirY(sps.getPoint(), sps.enterPoint())) {
            return 1;
        }

        return 0;
    }
    
    int isFishtailAvialble(const Circle& currCirc, const Circle& nextCirc) const {
        if (currCirc.orient != nextCirc.orient) {
            return 1;
        } else if (currCirc.checkIntersection(nextCirc) != Intersection::YES) {
            return 2;
        }
        
        return 0;
    }

    bool isRasterEnterLeaveAvailable(const LineSegment& eTS, const LineSegment& lTS) const;
    
    std::pair<double, double> getWtCrossLengths(const LineSegment& eseg, const LineSegment& lseg) const override;

    LineSegment extendHeadToBoundary(const LineSegment& seg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const override;
    LineSegment extendTailToBoundary(const LineSegment& seg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const override;
    LineSegment seekExtendHeadMax(const LineSegment& seg, double step, double limit, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const override;
    LineSegment seekExtendTailMax(const LineSegment& seg, double step, double limit, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const override;
    LineSegment ensureNoCollisionHeadward(const LineSegment& seg, double step, double minLen, BoundaryType::Kind::Set targetFlag) const;
    PathSegment getFromTailToBoundary(PathSegment seg, BoundaryType::Kind::Set targetFlag) const;
};


}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 @file PathExtent.cpp
 
 パス検証用外形クラス
 */

//#define LOGLEVEL 5

#include "PolyLib/Common.h"
#include "PathExtent.hpp"

#include "PathPlanConstant.hpp"
#include "PathGeneratorError.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

#pragma mark - PathExtentLine
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathExtentLine"
    /**
     PathExtentLineクラス コンストラクタ
     
     境界交差判定用パスセグメントコンストラクタ
     - 現在はフラグにかかわらず形状は同じである。
     
     @param[in] lseg    直線セグメント
     @param[in] gauge   パス限界値
     @param[in] aflags  ターゲット境界フラグ
     */
    PathExtentLine::PathExtentLine(const LineSegment& lseg, const Gauge& gauge, BoundaryType::Kind::Set aflags) :
        org(lseg), body(lseg), path(lseg), dimensions(gauge.entireDimension), clearance(gauge.clearance.BP)
    {
//        LOGV(LOG_TAG "::PathExtentLine", "(flag = 0x%llu)", flags.to_ullong());
        const double hw = gauge.halfActWidth;
        const double margin = gauge.clearance.BP;   // SHPも無くなったことだしtolBPは廃止
        const bool reverse = (lseg.direction == LineSegment::REVERSE);
        if (reverse) {
            // 後方移動
            // - 後退セグメントのみ前後もチェックする(フィッシュテール部分なので)
            flags.set(Flags::Index::FRONT).set(Flags::Index::REAR);
            // - 後方移動しているのでnose/tail が逆です
            initKinetic(hw, gauge.halfTractorWidth, gauge.tractor.noseLength, gauge.tractor.tailLength, margin);
        } else {
            // 前方移動
            // - 前方移動セグメントのleaveがトラクター前方
            // - 後方はテスト不要(前のセグメントがテストしているはず)
            flags.set(Flags::Index::FRONT).set(Flags::Index::REAR);
            initKinetic(hw, gauge.halfTractorWidth, gauge.tractor.tailLength, gauge.tractor.noseLength, margin);
        }
        
        LOGV(LOG_TAG, "%s", to_svg("PathExtentLine").c_str());
    }
    
    /**
     移動時外形初期化
     
     @param[in] hw           セグメント左右幅(全幅の半分)
     @param[in] enterExtend  セグメント進入側の延長量。前進の場合トラクター後方(tailLength)。
     @param[in] leaveExtend  セグメント出口側の延長量。前進の場合トラクター前方(noseLength)。
     @param[in] margin       トラクター外形からのマージン(クリアランス)
     */
    void PathExtentLine::initKinetic(double hw, double htw, double enterExtend, double leaveExtend, double margin) {
        const bool reverse = (org.direction == LineSegment::REVERSE);

        // セグメントの前方(出口側)
        if (0.0 < leaveExtend) {
            path.extendTail(leaveExtend + margin);
            body.extendTail(leaveExtend);
        }
        
        // セグメントの後方(入口側)
        if (0.0 < enterExtend) {
            path.extendHead(enterExtend + margin);
            body.extendHead(enterExtend);
        }

        if (reverse) {
            // 後退セグメント
            initKineticBackward(margin);
        } else {
            // 前進セグメント
            initKineticForward(margin);
        }
    }
    
    /**
     移動境界初期化(後退)
     
     初期化済みセグメント情報から衝突境界形状を算出する
     - 可能性のあるパラメータを求め実処理に渡す。
     - 後退方向に移動するので、dimensionsを前後左右入れ替えて算出する。
     @sa initKineticImpl()
     
     @param[in] hw       全幅の片側
     @param[in] margin   マージン(実形状からのクリアランス)
     */
    void PathExtentLine::initKineticBackward(double margin) {
        // 後退セグメント
        // バックするので前後左右逆である
        WidthArray widths{dimensions.getBackwardDim(), margin};
        initKineticImpl(widths);
    }

    /**
     移動境界初期化(前進)
     
     初期化済みセグメント情報から衝突境界形状を算出する
     - 可能性のあるパラメータを求め実処理に渡す。
     @sa initKineticImpl()
     
     @param[in] hw       基準幅の片側
     @param[in] margin   マージン(実形状からのクリアランス)
     */
    void PathExtentLine::initKineticForward(double margin) {
        // 前進セグメント
        WidthArray widths{dimensions, margin};
        initKineticImpl(widths);
    }

    /**
     移動境界初期化(実処理)
     
     12角形の幅情報から情報から衝突境界形状を算出する
     - 同じ幅の部分をまとめて、8から10角形の結果を得る。
     */
    void PathExtentLine::initKineticImpl(const WidthArray& widths) {
        // 後方
        LineSegment pathTail{path.enterPoint(), body.enterPoint()};
        LineSegment bodyTail{body.enterPoint(), org.enterPoint()};
        // 前方
        LineSegment bodyProw{org.leavePoint(), body.leavePoint()};
        LineSegment pathProw{body.leavePoint(), path.leavePoint()};

        // 前方コーナー(仮)
        frontCorner.left = getCollateralSegment(pathProw, +widths.prow.left);
        frontCorner.right = getCollateralSegment(pathProw, -widths.prow.right);
        // 基幹側面
        trunkSide.left = getCollateralSegment(org, +widths.trunk.left);
        trunkSide.right = getCollateralSegment(org, -widths.trunk.right);
        // 後方コーナー(仮)
        rearCorner.left = getCollateralSegment(pathTail, +widths.tail.left);
        rearCorner.right = getCollateralSegment(pathTail, -widths.tail.right);
        // 前方側面
        frontSide.left = getCollateralSegment(bodyProw, +widths.foreSide.left);
        frontSide.right = getCollateralSegment(bodyProw, -widths.foreSide.right);
        // 前方側面
        rearSide.left = getCollateralSegment(bodyTail, +widths.tailSide.left);
        rearSide.right = getCollateralSegment(bodyTail, -widths.tailSide.right);

        // 左側
        {
            // trunk は最大幅なので一致しなかったらtrunk側に合わせる
            // 前方側面
            if (widths.foreSide.left == widths.trunk.left) {
                trunkSide.left.leavePoint() = frontSide.left.leavePoint();
                // 長さを0にします
                frontSide.left.enterPoint() = frontSide.left.leavePoint();
            } else {
                frontSide.left.enterPoint() = trunkSide.left.leavePoint();
            }
            // 後方側面
            if (widths.tailSide.left == widths.trunk.left) {
                trunkSide.left.enterPoint() = rearSide.left.enterPoint();
                // 長さを0にします
                rearSide.left.leavePoint() = rearSide.left.enterPoint();
            } else {
                rearSide.left.leavePoint() = trunkSide.left.enterPoint();
            }
        }
        // 右側
        {
            // trunk は最大幅なので一致しなかったらtrunk側に合わせる
            // 前方側面
            if (widths.foreSide.right == widths.trunk.right) {
                trunkSide.right.leavePoint() = frontSide.right.leavePoint();
                // 長さを0にします
                frontSide.right.enterPoint() = frontSide.right.leavePoint();
            } else {
                frontSide.right.enterPoint() = trunkSide.right.leavePoint();
            }
            // 後方側面
            if (widths.tailSide.right == widths.trunk.right) {
                trunkSide.right.enterPoint() = rearSide.right.enterPoint();
                // 長さを0にします
                rearSide.right.leavePoint() = rearSide.right.enterPoint();
            } else {
                rearSide.right.leavePoint() = trunkSide.right.enterPoint();
            }
        }

        // 前コーナー
        frontCorner.left.enterPoint() = frontSide.left.leavePoint();
        frontCorner.right.enterPoint() = frontSide.right.leavePoint();
        // 後コーナー
        rearCorner.left.leavePoint() = rearSide.left.enterPoint();
        rearCorner.right.leavePoint() = rearSide.right.enterPoint();

        // 前蓋
        front.enterPoint() = frontCorner.left.leavePoint();
        front.leavePoint() = frontCorner.right.leavePoint();
        // 後蓋
        rear.enterPoint() = rearCorner.left.enterPoint();
        rear.leavePoint() = rearCorner.right.enterPoint();
    }

    /**
     静的パスセグメント初期化
     
     トラクターを考慮しないパスセグメントのみの幅付き形状を算出する。
     - 作業後の作業範囲などが該当する。矩形である。
     
     @param[in] hw       基準幅の片側
     @param[in] margin   マージン(実形状からのクリアランス)
     */
    void PathExtentLine::initStaticSegment(double hw, double margin) {
        const double leftSide = dimensions.left().getMaxWpWidth();
        const double rightSide = dimensions.right().getMaxWpWidth();
        rearSide.left = getCollateralSegment(org, +leftSide);
        rearSide.right = getCollateralSegment(org, -rightSide);
        // 左だけ使う
        front.enterPoint() = rearSide.left.leavePoint();
        front.leavePoint() = rearSide.right.leavePoint();
        rear.enterPoint() = rearSide.left.enterPoint();
        rear.leavePoint() = rearSide.right.enterPoint();
    }
    
    /**
     境界交差判定(直線)
     
     指定セグメントとBoundaryLineSegmentの各境界セグメントとの交差をチェックする。
     - 現在BPのみ
     
     @param[in] flseg       検査する境界セグメント
     
     @return 交差判定結果
     @retval Intersection::NO　交差なし
     @retval その他            交差あり
     */
    int PathExtentLine::checkIntersection(const BoundaryLineSegment& flseg) const {
        auto lseg = flseg.getSegmentBP();
        return checkIntersection(lseg);
    }

    /**
     境界交差判定(直線セグメント)
     
     指定直線セグメントとの交差をチェックする。
     
     @param[in] flseg       検査する境界セグメント
     
     @return 交差判定結果
     @retval Intersection::NO　交差なし
     @retval その他            交差あり
     */
    int PathExtentLine::checkIntersection(const LineSegment& lseg) const {
        if (lseg.isNegrective()) {
            return Intersection::NO;
        }

        // 左右側面
        if (frontSide.left.checkIntersection(lseg)  != Intersection::NO) { return 0x0031; }
        if (frontSide.right.checkIntersection(lseg)  != Intersection::NO) { return 0x0032; }
        if (trunkSide.left.checkIntersection(lseg)  != Intersection::NO) { return 0x0043; }
        if (trunkSide.right.checkIntersection(lseg)  != Intersection::NO) { return 0x0044; }
        if (rearSide.left.checkIntersection(lseg)  != Intersection::NO) { return 0x0055; }
        if (rearSide.right.checkIntersection(lseg)  != Intersection::NO) { return 0x0056; }

        // セグメントの移動前方(tail)
        if (flags.test(Flags::Index::FRONT)) {
            // 面取
            if (frontCorner.left.checkIntersection(lseg) != Intersection::NO) { return 0x0021; }
            if (frontCorner.right.checkIntersection(lseg) != Intersection::NO) { return 0x0022; }
        }
        // 平蓋
        if (front.checkIntersection(lseg)  != Intersection::NO) { return 0x0010; }

        // セグメントの移動後方(head)
        if (flags.test(Flags::Index::REAR)) {
            // 面取
            if (rearCorner.left.checkIntersection(lseg)  != Intersection::NO) { return 0x0063; }
            if (rearCorner.right.checkIntersection(lseg) != Intersection::NO) { return 0x0063; }
        }
        // 平蓋
        if (rear.checkIntersection(lseg)  != Intersection::NO) { return 0x0070; }

        // TODO: 本来必要ないはずである
        if (path.checkIntersection(lseg)  != Intersection::NO) { return 0x0100; }

        return Intersection::NO;
    }

    /**
     外形ポリゴン取得
     */
    XY_Polygon PathExtentLine::getPolygon() const {
        XY_Polygon polygon;

        if (!front.isNegrective()) {
            polygon.push_back(front.point1());
            polygon.push_back(front.point2());
        }
        if (!frontCorner.right.isNegrective()) {
            polygon.push_back(frontCorner.right.point2());
            polygon.push_back(frontCorner.right.point1());
        }
        if (!frontSide.right.isNegrective()) {
            polygon.push_back(frontSide.right.point2());
            polygon.push_back(frontSide.right.point1());
        }
        if (!trunkSide.right.isNegrective()) {
            polygon.push_back(trunkSide.right.point2());
            polygon.push_back(trunkSide.right.point1());
        }
        if (!rearSide.right.isNegrective()) {
            polygon.push_back(rearSide.right.point2());
            polygon.push_back(rearSide.right.point1());
        }
        if (!rearCorner.right.isNegrective()) {
            polygon.push_back(rearCorner.right.point2());
            polygon.push_back(rearCorner.right.point1());
        }
        if (!rear.isNegrective()) {
            polygon.push_back(rear.point2());
            polygon.push_back(rear.point1());
        }
        if (!rearCorner.left.isNegrective()) {
            polygon.push_back(rearCorner.left.point1());
            polygon.push_back(rearCorner.left.point2());
        }
        if (!rearSide.left.isNegrective()) {
            polygon.push_back(rearSide.left.point1());
            polygon.push_back(rearSide.left.point2());
        }
        if (!rearSide.left.isNegrective()) {
            polygon.push_back(rearSide.left.point1());
            polygon.push_back(rearSide.left.point2());
        }
        if (!trunkSide.left.isNegrective()) {
            polygon.push_back(trunkSide.left.point1());
            polygon.push_back(trunkSide.left.point2());
        }
        if (!frontSide.left.isNegrective()) {
            polygon.push_back(frontSide.left.point1());
            polygon.push_back(frontSide.left.point2());
        }
        if (!frontCorner.left.isNegrective()) {
            polygon.push_back(frontCorner.left.point1());
            polygon.push_back(frontCorner.left.point2());
        }
        return polygon;
    }

    /**
     境界交差判定(直線セグメント)
     
     @return 交差判定結果
     @retval Intersection::NO　交差なし
     @retval その他            交差あり
     */
    string to_svgpath(const XY_Point& p) {
        std::stringstream ss;
        ss << std::fixed << std::setprecision(7)
            << p.x << ", " << -p.y;

        return ss.str();
    }
    
//    string to_svgpath(const LineSegment& lseg) {
//        std::stringstream ss;
//        ss  << "M\t" << to_svgpath(lseg.point1()) << EOL
//            << "L\t" << to_svgpath(lseg.point2());
//
//        return ss.str();
//    }
    
    string PathExtentLine::to_svg(const string& classname) const {
        std::stringstream ss;
        ss  << std::fixed << std::setprecision(7) << EOL
            << "<path " << "class=\"" << classname << "\" d=\"" << EOL;
        // ORG segment
        if (!org.isNull()) {
            ss  << Svg::to_path_d(org) << EOL;
        }
        if (!body.isNull()) {
            ss  << Svg::to_path_d(body) << EOL;
        }
        if (!path.isNull()) {
            ss  << Svg::to_path_d(path) << EOL;
        }

        // left side
        if (!frontSide.left.isNull()) {
            ss  << Svg::to_path_d(frontSide.left) << EOL;
        }
        if (!trunkSide.left.isNull()) {
            ss  << Svg::to_path_d(trunkSide.left) << EOL;
        }
        if (!rearSide.left.isNull()) {
            ss  << Svg::to_path_d(rearSide.left) << EOL;
        }

        // rear (enter point)
        if (!rear.isNull()) {
            ss  << Svg::to_path_d(rear)  << EOL;
        }
        if (!rearCorner.left.isNull()) {
            ss << Svg::to_path_d(rearCorner.left) << EOL;
        }
        if (!rearCorner.right.isNull()) {
            ss << Svg::to_path_d(rearCorner.right) << EOL;
        }
        
        // right side
        if (!frontSide.right.isNull()) {
            ss  << Svg::to_path_d(frontSide.right) << EOL;
        }
        if (!trunkSide.right.isNull()) {
            ss  << Svg::to_path_d(trunkSide.right) << EOL;
        }
        if (!rearSide.right.isNull()) {
            ss  << Svg::to_path_d(rearSide.right) << EOL;
        }
        
        // front (leave point)
        if (!front.isNull()) {
            ss << Svg::to_path_d(front)  << EOL;
        }
        if (!frontCorner.left.isNull()) {
            ss << Svg::to_path_d(frontCorner.left)  << EOL;
        }
        if (!frontCorner.right.isNull()) {
            ss << Svg::to_path_d(frontCorner.right) << EOL;
        }
        ss << "\"/>" << EOL;
        
        return ss.str();
    }

#pragma mark - PathExtentArc
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathExtentArc"
    /**
     PathExtentArcクラス コンストラクタ
     
     境界交差判定用パスセグメントコンストラクタ
     - 対BPにしか使用しない。HPに対しては交差が防げないからである。
     
     @param[in] aseg    カーブセグメント
     @param[in] gauge   パス限界値
     */
    PathExtentArc::PathExtentArc(const ArcSegment& aseg, const Gauge& gauge) :
        PathExtentArc(aseg)
    {
        LOGD(LOG_TAG "::PathExtentArc()", "point distance:%g, lPos distance:%g, radius:%g",
             aseg.Circ.center.distance(aseg.enterPoint()), aseg.Circ.center.distance(aseg.leavePoint()), aseg.Circ.radius);
        clearance = gauge.clearance.BP;
//        PGASSERT(aseg.Circ.isContact(aseg.point1()), ErrorCode::PathGeneration::FATAL);
//        PGASSERT(aseg.Circ.isContact(aseg.point2()), ErrorCode::PathGeneration::FATAL);

        if (gauge.implement.widthOffset != 0.0) {
            // オフセット有り
            // - 旋回方向により異なるので常に再計算
            Gauge::CurveParam cp = gauge.getCurveParamSBD(aseg.Circ.radius, aseg.Circ.orient);
            initStatic(cp);
        } else {
            // オフセット無し
            if (aseg.Circ.radius == gauge.turnRadius) {
                // 旋回半径が標準値
                initStatic(gauge.getCurveParamSBD(aseg.Circ.radius, aseg.Circ.orient));
            } else if (aseg.Circ.radius == gauge.curveConcave.turnRadius) {
                // 旋回半径が凹角用である
                initStatic(gauge.curveConcave.getCurveParamSBD());
            } else {
                // 旋回半径が標準値でないので再計算
                Gauge::CurveParam cp = gauge.getCurveParamStd(org.Circ.radius, aseg.Circ.orient);
                cp = gauge.addClearance(cp, clearance);
                initStatic(cp);
            }
        }
        
        LOGV(LOG_TAG, "\n%s", to_svg("PathExtentArc").c_str());
    }
    
    /**
     外形初期化
     
     指定に従って外形をは初期化する。コンストラクタのヘルパー。
     - 現在は静的パス外形のみ。すなわちトラクターの前後のはみ出しは考えない
     
     @param[in] cp カーブ外形パラメータ
     */
    void PathExtentArc::initStatic(const Gauge::CurveParam& cp) {
        if (org.direction == SegmentDir::FORWARD) {
            outer.setRadius(cp.outerRadius);
            inner.setRadius(cp.innerRadius);
        } else {
            outer.setRadius(cp.innerRadius);
            inner.setRadius(cp.outerRadius);
        }

        // 前後蓋
        front.point1() = inner.point2();
        front.point2() = outer.point2();
        rear.point1() = inner.point1();
        rear.point2() = outer.point1();
    }
    
    /**
     境界交差判定(直線)
     
     指定セグメントとFieldLineSegmentの各境界セグメントとの交差をチェックする。
     - カーブはBPのみ
     
     @param[in] flseg       検査する境界セグメント
     
     @return 交差判定結果
     @retval Intersection::NO　交差なし
     @retval その他            交差あり
     */
    int PathExtentArc::checkIntersection(const BoundaryLineSegment& flseg) const {
        auto lseg = flseg.getSegmentBP();
        return checkIntersection(lseg);
    }
    
    /**
     交差判定(直線)
     
     @param[in] lseg       検査するLineSegment
     
     @return 交差判定結果
     @retval Intersection::NO　交差なし
     @retval その他            交差あり
     */
    int PathExtentArc::checkIntersection(const LineSegment& lseg) const {
        if (org.isNegrective()) {
            return Intersection::NO;
        }
        
        if (outer.checkIntersection(lseg) != Intersection::NO) { return 0x0002; }
        if (inner.checkIntersection(lseg) != Intersection::NO) { return 0x0001; }
        if (front.checkIntersection(lseg) != Intersection::NO) { return 0x0011; }
        if (rear.checkIntersection(lseg)  != Intersection::NO) { return 0x0021; }
        
        return Intersection::NO;
    }

    string to_svgpath(const ArcSegment& arc) {
        Vector2D ve{arc.Circ.center, arc.point1()};
        Vector2D vl{arc.Circ.center, arc.point2()};
        const int largeArc = int(signbit(ve.getCrossProduct(vl)) != signbit(arc.Circ.orient));
        const int sweep = signbit(arc.Circ.orient);
        
        std::stringstream ss;
        ss  << std::fixed << std::setprecision(5)
        << "" << to_svgpath(arc.point1())
        << " A" << arc.Circ.radius << "," << arc.Circ.radius
        << " 0"
        << " " << largeArc << "," << sweep
        << " " << to_svgpath(arc.point2());
        
        return ss.str();
    }
    
    string PathExtentArc::to_svg(const string& classname) const {
        std::stringstream ss;
        ss  << std::fixed << std::setprecision(5)
            << "<path " << "class=\"" << classname << "\" d=\"" << EOL
            << "M\t" << to_svgpath(inner.point1()) << EOL
            << "L\t" << to_svgpath(outer) << EOL
            << "L\t" << to_svgpath(inner.point2()) << EOL
            << "M\t" << to_svgpath(inner) << EOL
            << "\"/>" << EOL;
        
        return ss.str();
    }

#pragma mark - WorkPathExtentLine
#undef LOG_TAG
#define LOG_TAG "PathPlan::WorkPathExtentLine"
    /**
     作業耕跡外形クラス コンストラクタ
     @param[in] lseg    直線セグメント
     @param[in] gauge   パス限界値
     @param[in] aflags  ターゲット境界フラグ
     */
    WorkPathExtentLine::WorkPathExtentLine(const LineSegment& lseg, const Gauge& gauge) :
        PathExtentLine(lseg)
    {
        flags = Flags{0};
        dimensions = gauge.entireDimension;
        const auto clearance = gauge.clearance.RSE; // 現在対作業済み領域用固定

        const double leftSide = dimensions.left().getMaxWpWidth() + clearance;
        const double rightSide = dimensions.right().getMaxWpWidth() + clearance;
        trunkSide.left = getCollateralSegment(body, +leftSide);
        trunkSide.right = getCollateralSegment(body, -rightSide);
        front.point1() = trunkSide.left.point1();
        front.point2() = trunkSide.right.point1();
        rear.point1() = trunkSide.left.point2();
        rear.point2() = trunkSide.right.point2();

        LOGV(LOG_TAG, "\n%s", to_svg("WorkPathExtentLine").c_str());
    }

#pragma mark - FootPrintExtentLine
#undef LOG_TAG
#define LOG_TAG "PathPlan::FootPrintExtentLine"
    /**
     直線移動底面外形クラス コンストラクタ
     
     移動底面外形を生成する
     - ヒッチアップ可能かどうかを判断しセグメント移動時の底面形状の合成を得る。
       踏み荒らし判定に使用する。
     
     @param[in] lseg    直線セグメント
     @param[in] gauge   パス限界値
     @param[in] aflags  ターゲット境界フラグ
     */
    FootPrintExtentLine::FootPrintExtentLine(const LineSegment& lseg, const Gauge& gauge) :
        PathExtentLine(lseg)
    {
        dimensions = gauge.entireDimension;
        const auto clearance = gauge.clearance.RSE; // 現在対作業済み領域用固定
        const double enterLen = 0.0; // gauge.tractor.lumbarLength;
        const double leaveLen = 0.0; // gauge.tractor.shoulderLength;

        flags.set(Flags::Index::FRONT);
        flags.set(Flags::Index::REAR);

        double leftSide = clearance;
        double rightSide = clearance;
        if (gauge.tractor.variableFootPrint) {
            // バック可能時ヒッチアップしている前提
//            initKinetic(gauge.halfTractorWidth, gauge.halfTractorWidth, enterLen, leaveLen, clearance);
            // パスセグメント本体(始点GNSS - 終点GNSS間)の左右
            leftSide = dimensions.left().maxWidthT();
            rightSide = dimensions.right().maxWidthT();
        } else {
//            initKinetic(gauge.halfActWidth, gauge.halfTractorWidth, enterLen, leaveLen, clearance);
            leftSide = dimensions.left().maxWidthTI();
            rightSide = dimensions.right().maxWidthTI();
        }
        trunkSide.left = getCollateralSegment(body, +leftSide);
        trunkSide.right = getCollateralSegment(body, -rightSide);
        front.point1() = trunkSide.left.point1();
        front.point2() = trunkSide.right.point1();
        rear.point1() = trunkSide.left.point2();
        rear.point2() = trunkSide.right.point2();
        
        LOGV(LOG_TAG, "\n%s", to_svg("FootPrintExtentLine").c_str());
    }

#pragma mark - FootPrintExtentArc
#undef LOG_TAG
#define LOG_TAG "PathPlan::FootPrintExtentArc"
    /**
     カーブ移動底面外形クラス コンストラクタ
     
     カーブ移動時の底面外形を生成する
     - ヒッチアップ可能かどうかを判断しセグメント移動時の底面形状の合成を得る。
     - 作業済みセグメントの踏み荒らし判定に使用する。対BPの判定に使用してはいけない。
     
     @param[in] aseg    カーブセグメント
     @param[in] gauge   パス限界値
     */
    FootPrintExtentArc::FootPrintExtentArc(const ArcSegment& aseg, const Gauge& gauge) :
        PathExtentArc(aseg)
    {
        const auto clearance = gauge.clearance.RSE; // 現在対作業済み領域用固定
        const auto radius = org.Circ.radius;
        
        Gauge::CurveParam cp;
        if (gauge.permitBackward) {
            // ヒッチアップしている
            if (radius == gauge.turnRadius) {
                // 旋回半径標準値
                cp = gauge.getCurveParamBare();
            } else if (radius == gauge.curveConcave.turnRadius) {
                // 旋回半径が凹角用である
                cp = gauge.curveConcave.getCurveParamBare();
            } else {
                // 旋回半径非標準値なので再計算
                cp = gauge.getCurveParamBare(radius);
            }
        } else {
            // ヒッチアップしていない
            if (radius == gauge.turnRadius) {
                // 旋回半径標準値
                cp = gauge.getCurveParamStd();
            } else if (radius == gauge.curveConcave.turnRadius) {
                // 旋回半径が凹角用である
                cp = gauge.curveConcave.getCurveParamStd();
            } else {
                // 旋回半径非標準値なので再計算
                cp = gauge.getCurveParamStd(radius);
            }
        }
        // クリアランスを加える
        cp = gauge.addClearance(cp, clearance);
        
        initStatic(cp);
        
        LOGV(LOG_TAG, "\n%s", to_svg("FootPrintExtentArc").c_str());
    }

#pragma mark - free functions
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathExtent"

    /**
     フットプリント同士の交差判定
     */
    int checkIntersection(const PathExtentLine& lhs, const PathExtentLine& rhs) {
        if (lhs.checkIntersection(rhs.trunkSide.left)   != Intersection::NO) { return 0x0001; }
        if (lhs.checkIntersection(rhs.trunkSide.right)  != Intersection::NO) { return 0x0002; }
        if (lhs.checkIntersection(rhs.front)  != Intersection::NO) { return 0x0011; }
        if (lhs.checkIntersection(rhs.rear)  != Intersection::NO) { return 0x0021; }
        
        return Intersection::NO;
    }

    /**
     耕跡に対する踏み荒らし判定
     */
    int checkIntersection(const WorkPathExtentLine& lhs, const PathExtentLine& rhs) {
        if (lhs.checkIntersection(rhs.trunkSide.left)   != Intersection::NO) { return 0x0001; }
        if (lhs.checkIntersection(rhs.trunkSide.right)  != Intersection::NO) { return 0x0002; }
        if (lhs.checkIntersection(rhs.front)  != Intersection::NO) { return 0x0011; }
        if (lhs.checkIntersection(rhs.rear)  != Intersection::NO) { return 0x0021; }
        
        return Intersection::NO;
    }

    int checkIntersection(const PathExtentArc& lhs, const PathExtentLine& rhs) {
        return rhs.checkIntersection(lhs.org);
    }

//    std::string dump(const PathExtentLine& pe) {
//        std::stringstream ss;
//        ss <<
//            pe.side.left.point1()   << pe.side.left.point2()   <<
//            pe.side.right.point1()  << pe.side.right.point2()  <<
//            pe.rear2.left.point1()  << pe.rear2.left.point2()  <<
//            pe.rear2.right.point1() << pe.rear2.right.point2() <<
//            pe.rear1.left.point1()  << pe.rear1.left.point2()  <<
//            pe.rear1.right.point1() << pe.rear1.right.point2() <<
//            pe.front.left.point1()  << pe.front.left.point2()  <<
//            pe.front.right.point1() << pe.front.right.point2();
//
//        return ss.str();
//    }


}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 @file PathExtent.hpp
 
 パス検証用外形クラス
 */
#pragma once

#include "Gauge.hpp"
#include "Segment.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;
    /**
     パス外形ベースクラス
     */
    struct PentaLines {
        PentaLines() = default;
        PentaLines(const PentaLines&) = default;
        PentaLines(const LineSegment& lseg) :
            right(lseg), left(lseg)
        {}
        
        LineSegment right;
        LineSegment left;
    };
    
    /**
     パスセグメント外形(直線)クラス
     
     直線セグメントの交差判定用多角形を保持するクラス
     - GNSS位置より前方に出てはいけない。
     */
    struct PathExtentLine {
        // 交差判定用フラグ
        // 他のstd::bitset<4>に間違って代入できないようにprivate継承
        class Flags  : private std::bitset<4>
        {
            using super = std::bitset<4>;

        public:
            enum Index : unsigned int {
                RAW,        ///< 直線セグメントのみ
                SIDE,       ///< 左右クリアランス
                FRONT,      ///< 前方クリアランス(移動方向ではない)
                REAR        ///< 後方クリアランス(移動方向ではない)
            };
            
            struct Mask {
                constexpr static unsigned int BP        = 1u << Index::RAW;         ///< 直線パスセグメントのみ
                constexpr static unsigned int SIDE      = 1u << Index::SIDE;        ///< 左右クリアランス
                constexpr static unsigned int FRONT     = 1u << Index::FRONT;       ///< 前方クリアランス(移動方向ではない)
                constexpr static unsigned int REAR      = 1u << Index::REAR;        ///< 後方クリアランス(移動方向ではない)
                constexpr static unsigned int DEFAULT   = (BP | SIDE | FRONT);      ///< デフォルト(前進用五角形)
            };
            
            Flags() : super(Mask::DEFAULT) {};
            Flags(unsigned int flags) : super(flags) {};
            Flags(const BoundaryType::Kind::Set& boundaryType)
            {
                // 交差検査対象によって形状を変える場合ここに処理を追加する
                if (boundaryType.test(BoundaryType::Kind::Index::SBP)) {
                    // SBPは両サイドのBPクリアランスチェック(を意図したが実際にはデフォルトで行われる)
                    set(Index::RAW);
                    set(Index::SIDE);
                }
            }

            using super::set;
            using super::reset;
            using super::test;
            using super::any;
            using super::operator|=;
        };
        
        PathExtentLine() = default;
        PathExtentLine(const PathExtentLine& pe) = default;
        PathExtentLine(const LineSegment& lseg) :
            org(lseg), body(lseg), path(lseg)
        {}
        PathExtentLine(const LineSegment& lseg, const Gauge& gauge, BoundaryType::Kind::Set aflags = BoundaryType::Kind::FOR_DEFAULT);

        struct WidthArray {
            WidthArray(const Gauge::EntireDimensions& aDims, double margin) {
                const auto& left = aDims.left();
                const auto& right = aDims.right();
                // 前方端
                // - 作業機はトラクターより狭い可能性があるので、トラクターまたは作業機のどちらか大きい方。作業機が無い場合も含む。
                prow.left = left.front.getMaxTI().width;
                prow.right = right.front.getMaxTI().width;
                // 前方側面
                // - 前方端に安全マージンを加えたもの
                foreSide.left = prow.left + margin;
                foreSide.right = prow.right + margin;
                // 後方端
                // - 作業機はトラクターより狭い可能性があるので、トラクターまたは作業機のどちらか大きい方。
                tail.left = left.rear.getMaxTI().width;
                tail.right = right.rear.getMaxTI().width;
                // 後方側面
                // - 後方端に安全マージンを加えたもの
                tailSide.left = tail.left + margin;
                tailSide.right = tail.right + margin;
                // 基幹部側面+マージン
                // - パス本体範囲の側面。BPとの衝突境界なので最大幅。作業幅ではない。
                trunk.left = left.getMaxTI().width + margin;
                trunk.right = right.getMaxTI().width + margin;
            }
            
            struct Rateral {
                double left = 0.0;
                double right = 0.0;
            };
            
            Rateral prow;
            Rateral foreSide;
            Rateral trunk;
            Rateral tailSide;
            Rateral tail;
        };

        void initKinetic(double hw, double htw, double enterExtend, double leaveExtend, double margin);
        void initKineticForward(double margin);
        void initKineticBackward(double margin);
        void initKineticImpl(const WidthArray& widths);
        void initStaticSegment(double hw, double margin = 0.0);

        int checkIntersection(const BoundaryLineSegment& flseg) const;
        int checkIntersection(const LineSegment& lseg) const;

        XY_Polygon getPolygon() const;
        
        string to_string() const;
        virtual string to_svg(const string& classname = "") const;

        LineSegment org;    // 元のパスセグメント
        LineSegment body;   // トラクター前後端までを含むセグメント
        LineSegment path;   // 前後マージン込みパスセグメント
        
        // セグメント外形本体
        LineSegment front;
        PentaLines frontCorner;
        PentaLines frontSide;
        PentaLines trunkSide;
        PentaLines rearSide;
        PentaLines rearCorner;
        LineSegment rear;
        
        Gauge::EntireDimensions dimensions;
        double clearance = 0.0;
        Flags flags;
    };
    
    /**
     パスセグメント外形(カーブ)クラス
     
     カーブセグメント交差判定用扇型を保持するクラス
     */
    struct PathExtentArc {
        PathExtentArc() = default;
        PathExtentArc(const PathExtentArc& pe) = default;
        PathExtentArc(const ArcSegment& aseg) :
            org(aseg), inner(aseg), outer(aseg)
        {}
        PathExtentArc(const ArcSegment& aseg, const Gauge& gauge);

        void initStatic(const Gauge::CurveParam& cp);

        int checkIntersection(const BoundaryLineSegment& flseg) const;
        int checkIntersection(const LineSegment& lseg) const;

        string to_svg(const string& classname = "") const;
        
        ArcSegment org;     // 元のパスセグメント
        ArcSegment inner;   // 旋回外径セグメント
        ArcSegment outer;   // 旋回内径セグメント
        LineSegment front;   // 前方蓋
        LineSegment rear;    // 後方蓋
        
        double clearance = 0.0;
    };

    /**
     作業パスセグメント外形クラス
     
     作業パスセグメント交差判定用外形を保持する
     */
    struct WorkPathExtentLine : public PathExtentLine {
        constexpr static double tolMargin = 0.0;

        WorkPathExtentLine() = default;
        WorkPathExtentLine(const WorkPathExtentLine&) = default;
        WorkPathExtentLine(const LineSegment& lseg, const Gauge& gauge);
    };

    /**
     パスセグメントフットプリント外形クラス
     
     トラクターがパスセグメントを移動したとき踏む範囲の外形を保持する
     */
    struct FootPrintExtentLine : public PathExtentLine {
        FootPrintExtentLine() = default;
        FootPrintExtentLine(const FootPrintExtentLine&) = default;
        FootPrintExtentLine(const LineSegment& lseg, const Gauge& gauge);
    };

    /**
     パスセグメントフットプリント外形クラス(カーブ)
     
     トラクターがパスセグメントを移動したとき踏む範囲の外形を保持する
     */
    struct FootPrintExtentArc : public PathExtentArc {
        FootPrintExtentArc() = default;
        FootPrintExtentArc(const FootPrintExtentArc&) = default;
        FootPrintExtentArc(const ArcSegment& aseg, const Gauge& gauge);
    };

    // パス外形同士の交差検査
    int checkIntersection(const PathExtentLine& lhs, const PathExtentLine& rhs);
    int checkIntersection(const WorkPathExtentLine& lhs, const PathExtentLine& rhs);
    int checkIntersection(const PathExtentArc& lhs, const PathExtentLine&  rhs);
    inline static
    int checkIntersection(const PathExtentLine&  lhs, const PathExtentArc& rhs) { return checkIntersection(rhs, lhs); }

    std::string dumpToSvg();
}} // namespace yanmar::PathPlan

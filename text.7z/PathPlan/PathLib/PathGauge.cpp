// Yanmar Confidential 20200918
/**
 @file Gauge.cpp
 
 パス生成ゲージクラス
 */

#include "PathGauge.hpp"

#include <cassert>

#include "PathLib.h"
#include "PathExtent.hpp"

namespace yanmar { namespace PathPlan {
    using namespace std;
    
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathGauge"
    
    /**
     バックターン寸法
     
     指定の2線分間に構成するバックターンに必要なBPまでのマージン幅をそれぞれの線分ごとに返す。
     - 幅は与えられた線分からの距離。
     - seg1とseg2が構成するターンの方向が指定の周回方向と一致する場合(凸角)はターン外側の幅を返す。そうでなければ(凹角)ターン内側の幅を返す。
        - バックターンの寸法なので内側の幅は指定線分の条件によらず一定値である。
     @param[in] seg1    ターン進入側線分
     @param[in] seg2    ターン脱出側線分
     @param[in] rotation  周回方向　{CLOCKWISE|ANTICLOCKWISE}
     @return バックターンに必要なマージン幅の組(tulple<seg1側の幅, seg2側の幅>)
     */
    std::tuple<double, double> PathGauge::getAlphaTurnMargins(const GeoSegment& seg1, const GeoSegment& seg2, int rotation) const {
        LineSegment eSeg{seg1};
        LineSegment lSeg{seg2};
        double eMargin = 0.0;
        double lMargin = 0.0;

        const int cornerOrient = offsetSign(eSeg.getCrossProduct(lSeg));    // ターンの旋回方向
        if (rotation == cornerOrient) {
            const auto& path = pathAssemblerIf.getBackTurnPath(eSeg, lSeg, WhiskerMode::NONE);
            for (auto seg : path) {
                if (seg.segmentType == SegmentType::LINESEG) {
                    seg.direction = LineSegment::REVERSE;
                    PathExtentLine pel{seg, gauge, BoundaryType::Kind::Mask::SBP};
                    const auto points = pel.getPolygon();
                    for (const auto& p : points) {
                        auto cpe = eSeg.getCrossProduct(LineSegment{eSeg.leavePoint(), p});
                        if (cornerOrient != offsetSign(cpe)) {
                            const double d = eSeg.distance(p);
                            eMargin = std::max(eMargin, d);
                        }
                        auto cpl = lSeg.getCrossProduct(LineSegment{lSeg.leavePoint(), p});
                        if (cornerOrient != offsetSign(cpl)) {
                            const double d = lSeg.distance(p);
                            lMargin = std::max(lMargin, d);
                        }
                    }
                } else if (seg.segmentType == SegmentType::ARCSEG) {
                    // TODO: 現在カーブセグメントは見ていない
                    // PathExtentArc pea{seg, gauge};
                }
            }
        } else {
            const auto dim = (cornerOrient == RotateDirection::CLOCKWISE) ? gauge.entireDimension.right() : gauge.entireDimension.left();
            const auto maxf = dim.front.getMaxTI();
            const auto maxr = dim.rear.getMaxTI();
            eMargin = lMargin = std::max(maxf.width, maxr.width) + gauge.clearance.BP;
        }
        
        return std::tuple<double, double>(eMargin, lMargin);
    }

    /**
     
     */
    std::tuple<double, double> PathGauge::getMaxAlphaTurnMergins(const std::vector<XY_Point>& polygon, int rotation) const
    {
        std::tuple<double, double> maxMargins{0.0, 0.0};
        double& eMargin = get<0>(maxMargins);
        double& lMargin = get<1>(maxMargins);

        auto edgeList = getEdgeList(polygon, polygon.cbegin());
        if (rotation == RotateDirection::ANTICLOCKWISE) {
            reverse(edgeList);
        }
        // 各コーナーを作る
        for (auto it = edgeList.begin(); it != edgeList.end(); ++it) {
            auto it1 = next(it);
            if (it1 == edgeList.end()) {
                break;
            }
            
            const auto& seg0 = *it;
            const auto& seg1 = *it1;
            GeoSegment eSeg{seg0.enterPoint(), seg0.leavePoint()};
            GeoSegment lSeg{seg1.enterPoint(), seg1.leavePoint()};

            if (seg0.checkConnection(seg1) == Line::Connection::SMOOTH) {
                // 一直線上にある場合、ターンは生成しない
            } else {
                // コーナーでターンパス生成
                auto margins = getAlphaTurnMargins(eSeg, lSeg, rotation);
                eMargin = std::max(eMargin, get<0>(margins));
                lMargin = std::max(lMargin, get<1>(margins));
            }
        }
        
        return std::tuple<double, double>(eMargin, lMargin);
    }
    
    
    /**
     最小枕地幅を返す
     
     パスプランへの入力データのうち、トラクター、作業機、作業設定のパラメータにより算出できる必要な枕地幅を返す。
     考慮するパラメータは以下の通り。
     - ターン用BPクリアランス
         - オフセット対応のため、時計回りと反時計回りで幅が異なる。
         - 凹角がある場合はターン内径と外径の大きい方を採用
     - ターンに必要な幅(ここでは高さ方向)
         - バック可能な場合:フィッシュテールターン
         - バック可能作業機で外周作業がある場合:αターン
         - バック不可の場合に外周作業がある場合:フックターン
     - ヒッチアップ・ダウンマージン
     
     @param[in] rotaiton    周回方向
     @return 枕地幅
     */
    double PathGauge::getHeadlandWidth(int rotation) const {
        
        // ターン用BPクリアランス
        // double hWidth = std::max(gauge.getOuterRadius(gauge.turnRadius, rotation), gauge.getInnerRadius(gauge.turnRadius, rotation)) + gauge.minSpsLegLength + gauge.clearance.BP;
        // 現状唯一の呼出元であるFieldPolygonは、外周作業の最小枕地幅が欲しい。上の計算式が含まれていると都合が悪いためコメントアウト
        double hWidth = 0;
        // フックターン対応の場合カーブを追加
        if (gauge.headland.process != Param::Work::Headland::Process::NOP && !gauge.headland.permitBackward) {
            hWidth = std::max(gauge.getOuterRadius(gauge.turnRadius) + (gauge.turnRadius * 2.0) + gauge.minFpsLegLength + gauge.fpGauge.whpDiff + gauge.clearance.BP + TOL_ONE_CM, hWidth);
        }
        // アルファターン幅
        GeoPoint enter{0.0, -1.0};
        GeoPoint corner{0.0, 0.0};
        GeoPoint leave{rotation * -1.0, 0.0};
        GeoSegment eSeg{enter, corner};
        GeoSegment lSeg{corner, leave};
        double a0, a1;
        std::tie(a0, a1) = getAlphaTurnMargins(eSeg, lSeg, rotation);
        const double alpha = std::max(a0, a1);

        // 大きい方採用
        double d = std::max(hWidth, alpha);

        // ヒッチアップダウンマージン
        d += gauge.workPath.compensateLength;
        // オーバーラップ幅
        // - 最内周がHP(WHP)とオーバーラップ指定量重なるように減らす
        d -= gauge.workPath.overlap;
        // 誤差余裕
        d += 0.5 + TOL_TEN_CM;

        return d;
    }

}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 @file Gauge.hpp
 
 パス生成ゲージクラス
 */
#pragma once

#include <string>

#include "PathPlanIF.hpp"
#include "PolyLib/Context.hpp"
#include "Gauge.hpp"
#include "PathAssembler.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;
    
    /**
     パス形状計測クラス
     */
    class PathGauge {
    public:
        PathGauge(ContextIF& aContextIf, const Gauge& aGauge) :
            context(aContextIf),
            gauge(aGauge),
            pathAssemblerIf(aContextIf, aGauge)
        {}
        
        std::tuple<double, double> getAlphaTurnMargins(const GeoSegment& seg1, const GeoSegment& seg2, int orient) const;
        std::tuple<double, double> getMaxAlphaTurnMergins(const std::vector<XY_Point>& polygon, int rotation) const;
        double getHeadlandWidth(int rotation) const;
        
        const ContextIF& context;
        const Gauge& gauge;
        const PathAssemblerIf pathAssemblerIf;
    };

}} // namespace yanmar::PathPlan

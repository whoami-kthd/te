// Yanmar Confidential 20200918
/**
 @file PathValidator.cpp
 
 パス検査クラス
 */
/// @internal @defgroup PathGenerator  PathGenerator interface

//#define TXT_FILE_ENABLE
//#define LOGLEVEL 5

#define ENABLE_OBSTACLE 1

#include "PathGeneratorData.hpp"

#include <cstdlib>
#include <string>
#include <stdexcept>
#include <iostream>
#include <ostream>
#include <utility>

#include "PolyLib/Common.h"
#include "PathPlanConstant.hpp"
#include "PolyLib/PolygonUtil.hpp"
#include "PathLib/PathGeneratorError.hpp"
#include "Geometry/Geometry.hpp"
#include "DataConverter/OutputDataStream.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

namespace  PathGeneratorData{
    using namespace VertexType;

    template<typename T>
    static inline
    std::string to_string(T val) {
        std::stringstream ss;
        ss << val;
        return ss.str();
    }

#pragma mark - TurnPath: an part of path that consist of PathSegment(s)
#undef LOG_TAG
#define LOG_TAG "PathPlan::TurnPath"
    //
    // TurnPath definitions
    //

    /**
     ターンパス更新
     
     指定インデックスのセグメントを更新する。
     インデックスの指す要素にターンパスのサイズが足りない場合は必要な数の要素を自動的に追加する。
     
     @param[in] index 更新する要素インデックス
     @param[in] seg 更新内容セグメント
     @return 実行後のターンパスサイズ
     */
    TurnPath::size_type TurnPath::updateTurnPath(int index, PathSegment&& seg) {
        if (size() <= index) {
            resize(index + 1);
        }
        at(index) = seg;
        
        return (int)size();
    }

    /**
     点セグメント追加
     
     始点のみのセグメントを追加する
     
     @param[in] startPoint 開始点
     @param[in] aDirection トラクター進行方向
     @arg FORWARD 前進
     @arg REVERSE 後退
     @return セグメント追加後のターンパスサイズ
     */
    TurnPath::size_type TurnPath::pushTurnPath(const XY_Point& startPoint, int aDirection) {
        if (!empty()) {
            back().point2() = startPoint;
        }
        emplace_back(startPoint, aDirection);
        
        return (int)size();
    }

    /**
     パスセグメント追加
     
     @param[in] seg パスセグメント
     @return セグメント追加後のターンパスサイズ
     */
    TurnPath::size_type TurnPath::pushTurnPath(const PathSegment& seg) {
        if (!empty()) {
            back().leavePoint() = seg.enterPoint();
        }
        emplace_back(seg);
        
        return (int)size();
    }

    /**
     直線セグメント追加
     
     @param[in] lseg 追加する直線セグメント
     @return セグメント追加後のターンパスサイズ
     */
    TurnPath::size_type TurnPath::pushTurnPath(const LineSegment& lseg) {
        emplace_back(lseg);
        emplace_back(lseg.leavePoint(), lseg.direction);
        
        return (int)size();
    }
    
    /**
     円弧セグメント追加
     
     @param[in] startPoint 開始点
     @param[in] aCircle    ターンサークル
     @param[in] aDirection トラクター進行方向
         @arg FORWARD 前進
         @arg REVERSE 後退
     @return セグメント追加後のターンパスサイズ
     */
    TurnPath::size_type TurnPath::pushTurnPath(const XY_Point& startPoint, const Circle& aCircle, int aDirection) {
        emplace_back(startPoint, aCircle, aDirection);
        
        return (int)size();
    }
    
    /**
     パス全体の追加
     
     @param[in] path 追加するパス
     @return セグメント追加後のターンパスサイズ
     */
    TurnPath::size_type TurnPath::pushTurnPath(const TurnPath& path) {
        if (!empty()) {
            back().leavePoint() = path.getEnterPoint();
        }
        std::move(path.begin(), path.end(), back_inserter(*this));
        
        return (int)size();
    }
    
    /**
     部分パスリスト追加
     PathSpanのリストをターンパスとして追加する。
     @param[in] paths 追加するパスのリスト
     @return セグメント追加後のターンパスサイズ
     */
    TurnPath::size_type TurnPath::pushTurnPath(const vector<PathSpan>& paths) {
        for (const auto& path : paths) {
            pushTurnPath(path.currPath);
        }
        
        return (int)size();
    }

    /**
     部分パスリスト代入
     PathSpanのリストをターンパスとして結合して置き換える。ターンタイプも置き換える
     @param[in] paths 代入する部分パスのリスト
     @return 代入後のターンパスサイズ
     */
    TurnPath::size_type TurnPath::assign(const PathSpanStack& pss) {
        clear();
        turnType = pss.turnType;
        return pushTurnPath(pss);
    }

    /**
     最終セグメント参照
     */
    const PathSegment& TurnPath::lastSegment() const {
        PGASSERT(!empty(), ErrorCode::PathGeneration::FATAL);

        if (!isTerminated()) {
            return back();
        }
        
        if (2 <= size()) {
            auto rit = std::next(crbegin(), 2);
            return *rit;
        }
        
        return PathSegment::nullobj;
    }

    /**
     最終セグメント参照
     */
    PathSegment& TurnPath::lastSegment() {
        return const_cast<PathSegment&>(as_const(*this).lastSegment());
    }

    /**
     ターンパスセグメント取得
     
     ターンパス中の指定のセグメントをGenSegmentで返す。範囲チェックはしない。
     
     @param[in] index ターンパス中のセグメントインデックス
     @return ターンパス中のセグメント
     */
    template<>
    GenSegment TurnPath::getSegment<GenSegment>(int index) const {
        GenSegment seg{at(index)};
        seg.point2() = at(index + 1).point1();
        return seg;
    }

    /**
     ターンパスセグメント取得
     
     ターンパス中の指定のセグメントをLineSegmentで返す。範囲チェックはしない。
     
     @param[in] index ターンパス中のセグメントインデックス
     @return ターンパス中のセグメント
     */
    template<>
    LineSegment TurnPath::getSegment<LineSegment>(int index) const {
        PGASSERT(at(index).segmentType == SegmentType::LINESEG, ErrorCode::PathGeneration::FATAL);
        LineSegment seg{at(index)};
        if ((index + 1) < size()) {
            seg.point2() = at(index + 1).point1();
        }
        return seg;
    }
    
    /**
     ターンパスセグメント取得
     
     ターンパス中の指定のセグメントをArcSegmentで返す。範囲チェックはしない。
     
     @param[in] index ターンパス中のセグメントインデックス
     @return ターンパス中のセグメント
     */
    template<>
    ArcSegment TurnPath::getSegment<ArcSegment>(int index) const {
        PGASSERT(at(index).segmentType == SegmentType::ARCSEG, ErrorCode::PathGeneration::FATAL);
        ArcSegment seg{at(index)};
        seg.point2() = at(index + 1).point1();
        return seg;
    }

    /**
     最終接線取得
     
     末尾の一つ前の要素をLineSegmentとして取得する。(末尾のセグメントではない)
        - 要素数が2未満またはLineSegmentではない場合は不正な結果を返す(ASSERTあり)
     */
    LineSegment TurnPath::getLastTangent() const {
        PGASSERT(2 <= size(), ErrorCode::PathGeneration::FATAL);
        return getSegment<LineSegment>((int)size() - 2);
    }

    /**
     最終セグメント取得
     
     最後の有効なセグメントをGenSegmentとして取得する。
        - 有効なセグメントが無い場合不正な結果を返す(ASSERTあり)
     */
    GenSegment TurnPath::getLastSegment() const {
        PGASSERT(!empty(), ErrorCode::PathGeneration::FATAL);

        if (!isTerminated()) {
            return back();
        }
        
        if (2 <= size()) {
            return getSegment<GenSegment>((int)size() - 2);
        }
        
        return GenSegment::nullobj;
    }

    /**
     空セグメント削除
     
     指定のパスから長さ0のセグメントを削除したパスを生成して返す。
     
     @return 処理済みパス
     */
    TurnPath TurnPath::getNonredundantData() const {
        TurnPath resultPath;
        resultPath.reserve(size());

        if (size() < 2) {
            LOGV(LOG_TAG "::getNonredundantData", "remove result: %d->%d", (int)size(), (int)resultPath.size());
            return resultPath;
        }
        
        for (auto fromIt = cbegin(); fromIt != cend(); advance(fromIt, 1)) {
            auto toIt = next(fromIt);
            if (toIt == cend()) {
                break;
            }
            if (fromIt->point1() != toIt->point1()) {
                // 始点と終点=次セグメント始点が異なる場合のみコピー
                resultPath.push_back(*fromIt);
            } else {
                LOGD(LOG_TAG "::getNonredundantData", "[INFO] remove TurnPath[%d]: %s", (int)distance(cbegin(), fromIt), to_string(*fromIt).c_str());
            }
            
        }
        resultPath.push_back(back());
        
        LOGV(LOG_TAG "::getNonredundantData", "remove result: %d -> %d", (int)size(), (int)resultPath.size());
        return resultPath;
    }
    
    /**
     末尾長
     
     パス末尾の直線セグメントの長さを返す。
        - セグメントが無いか、末尾が直線でない場合は0.0を返す。
     
     @return 長さ
     */
    double TurnPath::terminalLength() const {
        double length = 0.0;
        const auto lTS = getLastSegment();
        if (lTS.segmentType == SegmentType::LINESEG) {
            length = lTS.length();
        }
        
        return length;
    }
    
    /**
     セグメント長
     
     指定範囲のセグメントの長さの合計を返す。
     
     @return 長さ
     */
    double TurnPath::milageAt(TurnPath::const_iterator beginIt, TurnPath::const_iterator endIt) const {
        double d = 0.0;
        for_each(beginIt, cend(), [&d](const PathSegment& seg) { d += seg.length(); } );
        return d;
    }

    /**
     最終接線セグメント検索
     
     @return 接線セグメントを指すiterator(reverse_iteratorではない)
     @retval crend() 見つからない場合
     */
    TurnPath::iterator TurnPath::findLastTangent(int dir) {
        auto rit = find_if(rbegin(), rend(), [dir](const TurnPath::value_type& seg) { return (seg.segmentType == SegmentType::LINESEG && seg.direction == dir); } );
        return (rit != rend()) ? prev(rit.base()) : end();
    }
    
    /**
     末尾短縮
     
     パス末尾を指定長短縮し、指定値と実際に短縮した長さの差を返す。
        - 末尾にある直線セグメントを短縮する。直線の長さが指定値に満たない場合、全体を破棄する
        - 指定値に対し実際の長さが足りない場合は空になり、無効となる(status = INVALID)
        - completeSegment()済みで実行すること
     
     @param[in] trimLen 短縮長
     
     @return 短縮残り
     @retval 正      指定長に対する短縮不足分がある(空になった)
     @retval 0及び負 指定長以上短縮した
     */
    double TurnPath::trimTail(double trimLen) {
        LOGV(LOG_TAG "::trimTail", "(%g)", trimLen);
        
        while (0.0 < trimLen && !empty()) {
            auto& seg = back();
            double len = seg.length();
            if (seg.segmentType != SegmentType::LINESEG) {
                trimLen -= len;
                pop_back();
            } else {
                if (seg.direction != SegmentDir::FORWARD) {
                    // バックのセグメントは短縮長に加えない
                    pop_back();
                } else if (trimLen < len) {
                    // 最終接線が十分長い
                    seg.extendTail(-trimLen);
                    trimLen = 0.0;
                } else {
                    // 最終接線が短い
                    pop_back();
                    trimLen -= len;
                }
            }
        }
        
        if (empty()) {
            clear();
        }
        
        LOGV(LOG_TAG "::trimTail", "rest len = %g", trimLen);
        return trimLen;
    }


    /**
     ターンパス入口調整
     先頭から二つのセグメントがいずれも前進直線セグメントであれば先頭を取り除き、二つ目を短縮する。
     - 先頭セグメントの長さが0になる場合は、何もしない。
     */
    void treatEntrance(TurnPath& turnPath, double termLen) {
        // 非作業パスに続くパス脚は長さに制限は無い
        auto& firstSeg = turnPath.front();
        auto& nextSeg = *std::next(turnPath.cbegin());
        if (SegTest::test(firstSeg, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING) &&
            SegTest::test(nextSeg, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING) && !nextSeg.isNegrective()) {
            turnPath.erase(turnPath.cbegin());
            turnPath.front() = getFromTail(turnPath.front(), termLen);
        }
    }

    /**
     ターンパス出口調整
     複数の前進直線セグメントがある場合は一つを残して取り除く。
     - 最終セグメントの長さが0になる場合は、何もしない。
     */
    void treatExitance(TurnPath& turnPath, double termLen) {
        // 非作業パスに続くパス脚は長さに制限は無い
        auto& lastSeg = turnPath.back();
        auto& prevSeg = *std::next(turnPath.begin());
        if (SegTest::test(lastSeg, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING) &&
            SegTest::test(prevSeg, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING) && !prevSeg.isNegrective()) {
            turnPath.pop_back();
            turnPath.front() = getFromTail(turnPath.back(), termLen);
        }
    }

    /**
     ターンパスログダンプ
     */
    string dumpTurnPath(const TurnPath& turnPath, const char* caption)
    {
        stringstream str;
        str << caption << "\n";
        str << turnPath.size() << " segments.";
        
        for (auto sg : turnPath) {
            switch (sg.segmentType) {
            case SegmentType::LINESEG:
                str << to_string(sg, "\nLINESEG: ");
                break;
            case SegmentType::ARCSEG:
                str << to_string(sg, "\nARCSEG : ");
                break;
            }
        }
        
        return str.str();
    }

#pragma mark - BoundaryPolygon utilities: the polygon was consist of Boundary as vertices.
#undef LOG_TAG
#define LOG_TAG "PathPlan::BoundaryPolygon"
    //
    // BoundaryPolygon utilities
    //

    // 凹角存在確認
    bool hasConcave(const BoundaryPolygon& field) noexcept {
        return std::any_of(field.cbegin(), field.cend(), [](const Boundary& bnd) { return (bnd.CvCnF == VertexType::CONCAVE); });
    }
    
    // 指定ノードID検索
    // constを返す。見つからない場合はend()を返す。
    BoundaryPolygon::iterator findNode(BoundaryPolygon& polygon, int nodeId) {
        BoundaryPolygon::iterator it = find_if(polygon.begin(), polygon.end(),
                                               [nodeId](const Boundary& bnd) {
                                                   return (bnd.nodeIndex == nodeId);
                                               });
        
        return it;
    }
    
    // 指定ノードID検索
    // const_iteratorを返す。見つからない場合はcend()を返す。
    BoundaryPolygon::const_iterator findNode(const BoundaryPolygon& polygon, int nodeId) {
        BoundaryPolygon::const_iterator it = find_if(polygon.cbegin(), polygon.cend(),
                                                     [nodeId](const Boundary& bnd) {
                                                         return (bnd.nodeIndex == nodeId);
                                                     });
        
        return it;
    }

    // 指定ノード座標検索
    // const_iteratorを返す。見つからない場合はcend()を返す。
    BoundaryPolygon::const_iterator findNode(const BoundaryPolygon& polygon, const XY_Point& pos) {
        BoundaryPolygon::const_iterator it = find_if(polygon.cbegin(), polygon.cend(),
                                                     [pos](const Boundary& bnd) {
                                                         return (isIsometric(bnd.HP, pos));
                                                     });
        
        return it;
    }

    /**
     ポリゴンの指定頂点から1周分のBP辺のリストを得る
     */
    vector<LineSegment> getEdgeListBP(const BoundaryPolygon& polygon, const BoundaryPolygon::const_iterator& startIt) {
        vector<LineSegment> edgeList;
        const size_t size = polygon.size();
        BoundaryPolygon::const_iterator it = startIt;
        
        for (size_t i = 0; i < size; i++) {
            auto it1 = nextCyclic(polygon, it);
            edgeList.emplace_back(it->BP, it1->BP);
            it = it1;
        }
        
        return edgeList;
    }
    
    /**
     ポリゴンの指定頂点から1周分のH辺のリストを得る
     */
    vector<LineSegment> getEdgeListHP(const BoundaryPolygon& polygon, const BoundaryPolygon::const_iterator& startIt) {
        vector<LineSegment> edgeList;
        const size_t size = polygon.size();
        auto it = startIt;
        
        for (size_t i = 0; i < size; i++) {
            auto it1 = nextCyclic(polygon, it);
            edgeList.emplace_back(it->HP, it1->HP);
            it = it1;
        }
        
        return edgeList;
    }

#pragma mark - BoundarySet: for handling set of field bondaries (BP, HP)
#undef LOG_TAG
#define LOG_TAG "PathPlan::BoundarySet"
    //
    // BoundarySet definitions
    //
    
    /**
     コンストラクタ
     */
    BoundarySet::BoundarySet(const GeoPolygons& extents, const GeoPolygons& hlps, const HwParam& aHwParam, const Gauge& gauge) :
        BoundarySet()
    {
        LOGV(LOG_TAG "::BoundarySet", "()");
        PGASSERT(0 < extents.size(), ErrorCode::PathGeneration::FATAL);
        
        const int NoBP = (int)extents[0].size();                                                    
        
        // ポリゴンのイテレータ
        auto extpIt = extents.begin();
        auto hlpIt = hlps.begin();
        
        // field boundary
        BoundaryInputIterator it{*extpIt, *hlpIt};
        BoundaryInputIterator endIt = next(it, NoBP);
        int nodeIndex = 0;
        for (;it != endIt; ++it) {
            Boundary boundary = it.boundary(BoundaryType::FIELD, nodeIndex);
            field.push_back(boundary);
            bp().push_back(it.bpValue());
            hp().push_back(it.hpValue());
            nodeIndex++;
            
            if (!it.bp->isFinite()) {
                ErrorPathGenerator err(ErrorCode::PathGeneration::Boundary::BP_COORDINATE_VALUE);
                err.setDescription("[EXCEPTION] A point of BP is not finite:" + to_string(*it.bp), "::BoundarySet");
                throw err;
            }
            if (!it.hp->isFinite()) {
                ErrorPathGenerator err(ErrorCode::PathGeneration::Boundary::HP_COORDINATE_VALUE);
                err.setDescription("[EXCEPTION] A point of HP is not finite:" + to_string(*it.hp), "::BoundarySet");
                throw err;
            }

        }

        // EHP生成
        {
            // 最小枕地設定による作業パス延長(どんつき)分の回避用
            // - HPを平行作業パス拡張した分広げる
            auto& polygon = ehp();
            polygon = hp();
            if (gauge.workPath.leg.type == Param::Work::WorkPath::Leg::Type::FOLD) {
                CyclicIteratorTrain<Polygon> triIt(polygon);
                auto bit = field.begin();
                bit = nextCyclic(field, bit);
                Vector2D sVec{0.0, gauge.workPath.expandLength};
                for (int i = 0; i < polygon.size(); i++) {
                    const auto& prevP = *triIt.prevIt();
                    auto& currP = *triIt.currIt();
                    const auto& nextP = *triIt.nextIt();
                    LineSegment prevEdge{prevP, currP};
                    LineSegment nextEdge{currP, nextP};
                    // 辺の移動向きはポリゴン外側方向で確定しているので、移動量は絶対値にする。
                    const auto pshift = std::abs(prevEdge.getVector().getUnitVector().getCrossProduct(sVec));
                    const auto nshift = std::abs(nextEdge.getVector().getUnitVector().getCrossProduct(sVec));
                    auto prevEdge1 = getCollateralSegment(prevEdge, pshift);
                    auto nextEdge1 = getCollateralSegment(nextEdge, nshift);
                    // 平行検査の許容誤差はFieldPolygon(PolygonUtil)と同じ値を使用する
                    currP = getCrossPoint(prevEdge1, nextEdge1, TOLERANCE_ANGLE);
                    // Boundaryにも書き戻す
                    auto& bnd = *bit;
                    bnd.EHP = currP;
                    bit = nextCyclic(field, bit);
                    triIt++;
                }
            }
            
            if (!aHwParam.whp.empty() &&
                gauge.workPath.pattern == Param::Work::Pattern::SEMICYCLONE &&
                gauge.headland.process != Param::Work::Headland::Process::NOP) {
                // 草刈機識別が容易にできないので半渦巻のみで判定
                auto& polygon = whp();
                polygon.clear();
                polygon = aHwParam.whp;
            } else {
                auto& polygon = whp();
                polygon = hp();
            }
            
//           for (auto p : ehp()) {
//               LOGD(LOG_TAG "::BoundarySet", "EHP: %s", Svg::to_string(p).c_str());
//           }
        }
        
        
#ifdef ENABLE_OBSTACLE
        // 障害物ポリゴンを指す
        ++extpIt;
        ++hlpIt;
        // obstacle boundary
        vector<Boundary> obstacle;
        
        // 障害物は二次元配列
        int index = 0;
        int oIndex = 0;
        for (; extpIt != extents.end(); ++extpIt, ++hlpIt) {
            for (BoundaryInputIterator it{*extpIt, *hlpIt}, endIt = next(it, OBsize); it != endIt; ++it) {
                auto bundary = it.boundary(BoundaryType::OBSTACLE, nodeIndex);
                obstacle.push_back(bundary);
                obp(oIndex).push_back(it.bpValue());
                ohp(oIndex).push_back(it.hpValue());
                index++;
                oIndex = (index / OBsize) + 1;
                nodeIndex++;

                if (!it.bp->isFinite()) {
                    ErrorPathGenerator err(ErrorCode::PathGeneration::Boundary::OBP_COORDINATE_VALUE);
                    err.setDescription("[EXCEPTION] A point of OBP is not finite:" + to_string(*it.bp), "::setFieldData");
                    throw err;
                }
                if (!it.hp->isFinite()) {
                    ErrorPathGenerator err(ErrorCode::PathGeneration::Boundary::OHP_COORDINATE_VALUE);
                    err.setDescription("[EXCEPTION] A point of OHP is not finite:" + to_string(*it.hp), "::setFieldData");
                    throw err;
                }
            }
            obstacles.push_back(obstacle);
        }
#endif // ENABLE_OBSTACLE
    }
    
    /**
     境界エレメメント取得
     
     指定インデックスのboundaryを返す。
     
     @param[in] nodeIndex グラフノード番号=頂点のシリアル番号
     */
    const Boundary& BoundarySet::boundaryAt(int nodeIndex) const
    {
        if (0 <= nodeIndex && nodeIndex < field.size()) {
            return field[nodeIndex];
        } else if (field.size() <= nodeIndex && nodeIndex < (field.size() + obstacles.size() * OBsize)) {
            const int obIndex = (nodeIndex - (int)field.size());
            const int oIndex = obIndex / OBsize;
            const int vIndex = obIndex % OBsize;
            return obstacles[oIndex][vIndex];
        } else {
            return Boundary::nullobj;
        }
    }

    /**
     全交点取得
     
     指定境界の指定線分を直線とみなした交点を返す。
     
     @param[in] seg         セグメント
     @param[in] targetFlag  対象の境界
     @param[in] pred        条件関数
     */
    std::vector<XY_Point> BoundarySet::getCrossPoints_if(const LineSegment& seg, BoundaryType::Kind::Set targetFlag, std::function<bool (const XY_Point&)> pred) const
    {
        std::vector<XY_Point> points;

        for (auto it1 = field.cbegin(); it1 != field.cend(); ++it1) {
            auto it2 = nextCyclic(field, it1);
            FieldLineSegment fls(*it1, *it2);
            LineSegment bndSeg;

            if (targetFlag.test(BoundaryType::Kind::Index::BP)) {
                bndSeg = fls.getSegmentBP();
            } else if (targetFlag.test(BoundaryType::Kind::Index::HP)) {
                bndSeg = fls.getSegmentHP();
            } else if (targetFlag.test(BoundaryType::Kind::Index::EHP)) {
                bndSeg = fls.getSegmentEHP();
            }
            try {
                const auto& px = getCrossPoint(seg, bndSeg);
                if (pred(px)) {
                    points.push_back(px);
                }
            } catch(...) {
                // nop
            }
        }

        return points;
    }

#pragma mark - Parameters for make whiwsker
#undef LOG_TAG
#define LOG_TAG "PathPlan::WhiskerMode_t"
//  none


#pragma mark - HLTCList
#undef LOG_TAG
#define LOG_TAG "PathPlan::HLTCList"
    //
    // HLTCList definitions
    //

    // ターンサークルインデックス定数
    constexpr int HLTCList::MIN_ESCAPE_LEG;
    constexpr int HLTCList::MIN_ESCAPE_LEG_EXT;
    constexpr int HLTCList::MIN_LEG;
    constexpr int HLTCList::MIN_LEG_EXT;

    /**
     HCP挿入
     
     指定indexにHCP要素を挿入する
     - index範囲外の場合は何もしない
     
     @param[in] index	挿入位置対象のインデックス
     @param[in] htc		操作対象のHeadlandTurnCircle
     @return 現在のHCP要素数
     */
    int HLTCList::insert(int index, const HeadlandTurnCircle& htc) {
        PGASSERT(!isInRangeClose(0, index, (int)size()), ErrorCode::PathGeneration::FATAL);
        if (isInRangeClose(0, index, (int)size())) {
            auto it = begin();
            advance(it, index);
            emplace(it, htc);
        }
        
        return (int)size();
    }
    
    /**
     HCPの更新
     
     @param[in] index	更新対象のインデックス
     @param[in] htc		対象対象のHeadlandTurnCircle
     */
    void HLTCList::update(int index, const HeadlandTurnCircle& htc) {
        if ((int)size() <= index) {
            // 無条件でresize()すると減る場合がある
            resize(index + 1);
        }
        // flagsは温存すること
        auto it = std::next(begin(), index);
        auto flags = it->flags;
        *it = htc;
        it->flags = flags;
    }
    
    /**
     HCP更新(FPS)
     
     指定SPSのサークルでHCP中のFPSサークルを更新する
     
     @param[in] fps		更新元のターンサークルを持つSPS
     */
    void HLTCList::update(const PathFPS& fps) {
        update(fpsIndex(), HeadlandTurnCircle{fps.Circ, Boundary::nullobj});
    }
    
    /**
     HCP更新(SPS)
     
     指定SPSのサークルでHCP中のSPSサークルを更新する
     
     @param[in] sps		更新元のターンサークルを持つSPS
     */
    void HLTCList::update(const PathSPS& sps) {
        update(spsIndex(), HeadlandTurnCircle{sps.Circ, Boundary::nullobj});
    }
    
    /**
     HCPの削除
     
     指定indexのHCP要素を削除する
     
     @param[in] index	削除対象のインデックス
     @return 現在のHCP要素数
     */
    int HLTCList::erase(int index) {
        auto it = begin();
        advance(it, index);
        LOGD(LOG_TAG "::eraseHCP", "[Circle skipped] HTP[%d](%d)", index, it->nodeIndex);
        super::erase(it);
        
        return (int)size();
    }
    
    /**
     HCPの削除
     
     startIndexからendIndexまでのHCP要素を削除する。
     
     @param[in] startIndex	削除対象の先頭インデックス
     @param[in] endIndex	削除対象の末尾インデックス(この要素も削除する)
     @return 現在のHCP要素数
     */
    int HLTCList::erase(int startIndex, int endIndex) {
        auto beginIt = begin();
        auto endIt = beginIt;
        advance(beginIt, startIndex);
        advance(endIt, endIndex + 1);
        LOGD(LOG_TAG "::extractHCP", "[Effective Circles] HTP[%d](%d) - HTP[%d](%d)", startIndex, beginIt->nodeIndex, endIndex, endIt->nodeIndex);
        super::erase(beginIt, endIt);
        
        return (int)size();
    }
    
    /**
     HCP範囲抽出
     
     startIndexからendIndexまでのHCP要素のリストを返す
     
     @param[in] srcHcp	抽出対象のHLTCList
     @param[in] begin	抽出対象の先頭インデックス(この要素も取り出す)
     @param[in] end     抽出対象の末尾インデックス(この要素も取り出す)
     @return 取り出したHCPリスト
     */
    HLTCList HLTCList::getClipHCP(const HLTCList& srcHcp, int begin, int end) const {
        HLTCList hcp;
        
        hcp.push_back(srcHcp.front());
        
        for (int index = begin; index <= end; index++) {
            hcp.push_back(srcHcp[index]);
        }
        
        hcp.push_back(srcHcp.back());
        
        return hcp;
    }


#pragma mark - PathFPS
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathFPS"
    //
    // PathFPS definitions
    //
    
    /**
     コンストラクタ
     
     @param[in] enterPoint パスへの進入点
     @param[in] leavePoint パスからの脱出点
     */
    PathFPS::PathFPS(const tData& enterPoint, const tData& leavePoint, double aMinLegLength) :
        WorkPath()
    {
        // 進入点の頂点データ
        point2() = enterPoint.point();
        org.point2() = enterPoint.pointOrg();
        
        // 脱出点の頂点データ
        point1() = leavePoint.point();
        org.point1() = leavePoint.pointOrg();
        
        // 最小パス脚長
        leg.minLength = aMinLegLength;
        if (dotProduct(enterPoint.pointOrg(), leavePoint.pointOrg(), leavePoint.point()) < 0.0) {
            // 縮んでいる時のみ
            leg.orgLength = leavePoint.point().distance(leavePoint.pointOrg());
        } else {
            leg.orgLength = 0.0;
        }

        // 所属作業領域辺
        edge = LineSegment{leavePoint.pointEdge1(), leavePoint.pointEdge2()};
        
        // 作業領域脱出角度
        const Vector2D deltaP = edge.getVector();
        const double angle = abs(deltaP.getAngle());
        angleToEdge = abs(angle - M_PI_2);
        
        // 向き設定
        Dir();
    }

    /**
     後脚長保証
     point2側の脚の最低長を保証する
     @return 設定後のパス脚長
    */
    double PathFPS::ensureMinimalLegLength() {
        LOGV(LOG_TAG "::ensureMinimalLegLength", "()");

        double legLen = getHeadLeg().length();
        const double minLen = leg.minLength;
        if (legLen < minLen) {
            LOGD(LOG_TAG "::ensureMinimalLegLength()", "FPS LEG LENGTH: %g -> %g", legLen, minLen);
            extended = false;
            legLen = minLen;
            setHeadLeg(legLen);
        }
        
        return legLen;
    }

    /**
     FPSターンサークル脚延長
     
     FPSターンサークル位置を目標ターンサークルへ揃える。
     - 目標ターンサークルがSPSのパス脚を延長して代替可能と思われる場合、パス脚をその位置まで延ばす。
     - パス脚延長処理のみであってその結果有効なパスが引けるかどうかは考慮しない。
     - 目標ターンサークルの距離が近くてもパス脚長の最小はminLengthを保証する。
     
     @param[in] htc   目標ターンサークル
     @param[in] gauge 限界値

     @return 処理結果
     @retval SUCCESS 脚延長成功
     @retval FAILURE 脚延長失敗
     */
    int PathFPS::extendLegTo(const HeadlandTurnCircle& htc, const Gauge& gauge) {
        LOGV(LOG_TAG "::extendLegTo", "()");
        
        const Circle& targetCircle = htc.Circ;	// 相手のターンサークル
        Vector2D delta{leavePoint(), targetCircle.center};
        Vector2D lVec = getLeaveVector();
        
        const double len = abs(delta.y) + ((htc.nodeIndex < 0) ? 0 : TOL_ONE_CM);
        if (len <= leg.minLength) {
            // 最小脚長保証により失敗
            LOGV(LOG_TAG "::extendLegTo", "FAILED by MINLENGTH");
            return FAILURE;
        }
        
        if (signbit(delta.y) != signbit(lVec.y)) {
            // 方向が違うので失敗
            LOGV(LOG_TAG "::extendLegTo", "FAILED by DIRECTION");
            return FAILURE;
        }
        
        LOGV(LOG_TAG "::extendLegTo", "deltaX: %g, deltaY: %g", abs(delta.x), abs(delta.y));
        const double radius = targetCircle.radius;
        const double minDistance = (htc.CvCnF == CONCAVE) ? radius : 0.0;  // 凹角の場合中心点は圃場外かもしれないので離れていなくてはならない : 凸角はHPなのでパス脚では踏んでも良い
        const double maxDistance = htc.BP.distance(htc.HP);  // 簡易だが、もし境界に近すぎた場合は検証で失敗すればよい
        const bool matchOrient = (signbit((-getVector()).getCrossProduct(Vector2D{leavePoint(), targetCircle.center})) == signbit((double)targetCircle.orient));    // ターンサークル回転方向との整合
        LOGV(LOG_TAG "::extendLegTo", "deltaX range: [%g, %g], orient:%s", minDistance, maxDistance, to_string(matchOrient).c_str());
        if (0 <= htc.nodeIndex && !(isInRangeClose(minDistance, abs(delta.x), maxDistance) && matchOrient)) {
            // コーナーのとき、ターゲットが範囲内になければ失敗
            LOGV(LOG_TAG "::extendLegTo", "FAILED by OUT_OF_RANGE");
            return FAILURE;
        }
        
        // 直進すると次のターンサークル内に出る場合
        // - FPSの足を伸ばす
        setHeadLeg(len);
        setLeaveTurnCircle(targetCircle.orient, radius);
        extended = true;
        LOGV(LOG_TAG "::extendLegTo", "SUCCESS: FPS leg extended: %s -> HCP[](indx:%d)%s", to_string(Circ.center).c_str(), htc.nodeIndex, to_string(targetCircle.center).c_str());
        
        return SUCCESS;
    }
    
    /**
     次のコーナーへのベクトル取得
     
     旋回方向の判定用であって、接線セグメントのベクトルではない。
     */
    Vector2D PathFPS::getNextCornerVector() const {
        const XY_Point point = (Circ.orient == Circle::Orient::CLOCKWISE) ? edge.point2() : edge.point1();
        return Vector2D{leavePoint(), point};
    }
    
#pragma mark - PathSPS
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathSPS"
    //
    // PathSPS definition
    //
    
    /**
     コンストラクタ
     
     @param[in] enterPoint パスへの進入点
     @param[in] leavePoint パスからの脱出点
     */
    PathSPS::PathSPS(const tData& enterPoint, const tData& leavePoint, double aMinLegLength) :
        WorkPath()
    {
        // 脱出点の頂点
        point2() = leavePoint.point();
        org.point2() = leavePoint.pointOrg();
        
        // 進入点の頂点
        point1() = enterPoint.point();
        org.point1() = enterPoint.pointOrg();

        // 最小パス脚長
        leg.minLength = aMinLegLength;
        if (dotProduct(leavePoint.pointOrg(), enterPoint.pointOrg(), enterPoint.point()) < 0.0) {
            // 縮んでいる時のみ
            leg.orgLength = enterPoint.pointOrg().distance(enterPoint.point());
        } else {
            leg.orgLength = 0.0;
        }

        // 所属作業領域辺
        edge = LineSegment{enterPoint.pointEdge1(), enterPoint.pointEdge2()};
        
        // 作業領域進入角度
        const Vector2D deltaP = edge.getVector();
        const double angle = abs(deltaP.getAngle());
        angleToEdge = abs(angle - M_PI_2);
        
        // 向き設定
        Dir();
    }
    
    /**
     SPSターンサークル脚延長
     
     SPSターンサークル位置を目標ターンサークルへ揃える。
     - 目標ターンサークルがSPSのパス脚を延長して代替可能と思われる場合、パス脚をその位置まで延ばす。
     - 延長処理のみであってその結果有効なパスが引けるかどうかは考慮しない。
     - 目標ターンサークルの距離が近くてもパス脚長の最小はminLengthを保証する。
     
     @param[in] htc   目標ターンサークル
     @param[in] gauge 限界値
     
     @return 処理結果
     @retval SUCCESS 脚延長成功
     @retval FAILURE 脚延長失敗
     */
    int PathSPS::extendLegTo(const HeadlandTurnCircle& htc, const Gauge& gauge) {
        LOGV(LOG_TAG "::extendLegTo", "()");
        
        const Circle& targetCircle = htc.Circ;	// 相手のターンサークル
        Vector2D delta{targetCircle.center, enterPoint()};
        Vector2D eVec = getEnterVector();
        
        const double len = abs(delta.y) + ((htc.nodeIndex < 0) ? 0 : TOL_ONE_CM);
        if (len <= leg.minLength) {
            // 最小脚長保証により失敗
            LOGV(LOG_TAG "::extendLegTo", "FAILED by MINLENGTH");
            return FAILURE;
        }
        
        if (signbit(delta.y) != signbit(eVec.y)) {
            // 方向が違うので失敗
            LOGV(LOG_TAG "::extendLegTo", "FAILED by DIRECTION");
            return FAILURE;
        }
        
        // この計算はターゲットの中心がコーナー頂点であることを前提としている
        const double radius = targetCircle.radius;
        const double minDistance = (htc.CvCnF == CONCAVE) ? radius : 0.0;  // 凹角の内側にマージンは無い : 凸角はHPなのでパス脚上では踏んでも良い
        const double maxDistance = htc.BP.distance(htc.HP);  // 簡易だが、もし境界に近すぎた場合は検証で失敗すればよい
        const bool matchOrient = (signbit(getVector().getCrossProduct(Vector2D{enterPoint(), targetCircle.center})) == signbit((double)targetCircle.orient));    // ターンサークル回転方向との整合
        LOGV(LOG_TAG "::extendLegTo", "deltaX range: [%g, %g]", minDistance, maxDistance);
        if (0 <= htc.nodeIndex && !(isInRangeClose(minDistance, abs(delta.x), maxDistance) && matchOrient)) {
            // コーナーのとき、ターゲットが範囲内になければ失敗
            LOGV(LOG_TAG "::extendLegTo", "FAILED by OUT_OF_RANGE");
            return FAILURE;
        }
        
        // SPSの足を伸ばす
        setHeadLeg(len);
        setEnterTurnCircle(targetCircle.orient, radius);
        extended = true;
        LOGV(LOG_TAG "::extendLegTo", "SUCCESS: SPS leg extended: HCP[](indx:%d)%s -> %s", htc.nodeIndex, to_string(targetCircle.center).c_str(), to_string(Circ.center).c_str());
        
        return SUCCESS;
    }

    /**
     前コーナーからのベクトル取得
     
     旋回方向の判定用であって、接線セグメントのベクトルではない。
     */
    Vector2D PathSPS::getPrevCornerVector() const {
        const XY_Point point = (Circ.orient == Circle::Orient::CLOCKWISE) ? edge.point1() : edge.point2();
        return Vector2D{point, enterPoint()};
    }


#pragma mark - PathSpan
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathSpanStack"
    //
    // PathSpan definition
    //

    /**
     末尾短縮
     
     末尾から指定長分切詰める。切り詰めた長さと指定短縮長の差を返す。
        - 短縮可能な前進の直線セグメントのみを対象とする。
            - 連続するセグメントは合計して合計して処理する。無視可能なセグメントを挟んでいても連続とみなす。
        - 短縮長に足りない場合はspan全体が空になる。
        - 予めcomplete()ずみであること。

     @param[in] trimLen 短縮長
     
     @return 残短縮長
     @retval 0.0     : 短縮完了
     @retval 0.0以外 : 短縮未達
     */
    double PathSpan::trimTail(double trimLen) {
        if (currPath.empty()) {
            return trimLen;
        }

        double rest = trimLen;
        currPath.pop_back();    // 末尾には開いたカーブセグメントがあるはず
        while (0.0 < rest && !currPath.empty()) {
            auto& seg = currPath.back();

            if ((seg.segmentType != SegmentType::LINESEG) ||
                (seg.direction == SegmentDir::REVERSE) ) {
                // 前進直線以外は対象外
                if (!seg.isNegrective()) {
                    // 無視可能でない場合
                    // - 残短縮長リセット
                    rest = trimLen;
                }
                currPath.pop_back();
                continue;
            }
            
            // 短縮を試みる
            const double len = seg.length();
            if (rest < len) {
                // 接線が十分長い
                // - 成功終了
                seg.extendTail(-rest);
                rest = 0.0;
                break;
            } else {
                // 接線が短い
                // - 次に期待する
                rest -= len;
                currPath.pop_back();
            }
        }

        if (!currPath.empty()) {
            currPath.terminate(currPath.back().point2());
        }
        return rest;
    }


#pragma mark - PathSpanStack
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathSpanStack"
    //
    // PathSpanStack definition
    //
    
    /**
     最終セグメント更新
     
     生成中のターンパス中の最後のセグメントを更新する
        - 最後のセグメントがArcSegmentでなければ何もしない

     @param[in] startPoint セグメント始点
     @param[in] circle     ターンサークル
     */
    void PathSpanStack::updateTurnPathLast(const XY_Point& startPoint, const Circle& circle) {
        if (!empty() && !back().currPath.empty()) {
            if (back().currPath.back().segmentType == SegmentType::ARCSEG) {
                back().currPath.pop_back();
                back().currPath.emplace_back(startPoint, circle);
            }
        }
    }
    
    /**
     最終セグメントで終端
     
     生成中のターンパス中の最後のセグメントを削除する
     */
    void PathSpanStack::trimTurnPathLast() {
        if (!empty() && !back().currPath.empty()) {
            back().currPath.pop_back();
        }
    }

    /**
     強制終端
     */
    void PathSpanStack::terminate() {
        if (!empty()) {
            auto& span = back();
            span.currPath.terminate();
        }
    }

    /**
     パス末尾短縮
     
     生成中のパス末尾から指定長切詰める。
        - 短縮した長さが指定の長さを超えるまでspanを跨いで処理を行う
        - 直線セグメントは末尾から指定長短縮を試みる
        - 円弧セグメントは短縮せずに全体を削除する
     */
    void PathSpanStack::trimTail(double trimLen) {
        while (0.0 < trimLen && !empty()) {
            auto& span = back();
            trimLen = span.trimTail(trimLen);
            if (0.0 < trimLen) {
                pop_back();
            }
        }
    }
    
    /**
     直線セグメント追加
     
     @param[in] lseg 直線セグメント
     */
    void PathSpanStack::pushTangent(const LineSegment& lseg) {
        PathSpan pathSpan;
        pathSpan.currPath.emplace_back(lseg);
        pathSpan.currPath.emplace_back(lseg.point2());
        push_back(pathSpan);
    }

    /**
     セグメント完成
     
     パス中のセグメントの終端を設定し完成させる
     */
    void PathSpanStack::completeSegment() {
        for (auto it = begin(); it != end(); ++it) {
            auto it2 = next(it);
            if (it2 != end()) {
                it->completeSegment(it2->getEnterPoint());
            } else {
                it->completeSegment();
            }
        }
        complete = true;
    }
    
    /**
     セグメント完成
     
     パス中のセグメントの終端を設定し完成させる
     
     @param[in] leavePoint パスの終点(SPSの進入点)
     */
    void PathSpanStack::completeSegment(const XY_Point& leavePoint) {
        for (auto it = begin(); it != end(); ++it) {
            auto it2 = next(it);
            if (it2 != end()) {
                it->completeSegment(it2->getEnterPoint());
            } else {
                it->completeSegment(leavePoint);
            }
        }
        complete = true;
    }
    
    /**
     パス長算出
     
     @return パス長
     */
    double PathSpanStack::calcMilage() noexcept {
        milage = 0.0;
        for (auto& span : *this) {
            milage += span.calcMilage();
        }
        
        return milage;
    }

    /**
     パス長算出
     
     @param[in] enterPoint FPSパス脚の始点(FPSの脱出点)
     @return パス長
     */
    double PathSpanStack::calcMilage(const XY_Point& enterPoint) noexcept {
        calcMilage();

        // パス脚が含まれていないので加える
        if (0.0 < milage) {
            milage += enterPoint.distance(front().getEnterPoint());
        }
        
        return milage;
    }


#pragma mark - for debug log
    //
    //ログ出力用
    //

    string to_string(const PathFPS& path) {
        return to_string(static_cast<const WorkPath&>(path), " FPS:");
    }
    
    string to_string(const PathSPS& path) {
        return to_string(static_cast<const WorkPath&>(path), " SPS:");
    }

    string to_string(const HwParam& hwParam) {
        std::stringstream ss;
        ss << std::fixed << setprecision(15)
        << "[HwParam]" << EOL
        << "additionalWidth:\t"     << hwParam.additionalWidth << "distance of edges in HP and WHP" << EOL
        << "startIndex:\t"          << hwParam.startIndex << "start index of WHP vertex"<< EOL
        << "startPos:\t"            << hwParam.startPos << "start point of pre-orbital path"<< EOL
        << "endPointAvailable:\t"   << hwParam.endPointAvailable << "endPos available or not"<< EOL
        << "endPos:\t"              << hwParam.endPos << "end point of post-orbital path."<< EOL
        << endl;
        
        return ss.str();
    }

    /**
     ターンサークルリストダンプ
     */
    string dumpHLTCList(const HLTCList& HCP) {
        stringstream os;
        
        for (HeadlandTurnCircle htc : HCP) {
            os << to_string(htc.Circ) << ", " << htc.nodeIndex << ", " << htc.bndFlg << ", " << htc.CvCnF << ", " << htc.flags.to_string() << EOL;
        }
        
        return os.str();
    }
    
    /**
     境界データダンプ
     
     境界ポリゴンBoundaryの配列をダンプする
     */
    string dumpBoundary(const vector<Boundary>& boundaries) {
        stringstream os;
        for (Boundary boundary : boundaries) {
            os << boundary.BP << ", " << boundary.HP << EOL;
        }
        
        return os.str();
    }
    
    /**
     枕地移動範囲情報データダンプ
     
     TraverseSpanデータをダンプする
     */
    string dumpTraverseInfo(const TraverseInfo& traverseInfo) {
        stringstream os;
        // パス生成モード(Mode)
        os  << (int)traverseInfo.mode << EOL
            // 周回方向(RotateDirection)
            << traverseInfo.rotation << EOL
            // 枕地移動範囲(Boundaryのインデックス)
            << "{" << traverseInfo.traverseSpan.first << ", " << traverseInfo.traverseSpan.second << "}" <<EOL
            // 枕地移動方向(インデックスの加算差分: 1 または -1)
            << traverseInfo.traverseDir << EOL
            // 枕地種別(BoundaryType)
            << traverseInfo.boundaryType << EOL
            // ターン種別　@see Param::Path::Turn::Type
            << traverseInfo.turnType.value << EOL
            // 現在パス生成中のターンサークルインデックス
            << traverseInfo. currentIndex << EOL;
        
        return os.str();
    }

    /**
     ターンサークルリストログダンプ
     */
    string dumpHltcList(const HLTCList& htpList) {
        stringstream str;
        
        str << "\n[TurnCircles] size:" << to_string((unsigned int)htpList.size());
        int i = 0;
        for (const auto& htp : htpList) {
            auto& circ1 = htp.Circ;
            str << "\nHTC[" << i << "]" << "\tflags:" + htp.flags.to_string() << ",\tnode:" << setw(4) << htp.nodeIndex << ",\t" << to_string(circ1);
            i++;
        }
        str << "\nreachedListByFps = {";
        for (auto rhtc : htpList.fpsTarget.list) {
            str << "{" << rhtc.index << ", " << rhtc.length <<  "}, ";
        }
        str << "}" "\nreachedListBySps = {";
        for (auto rhtc : htpList.spsTarget.list) {
            str << "{" << rhtc.index << ", " << rhtc.length <<  "}, ";
        }
        str << "}\n"
            << "curr:" << to_string(htpList.curr) << " -> next:" << to_string(htpList.next);
        
        return str.str();
    }
    
    /**
     パス候補ログダンプ
     */
    string dumpPathSpanList(const PathSpanStack& pathSpanList) {
        string str;
        
        if (pathSpanList.empty()) {
            return string{};
        }
        
        str = "milage:" + to_string(pathSpanList.milage) + "\t[" + std::to_string(pathSpanList.front().range.first);
        for (auto span : pathSpanList) {
            str += ", " + std::to_string(span.range.second);
        }
        str += "]";
        
        return str;
    }
    
    /**
     全パス候補ログダンプ
     */
    string dumpCandidates(const vector<PathSpanStack>& pathList) {
        string str;
        
        for (const auto& path : pathList) {
            str += "CANDIDATE: " + dumpPathSpanList(path) + "\n";
        }
        
        return str;
    }

} // namespace PathGeneratorData


#pragma mark - for debug log
//
//ログ出力用
//
string to_string(const XY_Point& point, const char* caption) {
    stringstream ss;
    ss << setprecision(15) << std::showpoint
        << caption << "(" << point.x << ", " << point.y << ")";
    return ss.str();
}

string to_string(const Circle& circle, const char* caption) {
    stringstream ss;
    ss << setprecision(15) << std::showpoint
//     << " C:" << to_string(circle.center) << " R:" << circle.radius << " orient:" << circle.orient;
       << "<circle cx=\"" << circle.center.x << "\" cy=\"" << circle.center.y << "\" r=\"" << circle.radius << "\" fill=\"none\" stroke=\"blue\" stroke-width=\"1.0\"/>";
    return ss.str();
}

string to_string(const LineSegment& path, const char* caption) {
    const auto& point1 = path.point1();
    const auto& point2 = path.point2();
    stringstream ss;
    ss << setprecision(15) << std::showpoint
        << caption << to_string(point1) << " - " << to_string(point2);
    return ss.str();
}

string to_string(const ArcSegment& path, const char* caption) {
    const auto& circle = path.Circ;
    stringstream ss;
    ss << setprecision(15) << std::showpoint
        << caption << to_string(static_cast<LineSegment>(path)) << to_string(circle, "C:");
    return ss.str();
}

string to_string(const tData& data, const char* caption) {
    stringstream ss;
    ss << setprecision(15) << std::showpoint
        << "pos:" << data.point() << ", v:" << data.pointEdge1() << " - " << data.pointEdge2() << ", orgpos:" << data.pointOrg();
    return ss.str();
}

string to_string(const GenSegment& path, const char* caption) {
    stringstream ss;
    if (path.segmentType == SegmentType::ARCSEG) {
        ss << caption << to_string(static_cast<ArcSegment>(path));
    } else {
        ss << caption << to_string(static_cast<LineSegment>(path));
    }
    return ss.str();
}

string to_string(const PathSegment& path, const char* caption) {
    return to_string(static_cast<GenSegment>(path), caption);
}

string to_string(const WorkPath& path, const char* caption) {
    return to_string(static_cast<ArcSegment>(path), caption);
}


namespace Svg {
    string to_string(const XY_Point& point, const char* caption) {
        stringstream ss;
        ss << setprecision(15) << std::showpoint
            << caption << point.x << ", " << -point.y;
        return ss.str();
    }
    
    string to_point(const GeoPoint& point, const string& color, double r, const char* caption) {
        stringstream ss;
        ss << setprecision(15) << std::showpoint
            << caption
            << "<circle"
            << makeProperty(" cx", point.x) <<  makeProperty(" cy", -point.y)
            << makeProperty(" r", r) << makeProperty(" fill", color) <<  makeProperty(" stroke", "none")
            << "/>";
        return ss.str();
    }

    string to_disc(const Circle& c, const string& color, const char* caption) {
        stringstream ss;
        ss << setprecision(15) << std::showpoint
            << caption
            << "<circle"
            << makeProperty(" cx", c.center.x) <<  makeProperty(" cy", -c.center.y)
            << makeProperty(" r", c.radius) << makeProperty(" fill", color) <<  makeProperty(" stroke", "none")
            << "/>";
        return ss.str();
    }

    string to_circle(const Circle& c, const string& color, const char* caption) {
        stringstream ss;
        ss << setprecision(15) << std::showpoint
            << caption
            << "<circle"
            << makeProperty(" cx", c.center.x) <<  makeProperty(" cy", -c.center.y)
            << makeProperty(" r", c.radius) << makeProperty(" fill", "none") << makeProperty(" stroke", color)
            << "/>";
        return ss.str();
    }

    template<typename T>
    string to_path_d_t(const T& seg, const char* caption) {
        const auto& point1 = seg.point1();
        const auto& point2 = seg.point2();
        stringstream ss;
        ss << setprecision(15) << std::showpoint
            << caption << "\tM " << Svg::to_string(point1) << "\tL " << Svg::to_string(point2);
        return ss.str();
    }

    string to_path_d(const GeoPoint& point, const char* caption) {
        return Svg::to_string(point, caption);
    }

    string to_path(const Circle& circle, const char* caption) {
        return to_circle(circle, "blue", caption);
    }

    string to_path_d(const LineSegment& seg, const char* caption) {
        return to_path_d_t(seg, caption);
    }

    int sweepFlag(int rot) noexcept {
        return signbit(rot) ? 0 : 1;
    }

    string to_path_d(const ArcSegment& seg, const char* caption) {
        stringstream ss;
        ss << setprecision(15) << std::showpoint
            << caption << "\tM "  << Svg::to_string(seg.enterPoint()) << " A " << seg.Circ.radius << ' ' << seg.Circ.radius
            << " 0 " << (int)sweepFlag(-seg.Circ.orient) << ' ' << (int)seg.isMajorArc() <<  ' ' << Svg::to_string(seg.leavePoint());

        return ss.str();
    }

    string to_path_d(const GenSegment& seg, const char* caption) {
        return (seg.segmentType == SegmentType::LINESEG) ? Svg::to_path_d(static_cast<LineSegment>(seg)) : Svg::to_path_d(static_cast<ArcSegment>(seg));
    }

    string to_path_d(const PathSegment& seg, const char* caption) {
        return (seg.segmentType == SegmentType::LINESEG) ? Svg::to_path_d(static_cast<LineSegment>(seg)) : Svg::to_path_d(static_cast<ArcSegment>(seg));
    }

    template<typename T>
    string to_path_d_t(const std::vector<T>& path) {
        std::stringstream ss;
        for (const auto& seg : path) {
            ss << to_path_d(seg) << EOL;
        }

        return ss.str();
    }

    string to_path_d(const std::vector<LineSegment>& path) {
        return to_path_d_t(path);
    }

    string to_path_d(const std::vector<ArcSegment>& path) {
        return to_path_d_t(path);
    }

    string to_path_d(const std::vector<GenSegment>& path) {
        return to_path_d_t(path);
    }

    string to_path_d(const std::vector<PathSegment>& path) {
        return to_path_d_t(path);
    }

    string to_path_d(const PathGeneratorData::TurnPath& turnPath) {
        return to_path_d_t(turnPath);
    }

    template<typename T>
    string to_path_t(const T& seg, const char* caption) {
        std::stringstream ss;
        ss  << R"(<path d=")" << EOL
            << to_path_d(seg, caption) << EOL
            << R"("/>)" << EOL;
        
        return ss.str();
    }

    string to_path(const PathSegment& seg, const char* caption) {
        return to_path_t(seg, caption);
    }

    string to_path(const GenSegment& seg, const char* caption) {
        return (seg.segmentType == SegmentType::LINESEG) ? to_path_t(static_cast<LineSegment>(seg), caption) : to_path_t(static_cast<ArcSegment>(seg), caption);
    }

    string to_path(const LineSegment& seg, const char* caption) {
        return to_path_t(seg, caption);
    }

    string to_path(const ArcSegment& seg, const char* caption) {
        return to_path_t(seg, caption);
    }


    template<typename T>
    string to_path_t(const std::vector<T>& path) {
        std::stringstream ss;
        ss  << R"(<path d=")" << EOL
            << to_path_d(path)
            << R"(" />)" << EOL;
        
        return ss.str();
    }


    string to_path(const std::vector<LineSegment>& path) {
        return to_path_t(path);
    }

    string to_path(const std::vector<GenSegment>& path) {
        return to_path_t(path);
    }

    string to_path(const std::vector<PathSegment>& path) {
        return to_path_t(path);
    }

    string to_path(const PathGeneratorData::TurnPath& turnPath) {
        return to_path_t(turnPath);
    }

    void dumpToLog(const string& tag, const std::vector<LineSegment>& path) {
        LOGD(tag.c_str(), "%s", to_path(path).c_str());
    }

    void dumpToLog(const string& tag, const std::vector<GenSegment>& path) {
        LOGD(tag.c_str(), "%s", to_path(path).c_str());
    }

    void dumpToLog(const string& tag, const std::vector<PathSegment>& path) {
        LOGD(tag.c_str(), "%s", to_path(path).c_str());
    }

    void dumpToLog(const string& tag, const PathGeneratorData::TurnPath& turnPath) {
        LOGD(tag.c_str(), "%s", to_path(turnPath).c_str());
    }

}

}} // namespace yanmar::PathPlan

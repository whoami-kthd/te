// Yanmar Confidential 20200918
/**
 @file PathGeneratorData.hpp
 
 パス生成データクラス群ヘッダーファイル
 */
#pragma once

#include "PathPlanIF.hpp"

#include <iostream>
#include <list>
#include <vector>
#include <array>
#include <queue>
#include <fstream>

#include "boost/geometry.hpp"

#include "IteratorUtils.hpp"
#include "Geometry/Geometry.hpp"
#include "OutLib/OutLib.h"
#include "Segment.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;
struct Gauge;

namespace PathGeneratorData {
    static constexpr int SUCCESS = yanmar::PathPlan::ResultCode::SUCCESS;
    static constexpr int FAILURE = yanmar::PathPlan::ResultCode::FAILURE;
    static constexpr int VALID = SUCCESS;
    static constexpr int INVALID = FAILURE;

#pragma mark - parameters for headland workng

struct HwParam {
    /** WHP(外周作業用HP) */
    vector<XY_Point> whp;
    /** HPとWHP外周作業用HPとの差 */
    double additionalWidth = 0;
    /** 外周作業の開始位置 (外周作業が先の場合だけ利用可能) */
    int startIndex = -1;
    /** 外周作業の自動運転開始位置 (外周作業が先の場合だけ利用可能、外周作業用HP上の点) */
    XY_Point startPos;
    /** 外周作業の自動運転終了位置 (外周作業が後の場合だけ利用可能、外周作業用HP上の点) */
    XY_Point endPos;
    /** 外周作業の自動運転終了位置2 (外周作業が塗り潰す境界線上の点、ゴールライン設定用) */
    XY_Point endPos2;
    /** 終了点有効フラグ */
    bool endPointAvailable = false;
};

// デバッグログ出力用
string to_string(const HwParam& hwParam);

#pragma mark - TurnPath a flagment of path data that consist of segment(s).
    class PathFPS;
    class PathSPS;
    struct PathSpan;

    inline static
    vector<PathSegment>::const_iterator findFirstWorkingSegment(const vector<PathSegment>& path) {
        vector<PathSegment>::const_iterator it = std::find_if(path.cbegin(), path.cend(),
                                        [](const PathSegment& pseg) {
                                            return PathParam::Segment::RideType::isWorking(pseg.pathAttr.rideType);
                                        });
        return it;
    }

    inline static
    vector<PathSegment>::iterator findFirstWorkingSegment(vector<PathSegment>& path) {
        vector<PathSegment>::iterator it = std::find_if(path.begin(), path.end(),
                                   [](const PathSegment& pseg) {
                                        return PathParam::Segment::RideType::isWorking(pseg.pathAttr.rideType);
                                    });
        return it;
    }

    /**
     ターンパスデータクラス
     
     生成するパスデータの一部分、典型的には接線と次のカーブまでの部分パスをハンドルするクラス。
     セグメントのリストの他にステータスを持ちターンパス生成関数の戻り値として使う。
     */
    class TurnPath : public vector<PathSegment> {
        using super = vector<PathSegment>;

    public:
        using value_type = super::value_type;
        static constexpr int SUCCESS = ResultCode::SUCCESS;
        static constexpr int FAILURE = ResultCode::FAILURE;
        static constexpr int FAILURE_TOO_CLOSE_CORNERS = -2;

        TurnPath() = default;
        TurnPath(const TurnPath&) = default;
        TurnPath(int size) :
            super(size)
        {}
        TurnPath(const TurnType& aTurnType) :
            turnType(aTurnType)
        {}
        
        // 有効性テスト
        bool isValid() const noexcept { return (status == VALID); }
        // 無効化
        void invalidate(int aStatus = INVALID) noexcept { status = aStatus; }
        // 有効化
        void validate() noexcept { status = VALID; }
        // クリア
        void clear() {
            super::clear();
            invalidate();
            milage = 0.0;
        };
        // 追加
        void append(TurnPath& turnPath, int rideType);
        // 代入
        size_type assign(const class PathSpanStack& pss);
        // ターンパス更新
        size_type updateTurnPath(int index, PathSegment&& turnpath);
        // 点追加
        size_type pushTurnPath(const XY_Point& startPoint, int aDirection = LineSegment::FORWARD);
        // パスセグメント追加
        size_type pushTurnPath(const PathSegment& lseg);
        // 直線セグメント追加
        size_type pushTurnPath(const LineSegment& lseg);
        // 円弧セグメント追加
        size_type pushTurnPath(const XY_Point& startPoint, const Circle& aCircle, int aDirection = LineSegment::FORWARD);
        // パス追加
        size_type pushTurnPath(const TurnPath& path);
        size_type pushTurnPath(const vector<PathSpan>& paths);

        // パス削除
        void popFront() {
            if ((2 <= size()) || (size() == 1 && !front().term)) {
                erase(cbegin());
            }
        }

        // ターンタイプ設定
        void setTurnType(int aTurnType) noexcept {
            turnType = aTurnType;
            applyTurnType();
        }
        // ターンタイプ設定
        void setTurnType(TurnType aTurnType) noexcept {
            turnType = aTurnType;
            applyTurnType();
        }
        // ターンタイプフラグ設定
        void modTurnType(int aTurnTypeFlag) noexcept {
            turnType.value |= aTurnTypeFlag;
            applyTurnType();
        }
        // ターンタイプ反映
        // -
        void applyTurnType() noexcept {
            for_each(begin(), end(), [this](value_type& seg) { seg.turnType = turnType; } );
        }
        // セグメント属性反映
        // - この値はセグメント毎に違うためTurnPath側は持っていない
        void applyExtAttr(int aExtAttr) noexcept {
            for_each(begin(), end(), [aExtAttr](value_type& seg) { seg.pathAttr.setExtAttr(aExtAttr); } );
        }

        // 強制終端
        size_type terminate() {
            if (!empty() && !back().term) {
                back().leavePoint() = back().enterPoint();
                back().term = true;
            }

            return size();
        }

        size_type terminateAuto() {
            if (empty()) {
                return 0;
            }
            pushTurnPath(back().leavePoint());
            return terminate();
        }
        
        size_type terminate(const XY_Point& endPoint) {
            pushTurnPath(endPoint);
            return terminate();
        }

        size_type open() {
            if (!empty() && isTerminated()) {
                pop_back();
                back().term = false;
            }

            return size();
        }

        bool isTerminated() const {
            return empty() ? false : back().term;
        }

        // 最終セグメント参照
        const PathSegment& lastSegment() const;
        // 最終セグメント参照
        PathSegment& lastSegment();

        // セグメント取得
        template<typename T>
        T getSegment(int index) const;
        // 最終セグメント取得
        GenSegment getLastSegment() const;
        // 最終接線セグメント取得
        LineSegment getLastTangent() const;
        
        TurnPath getNonredundantData() const;
        
        const XY_Point& getEnterPoint() const noexcept {
            return (empty()) ? XY_Point::nullobj : front().enterPoint();
        }

        const XY_Point& enterPoint() const noexcept {
            return getEnterPoint();
        }

        XY_Point& enterPoint() noexcept {
            return front().enterPoint();
        }

        const XY_Point& getLeavePoint() const noexcept {
            if (empty()) {
                return XY_Point::nullobj;
            }
            
            return (back().term) ? back().enterPoint() : back().leavePoint();
        }

        const XY_Point& leavePoint() const noexcept {
            if (empty()) {
                return XY_Point::nullobj;
            }
            return getLeavePoint();
        }

        XY_Point& leavePoint() noexcept {
            return back().leavePoint();
        }

        // パス長計算
        double calcMilage() {
            milage += milageAt(cbegin(), cend());
            
            return milage;
        }

        double milageAt(TurnPath::const_iterator beginIt, TurnPath::const_iterator endIt) const;
        iterator findLastTangent(int dir = TangentDir::FORWARD);

        // セグメント接続
        void completeSegment() {
            if (!empty()) {
                completeSegment(back().leavePoint());
            }
        }
        // セグメント接続
        void completeSegment(const XY_Point& leavePoint) {
            for (auto it = begin(); it != end(); ++it) {
                auto& seg = *it;
                const auto nextIt = next(it);
                seg.point2() = (nextIt != end()) ? nextIt->point1() : leavePoint;
            }
        }
        
        // 終端セグメント長
        double terminalLength() const;
        
        double trimTail(double trimLen);
        
        // バック移動セグメントを持つかどうか
        bool hasReverseSeg() const noexcept {
            auto it = std::find_if (cbegin(), cend(), [](const PathSegment& pseg) { return pseg.direction == SegmentDir::REVERSE; });
            return (it != cend());
        }

        template<typename U>
        inline static
        const U& as_const(U& src) { return const_cast<const U&>(src); }

        template<typename U>
        inline static
        const U& as_noconst(U& src) { return const_cast<U&>(src); }

        // 最初の作業セグメント探索
        const_iterator findFirstWorkingSegment() const { return PathGeneratorData::findFirstWorkingSegment(*this); }
        iterator findFirstWorkingSegment() { return PathGeneratorData::findFirstWorkingSegment(*this); }
    
    public:
        TurnType turnType{TurnType::UNDEFINED};  // ターンの種類
        int status = INVALID;
        double milage = 0.0;
    };


    // パスセグメント属性テスト構造体
    struct SegTest {
        static bool test(const OutPathSegment& seg, int stype, int rtype, int dir = LineSegment::FORWARD) {
            return (seg.segmentType == stype && seg.pathAttr.rideType == rtype && seg.direction == dir);
        }

        static bool isRasterSeg(const OutPathSegment& seg) {
            return (seg.segmentType == SegmentType::LINESEG &&
                    ((seg.turnType.value & PathParam::Turn::Type::MASK) == PathAttr::RideType::WORKING || (seg.turnType.value & PathParam::Turn::Type::MASK) == PathAttr::RideType::DUMMY));
        }

        static bool isNavigation(const OutPathSegment& seg) {
            return ((seg.turnType.value & PathParam::Turn::Type::MASK) == PathParam::Turn::Type::NAVIGATION);
        }

    };

// 進入セグメント調整
void treatEntrance(TurnPath& turnPath, double termLen);
void treatExitance(TurnPath& turnPath, double termLen);

string dumpTurnPath(const TurnPath& tuenPath, const char* caption = "");

#pragma mark - BoundarySet: for handling set of field bondaries (BP, HP, SHP)
#undef LOG_TAG
#define LOG_TAG "PathPlan::BoundarySet"
    using BoundaryPolygon = vector<Boundary>;
    using BoundaryPolygons = vector<BoundaryPolygon>;

    bool hasConcave(const BoundaryPolygon& field) noexcept;
    BoundaryPolygon::iterator findNode(BoundaryPolygon& polygon, int nodeId);
    BoundaryPolygon::const_iterator findNode(const BoundaryPolygon& polygon, int nodeId);
    vector<LineSegment> getEdgeListBP(const BoundaryPolygon& polygon, const BoundaryPolygon::const_iterator& startIt);
    vector<LineSegment> getEdgeListHP(const BoundaryPolygon& polygon, const BoundaryPolygon::const_iterator& startIt);

    /**
     * BoundarySet
     *  - 圃場境界の集合
     */
    class BoundarySet
    {
        using GeoPolygon = vector<GeoPoint>;
        using GeoPolygons = vector<GeoPolygon>;
        using Polygon = vector<XY_Point>;
        using Polygons = vector<Polygon>;

    public:
      	static constexpr int OBsize	= 4;

        BoundarySet() :
            bpList(5),
            hpList(5),
            ehpList(5),
            whpList(5)
        {}

        BoundarySet(const GeoPolygons& extents, const GeoPolygons& hlps, const HwParam& aHwParam, const Gauge& gauge);

        const Polygon& bp(int index = 0) const { return bpList[index]; }
        const Polygon& hp(int index = 0) const { return hpList[index]; }
        const Polygon& ehp(int index = 0) const { return ehpList[index]; }
        const Polygon& whp(int index = 0) const { return whpList[index]; }
        const Polygon& obp(int index) const { return bp(index + 1); }
        const Polygon& ohp(int index) const { return hp(index + 1); }
        Polygon& bp(int index = 0) { return const_cast<Polygon&>(bpList[index]); }
        Polygon& hp(int index = 0) { return const_cast<Polygon&>(hpList[index]); }
        Polygon& ehp(int index = 0) { return const_cast<Polygon&>(ehpList[index]); }
        Polygon& whp(int index = 0) { return const_cast<Polygon&>(whpList[index]); }
        Polygon& obp(int index) { return const_cast<Polygon&>(bp(index + 1)); }
        Polygon& ohp(int index) { return const_cast<Polygon&>(hp(index + 1)); }
        
        const Boundary& boundaryAt(int nodeIndex) const;

        std::vector<XY_Point> getCrossPoints_if(const LineSegment& seg, BoundaryType::Kind::Set targetFlag, std::function<bool (const XY_Point&)>) const;
        std::vector<XY_Point> getCrossPoints(const LineSegment& seg, BoundaryType::Kind::Set targetFlag) const {
            return getCrossPoints_if(seg, targetFlag, [](const XY_Point&) { return true; });
        }
        std::vector<XY_Point> getCrossPointsHeadward(const LineSegment& seg, BoundaryType::Kind::Set targetFlag) const {
            return getCrossPoints_if(seg, targetFlag, [seg](const XY_Point& p) { return (seg.getDotProductFrom(p) <= 0.0); });
        }
        std::vector<XY_Point> getCrossPointsTailward(const LineSegment& seg, BoundaryType::Kind::Set targetFlag) const {
            return getCrossPoints_if(seg, targetFlag, [seg](const XY_Point& p) { return (0.0 <= seg.getDotProductTo(p)); });
        }
        
    public:
        Polygons bpList;
        Polygons hpList;
        Polygons ehpList;
        Polygons whpList;

        BoundaryPolygon field;
        BoundaryPolygons obstacles;
    };

#pragma mark - list of headland turn circles
    class PathFPS;
    class PathSPS;
    
    /**
     ターンサークルリストクラス
     */
    class HLTCList : public vector<HeadlandTurnCircle> {
        using super = vector<HeadlandTurnCircle>;
    public:
        HLTCList() = default;
		HLTCList(const HLTCList& src) = default;
		HLTCList& operator=(const HLTCList&) = default;

        // HCP操作
        int insert(int index, const HeadlandTurnCircle& htc);
        iterator append(HLTCList htclist) { return super::insert(cend(), htclist.begin(), htclist.end()); }
        void update(int index, const HeadlandTurnCircle& htc);
        void update(const PathFPS& fps);
        void update(const PathSPS& sps);
        int erase(int index);
        int erase(int startIndex, int endIndex);
        // HCPインデックスgetter群
        int fpsIndex() const { return 0; }
        int spsIndex() const { return (int)(size() - 1); }
        int lastIndex() const { return (int)(size() - 1); }
        int endIndex() const { return (int)(size()); }
        pair<int, int> getMinimalStartNavRange() const { return pair<int, int>{spsIndex(), spsIndex()}; }
        pair<int, int> getMinimalEndNavRange() const { return pair<int, int>{fpsIndex(), fpsIndex()}; }
        
        /**
         ターンサークルスキップ条件初期化
         */
        void initSkip() {
			fpsTarget.reset();
			spsTarget.reset();
        }

        void initRange() {
            range = {0, size() - 1};
        }

        /**
         ターンサークル無視フラグ設定(FPS)
         
         FPS脚をindexで示すターンサークルまでスキップした時の無視フラグを設定する。
         */
        void setIgnoresFps(int index) {
            if (size() < 2) {
                return;
            }
            
            const size_type end = size() - 1;
            const size_type bound = (index < 0) ? 0 : index;
            size_type i = 0;
            at(0).flags.reset(HeadlandTurnCircle::IGNORED_BY_FPS);
            for (; i < bound; i++) {
                at(i).flags.set(HeadlandTurnCircle::IGNORED_BY_FPS);
            }
            for (; i < end; i++) {
                at(i).flags.reset(HeadlandTurnCircle::IGNORED_BY_FPS);
            }
            at(end).flags.reset(HeadlandTurnCircle::IGNORED_BY_FPS);
        }
        
        /**
         ターンサークル無視フラグ設定(SPS)
         
         SPS脚をindexで示すターンサークルまでスキップした時の無視フラグを設定する。
         */
        void setIgnoresSps(int index) {
            if (size() < 2) {
                return;
            }
            size_type i = 0;
            const size_type end = size() - 1;
            const size_type bound = (index < 0) ? end : index;
            at(i).flags.reset(HeadlandTurnCircle::IGNORED_BY_SPS);
            i++;
            for (; i < bound; i++) {
                at(i).flags.reset(HeadlandTurnCircle::IGNORED_BY_SPS);
            }
            for (; i < end; i++) {
                at(i).flags.set(HeadlandTurnCircle::IGNORED_BY_SPS);
            }
            at(end).flags.reset(HeadlandTurnCircle::IGNORED_BY_SPS);
        }
        
        /**
         スキップ準備
         
         次のスキップの組み合わせ条件を設定する。次がない場合falseを返す。
         */
        bool nextSkip() {
            if (isSkip()) {
                if (!fpsTarget.next()) {
                    if (spsTarget.next()) {
                        fpsTarget.reset();
                    }
                }
            }
            
            return isSkip();
        }
        
        /**
         スキップ可否
         
         スキップがあるかどうかを返す。
         */
        bool isSkip() const {
            return (fpsTarget.isAvailable() || spsTarget.isAvailable());
        }
        
        // HCP範囲抽出
        HLTCList getClipHCP(const HLTCList& srcHhp, int begin, int end) const;
        
        // HeadlandTurnCircleではなく単なるCircleのvectorへの変換演算子
        operator vector<Circle>() const {
            vector<Circle> circles;
            for (const auto& htc : *this) {
                circles.push_back(htc.Circ);
            }
            return circles;
        }

        /**
         先頭側ターンサークルを一つスキップ
         
         @return スキップしたかどうか
        */
        bool skipFront() noexcept {
            if (range.first == range.second) {
                return false;
            }

            range.first++;
            return true;
        }
    
    public:
        size_t curr = 0;
        size_t next = 0;
        size_t fpsCurr = 0;
        size_t spsCurr = 0;
        
        static constexpr int MIN_ESCAPE_LEG = -1;
        static constexpr int MIN_ESCAPE_LEG_EXT = -11;
        static constexpr int MIN_LEG = -2;
        static constexpr int MIN_LEG_EXT = -12;
        
        struct ReachedHtc {
            ReachedHtc() = default;
            ReachedHtc(const ReachedHtc&) = default;
            ReachedHtc(int aIndex, double aLength) :
                index(aIndex),
                length(aLength)
            {}
            
            int index = -1;
            double length = 0.0;
        };

		class ReachedHtcList {
		public:
			vector<ReachedHtc> list;
			int index = 0;

			int next() {
				if (isAvailable()) {
					index++;
				}

				return isAvailable();
			}

			bool isAvailable() const {
				return isInRangeClose(0, index, (int)list.size() - 1);
			}

			void reset() {
				index = 0;
			}

			ReachedHtc at() const {
				return list.at(index);
			}
            
            void normalize() {
                auto boundIt = std::find_if(list.begin(), list.end(), [](ReachedHtc& v) { return (v.index < 0); });
                std::stable_sort(boundIt, list.end(), [](const ReachedHtc& lhs, const ReachedHtc& rhs) {
                    return (rhs.length < lhs.length || (rhs.length == lhs.length && rhs.index < lhs.index));
                });
                auto eit = std::unique(list.begin(), list.end(),
                                       [](const ReachedHtc& lhs, const ReachedHtc& rhs) {return isIsometric(lhs.length, rhs.length, TOL_MILLI); });
                list.erase(eit, list.end());
            }
		};

		ReachedHtcList fpsTarget;
        ReachedHtcList spsTarget;
        pair<int, int> range;  ///< 有効な範囲(無視フラグとは別に使用する開始位置から終了位置を示す)
    };


#pragma mark - WorkPath derived
    /**
     FPSパスクラス
     
     ターン前の作業パス
     @note トラクターは point2 -> point1 へ移動する。point1がターン側。
     */
    class PathFPS : public WorkPath {
    public:
        PathFPS() = default;
        PathFPS(const tData& p1, const tData& p2, double minLegLength);
        void setTurnCircle(int rotation, double raduis) { setLeaveTurnCircle(rotation, raduis); }
        int extendLegTo(const HeadlandTurnCircle& htc, const Gauge& gauge);
        // FPSは入口出口が逆なのでオーバーライドする
        virtual const XY_Point& enterPoint() const noexcept { return point2(); }
        virtual XY_Point& enterPoint() noexcept { return point2(); }
        virtual const XY_Point& leavePoint() const noexcept { return point1(); }
        virtual XY_Point& leavePoint() noexcept { return point1(); }
        virtual double ensureMinimalLegLength();
        virtual LineSegment getHeadLeg() const { return LineSegment{point1(), foot}; }
//		virtual LineSegment getTailLeg() const { return LineSegment{point2(), point2()}; }
        virtual LineSegment getSegmentWithLeg() const { return LineSegment{point2(), foot}; }
        virtual LineSegment getSegment() const { return LineSegment{point2(), point1()}; }
        virtual bool isFishtailAvailable(const LineSegment& lTS) const {
            const LineSegment lseg = getSegmentWithLeg();
            const double dp = lseg.getDotProduct(lTS);
            const double cp = lseg.getCrossProduct(lTS);
            return (dp < 0.0) && (isIsometric(cp, 0.0) || (signbit(cp) == signbit((double)Circ.orient)));
        }
        Vector2D getNextCornerVector() const;
    };
    
    /**
     SPSパスクラス
     
     ターン後の作業パス
     @note トラクターは point1 -> point2 へ移動する。point1がターン側。
     */
    class PathSPS : public WorkPath {
    public:
        PathSPS() = default;
        PathSPS(const tData& p1, const tData& p2, double minLegLength);
        void setTurnCircle(int rotation, double raduis) { setEnterTurnCircle(rotation, raduis); }
        int extendLegTo(const HeadlandTurnCircle& htc, const Gauge& gauge);
        // SPSは入口出口が同じなのでオーバーライドしないこと
//      virtual const XY_Point& enterPoint() const noexcept
//      virtual XY_Point& enterPoint() noexcept
//      virtual const XY_Point& leavePoint() const noexcept
//      virtual XY_Point& leavePoint() noexcept
        virtual double ensureMinimalLegLength() { return WorkPath::ensureMinimalHeadLegLength(); }
        virtual LineSegment getHeadLeg() const { return LineSegment{foot, point1()}; }
//		virtual LineSegment getTailLeg() const { return LineSegment{point2(), point2()}; }
        virtual LineSegment getSegmentWithLeg() const { return LineSegment{foot, point2()}; }
        virtual LineSegment getSegment() const { return static_cast<LineSegment>(*this); }
        
        virtual bool isFishtailAvailable(const LineSegment& eTS) const {
            const LineSegment eseg = getSegmentWithLeg();
            const double dp = eTS.getDotProduct(eseg);
            const double cp = eTS.getCrossProduct(eseg);
            return (dp < 0.0) && (isIsometric(cp, 0.0) || (signbit(cp) == signbit((double)Circ.orient)));
        }
        
        Vector2D getPrevCornerVector() const;
    };


#pragma mark - Traverse infomations
    /// ターンパス生成用枕地移動情報
    struct TraverseInfo {
        // PathGeneratorData 定数のエイリアス
        static constexpr int SUCCESS = PathGeneratorData::SUCCESS;
        static constexpr int FAILURE = PathGeneratorData::FAILURE;
        static constexpr int VALID = PathGeneratorData::VALID;
        static constexpr int INVALID = PathGeneratorData::INVALID;
        static constexpr int CLOCKWISE = RotateDirection::CLOCKWISE;
        static constexpr int ANTICLOCKWISE = RotateDirection::ANTICLOCKWISE;

        /// パス生成モード値
        enum class Mode : int {
            INTER_PATH,	///< 作業パス間
            START_NAV,	///< 作業開始ナビゲーション
            END_NAV,	///< 作業終了ナビゲーション
            ORBITAL     ///< 周回パス
        };
        
        TraverseInfo() = default;
        
        PathFPS fps;
        PathSPS sps;
        
        void setFps(const tData& p1, const tData& p2, double minLegLength) {
            fps = PathFPS{p1, p2, minLegLength};
            fps.pathAttr = p2.pathAttr;
        }
        
        void setSps(const tData& p1, const tData& p2, double minLegLength) {
            sps = PathSPS{p1, p2, minLegLength};
            sps.pathAttr = p1.pathAttr;
        }
        
        /// パス生成モード(Mode)
        Mode mode = Mode::INTER_PATH;
        /// 周回方向(RotateDirection)
        int rotation = 0;
        /// 枕地移動範囲(Boundaryのインデックス)
        std::pair<int, int> traverseSpan = {0, 0};
        /// 枕地移動方向(インデックスの加算差分: 1 または -1)
        // ポリゴン種別によって方向が違うのでrotationを直接使用しないこと
        int traverseDir = 0;
        /// 枕地種別(BoundaryType)
        int boundaryType = BoundaryType::FIELD;
        /// ターン種別　@see Param::Path::Turn::Type
        TurnType turnType{PathParam::Turn::Type::STRAIGHT};
        /// 現在パス生成中のターンサークルインデックス
        int currentIndex = 0;

        /// 周回パス生成用
        struct Orbital {
            /// 周回方向
            int orient = CLOCKWISE;
            /// 総周回数
            int totalLaps = 0;
            /// 現在の周回数
            int currentLap = 0;
            /// 最初コーナーノード(一周してこのコーナーから内周に移る)
            int firstCornerNode = 0;
            /// 最終コーナーとなるノード
            int finalCornerNode = 0;
            /// 外周作業回開始線(外周先の時のみ有効)
            LineSegment startLine;
            /// 周回開始線(外周先の時のみ有効)
            LineSegment goalLine;
        } orbital;

        struct Truncation {
            // 開始ナビゲーション途中から開始試行禁止
            void disableHead() noexcept {
                head = false;
            }
            /// 終了ナビゲーション途中で終了試行禁止
            void disableTail() noexcept {
                tail = false;
            }

            /// 開始ナビゲーション途中から開始試行許可
            bool head = true;
            /// 終了ナビゲーション途中で終了試行許可
            bool tail = true;
        } truncation;
        
        HLTCList HCP;

        bool skipFrontNode() noexcept {
            bool retval = false;
            if (truncation.head) {
                retval = HCP.skipFront();
            }
            return retval;
        }

        bool isStandardTurn() const {
            return (HCP.size() < 3);
        }
    };


#pragma mark - PathSpan: for handling set of path segments as a part of navigation path.
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathSpan"
    /**
     ナビゲーションパス生成中の履歴エンティティ
     
     パスデータとそのターンポイント範囲等の情報を保持するクラス。
     パス生成バックトラック用の履歴データ。
     */
    struct PathSpan {
        PathSpan() :
            range(0, 0)
        {}
        
        explicit PathSpan(std::pair<int, int> aPathRange) :
            range(aPathRange)
        {}
        
        explicit PathSpan(const HLTCList& hcp) :
            range(hcp.range),
            HCP(hcp)
        {}
        
        /**
         空チェック
         
         範囲が0かどうかを返す。raneg以外のデータメンバーの内容は不定である。
         
         @retval true: 範囲がある
         @retval false: 範囲がない(0)
         */
        bool empty() const {
            return (range.first == range.second);
        }
        
        /// 成否取得
        bool isSuccess() const { return success; }
        
        /**
         範囲減少
         
         @retval true: 範囲減少成功
         @retval false: 範囲減少失敗(既に範囲0)
         */
        bool decRange() {
            success = false;
            const bool result = empty();
            if (!result) {
                range.second -= 1;
                currPath.clear();
                savePath.clear();
                halfway.clear();
                return true;
            }
            return false;
        }
        
        /// パスデータ追加
        void append(const TurnPath& aPath) {
            if (empty()) {
                // 念のため
                currPath.clear();
            }
            currPath.insert(currPath.end(), aPath.begin(), aPath.end());
        }

        void saveHalfway(const TurnPath& aPath, int endIndex) {
            if (!aPath.empty() && !hasHalfwaySpan()) {
                halfway.path = aPath;
                halfway.range = range;
                halfway.range.second = endIndex;
            }
        }
        
        /// 次の範囲に進む
        void shiftRange(int newlast) {
            range.first = range.second;
            range.second = newlast;
            currPath.clear();
            savePath.clear();
            success = false;
        }
        
        bool isInHcpRange() {
            return isInRangeClose(HCP.range.first, range.first, HCP.range.second - 1) &&
            isInRangeClose(HCP.range.first, range.second, HCP.range.second);
        }
        
        /// 範囲長
        int length() const {
            return (range.second - range.first);
        }
        
        /// 保存時の処理
        void save() {
            savePath = currPath;
            halfway.clear();
        }
        
        /// 復元時の処理
        void restore() {
            currPath = savePath;
        }
        
        /// 最終接線取得
        PathSegment getLastTangent() const {
            PathSegment	LS;
            
            const int index = (int)currPath.size() - 2;
            if (0 <= index) {
                auto& p1 = currPath[index];
                if (p1.segmentType == SegmentType::LINESEG) {
                    auto& p2 = currPath[index + 1];
                    LS = PathSegment{p1.point1(), p2.point1()};
                    LS.validate();
                }
            }
            
            return LS;
        }
        
        /// 出発コーナーHTC参照
        HLTCList::value_type& srcCorner() {
            return HCP[range.first];
        }
        
        /// 行先コーナーHTC参照
        HLTCList::value_type& dstCorner() {
            return HCP[range.second];
        }
        
        double calcMilage() {
            return currPath.calcMilage();
        }
        
        XY_Point getEnterPoint() const {
            return currPath.getEnterPoint();
        }
        
        XY_Point getLeavePoint() const {
            return currPath.getLeavePoint();
        }
        
        void completeSegment() {
            currPath.completeSegment();
        }
        
        void completeSegment(const XY_Point& leavePoint) {
            currPath.completeSegment(leavePoint);
        }

        double trimTail(double trimLen);
        
        bool hasHalfwaySpan() const { return (!halfway.path.empty()); }
        
        PathSpan getHalfwaySpan() const {
            PathSpan ps(*this);
            if (hasHalfwaySpan()) {
                ps.currPath = halfway.path;
                ps.range = halfway.range;
            }
            return ps;
        }

    public:
        std::pair<int, int> range;	///< 部分パス探索ターンポイント(HCP)範囲
        bool success = false;
        TurnPath currPath;	///< パスデータ
        TurnPath savePath;	///< リストア用パスデータ
        HLTCList HCP;		///< 現HCP
        struct Halfway {
            TurnPath path;       ///< 中途終了パスデータ
            std::pair<int, int> range;	///< 中途パス範囲
            /// パスのクリア
            void clear() {
                path.clear();
                range = {0, 0};
            }
        } halfway;  ///< 中途終了パス
    };
    
    
#pragma mark - BoundarySet: for handling set of field bondaries (BP, HP, SHP)
#undef LOG_TAG
#define LOG_TAG "PathPlan::BoundarySet"
    
    /**
     部分パススタック
     
     ナビゲーションパス生成中の部分パスのスタック
     */
    class PathSpanStack : public vector<PathSpan> {
    public:
        void updateTurnPathLast(const XY_Point& startPoint, const Circle& circle);
        void trimTurnPathLast();
        void trimTail(double trimLen);
        void pushTangent(const LineSegment& lseg);
        void setTurnType(int aTurnType) noexcept {
            turnType = aTurnType;
        }
        void completeSegment();
        void completeSegment(const XY_Point& leavePoint);
        void terminate();
        double calcMilage() noexcept;
        double calcMilage(const XY_Point& enterPoint) noexcept;
        
        int enterHcpIndex() const noexcept {
            return (empty()) ? 0 : front().range.first;
        }
        
        int leaveHcpIndex() const noexcept {
            return (empty()) ? 0 : back().range.second;
        }

        
    public:
        TurnType turnType;
        bool complete = false;
        double milage = 0.0;
    };

#pragma mark - BoundaryCollisions: Intersection status
    struct BoundaryCollisions {
        int BP = 0;
        int HP = 0;
        
        bool isValid() const {
            return ((BP == 0) && (HP == 0));
        }
    };
    
#pragma mark - Parameters for make whiwsker
    
    struct WhiskerMode_t {
        WhiskerMode_t() = default;
        constexpr WhiskerMode_t(int aMode, const BoundaryType::Kind::Set& aBndFlag) :
            mode(aMode),
            bndFlag(aBndFlag)
        {}
        constexpr WhiskerMode_t(const WhiskerMode_t&) = default;

        /**
         凹角旋回方向判定
         指定の旋回方向が内部保持する周回方向に対して凹角のものかどうかを返す。
         - 内部の周回方向がUNDEFINEDの場合、常に偽を返す。
         @param[in] orient  検査対象旋回方向 RotateDirection
         @return 凹角かどうか
         @retval true 凹角
         @retval false 凸角
         */
        bool isConcave(int orient) const noexcept {
            return (rotation != RotateDirection::UNDEFINED) && (orient != rotation);
        }

        // ウィスカー補正値
        struct {
            double forward = 0.0;
            double backward = 0.0;
        } adjustLength;

        /// ウィスカー長確認対象境界
        /// - 現在はBPのみ
        std::bitset<5> mode;
        BoundaryType::Kind::Set bndFlag = BoundaryType::Kind::FOR_SEEK_WHISKER_LENGTH;

        int rotation = RotateDirection::UNDEFINED;
    };

    /**
     ウィスカー生成モードクラス
     */
    namespace WhiskerMode {
        namespace Mode {
            namespace Index {
                static constexpr unsigned int FORWARD = 0;
                static constexpr unsigned int BACKWARD = 1;
                static constexpr unsigned int CROSS = 3;
                static constexpr unsigned int CONCAVE = 4;
            }
            
            namespace Mask {
                static constexpr unsigned int NONE          = 0x00u;
                static constexpr unsigned int FORWARD       = 0x01u << Index::FORWARD;
                static constexpr unsigned int BACKWARD      = 0x01u << Index::BACKWARD;
                static constexpr unsigned int BOTH          = FORWARD | BACKWARD;
                static constexpr unsigned int CROSS         = BOTH | (0x01u << Index::CROSS);
                static constexpr unsigned int CONCAVE       = 0x01u << Index::CONCAVE;
                static constexpr unsigned int CROSS_CONCAVE = CROSS | CONCAVE;
            }
        }
    
        // ターン生成引数用ウィスカーモード値定数
        /// ウィスカー無し
        static constexpr WhiskerMode_t NONE{Mode::Mask::NONE, BoundaryType::Kind::FOR_SEEK_WHISKER_LENGTH};
        /// 交差ウィスカー(凸角)
        static constexpr WhiskerMode_t CROSS{Mode::Mask::CROSS, BoundaryType::Kind::FOR_SEEK_WHISKER_LENGTH};
        /// 交差ウィスカー(凹角)
        static constexpr WhiskerMode_t CROSS_CONCAVE{Mode::Mask::CROSS_CONCAVE, BoundaryType::Kind::FOR_SEEK_WHISKER_LENGTH_CONCAVE};
    }
    
#pragma mark - Parameters for make whiwsker
/// RO/OR遷移ターン生成パラメータ
struct TransitTurnParams : public WhiskerMode_t {
    TransitTurnParams() = default;
    TransitTurnParams(WhiskerMode_t& whiskermode) :
        WhiskerMode_t(whiskermode)
    {}

    bool avoidAwp = false;
};


#pragma mark - formatters: for debug log.
    //
    // デバッグログ用フォーマッター
    //
    string to_string(const PathFPS& path);
    string to_string(const PathSPS& path);
    string dumpHLTCList(const HLTCList& HCP);
    string dumpBoundary(const vector<Boundary>& boundaries);
    string dumpTraverseInfo(const TraverseInfo& traverseInfo);
    string dumpHltcList(const HLTCList& htpList);
    string dumpCandidates(const vector<PathSpanStack>& pathList);
    string dumpPathSpanList(const PathSpanStack& pathSpanList);

} // namespace PathGeneratorData

//
// デバッグログ用フォーマッター
//
string to_string(const XY_Point& point, const char* caption = "");
string to_string(const Circle& circle, const char* caption = "");
string to_string(const GenSegment& path, const char* caption = "");
string to_string(const ArcSegment& path, const char* caption = "");
string to_string(const LineSegment& path, const char* caption = "");
string to_string(const PathSegment& path, const char* caption = "");
string to_string(const tData& path, const char* caption = "");
string to_string(const WorkPath& path, const char* caption = "");

//
// デバッグログ用フォーマッター(SVG)
//
namespace Svg {
/**
     property フォーマット
 
     SVGエレメントのプロパティ文字列を生成して返す。
     - つまり name="value" 文字列を返す。
     
     @param[in] name プロパティ名
     @param[in] value プロパティの値
     */
    template<typename T>
    inline static
    string makeProperty(const string& name, T value) {
        stringstream ss;
        ss << setprecision(15) << std::showpoint
            << name << "=\"" << value << "\"";
        return ss.str();
    }
    // x, y座標文字列生成
    string to_string(const XY_Point& point, const char* caption = "");
    // 指定座標のcircleエンティティ(丸)文字列生成
    string to_point(const GeoPoint& point, const string& color = "black", double r = 0.5, const char* caption = "");
    string to_circle(const Circle& c, const string& color = "black", const char* caption = "");
    string to_disc(const Circle& c, const string& color = "black", const char* caption = "");
    // pathエンティティのdプロパティの内容を生成
    string to_path_d(const GeoPoint& seg, const char* caption = "");
    string to_path_d(const LineSegment& seg, const char* caption = "");
    string to_path_d(const ArcSegment& seg, const char* caption = "");
    string to_path_d(const GenSegment& path, const char* caption = "");
    string to_path_d(const PathSegment& path, const char* caption = "");
    string to_path_d(const std::vector<LineSegment>& path);
    string to_path_d(const std::vector<GenSegment>& path);
    string to_path_d(const std::vector<PathSegment>& path);
    string to_path_d(const PathGeneratorData::TurnPath& turnPath);

    // pathエンティティ文字列生成
    string to_path(const LineSegment& seg, const char* caption = "");
    string to_path(const ArcSegment& seg, const char* caption = "");
    string to_path(const GenSegment& seg, const char* caption = "");
    string to_path(const PathSegment& seg, const char* caption = "");
    string to_path(const std::vector<LineSegment>& path);
    string to_path(const std::vector<GenSegment>& path);
    string to_path(const std::vector<PathSegment>& path);
    string to_path(const PathGeneratorData::TurnPath& turnPath);

    void dumpToLog(const string& tag, const std::vector<LineSegment>& path);
    void dumpToLog(const string& tag, const std::vector<GenSegment>& path);
    void dumpToLog(const string& tag, const std::vector<PathSegment>& path);
    void dumpToLog(const string& tag, const PathGeneratorData::TurnPath& turnPath);
} // namespace Svg

}} // namespace yanmar::PathPlan

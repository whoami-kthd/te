// Yanmar Confidential 20200918
/**
 @file PathGeneratorError.cpp
 
 パス生成エラークラス
 */

#include "PathGeneratorError.hpp"
#include "PathPlanConstant.hpp"
#include "PathLib.h"

namespace yanmar { namespace PathPlan {
using namespace std;
using namespace PathGeneratorData;


ErrorPathGenerator::ErrorPathGenerator(const PathGenerator& pathData) :
    super("INFORM")
{   
    segments.push_back(pathData.traverseInfo.fps);
    segments.push_back(pathData.traverseInfo.sps);
    outputPath.insert(outputPath.end(), pathData.outputPathData.begin(), pathData.outputPathData.end());	// エラー発生時パスデータ
    if (!pathData.inputPathNodeList.empty()) {
        srcPoint = pathData.endPoints.src;
        destPoint = pathData.endPoints.dest;
    }
    gauge = pathData.gauge;
}

ErrorPathGenerator::ErrorPathGenerator(const PathFPS& aFps, const PathSPS& aSps, const char* msg) :
    super(msg),
    fps(new PathFPS{aFps}),
    sps(new PathSPS{aSps})
{
    path.emplace_back(aFps);
    path.emplace_back(aSps);
}

ErrorPathGenerator::ErrorPathGenerator(const PathGeneratorData::TraverseInfo& traverseInfo, const char* msg) :
    ErrorPathGenerator(traverseInfo.fps, traverseInfo.sps, msg)
{}

ErrorPathGenerator::ErrorPathGenerator(const OutNodeList& pathData) :
    super("")
{}

ErrorPathGenerator::ErrorPathGenerator(const OutPathData& pathData) :
    super(""),
    outputPath(pathData)
{}

/**
 デバッグログ出力
 */
void ErrorPathGenerator::printLog() const {
    const auto tagstr = logtag.c_str();
    LOGE(tagstr, "%s", what());

#ifdef DEBUG_LOG
    LOGE(tagstr, "%s", description.c_str());
    if (!points.empty()) {
        int index = 0;
        for (const auto& point : points) {
            LOGE(tagstr, "points[%d]: %s\n", index, to_string(point).c_str());
            index++;
        }
    }
    if (fps) {
        LOGE(tagstr, "%s", to_string(*fps).c_str());
    }
    if (sps) {
        LOGE(tagstr, "%s", to_string(*sps).c_str());
    }
    if (!circles.empty()) {
        LOGE(tagstr, "%s", dumpHltcList(circles).c_str());
    }
    if (!segments.empty()) {
        int index = 0;
        for (const auto& segment : segments) {
            LOGE(tagstr, "segments[%d]: %s", index, to_string(segment).c_str());
            index++;
        }
    }
    if (!path.empty()) {
        int index = 0;
        for (const auto& segment : path) {
            LOGE(tagstr, "path[%d]: %s", index, to_string(segment).c_str());
            index++;
        }
    }
    LOGE(tagstr, "srcPoint : %s", to_string(srcPoint).c_str());
    LOGE(tagstr, "destPoint: %s", to_string(destPoint).c_str());
#endif // DEBUG_LOG
}

template<>
void throw_if_not<ErrorPathGenerator>(bool condition, const char* code, const char* desc) {
    if (!condition) {
        LOGE("[EXCEPTION]", "%s:%s", code, desc);
        ErrorPathGenerator err(code);
        err.setDescription(desc);
        throw err;
    }
}

}} // namespace yanmar::PathPlan::PathGeneratorData

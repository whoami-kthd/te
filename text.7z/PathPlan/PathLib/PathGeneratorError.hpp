// Yanmar Confidential 20200918
/**
 @file PathGeneratorError.hpp
 
 パス生成エラークラス
 */
#pragma once

#include "PathPlanIF.hpp"

#include <string>
#include <vector>

#include "PathGeneratorData.hpp"
#include "Gauge.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;
class PathGenerator;

/**
 PathGeneratorエラークラス
 */
class ErrorPathGenerator : public Error
{
    using super = Error;
    
    using TurnPath = PathGeneratorData::TurnPath;
    using TraverseInfo = PathGeneratorData::TraverseInfo;
    using HLTCList = PathGeneratorData::HLTCList;
    using PathFPS = PathGeneratorData::PathFPS;
    using PathSPS = PathGeneratorData::PathSPS;
    using HwParam = PathGeneratorData::HwParam;

public:
    using super::super;
    ErrorPathGenerator() = default;
    explicit ErrorPathGenerator(const char* str) : super(str) {}
    explicit ErrorPathGenerator(const PathGenerator& pathData);
    explicit ErrorPathGenerator(const OutNodeList& pathData);
    explicit ErrorPathGenerator(const OutPathData& pathData);

    ErrorPathGenerator(const PathFPS& fps, const PathSPS& sps, const char* msg);
    ErrorPathGenerator(const TraverseInfo& traverseInfo, const char* msg);

    void addPath(const OutPathData& aPath) {
        path.insert(path.end(), aPath.begin(), aPath.end());
    }

    void addCircle(const Circle& circle) {
        circles.emplace_back(circle, Boundary::nullobj);
    }
    
    virtual void printLog() const;

public:
    std::shared_ptr<PathFPS> fps;
    std::shared_ptr<PathSPS> sps;
    
    vector<XY_Point> points;	///< エラー発生点
    XY_Point srcPoint;          ///< 開始ナビゲーション開始ノード座標
    XY_Point destPoint;         ///< 終了ナビゲーション終了ノード座標
    vector<GenSegment> segments;	///< エラー発生時セグメント
    OutPathData outputPath;	///< エラー発生時生成済みパス
    OutPathData path;		///< エラー発生パスデータ
    HLTCList circles;           ///< エラー発生時ターンサークル
    Gauge gauge;                ///< エラー発生時のゲージ
    HwParam hwParam;            ///< エラー発生時のHWパラメータ
};

/**
 リトライオーバー時エラークラステンプレート
 */
template<class T>
class ErrorRetryOver : public T
{
    using super = Error;

public:
    explicit ErrorRetryOver(const T& src) :
        T(src)
    {
        retryMsg = src.what();
        // "E-PP-x80"に置換する
        retryMsg.replace(6, 2, "80");
    }

    virtual const char* what() const noexcept {
        return retryMsg.c_str();
    }

public:
    std::string retryMsg;
};
    
template<>
void throw_if_not<ErrorPathGenerator>(bool condition, const char* code, const char* desc);

#if defined(NDEBUG)
#define PGASSERT(condition, desc)
#else
#define PGASSERT(condition, desc) \
throw_if_not<ErrorPathGenerator>(condition, ErrorCode::FATAL, desc);
#endif // NDEBUG

}} // namespace yanmar::PathPlan

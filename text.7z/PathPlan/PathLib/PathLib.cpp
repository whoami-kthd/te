// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] PATH GENERATION                                                */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company                :            xxxx xxxxxxxxxxxx xxxx xxxxxxxxx     */
/* Client                 :            YANMAR Co. Ltd, JAPAN                */
/* Author                 :            MANUJ SHARMA,GAURAV                  */
/*                                     ( YANMAR PathPlanning Team )         */
/* Version                :            1.1                                  */
/*                                                                          */
/* The purpose of PathLib data class is to Create and process turning path  */
/* out of created path from OutLib class.It stores the created path in      */
/* a structure which is later used for sending it to display functionality. */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140107                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/****************************************************************************/
/// @internal @defgroup PathGenerator  PathGenerator interface

//#define TXT_FILE_ENABLE
//#define LOGLEVEL 5

// 枕地ターンポイントのモード
// - EHP使用
#define CONVEX_TURNCIRCLE_ON_EHP true
// - 凸頂点の枕地ターンポイントをコーナー内側に配置する
#define CONVEX_TURNCIRCLE_INSIDE false
// オフセット回り耕のときの作業パス短縮に対し、パス脚長を補填する
#define PRESERVE_WORKPATH_ORG_POINT true
// コーナーターンサークルのシフト量制限
// - 制限しないことで凹頂点近くのFPS側のターンサークル交差が回避できるが、コの字型の凹頂点近くにFPS/SPSとも存在するようなケースで、SPS側に回避不能のターンサークル交差ができる。
#define LIMIT_TC_SHIFT true

#include "PolyLib/Common.h"
#include "PathLib.h"

#include <cstdlib>
#include <string>
#include <stdexcept>
#include <ostream>
#include <utility>
#include <iterator>
#include <algorithm>

#include "PathGauge.hpp"
#include "PolyLib/PolygonUtil.hpp"
#include "IteratorUtils.hpp"
#include "DataConverter/OutputDataStream.hpp"
#include "PathExtent.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

using namespace Param::Path;
using namespace SegmentType;
using namespace VertexType;
using namespace RotateDirection;
using namespace PathGeneratorData;


//
// PathGenerator definition
//
#pragma mark - PathGenerator
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathGenerator"

/**
 コンストラクタ
 */
PathGenerator::PathGenerator(ContextIF& aContext) :
    context(aContext),
    pathValidator(gauge, traverseInfo, traverseInfo.HCP, boundarySet),
    pathAssembler(aContext, gauge, pathValidator)
{}

/** @ingroup PathGenerator
 ノードリスト入力
 
 Outlibが生成したノードリスト OutNodeList を内部にコピーする。
	- このノードを順につないだパスを生成する
 
 @param[in] tp outlibが生成するOutNodeList
 */
void PathGenerator::setNodePathList(const OutNodeList& tp) {
	LOGV(LOG_TAG "::setNodePathList", "()");
	
	inputPathNodeList = tp;
    
    if (!inputPathNodeList.empty()) {
        endPoints.src = inputPathNodeList.front().point();
        endPoints.dest = hwParam.endPos2;

    }
}

/**
 冗長ノード削除
 
 NaviPathのうち不要なノードを削除する。
	- パスノードのうち、作業パス端点ではないもの
	- isNodePath()はダミーパスも含まない
 */
void PathGenerator::removeRedundantNode() {
	LOGV(LOG_TAG "::removeRedundantNode", "()");
         
    if (gauge.headland.process == Param::Work::Headland::Process::PRE) {
        // 最初のナビゲーションパス削除
        auto firstRasterIt = find_if(inputPathNodeList.begin(), inputPathNodeList.end(),
                                     [](tData& ci) {
                                         return (0 <= ci.index && ci.nodeType == tData::NodeType::PATHNODE_1);
                                     });
        inputPathNodeList.erase(inputPathNodeList.begin(), firstRasterIt);
    }

    inputPathNodeList.remove_if([this](tData& curr) { return (isNodePath(curr) && (curr.nodeType != tData::NodeType::PATHNODE_1 && curr.nodeType != tData::NodeType::PATHNODE_2)); });
}

/**
 作業パスノード検索
 OutNodeList内の指定範囲から作業パスのノードを指すイテレータのペアを返す。
 @param[in] beginIt 検索開始位置
 @param[in] beginEnd 検索終了値位置
 @return std::pair　first:始点ノードイテレータ, second 終点ノードイテレータ
 */
std::pair<OutNodeList::iterator, OutNodeList::iterator> findWorkPathNodes(OutNodeList::iterator beginIt, OutNodeList::iterator endIt) {
    auto eit = std::adjacent_find(beginIt, endIt,
                                    [](tData& node1, tData& node2) {
                                        return (node1.nodeType == tData::NodeType::PATHNODE_1 && node2.nodeType == tData::NodeType::PATHNODE_2);
                                    });
    auto lit =  (eit != endIt) ? std::next(eit) : endIt;

    return {eit, lit};
}

/**
 冗長ノード削除
 
 NaviPathのうち不要なノードを削除する。
    - パスノードのうち、作業パス端点ではないもの
    - isNodePath()はダミーパスも含まない
 */
void uniteCollinearWorkPath(OutNodeList& nodeList, double minDistance) {
    LOGV(LOG_TAG "uniteCollinearWorkPath", "()");

    auto it = nodeList.begin();
    while (it != nodeList.end()) {
        auto itsFps = findWorkPathNodes(it, nodeList.end());
        LOGD(LOG_TAG "uniteCollinearWorkPath()", "FPS nodeList[%d]", (int)std::distance(nodeList.begin(), itsFps.first));
        if (itsFps.first == nodeList.end()) {
            break;
        }
        auto itsSps = findWorkPathNodes(itsFps.second, nodeList.end());
        LOGD(LOG_TAG "uniteCollinearWorkPath()", "SPS nodeList[%d]", (int)std::distance(nodeList.begin(), itsSps.first));
        if (itsSps.first == nodeList.end()) {
            break;
        }
        //  FPS/SPSセグメント
        LineSegment fpsSeg{itsFps.first->point(), itsFps.second->point()};
        const LineSegment spsSeg{itsSps.first->point(), itsSps.second->point()};
        // 検査
        // - 同一直線上にあり、かつ交差しているか端点が近すぎてナビゲーションパスで結べない
        if (isCollinear(fpsSeg, spsSeg)) {
            if (fpsSeg.checkIntersection(spsSeg) != Intersection::NO ||
                (isIsometric(fpsSeg.enterPoint(), spsSeg.enterPoint()) && isIsometric(fpsSeg.leavePoint(), spsSeg.leavePoint())) ||
                fpsSeg.leavePoint().distance(spsSeg.enterPoint()) < minDistance) {
                LOGD(LOG_TAG "uniteCollinearWorkPath()", "unite FPS - SPS (distance:%g)\n%s\n%s", fpsSeg.leavePoint().distance(spsSeg.enterPoint()), Svg::to_path(fpsSeg).c_str(), Svg::to_path(spsSeg).c_str());
                // 結合(間のノード削除)
                // 結合した場合はitを進めない(結合後のセグメントをFPSとしたチェックが必要なため)
                nodeList.erase(itsFps.second, itsSps.second);
            } else {
                LOGD(LOG_TAG "uniteCollinearWorkPath()", "skip unite FPS - SPS (distance:%g)\n%s\n%s", fpsSeg.leavePoint().distance(spsSeg.enterPoint()), Svg::to_path(fpsSeg).c_str(), Svg::to_path(spsSeg).c_str());
                it = itsSps.first;
            }
        } else {
            LOGD(LOG_TAG "uniteCollinearWorkPath()", "no collinear");
            it = itsSps.first;
        }
    }
}

/**
 ラスターパスノード生成
 ラスター作業パスの作業機航跡がHP全体をカバーするようにノードリストのノード位置を前後に拡張する。
 - オフセットを考慮した実際の作業航跡と脱出HP辺の表す直線との交点から求める。厳密には実際のポリゴン辺と一致はしない。
 - 延長量の上限は脱出辺の端点、即ち隣の頂点。
 */
void PathGenerator::makeStrictRasterPathNode() {
    LOGV(LOG_TAG "::makeStrictRasterPathNode", "()");

    const double halfWc = (gauge.implement.cultivationWidth / 2.0);

    for (auto eit = inputPathNodeList.begin(); eit != inputPathNodeList.end(); std::advance(eit, 1)) {
        auto lit = std::next(eit);
        if (lit == inputPathNodeList.end()) {
            break;
        }
        // 作業パスセグメント
        auto& node1 = *eit;
        auto& node2 = *lit;
        if (node1.index >= 0 && node2.index >= 0 && node1.nodeType == tData::NodeType::PATHNODE_1 && node2.nodeType == tData::NodeType::PATHNODE_2) {
//            LOGD(LOG_TAG "::makeStrictRasterPathNode", "[node] (%.015g, %.015g) (%.015g, %.015g) (%.015g, %.015g)\"/>",
//                 node1.point().x, node1.point().y, node1.pointEdge1().x, node1.pointEdge1().y, node1.pointEdge2().x, node1.pointEdge2().y);
        } else {
//            LOGD(LOG_TAG "::makeStrictRasterPathNode", "[skip] (%.015g, %.015g) (%.015g, %.015g) (%.015g, %.015g) skip\"/>",
//                 node1.point().x, node1.point().y, node1.pointEdge1().x, node1.pointEdge1().y, node1.pointEdge2().x, node1.pointEdge2().y);
            continue;
        }
        LineSegment seg{node1.point(), node2.point()};
        const double curLen = seg.length();
        if (curLen <= 0.0) {
            LOGD(LOG_TAG "::makeStrictRasterPathNode", "[WARN] ZERO length working path.\n%s", Svg::to_path_d(seg).c_str());
            continue;
        }

        // 作業パスセグメントに対応する作業耕跡
        const double offset = -gauge.implement.cultivationWidthOffset;    // 作業機オフセット値は右が正なので符号反転する
        const double dirSign = offsetSign(seg.getVector().y);
        // - 業耕跡の左右辺距離
        const double wtLeftDistance = offset + halfWc;
        const double wtRightDistance = offset - halfWc;
        // - 作業耕跡の左右辺
        auto wtLeft = getCollateralSegment(seg, wtLeftDistance);
        auto wtRight = getCollateralSegment(seg, wtRightDistance);

        // - 延長長
        struct {
            double head = 0.0;
            double tail = 0.0;
        } extLengths;
		{
			// 外周作業用HPの塗り潰しを判定して伸縮するバージョン
			// PolygonUtilの定義が上書きされてて使えないので
			typedef std::vector<Point2D> Polygon;
			typedef std::vector<Polygon_> Polygons;
			// 内側の作業パスで塗り潰す必要がある領域
			Polygon_ hp = Polygon_(new Polygon);
			Polygon_ hp2 = Polygon_(new Polygon);
			if (hwParam.whp.size()) {
				// 外周作業用HPがある場合、外周作業用HPを使用
				for (int i = 0; i < hwParam.whp.size(); ++i) {
					hp->push_back(hwParam.whp[i]);
				}
				for (int i = 0; i < boundarySet.hp().size(); ++i) {
					hp2->push_back(boundarySet.hp()[i]);
				}
			} else {
				// 外周作業用HPがない場合
				for (int i = 0; i < boundarySet.hp().size(); ++i) {
					hp->push_back(boundarySet.hp()[i]);
				}
				for (int i = 0; i < boundarySet.hp().size(); ++i) {
					hp2->push_back(boundarySet.hp()[i]);
				}
			}
			// HPのバウンディングボックス
			Point2D hpMin, hpMax;
			PolygonUtil::boundingBox(hp, &hpMin, &hpMax);
			// x方向は、この作業パスが塗りつぶす幅
			hpMin.x = min(wtLeft.point1().x, wtRight.point1().x);
			hpMax.x = max(wtLeft.point1().x, wtRight.point1().x);
			// y方向は、HPが確実に納まるように拡大
			hpMin.y -= 1;
			hpMax.y += 1;
			// HPから切り抜く矩形
			Polygon_ box = PolygonUtil::box2Polygon(hpMin, hpMax);
			// 塗り潰し領域のリスト
			Polygons_ fillPolygons = Polygons_(new Polygons);
			PolygonUtil::intersection(hp, box, fillPolygons);
			// この作業パスに対応する塗り潰し領域を特定する
			const double yMin = min(node1.point().y, node2.point().y);
			const double yMax = max(node1.point().y, node2.point().y);
			Point2D fillMin, fillMax;
			double dMax = -1000000;
			Polygons_ tmpPolygons = Polygons_(new Polygons);
			Polygon_ tmpPolygon = Polygon_(new Polygon);
			// この作業パスが塗り潰す領域を判定する
			for (int i = 0; i < fillPolygons->size(); ++i) {
				Polygon_ fillPolygon = fillPolygons->at(i);
				PolygonUtil::boundingBox(fillPolygon, &fillMin, &fillMax);
				double dTmp = -1000000;
				if (fillMax.y < yMin || yMax < fillMin.y) {
					// オーバーラップがない場合、ギャップのマイナス
					dTmp = -min(abs(fillMax.y - yMin), abs(fillMin.y - yMax));
				} else {
					// オーバーラップがある場合、オーバーラップの大きさ
					dTmp = min(fillMax.y, yMax) - max(fillMin.y, yMin);
					Polygon_ tmp = Polygon_(new Polygon);
					tmp->assign(fillPolygon->begin(), fillPolygon->end());
					tmpPolygons->push_back(tmp);
				}
				if (dTmp > dMax) {
					dMax = dTmp;
					tmpPolygon->swap(*fillPolygon);
				}
			}
			// 塗り潰す必要がある領域の大きさに応じて作業パスの長さを調節する
			tmpPolygons->push_back(tmpPolygon);
			PolygonUtil::boundingBox(tmpPolygons, &fillMin, &fillMax);
			if (wtLeft.point1().y < wtLeft.point2().y) {
				// 上向き
				extLengths.head = -dirSign * (fillMin.y - seg.enterPoint().y);
				extLengths.tail = dirSign * (fillMax.y - seg.leavePoint().y);
			} else {
				// 下向き
				extLengths.head = -dirSign * (fillMax.y - seg.enterPoint().y);
				extLengths.tail = dirSign * (fillMin.y - seg.leavePoint().y);
			}
			// ヒッチアップ・ダウンマージン
			extLengths.head += gauge.workPath.compensateLength;
			extLengths.tail += gauge.workPath.compensateLength;
			// オフセット周回経路のE-PP-606対応
			// TODO:内側作業のパターン(半渦巻き)を持ってないため、走行(GNSS)位置が塗り潰し範囲外であることで判定
			if (seg.point1().x < hpMin.x || hpMax.x < seg.point1().x) {
				// パス足が、完全にHP内部にめり込むのはNG (そうならない範囲で縮めるように制限する)
				std::vector<Point2D> crossPoints;crossPoints.clear();
				PolygonUtil::getCrossPoints(hp2, seg.point1(), seg.point2(), &crossPoints);
				if (crossPoints.size() >= 2) {
					double y1 = yMin;
					double y2 = yMax;
					for (auto p : crossPoints) {
						y1 = std::max(y1, p.y);
						y2 = std::min(y2, p.y);
					}
					if (seg.point1().y < seg.point2().y) {
						double y_ = y1;
						y1 = y2;
						y2 = y_;
					}
					extLengths.head = std::max(extLengths.head, -fabs(seg.point1().y - y1) - gauge.minSpsLegLength + TOL_MICRO);
					extLengths.tail = std::max(extLengths.tail, -fabs(seg.point2().y - y2) - gauge.minFpsLegLength + TOL_MICRO);
				}
			}
		}
		// ヒッチアップ・ダウンマージンを含めた最小保証
		// - 縮める場合もあるため。
		const double afterLen = curLen + extLengths.head + extLengths.tail;
		if (afterLen < gauge.workPath.length.min + gauge.workPath.compensateLength * 2.0) {
			const double addLen = (gauge.workPath.length.min + gauge.workPath.compensateLength * 2.0 - afterLen) * 0.5 + TOL_MICRO;
			extLengths.head += addLen;
			extLengths.tail += addLen;
		}
        
        // 延長処理
        // - 入口側延長
        seg.shiftEnterPointHeadward(extLengths.head);
        // - 出口側延長
        seg.shiftLeavePointTailward(extLengths.tail);
        // ノードリストに書き戻す
        node1.point() = seg.enterPoint();
        node2.point() = seg.leavePoint();
//        LOGD(LOG_TAG "::makeStrictRasterPathNode", "[RasterSeg]<path stroke=\"black\" d=\"%s\"/>", Svg::to_path_d(seg).c_str());
    }
    
    // 共線パス接続
    // - 伸ばした結果、間が狭い共線パスができたかもしれないので、接続してしまう。
    const double minDistance = gauge.minFpsLegLength + gauge.minSpsLegLength;
    uniteCollinearWorkPath(inputPathNodeList, minDistance);

    // 作業範囲の集合
    auto it = inputPathNodeList.begin();
    while (it != inputPathNodeList.end()) {
        auto itsFps = findWorkPathNodes(it, inputPathNodeList.end());
        if (itsFps.first == inputPathNodeList.end()) {
            break;
        }
        // FPSセグメント
        LineSegment fpsSeg{itsFps.first->point(), itsFps.second->point()};
        if (!fpsSeg.isNegrective()) {
            // 作業パスセグメントに対応する作業耕跡
            const double offset = -gauge.implement.cultivationWidthOffset;    // 作業機オフセット値は右が正なので符号反転する
            // - 作業耕跡矩形
            const double wtLeftDistance = offset + halfWc;
            const double wtRightDistance = offset - halfWc;
            auto wtLeft = getCollateralSegment(fpsSeg, wtLeftDistance);
            auto wtRight = getCollateralSegment(fpsSeg, wtRightDistance);
            const LineSegment wtFront{wtLeft.leavePoint(), wtRight.leavePoint()};
            const LineSegment wtRear{wtRight.enterPoint(), wtLeft.enterPoint()};;
            wtRight.exchange();

            rasterSegList.push_back(wtLeft);
            rasterSegList.push_back(wtFront);
            rasterSegList.push_back(wtRight);
            rasterSegList.push_back(wtRear);
        }

        it = itsFps.second;
        it++;
        if (it == inputPathNodeList.end()) {
            break;
        }
    }
    LOGD(LOG_TAG "::makeStrictRasterPathNode", "rasterSegList:\n%s", Svg::to_path_d(rasterSegList).c_str());
}

/**  @ingroup PathGenerator
 回転パラメータ設定
 
 回転基準点と回転角を保存する。パス生成後に元の方向に戻すため。
 
 @return none
 */
void PathGenerator::setRotationPara(const XY_Point& refPoint, float rotateAngle) {
	LOGV(LOG_TAG "::setRotationPara", "()");
	rotater.setAngle(rotateAngle);
	rotater.setOrigin(refPoint);
}

/**  @ingroup PathGenerator
 パスデータ回転(Display用)
 
 パスデータを回転し内部方角から元の方角へ戻す。
 
 @return none
 */
void PathGenerator::rotatePathDataDisplay() {
	LOGV(LOG_TAG "::rotatePathDataDisplay", "()");
	
	for (auto& ci : outputPathData) {
		ci.Circ.center = rotater.rotateByOrigin(ci.Circ.center - rotater.origin);
		for (auto& pos : ci.points) {
			pos = rotater.rotateByOrigin(pos - rotater.origin);
		}
	}

    // 内部生成したポリゴン(デバッグ用)
    auto& whp = hwParam.whp;
    for_each(whp.begin(), whp.end(), [&](XY_Point& point) { point = rotater.rotateByOrigin(point - rotater.origin); });
    auto& ehp = boundarySet.ehp();
    for_each(ehp.begin(), ehp.end(), [&](XY_Point& point) { point = rotater.rotateByOrigin(point - rotater.origin); });

    endPoints.src = rotater.rotateByOrigin(endPoints.src - rotater.origin);
    endPoints.dest = rotater.rotateByOrigin(endPoints.dest - rotater.origin);
}

/**
 圃場境界データ設定
 
 BP(OBP),HP(OHP)のポリゴン頂点を取り出し、頂点除外フラグとともに圃場境界(Boundaries)を作成する。
 
 @param[in] extents  外形ポリゴンリスト
 @param[in] hlps     作業領域ポリゴンリスト
 */
void PathGenerator::setBoundary(const Polygons& extents, const Polygons& hlps, const HwParam& aHwParam) {
	LOGV(LOG_TAG "::setBoundary", "()");
	PGASSERT(0 < extents.size(), ErrorCode::PathGeneration::FATAL);

	NoBP = (int)extents[0].size();
	NoOB = std::max(0, (int)extents.size() - 1);
	NoOBP = NoOB * OBsize;

    boundarySet = BoundarySet(extents, hlps, aHwParam, gauge);
    hwParam = aHwParam;

//  dumpBoundary("BoundariesFLD.txt", Fld);
//  dumpBoundary("BoundariesObst.txt", Obst);
}

/** @ingroup PathGenerator
 ターンデータ設定
 
 ターン生成時の限界値(Gauge)を設定する。
 
 @param[in] hPara  FieldPolygonの産出値
 @param[in] inData パスプラン入力データ
 */
void PathGenerator::setGauge(const FpGauge& hPara, const InputData& inData) {
	// ターン制限値
    gauge = {hPara, inData};
    
    LOGD(LOG_TAG "::setGauge", "%s", PathPlan::to_string(gauge).c_str());
}

/** @ingroup PathGenerator
 ABパス生成
 
 指定ノードリスト分の作業パスを生成してパスデータに出力する。
    - 作業パス間は接続はしない。
    - パスデータに対する検査はない。
 */
void PathGenerator::generatePathDataAB() {
    try {
        for (auto itr = inputPathNodeList.cbegin(); itr != inputPathNodeList.cend(); ++itr) {
            auto itr1 = itr;
            itr++;
            if (itr == inputPathNodeList.end()) {
                ErrorPathGenerator err(ErrorCode::PathGeneration::FATAL);
       			err.setDescription("[EXCEPTION:EXCEPTION:PATH_GENERATION] odd number of nodes.", "::generatePathDataAB");
                throw err;
            }
            PathSegmentAB segAB{*itr1, *itr};
            outputPathData.emplace_back(segAB);
        }
    } catch (const ErrorPathGenerator& e) {
        LOGE(LOG_TAG, "%s", e.what());
        throw;
    }
}

/**
 ラスターパス生成
 
 ラスターパス(従来の作業パス)の生成。
 ノードリスト順にノードを結び、作業パスと作業パス間を繋ぐターンパスを生成する。
 */
int PathGenerator::createRasterPath() {
    LOGV(LOG_TAG "::createRasterPath", "()");
    auto& HCP = traverseInfo.HCP;

    for (auto ci = inputPathNodeList.begin(); ci != inputPathNodeList.end();) {
        context.abortIfRequested("Abort: during PathGenerator.");
        
        // 最初の作業パスの手前に空走りを追加するためのダミーデータが設定されている場合
        if (ci->getIndex() == START_EXTENSION) {
            // ダミーデータスキップ
            ci++;
            // 作業パスのデータ
            const auto& node1 = *ci;
            const auto& node2 = *next(ci);
            traverseInfo.sps = PathSPS{node1, node2, gauge.minSpsLegLength};
            // 最小開始ナビゲーションパス追加
            traverseInfo.mode = TraverseInfo::Mode::START_NAV;
            auto path = pathAssembler.getMinimalEnterPath(traverseInfo.sps, gauge.termMin.start);
            validateCreateTurnPathOutput(path);
            addOutputPath(path, PathAttr{PathAttr::RideType::NON_WORKING});
            continue;
        }

        // 移動情報初期化
        traverseInfo = TraverseInfo{};
        
        // ターン生成するパス頂点データを取り出す
        // - 1本目の作業パスの頂点データ(前後2個)+作業パス間の頂点データ(あれば)+2本目の作業パスの頂点データ(前後2個)
        auto localList = getWorkingPathPoints(ci, inputPathNodeList.end());
        if (localList.empty()) {
            // 作業パスがもう無い
            LOGD(LOG_TAG "::createTangentPath", "localList was empty.");
            break;
        }
        
        // 最小パス脚長準備
        const auto first = localList.cbegin();
        double minFpsLegLength = gauge.minFpsLegLength;
        double minSpsLegLength = gauge.minSpsLegLength;
        const auto last = localList.crbegin();    // reverse_iterator
#if (PRESERVE_WORKPATH_ORG_POINT)
//        if (gauge.workPath.pattern == Param::Work::Pattern::SEMICYCLONE) {
//            // 内側作業が回り耕の場合
//            // - 作業パスを大幅に縮めている場合があるため、最小パス脚長を補填しておく。
//            tData fps_n1 = *first;
//            tData fps_n2 = *next(first);
//            if (dotProduct(fps_n1.pointOrg(), fps_n2.pointOrg(), fps_n2.point()) < 0.0) {
//                minFpsLegLength += fps_n2.point().distance(fps_n2.pointOrg());
//            }
//            tData sps_n1 = *next(last);
//            tData sps_n2 = *last;
//            if (dotProduct(sps_n2.pointOrg(), sps_n1.pointOrg(), sps_n1.point()) < 0.0) {
//                minSpsLegLength += sps_n1.point().distance(sps_n1.pointOrg());
//            }
//        }
#endif // PRESERVE_WORKPATH_ORG_POINT
        // FPS生成
        traverseInfo.setFps(*first, *next(first), minFpsLegLength);
        const PathAttr pathAttr = next(first)->pathAttr; // FPSは出口側で見る
        // SPS生成
        traverseInfo.setSps(*next(last), *last, minSpsLegLength);
        // パス生成モード決定
        if (first->getIndex() == START_NAVIGATION) {
            LOGD(LOG_TAG "::createTangentPath", "CREATE: START_NAV");
            // 開始ナビゲーション
            if (gauge.headland.process == Param::Work::Headland::Process::PRE) {
                LOGD(LOG_TAG "::createTangentPath", "SKIP: START_NAV; headland has been proceed.");
                break;
            }
            traverseInfo.mode = TraverseInfo::Mode::START_NAV;
        } else if (last->getIndex() == END_NAVIGATION) {
            LOGD(LOG_TAG "::createTangentPath", "CREATE: END_NAV");
            // 終了ナビゲーション
            if (gauge.headland.process == Param::Work::Headland::Process::POST) {
                LOGD(LOG_TAG "::createTangentPath", "SKIP: END_NAV; headland will be proceed.");
                traverseInfo.fps.setMinimalLeg();
                // 枕地仕上げがあるので仮のセグメントである
                auto path = pathAssembler.getMinimalLeavePath(traverseInfo.fps, gauge.termMin.end, false);
                addOutputPath(path, PathAttr{PathAttr::RideType::WORKING});
                break;
            }
            traverseInfo.mode = TraverseInfo::Mode::END_NAV;
        } else {
            LOGD(LOG_TAG "::createTangentPath", "CREATE: INTER_PATH");
            // その他ターンパス
            traverseInfo.mode = TraverseInfo::Mode::INTER_PATH;
        }
        
        // ノードリストからターンポイントをHCPに抽出(ターンサークル内容は未設定)
        HCP = extractTurnPoints(localList);
        
        try {
            // ターンパスの生成
            createTurnPath();
            // 出力パスデータに追加
            addOutputPath(pathBuffer, pathAttr);
        } catch (const ErrorPathGenerator& e) {
            // 出来たところまでは出力
            addOutputPath(pathBuffer, pathAttr);
            LOGE(LOG_TAG, "%s", e.what());
            throw;
        }
        
        if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
            // 終了ナビゲーションを生成したらパス終了
            break;
        }
    }

    return SUCCESS;
}

/**
 周回パス生成(先・枕地作成用)
 
 草刈り、稲刈りなど、先に枕地分の作業を行うための場合の周回パスを生成する。
 末尾は最後にラスター作業パスへ繋がる。
 - クラスメンバーのパラメータから生成する周回パスのパターンを決定し、周回パス生成関数を呼び出す。
 - ラスター作業パス
 */
int PathGenerator::createPreOrbitalPath() {
    LOGV(LOG_TAG "::createPreOrbitalPath", "()");

    traverseInfo.mode = TraverseInfo::Mode::ORBITAL;
    traverseInfo.turnType = Turn::Type::NAVIGATION;
    pathBuffer.clear();

    // 開始ノード保存
    // TODO: アクセス前にチェック
    {
        auto it = next(inputPathNodeList.begin());
        traverseInfo.orbital.firstCornerNode = it->index;
    }
    
    // 周回方向
    const int rotation = gauge.headland.rotation;
    
    // SPSを生成する
    auto ci = inputPathNodeList.begin();
    auto itsSps = findWorkPathNodes(ci, inputPathNodeList.end());
    traverseInfo.setSps(*itsSps.first, *itsSps.second, gauge.minSpsLegLength);
    traverseInfo.sps.setMinimalLeg();
    traverseInfo.sps.setTurnCircle(rotation, gauge.turnRadius);
    
    const auto destSeg = traverseInfo.sps.getSegment();
    auto rasterEnterPoint = destSeg.enterPoint(); // ラスター進入点

    // 周回パス生成
    auto field = boundarySet.field;
    auto destSeg0 = destSeg;
    
    // パラメータ準備
    const double clearance = gauge.getOrbitalClearance(hasConcave(field), rotation);
    gauge.fpGauge.headLandRasters += gauge.headland.coverRaster;
    OrbitalPathParam params{gauge, clearance};
    // - WHPとSHPの間で枕地を横断するスタートラインを張る。
    LineSegment startLine{endPoints.src, hwParam.startPos};
    startLine.extendHead(gauge.actSHD);
    startLine.extendTail(hwParam.additionalWidth);
    traverseInfo.orbital.startLine = startLine;
    LOGD(LOG_TAG "::createPreOrbitalPath", "startLine: %s", to_string(startLine).c_str());

    // 周回パス辺生成
    auto edgeList = makeEdgeList(destSeg0, field, traverseInfo.orbital.firstCornerNode, params);
    LOGD(LOG_TAG "::createPreOrbitalPath", "edgeList\n%s", Svg::to_path(edgeList).c_str());

    // 周回パス本体生成
    TurnPath path;
    try {
        path = createOrbitalPath(edgeList, params);
        pathValidator.validateSegmentPropaties(path);
        pathValidator.validatePointVectorInside(path);
        // 端点がBP抵触する可能性があるまのでまだ検査してはいけない。
        // pathValidator.validateIntersectionWithShp(path);
    } catch (ErrorPathGenerator& err) {
        LOGE(LOG_TAG "::createPreOrbitalPath", "createOrbitalPath returns invalid path: %s", Svg::to_path(path).c_str());
        if (err.compareErrorCode(ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE)) {
            // コーナー間距離の問題はリカバリできない
            throw;
        }
        path.invalidate();
    } catch (...) {
        path.invalidate();
    }

    if (!path.isValid()) {
        LOGE(LOG_TAG "::createPreOrbitalPath", "createOrbitalPath returns invalid");
        ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::Orbital::GENERAL);
        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] pre-orbital path genration.", "::createPreOrbitalPath");
        throw err;
    }
    
    path.open();
    // 先頭はパス脚なので削除
    path.erase(path.begin());
   
    // 進入ターン

    // 最後のパス脚を削減する
    if (2 < path.size()) {
        // 非作業パスに続くパス脚は長さに制限は無い
        auto& prevSeg = path.back();
        auto& prevSeg0 = *std::next(path.rbegin());
        auto& prevSeg1 = *std::next(path.rbegin(), 2);
        if (prevSeg1.pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING && prevSeg1.direction == SegmentDir::FORWARD &&
            prevSeg0.segmentType == SegmentType::LINESEG && prevSeg0.pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING && prevSeg0.direction == SegmentDir::FORWARD &&
            prevSeg.segmentType == SegmentType::LINESEG && prevSeg.pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING && prevSeg.direction == SegmentDir::FORWARD) {
            LOGD(LOG_TAG "::createPreOrbitalPath", "[Orbit to Rster trun]: shorten last leg");
            prevSeg0 = getFromHead(prevSeg0, 0.1);
            prevSeg.enterPoint() = prevSeg0.leavePoint();
        }
    }
    // 最終セグメント
    const auto lastSeg = path.lastSegment();
    auto srcSeg = lastSeg;
    LOGD(LOG_TAG "::createPreOrbitalPath", "[Orbit to Rster trun]: \n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
         Svg::to_path_d(srcSeg).c_str(), Svg::to_path_d(destSeg).c_str());
    // - ラスター進入ターン生成
    TurnPath transitPath;
    if (connectAny(srcSeg, destSeg0) && isCollinear(srcSeg, lastSeg)) {
        // コーナーを形成可能、かつ、向きが変わっていない
        if (gauge.headland.permitBackward) {
            auto destleg = traverseInfo.sps.getHeadLeg();
            PathSegment destPSeg{destleg};
            LOGD(LOG_TAG "::createPreOrbitalPath", "[Orbit to Rster trun]: \n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n\"/>",
                 Svg::to_path_d(srcSeg).c_str(), Svg::to_path_d(destPSeg).c_str());
            transitPath = pathAssembler.getValidatedEnterRasterTurnPath(srcSeg, destPSeg, WhiskerMode::NONE);
        } else {
            transitPath = pathAssembler.getPlainTurnPath(srcSeg, destSeg, WhiskerMode::NONE);
        }
    } else {
        LOGD(LOG_TAG "::createPreOrbitalPath", "[ERROR] edge connection failed");
    }
    // - 有効性検査
    // - 失敗した場合、フィッシュテールターンに切り替える必要がある
    if (transitPath.isValid()) {
        transitPath.open();
        transitPath.back().pathAttr.rideType = PathParam::Segment::RideType::NON_WORKING;
//        path.back().leavePoint() = transitPath.front().enterPoint();
        transitPath.applyTurnType();
        int result = pathAssembler.connectTurnToTurn(path, transitPath, gauge.headland.permitBackward);
        transitPath.terminate(rasterEnterPoint);
        if (result != SUCCESS) {
            transitPath.invalidate();
        } else {
            LOGD(LOG_TAG "::createPreOrbitalPath", "transitPath\n%s", Svg::to_path(transitPath).c_str());
            try {
                // パス脚長検査
                if (!pathValidator.checkFPSLegLength(transitPath.getLastSegment())) {
                    LOGE(LOG_TAG "::createPreOrbitalPath", "too short path leg:%.15g / min:%.15g\n%s",
                         transitPath.getLastSegment().length(), gauge.minFpsLegLength, Svg::to_path(transitPath).c_str());
                    transitPath.invalidate();
                } else {
                    // その他検査
                    pathValidator.validateSegmentPropaties(transitPath);
                    pathValidator.validatePointVectorInside(transitPath);
                    pathValidator.validateIntersectionWithShp(transitPath);
                }
            } catch (...) {
                LOGD(LOG_TAG "::createPreOrbitalPath", "edgeList\n%s", Svg::to_path(transitPath).c_str());
                transitPath.invalidate();
            }
        }
    }
    // バック許可の場合、プレーンターンも試す
    if (!transitPath.isValid() && gauge.headland.permitBackward) {
        path.terminate();
        path.open();
        auto srcSeg = path.getLastSegment();
        transitPath = pathAssembler.getPlainTurnPath(srcSeg, destSeg, WhiskerMode::NONE);
        if (transitPath.isValid()) {
            transitPath.open();
            transitPath.erase(transitPath.begin());
            transitPath.back().pathAttr.rideType = PathParam::Segment::RideType::NON_WORKING;
            LOGD(LOG_TAG "::createPreOrbitalPath", "edgeList\n%s", Svg::to_path(transitPath).c_str());
            path.back().leavePoint() = transitPath.front().enterPoint();
            transitPath.terminate(rasterEnterPoint);
            try {
                pathValidator.validatePointVectorInside(transitPath);
                pathValidator.validateIntersectionWithShp(transitPath);
            } catch (...) {
                LOGD(LOG_TAG "::createPreOrbitalPath", "edgeList\n%s", Svg::to_path(transitPath).c_str());
                transitPath.invalidate();
            }
        }
    }
    // - リトライ
    if (!transitPath.isValid()) {
        LOGD(LOG_TAG "::createPreOrbitalPath", "O-R transit retry.");
        pathBuffer.clear();
        LineSegment iTS = edgeList.back();
        edgeList.pop_back();
        LineSegment srcSeg = edgeList.back();
        path = createOrbitalPath(edgeList, params);
        if (!path.isValid()) {
            ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
            err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] pre-orbital path genration.", "::createPreOrbitalPath");
            throw err;
        }
        path.open();
        // 先頭はパス脚なので削除
        path.erase(path.begin());

        // 進入接線(SPSパス脚)
        traverseInfo.sps.setHeadLeg(gauge.minSpsLegLength);
        traverseInfo.sps.setTurnCircle(rotation, gauge.turnRadius);
        destSeg0 = traverseInfo.sps.getHeadLeg();
        // - 算出に使うターンサークル
        const auto& sTc = traverseInfo.sps.Circ;
        
        // O-R遷移パス取得
        if (gauge.headland.permitBackward) {
            // 中間接線(仮)
            const LineSegment iSeg{iTS.getVector(), destSeg0.enterPoint(), iTS.length()};
            auto cornerOrient = getCornerOrient(srcSeg, iSeg);
            iTS = getCollateralSegment(iSeg, -cornerOrient * sTc.radius);
            // 第1コーナー接続
            if (!connectForward(srcSeg, iTS)) {
                ErrorPathGenerator err(PathFPS{}, traverseInfo.sps, ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
                err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] O-R transit first corner invalid.", "::createPreOrbitalPath");
                err.segments.push_back(srcSeg);
                err.segments.push_back(iTS);
                err.segments.push_back(destSeg0);
                Svg::dumpToLog(LOG_TAG, err.segments);
                throw err;
            }
            // 第2コーナー接続
            if (!connectForward(iTS, destSeg0)) {
                ErrorPathGenerator err(PathFPS{}, traverseInfo.sps, ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
                err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] O-R transit last corner invalid.", "::createPreOrbitalPath");
                err.segments.push_back(srcSeg);
                err.segments.push_back(iTS);
                err.segments.push_back(destSeg);
                Svg::dumpToLog(LOG_TAG, err.segments);
                throw err;
            }
            LOGD(LOG_TAG "::createPreOrbitalPath", "O-R transit path (retry)\n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n%s\n\"/>",
                 Svg::to_path_d(srcSeg).c_str(), Svg::to_path_d(iTS).c_str(), Svg::to_path_d(destSeg0).c_str());
            transitPath = pathAssembler.getCornerTurnPath(srcSeg, iTS, destSeg0);
        } else {
            iTS = LineSegment{iTS.getVector(), destSeg0.enterPoint(), iTS.length()};
            LOGD(LOG_TAG "::createPreOrbitalPath", "O-R transit path (retry)\n<path fill=\"none\" opacity=\"1.0\" stroke=\"black\" d=\"\n%s\n%s\n%s\n\"/>",
                 Svg::to_path_d(destSeg0).c_str(), Svg::to_path_d(iTS).c_str(), Svg::to_path_d(destSeg0).c_str());
            // 第1コーナー接続
            if (!connectForward(srcSeg, iTS)) {
                ErrorPathGenerator err(PathFPS{}, traverseInfo.sps, ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
                err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] O-R transit first corner invalid.", "::createPreOrbitalPath");
                err.segments.push_back(srcSeg);
                err.segments.push_back(iTS);
                err.segments.push_back(destSeg0);
                Svg::dumpToLog(LOG_TAG, err.segments);
                throw err;
            }
            // 第2コーナー接続
            if (!connectForward(iTS, destSeg0)) {
                ErrorPathGenerator err(PathFPS{}, traverseInfo.sps, ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
                err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] O-R transit last corner invalid.", "::createPreOrbitalPath");
                err.segments.push_back(srcSeg);
                err.segments.push_back(iTS);
                err.segments.push_back(destSeg);
                Svg::dumpToLog(LOG_TAG, err.segments);
                throw err;
            }
            transitPath = pathAssembler.getHookTurnPath(srcSeg, iTS, destSeg0);
        }
        // 生成成功したか?
        if (!transitPath.isValid()) {
            ErrorPathGenerator err(PathFPS{}, traverseInfo.sps, ErrorCode::PathGeneration::Orbital::ORBITAL_RASTER_TRANSIT);
            err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] R-O transit failed.", "::createPreOrbitalPath");
            err.segments.push_back(srcSeg);
            err.segments.push_back(iTS);
            err.segments.push_back(destSeg0);
            Svg::dumpToLog(LOG_TAG, err.segments);
            throw err;
        }
        // 周回パス接続
        if (path.back().pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING) {
            // 周回パスの最後のセグメントが非作業パスの場合、削除して繋ぐ
            path.terminate();
            path.open();
            transitPath.front().enterPoint() = path.getLeavePoint();
        } else {
            // 周回パスの最後のセグメントが作業パスの場合、transitPath側の1本目の長さをパス足長に調整、path側の最後の長さをtransitPathの始点に合わせる
            transitPath.front() = getFromTail(transitPath.front(), gauge.minFpsLegLength);
            path.back().leavePoint() = transitPath.front().enterPoint();
        }
        transitPath.terminate(rasterEnterPoint);
        transitPath.setTurnType(Turn::Type::NAVIGATION);
#ifdef DEBUG
        pathValidator.validatePointVector(transitPath);
#endif // DEBUG
    }
    
    // 開始ナビゲーション生成
    {
        auto& firstSeg = path.front();

        bool addStartNav = false;
        if (gauge.headland.pattern == Param::Work::Headland::Pattern::ANTICYCLONE) {
            // 開始ナビゲーション生成
            TurnPath startNav = pathAssembler.getValidatedOribitalEnterPath(PathAssembler::EndPoint(endPoints.src), firstSeg);
            if (startNav.isValid()) {
                LOGD(LOG_TAG "::createPreOrbitalPath", "Add Start Nav");
                addStartNav = true;
                startNav.open();
                pathBuffer.pushTurnPath(startNav);
            }
        }
        
        if (!addStartNav && firstSeg.pathAttr.isWorking()) {
            // 先頭が作業パスなので開始ナビゲーションを付ける
            LineSegment leg = getHeadLeg(firstSeg, gauge.minSpsLegLength + gauge.termMin.start);
            if (checkBoundaryIntersection(leg, BoundaryType::Kind::Mask::SBP) == Intersection::NO) {
                LOGD(LOG_TAG "::createPreOrbitalPath", "Add Start Nav");
                addStartNav = true;
                PathSegment startNavSeg{leg};
                startNavSeg.pathAttr.rideType = PathParam::Segment::RideType::ORBITAL_NON_WORKING;
                startNavSeg.turnType = PathParam::Turn::Type::STARTNAV_MIN;
                pathBuffer.pushTurnPath(startNavSeg);
            }
        }

        if (!addStartNav) {
            // 何れも失敗した場合は開始ナビゲーション削除
            // - 始点なのでパス脚がなくても動作できる
            LOGD(LOG_TAG "::createPreOrbitalPath", "Eliminate Start Nav");
            double minLen = gauge.workPath.length.min + gauge.headland.whisker.lengthStep;
            auto extSeg = pathAssembler.ensureNoCollisionHeadward(firstSeg, gauge.headland.whisker.lengthStep, minLen, BoundaryType::Kind::Mask::SBP);
            if (!extSeg.isNegrective()) {
                firstSeg.enterPoint() = extSeg.enterPoint();
                addStartNav = true;
            }
        }
    }
    
    pathBuffer.pushTurnPath(path);
    pathBuffer.pushTurnPath(transitPath);
        
    addOutputPath(pathBuffer, PathAttr{PathAttr::RideType::ORBITAL_NON_WORKING});
    // 検証
    try {
        validateCreateTurnPathOutput(pathBuffer);
    } catch (...) {
        LOGE(LOG_TAG "::createPreOrbitalPath", "[EXCEPTION:TURN_GENERATION_ISSUE] pre orbiatl path is invalid.");
        LOGV(LOG_TAG "::createPreOrbitalPath", "Orbital path:\n%s", Svg::to_path(pathBuffer).c_str());
        throw;
    }
    pathBuffer.clear();

    return SUCCESS;
}

/**
 周回パス生成(後・枕地仕上げ用)
 */
int PathGenerator::createPostOrbitalPath() {
    LOGV(LOG_TAG "::createPostOrbitalPath", "()");

    traverseInfo.mode = TraverseInfo::Mode::ORBITAL;
    traverseInfo.turnType = Turn::Type::NAVIGATION;
    pathBuffer.clear();
    auto field = boundarySet.field;
    // 周回方向
    const int rotation = gauge.headland.rotation;

    // 周回パスの最初のコーナーのインデックスを求める
    // - 外向きなので終点ノード(PATHNODE_2)を見る
    traverseInfo.orbital.firstCornerNode = getRasterLeaveCornerIndex(field);
    
    // 終了ナビゲーションなし(最小)想定なのでFPSである。
    auto& FPS = traverseInfo.fps;
    FPS.setMinimalLeg();
    auto srcSeg = FPS.getSegment();
    auto rasterLeavePoint = srcSeg.leavePoint();
    // パラメータ準備
    const double clearance = gauge.getOrbitalClearance(hasConcave(field), rotation);
    gauge.fpGauge.headLandRasters += gauge.headland.coverRaster;
    OrbitalPathParam params{gauge, clearance};
    // ゴールライン
    // - WHPとSHPの間で枕地を横断するゴールラインを張る。
    if (!inputPathNodeList.empty() && hwParam.endPointAvailable) {
        LineSegment goalLine{endPoints.dest, hwParam.endPos};
        // endPoints.dest側に、BPとの交点まで延長する
        double d = numeric_limits<double>::max();
        for (auto itr = field.begin(); itr != field.end(); ++itr) {
            const auto &bp1 = itr->BP;
            const auto &bp2 = nextCyclic(field, itr)->BP;
            LineSegment bpLine{bp1, bp2};
            GeoPoint cp;
            try {
                cp = getCrossPoint(goalLine, bpLine);
            } catch (const std::runtime_error &e) {
                // 交点が求まらない(平行検査に失敗した)場合
                continue;
            }
            if (!bpLine.isAside(cp)) {
                // BP辺の範囲側で交差する場合は無視
                continue;
            }
            double d1 = endPoints.dest.distance(cp);
            double d2 = hwParam.endPos.distance(cp);
            if (d2 < d1) {
                // hwParam.endPos側の交点は無視
                continue;
            }
            // endPoints.dest側の一番近い交点までの距離を採用する
            if (d1 < d) {
                d = d1;
            }
        }
        goalLine.extendHead(d);
        goalLine.extendTail(params.clearance + gauge.halfActWidth);
        traverseInfo.orbital.goalLine = goalLine;
    }
    
    // 周回パス生成
    // - 周回接線の準備
    auto edgeList = makeEdgeList(srcSeg, field, traverseInfo.orbital.firstCornerNode, params);
    if (edgeList.empty()) {
        LOGE(LOG_TAG "::createPostOrbitalPath", "makeEdgeList returns empty edge list");
        ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::Orbital::GENERAL);
        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] NONE OF ORBITAL EDGE.", "::createPostOrbitalPath");
        throw err;
    }

    // 周回パス進入点準備
    orbitalHalfway = params.halfway;
    FPS.setTurnCircle(params.transitRotation, gauge.turnRadius);
    PathSegment iSeg = edgeList.front(); // 最初の辺を保存
    auto tc = FPS.Circ;
    if ((!iSeg.pathAttr.isWorking() && tc.checkIntersection(iSeg.leavePoint()) != Intersection::NO) ||
        !gauge.headland.permitBackward) {
        // バックできない、またはラスター作業パス脱出ターンサークルに近いとき、ターン生成に失敗するのは明らかなので最初の辺を無視する。
        // 現在のところ先頭のみ考慮する
        // 救えるケースよりエラーになるケースの方が多かったため一旦コメントアウト
//        edgeList.erase(edgeList.cbegin());
    }
     
    // - 周回パス生成
    TurnPath tmpPath;
    try {
        tmpPath = createOrbitalPath(edgeList, params);
        pathBuffer.pushTurnPath(tmpPath);
    } catch (ErrorPathGenerator& err) {
        LOGE(LOG_TAG "::createPostOrbitalPath", "createOrbitalPath returns invalid path: %s", Svg::to_path(tmpPath).c_str());
        if (err.compareErrorCode(ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE)) {
            // 周回パスでコーナー間距離の問題はリカバリ不能
            throw;
        }
        tmpPath.invalidate();
    } catch(...) {
        tmpPath.invalidate();
    }
    
    if (!tmpPath.isValid()) {
        LOGD(LOG_TAG "::createPostOrbitalPath", "createOrbitalPath returns invalid path: %s", Svg::to_path(tmpPath).c_str());
        ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::Orbital::GENERAL);
        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] post-orbital path genration.", "::createPostOrbitalPath");
        throw err;
    }
    pathBuffer.open();
    // 開始セグメント
    // - 先頭に最小ナビゲーションがある
    pathBuffer.erase(pathBuffer.cbegin());
    // - 先頭非作業セグメントを一つの前進セグメントにする
    if (2 < pathBuffer.size()) {
        treatEntrance(pathBuffer, TOL_TEN_CM);
    }
    
    auto ePathSeg = pathBuffer.front();
    auto destSeg = pathBuffer.front();
    // ラスター脱出ターン
    LOGD(LOG_TAG "::createPostOrbitalPath", "\n<path fill=\"none\" stroke=\"black\" d=\"\n%s\n%s\n\"/>\n",
         Svg::to_path_d(srcSeg).c_str(), Svg::to_path_d(destSeg).c_str());
    // - 平行パス末と繋ぐ
    TurnPath transitPath;
    if (gauge.headland.permitBackward) {
        traverseInfo.fps.setMinimalLeg();
        srcSeg = traverseInfo.fps.getHeadLeg();
        PathSegment srcpSeg{srcSeg};
        LOGD(LOG_TAG "::createPostOrbitalPath", "\n<path fill=\"none\" stroke=\"black\" d=\"\n%s\n%s\n\"/>\n",
             Svg::to_path_d(srcpSeg).c_str(), Svg::to_path_d(destSeg).c_str());
        auto whiskerMode = WhiskerMode::CROSS;
        whiskerMode.mode.reset(WhiskerMode::Mode::Index::FORWARD);
        whiskerMode.mode.set(WhiskerMode::Mode::Index::BACKWARD, destSeg.pathAttr.isWorking());
        TransitTurnParams ttParams{whiskerMode};
        ttParams.avoidAwp = (params.trEdgeAlt == OrbitalPathParam::LOW);
        try {
            if (connectAny(srcSeg, destSeg)) {
                transitPath = pathAssembler.getValidatedLeaveRasterTurnPath(srcpSeg, destSeg, ttParams);
                LOGD(LOG_TAG "::createPostOrbitalPath", "AlphaTurnReviced:\n<path fill=\"none\" stroke=\"black\" d=\"\n%s\n\"/>\n",
                     Svg::to_path_d(transitPath).c_str());
                transitPath.validate();
            }
            // リトライ
            if (!transitPath.isValid()) {
                LOGD(LOG_TAG "::createPostOrbitalPath", "retry getValidatedLeaveRasterTurnPath()");
                // TODO: 要再検討
                pathBuffer.erase(pathBuffer.cbegin());
                destSeg = pathBuffer.front();
                if (connectAny(srcSeg, destSeg)) {
                    transitPath = pathAssembler.getValidatedLeaveRasterTurnPath(srcpSeg, destSeg, ttParams);
                }
            }
            LOGD(LOG_TAG "::createPostOrbitalPath", "transitPath (1st)\n%s", Svg::to_path(transitPath).c_str());
        } catch(...) {
            // エラー
            if (ttParams.avoidAwp) {
                throw;
            }
            LOGE(LOG_TAG "::createPostOrbitalPath", "[WARN] has no cross \n%s", Svg::to_path(transitPath).c_str());
        }
    } else {
        //　バックできないとき
        traverseInfo.fps.setMinimalLeg();
        srcSeg = traverseInfo.fps.getSegment();
        transitPath = pathAssembler.getPlainTurnPath(srcSeg, destSeg, WhiskerMode::NONE);
        if (!transitPath.isValid()) {
            if (connectForward(srcSeg, iSeg) && connectForward(iSeg, destSeg)) {
                transitPath = pathAssembler.getHookTurnPath(srcSeg, iSeg, destSeg);
            }
        }
    }
    if (transitPath.isValid()) {
        transitPath.open();
        // 先頭のパス脚を削減する
        if (2 < transitPath.size()) {
            treatEntrance(transitPath, TOL_TEN_CM);
        }

        try {
            // - 有効性検査
            transitPath.front().enterPoint() = traverseInfo.fps.leavePoint();
            if (!pathValidator.checkSPSLegLength(transitPath.front())) {
                transitPath.invalidate();
            } else {
                pathValidator.validatePointVectorInside(transitPath);
                pathValidator.validateIntersectionWithShp(transitPath);
            }
        } catch (...) {
            // - 失敗した場合、フィッシュテール/フックターンで再試行する
            transitPath.invalidate();
            LOGD(LOG_TAG "::createPostOrbitalPath", "[FAILED] raster - orbital transit path genration. (1st try)");
        }
    } else {
        // - 失敗した場合、フィッシュテール/フックターンで再試行する
        transitPath.invalidate();
        LOGD(LOG_TAG "::createPostOrbitalPath", "[FAILED] raster - orbital transit path genration. (1st try)");
    }
    // リトライ
    if (!transitPath.isValid()) {
        LOGD(LOG_TAG "::createPostOrbitalPath", "raster - orbital transit path genration. (2nd try)");
        if (!edgeList.front().pathAttr.isWorking()) {
            edgeList.erase(edgeList.cbegin());
        }
        pathBuffer.clear();
        auto tmpPath = createOrbitalPath(edgeList, params);
        try {
            pathBuffer.pushTurnPath(tmpPath);
            pathValidator.validatePointVectorInside(tmpPath);
            pathValidator.validateIntersectionWithShp(tmpPath);
        } catch (...) {
            LOGE(LOG_TAG "::createPostOrbitalPath", "createOrbitalPath returns invalid path: %s",
                 Svg::to_path(tmpPath).c_str());
            ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::Orbital::GENERAL);
            err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] post-orbital path genration.", "::createPostOrbitalPath");
            throw err;
        }
        pathBuffer.open();
        // 開始セグメント
        // - 先頭に最小ナビゲーションがある
        pathBuffer.erase(pathBuffer.cbegin());
        destSeg = pathBuffer.front();
        
        LOGD(LOG_TAG "::createPostOrbitalPath", "\n<path fill=\"none\" stroke=\"black\" d=\"\n%s\n%s\n\"/>\n",
             Svg::to_path_d(srcSeg).c_str(), Svg::to_path_d(destSeg).c_str());
        traverseInfo.fps.setMinimalLeg();
        srcSeg = traverseInfo.fps.getHeadLeg();
        PathSegment srcpSeg{srcSeg};
        LOGD(LOG_TAG "::createPostOrbitalPath", "\n<path fill=\"none\" stroke=\"black\" d=\"\n%s\n%s\n\"/>\n",
             Svg::to_path_d(srcpSeg).c_str(), Svg::to_path_d(destSeg).c_str());
        auto whiskerMode = WhiskerMode::CROSS;
        whiskerMode.mode.reset(WhiskerMode::Mode::Index::FORWARD);
        whiskerMode.mode.set(WhiskerMode::Mode::Index::BACKWARD, destSeg.pathAttr.isWorking());
        TransitTurnParams ttParams{whiskerMode};
        ttParams.avoidAwp = (params.trEdgeAlt == OrbitalPathParam::LOW);
        if (connectAny(srcSeg, destSeg)) {
            transitPath = pathAssembler.getValidatedLeaveRasterTurnPath(srcpSeg, destSeg, ttParams);
        }
        // 脱出ターン確認
        if (transitPath.isValid()) {
            // - 有効性検査
            try {
                pathValidator.validatePointVectorInside(transitPath);
                pathValidator.validateIntersectionWithShp(transitPath);
            } catch (...) {
                transitPath.invalidate();
                LOGE(LOG_TAG "::createPostOrbitalPath", "[FAILED] raster - orbital transit path genration. (final try)");
            }
        }
    }

    // 脱出ターン確認
    if (!transitPath.isValid()) {
        LOGE(LOG_TAG "::createPostOrbitalPath", "[FAILED] raster - orbital transit path genration. (final)\n%s", Svg::to_path(transitPath).c_str());
        ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::Orbital::RASTER_ORBITAL_TRANSIT);
        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] raster - orbital transit path genration. ", "::createPostOrbitalPath");
        throw err;
    }

    // 接続
    transitPath.open();
    transitPath.back().pathAttr.rideType = PathParam::Segment::RideType::NON_WORKING;
    transitPath.front().enterPoint() = traverseInfo.fps.leavePoint();
    // - 脱出ターン追加
    {
        // 境界が非作業セグメントであるはずなので結合する
        // - 接続
        if (pathBuffer.front().pathAttr.rideType == transitPath.back().pathAttr.rideType) {
            LOGD(LOG_TAG "::createPostOrbitalPath", "raster - orbital transit: MARGE");
            // 接続
            auto iSeg = pathBuffer.front();
            iSeg.pathAttr.rideType = PathParam::Segment::RideType::NON_WORKING;
            iSeg.turnType = PathParam::Turn::Type::NAVIGATION;
            int result = pathAssembler.connectTurnToTurnRO(transitPath, iSeg, pathBuffer, gauge.headland.permitBackward);
            if (result != SUCCESS) {
                result = pathAssembler.connectTurnToTurnRO(transitPath, pathBuffer, gauge.headland.permitBackward);
            }
            if (result != SUCCESS) {
                // 接続時点で失敗検出する
                LOGD(LOG_TAG "::createPostOrbitalPath", "[FAILED] failed connect leave rater turn to orbital path.\n%s", Svg::to_path(transitPath).c_str());
                ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::Orbital::RASTER_ORBITAL_TRANSIT);
                err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] failed connect leave raster turn to orbital path..", "::createPostOrbitalPath");
                throw err;
            }
        } else if (pathBuffer.front().pathAttr.rideType == PathParam::Segment::RideType::WORKING) {
            LOGD(LOG_TAG "::createPostOrbitalPath", "raster - orbital transit: CONNECT(to work)");
            // 周回作業パスと接続
            // - 直接作業パスに接続するのでウィスカーに注意する
            if (2 <= transitPath.size()) {
                auto& lastSeg = transitPath.back();
                auto& prevSeg = *std::next(transitPath.rbegin());
                if ((prevSeg.segmentType == SegmentType::ARCSEG && prevSeg.direction == SegmentDir::FORWARD) &&
                    (lastSeg.pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING && lastSeg.direction == SegmentDir::FORWARD)) {
                    // 前進のカーブ後はパス脚をつける
                    lastSeg = getFromHead(lastSeg, gauge.minSpsLegLength);
                }
                pathBuffer.enterPoint() = transitPath.leavePoint();
            } else {
                // セグメントが1本のみ
                auto& lastSeg = transitPath.back();
                if (lastSeg.segmentType == SegmentType::ARCSEG && lastSeg.direction == SegmentDir::FORWARD) {
                    LOGD(LOG_TAG "::createPostOrbitalPath", "[WARN] this turn end by arc");
                    // ターンが前進のカーブで終わっている(これ自体がイレギュラーだが)
                    auto leg = getFromHead(pathBuffer.front(), gauge.minSpsLegLength);
                    PathSegment pleg{leg};
                    transitPath.pushTurnPath(pleg);
                } else if (lastSeg.segmentType == SegmentType::LINESEG && lastSeg.direction == SegmentDir::FORWARD) {
                    // 前進の直線はパス脚とみなす
                    lastSeg.leavePoint() = pathBuffer.enterPoint();
                    // 長さを保証
                    if (lastSeg.length() < gauge.minSpsLegLength) {
                        lastSeg = getFromHead(lastSeg, gauge.minSpsLegLength);
                    }
                }
                pathBuffer.enterPoint() = transitPath.leavePoint();
            }
        } else {
            LOGD(LOG_TAG "::createPostOrbitalPath", "raster - orbital transit: CONNECT");
            pathBuffer.enterPoint() = transitPath.leavePoint();
        }
        transitPath.pushTurnPath(pathBuffer);
        pathBuffer = transitPath;
    }
    
    // 周回パスの終了点
    // - コーナーまでなので、BPを上限に終了ナビゲーション分補償する。
    // - BPクリアランスには終点余裕を加える必要がある。クリアランス不足の場合でも折り返さず、パスを短縮する。この際の短縮に耐えないほどパスが極端に短いことは想定しない。
    pathBuffer.open();
    LineSegment lastseg = pathBuffer.back();
    // - これは終点余裕を含まない通常の安全マージンでの最長セグメント
    lastseg = pathAssembler.seekExtendTailMax(lastseg, -gauge.headland.whisker.lengthStep, gauge.minFpsLegLength + gauge.termMin.end, BoundaryType::Kind::Mask::SBP);
    // 最小終了ナビゲーション生成
    TurnPath endNavPath;
    {
        // 終点余裕0.2m分短縮する
        lastseg.extendTail(-gauge.clearance.stopEndMargin);
        // 末尾から最小終了ナビゲーションパスを取り出す
        auto leg = getFromTail(lastseg, gauge.minFpsLegLength + gauge.termMin.end);
//        PathExtentLine pel{leg, gauge, BoundaryType::Kind::Mask::SBP};　// 交差確認用
        PathSegment leaveSeg{leg};
        leaveSeg.pathAttr.rideType = PathParam::Segment::RideType::ORBITAL_NON_WORKING;
        leaveSeg.turnType = PathParam::Turn::Type::ENDNAV_MIN;
        pathBuffer.pushTurnPath(leaveSeg);
        pathBuffer.terminate(leaveSeg.leavePoint());
    }

    // 周回パス追加
    traverseInfo.mode = TraverseInfo::Mode::ORBITAL;
    outputPathData.pop_back();  // パス脚がついているので削除
    addOutputPath(pathBuffer, PathAttr{PathAttr::RideType::WORKING});
    // 検証
    try {
        validateCreateTurnPathOutput(pathBuffer);
    } catch (...) {
        transitPath.invalidate();
        LOGE(LOG_TAG "::createPostOrbitalPath", "[FAILED]  raster - orbital transit path genration. (validatioin)");
        throw;
    }
    pathBuffer.clear();
    
    return SUCCESS;
}

/**
 ラスター進入辺のノードインデックス取得
 */
int PathGenerator::getRasterEnterCornerIndex(const BoundaryPolygon& bdpolygon) const {
    LOGV(LOG_TAG "::getRasterEnterCornerIndex", "()");
    
    int nodeIndex = 0;
    auto it = find_if(inputPathNodeList.rbegin(), inputPathNodeList.rend(), [](const tData& td) { return (td.nodeType == tData::NodeType::PATHNODE_2); });
    auto startPoint = it->point();
    double nearest = numeric_limits<double>::max();
    for (auto it1 = bdpolygon.cbegin(); it1 != bdpolygon.cend(); ++it1) {
        auto it2 = nextCyclic(bdpolygon, it1);
        FieldLineSegment fls(*it1, *it2);
        auto segHp = fls.getSegmentHP();
        LOGD(LOG_TAG "::getRasterEnterCornerIndex", "\n<path fill=\"none\" stroke=\"black\" d=\"\nM\t%15g,%15g\nL\t%15g,%15g\n",
             segHp.point1().x, segHp.point1().y, segHp.point2().x, segHp.point2().y);
        if (segHp.isAside(startPoint, nearest)) {
            nearest = segHp.distance(startPoint);
            nodeIndex = it1->nodeIndex;
        }
    }
    
    return nodeIndex;
}

/**
 ラスター脱出辺のノードインデックス取得
 */
int PathGenerator::getRasterLeaveCornerIndex(const BoundaryPolygon& bdpolygon) const {
    LOGV(LOG_TAG "::getRasterLeaveCornerIndex", "()");
    
    int nodeIndex = 0;
    auto it = find_if(inputPathNodeList.crbegin(), inputPathNodeList.crend(), [](const tData& td) { return (td.nodeType == tData::NodeType::PATHNODE_2); });
    auto startPoint = it->point();
    double nearest = numeric_limits<double>::max();
    for (auto it1 = bdpolygon.cbegin(); it1 != bdpolygon.cend(); ++it1) {
        auto it2 = nextCyclic(bdpolygon, it1);
        FieldLineSegment fls(*it1, *it2);
        auto segHp = fls.getSegmentHP();
        LOGD(LOG_TAG "::getRasterLeaveCornerIndex", "\n<path fill=\"none\" stroke=\"black\" d=\"\nM\t%15g,%15g\nL\t%15g,%15g\n",
             segHp.point1().x, segHp.point1().y, segHp.point2().x, segHp.point2().y);
        if (segHp.isAside(startPoint, nearest)) {
            nearest = segHp.distance(startPoint);
            nodeIndex = it1->nodeIndex;
        }
    }
    
    return nodeIndex;
}

/** @ingroup PathGenerator
 半渦巻き仕上げ

 作業パス間のターンパス部分を全て作業パスに転換し単一の作業パスとする
 @internal
 */
int PathGenerator::modifyTurnSegmentPropery() {
    // - 作業パス先頭と末尾
    auto beginIt = find_if(outputPathData.begin(), outputPathData.end(), [](OutPathSegment& seg) { return (seg.pathAttr.rideType == OutPathSegment::RideType::WORKING); });
    auto rendIt = find_if(outputPathData.rbegin(), outputPathData.rend(), [](OutPathSegment& seg) { return (seg.pathAttr.rideType == OutPathSegment::RideType::WORKING || seg.pathAttr.rideType == OutPathSegment::RideType::DUMMY); });
    if (beginIt != outputPathData.end() && rendIt != outputPathData.rend()) {
        const auto endIt = prev(rendIt.base()); // rendItは末尾側範囲に含める
        // 開始ナビゲーション部
        // - 処理なし
        
        // 作業パス部
        // - DRはDRのままにする。ただしごく短いDRパスを挟んでも無駄なのでFPに転換してしまう。
        //   作業パス脚は手付かずなので実質の直進作業パスは0mにならない。
        for (auto it = beginIt; it != endIt; ++it) {
            auto& t = *it;
            
            // バック及びバック準備直進は非作業セグメント
            if (t.direction == LineSegment::REVERSE) {
                t.pathAttr = PathAttr{PathAttr::RideType::NON_WORKING};
                // 準備直進
                auto prevIt1 = prev(it);
                if (prevIt1 != outputPathData.cbegin()) {
                    auto& pt1 = *prevIt1;
                    auto prevIt2 = prev(prevIt1);
                    auto& pt2 = *prevIt2;
                    if (pt2.segmentType == SegmentType::ARCSEG) {
                        pt1.pathAttr.rideType = PathAttr::RideType::NON_WORKING;
                    }
                }
                continue;
            }
            
            // DRは規定より長い場合のみ非作業セグメント
            if (t.pathAttr.rideType == PathAttr::RideType::DUMMY && gauge.workPath.length.preserveDummyRide < t.length()) {
                // t.rideType = tData::DR;
                continue;
            }
            
            // その他は作業パスセグメント
            if (t.pathAttr.rideType == PathAttr::RideType::NON_WORKING) {
                t.pathAttr.rideType = PathAttr::RideType::WORKING;
            }
        }
        
        // 終了ナビゲーション部
        // - 終了ナビゲーションパスがDR直後のときは終了ナビゲーションに含める。
        for_each(endIt, outputPathData.end(),
                 [](OutPathSegment& seg) {
                     if (seg.pathAttr.rideType != PathAttr::RideType::WORKING) { // FPは変更しないこと(末尾作業パスは必ずしもDRではない)
                         seg.pathAttr.rideType = PathAttr::RideType::NON_WORKING;
                     }
                 });
    }
    
    return SUCCESS;
}


/** @ingroup PathGenerator
 接線パス生成
 
 ターンパス生成の主関数。
 設定済みのパラメータに従いNaviPathのノード間を繋ぐターンパスを生成する。
 
 @internal
 -# NavPathから作業パスのノードを選択
 -# FPS、SPSを生成
 -# FPS-SPS間のターンパスをpathBufferに生成
 -# pathBufferをnewNavPathに変換出力
 -# NavPathのノード残数が足りなければ終端をnewNavPathに追加
 */
void PathGenerator::generatePathData() {
	LOGV(LOG_TAG "::generatePathData", "()");

	// パスノード前処理
	removeRedundantNode();
    // パスノードをHPを覆うように拡張する
    makeStrictRasterPathNode();

    // 外周周回パス生成
    if (gauge.headland.process == Param::Work::Headland::Process::PRE) {
        if (gauge.headland.pattern == Param::Work::Headland::Pattern::CYCLONE || gauge.headland.pattern == Param::Work::Headland::Pattern::ANTICYCLONE) {
            createPreOrbitalPath();
        }
    }
    
    // ラスターパス生成
    {
        createRasterPath();
        // 作業パス化
        if (gauge.headland.process == Param::Work::Headland::Process::NOP) {
            promoteToWorkPath();
        }
        // 属性修正
        if (gauge.workPath.types == Gauge::WorkPath::Type::COMBINED_SIMPLEX) {
            modifyTurnSegmentPropery();
        }
    }

    // 外向き周回パス(枕地仕上げ)
    if (gauge.headland.process == Param::Work::Headland::Process::POST) {
        if (gauge.headland.pattern == Param::Work::Headland::Pattern::CYCLONE || gauge.headland.pattern == Param::Work::Headland::Pattern::ANTICYCLONE) {
            createPostOrbitalPath();
        }
    }

    // 短すぎる作業パスを削除
    ensureWorkPathLength();

    // 作業パス有効性検査
    pathValidator.validateWorkPath(outputPathData);
    
    // 生成パス全体のチェック
    pathValidator.validateOutputPathData(outputPathData);

    dumpTrnPath(LOG_DIR "TrnPathGenerator.txt");
}

/**
  無効なセグメントの削除
 
  長さ0のセグメントを削除する。
 */
void PathGenerator::removeVoidSegemnt(TurnPath& turnPath) {
    TurnPath tmpPath{turnPath.turnType};
    turnPath.open();
    for (const auto& seg : turnPath) {
       if (seg.enterPoint() != seg.leavePoint()) {
           tmpPath.push_back(seg);
        } else {
            LOGD(LOG_TAG "::removeVoidSegemnt", "remove:\n%s", Svg::to_path(seg).c_str());
        }
    }
    
    turnPath = tmpPath;
    if (!turnPath.empty()) {
        turnPath.terminate(turnPath.leavePoint());
    }
}

/**
 作業パス化
 
 非作業パスのうち作業パスに置き換え可能なものを作業パスで置換する。
 */
void PathGenerator::promoteToWorkPath() {
    // 属性の初期化
    for (auto& seg : outputPathData) {
        seg.ppInfo.promoRideType = PathParam::Segment::RideType::UNDEFINED;
        // 作業パスは交差判定対象から外す
        // TODO: 通常ターンの判定
        // 現状のseg.turnTypeではナビゲーションパスとして生成した通常ターンの判別ができないので、踏み荒らし判定対象となる。今後の検討課題。
        seg.ppInfo.intersectTarget = !(SegTest::isRasterSeg(seg) || !SegTest::isNavigation(seg));
    }

    // 作業パス化予約
    // - 隣の共線パスも作業パス化する可能性があるため、交差判定の除外処理が必要である。
    for (IteratorTrain<OutPathData> trit(outputPathData); !trit.isEnd(); ++trit) {
        auto& seg0 = *trit.prevIt();
        auto& seg1 = *trit.currIt();
        auto& seg2 = *trit.nextIt();
        if (SegTest::test(seg0, SegmentType::LINESEG, PathParam::Segment::RideType::DUMMY)) {
            // ダミーライド発見
            // 以降のセグメントは非対象とする(後から作業されてしまう可能性がある)
            break;
        }
        if (SegTest::test(seg0, SegmentType::LINESEG, PathParam::Segment::RideType::WORKING)     &&
            SegTest::test(seg1, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING) &&
            SegTest::test(seg2, SegmentType::LINESEG, PathParam::Segment::RideType::WORKING)) {
            // 作業パスの間を渡る単一の直線セグメント(共線ナビゲーションパス)をマーク
            seg1.ppInfo.promoRideType = PathParam::Segment::RideType::WORKING;
            // - 交差判定対象から外す
            seg1.ppInfo.intersectTarget = false;
        }
    }
    
    // 交差判定対象設定
    for (IteratorTrain<OutPathData> trit(outputPathData); !trit.isEnd(); ++trit) {
        auto& seg0 = *trit.prevIt();
        auto& seg1 = *trit.currIt();
        auto& seg2 = *trit.nextIt();
        if (SegTest::test(seg0, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING) &&
            SegTest::isRasterSeg(seg1) &&
            SegTest::test(seg2, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING)) {
            // 作業パス脚(FPS)は隣と100%当たるので除外
            seg0.ppInfo.intersectTarget = false;
            // 作業パス脚(SPS)は隣と100%当たるので除外
            seg2.ppInfo.intersectTarget = false;
        }
        if (SegTest::test(seg0, SegmentType::ARCSEG,  PathParam::Segment::RideType::NON_WORKING) &&
            SegTest::test(seg1, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING) &&
            SegTest::isRasterSeg(seg2)) {
            // 作業パス脚・脱出カーブは隣と100%当たるので除外
            seg0.ppInfo.intersectTarget = false;
            seg1.ppInfo.intersectTarget = false;
        }
        if (SegTest::isRasterSeg(seg0) &&
            SegTest::test(seg1, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING) &&
            SegTest::test(seg2, SegmentType::ARCSEG,  PathParam::Segment::RideType::NON_WORKING) ) {
            // 作業パス脚・侵入カーブは隣と100%当たるので除外
            seg1.ppInfo.intersectTarget = false;
            seg2.ppInfo.intersectTarget = false;
        }
        if (SegTest::test(seg0, SegmentType::ARCSEG,  PathParam::Segment::RideType::NON_WORKING, LineSegment::FORWARD) &&
            SegTest::test(seg1, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, LineSegment::FORWARD) &&
            SegTest::test(seg2, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, LineSegment::REVERSE)) {
            // フッィシュテール部分は除外
            seg0.ppInfo.intersectTarget = false;
            seg1.ppInfo.intersectTarget = false;
            seg2.ppInfo.intersectTarget = false;
        }
        if (SegTest::test(seg0, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, LineSegment::FORWARD) &&
            SegTest::test(seg1, SegmentType::LINESEG, PathParam::Segment::RideType::NON_WORKING, LineSegment::REVERSE) &&
            SegTest::test(seg2, SegmentType::ARCSEG,  PathParam::Segment::RideType::NON_WORKING, LineSegment::FORWARD)) {
            // フッィシュテール部分は除外
            seg0.ppInfo.intersectTarget = false;
            seg1.ppInfo.intersectTarget = false;
            seg2.ppInfo.intersectTarget = false;
        }
        if (seg2.turnType == PathParam::Turn::Type::ENDNAV_MIN) {
            // 最小終了ナビゲーション末尾は除外
            seg2.ppInfo.intersectTarget = false;
        }
    }

    // 作業パス化実行
    IteratorTrain<OutPathData> trit(outputPathData);
    while (!trit.isEnd()) {
        auto& seg0 = *trit.prevIt();
        auto& seg1 = *trit.currIt();
        auto& seg2 = *trit.nextIt();
        // 作業パス化可否判定
        if (seg1.ppInfo.promoRideType == PathParam::Segment::RideType::WORKING) {
            auto beginIt = std::next(trit.nextIt());
            if (!gauge.permitBackward) {
                LOGD(LOG_TAG "::promoteToWorkPath", "canBackward:false then collision without segment order.");
                // 順序によらず全てのセグメントと交差検査
                beginIt = outputPathData.begin();
            } else {
                LOGD(LOG_TAG "::promoteToWorkPath", "canBackward:true then collision with segment order.");
            }
            if (pathValidator.checkIntersection(seg1, beginIt, outputPathData.end()) == Intersection::NO) {
                // 3本を1本に接続し、残りの不要なセグメントを削除
                LOGD(LOG_TAG "::promoteToWorkPath", "[Promote to WORKING seg]:\n %s\n %s\n %s",
                     to_string(seg0).c_str(), to_string(seg1).c_str(), to_string(seg2).c_str());
                // セグメントをマージ
                seg0.leavePoint() = seg2.leavePoint();
                seg0.ppInfo.promoRideType = PathParam::Segment::RideType::UNDEFINED;
                LOGD(LOG_TAG "::promoteToWorkPath", "to\nadd %s", to_string(seg0).c_str());
                // 後ろ二つ消滅
                outputPathData.erase(trit.currIt(), std::next(trit.nextIt()));  // 終端は開区間なので要next
                // イテレーター更新
                // - eraseにより無効になっているので要再生成
                // - 同条件で連続している可能性があるのでマージしたセグメントから三つとする
                trit = {outputPathData, trit.prevIt()};
                continue;
            } else {
                LOGD(LOG_TAG "::promoteToWorkPath", "[Promote to WORKING seg]:FAILED\nseg:%s", to_string(seg0).c_str());
            }
        }
        // 条件にマッチしないセグメント列の場合は進める
        trit.setIt(trit.currIt());
    }
}

/**
 隣接イテレーター対生成
 
 イテレーターを取り、次を指すイテレーターと std::pair を作って返す
 - ペアが有効な要素を指すことを検査する。どちらかがceであればsecondは常にceとする。
 
 @param[in] ci  対象イテレーター
 @param[in] ce  ciが指すコンテナのend()

 @return イテレーターのstd::pair。
 */
template<typename iterator_t>
static
std::pair<iterator_t, iterator_t> getPairIt(const iterator_t& ci, const iterator_t& ce) {
	std::pair<iterator_t, iterator_t> retval{ce, ce};
    
    if (ci != ce) {
        auto co = next(ci);
        if (co != ce) {
            retval.first = ci;
            retval.second = co;
        }
    }

	return retval;
}
	
/**
 ノード選択
 
 ノードリストのイテレータを受け取り、ターンパスを生成するノードを選択してリストで返す。
 - 作業パスの頂点データ(前後2個)+作業パス間のナビゲーションターン用の頂点データ(あれば)+作業パスの頂点データ(前後2個)をコピーする。
 - 受け取ったイテレータを更新し、次の処理位置を指す。
 
 @param[in, out] ci 処理開始位置を指すノードリストイテレータの参照
 @param[in] ce		処理終了位置を指すノードリストイテレータの参照
 @return 作業パスノードノードリスト
 */
OutNodeList PathGenerator::getWorkingPathPoints(OutNodeList::iterator& ci, const OutNodeList::iterator& ce) {
	LOGV(LOG_TAG "::getWorkingPathPoints", "()");
	OutNodeList localList;

	// 作業パス(FPS)が見つかるまで繰り返す
	// 外側のループの1回目において、全体の中で1本目の作業パスより前の頂点データは、ココで読み捨てられてしまってる
	for (; ci != ce; ci++) {
		auto its = getPairIt(ci, ce);
		auto p0 = its.first;
		auto p1 = its.second;
		if (p0->nodeType == tData::NodeType::PATHNODE_1 && p1->nodeType == tData::NodeType::PATHNODE_2) {
			LOGV(LOG_TAG "::getWorkingPathPoints", "found FPS");
			// 1本目の作業パスの頂点データをコピー
			localList.push_back(*p0);
			localList.push_back(*p1);
			ci = next(p1);	// ciは1本目の作業パスの次の頂点データ
			break;
		}
	}

	if (localList.empty()) {
		LOGV(LOG_TAG "::getWorkingPathPoints", "could not find FPS");
		// FPS発見できず
		return localList;
	}

	// 作業パス(SPS)が見つかるまで繰り返す
	// 外側のループの最後において、全体の中で最後の作業パスより後ろの頂点データは、ココで読み捨てられてしまってる
	for (; ci != ce; ci++) {
		auto its = getPairIt(ci, ce);
		auto p0 = its.first;
		auto p1 = its.second;
		if (p1 == ce) {
			// SPS発見できず
			LOGV(LOG_TAG "::getWorkingPathPoints", "just single work path without start and end navigation.");
			// 作業パスが1本のみしかない、かつ開始側も終了側もナビゲーションしない(短い空走りになる)場合
			// - 終端処理して終わり
			addSporadicPathData(localList, localList.begin());
			localList.clear();
            traverseInfo.mode = TraverseInfo::Mode::END_NAV;    // 終了ナビゲーション
			break;
		}
		if (p0->nodeType == tData::NodeType::PATHNODE_1 && p1->nodeType == tData::NodeType::PATHNODE_2) {
			LOGV(LOG_TAG "::getWorkingPathPoints", "found SPS");
			// SPS発見
			localList.push_back(*p0);
			localList.push_back(*p1);
			// 外側のループの次の処理において、ciはFPSの前側の頂点データから読み始めたい。
			// よって、ciはそのまま帰す。
			break;
		}

		// その他の頂点
		localList.push_back(*p0);
	}
	
	return localList;
}

/**
 孤立作業パス処理
 
 ノードリストとリスト中の処理開始位置のイテレータを受け取り、最期の作業パスとパス終端を生成して追加する。
	- ノードの残りが2つ以上のとき、作業パスを生成し、最小脱出パスにて終端する。
	- 3つ目以降のノードは無視する。
	- ノードが2つ未満の場合は何もしない。
 
 @note	ノードの残りが4つ以上なければFPSとSPSが揃わず、ターンパスが引けないための処理。
 
 @param[in]      nodeList   ノードリスト
 @param[in, out] it         inputPathNodeListイテレータの参照
 */
void PathGenerator::addSporadicPathData(const OutNodeList& nodeList, const OutNodeList::const_iterator& it) {
	const auto rest = std::distance(it, nodeList.end());
	if (2 <= rest) {
		// 作業パスと最小脱出セグメントを追加して終了
		const auto& enterNode = *it;
		const auto& leaveNode = *next(it);
        traverseInfo.setFps(enterNode, leaveNode, gauge.minFpsLegLength);
		traverseInfo.mode = TraverseInfo::Mode::END_NAV;	// addOutputPathでFPSが追加される
		traverseInfo.turnType = Turn::Type::ENDNAV_MIN;
        // どんつき処理されるので折り返し処置なしで仮生成
        // - バック不可のときはFOLD指定されないはずでそのまま採用になる
		pathBuffer = pathAssembler.getMinimalLeavePath(traverseInfo.fps, gauge.termMin.end, false);
        // 脚の改造
        if (gauge.workPath.leg.type == Gauge::WorkPath::Leg::Type::FOLD) {
            foldLeg(pathBuffer);
        }
        addOutputPath(pathBuffer, PathAttr{PathAttr::RideType::WORKING});
	}
}

/**
 HCP生成
 
 パスノードリストからターンポイントを抽出し、HCPを生成して返す
	- ターンポイントの設定のみで、ターンサークルとしての初期化はまだ行わない
 
 @param[in] localList ノードリスト
 */
PathGenerator::HLTCList PathGenerator::extractTurnPoints(const OutNodeList& localList) const {
	LOGV(LOG_TAG "::extractTurnPoints", "()");
	HLTCList hltc;
	hltc.reserve(localList.size());
	hltc.push_back(HeadlandTurnCircle{});
	
	// 最初の頂点と最後の頂点はFPS入口と、SPS出口なので除外
	if (localList.size() > 4) {
		for_each(next(localList.begin(), 2), prev(localList.end(), 2),
				 [this, &hltc](const OutNodeList::value_type& node) {
					 const auto& point = node.pointOrg();
					 const auto nodeIndex = node.index;
                     const Boundary& bnd = boundarySet.boundaryAt(nodeIndex);
                     if (&bnd != &Boundary::nullobj) {
                         hltc.emplace_back(Circle{point, gauge.turnRadius}, bnd);
                         if (!point.isFinite()) {
                             // 無限大かNaNが含まれている
                             ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::Node::COORDINATE_VALUE);
                             err.setDescription("[EXCEPTION:PATH_GENERATION] An turn point has non-finite value.", "::extractTurnPoints");
                             throw err;
                         }
                     }
				 }); // for_each
	}
	
	hltc.push_back(HeadlandTurnCircle{});
	
	hltc.shrink_to_fit();
	return hltc;
}

/** @ingroup PathGenerator
 ターンパス初期化
 
 設定されたデータを検査し、拡張安全境界を生成する。
 @see SafeBoundary(double safeWidth)

 @return 0
 */
int PathGenerator::initTrnPath() {
	LOGV(LOG_TAG "::initTrnPath", "()");

	/*
	 Identification of vertex type convex or concave and calculation of
	 angle between adjacent edges for field boundary
	 */
	setCornerProperties(boundarySet.field);

	// Field boundary Validity check
	checkFieldBoundary();

	/*
	 Identification of vertex type convex or concave and calculation of
	 angle between adjacent edges for obstacle boundary
	 */
    for (auto& oPolygon : boundarySet.obstacles) {
		setCornerProperties(oPolygon);
	}

	// Obstacle Boundary Validity check
	checkObstacleBoundary();
    
	return 0;
}

/**
 境界頂点コーナー属性設定

 境界ポリゴン頂点(Boundary)の属性を初期化する。
 - CnCvF: 頂点が凸か凹か
 - bisector: 二等分ベクトル(内向き)
 - r2length: bisectorのy軸成分

 @param[in] polygon 境界ポリゴン(Boundaryのリスト)
 @return 0
 */
void PathGenerator::setCornerProperties(vector<Boundary>& polygon) {
	LOGV(LOG_TAG "::setCornerProperties", "()");
    size_t size = polygon.size();
    
	// ポリゴンの頂点は時計回り
	// 連続する3個の頂点
	for (int i = 0; i < polygon.size(); ++i) {
		const int prev = decCyclic(0, size - 1, i);
		const int next = incCyclic(0, size - 1, i);
		const auto& p1 = polygon[prev].BP;
		Vector2D p2 = polygon[i].BP;
		const auto& p3 = polygon[next].BP;
		// ベクトルp1p2がx軸と為す角度[-M_PI,M_PI]
		double angle12 = p2.getAngleFrom(p1);
		// ベクトルp2p3がx軸と為す角度[-M_PI,M_PI]
		double angle23 = p2.getAngleTo(p3);
		// ベクトルp1p2の向きを基準としたベクトルp2p3の向き(右左折の角度、マイナスが右折=凸頂点)
		double turnAngle = PolygonUtil::normalizeRadian(angle23 - angle12);
		PGASSERT(turnAngle != 0.0 && abs(turnAngle) != M_PI, ErrorCode::PathGeneration::FATAL); // 同一直線上の場合、FieldPolygonがおかしい
		polygon[i].CvCnF = (turnAngle < 0 ? CONVEX : CONCAVE);
		LOGV(LOG_TAG "::setCornerProperties", "Bnd[%d](%g, %g): %g -> %g diff %g CvCnF(%d)", i, p2.x, p2.y, angle12, angle23, turnAngle, polygon[i].CvCnF);

		// p2を挟む2辺の2等分線の方向(領域内側方向)
		double bisectorAngle = PolygonUtil::normalizeRadian(angle23 - (M_PI + turnAngle) / 2.0);
		polygon[i].bisector = UnitVector2D::fromAngle(bisectorAngle);

		// p2を挟む2辺の為す角度(狭い方)
		double angle123 = M_PI - abs(turnAngle);
		// p2を挟む2辺から距離1離れるための長さ
		polygon[i].r2Length = 1.0 / sin(angle123 / 2.0);
	}
}

/**
 出力パスデータ追加
 
 生成済みのターンパスを出力パスデータ列に追加する。
	- 生成したターンパスはノード列なのでパスセグメントに変換しながら追加する

 @attention 各パスセグメントにおいて終点は次のセグメント始点である。
		ただし、生成中にセグメント追加するとき次のセグメントが確定していないため始点しか入れておらず、
		歴史的経緯によりこの時点で初めてセグメント終点に値を入れるため引数のturnPathを変更する。
		そして、パスセグメント間のセグメント接続テストはこの処理の後で行っている。
 
 @param[in, out] turnPath 追加するターンパスデータ
 @param[in]		 pathAttr パス属性 @see PathAttr
 */
void PathGenerator::addOutputPath(TurnPath& turnPath, const PathAttr& pathAttr) {
	LOGV(LOG_TAG "::addOutputPath", "()");

    if (turnPath.empty()) {
        LOGD(LOG_TAG "::addOutputPath()", "empty turnPath");
        return;
    }

    // 最初のパスセグメント
	// - 開始ナビゲーションはFPS不要
	if (traverseInfo.mode != TraverseInfo::Mode::START_NAV &&
        traverseInfo.mode != TraverseInfo::Mode::ORBITAL) {
		// 1本目の作業パスの頂点データ(前後2個)で作業パスを生成
        auto fps = traverseInfo.fps;
        if (gauge.workPath.leg.type == Gauge::WorkPath::Leg::Type::FOLD) {
            fps.enterPoint() = outputPathData.back().leavePoint();
            fps.leavePoint() = turnPath.getEnterPoint();
        }
        fps.pathAttr = pathAttr;
        if (!outputPathData.empty()) {
            // fpsを前のセグメントに接続
            LOGD(LOG_TAG "::addOutputPath()", "Previous leave leg to FPS.");
            // ターンのパス脚を縮めてでも接続するようにした
            // outputPathData.back().leavePoint() = fps.enterPoint();
            PathSegment destSeg{fps};
            if (pathAssembler.connectTurnToSegment(turnPath, destSeg) == ResultCode::FAILURE) {
                LOGD(LOG_TAG "::addOutputPath()", "[ERROR] Previous leave leg to FPS: <path d=\"\n%s\n%s\n\"/>",
                     Svg::to_path_d(turnPath.back()).c_str(), Svg::to_path_d(destSeg).c_str());
                // 接続失敗
                ErrorPathGenerator err(ErrorCode::PathGeneration::PATH_LEG_CONNECTION);
                err.setDescription("[EXCEPTION:EXCEPTION:PATH_GENERATION] unknown path type", "::addOutputPath");
                err.segments.push_back(turnPath.back());
                throw err;
            }
        } else {
            // 前のセグメントが無いのでfpsと接続処理しない
            LOGD(LOG_TAG "::addOutputPath()", "FPS just add.");
        }
        outputPathData.emplace_back(fps, pathAttr);
	}

	if (turnPath.empty()) {
		return;
	}
	
	// 出力パスデータの構築
	auto last = prev(turnPath.end());
	for (auto it = turnPath.begin(); it != last; ++it) {
		auto& currPath = *it;
		const auto nextPath = *next(it);
        if (traverseInfo.mode != TraverseInfo::Mode::ORBITAL) {
//            currPath.pathAttr.rideType = PathAttr::RideType::NON_WORKING;
//            currPath.turnType = traverseInfo.turnType;
        }
        if (currPath.segmentType == LINESEG || currPath.segmentType == ARCSEG) {
            outputPathData.emplace_back(currPath);
        } else {
			ErrorPathGenerator err(ErrorCode::PathGeneration::FATAL);
			err.setDescription("[EXCEPTION:EXCEPTION:PATH_GENERATION] unknown path type", "::addOutputPath");
			err.path.push_back(currPath);
			throw err;
		}
	}
}

/**
 圃場境界ポリゴン検査
 
 圃場境界ポリゴンが枕地ターンポイントを生成するために十分かどうかをテストする。

 @return 検査結果
 @retval VALID ポリゴンは有効
 @retval INVALID ポリゴンは無効
 */
int PathGenerator::checkFieldBoundary() {
	int VertxOk = VALID;
#ifdef DEBUG_LOG
	// Turning circles on field boundary
	vector<Circle> HCP1(NoBP);

	// Define Turning circles
    auto& field = boundarySet.field;
	for (size_t i = 0; i < field.size(); i++) {
		Boundary& boundary = field[i];
		Circle& circle = HCP1[i];
		if (boundary.CvCnF == CONVEX) {
			// convex vertex
			XY_Point center = boundary.BP + boundary.bisector * Vector2D(boundary.r2Length * (gauge.outerRadius + gauge.clearance.BP));
			circle = Circle(center, gauge.turnRadius);
		} else {
			// concave vertex
			double radius = max(gauge.turnRadius, (gauge.turnRadius - gauge.innerRadius + gauge.clearance.BP));
			circle = Circle(boundary.BP, radius);
		}
	}

	// Check if the turning circles generated are sutaible for turn path generation
	for (size_t i = 0; i < field.size(); i++) {
		Boundary& boundary = field[i];
		int VertexTypeCurrent = boundary.CvCnF; // Vertex concave or convex

		const size_t j = incCyclic(0, field.size() - 1, i);
		int VertexTypeNext = field[j].CvCnF;

		// when both vertex have turning circles
		if (((VertexTypeCurrent == CONVEX) && (VertexTypeNext == CONCAVE)) || ((VertexTypeCurrent == CONCAVE) && (VertexTypeNext == CONVEX))) {
			// one vertex is convex and one is concave
			double tempd = HCP1[i].distance(HCP1[j]);
			double r1 = max(gauge.turnRadius, gauge.actSHD);
			if (tempd <= gauge.turnRadius + r1) {
				// Vertex points are not proper for turn generation
				LOGD(LOG_TAG "::checkFieldBoundary", "[INFO:BOUNDARY_PTS_SELECTION] convex and concave virtices too close (under actWidth / 2)");
//				throw ErrorPathGenerator(ErrorCode::PathGeneration::INPUT);
			}
		} else if ((VertexTypeCurrent == CONCAVE) && (VertexTypeNext == CONCAVE)) {
			// Both the vertex are concave
			HCP1[i].center = boundary.BP;
			double tempd = HCP1[i].distance(HCP1[j]);
			double r1 = max(gauge.turnRadius, gauge.actSHD);
			if (tempd <= 2 * r1) {
				LOGD(LOG_TAG "::checkFieldBoundary", "[INFO:BOUNDARY_PTS_SELECTION] concave to concave virtices too close (under actWidth / 2)");
//				throw ErrorPathGenerator(ErrorCode::PathGeneration::INPUT);
			}
		} else {
			// 頂点間が近すぎる
			// both the vertex are convex
			HCP1[i].center = boundary.BP;
			double tempd = HCP1[i].distance(HCP1[j]);
			if (tempd <= TOL_TEN_CM) {
				// 10 cm
				LOGD(LOG_TAG "::checkFieldBoundary", "[INFO:BOUNDARY_PTS_SELECTION] too close virtices (under 10cm)");
//				throw ErrorPathGenerator(ErrorCode::PathGeneration::INPUT);
			}
		}

		//Min HP edge length = 10 cm
		double tmpdist = field[j].HP.distance(boundary.HP);
		if (tmpdist < TOL_TEN_CM) {
			// Headland boundary points are not proper for turn generation
			LOGD(LOG_TAG "::checkFieldBoundary", "[INFO:BOUNDARY_PTS_SELECTION] too close virtices (under 10cm)");
//			throw ErrorPathGenerator(ErrorCode::PathGeneration::INPUT);
		}
	}
#endif // DEBUG_LOG
	return VertxOk;
}

/**
 障害物ポリゴン検査

 障害物境界ポリゴンが枕地ターンポイントを生成するために十分かどうかをテストする。
 - 凸ポリゴンである
 - すべての頂点間隔が gauge.turnRadius と (MaxWdth / 2 + SafeMargin) のどちらよりもより大きい
 
 @return 検査結果
 @retval VALID ポリゴンは有効
 @retval INVALID ポリゴンは無効
 */
int PathGenerator::checkObstacleBoundary() {
	int VertxOk = VALID;
#if defined(DEBUG) && !defined(UNITTEST)
	// 凸ポリゴンチェック
	// - 実際は入力でチェックされている
	for (auto obst : Obst) {
		if (obst.CvCnF == CONCAVE) {
			//If any vertex is concave
			ErrorPathGenerator err(ErrorCode::PathGeneration::INPUT_OBSTACLE);
			err.setDescription("[EXCEPTION:BOUNDARY_PTS_SELECTION] Failed by obstacle boundary has concave.", "::checkObstacleBoundary");
			throw err;
		}
	}

	// 最小幅チェック
	if (VertxOk == VALID) {
		// Turning circle radius at convex vertex of obstacle
		double r1 = max(gauge.turnRadius, gauge.gauge.actSHD);
		for (int i = 0; i < NoOB; i++) {
			int end = OBsize * (i + 1);
			for (int curr = OBsize * i; curr < end; curr++) {
				const int next = PathPlan::incCyclic(0, end - 1, curr);

				const auto& currPos = Obst[curr].BP;
				const auto& nextPos = Obst[next].BP;
				double tmpd = currPos.distance(nextPos);
				if (tmpd - r1 < TOL_ONE_CM) {
					// Vetex are not ok
					LOGD(LOG_TAG "::checkObstacleBoundary", "[INFO:BOUNDARY_PTS_SELECTION] obstacle boundary has close points.");
					LOGD(LOG_TAG "::checkObstacleBoundary", " (%g, %g) - (%g, %g)", currPos.x, currPos.y, nextPos.x, nextPos.y);
					// デバッグ用情報のみ
//					ErrorPathGenerator err(ErrorCode::PathGeneration::INPUT);
//					err.setDescription("[INFO:BOUNDARY_PTS_SELECTION] obstacle boundary has close points.", "::checkObstacleBoundary");
//					throw;
				}
			}
		}
	}
	LOGD(LOG_TAG "::checkObstacleBoundary", "result:%d", VertxOk);
#endif // defined(DEBUG) && !defined(UNITTEST)
	return VertxOk;
}


#pragma mark - PathGenerator:: Standard Turn Path creation
/**
 ターンパス生成

 1ターンパス全体を生成しpathBufferに格納する。
    - FPS,SPSの初期化
    - 入力値をチェック
    - ターンパス生成
        - 通常ターン適用　@see createStandardTurnPath() <br>
          フックターンはバック可能な場合にフィッシュテールターンでリトライする。
        - ナビゲーションターン適用 @see applyNavigationTurnPath()
    - 生成結果の検査

 @return 0
 */
int PathGenerator::createTurnPath() {
	LOGD(LOG_TAG "::createTurnPath", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    auto& HCP = traverseInfo.HCP;
    bool needStartEndNav = false;
    // 入力パラメータのチェック(主にデバッグ用)
    validateCreateTurnPathInput(HCP);

    // FPS(1本目の作業パスの後前)
	// Update FPS
    if (traverseInfo.mode != TraverseInfo::Mode::START_NAV) {
        setHeadLegMinimal(FPS);
        FPS.Circ.radius = gauge.turnRadius;
    } else {
        FPS.Circ.radius = 0.0;
    }

	// SPS(2本目の作業パスの前後)
	// Update SPS
	if (traverseInfo.mode != TraverseInfo::Mode::END_NAV) {
        setHeadLegMinimal(SPS);
        SPS.Circ.radius = gauge.turnRadius;
    } else {
        SPS.Circ.radius = 0.0;
	}

	FPS.dump(LOG_DIR "FPS.txt");
	SPS.dump(LOG_DIR "SPS.txt");
	dumpHCP(LOG_DIR "HCP.txt", HCP);
	
	if ((FPS.dir == SPS.dir) && (HCP.size() == 2) &&
		(traverseInfo.mode != TraverseInfo::Mode::START_NAV) && (traverseInfo.mode != TraverseInfo::Mode::END_NAV)) {
      	LOGD(LOG_TAG "::createTurnPath", "[STANDARD TURN PATH]");
        createStandardTurnPathValidated();
        // 脚の改造
        if (gauge.workPath.leg.type == Gauge::WorkPath::Leg::Type::FOLD) {
            foldLeg(pathBuffer);
        }
        // 生成後検査
        validateCreateTurnPathOutput(pathBuffer);
	} else {
        LOGD(LOG_TAG "::createTurnPath", "[NAVIGATION TURN PATH]");
		// 作業パスの間にターンポイントがある場合
		try {
            // ナビゲーションパス生成
			createNaviTurnPath();
            // 脚の改造
            if (gauge.workPath.leg.type == Gauge::WorkPath::Leg::Type::FOLD) {
                foldLeg(pathBuffer);
                if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
                    ensureHeadForward(pathBuffer);
                } else if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
                    ensureTailForward(pathBuffer);
                }
            }
			// 生成後検査
			validateCreateTurnPathOutput(pathBuffer);
		} catch (...) {
			if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
				LOGI(LOG_TAG "::createTurnPath", "[INFO] use minimum start navigation path");
				// 開始ナビゲーションが生成できない
				pathBuffer = pathAssembler.getMinimalEnterPath(SPS, gauge.termMin.start);
                pathBuffer.completeSegment();
                needStartEndNav = true;
			} else if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
				LOGI(LOG_TAG "::createTurnPath", "[INFO] use minimum end navigation path");
				// 終了ナビゲーションが生成できない
				// - FPS後に最小ダミーラン追加して終了
                // - どんつき処理後なので正規のものを生成する必要がある。安全マージンはこの後は最早チェックされない。
                const bool fold = ((gauge.workPath.leg.type == Gauge::WorkPath::Leg::Type::FOLD) && gauge.implement.canBackward);
                pathBuffer = pathAssembler.getMinimalLeavePath(FPS, gauge.termMin.end, fold);
                pathBuffer.completeSegment();
                needStartEndNav = true;
			} else {
				// 再スロー
				throw;
			}
		}
        
        if (needStartEndNav) {
            needStartEndNav = false;
            validateCreateTurnPathOutput(pathBuffer);
        }
	}

	return 0;
}

/**
 createTurnPath()入力値検査

 createTurnPath() へのターンパス生成用入力値を検査する。
 以下のいずれかに該当する場合は入力値が無効である。
	- 枕地頂点HCPが2未満(FPS/SPSが無い)
 */
void PathGenerator::validateCreateTurnPathInput(const HLTCList& htc) {
	LOGV(LOG_TAG "::validateCreateTurnPathInput", "()");

	/* Fail safe check */
	if (htc.size() < 2) {
        ErrorPathGenerator err(ErrorCode::PathGeneration::TurnPoint::INVALID_LIST);
		err.setDescription("[EXCEPTION:TURNPATH_INPUTS_ISSUE] HCP.size() < 2.", "::validateCreateTurnPathInput");
		throw err;
	}
}

/**
 createTurnPath()出力検査
 
 createTurnPath() で生成したターンパスの一般検査を行い、ターンパスが無効な場合に例外を投げる
 ターン種別固有の検査はしない。
 */
void PathGenerator::validateCreateTurnPathOutput(const TurnPath& turnPath) {
    // 生成後検査0:パスが存在すること
    pathValidator.validateEmpty(turnPath);
    // 生成後検査1:バック禁止時にバック移動を含んでいないこと
    pathValidator.validateWithReverseSegment(turnPath);
    // 生成後検査2:パス頂点がBP外に無いこと
    pathValidator.validatePoints(turnPath);
    // 生成後検査3:パスがSHPに交差しないこと
    pathValidator.validateIntersectionWithShp(turnPath);
    // 生成後検査4:パスセグメントの接続ベクトル検査
    pathValidator.validatePointVector(turnPath);
    // 生成後検査5:カーブ前後の接線パス同士が交差しないこと
    pathValidator.validateTangents(turnPath);
    // 生成後検査6:セグメント種類の検査(デバッグ用)
    pathValidator.validateSegmentPropaties(turnPath);
}

/**
 脚の折り畳み

 turnPathの脚を折りたたむ。
 - gauge.tractor.tailOverhang 長さのバック移動セグメントに置き換える。
 @warning 平行作業パスのパス脚にのみ使用すること
 */
int PathGenerator::foldLeg(TurnPath& turnPath) {
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;

    // 延長長さ
    double extendLength = gauge.workPath.expandLength;

    if (turnPath.empty()) {
        return FAILURE;
    }
    if ((turnPath.front().segmentType != LINESEG) || (turnPath.back().segmentType != LINESEG)) {
        return FAILURE;
    }

    // TODO: ターン生成時に末尾に無駄なセグメントが無いことを保証するべき
    removeVoidSegemnt(pathBuffer);

    // 脚
    // 延長量計算は最小パス脚で行う(ターンパスのパス脚は延長されている可能性がある)
    // - ターンの進入パス脚
    auto frontLeg = turnPath.front();
    // - ターンの脱出パス脚
    auto rearLeg = static_cast<LineSegment>(turnPath.getLastSegment());
    if (turnPath.turnType == TurnType::ENDNAV_MIN) {
        // ここでは通常のパス脚長での延長量を計算する。 gauge.termMin.end、gauge.clearance.stopBPは加味しないこと。
        rearLeg = frontLeg;
        rearLeg.exchange();
        LOGV(LOG_TAG "::foldLeg()", "ENDNAV_MIN  : length: %g, %g\nfrontLeg: %s\nrearLeg : %s", frontLeg.length(), rearLeg.length(), Svg::to_path_d(frontLeg).c_str(), Svg::to_path_d(rearLeg).c_str());
    } else if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
        // 面倒だが念のため今のところは座標を代入で済ませる
        frontLeg.enterPoint() = rearLeg.enterPoint();
        frontLeg.leavePoint() = rearLeg.leavePoint();
        frontLeg.exchange();
        LOGV(LOG_TAG "::foldLeg()", "START_NAV   : length: %g, %g\nfrontLeg: %s\nrearLeg : %s", frontLeg.length(), rearLeg.length(), Svg::to_path_d(frontLeg).c_str(), Svg::to_path_d(rearLeg).c_str());
    } else if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
        // こちらはアップキャストなのでそのまま代入できる
        rearLeg = frontLeg;
        rearLeg.exchange();
        LOGV(LOG_TAG "::foldLeg()", "END_NAV     : length: %g, %g\nfrontLeg: %s\nrearLeg : %s", frontLeg.length(), rearLeg.length(), Svg::to_path_d(frontLeg).c_str(), Svg::to_path_d(rearLeg).c_str());
    } else {
        LOGV(LOG_TAG "::foldLeg()", "INTER_CORNER: length: %g, %g\nfrontLeg: %s\nrearLeg : %s",  frontLeg.length(), rearLeg.length(), Svg::to_path_d(frontLeg).c_str(), Svg::to_path_d(rearLeg).c_str());
    }
    // - 作業パスの脱出パス脚
    const auto minFpsLeg = getFromHead(frontLeg, gauge.minFpsLegLength);
    // - 作業パス進入パス脚
    const auto minSpsLeg = getFromTail(rearLeg, gauge.minSpsLegLength);
    LOGV(LOG_TAG "::foldLeg()", "ORG: length: %g, %g\ewLeg: %s\nlwLeg : %s",  minSpsLeg.length(), minFpsLeg.length(), Svg::to_path_d(minSpsLeg).c_str(), Svg::to_path_d(minFpsLeg).c_str());

    // 延長限界値チェック
    // - 延長可能長を求める
    // - 前後同じ長さとする
    const double limit = extendLength;
    const double step = -0.1;
    BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::SBP;
    const auto frontSegExt = pathAssembler.seekExtendTailMax(minFpsLeg, step, limit, targetFlag);
    const auto rearSegExt = pathAssembler.seekExtendHeadMax(minSpsLeg, step, limit, targetFlag);
    const double frontExtLen = frontSegExt.length() - minFpsLeg.length();
    const double rearExtLen = rearSegExt.length() + minSpsLeg.length();
    LOGD(LOG_TAG "foldLeg()", "extend length: %g, %g\nfrontSegExt: %s\nrearSegExt : %s", frontExtLen, rearExtLen, Svg::to_path_d(frontSegExt).c_str(), Svg::to_path_d(rearSegExt).c_str());
    extendLength = std::min(frontExtLen, rearExtLen);
    // 延長が有効な長さか?
    if (extendLength < gauge.workPath.leg.foldSleshold) {
        extendLength = 0.0;
    }

    TurnPath path{turnPath.turnType};
    turnPath.open();
    if (0.0 < extendLength) {
        // 前脚
        if (traverseInfo.mode != TraverseInfo::Mode::START_NAV &&
            FPS.pathAttr.rideType != PathAttr::RideType::DUMMY) {
            const double kneeHeight = gauge.minFpsLegLength + extendLength;
            if (turnPath.turnType == TurnType::ENDNAV_MIN) {
                // 最小終了ナビゲーションパス
                // - 前進して停止する場合、BPクリアランスに0.2m加えて1.2m手前でなければならない。
                auto leaveSeg = getFromHead(minFpsLeg, gauge.minFpsLegLength + gauge.termMin.end);
                leaveSeg.shiftTailward(extendLength + gauge.clearance.stopBP);
                // - 折り返すかどうかのフラグ。前方折り返しなので前進のみでチェック
                const bool fold = (checkBoundaryIntersection(leaveSeg, PathPlan::BoundaryType::Kind::FOR_WORKPATH_LEG) != Intersection::NO);
                LOGV(LOG_TAG "::foldLeg()", "ENDNAV_MIN:tail fold:%d\n%s", fold, Svg::to_path(leaveSeg).c_str());
                LOGV(LOG_TAG "::foldLeg()", "ENDNAV_MIN:\n%s", Svg::to_path(leaveSeg).c_str());
                // 最小終了ナビゲーションパス生成
                auto endnavLeg = minFpsLeg;
                endnavLeg.shiftTailward(extendLength);
                turnPath = pathAssembler.getMinimalLeavePath(endnavLeg, gauge.termMin.end, fold);
                // 膝折フラグ立てる
                // - 実形状はどんつきとは少し異なるが統一する
                turnPath.modTurnType(Turn::Type::Flag::LEGFOLD);
                LOGV(LOG_TAG "foldLeg()", "ENDNAV_MIN:\n%s", Svg::to_path(turnPath).c_str());
            } else {
                const double frontLegLen = turnPath.front().length();
                const double diff = frontLegLen - kneeHeight;
                if (diff < -TOL_ONE_CM) {
                    // 長さが足りないので曲げる
                    // - pathに別途パスを用意し、後でturnPathと合成する
                    const auto frontLegOrg = turnPath.front();  // カーブの始点として要保存
                    frontLeg = getFromHead(frontLegOrg, gauge.minFpsLegLength); // 脱出パス脚なので最小パス脚で作り直す
                    frontLeg.shiftTailward(extendLength);           // 延長量ずらす
                    // バックセグメント
                    LineSegment thigh = ReverseSegment(frontLeg);
                    thigh.enterPoint() = frontLeg.leavePoint();     // パス脚先端から
                    thigh.leavePoint() = frontLegOrg.leavePoint();  // 元のパス脚出口(カーブ入口)。frontLegは最小パス脚なので出口ではない。
                    if (!thigh.isNegrective() && (frontLeg.getDotProduct(thigh) < 0.0)) {
                        path.pushTurnPath(PathSegment{frontLeg});       // 延長後の作業パス先端から最小脱出パス脚
                        // ターンの前パス脚を更新
                        turnPath.updateTurnPath(0, PathSegment{thigh});
                        // TurnTypeを変換
                        turnPath.modTurnType(Turn::Type::Flag::LEGFOLD);
                    } else {
                        // failsafe
                        turnPath.front().extendHead(-extendLength);
                    }
                } else {
                    // 長さが十分なので延長量だけ縮める
                    turnPath.front().extendHead(-extendLength);
                }
            }
        }
        // 後脚
        if (traverseInfo.mode != TraverseInfo::Mode::END_NAV &&
            SPS.pathAttr.rideType != PathAttr::RideType::DUMMY) {
            const double kneeHeight = gauge.minSpsLegLength + extendLength;
            const double rearLegLen = rearLeg.length();
            const double diff = rearLegLen - kneeHeight;
            if (-TOL_ONE_CM < diff) {
                // 長さが十分なので延長量だけパス脚を縮める
                // - 前進パス脚長込みの長さが必要。
                turnPath.back().extendTail(-extendLength);
            } else {
                // 長さ不足
                if ((turnPath.turnType == TurnType::STARTNAV_MIN) ||
                    ((traverseInfo.mode == TraverseInfo::Mode::START_NAV) && (turnPath.size() == 1))) {
                    // 最小開始ナビゲーションパス
                    // - セグメントが一つだけの場合も最小開始ナビゲーションとみなす
                    turnPath.clear();
                    turnPath = pathAssembler.getMinimalEnterPath(SPS, gauge.termMin.start);
                    turnPath.open();
                    auto& enterSeg = turnPath.front();
                    enterSeg.shiftHeadward(extendLength);
                    if (checkBoundaryIntersection(enterSeg, PathPlan::BoundaryType::Kind::FOR_WORKPATH_LEG) != Intersection::NO) {
                        // - スペースが無い場合は開始ナビゲーション無し
                        enterSeg.enterPoint() = enterSeg.leavePoint();
                    }
                } else {
                    // 長さが足りないので曲げる
                    const double preBackLength = gauge.workPath.leg.front.preBackLength;
                    const double remain = rearLegLen - extendLength;
                    // remainより短い場合はバックにならない
                    const double postCurveLen = std::max(preBackLength, remain) + TOL_TEN_CM;
                    // バック前準備直進(カーブ後のため)
                    auto eSeg = getFromHead(rearLeg, postCurveLen);
                    // -　作業セグメント延長部分
                    auto lSeg = getFromTail(rearLeg, extendLength);
                    LineSegment bwSeg = ReverseSegment{eSeg.leavePoint(), lSeg.enterPoint()};
                    LOGV(LOG_TAG "foldLeg()", "REAR Len:%.15g, remain:%.15g\n%s\t%.15g\n%s\t%.15g",
                         rearLegLen, remain,
                         Svg::to_path_d(eSeg).c_str(), eSeg.length(), Svg::to_path_d(lSeg).c_str(), lSeg.length());
                    if (!bwSeg.isNegrective() && (eSeg.getDotProduct(bwSeg) < 0.0)) {
                        // - バック前にパス脚長前進が必要。
                        turnPath.pushTurnPath(PathSegment{eSeg});
                        turnPath.pushTurnPath(PathSegment{bwSeg});
                        // - バック後はパス脚不要
                        // turnPath.pushTurnPath(PathSegment{lSeg});
                        LOGV(LOG_TAG "foldLeg()", "REAR eSeg:%0.15g, bwSeg:%0.15g, lSeg:%0.15g",
                             eSeg.length(), bwSeg.length(), lSeg.length());
                        Svg::dumpToLog(LOG_TAG "::lefFold()", turnPath);
                        // TurnTypeを変換
                        turnPath.modTurnType(Turn::Type::Flag::LEGFOLD);
                    } else {
                        // failsafe
                        turnPath.back().extendTail(-extendLength);
                    }
                }
            }
        }
    }

    // ターンパス本体
    path.pushTurnPath(turnPath);
    path.setTurnType(turnPath.turnType);
    path.terminateAuto();
    turnPath = path;

    // TODO: 別の対処法を考える。
    // - FPSの出口とターンの開始点で接続チェックをしているので辻褄を合わせないと705エラー
    traverseInfo.fps.leavePoint() = turnPath.getEnterPoint();
    traverseInfo.sps.enterPoint() = turnPath.getLeavePoint();

    return SUCCESS;
}

/**
 通常ターン生成
 
 検査済通常ターンを返す。
 - ターン形状のフォールバックと、対HP横断検査を行った上でリトライを行う。
 @see createStandardTurnPath(), validateTurnPathWithRetry()
 */
void PathGenerator::createStandardTurnPathValidated() {
    LOGV(LOG_TAG "::createStandardTurnPathValidated", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    createStandardTurnPath();
    validateTurnPathWithRetry(); // retry if necessary

    if (gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
        gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE &&
        pathValidator.checkIntersection(pathBuffer, rasterSegList) != Intersection::NO) {
        // 平行作業パス短縮に起因する場合、元の端点までパス脚長で補填して試行する
        // - 現在はオフセット回り耕(草刈り)の場合のみ。単純にはオフセット耕機が区別できないため。
        LOGD(LOG_TAG "::createStandardTurnPathValidated", "Standard Turn Path Collision with HP:\n%s", Svg::to_path(pathBuffer).c_str());
        // パス脚長さ補填
        FPS.leg.minLength += FPS.leg.orgLength;
        SPS.leg.minLength += SPS.leg.orgLength;
        setHeadLegMinimal(FPS);
        setHeadLegMinimal(SPS);
        createStandardTurnPath();
        validateTurnPathWithRetry(); // retry if necessary
        // 元の位置からのターンなのでHP横断はしない
        // - 現状では元の位置でもラスター作業パスの端を踏む
    }
}

/**
 通常ターン生成
 
 パスセグメントFPS - SPS間を直接結ぶ(間にコーナーの無い)ターンを生成する。
 各ターンの生成条件は次の通り。
	- Flat turn: x幅がターン直径より広い
	- U turn: x幅がちょうどターン直径
	- x幅がターン直径より狭い
		- Fishtail: 作業パスに対する枕地辺の傾き小 (傾きが大きいとターンがHPに接触する)
		- Hook: 枕地の傾き大
	- バック移動が許可されていないときは Fishtail turn は全て Hook turn で代替する。
	- サイドマージン例外があり、サイドマージンでは補助ターンサークルを挿入する。この場合のターン種別はNAVIGATIONである。
	  @see createFishtailTurnPath

 @note	作業パス間隔判定にマージンは設けない。インド版にはあるが、マージン分未満の差でフックターンを生成すべきところをフラットターンで生成してエラーになる。
 		実際のAuto-ECUの許容値が判るなら考慮しても良い。
 @note	現在、境界種別は圃場外周に決め打ち(traverseInfo.boundaryType = BoundaryType::FIELD)。有効性検査でのポリゴン内外判定に必要。
 
 @return 0
 */
int PathGenerator::createStandardTurnPath() {
	LOGV(LOG_TAG "::createStandardTurnPath", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;

    int result = FAILURE;
    pathBuffer.clear();

	// 現在のところ圃場周囲に決め打ち
	traverseInfo.boundaryType = BoundaryType::FIELD;

    LOGV(LOG_TAG "::createStandardTurnPath", "[FPS angles] angle:%g (%g degree)", FPS.angleToEdge, Degree::convert(FPS.angleToEdge));
    const double pathWidth = abs(FPS.leavePoint().x - SPS.enterPoint().x);
    const double diameter = gauge.turnRadius * 2;
    
	if (gauge.permitBackward && FPS.isSideEdgePath() && traverseInfo.isStandardTurn()) {
		// バック許可でサイドマージンのとき
        if (isIsometric(diameter, pathWidth, TOL_U_TURN_WIDTH)) {
            // 幅がちょうど2R: U Turn
            // - Uターンのみマージンつき。境界値(2R)付近のマージンをUターンに集中して処理する。
            // - 滅多に発生しなさそうだが、実際には作業幅やオーバーラッブ幅のcm単位の入力値に依存しているので容易に発生する。
            LOGV(LOG_TAG "::createStandardTurnPath", "distance:%g, (diff:%0.7g)\n", pathWidth, abs(diameter - pathWidth));
            result = createUTurn();
        } else {
            // 固定角度だけでなく、幅チェックの上補助ターンが入る
            result = createFishtailTurnFixed();
        }
	} else {
		// x間隔
		if (isIsometric(diameter, pathWidth, TOL_U_TURN_WIDTH)) {
			// 幅がちょうど2R: U Turn
			// - Uターンのみマージンつき。境界値(2R)付近のマージンをUターンに集中して処理する。
			// - 滅多に発生しなさそうだが、実際には作業幅やオーバーラッブ幅のcm単位の入力値に依存しているので容易に発生する。
			LOGV(LOG_TAG "::createStandardTurnPath", "distance:%g, (diff:%0.7g)\n", pathWidth, abs(diameter - pathWidth));
			result = createUTurn();
		} else if (pathWidth < diameter) {
			// パスの間隔がターン直径より狭い: Hook または Fishtail
			if (!gauge.permitBackward) {
				// バック禁止: 常にHook turn
				result = createHookTurn();
				// バック禁止なのでfishtailへのフォールバックなし
			} else {
				// 作業パスに対する枕値の傾き検査
				double angleHpEdge = Vector2D(SPS.enterPoint(), FPS.leavePoint()).getAngle();
				if (angleHpEdge < 0) {
					angleHpEdge = M_PI - abs(angleHpEdge);
				}
				const double leaveAngle = abs(M_PI_2 - angleHpEdge);	// angle between path and headland line
				if (leaveAngle < M_PI_4) {
					// 傾きが大きい: Hook turn
					result = createHookTurn();
				} else {
					// 傾きが小さい: Fish tail
                    const bool makeAdaptivbe = (gauge.workPath.types != Gauge::WorkPath::Type::COMBINED_SIMPLEX);
					result = createFishtailTurn(makeAdaptivbe);
				}
			}
		} else {
			// 幅が十分(2Rより)広い: Flat turn
			result = createFlatTurn();
		}
	}
    
    // セグメントの完成
    pathBuffer.completeSegment(SPS.enterPoint());

    return result;
}

#pragma mark - PathGenerator:: miscellaneous functions for Turn Path create

/**
 最新接線取得
 
 ターンパス中の最後の一つ前のセグメントをLineSegmentで返す
 
 @return ターンパス中の最後のLineSegment
 */
PathSegment PathGenerator::getLastTangent() {
	PathSegment	seg;

	if (!pathSpanStack.empty()) {
		seg = pathSpanStack.back().getLastTangent();
        seg.validate();
	}

	return seg;
}

/**
 通常ターン検査及びリトライ
 
 生成した通常ターンパスを検査し、無効であれば通常ターン生成を再試行する。
	- フィッシュテールターン以外はフィッシュテールターン(適応的)で再試行する。
	- フッィシュテールターンは固定フィッシュテールターン(固定)で再試行する。
	- 従って、バック禁止である場合は何もしない。
 */
void PathGenerator::validateTurnPathWithRetry() {
	LOGV(LOG_TAG "::validateTurnPathWithRetry", "()");
	
	if (!gauge.permitBackward) {
		// フィッシュテールでリトライするのでバック可能な場合のみ
		// - 他のリトライ方法ができたら外す
		return;
	}

    const int stdTypes = traverseInfo.turnType.std();
	switch (stdTypes) {
	case Turn::Type::HOOK:	// Hook Turn
		if (pathValidator.checkTurnPath(pathBuffer, stdTypes) != VALID) {
			LOGD(LOG_TAG "::validateTurnPathWithRetry", "retry: Hook turn to Fishtail");
			pathBuffer.clear();
			createFishtailTurn(true);
			validateTurnPathWithRetry();
		}
		break;
	case Turn::Type::FISHTAIL:	// Fishtail Turn
		if (pathValidator.checkTurnPath(pathBuffer, stdTypes) != VALID) {
			LOGD(LOG_TAG "::validateTurnPathWithRetry", "fishtail: failed");
		}
		break;
	case Turn::Type::FLAT:		// Flat Turn
	case Turn::Type::U:			// U Turn
	default:
		// 代替方法は無い
		break;
	}
    
    if (pathBuffer.isValid() == VALID) {
        pathBuffer.terminate();
    }
}

#pragma mark - PathGenerator:: Navigation Path creation
/**
 ナビゲーションターンパス生成

 3を超えるターンを持つパスを生成を試行し、生成結果を返す。
 処理内容は以下の通り。
	- 使用するコーナーターンサークルの決定
	- 圃場周回方向の決定
	- ターンパス生成
		- FPS/SPS間を直線で結ぶパス生成
		- 対向するFPS/SPS間を結ぶパス生成
		- 通常ターンパス生成
		- ターンサークル間を順に結ぶパス生成

 @return 生成結果
 @retval SUCCESS 成功
 @retval FAILURE 失敗
 */
int PathGenerator::createNaviTurnPath() {
	LOGV(LOG_TAG "::createNaviTurnPath", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    auto& HCP = traverseInfo.HCP;

    int result = FAILURE;
    
    // HCP準備: HCPへのターンポイントの抽出は完了しているが、通常ターンでは必要無いので初期化はここまで遅延している。
    prepareHCP();
    if (!((traverseInfo.boundaryType == BoundaryType::FIELD) || (traverseInfo.boundaryType == BoundaryType::OBSTACLE))) {
        ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::NaviPath::FATAL);
        err.setDescription("[EXCEPTION:PATH_GENERATION] Error in traverseInfo.boundaryType", "::applyNavigationTurnPath");
        throw err;
    }

	// Find the dirction of movement on the headland
	setOrbitingDirection();
	// check for traverseInfo.rotation output
	if (!((traverseInfo.rotation == ANTICLOCKWISE) || (traverseInfo.rotation == CLOCKWISE))) {
		ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::NaviPath::FATAL);
		err.setDescription("[EXCEPTION:PATH_GENERATION] Error in traverseInfo.rotation", "::applyNavigationTurnPath");
		throw err;
	}

	/*
	 Determining movement direction of the tractor on turning circles
	 clockwise of anti clock wise
	 */
	for (int i = 1; i < (int)HCP.size() - 1; i++) {
		HCP[i].Circ.orient = traverseInfo.rotation * HCP[i].CvCnF;
	}

    if (gauge.implement.widthOffset != 0.0) {
        // オフセットによるターンサークル径調整
        adjustHCP();
    }

	// Finding the headland area part where turn path will be generated
	getTraverseSpan();
	if (!((traverseInfo.traverseDir == 1) || (traverseInfo.traverseDir == -1))) {
		ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::NaviPath::FATAL);
		err.setDescription("[EXCEPTION:PATH_GENERATION] Error in traverseInfo.traverseDir", "::applyNavigationTurnPath");
        err.circles = HCP;
		throw err;
	}
    
	// FPS initialize
    setHeadLegMinimal(FPS);
	// SPS initialize
    setHeadLegMinimal(SPS);

    // Update first point of TurnPath
    pathBuffer.clear();
    if (traverseInfo.mode != TraverseInfo::Mode::START_NAV) {
        pathBuffer.pushTurnPath(FPS.leavePoint());
    }

    ///////////Check for the case: collinear path condition ///////////////////////
	/*
	 Collinear path condition is checked and if possible turn path is generated
	 for collinear path
	 */
    if ((traverseInfo.mode != TraverseInfo::Mode::START_NAV) && (traverseInfo.mode != TraverseInfo::Mode::END_NAV)) {
        const int ChkPth = applyCollinearPath();
        if (ChkPth == SUCCESS) {
            traverseInfo.turnType = Turn::Type::NAVIGATION;
            pathBuffer.completeSegment();
            return SUCCESS;
        }
    }
    
    setupFPS(FPS);
    setupSPS(SPS);
    // パス脚に関する最適化
    initHcpSkipList(HCP, FPS, SPS);

    LOGD(LOG_TAG "::createNaviTurnPath", "%s", dumpHltcList(HCP).c_str());
	// 通常ターン試行
    //  - 開始/終了ナビゲーションは適用しない
	if ((FPS.dir == SPS.dir) &&
		(traverseInfo.mode != TraverseInfo::Mode::START_NAV) && (traverseInfo.mode != TraverseInfo::Mode::END_NAV)) {
        traverseInfo.HCP.initSkip();
        traverseInfo.HCP.initRange();
        PathSpan pathSpan{traverseInfo.HCP.range};
        pathSpan.HCP = traverseInfo.HCP;
        pathSpan.HCP.initSkip();
        while (applyPathLegs(pathSpan)) {
            result = applyStandardTurnPath();
            if (result == SUCCESS && pathValidator.checkIntersection(pathBuffer, rasterSegList) != Intersection::NO) {
                // WHP検査は必須
                result = FAILURE;
            }
            if (result == SUCCESS) {
                // ターン種別設定
                traverseInfo.turnType = Turn::Type::NAVIGATION;
                pathBuffer.setTurnType(Turn::Type::NAVIGATION);
                return SUCCESS;
            }
        }
	}

	// ナビゲーションターン試行
    // ナビゲーションターン最適化
    // - 最適化しつつパス自体が生成される
    try {
        result = createNavigationPath();
        // 生成後検査
        if (pathValidator.checkIntersection(pathBuffer, rasterSegList) != Intersection::NO) {
            result = FAILURE;
        }
        if (result == SUCCESS) {
            validateCreateTurnPathOutput(pathBuffer);
        }
    } catch(...) {
        result = FAILURE;
    }
    
    if (result != SUCCESS &&
        gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
        gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE) {
        FPS.leg.minLength += FPS.leg.orgLength;
        SPS.leg.minLength += SPS.leg.orgLength;
        result = createNavigationPath();
    }
   
    // - ターン種別設定
    traverseInfo.turnType = Turn::Type::NAVIGATION;
    pathBuffer.setTurnType(Turn::Type::NAVIGATION);

#if defined(DEBUG_LOG) || defined(STANDALONE_DEBUG)
    if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
        // 開始ナビゲーションの先端テスト
        auto firstTS = pathBuffer.front();
        ASSERTLOGD(firstTS.segmentType == SegmentType::LINESEG, LOG_TAG, "[START NAV] start navigation has started in curve.");
        ASSERTLOGD(gauge.termMin.start <= firstTS.length(), LOG_TAG, "[START NAV] first segment too short.");
        ASSERTLOGD(firstTS.direction == TangentDir::FORWARD, LOG_TAG, "[START NAV] last segment is reverse.");
    } else if (traverseInfo.mode == TraverseInfo::Mode::END_NAV && 2 < pathBuffer.size()) {
        // 終了ナビゲーションの末端テスト
        ASSERTLOGD(pathBuffer.getLastSegment().segmentType == SegmentType::LINESEG, LOG_TAG, "[END NAV] end navigation has terminated in curve.");
        ASSERTLOGD(gauge.termMin.end <= pathBuffer.getLastSegment().length(), LOG_TAG, "[END NAV] last segment too short.");
        ASSERTLOGD(pathBuffer.getLastSegment().direction == TangentDir::FORWARD, LOG_TAG, "[END NAV] last segment is reverse.");
    } else {
        // ナビゲーションパスの終端処理
        // なし
    }
#endif

    dumpTrnPath("TrnPath.txt");
    LOGD(LOG_TAG "::createNaviTurnPath", "%s", PathGeneratorData::dumpTurnPath(pathBuffer, "[Navigation Turn Path]").c_str());

	return result;
}

/**
 枕地周回方向決定

 ナビゲーションパスによりポリゴン周囲を時計回りに周るか、反時計回りに周るかを返す。
    - ナビゲーションターンポイント(HCP[])が4つ以上(すなわち境界ポリゴン頂点が二つある)ある場合、
      HCP[1]とHCP[2]を比較しポリゴンの頂点インデックスが1増えているかどうか判別する。
    	- 1増えている=時計回り(ポリゴンは時計回り)
    	- それ以外=反時計回り
    - HCPが3つで境界ポリゴン頂点インデックスが比較できない場合、
      唯一の境界ポリゴン頂点HCP[1]と次のインデックスの頂点を結ぶ辺の上に作業パスFPSの脱出点があるかどうかをテストする。
    	- 辺の上にある=反時計回り(遡る方向にターンポイントがあり、ポリゴンは時計回り)
    	- それ以外=時計回り

 @note TODO: このような判定は無くす。計算誤差により判定を誤る。

 @return 周回する向き
 @retval ANTICLOCKWISE :(1) 反時計回り
 @retval CLOCKWISE :(-1) 時計回り
 */
int PathGenerator::setOrbitingDirection() {
	LOGV(LOG_TAG "::setOrbitingDirection", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    auto& HCP = traverseInfo.HCP;

	if (HCP.size() == 2) {
		if (FPS.dir == WorkPath::ASCEND) {
			traverseInfo.rotation = (FPS.leavePoint().x < SPS.enterPoint().x) ? CLOCKWISE : ANTICLOCKWISE;
			traverseInfo.traverseDir = 1;
		} else {
			traverseInfo.rotation = (FPS.leavePoint().x < SPS.enterPoint().x) ? ANTICLOCKWISE : CLOCKWISE;
			traverseInfo.traverseDir = -1;
		}
	} else if (HCP[1].bndFlg == BoundaryType::FIELD) {
		// 圃場周囲
		// Point index
		if (HCP.size() > 3) {
            const auto& field = boundarySet.field;
            const int currIndex = HCP[1].nodeIndex;
            const int nextIndex = PathPlan::incCyclic(0, field.size() - 1, currIndex);
            const int expectNode = field[nextIndex].nodeIndex;
			// コーナーが二つ以上あるときインデックス比較
			int actNode = HCP[2].nodeIndex;
			traverseInfo.rotation = (expectNode == actNode) ? CLOCKWISE : ANTICLOCKWISE;
		} else {
            // ターン方向で見る
            const Vector2D v1 = FPS.getSegment().getLeaveVector();
            const Vector2D v2{FPS.leavePoint(), HCP[1].HP};
            double cp = v1.getCrossProduct(v2);
            if (v1.getCrossProduct(v2) == 0.0) {
                // fail-safe
                // - FPS - HCP[1] がFPSの延長線上にある場合SPS側で見る
                LOGW(LOG_TAG "::setOrbitingDirection", "[INFO] use HCP - SPS vector.");
                const Vector2D v1{HCP[1].HP, SPS.enterPoint()};
                const Vector2D v2 = SPS.getVector();
                cp = v1.getCrossProduct(v2);
            }
            traverseInfo.rotation = (cp <= 0.0) ? CLOCKWISE : ANTICLOCKWISE;
		}
	} else {
		// 障害物周囲
        const auto& obstacles = boundarySet.obstacles;
        const int nodeIndex = HCP[1].nodeIndex;
        const int oIndex = nodeIndex - (int)boundarySet.field.size();
        const int pIndex = oIndex / OBsize;
        const int currIndex = oIndex % OBsize;
        const int lastIndex = OBsize - 1;
        const int nextIndex = PathPlan::incCyclic(0, lastIndex, currIndex);
        const int expectNode = obstacles[pIndex][nextIndex].nodeIndex;
		if (HCP.size() > 3) {
			// コーナーが二つ以上あるときインデックス比較
			const int actNode = HCP[2].nodeIndex;
			traverseInfo.rotation = (expectNode == actNode)  ? CLOCKWISE : ANTICLOCKWISE;
		} else {
			// Point index
			// Obstacle headland edge
			LineSegment SG(boundarySet.obstacles[oIndex][currIndex].HP, boundarySet.obstacles[oIndex][nextIndex].HP);

			// Check point Pnt on SG
			XY_Point Pnt = FPS.org.point1();
			int n = SG.checkIntersection(Pnt);

			// Movement on headland is anti clockwise or clockwise
			traverseInfo.rotation = (n == Intersection::YES) ? ANTICLOCKWISE : CLOCKWISE;
		}
	}

	return traverseInfo.rotation;
}

/**
 ターンサークル準備

 生成済みHCPのターンサークル情報を設定する。
 - 先頭と末尾はパス出入口のターンサークルなので触らない
 */
void PathGenerator::prepareHCP() {
	LOGV(LOG_TAG "::prepareHCP", "()");
    auto& HCP = traverseInfo.HCP;
	
	if (HCP.size() <= 2) {
		// コーナーターンポイントが無いので何もしない
		// assert(false);
		traverseInfo.boundaryType = BoundaryType::FIELD;
		return;
	}

	traverseInfo.boundaryType = HCP[1].bndFlg;

    // Calculate HCP points except for first and last circle
    for_each(next(HCP.begin()), prev(HCP.end()), [this](HLTCList::value_type& hcp) {
        // check if the vertex lies on field boundary
        const int bndFlg = hcp.bndFlg;
        if (bndFlg == BoundaryType::FIELD) {
#if (LIMIT_TC_SHIFT)
            const int fldIndex = hcp.nodeIndex;
            const auto& field = boundarySet.field;
#endif // LIMIT_TC_SHIFT
            // Check with which field headland point HLP point is matching
            Boundary& boundary = hcp;
            /*
             If convex vertex:- then HCP point is place such that SHP
             boundary will be tangent to the circle near the vertex with
             turning radius = Rmin

             If concave vertex:- HCP point centre is placed at field
             boundary vertex with radius max(Rmin,d1/2+delta1)
             */
            if (boundary.CvCnF == CONVEX) {
                // convex vertex
#if CONVEX_TURNCIRCLE_ON_EHP
                // EHPである
                XY_Point center = boundary.EHP;
#elif CONVEX_TURNCIRCLE_INSIDE
                // HP頂点から内側を攻める
                XY_Point center = boundary.BP + boundary.bisector * XY_Point(boundary.r2Length * (outerRadius + SafeMargin));
#else // CONVEX_TURNCIRCLE_INSIDE
                // HP頂点
                XY_Point center = boundary.HP;
#endif // CONVEX_TURNCIRCLE_INSIDE
                hcp.Circ.center = center;
                hcp.Circ.radius = gauge.turnRadius;
                hcp.CvCnF = CONVEX;
            } else {
                // concave vertex
                if (gauge.curveConcave.maxShift > 0.0) {
#if (LIMIT_TC_SHIFT)
                    double shift = gauge.curveConcave.maxShift;
                    // 隣の頂点もCONCAVEの場合、位置が逆転してしまう可能性があるため
                    // 隣の頂点のシフト方向との交点を求め、求めた交点以上はシフトさせないようにする
                    const int prev = decCyclic(0, field.size() - 1, fldIndex);
                    auto& prevBoundary = field[prev];
                    const int next = incCyclic(0, field.size() - 1, fldIndex);
                    auto& nextBoundary = field[next];
                    PolygonUtil::Segment _s0 = PolygonUtil::Segment(prevBoundary.BP, prevBoundary.BP + prevBoundary.bisector);
                    PolygonUtil::Segment _s1 = PolygonUtil::Segment(boundary.BP, boundary.BP + boundary.bisector);
                    PolygonUtil::Segment _s2 = PolygonUtil::Segment(nextBoundary.BP, nextBoundary.BP + nextBoundary.bisector);
                    // 前側の頂点
                    if (prevBoundary.CvCnF == CONCAVE) {
                        Point2D p;
                        PolygonUtil::crossPoint(_s0, _s1, &p);
                        // 移動量を制限する
                        shift = min(shift, boundary.BP.distance(p));
                    }
                    // 後側の頂点
                    if (nextBoundary.CvCnF == CONCAVE) {
                        Point2D p;
                        PolygonUtil::crossPoint(_s1, _s2, &p);
                        // 移動量を制限する
                        shift = min(shift, boundary.BP.distance(p));
                    }
#endif  // LIMIT_TC_SHIFT
                    hcp.Circ.center = (boundary.BP - boundary.bisector * XY_Point(shift));
                } else {
                    hcp.Circ.center = (boundary.BP);
                }
				hcp.Circ.radius = gauge.curveConcave.turnRadius;
//                hcp.BndFlg = BoundaryType::FIELD;
                hcp.CvCnF = CONCAVE;
            }
        } else if (bndFlg == BoundaryType::OBSTACLE) {
            // check if the vertex lies on obstacle boundary
            Boundary& obst = hcp;
            if (hcp.Circ.center.inRange(obst.HP, TOL_ONE_CM)) {
                /*
                 Convex vertex of obstacle means it is concave with respect to
                 field so the HCP point centre are at obstacle boundary
                 vertex with radius max(Rmin,d1/2+delta1)
                 */
                if (obst.CvCnF == CONVEX) {
                    // convex vertex
                    const double r1 = max(gauge.turnRadius, (gauge.turnRadius - gauge.innerRadius + gauge.clearance.BP));
                    
                    // 内径と安全マージンを考慮しても、まだ内側に余裕がある場合、旋回軸を内側にシフトする
                    // - この値は厳密に安全マージン公称値とする。実際のSHPの幅(tolSHD) = ImprvdSHPVrtxArc半径の方が許容差控除済みである
                    double shift = 0.0;
                    double restMargin = gauge.innerRadius - gauge.clearance.BP;
                    if (restMargin > 0.0 && obst.bisector.y > 0.0) shift = +restMargin;
                    if (restMargin > 0.0 && obst.bisector.y < 0.0) shift = -restMargin;

                    hcp.Circ.center = obst.BP;
                    hcp.Circ.center.y += shift;
                    hcp.Circ.radius = r1;
//                    hcp.BndFlg = BoundaryType::OBSTACLE;
                    hcp.CvCnF = CONVEX;
                } else {
                    // concave vertex
                    XY_Point center = obst.HP + obst.bisector * XY_Point(obst.r2Length * (gauge.outerRadius + gauge.clearance.BP));
                    hcp.Circ.center = center;
                    hcp.Circ.radius = gauge.turnRadius;
//                    hcp.BndFlg = BoundaryType::OBSTACLE;
                    hcp.CvCnF = CONCAVE;
                }
            }
        } else {
            // 圃場・障害物どちらにもマッチする頂点が無い
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::TurnPoint::SUSPICIOUS_POINT);
            err.setDescription("[EXCEPTION:MAKE_HCP] HCP has no match vertex in any boundary.", "::makeHCP");
            err.circles.push_back(hcp);
            throw err;
        }
    }); // for_each
   
    dumpHCP(LOG_DIR "HCP.txt", HCP);
}

/**
 枕地ターンサークル調整

 生成済みHCPのターンサークル情報を調整する。
 */
void PathGenerator::adjustHCP() {
    LOGV(LOG_TAG "::adjustHCP", "()");
    auto& HCP = traverseInfo.HCP;
    
    if (HCP.size() <= 2) {
        // コーナーターンポイントが無いので何もしない
        // assert(false);
        traverseInfo.boundaryType = BoundaryType::FIELD;
        return;
    }

    traverseInfo.boundaryType = HCP[1].bndFlg;
    // Calculate HCP points except for first and last circle
    for_each(next(HCP.begin()), prev(HCP.end()), [this](HLTCList::value_type& hcp) {
        // check if the vertex lies on field boundary
        const int bndFlg = hcp.bndFlg;
        if (bndFlg == BoundaryType::FIELD) {
            double maxShift = 0.0;
            if (hcp.Circ.orient == CLOCKWISE) {
                hcp.Circ.radius = gauge.concaveBP.right.turnRadius;
                maxShift = gauge.concaveBP.right.maxShift;
            } else {
                hcp.Circ.radius = gauge.concaveBP.left.turnRadius;
                maxShift = gauge.concaveBP.left.maxShift;
            }

#if (LIMIT_TC_SHIFT)
            const int fldIndex = hcp.nodeIndex;
            const auto& field = boundarySet.field;
#endif // LIMIT_TC_SHIFT
            // Check with which field headland point HLP point is matching
            Boundary& boundary = hcp;
            /*
             If convex vertex:- then HCP point is place such that SHP
             boundary will be tangent to the circle near the vertex with
             turning radius = Rmin

             If concave vertex:- HCP point centre is placed at field
             boundary vertex with radius max(Rmin,d1/2+delta1)
             */
            if (boundary.CvCnF == CONVEX) {
                // convex vertex
#if CONVEX_TURNCIRCLE_ON_EHP
                // EHPである
                XY_Point center = boundary.EHP;
#elif CONVEX_TURNCIRCLE_INSIDE
                // HP頂点から内側を攻める
                XY_Point center = boundary.BP + boundary.bisector * XY_Point(boundary.r2Length * (outerRadius + SafeMargin));
#else // CONVEX_TURNCIRCLE_INSIDE
                // HP頂点
                XY_Point center = boundary.HP;
#endif // CONVEX_TURNCIRCLE_INSIDE
                hcp.Circ.center = center;
                hcp.Circ.radius = gauge.turnRadius;
                hcp.CvCnF = CONVEX;
            } else {
                // concave vertex
                if (0.0 < maxShift) {
#if (LIMIT_TC_SHIFT)
                    // 隣の頂点もCONCAVEの場合、位置が逆転してしまう可能性があるため
                    // 隣の頂点のシフト方向との交点を求め、求めた交点以上はシフトさせないようにする
                    const int prev = decCyclic(0, field.size() - 1, fldIndex);
                    auto& prevBoundary = field[prev];
                    const int next = incCyclic(0, field.size() - 1, fldIndex);
                    auto& nextBoundary = field[next];
                    PolygonUtil::Segment _s0 = PolygonUtil::Segment(prevBoundary.BP, prevBoundary.BP + prevBoundary.bisector);
                    PolygonUtil::Segment _s1 = PolygonUtil::Segment(boundary.BP, boundary.BP + boundary.bisector);
                    PolygonUtil::Segment _s2 = PolygonUtil::Segment(nextBoundary.BP, nextBoundary.BP + nextBoundary.bisector);
                    double shift = maxShift;
                    // 前側の頂点
                    if (prevBoundary.CvCnF == CONCAVE) {
                        Point2D p;
                        PolygonUtil::crossPoint(_s0, _s1, &p);
                        // 移動量を制限する
                        shift = min(maxShift, boundary.BP.distance(p));
                    }
                    // 後側の頂点
                    if (nextBoundary.CvCnF == CONCAVE) {
                        Point2D p;
                        PolygonUtil::crossPoint(_s1, _s2, &p);
                        // 移動量を制限する
                        shift = min(maxShift, boundary.BP.distance(p));
                    }
#endif  // LIMIT_TC_SHIFT
                    LOGD(LOG_TAG "::adjustHCP", "hcp(%g, %g) R:%g, shift:%g, maxShift:%g", hcp.Circ.center.x, hcp.Circ.center.y, hcp.Circ.radius, shift, maxShift);
                    hcp.Circ.center = (boundary.BP - boundary.bisector * XY_Point(shift));
                } else {
                    LOGD(LOG_TAG "::adjustHCP", "hcp(%g, %g) R:%g; no shift", hcp.Circ.center.x, hcp.Circ.center.y, hcp.Circ.radius);
                    hcp.Circ.center = (boundary.BP);
                }
                hcp.CvCnF = CONCAVE;
            }
        } else if (bndFlg == BoundaryType::OBSTACLE) {
            // check if the vertex lies on obstacle boundary
            Boundary& obst = hcp;
            if (hcp.Circ.center.inRange(obst.HP, TOL_ONE_CM)) {
                /*
                 Convex vertex of obstacle means it is concave with respect to
                 field so the HCP point centre are at obstacle boundary
                 vertex with radius max(Rmin,d1/2+delta1)
                 */
                if (obst.CvCnF == CONVEX) {
                    // convex vertex
                    const double r1 = max(gauge.turnRadius, (gauge.turnRadius - gauge.innerRadius + gauge.clearance.BP));
                    
                    // 内径と安全マージンを考慮しても、まだ内側に余裕がある場合、旋回軸を内側にシフトする
                    // - この値は厳密に安全マージン公称値とする。実際のSHPの幅(tolSHD) = ImprvdSHPVrtxArc半径の方が許容差控除済みである
                    double shift = 0.0;
                    double restMargin = gauge.innerRadius - gauge.clearance.BP;
                    if (restMargin > 0.0 && obst.bisector.y > 0.0) shift = +restMargin;
                    if (restMargin > 0.0 && obst.bisector.y < 0.0) shift = -restMargin;

                    hcp.Circ.center = obst.BP;
                    hcp.Circ.center.y += shift;
                    hcp.Circ.radius = r1;
//                    hcp.BndFlg = BoundaryType::OBSTACLE;
                    hcp.CvCnF = CONVEX;
                } else {
                    // concave vertex
                    XY_Point center = obst.HP + obst.bisector * XY_Point(obst.r2Length * (gauge.outerRadius + gauge.clearance.BP));
                    hcp.Circ.center = center;
                    hcp.Circ.radius = gauge.turnRadius;
//                    hcp.BndFlg = BoundaryType::OBSTACLE;
                    hcp.CvCnF = CONCAVE;
                }
            }
        } else {
            // 圃場・障害物どちらにもマッチする頂点が無い
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::TurnPoint::SUSPICIOUS_POINT);
            err.setDescription("[EXCEPTION:MAKE_HCP] HCP has no match vertex in any boundary.", "::makeHCP");
            err.circles.push_back(hcp);
            throw err;
        }
    }); // for_each
   
    dumpHCP(LOG_DIR "HCP.txt", HCP);
}

/**
 枕地移動部分選択

 圃場境界のうちナビゲーションパスが移動に使用する範囲をtraverseInfo.traverseSpanに取り出す。

 @return 0
 */
int PathGenerator::getTraverseSpan() {
	LOGV(LOG_TAG "::getTraverseSpan", "()");
    auto& HCP = traverseInfo.HCP;

	traverseInfo.traverseSpan.first = -1;
	traverseInfo.traverseSpan.second = -1;

	if (traverseInfo.boundaryType == BoundaryType::FIELD)	//field boundary points
	{
		if (HCP.size() == 3) {
			traverseInfo.traverseDir = 1;
			if (HCP[1].nodeIndex == 0)	// when point number is 0
			{
				traverseInfo.traverseSpan.first = NoBP - 1;
				traverseInfo.traverseSpan.second = 1;
			} else if (HCP[1].nodeIndex == NoBP - 1) {
				traverseInfo.traverseSpan.first = NoBP - 2;
				traverseInfo.traverseSpan.second = 0;
			} else	// when point number is not 0
			{
				traverseInfo.traverseSpan.first = HCP[1].nodeIndex - 1;
				traverseInfo.traverseSpan.second = HCP[1].nodeIndex + 1;
			}
		} else if (HCP.size() > 3)	// more than three points
		{
			if ((HCP[2].nodeIndex == 0) && (HCP[1].nodeIndex == NoBP - 1)) {
				traverseInfo.traverseDir = 1;
			} else if ((HCP[2].nodeIndex == NoBP - 1) && (HCP[1].nodeIndex == 0)) {
				traverseInfo.traverseDir = -1;
			} else {
				traverseInfo.traverseDir = offsetSign(HCP[1].nodeIndex, HCP[2].nodeIndex);
			}

			if (traverseInfo.traverseDir == 1) {
				if (HCP[1].nodeIndex == 0)	// when point number is 0
				{
					traverseInfo.traverseSpan.first = NoBP - 1;

				} else	// when point number is not 0
				{
					traverseInfo.traverseSpan.first = HCP[1].nodeIndex - 1;
				}
				if (HCP[HCP.size() - 2].nodeIndex == NoBP - 1) {
					traverseInfo.traverseSpan.second = 0;
				} else	// when point number is not 0
				{
					traverseInfo.traverseSpan.second = HCP[HCP.size() - 2].nodeIndex + 1;
				}

			} else	//qAdd=-1
			{
				if (HCP[1].nodeIndex == NoBP - 1)	// when point number is 0
				{
					traverseInfo.traverseSpan.first = 0;
				} else	// when point number is not 0
				{
					traverseInfo.traverseSpan.first = HCP[1].nodeIndex + 1;
				}

				if (HCP[HCP.size() - 2].nodeIndex == 0) {
					traverseInfo.traverseSpan.second = NoBP - 1;
				} else	// when point number is not 0
				{
					traverseInfo.traverseSpan.second = HCP[HCP.size() - 2].nodeIndex - 1;
				}
			}
		}
	} else	//obstacle boundary points
	{
		int p = ((HCP[1].nodeIndex - NoBP) / OBsize);
		traverseInfo.traverseSpan.first = OBsize * p;
		traverseInfo.traverseSpan.second = OBsize * p + OBsize;
		traverseInfo.traverseDir = 1;
	}

	dumpTraverseInfo("TraverseInfo.txt");
	return 0;
}

/**
 共線パス間ターンパス生成

 FPS/SPSが同一直線上にある場合に直線のターン(?)パス生成を試み、結果を返す。
	- FPS/SPS間を強制的に1セグメントの直線にする。パス脚は省略する。
	- FPS/SPSが重複する区間がある場合は例外を投げる。

 @return 結果
 @retval SUCCESS パス生成成功
 @retval FAILURE パス生成失敗
 */
int PathGenerator::applyCollinearPath() {
	LOGV(LOG_TAG "::applyCollinearPath", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    const bool collinear = isCollinear(FPS.getSegment(), SPS.getSegment());

    if (!collinear) {
        // 共線上にない
        return FAILURE;
    }

    const auto& leavePoint = FPS.leavePoint();
    const auto& enterPoint = SPS.enterPoint();
    LineSegment iTS{leavePoint, enterPoint};
    const double distance = iTS.length();

    if ((gauge.minFpsLegLength + gauge.minSpsLegLength) <= distance) {
        // 距離が長い場合
		LineSegment Ln{FPS.leavePoint(), SPS.enterPoint()};
		// HPコリジョンは無視する
		// - 延長した先のHP交差点はすなわち行き先SPSの入口と決まっている。
		// - 途中に作業パスを除外した短いHP切片があるかもしれないが当然無視可能。
		const int intersection = checkBoundaryIntersection(Ln, BoundaryType::Kind::FOR_COLLINEAR);
		if (intersection == Intersection::NO) {
			pathBuffer.terminate(SPS.enterPoint());
			return SUCCESS;
		}
    } else {
        ErrorPathGenerator err(FPS, SPS, ErrorCode::PathGeneration::Node::WORKING_PATH_OVERLAP);
        err.setDescription("[EXCEPTION:PATH_GENERATION] FPS and SPS were collinear and overlapped.", "::applyCollinearPath");
        throw err;
    }

    return FAILURE;
}

/**
 通常ターン適用
 
 コーナーターンサークルの有無を無視して作業パス間の接続を試み、実行したかどうかを返す(ターンパスの生成結果ではない)。
	 - 前後のバス方向が順方向で間にターンを挟まない
	 - パス同士が同一直線上に無いこと(これはターンを挟むはずだと思うが?)
	 - 生成に失敗した場合、ターンパス生成コンテキスト(FPS,SPS,HCP)を復元する。
 
 @return 生成結果
 @retval SUCCESS ターン生成実行
 @retval FAILURE ターン生成非実行
 */
int PathGenerator::applyStandardTurnPath() {
	LOGV(LOG_TAG "::applyStandardTurnPath", "()");
    int result = FAILURE;
    auto& HCP = traverseInfo.HCP;

	HLTCList tmpHCP = HCP;
	PathFPS FPS = traverseInfo.fps;
	PathSPS SPS = traverseInfo.sps;
    
    HCP.curr = 0;
    HCP.next = HCP.size() - 1;

	if ((FPS.dir != SPS.dir) && (HCP.size() == 2) && (traverseInfo.boundaryType == BoundaryType::FIELD)) {
		// 対向するパスのみ(?)
		createOppositeTurnPath();
	} else if (FPS.dir == SPS.dir) {
		createStandardTurnPathValidated();
	}

	result = (pathValidator.checkTurnPath(pathBuffer, traverseInfo.turnType.std()) == VALID) ? SUCCESS : FAILURE;
	if (result != SUCCESS) {
		HCP = tmpHCP;
		traverseInfo.fps = FPS;
		traverseInfo.sps = SPS;
	}

	return result;
}

/**
 ターンサークルスキップ準備(FPS)
 
 FPSターンサークル位置の調整によりスキップ可能なターンサークルインデックスとその時のパス脚のリストを生成する。
 リストアップされるものは以下の通り。
    - パス脚の延長で届くターンサークル(インデックスの大きい順)
    - HP脱出パス脚長
    - 最小パス脚長(HP脱出パス脚長と異なる場合のみ)
 */
void PathGenerator::prepareSkipTurnCircle(HLTCList& hcp, PathFPS fps, const PathSPS& sps) {
    auto& reachedList = hcp.fpsTarget.list;
    
    if (traverseInfo.boundaryType == BoundaryType::OBSTACLE) {
        // 障害物周囲は脚長固定
        reachedList.emplace_back(HLTCList::MIN_LEG, gauge.minFpsLegLength);
        return;
    }

    // 開始ナビゲーションの場合はFPSを延長できない
    if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
        reachedList.emplace_back(HLTCList::MIN_LEG, 0.0);
        return;
    }

    const int first = hcp.fpsIndex();
    int last = hcp.spsIndex();
    for (int index = last; first <= index; index--) {
        auto& htc = hcp[index];
		const int result = extendFpsLeg(fps, htc, sps);
        fps.ensureMinimalLegLength();
        if (result == SUCCESS) {
            htc.flags.set(HeadlandTurnCircle::REACHED_BY_FPS);
            const double length = fps.getHeadLeg().length();
            reachedList.emplace_back(index, length);
        }
	}

    setEscapeLeg(fps);
    const double escapeLen = fps.getHeadLeg().length();
    reachedList.emplace_back(HLTCList::MIN_ESCAPE_LEG_EXT, escapeLen + gauge.workPath.expandLength);
    reachedList.emplace_back(HLTCList::MIN_ESCAPE_LEG, escapeLen);
    reachedList.emplace_back(HLTCList::MIN_LEG_EXT, gauge.minFpsLegLength + gauge.workPath.expandLength);
    reachedList.emplace_back(HLTCList::MIN_LEG, gauge.minFpsLegLength);
    hcp.fpsTarget.normalize();
}

/**
 ターンサークルスキップ準備(SPS)
 
 SPSターンサークル位置の調整によりスキップ可能なターンサークルのリストを生成する。
 @see prepareSkipTurnCircle(HLTCList& hcp, PathFPS fps)
 */
void PathGenerator::prepareSkipTurnCircle(HLTCList& hcp, PathSPS sps, const PathFPS& fps) {
    auto& reachedList = hcp.spsTarget.list;

    if (traverseInfo.boundaryType == BoundaryType::OBSTACLE) {
        // 障害物周囲は脚長固定
       reachedList.emplace_back(HLTCList::MIN_LEG, gauge.minSpsLegLength);
        return;
    }

    // 終了ナビゲーションの場合はSPSを延長できない
    if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
        reachedList.emplace_back(HLTCList::MIN_LEG, 0.0);
        return;
    }
    
    for (int index = 0; index < hcp.size(); index++) {
        auto& htc = hcp[index];
		const int result = extendSpsLeg(sps, htc, fps);
        sps.ensureMinimalLegLength();
        if (result == SUCCESS) {
            htc.flags.set(HeadlandTurnCircle::REACHED_BY_SPS);
            const double length = sps.getHeadLeg().length();
            reachedList.emplace_back(index, length);
        }
	}

    setEscapeLeg(sps);
    const double escapeLen = sps.getHeadLeg().length();
    reachedList.emplace_back(HLTCList::MIN_ESCAPE_LEG_EXT, gauge.minSpsLegLength + gauge.workPath.expandLength);
    reachedList.emplace_back(HLTCList::MIN_ESCAPE_LEG, escapeLen);
    reachedList.emplace_back(HLTCList::MIN_LEG_EXT, gauge.minSpsLegLength + gauge.workPath.expandLength);
    reachedList.emplace_back(HLTCList::MIN_LEG, gauge.minSpsLegLength);
    hcp.spsTarget.normalize();
}

/**
 初期パス脚長設定
 */
void PathGenerator::setHeadLegMinimal(PathFPS& fps) const {
    fps.setMinimalLeg();
}

/**
初期パス脚長設定
*/
void PathGenerator::setHeadLegMinimal(PathSPS& sps) const {
    sps.setMinimalLeg();
}

/**
 最初のターンサークル(FPS)設定
 
 @param[in,out] fps 処理対象FPS
 */
void PathGenerator::setupFPS(PathFPS& fps) {
	fps.setLeaveTurnCircle(traverseInfo.rotation * traverseInfo.boundaryType, gauge.turnRadius);
    if (traverseInfo.mode == TraverseInfo::Mode::START_NAV) {
        // 開始ナビゲーションの始端は点
        fps.setHeadLeg(0.0);
        fps.Circ.center = fps.enterPoint();
        fps.Circ.radius = 0.0;
    }

    setEscapeLeg(fps);
    traverseInfo.HCP.update(fps);
}

/**
 最後のターンサークル(SPS)設定
 
 @param[in,out] sps 処理対象SPS
 */
void PathGenerator::setupSPS(PathSPS& sps) {
	sps.setEnterTurnCircle(traverseInfo.rotation * traverseInfo.boundaryType, gauge.turnRadius);
	if (traverseInfo.mode == TraverseInfo::Mode::END_NAV) {
		// 終了ナビゲーションの終端は点
		sps.setHeadLeg(0.0);
		sps.Circ.center = sps.enterPoint();
		sps.Circ.radius = 0.0;
    }

    setEscapeLeg(sps);
    traverseInfo.HCP.update(sps);
}

/**
 FPS脚延長
 
 指定インデックスのターンサークルまでFPSターンサークル位置を延ばす。
     - 最小パス脚長の保証はしない。
        - ターゲットサークルが置き換え可能かどうか以下の条件をテストする。可能でない場合は何も行わない。
     - ターンの種別
     - ターゲットがパス延長線上にある
     - 延長した脚が境界と交差しない
 
 @param[in,out] fps 処理対象FPS
 @param[in] htc ターゲットサークル
 @param[in] sps ターゲットSPS
 @return 処理結果
 @retval SUCCESS 延長成功
 @retval FAILRE  延長失敗
 */
int PathGenerator::extendFpsLeg(PathFPS& fps, const HeadlandTurnCircle& htc, const PathSPS& sps) {
	LOGV(LOG_TAG "::extendFpsLeg", "(%d)", htc.nodeIndex);
	
    const int bndFlg = htc.bndFlg;
	if ((bndFlg == BoundaryType::FIELD && htc.CvCnF == CONCAVE) ||
		(bndFlg == BoundaryType::OBSTACLE) ||
		(traverseInfo.mode == TraverseInfo::Mode::START_NAV))
	{
		// 対象のターンではない
		return FAILURE;
	}
	
	// 足を延ばしてみよう
	PathFPS tmpFPS{fps};
	int extended = tmpFPS.extendLegTo(htc, gauge);
	if (extended != SUCCESS) {
		// 延長線上に無い
		return FAILURE;
	}
	
    int result = FAILURE;
	// 脚のコリジョンチェック
	LineSegment leg = tmpFPS.getHeadLeg();
	leg.extendHead(-TOL_ONE_CM);	// HPとのコリジョン避け
    int collisions = checkBoundaryIntersection(leg, BoundaryType::Kind::FOR_WORKPATH_LEG);
    if (collisions == Intersection::NO && isStandIn(boundarySet.hp(), leg)) {
        collisions++;
        LOGD(LOG_TAG "::extendFpsLeg", "check FOR_WORKPATH_LEG:%d", collisions);
    }
    // ターゲットがコーナーでない場合、ターゲットとの間でコリジョンチェック
    //  - FPS-SPS間ではHPを跨いでも有効な接線を引いてしまうため。
    if (collisions == Intersection::NO && htc.nodeIndex < 0) {
        auto fpsLeg = tmpFPS.getHeadLeg();
        auto spsLeg = sps.getHeadLeg();
        fpsLeg.extendTail(tmpFPS.Circ.radius);
        spsLeg.extendHead(sps.Circ.radius);
        LineSegment ts{fpsLeg.point2(), spsLeg.point1()};
        collisions = checkBoundaryIntersection(ts, BoundaryType::Kind::FOR_INTER_WORKPATH_LEG);
    }

	if (collisions == Intersection::NO) {
		LOGD(LOG_TAG "::extendFpsLeg", "extendFpsLeg(nodeIndex:%d) SUCCESS", htc.nodeIndex);
		// 延長成功
		fps = tmpFPS;
        fps.extended = true;
		result = SUCCESS;
	}
	
	return result;
}

/**
 SPS脚延長
 
 指定インデックスのターンサークルまでSPSターンサークル位置を延ばす。
    - 最小パス脚長の保証はしない。
	- ターゲットサークルが置き換え可能かどうか以下の条件をテストする。可能でない場合は何も行わない。
		- ターンの種別
		- ターゲットがパス延長線上にある
		- 延長した脚が境界と交差しない

 @param[in,out] sps 処理対象SPS
 @param[in]     htc ターゲットサークル
 @param[in]     fps ターゲットFPS
 @return 処理結果
 @retval SUCCESS 延長成功
 @retval FAILRE  延長失敗
 */
int PathGenerator::extendSpsLeg(PathSPS& sps, const HeadlandTurnCircle& htc, const PathFPS& fps) {
	LOGV(LOG_TAG "::extendSpsLeg", "(nodeIndex:%d)", htc.nodeIndex);

    const int bndFlg = htc.bndFlg;
	if ((bndFlg == BoundaryType::FIELD && htc.CvCnF == CONCAVE) ||
		(bndFlg == BoundaryType::OBSTACLE) ||
		(traverseInfo.mode == TraverseInfo::Mode::END_NAV))
	{
		// 対象のターンではない
		return FAILURE;
	}
	
	// 脚を延ばしてみよう
	PathSPS tmpSPS{sps};
	int extended = tmpSPS.extendLegTo(htc, gauge);
	if (extended != SUCCESS) {
		// 延長線上に無い
		return FAILURE;
	}
	
    int result = FAILURE;
	// 脚をコリジョンチェック
	LineSegment leg = tmpSPS.getHeadLeg();
    leg.extendTail(-TOL_ONE_CM);	// HPとのコリジョン避け
	int collisions = checkBoundaryIntersection(leg, BoundaryType::Kind::FOR_WORKPATH_LEG);
    if (collisions == Intersection::NO && isStandIn(boundarySet.hp(), leg)) {
        collisions++;
    }
    // ターゲットがコーナーでない場合、ターゲットとの間でコリジョンチェック
    //  - FPS-SPS間ではHPを跨いでも有効な接線を引いてしまうため。
    if (collisions == Intersection::NO && htc.nodeIndex < 0) {
        auto fpsLeg = fps.getHeadLeg();
        auto spsLeg = tmpSPS.getHeadLeg();
        fpsLeg.extendTail(fps.Circ.radius);
        spsLeg.extendHead(tmpSPS.Circ.radius);
        LineSegment ts{fpsLeg.point2(), spsLeg.point1()};
      	collisions = checkBoundaryIntersection(ts, BoundaryType::Kind::FOR_INTER_WORKPATH_LEG);
    }

	if (collisions == Intersection::NO) {
		LOGD(LOG_TAG "::extendSpsLeg", "(nodeIndex:%d) SUCCESS", htc.nodeIndex);
		// 延長成功
		sps = tmpSPS;
        sps.extended = true;
		result = SUCCESS;
	}
	
	return result;
}

/**
 有人トラクターパスの作業領域延長
 createPathData後にしか呼び出せない。
 @param[in] vertices 有人作業パスデータ
 @return 延長後の有人作業パスデータ
 */
vector<GeoPoint> PathGenerator::createMannedPath(vector<GeoPoint> vertices) {

    for (auto it0 = vertices.begin(); it0 != vertices.end(); advance(it0, 2)) {
        auto it1 = std::next(it0);
        if (it1 == vertices.end()) {
            break;
        }
        LineSegment seg{*it0, *it1};
        if (gauge.workPath.leg.type == Param::Work::WorkPath::Leg::Type::FOLD) {
            seg.extendBoth(gauge.workPath.expandLength);
        }
        *it0 = seg.enterPoint();
        *it1 = seg.leavePoint();
    }

    return vertices;
}


#pragma mark - post-process functions
//
// ポストプロセス関数
//

/**
 作業パス最短保証
 短すぎる作業パスを非作業パスに変換する。
 @return 変換したセグメント数
 */
int PathGenerator::ensureWorkPathLength() {
    LOGV(LOG_TAG "::ensureWorkPathLength", "()");
    int count = 0;
    
    std::for_each(outputPathData.begin(), outputPathData.end(),
                    [&](OutPathData::value_type& oseg) {
                        if (oseg.segmentType == SegmentType::LINESEG &&
                            oseg.pathAttr.rideType == Param::Path::Segment::RideType::WORKING &&
                            oseg.length() < gauge.workPath.length.min) {
                            oseg.pathAttr.rideType = Param::Path::Segment::RideType::NON_WORKING;
                            count++;
                            LOGD(LOG_TAG "::ensureWorkPathLength", "[SHORT WORK SEG] (%g)m : %s", oseg.length(), to_string(oseg).c_str());
                        }
                    });
    
    return count;
}


#pragma mark - log dump for debug
//
// デバッグ用ログファイルダンプ
//

void PathGenerator::dumpHCP(const char* filename, const HLTCList& hcp) const {
#ifdef TXT_FILE_ENABLE
	//Save Parameters in text file
	ofstream oFile;
	oFile.open(filename);
    oFile << dumpHLTCList(hcp) << endl;
	oFile.close();
#endif
}

/**
 パスデータダンプ
 
 座標系変換前のパスデータをダンプする
 */
void PathGenerator::dumpTrnPath(const char* filename) const {
#ifdef TXT_FILE_ENABLE
	ofstream myfile;
	OutputDataStream os;
	myfile.open(string(LOG_DIR) + filename);
	myfile << os.str();
	os << this->outputPathData;
	myfile.close();
#endif // TXT_FILE_ENABLE
}

/**
 枕地移動範囲情報データダンプ
 
 TraverseSpanデータをダンプする
 */
void PathGenerator::dumpTraverseInfo(const char* filename) const {
#ifdef TXT_FILE_ENABLE
    ofstream myfile;
    myfile.open(string(LOG_DIR) + filename);
    myfile	<< PathGeneratorData::dumpTraverseInfo(traverseInfo);
    myfile.close();
#endif // TXT_FILE_ENABLE
}

}} // namespace yanmar::PathPlan

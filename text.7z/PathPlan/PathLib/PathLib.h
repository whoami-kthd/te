// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] PATH GENERATION                                                */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company                :            xxxx xxxxxxxxxxxx xxxx xxxxxxxxx     */
/* Client                 :            YANMAR Co. Ltd, JAPAN                */
/* Author                 :            MANUJ SHARMA,GAURAV                  */
/*                                     ( YANMAR PathPlanning Team )         */
/* Version                :            1.1                                  */
/*                                                                          */
/* The purpose of PathLib data class is to Create and process               */
/* turning path out of created path from OutLib class.                      */
/* It stores the created path in a structure which is later used for        */
/* sending it to display functionality.                                     */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140107                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/****************************************************************************/
#pragma once

#include "PathPlanIF.hpp"

#include <iostream>
#include <list>
#include <vector>
#include <array>
#include <queue>
#include <fstream>
#include <tuple>

#include "boost/geometry.hpp"

#include "PolyLib/Context.hpp"
#include "Gauge.hpp"
#include "Geometry/Geometry.hpp"
#include "OutLib/OutLib.h"
#include "Segment.hpp"
#include "PolyLib/DisplayData.h"
#include "PathGeneratorData.hpp"
#include "PathGeneratorError.hpp"
#include "PathValidator.hpp"
#include "PathAssembler.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

#pragma mark - OrbitalPathParam
/**
 周回パス生成パラメーターセット
 */
struct OrbitalPathParam {
    OrbitalPathParam() = default;
    OrbitalPathParam(const OrbitalPathParam&) = default;
    OrbitalPathParam(Gauge gauge, double aClearance) :
        pattern(gauge.headland.pattern),
        rotation(gauge.headland.rotation),
        transitRotation(gauge.headland.rotation),
        clearance(aClearance),
        interval(gauge.workPath.interval),
        count(gauge.fpGauge.headLandRasters)
    {}
    
    OrbitalPathParam& operator=(const OrbitalPathParam&) = default;
    
    /// パス形状　@see Param::Work::Headland::Pattern:
    int pattern = Param::Work::Headland::Pattern::CYCLONE;
    /// 周回方向　@see RotateDirection
    int rotation = RotateDirection::CLOCKWISE;
    /// 遷移周回方向　@see RotateDirection
    int transitRotation = RotateDirection::CLOCKWISE;
    /// クリアランス(基準辺から一周目のパスまでの距離)
    double clearance = 0.0;
    /// パス間隔
    double interval = 0.0;
    /// 周回数
    int count = 0;
    /// 周回打切り
    bool halfway = false;
    /// 基本周回ポリゴン辺
    vector<LineSegment> baseEdgeList;
    /// 周回辺数
    int edgeCount = 0;
    struct TransitEdgeMargins {
        double shiftLenMin = 0.0;
        double shiftLenFw = 0.0;
        double shiftLenBw = 0.0;
    } trEdgeMargin;

    /**
     遷移辺高度
     R-O間遷移エッジの高度。枕地の大外を回るか内側を周るか。
     */
    enum TransitAltitude : int {
        UNDEFINED = 0,
        LOW = 1,    // 低:周回パス内側へ接続する。
        HIGH = 2    // 高:周回パス外側へ接続する。逆走遷移パスの場合など。
    };
    int trEdgeAlt = TransitAltitude::UNDEFINED;

    /**
     シフト方向
     各辺を進行方向に対してシフトする方向を返す。{左|右}={+1|-1}
     */
    double shiftsign() const noexcept {
        double retval = 0.0;
        const double innerDir = rotation;
        const double outerDir = -rotation;
        switch (pattern) {
            case Param::Work::Headland::Pattern::CYCLONE:
                retval = innerDir;
                break;
            case Param::Work::Headland::Pattern::ANTICYCLONE:
                retval = outerDir;
                break;
            default:
                retval = 0;
                break;
        }
        
        return retval;
    }
    
    /**
     シフト量
     指定の周回に対する辺の基準辺のシフト量を返す。符号付き。
     @see shiftsign()
     */
    double getShiftValue(int lap) const noexcept {
        return (clearance + shiftsign() * (interval * lap));
    }
    
    /**
     頂点リスト方向変換要否
     */
    bool isNeedReverse() const noexcept {
        return (rotation == RotateDirection::ANTICLOCKWISE);
    }
};

#pragma mark - PathGenerator
/**
 パス生成クラス
 
 パスノード間を結んでパスを生成するクラス
 */
class PathGenerator {
	friend class PathGeneratorTest;
    friend struct Gauge;
    friend class PathValidator;
    friend class PathAssembler;
    friend class Engine;
    friend class ErrorPathGenerator;

    static constexpr int SUCCESS = PathGeneratorData::SUCCESS;
    static constexpr int FAILURE = PathGeneratorData::FAILURE;
    static constexpr int FAILURE_TERM_END = -2;
    static constexpr int VALID = SUCCESS;
    static constexpr int INVALID = FAILURE;
    static constexpr int CLOCKWISE = RotateDirection::CLOCKWISE;
    static constexpr int ANTICLOCKWISE = RotateDirection::ANTICLOCKWISE;
    /*
	 * external interface
	 */
public:
    using Polygon = OutVertexList;
	using Polygons = vector<Polygon>;
    using TurnPath = PathGeneratorData::TurnPath;
    using BoundarySet = PathGeneratorData::BoundarySet;
    using HwParam = PathGeneratorData::HwParam;
    using TraverseInfo = PathGeneratorData::TraverseInfo;
    using HLTCList = PathGeneratorData::HLTCList;
    using PathFPS = PathGeneratorData::PathFPS;
    using PathSPS = PathGeneratorData::PathSPS;
    using PathSpan = PathGeneratorData::PathSpan;
    using PathSpanStack = PathGeneratorData::PathSpanStack;

	/*
	 * PUBLIC functions
	 */
public:
    // constructor
    PathGenerator(ContextIF& context);
	// 入力パラメータ設定関数郡
	void setNodePathList(const OutNodeList& tp);
	void setBoundary(const Polygons& extents, const Polygons& hlps, const HwParam& aHwParam);
	void setGauge(const FpGauge& hPara, const InputData& inData);
	void setRotationPara(const XY_Point& refPoint, float angle1);
	// 生成準備
	int initTrnPath();
	// パス生成
	void generatePathData();
	void generatePathDataAB();
	
	// 出力パスデータ回転
	void rotatePathDataDisplay();

#pragma mark - PathGenerator data member
	/*
	 * PUBLIC data
	 */
public:
	/// 出力パスノード
    OutPathData outputPathData;
    /**
     周回打ち切りフラグ
     後周回作業を辺の途中で打ち切った場合にtrueになる
     */
    bool orbitalHalfway = false;

    /*
	 * INTERNAL
	 */
private:
	//Constants
	/// 障害物の頂点数
	static constexpr int OBsize	= 4;
	/// 開始ナビゲーション末端マージン
	static constexpr double START_NAV_TERM = 5.0;
	/// 終了ナビゲーション末端マージン
	static constexpr double END_NAV_TERM = 5.0;

private:
	int NoBP = 0; // 圃場外形の頂点数(障害物を含まない)
	int NoOB = 0; // 障害物の数
	int NoOBP = 0; // 全障害物の合計頂点数

	///////////////////
    ContextIF& context;    ///< パス生成コンテキスト
    Gauge gauge;    ///< パス生成用ゲージ(限界値や制限値)
	OutNodeList inputPathNodeList;	///< 入力パスノードリスト
    struct {
        XY_Point src;    ///< パス開始ノード座標
        XY_Point dest;   ///< パス終点ノード座標
    } endPoints;
    TurnPath pathBuffer;        ///< このパスの要素(パスセグメント)リスト
    TurnPath orbiatlPathBuffer; ///< このパスの要素(周回パス)リスト
    vector<LineSegment> rasterSegList;   ///< ラスター作業パスのリスト
	TraverseInfo traverseInfo;	///< 枕地移動属性
    BoundarySet boundarySet;    ///< 圃場、作業領域、交差判定用ポリゴン、凸凹フラグ・・・
    HwParam hwParam;            ///< 外周作業用追加情報
    PathSpanStack pathSpanStack;    ///< ナビゲーションパス生成中の履歴(バックトラック用)
    
	///////////////////
	PathPlan::Rotater rotater;	///< 座標回転器。基準点と回転角度を保持、座標回転を行う。

private:
#pragma mark - PathGenerator prepare
	/*
	 * パス生成準備
	 */
	// SHP準備
	// 圃場頂点のターン方向決定
	static void setCornerProperties(vector<Boundary>& PP);
	// その他事前検査
	int checkFieldBoundary();
	int checkObstacleBoundary();
	
	bool isNodeBP(const tData& node) { return (0 <= node.index && node.index < NoBP); }
	bool isNodeOBP(const tData& node) { return (NoBP <= node.index && node.index < (NoBP + NoOBP)); }
	bool isNodePath(const tData& node) { return ((NoBP + NoOBP) <= node.index); }

#pragma mark - PathGenerator path generation
	/*
	 * パス生成
	 */
	// 作業パス準備
	void removeRedundantNode();
    void makeStrictRasterPathNode();
	// 接続ノード選択
	OutNodeList getWorkingPathPoints(OutNodeList::iterator& ci, const OutNodeList::iterator& ce);
	// 孤立パス処理
	void addSporadicPathData(const OutNodeList& nodeList, const OutNodeList::const_iterator& ci);
	// HCP生成
	HLTCList extractTurnPoints(const OutNodeList& localList) const;
	
	// パス出力
	void addOutputPath(TurnPath& turnPath, const PathAttr& pathAttr);

    // ラスターパス生成
    int createRasterPath();

	/*
	 * ターンパス生成
	 */
	int createTurnPath();
    vector<GeoPoint> createMannedPath(vector<GeoPoint> vertices);
	// 入力チェック
	void validateCreateTurnPathInput(const HLTCList& htc);
    // 出力チェック
	void validateCreateTurnPathOutput(const TurnPath& turnPath);

    // 通常ターン生成
    void createStandardTurnPathValidated();
	int createStandardTurnPath();
    // ナビゲーションターン生成
    int createNaviTurnPath();

    // 生成中の現在の最新セグメント取得
    PathSegment getLastTangent();
    
	// 通常ターンパスバリデートとリトライ
	void validateTurnPathWithRetry();

    // 後折り畳み(どんつき)
    int foldLeg(TurnPath& turnPath);

    // 共線パス間接続
	int applyCollinearPath();
	
	// 通常ターンパス適用
	int applyStandardTurnPath();

    // HCP初期化
	void prepareHCP();
	int setOrbitingDirection();
	int getTraverseSpan();
    void adjustHCP();

#pragma mark - OrbitalPathGenerator part
    // 外周パス生成 - OrbitalPathGenerator
    int modifyTurnSegmentPropery();
    int getRasterEnterCornerIndex(const BoundaryPolygon& bdpolygon) const;
    int getRasterLeaveCornerIndex(const BoundaryPolygon& bdpolygon) const;
    int createPreOrbitalPath();
    int createPostOrbitalPath();
    vector<PathSegment> makeEdgeList(LineSegment& seg, BoundaryPolygon polygon, int firstCornerNode, OrbitalPathParam& params) const;
    vector<PathSegment> makeEdgeListPreOrbital(LineSegment& seg, vector<PathSegment> edgeList, int edgeCount, OrbitalPathParam& params) const;
    vector<PathSegment> makeEdgeListPostOrbital(LineSegment& seg, vector<PathSegment> edgeList, int edgeCount, OrbitalPathParam& params) const;
    void adjustPostAnticycloneEndPoint(vector<PathSegment>& edgeList, int edgeCount, OrbitalPathParam& params) const;
    vector<PathSegment> getVortexEdgesInsideOrigin(vector<LineSegment> baseEdgeList, const OrbitalPathParam& params) const;
    TurnPath createOrbitalPath(const vector<PathSegment>& edgeList, OrbitalPathParam& params);
    TurnPath getOrbitalPath(const vector<PathSegment>& edgeList, OrbitalPathParam& params);
    void adjustWorkingStartPoint(vector<PathSegment>& orbialEdgeList, const OrbitalPathParam& params) const;
    void adjustWorkingStartWhisker(vector<PathSegment>& orbialPath, TurnPath::iterator it, const OrbitalPathParam& params) const;
    void adjustWorkingStartWhisker(LineSegment& seg, vector<PathSegment>& noworkEdges, vector<PathSegment>& workEdges, const OrbitalPathParam& params) const;
    void adjustWorkingEndWhisker(LineSegment& seg, vector<PathSegment>& noworkEdges, vector<PathSegment>& workEdges, const OrbitalPathParam& params) const;

#pragma mark - StandardTurnGenerator part
    // 通常ターン生成関数群
    int createUTurn();
    int createFlatTurn();
    int createHookTurn();
    // フィッシュテールターン生成
    int createFishtailTurnFixed();
    int createFishtailTurnAdapive();
    int createFishtailTurn(bool adaptive = true);
    int seekFishtailAngle(PathFPS& FPS, PathSPS& SPS, int pth) const;

#pragma mark - NavigationPathGenerator part
	/*
	 * ターンパス最適化
	 * - ナビゲーションパス生成本体
	 */
	int createNavigationPath();
    void initHcpSkipList(HLTCList& hcp, PathFPS& fps, PathSPS& sps);
    bool applyPathLegs(PathSpan& pathSpan);
    int setEscapeLeg(PathFPS& fps);
    int setEscapeLeg(PathSPS& sps);
	PathSpan getFarthestPath(PathSpan pathSpan);
    HLTCList clipHCP(const HLTCList& srcHhp, int begin, int end);

	TurnPath optimizeFpsTurnPath(int index);
    TurnPath optimizeFpsTurnPathStartNav(int index);
    TurnPath optimizeFpsTurnPathEndNav(int index);
    TurnPath optimizeFpsTurnPathHalfway(const PathFPS& fps, const XY_Point& destPoint);
    TurnPath optimizeFpsSpsTurnPath(int index);
    TurnPath optimizeFpsSpsTurnPathEndNav(int index);
	TurnPath optimizeCornerTurnPath(LineSegment& eTS, Circle& currCirc, const Circle& nextCirc);
    TurnPath optimizeCornerTurnPathEndNav(LineSegment& eTS, Circle& currCirc, const Circle& nextCirc);
    TurnPath optimizeCornerTurnPath(Circle& currCirc, const Circle& nextCirc);
	TurnPath optimizeSpsTurnPath(LineSegment& eTS, int index);
    TurnPath optimizeSpsTurnPathStart(int index);
	TurnPath optimizeSpsTurnPathEnd(const LineSegment& eTS, int index);

    bool getFpsTurnPath(PathSpan& pathSpan, int index);
    bool getFpsSpsTurnPath(PathSpan& pathSpan, int index);
	bool getCornerTurnPath(PathSpan& pathSpan, int curr, int next);
	bool getSpsTurnPath(PathSpan& pathSpan, PathSegment& eTS, int index);
    double trimPathTail(TurnPath turnPath, double trimLen) const;

    void ensureHeadForward(TurnPath& startNav) const;
    void ensureTailForward(TurnPath& endNav) const;
    void ensureMinimalStartNav(TurnPath& startNav) const;
    bool ensureMinimalEndNav(TurnPath& endNav) const;

    /// パス生成試行条件
    struct TryCondition{
        /// 条件フラグセットクラス
        using Flags = std::bitset<4>;
        
        // インクリメントしていくとフラグビットが試行すべき順序で設定されていくようにビット位置を決める
        struct FPS {
            static constexpr unsigned int ALTTC  = 0;   ///< ターンサークルフリップ
            static constexpr unsigned int ALTLEG = 1;   ///< パス脚長変更
        };
        struct SPS {
            static constexpr unsigned int ALTTC  = 2;   ///< ターンサークルフリップ
            static constexpr unsigned int ALTLEG = 3;   ///< パス脚長変更
        };
        /// 条件パターン数
        static constexpr unsigned int END_OF_VALUE = (1 << TryCondition::Flags().size());
    };

    TryCondition::Flags applyCondition(HLTCList& hcp, PathFPS& fps, TryCondition::Flags condition);
    TryCondition::Flags applyCondition(HLTCList& hcp, PathSPS& sps, TryCondition::Flags condition);
    
    // 対向パス接続
    int createOppositeTurnPath();
    
#pragma mark - PathGenerator
	// パス脚セットアップ
    void setHeadLegMinimal(PathFPS& fps) const;
    void setHeadLegMinimal(PathSPS& sps) const;
	// FPSのセットアップ
	void setupFPS(PathFPS& fps);
	int extendFpsLeg(PathFPS& fps, const HeadlandTurnCircle& htc, const PathSPS& sps);
    void prepareSkipTurnCircle(HLTCList& hcp, PathFPS fps, const PathSPS& sps);
	// SPSのセットアッブ
	void setupSPS(PathSPS& sps);
	int extendSpsLeg(PathSPS& sps, const HeadlandTurnCircle& htc, const PathFPS& fps);
    void prepareSkipTurnCircle(HLTCList& hcp, PathSPS sps, const PathFPS& fps);

    // パスの検証クラスインスタンス
    PathValidator pathValidator;
    // 部分パスの生成クラスインスタンス
    PathAssembler pathAssembler;

    
#pragma mark - path validation
	/*
	 * ターンパス有効性検査
     *  - pathValidatorへ委譲
	 */

    // 圃場境界交差検査
    // - PathValidatorに委譲
    int checkBoundaryIntersection(const LineSegment& lineSeg, BoundaryType::Kind::Set targetFlag = PathPlan::BoundaryType::Kind::Mask::ALL) const {
        return pathValidator.checkBoundaryIntersection(lineSeg, targetFlag);
    }
    int checkBoundaryIntersection(const ArcSegment& arcSeg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const {
        return pathValidator.checkBoundaryIntersection(arcSeg, targetFlag);
    }
    int checkBoundaryIntersection(const GenSegment& gseg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const {
        if (gseg.segmentType == SegmentType::ARCSEG) {
            return checkBoundaryIntersection(static_cast<ArcSegment>(gseg), targetFlag);
        } else {
            return checkBoundaryIntersection(static_cast<LineSegment>(gseg), targetFlag);
        }
    }
    int checkBoundaryIntersection(const TurnPath& turnPath, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const {
        int result = Intersection::NO;
        
        for (auto& pseg : turnPath) {
            result = checkBoundaryIntersection(pseg, targetFlag);
            if (result != Intersection::NO) {
                break;
            }
        }
        
        return result;
    }

#pragma mark - post process
    /*
     * ポストプロセス
     */

    // 無効なセグメント削除
    void removeVoidSegemnt(TurnPath& turnPath);
    // 作業パス化
    void promoteToWorkPath();
    // 作業パス最小長保証
    int ensureWorkPathLength();
    
#pragma mark - log dump for debug
	/*
	 * デバッグダンプ
	 */
	void dumpHCP(const char* filename, const HLTCList& hcp) const;
	void dumpTrnPath(const char* filename) const;
	void dumpTraverseInfo(const char* filename) const;
};
    
}} // namespace yanmar::PathPlan

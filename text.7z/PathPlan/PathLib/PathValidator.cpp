// Yanmar Confidential 20200918
/**
 @file PathValidator.cpp
 
 パス検査クラス
 */
/// @internal @defgroup PathGenerator  PathGenerator interface

//#define LOGLEVEL 5

#include "PolyLib/Common.h"
#include "PathValidator.hpp"

#include <cstdlib>
#include <string>
#include <stdexcept>
#include <iostream>
#include <ostream>
#include <utility>

#include "PathPlanConstant.hpp"
#include "PathExtent.hpp"
#include "PolyLib/PolygonUtil.hpp"
#include "Geometry/Geometry.hpp"
#include "Segment.hpp"
#include "DataConverter/OutputDataStream.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

using namespace Param::Path;
using namespace SegmentType;
using namespace VertexType;
using namespace RotateDirection;
using namespace ResultCode;
using TurnPath = PathGeneratorData::TurnPath;
    
#pragma mark - anonymous namespace
namespace {

#undef LOG_TAG
#define LOG_TAG "PathPlan::PathLib"

/**
 差分方向符号取得
 
 dst までの src からの値の変化方向を返す。つまり、offsetSign(src, dst) のとき (dst - src) の符号を 1 か -1 で返す。
 
 @param[in] src 現在値
 @param[in] dst 目標値
 @retval 1 増加する(変化しない場合も含む)
 @retval -1 減少する
 */
template<typename T>
int offsetSign(const T& src, const T& dst) {
	return (dst < src) ? -1 : 1;
}

/**
 符号取得
 
 0 から dst の値の変化方向を返す。つまり、dstの符号を 1 か -1 で返す。
 
 @param[in] dst 目標値
 @retval 1 増加する(変化しない場合も含む)
 @retval -1 減少する
 */
template<typename T>
int offsetSign(const T& dst) {
	return signbit(dst) ? -1 : 1;
}

} // anonymous namespace


//
// PathGenerator definition
//
#pragma mark - PathValidator
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathValidator"

/**
 ターンパスセグメント検査
 
 生成したターンパスの各セグメントについて検査する
	- 境界に接触していないかどうかなど
	- ターンの種類を判別し異なる検査をする
	- セグメントが一つも無い場合はINVALIDを返す

 @param[in] turnPath 検査するターンパス
 @param[in] type ターン種別
 
 @return 検査結果
 @retval VALID  有効なパス
 @retval INVALID 無効なパス
 */
int PathValidator::checkTurnPath(TurnPath& turnPath, int turnType) const {
	LOGV(LOG_TAG "::checkTurnPath", "()");
	int retval = INVALID;

	if (turnPath.empty()) {
		// 空は有効なターンではない
        turnPath.invalidate();  // 念のため
		return retval;
	}
	
// TODO: 脚のチェック追加
//	if (checkPathLegIntersection() == Intersection::YES) {
//		// 脚のチェック
//		return retval;
//	}

	switch (turnType) {
    case Turn::Type::FISHTAIL:	// Fish tail Turn
        retval = validateFishtailTurn(turnPath);
        LOGV(LOG_TAG "::checkTurnPath", "[VALIDATE] Fishtail Turn (%d)", retval);
        break;
    case Turn::Type::HOOK:	// Hook Turn
        retval = validateHookTurn(turnPath);
        LOGV(LOG_TAG "::checkTurnPath", "[VALIDATE] Hook Turn (%d)", retval);
        break;
    case Turn::Type::U:		//U Turn
        retval = validateUTurn(turnPath);
        LOGV(LOG_TAG "::checkTurnPath", "[VALIDATE] U Turn (%d)", retval);
        break;
    case Turn::Type::FLAT: 	//Flat Turn
        retval = validateFlatTurn(turnPath);
        LOGV(LOG_TAG "::checkTurnPath", "[VALIDATE] Flat Turn (%d)", retval);
        break;
    case Turn::Type::NAVIGATION: // Navigation Turn
    default:
        retval = checkTurnPath(turnPath);
        LOGV(LOG_TAG "::checkTurnPath", "[VALIDATE] Navigation Turn (%d)", retval);
        break;
	}
	
	return retval;
}

/**
 ターンパス検査
 
 ターンパスの各セグメントと境界ポリゴンとの交差を検査する。
	- セグメントのターゲット境界指定フラグにより検査対象の境界ポリゴン(BP,HP,SHP)を選択する。
 
 @param[in] turnPath 検査するターンパス
 
 @return 検査結果
 @retval VALID  有効なパス
 @retval INVALID 無効なパス
 */
int PathValidator::checkTurnPath(TurnPath& turnPath) const {
	LOGV(LOG_TAG "::checkTurnPath", "(turnPath)");
	int retval = VALID;
	
	if (turnPath.size() < 2) {
		// 検査対象外
      	LOGW(LOG_TAG "::checkTurnPath(turnPath)", "[WARN] unecpected argument. size() < 2");
		return retval;
	}
	
	GenSegment SG;
	for (auto it = turnPath.begin(); it != prev(turnPath.end()); ++it) {
		auto& seg1 = *it;
		auto& seg2 = *next(it);
		
		if (seg1.segmentType == LINESEG) {
			// Line segment
			SG = GenSegment(LineSegment(seg1.point1(), seg2.point1()));
		} else {
			// arc segment
			SG = GenSegment(ArcSegment(seg1.point1(), seg2.point1(), seg1.Circ));
		}
		
		if (seg1.collisionBoundary.test(BoundaryType::Kind::Index::HP)) {
			// HPとのコリジョン避け
			if (it == turnPath.begin()) {
				SG.extendHead(-TOL_TEN_CM);
			}
			if (it == prev(turnPath.end(), 2)) {
				SG.extendTail(-TOL_TEN_CM);
			}
		}
		int intersection = checkBoundaryIntersection(SG, seg1.collisionBoundary);
		if (intersection == Intersection::YES) {
            LOGD(LOG_TAG "::checkTurnPath", "COLLIDE at(%d)", (int)std::distance(turnPath.begin(), it));
			retval = INVALID;
			break;
		}
	}
		
	return retval;
}

/**
 フィッシュテールターンの検査

 @param[in] turnPath    検査対象ターンパス
 
 @return 検査結果
 @retval VALID  有効なパス
 @retval INVALID 無効なパス
 */
int PathValidator::validateFishtailTurn(TurnPath& turnPath) const {
	LOGV(LOG_TAG "::validateFishtailTurn", "()");

	// セグメント数
	if (turnPath.size() != NUM_OF_FISHTAIL_TURN_SEGMENTS + 1) {
		// 生成に最初から失敗している
		return INVALID;
	}
	// セグメント種別
	if (!(turnPath[0].segmentType == SegmentType::LINESEG &&
		  turnPath[1].segmentType == SegmentType::ARCSEG  &&
		  turnPath[2].segmentType == SegmentType::LINESEG &&
		  turnPath[3].segmentType == SegmentType::LINESEG &&
		  turnPath[4].segmentType == SegmentType::ARCSEG  &&
		  turnPath[5].segmentType == SegmentType::LINESEG &&
		  turnPath[1].Circ.orient == turnPath[4].Circ.orient)) {
		return INVALID;
	}

	if (!gauge.permitBackward) {
		// バック移動禁止のとき
        ErrorPathGenerator err(ErrorCode::PathGeneration::StdTurn::INCLUDE_BACKWARD);
		err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] path includes reverse segment without backward permission.", "::validateFishtailTurn");
		throw err;
	}

	try {
		// 生成後検査2:パス頂点がBP外に無いこと
		validatePoints(turnPath);
		// 生成後検査3:パスがSHPに交差しないこと
		validateIntersectionWithShp(turnPath);
	} catch (...) {
		return INVALID;
	}
	
	return VALID;
}

/**
 フックターンの検査
 
 @param[in] turnPath    検査対象ターンパス
 
 @return 検査結果
 @retval VALID  有効なパス
 @retval INVALID 無効なパス
 */
int PathValidator::validateHookTurn(TurnPath& turnPath) const {
	// セグメント数
	if (turnPath.size() != NUM_OF_HOOK_TURN_SEGMENTS + 1) {
		// 生成に最初から失敗している
		return INVALID;
	}
	// セグメント種別
	if (!(turnPath[0].segmentType == SegmentType::LINESEG &&
		  turnPath[1].segmentType == SegmentType::ARCSEG  &&
		  turnPath[2].segmentType == SegmentType::LINESEG &&
		  turnPath[3].segmentType == SegmentType::ARCSEG  &&
		  turnPath[4].segmentType == SegmentType::LINESEG &&
		  turnPath[1].Circ.orient != turnPath[3].Circ.orient)) {
		return INVALID;
	}

	try {
		// 生成後検査2:パス頂点がBP外に無いこと
		validatePoints(turnPath);
		// 生成後検査3:パスがSHPに交差しないこと
		validateIntersectionWithShp(turnPath);
	} catch (...) {
		return INVALID;
	}
	
    const int intersect = checkIntersectionWithHp(turnPath);
	if (intersect == Intersection::YES) {
		return INVALID;
	}

	return  VALID;
}

/**
 Uターンの検査
 
 @param[in] turnPath    検査対象ターンパス
 
 @return 検査結果
 @retval VALID  有効なパス
 @retval INVALID 無効なパス
 */
int PathValidator::validateUTurn(TurnPath& turnPath) const {
	// セグメント数
	if (turnPath.size() != NUM_OF_U_TURN_SEGMENTS + 1) {
		// 生成に最初から失敗している
		return INVALID;
	}
	// セグメント種別
	if (!(turnPath[0].segmentType == SegmentType::LINESEG &&
		  turnPath[1].segmentType == SegmentType::ARCSEG  &&
		  turnPath[2].segmentType == SegmentType::LINESEG)) {
		return INVALID;
	}

	try {
		// 生成後検査2:パス頂点がBP外に無いこと
		validatePoints(turnPath);
		// 生成後検査3:パスがSHPに交差しないこと
		validateIntersectionWithShp(turnPath);
	} catch (...) {
		return INVALID;
	}
	
	const int intersect = checkIntersectionWithHp(turnPath);
	if (intersect == Intersection::YES) {
		return INVALID;
	}

	return VALID;
}

/**
 フラットターンの検査
 
 @param[in] turnPath    検査対象ターンパス
 
 @return 検査結果
 @retval VALID  有効なパス
 @retval INVALID 無効なパス
 */
int PathValidator::validateFlatTurn(TurnPath& turnPath) const {
	// セグメント数
	if (turnPath.size() != NUM_OF_FLAT_TURN_SEGMENTS + 1) {
		// 生成に最初から失敗している
		return INVALID;
	}
	// セグメント種別
	if (!(turnPath[0].segmentType == SegmentType::LINESEG &&
		  turnPath[1].segmentType == SegmentType::ARCSEG  &&
		  turnPath[2].segmentType == SegmentType::LINESEG &&
		  turnPath[3].segmentType == SegmentType::ARCSEG  &&
		  turnPath[4].segmentType == SegmentType::LINESEG &&
		  turnPath[1].Circ.orient == turnPath[3].Circ.orient)) {
		return INVALID;
	}

	try {
		// 生成後検査2:パス頂点がBP外に無いこと
		validatePoints(turnPath);
		// 生成後検査3:パスがSHPに交差しないこと
		validateIntersectionWithShp(turnPath);
	} catch (...) {
		return INVALID;
	}
	
    if (checkIntersectionWithHp(turnPath) == Intersection::YES) {
        return INVALID;
    }

    if (2 < HCP.size()) {
        // ナビゲーションパスのとき
        // - ターンサークル間接線は厳密にチェック
        LineSegment tseg{turnPath[2].point(), turnPath[3].point()};
        if (checkBoundaryIntersection(tseg, BoundaryType::Kind::FOR_DEFAULT) == Intersection::YES) {
            return INVALID;
        }
        // カーブがHPを踏まない
        ArcSegment aseg1{static_cast<ArcSegment>(turnPath[1])};
        aseg1.point2() = turnPath[2].point();
        ArcSegment aseg2{static_cast<ArcSegment>(turnPath[3])};
        aseg2.point2() = turnPath[4].point();
        if ((checkBoundaryIntersection(aseg1, BoundaryType::Kind::FOR_DEFAULT) == Intersection::YES) ||
            (checkBoundaryIntersection(aseg2, BoundaryType::Kind::FOR_DEFAULT) == Intersection::YES)) {
            return INVALID;
        }
    }

	return VALID;
}

/**
境界交差判定(パス)

指定パス内のセグメントとBoundaryの各境界との交差およびクリアランスをチェックする。
- targetFlagで検査するターゲット境界(BP, HP, SHP)を指定する。
   - 現在、ターゲット境界指定フラグのBPとSHPは同値である。SHPの交差ではなくBPに対するクリアランスチェックを行う。
       - SHPポリゴン自体が廃止予定である。
- HPが指定された場合、セグメントがHP内かどうかもチェックする。
- 障害物は未対応

@param[in] turnPath     検査するパス
@param[in] targetFlag ターゲット境界指定フラグ
@return 交差判定結果
@retval Intersection::NO　交差なし
@retval その他            交差あり
*/
int PathValidator::checkBoundaryIntersection(TurnPath& turnPath, BoundaryType::Kind::Set targetFlag) const {
    int retval = Intersection::NO;
    for (const auto& seg : turnPath) {
        retval = checkBoundaryIntersection(seg, targetFlag);
        if (retval != Intersection::NO) {
            turnPath.invalidate();
            break;
        }
    }

    return retval;
}

/**
 境界交差判定(直線)

 指定セグメントとBoundaryの各境界との交差およびクリアランスをチェックする。
 - targetFlagで検査するターゲット境界(BP, HP, SHP)を指定する。
    - 現在、ターゲット境界指定フラグのBPとSHPは同値である。SHPの交差ではなくBPに対するクリアランスチェックを行う。
        - SHPポリゴン自体が廃止予定である。
 - HPが指定された場合、セグメントがHP内かどうかもチェックする。
 - 障害物は未対応

 @param[in] SG 検査するセグメント
 @param[in] targetFlag ターゲット境界指定フラグ
 @return 交差判定結果
 @retval Intersection::NO　交差なし
 @retval その他            交差あり
 */
int PathValidator::checkBoundaryIntersection(const LineSegment& SG, BoundaryType::Kind::Set targetFlag) const {
//	LOGV(LOG_TAG "::checkBoundaryIntersection",
//		 "(%s, target:0x%lu)", to_string(SG, "LSG").c_str(), targetFlag.to_ulong());

	if (SG.isNegrective()) {
      	LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: IGNORED SEGMENT");
		return Intersection::NO;
	}

    if (targetFlag.none()) {
        LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: NO TARGET BOUNDARY");
        return Intersection::NO;
    }

    if (gauge.workPath.types == Gauge::WorkPath::Type::COMBINED_SIMPLEX) {
        // 渦巻きのときHP無視
        targetFlag.reset(BoundaryType::Kind::Index::HP);
        targetFlag.reset(BoundaryType::Kind::Index::EHP);
    }

    PathExtentLine pe{SG, gauge, targetFlag};
    PathGeneratorData::BoundaryCollisions collisions;
    const bool checkClearance = targetFlag.test(BoundaryType::Kind::Index::SBP);

	if (traverseInfo.boundaryType == BoundaryType::FIELD) {
		//field boundary
		/* Check for intersection */
        const auto& field = boundarySet.field;
        for (auto it1 = field.cbegin(); it1 != field.cend(); ++it1) {
            auto it2 = nextCyclic(field, it1);
			FieldLineSegment fls(*it1, *it2);

            if (targetFlag.test(BoundaryType::Kind::Index::HP) || targetFlag.test(BoundaryType::Kind::Index::EHP)) {
                if (gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
                    gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE) {
                    // 外周作業あり+オフセット半渦巻のときWHPと作業耕跡を使う(後で)
                    // NOP
                } else {
                    // 現在はEHP境界頂点ポリゴンがあるので常にEHPを使う
                    const LineSegment& flsEHP = fls.getSegmentEHP();
                    // ここではパス本体のみ。対HPクリアランスは後で凸頂点を踏まないかどうかをチェックする。
                    collisions.HP = flsEHP.checkIntersection(SG);
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "[PATH SEGMENT]\n %s", Svg::to_path_d(SG, "ORG    :").c_str());
                }
			}

            if (collisions.isValid()) {
                if (checkClearance) {
                    // BPに対する交差とクリアランス
                    collisions.BP = pe.checkIntersection(fls);
                } else if (targetFlag.test(BoundaryType::Kind::Index::BP)) {
                    // BPに対する交差のみ
                    LineSegment flsBP = fls.getSegmentBP();
                    collisions.BP = flsBP.checkIntersection(SG);
                }
            }

			if (!collisions.isValid()) {
				LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: HP:0x%x, BP:0x%x (at %d)\n %s\n %s",
                                                                 collisions.HP, collisions.BP, (int)distance(field.cbegin(), it1),
                                                                 Svg::to_path_d(fls.getSegmentBP(), "BP     :").c_str(),
                                                                 Svg::to_path_d(fls.getSegmentHP(), "HP     :").c_str());
                if (collisions.HP != 0) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "[PATH EXTENT] LINE FORWARD\n %s",
                                                                     Svg::to_path_d(SG,            "ORG    :").c_str());
                } else if (collisions.BP != 0) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "[PATH EXTENT] LINE FORWARD\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s\n %s",
                                                                     Svg::to_path_d(pe.path,       "PATH   :").c_str(),
                                                                     Svg::to_path_d(pe.front,            "FRONT:").c_str(),
                                                                     Svg::to_path_d(pe.frontCorner.left, "FC.L :").c_str(), Svg::to_path_d(pe.frontCorner.right, "FC.R :").c_str(),
                                                                     Svg::to_path_d(pe.frontSide.left,   "FS.L :").c_str(), Svg::to_path_d(pe.frontSide.right,   "FS.R :").c_str(),
                                                                     Svg::to_path_d(pe.trunkSide.left,   "TS.L :").c_str(), Svg::to_path_d(pe.trunkSide.right,   "TS.R :").c_str(),
                                                                     Svg::to_path_d(pe.rearSide.left,    "RS.L :").c_str(), Svg::to_path_d(pe.rearSide.right,    "RS.R :").c_str(),
                                                                     Svg::to_path_d(pe.rearCorner.left,  "RC.L :").c_str(), Svg::to_path_d(pe.rearCorner.right,  "RC.R :").c_str(),
                                                                     Svg::to_path_d(pe.rear,             "REAR :").c_str());
                }
				return Intersection::YES;
			}
		}

        // EHP
        // - 凸頂点を踏まないかどうかチェック。ポリゴンの外側なので凹角は無視している。
        if (targetFlag.test(BoundaryType::Kind::Index::EHP) && 2 < HCP.size() && HCP.curr != HCP.next) {
            // 現在ターンサークル位置はEHP頂点であることを期待している
            for (auto htc : HCP) {
                if (htc.nodeIndex < 0 || htc.CvCnF == CONCAVE) {
                    // 端はFPS/SPSなので除外
                    // 凹頂点も除外
                    continue;
                }
                const auto& cornerPoint = htc.EHP;
                const bool result = SG.isAside(cornerPoint, gauge.actHPD);
                if (result) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: HP CLEARANCE ERROR: node:%d; %s", htc.nodeIndex, Svg::to_point(cornerPoint).c_str());
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "[PATH EXTENT] LINE\n %s\n %s\n %s",
                                                                     Svg::to_path_d(SG, "ORG    :").c_str(),
                                                                     Svg::to_path_d(getCollateralSegment(SG, gauge.actHPD), "SIDE.L :").c_str(),
                                                                     Svg::to_path_d(getCollateralSegment(SG, -gauge.actHPD), "SIDE.R :").c_str());
                    return Intersection::YES;
                }
            }
        }

        // WHP
        if ((targetFlag.test(BoundaryType::Kind::Index::HP) || targetFlag.test(BoundaryType::Kind::Index::EHP)) &&
            gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
            gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE) {
            // 半渦巻のとき、WHP判定
            const auto& whp = boundarySet.whp();
            const auto whpEdges = getEdgeList(whp, whp.cbegin());
            LineSegment left = getCollateralSegment(SG, gauge.halfTractorWidth);
            LineSegment right = getCollateralSegment(SG, -gauge.halfTractorWidth);
            for (const auto& wseg : whpEdges) {
                if (left.checkIntersection(wseg) != Intersection::NO ||
                    right.checkIntersection(wseg) != Intersection::NO) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: WHP CLEARANCE ERROR:\n%s", Svg::to_path(wseg).c_str());
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "[PATH EXTENT] LINE\n %s\n %s\n %s",
                                                                     Svg::to_path_d(pe.body, "ORG    :").c_str(),
                                                                     Svg::to_path_d(right, "SIDE.L :").c_str(),
                                                                     Svg::to_path_d(right, "SIDE.R :").c_str());
                    return Intersection::YES;
                }
            }
        }
        
        // 両端点がポリゴン内だと交差が存在しないためチェックする
        if (targetFlag.test(BoundaryType::Kind::Index::HP) || targetFlag.test(BoundaryType::Kind::Index::EHP)) {
            if (gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
                gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE) {
                if (isStandIn(boundarySet.whp(), SG)) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: endpoints within WHP");
                    return Intersection::YES;
                }
            } else {
                if (isStandIn(boundarySet.ehp(), SG)) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: endpoints within EHP");
                    return Intersection::YES;
                }
            }
		}
	} else if (traverseInfo.boundaryType == BoundaryType::OBSTACLE) {
		// obstacle boundary
        // TODO: 障害物対応時はポリゴン計算から対応すること。
        //       現在はクリアランスが足りない
        for (const auto& PP : boundarySet.obstacles) {
			for (auto it1 = PP.cbegin(); it1 != PP.cend(); ++it1) {
				auto it2 = nextCyclic(PP, it1);
				ObstacleLineSegment ols(*it1, *it2);
				
                if (targetFlag.test(BoundaryType::Kind::Index::HP)) {
                    LineSegment olsHP = ols.getSegmentHP();
                    // 対HPクリアランスはEHPで行うので本体のみ
                    collisions.HP = olsHP.checkIntersection(SG);
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "[PATH SEGMENT]\n %s", to_string(SG, "ORG    :").c_str());
                }
                
                if (checkClearance && collisions.isValid()) {
                    // BPに対する交差とクリアランス
                    collisions.BP = pe.checkIntersection(ols);
                }

				if (!collisions.isValid()) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: HP:0x%x, BP:0x%x", collisions.HP, collisions.BP);
					return Intersection::YES;
				}
			}
		}

        // HP凸頂点を踏まないかどうかチェック
        if (targetFlag.test(BoundaryType::Kind::Index::EHP) && 2 < HCP.size() && HCP.curr != HCP.next) {
            for (auto htc : HCP) {
                if (htc.nodeIndex < 0) {
                    // 端はFPS/SPSなので除外
                    continue;
                }
                const auto& cornerPoint = htc.EHP;
                if (SG.isAside(cornerPoint, gauge.actHPD)) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: OHP CLEARANCE ERROR: node:%d; %s", htc.nodeIndex, to_string(cornerPoint).c_str());
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "[PATH EXTENT] LINE\n %s\n %s\n %s",
                                                                     to_string(SG, "ORG    :").c_str(),
                                                                     to_string(getCollateralSegment(SG, gauge.actHPD),  "SIDE.L :").c_str(),
                                                                     to_string(getCollateralSegment(SG, -gauge.actHPD), "SIDE.R :").c_str());
                    return Intersection::YES;
                }
            }
        }
    } else {
		// 境界種別が圃場・障害物どちらでもない
		LOGE(LOG_TAG "::checkBoundaryIntersection(LSG)", "[EXCEPTION] unknown boundary type: %d", traverseInfo.boundaryType);
		throw ErrorPathGenerator(ErrorCode::PathGeneration::Boundary::UNKOWN_TYPE);
	}

	LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: HP:0x%x, BP:0x%x", collisions.HP, collisions.BP);
	return Intersection::NO;
}

/**
 境界交差判定(円弧)
 
 指定セグメントとBoundaryの各境界ポリゴンとの交差をチェックする。
 - 境界ポリゴンは障害物がある場合を考慮していない
 - targetFlagで BP, HP およびクリアランスの有無を指定する
 - HPの場合のみ、セグメントがHP内かどうかもテストする
 
 @param[in] SG 検査対象の円弧セグメント
 @param[in] targetFlag ターゲット境界指定フラグ
 @return 交差判定結果
 @retval Intersection::NO　交差なし
 @retval その他            交差あり
 */
int PathValidator::checkBoundaryIntersection(const ArcSegment& SG, BoundaryType::Kind::Set targetFlag) const {
//	LOGV(LOG_TAG "::checkBoundaryIntersection",
// 		 "(%s, target:0x%lu)", to_string(SG, "ASG").c_str(), targetFlag.to_ulong());

	if (SG.isNegrective()) {
		return Intersection::NO;
	}

    if (gauge.workPath.types == Gauge::WorkPath::Type::COMBINED_SIMPLEX) {
        // 渦巻きのときHP無視
        targetFlag.reset(BoundaryType::Kind::Index::HP);
        targetFlag.reset(BoundaryType::Kind::Index::EHP);
    }

    // BPクリアランステスト用内径&外径カーブ
    PathExtentArc pe{SG, gauge};
    // 判定結果値
    PathGeneratorData::BoundaryCollisions collisions;
    // クリアランス要否
    const bool checkBpClearance = targetFlag.test(BoundaryType::Kind::Index::SBP);

    if (traverseInfo.boundaryType == BoundaryType::FIELD) {
		//field boundary
        const auto& field = boundarySet.field;

		/* Check for intersection */
        for (auto it1 = field.cbegin(); it1 != field.cend(); ++it1) {
            auto it2 = nextCyclic(field, it1);
			
			FieldLineSegment fls(*it1, *it2);
			if (targetFlag.test(BoundaryType::Kind::Index::EHP)) {
                if (gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
                    gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE) {
                    // 外周作業あり+オフセット半渦巻のときWHPと作業耕跡を使う(後で)
                    // NOP
                } else {
                    LineSegment flsEHP = fls.getSegmentEHP();
                    collisions.HP += flsEHP.checkIntersection(SG);
                }
			}

            if (checkBpClearance && collisions.isValid()) {
                // SHP/BPに交差しない場合のみ内径/外径のBPクリアランステストをする
                collisions.BP = pe.checkIntersection(fls);
            }

            if (!collisions.isValid()) {
				LOGV(LOG_TAG "::BoundaryInterSection(ARC)", "RESULT: HP:0x%x, BP:0x%x (at %d)\n %s\n %s\n[PATH EXTENT] ARC\n %s\n %s\n %s\n %s\n %s",
                                                             collisions.HP, collisions.BP, (int)it1->nodeIndex,
                                                             Svg::to_path_d(fls.getSegmentBP(), "BP   :").c_str(),
                                                             Svg::to_path_d(fls.getSegmentEHP(),"EHP  :").c_str(),
                                                             Svg::to_path_d(pe.org,             "ORG  :").c_str(),
                                                             Svg::to_path_d(pe.inner,           "INNER:").c_str(),
                                                             Svg::to_path_d(pe.outer,           "OUTER:").c_str(),
                                                             Svg::to_path_d(pe.front,           "FRONT:").c_str(),
                                                             Svg::to_path_d(pe.rear,            "REAR :").c_str());
				return Intersection::YES;
			}
		}
        // WHP
        if ((targetFlag.test(BoundaryType::Kind::Index::HP) || targetFlag.test(BoundaryType::Kind::Index::EHP)) &&
            gauge.headland.process != PathPlan::Param::Work::Headland::Process::NOP &&
            gauge.workPath.pattern == PathPlan::Param::Work::Pattern::SEMICYCLONE) {
            // 反渦巻のとき、WHP判定
            const auto& whp = boundarySet.whp();
            const auto whpEdges = getEdgeList(whp, whp.cbegin());
            for (const auto& wseg : whpEdges) {
                if (SG.checkIntersection(wseg) != Intersection::NO) {
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "RESULT: WHP CLEARANCE ERROR:\n%s", Svg::to_path(wseg).c_str());
                    LOGV(LOG_TAG "::checkBoundaryIntersection(LSG)", "[PATH EXTENT] ARC:\n%s",
                                                                     Svg::to_path_d(SG, "ORG    :").c_str());
                    return Intersection::YES;
                }
            }
        }
	} else if (traverseInfo.boundaryType == BoundaryType::OBSTACLE) {
        // obstacle boundary
        // TODO: 障害物対応時はポリゴン計算から対応すること。
        //       現在はクリアランスが足りない
        const auto& obstacles = boundarySet.obstacles;
        for (const auto& PP : obstacles) {
			for (auto it1 = PP.cbegin(); it1 != PP.cend(); ++it1) {
				auto it2 = nextCyclic(PP, it1);
				
				ObstacleLineSegment ols(*it1, *it2);
				
                if (targetFlag.test(BoundaryType::Kind::Index::HP)) {
                    LineSegment olsHP = ols.getSegmentHP();
                    collisions.HP += olsHP.checkIntersection(SG);
                }
				
                if (checkBpClearance && collisions.isValid()) {
                    // BPに交差しない場合のみ内径/外径のBPクリアランステストをする
                    collisions.BP = pe.checkIntersection(ols);
                }

                if (!collisions.isValid()) {
                    LOGV(LOG_TAG "::BoundaryInterSection(ARC)", "RESULT: OHP:0x%x, OBP:0x%x (at %d)\n %s\n %s\n[PATH EXTENT] ARC\n %s\n %s\n %s\n %s\n %s",
                                                                 collisions.HP, collisions.BP, (int)it1->nodeIndex,
                                                                 Svg::to_path_d(ols.getSegmentBP(), "BP   :").c_str(),
                                                                 Svg::to_path_d(ols.getSegmentHP(), "HP   :").c_str(),
                                                                 Svg::to_path_d(pe.inner,           "ORG  :").c_str(),
                                                                 Svg::to_path_d(pe.inner,           "INNER:").c_str(),
                                                                 Svg::to_path_d(pe.outer,           "OUTER:").c_str(),
                                                                 Svg::to_path_d(pe.front,           "FRONT:").c_str(),
                                                                 Svg::to_path_d(pe.rear,            "REAR :").c_str());
                    return Intersection::YES;
                }
            }
        }
	} else {
		// 境界種別が圃場・障害物どちらでもない
		LOGE(LOG_TAG "::checkBoundaryIntersection(ARC)", "[EXCEPTION] unknown boundary type: %d", traverseInfo.boundaryType);
		throw  ErrorPathGenerator(traverseInfo.fps, traverseInfo.sps, ErrorCode::PathGeneration::Boundary::UNKOWN_TYPE);
	}
	
    LOGV(LOG_TAG "::BoundaryInterSection(ARC)", "RESULT: HP:0x%x, BP:0x%x", collisions.HP, collisions.BP);
	return Intersection::NO;
}

/**
 パスセグメント交差検査(出力パスセグメント)
 
 対象パスセグメントsegを[begin, end)の範囲のパスで踏まないかどうか検査する。
 - 単に線分ではなく幅を考慮する。
 - 共線ナビゲーションパスの作業パス化ポストプロセス用の検査なので対象セグメントは作業パスとし前後のマージンは考慮しない。
 - パス中の検査対象のセグメントはフラグで識別する
 
 @param[in] seg     パスグメント(作業パスを想定)
 @param[in] begin   パス範囲の開始イテレータ
 @param[in] end     パス範囲の終了イテレータ
 */
int PathValidator::checkIntersection(const OutPathData::value_type& seg, OutPathData::iterator begin, OutPathData::iterator end) const {
    auto retval = Intersection::NO;
    WorkPathExtentLine peT{seg, gauge};

    for (auto it = begin; it != end; it++) {
        if (!it->ppInfo.intersectTarget) {
             // 非対象のセグメント
            continue;
        }
        // 交差判定
        if (it->segmentType == SegmentType::LINESEG) {
            FootPrintExtentLine peLine{*it, gauge};
            retval = PathPlan::checkIntersection(peT, peLine);
            if (retval != Intersection::NO) {
                LOGD(LOG_TAG "::checkIntersection(OutPathSeg, range)", "collides:\nlseg:%s\nvs :%s", peT.to_svg().c_str(), peLine.to_svg().c_str());
            }
        } else {
            FootPrintExtentArc peArc{*it, gauge};
            retval = PathPlan::checkIntersection(peT, peArc);
            if (retval != Intersection::NO) {
                LOGD(LOG_TAG "::checkIntersection(OutPathSeg, range)", "collides:\naseg:%s\nvs :%s", peT.to_svg().c_str(), peArc.to_svg().c_str());
            }
        }

        if (retval != Intersection::NO) {
            break;
        }
    }
    
    return retval;
}


int PathValidator::checkIntersection(const TurnPath& turnPath, const std::vector<LineSegment>& seglist) const {
    auto retval = Intersection::NO;
//    WorkPathExtentLine peT{seg, gauge};
    if (turnPath.size() < 3) {
        // 検査対象外
        return retval;
    }

    for (auto it = std::next(turnPath.cbegin()); it != std::prev(turnPath.end(), 2); it++) {
        const auto& seg = *it;
        for (const auto& wpseg : seglist) {
            // 交差判定
            retval = seg.LineSegment::checkIntersection(wpseg);
            if (retval != Intersection::NO) {
                LOGD(LOG_TAG "::checkIntersection", "Collision with Raster workpath segment:\n%s%s",
                     Svg::to_path(seg).c_str(), Svg::to_path((LineSegment)wpseg).c_str());
                break;
            }
        }
        if (retval != Intersection::NO) {
            break;
        }
    }
    
    return retval;
}



#pragma mark - PathValidator:: Validator Functions
/**
 ターンパス検査(対BP)

 ターンパスの全ての点がBP内かつOBP外にあることを検査する。BP外またはOBP内にあるものを発見した場合例外を投げる。
 
 @param[in] turnPath    検査対象ターンパス
 */
void PathValidator::validatePoints(const TurnPath& turnPath) const {

	const auto& fldBP = boundarySet.bp();
	for (auto seg : turnPath) {
		XY_Point Pnt = seg.point1();
		if (!within(fldBP, Pnt)) {
			ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::PostValidation::POINT_OUTSIDE_OF_BP);
			err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] a point is outside of field boundary.");
			err.points.push_back(Pnt);
			throw err;
		}
	}

	/*Check if point is inside or outside of obstcle boundary*/
	for (int j = 0; j < NoOB; j++) {
		const auto& obstBP = boundarySet.obp(j);
		for (auto seg : turnPath) {
			XY_Point Pnt = seg.point1();
			if (within(obstBP, Pnt)) {
				ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::PostValidation::POINT_INSIDE_OF_OBP);
				err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] a point is inside of obstacle boundary.");
				err.points.push_back(Pnt);
				throw err;
			}
		}
	}
}

/**
 パス衝突検査
 
 パスがBPと交差しないかどうか検査する。交差がある場合例外を投げる。
 @param[in] turnPath 検査するターンパス
 @see validateIntersectionWithShp(TurnPath::const_iterator beginIt, TurnPath::const_iterator endIt)
 */
void PathValidator::validateIntersectionWithShp(const TurnPath& turnPath) const {
	LOGV(LOG_TAG "::validateIntersectionWithShp", "(TurnPath)");

	if (turnPath.size() < 2) {
		// 検査対象外
		return;
	}
    auto beginIt = turnPath.cbegin();
    auto endIt = std::prev(turnPath.cend());

    validateIntersectionWithShp(beginIt, endIt);
}

/**
 パス衝突検査
 
 指定の範囲のパスがBPと交差しないかどうか検査する。交差がある場合例外を投げる。
 - パスセグメントが持つ検査対象はNONEのみ有効。
 @param[in] beginIt 検査範囲先頭イテレータ
 @param[in] endIt   検査範囲終点イテレータ(これは検査しない)
 */
void PathValidator::validateIntersectionWithShp(TurnPath::const_iterator beginIt, TurnPath::const_iterator endIt) const {
    LOGV(LOG_TAG "::validateIntersectionWithShp", "(beginIt, endit)");
    
    for (auto it = beginIt; it != endIt; it++) {
        auto& seg = *it;
        if (seg.collisionBoundary.none()) {
            // 非対象セグメント
            // - 例:バック前の準備直進
            continue;
        }
        if (checkBoundaryIntersection(seg, BoundaryType::Kind::Mask::SBP) == Intersection::YES) {
            LOGV(LOG_TAG, "Turn Path (LINE) Collision with safe headland\n%s", Svg::to_path(seg).c_str());
            ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::PostValidation::BP_CLEARANCE);
            err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] Turn Path Collision with safe headland.", "::validateIntersectionWithShp");
            throw err;
        }
    }
}


/**
 パス衝突検査
 
 パスがHPと交差しないかどうか検査する。
 
 @param[in] turnPath    検査対象ターンパス
 
 @return 交差判定結果
 @retval Intersection::NO　交差なし
 @retval その他            交差あり
 */
int PathValidator::checkIntersectionWithHp(const TurnPath& turnPath) const {
	LOGV(LOG_TAG "::checkIntersectionWithHp", "()");
	int retval = Intersection::NO;
	
	if (turnPath.size() < 3) {
		// 検査対象外
		return retval;
	}
	
	for (auto it = next(turnPath.begin()); it != prev(turnPath.end(), 2); ++it) {
		auto& seg1 = *it;
		auto& seg2 = *next(it);
		
		if (seg1.segmentType == LINESEG) {
			// Line segment
            const LineSegment lseg{seg1.point1(), seg2.point1()};
            retval = checkBoundaryIntersection(lseg, BoundaryType::Kind::Set{BoundaryType::Kind::Mask::EHP});
		} else {
			// arc segment
            const ArcSegment aseg{seg1.point1(), seg2.point1(), seg1.Circ};
            retval = checkBoundaryIntersection(aseg, BoundaryType::Kind::Set{BoundaryType::Kind::Mask::EHP});
		}
		
		if (retval == Intersection::YES) {
			break;
		}
	}

	return retval;
}

/**
EHP進入判定
指定線分がEHPに侵入しているかどうかを検査する。
@param[in] seg 直線セグメント
@retval Intersection::NO　交差なし
@retval その他            交差あり
*/
int PathValidator::checkIntersectionEhp(const LineSegment& seg) const {
    LOGV(LOG_TAG "::checkIntersectionEhp", "(LSG)");

    const auto& whp = boundarySet.whp();
    const auto whpEdges = getEdgeList(whp, whp.cbegin());
    for (const auto& wseg : whpEdges) {
        if (wseg.checkIntersection(seg)) {
            LOGV(LOG_TAG "::checkIntersectionEhp(LSG)", "RESULT: WHP CLEARANCE ERROR:\n%s", Svg::to_path(wseg).c_str());
            return Intersection::YES;
        }
    }
    
    if (isStandIn(boundarySet.whp(), seg)) {
        LOGV(LOG_TAG "::checkIntersectionEhp(LSG)", "RESULT: endpoints within WHP");
        return Intersection::YES;
    }

    return Intersection::NO;
}


/**
 ターンパス存在検査
 
 生成したターンパスが空でないかどうか。空ならば例外を投げる。
 
 @param[in,out] turnPath    検査対象パス
 */
void PathValidator::validateEmpty(const TurnPath& turnPath) const {
	LOGV(LOG_TAG "::validateEmpty", "()");
	
	if (turnPath.empty()) {
		ErrorPathGenerator err(ErrorCode::PathGeneration::PostValidation::FATAL);
		err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] empty turn path.", "::validateEmpty");
		throw err;
	}
}

/**
 作業パス検査

 生成したパスの作業パスを検査する。
    - 長さが足りない場合 ErrorCode::PathGeneration::PostValidation::INCLUDE_SHORT_PATH
    - 作業パスが存在しない場合 ErrorCode::PathGeneration::PostValidation::NO_WORK_SEGMENT
 @param[in,out] outputPathData    検査対象パス
 */
void PathValidator::validateWorkPath(OutPathData& outputPathData) const {
    LOGV(LOG_TAG "::validateWorkPath", "(%d segments)", (int)outputPathData.size());
    
    int workPathCount = 0;
    
    if (gauge.workPath.types == Gauge::WorkPath::Type::COMBINED_SIMPLEX) {
        LOGV(LOG_TAG "::validateWorkPath", "IGNORED");
        // 渦巻き系のとき検査しない
        return;
    }

    for (auto& seg : outputPathData) {
        if (seg.pathAttr == PathParam::Segment::RideType::WORKING) {
            workPathCount++;
            if (seg.length() < gauge.workPath.length.min) {
                ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::PostValidation::INCLUDE_SHORT_PATH);
                err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] too short work path.", "::validateWorkPath");
#ifdef DEBUG_LOG
                LOGE(LOG_TAG "::validateWorkPath", "seg (%s) - (%s) = %g m",
                     to_string(seg.point1(), "").c_str(), to_string(seg.point2(), "").c_str(), seg.length());
#endif // DEBUG_LOG
                err.path.emplace_back(seg);
                throw err;
            }
        }
    }
    
    if (workPathCount == 0) {
        ErrorPathGenerator err(PathFPS{}, PathSPS{}, ErrorCode::PathGeneration::PostValidation::NO_WORK_SEGMENT);
        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] There is no work segment.", "::validateWorkPath");
#ifdef DEBUG_LOG
        LOGE(LOG_TAG "::validateWorkPath", "work path not found.");
#endif // DEBUG_LOG
        throw err;
    }
}

/**
 パス接続ベクトル検査
 
 パス中の各セグメント間の接続検査をする。
 @see validatePointVector(const GenSegment& fromSeg, const GenSegment& toSeg)
 
 @param[in] turnPath    検査対象パス
 */
void PathValidator::validatePointVector(const TurnPath& turnPath) const {
	LOGV(LOG_TAG "::validatePointVector", "(%d segments)", (int)turnPath.size());
    
    auto path = turnPath.getNonredundantData();
    if (path.size() < 2) {
        // ベクトル検査対象外
        return;
    }

    auto fromIt = path.cbegin();
    auto endIt = prev(path.cend());	// 最後のセグメントは始点しかないのでテストしない

    if (traverseInfo.mode == TraverseInfo::Mode::ORBITAL) {
        if (gauge.headland.process == PathPlan::Param::Work::Headland::Process::PRE) {
            validatePointVector(*endIt, traverseInfo.sps.getSegment());
        } else if (gauge.headland.process == PathPlan::Param::Work::Headland::Process::POST) {
            validatePointVector(traverseInfo.fps.getSegment(), *fromIt);
        }
    } else {
        if (traverseInfo.mode != TraverseInfo::Mode::START_NAV) {
            // FPSからターンパス進入点(開始ナビゲーション以外)
            validatePointVector(traverseInfo.fps.getSegment(), *fromIt);
        }
        if (traverseInfo.mode != TraverseInfo::Mode::END_NAV) {
            // ターンパスからSPS脱出点(終了ナビゲーション以外)
            validatePointVector(*endIt, traverseInfo.sps.getSegment());
        }
    }

    // ターンパス内
    for (auto toIt = next(fromIt); toIt != endIt; ++fromIt, ++toIt) {
        validatePointVector(*fromIt, *toIt);
    }
}

/**
パス接続ベクトル検査

パス中の各セグメント間の接続検査をする。
@see validatePointVector(const GenSegment& fromSeg, const GenSegment& toSeg)

@param[in] turnPath    検査対象パス
*/
void PathValidator::validatePointVectorInside(const TurnPath& turnPath) {
    // ターンパス内
    auto path = turnPath.getNonredundantData();
    if (turnPath.size() < 2) {
        // ベクトル検査対象外
        return;
    }
    LOGD(LOG_TAG "::validatePointVectorInside", "TurnPath:\n%s", Svg::to_path(turnPath).c_str());
    auto fromIt = path.cbegin();
    auto endIt = prev(path.cend());    // 最後のセグメントは始点しかないのでテストしない
	for (auto toIt = next(fromIt); toIt != endIt; ++fromIt, ++toIt) {
        LOGD(LOG_TAG "::validatePointVectorInside", "TurnPath[%d]-[%d]", (int)std::distance(path.cbegin(), fromIt), (int)std::distance(path.cbegin(), toIt));
        validatePointVector(*fromIt, *toIt);
	}
}

/**
パス接続ベクトル検査(範囲指定)

指定区間の各セグメント間の接続検査をする。
@see validatePointVector(const GenSegment& fromSeg, const GenSegment& toSeg)

@param[in] beginIt    検査対象開始セグメント
@param[in] endIt        検査対象終端セグメント(これは検査対象に含まない)
*/
void PathValidator::validatePointVector(TurnPath::const_iterator beginIt, TurnPath::const_iterator endIt) {
    LOGV(LOG_TAG "::validatePointVector", "(beginIt, endIt)");

    if (beginIt == endIt) {
        return;
    }
    
    auto fromIt = beginIt;
    for (auto toIt = next(fromIt); toIt != endIt; ++fromIt, ++toIt) {
        validatePointVector(*fromIt, *toIt);
    }
}

void PathValidator::validatePointVector(const LineSegment& eSeg, const TurnPath& turnPath, const LineSegment& lSeg) {
    LOGV(LOG_TAG "::validatePointVector", "(eSeg, turnPath, lSeg)");

    // ターンパス内
    auto path = turnPath.getNonredundantData();
    if (turnPath.size() < 2) {
        // ベクトル検査対象外
        return;
    }
    
    {
        auto firstSeg = path.front();
        LineSegment seg1{firstSeg.enterPoint(), firstSeg.leavePoint()};
        GenSegment gseg0{eSeg};
        validatePointVector(gseg0, firstSeg);
    }
    {
        LineSegment seg0 = path.getLastSegment();
        GenSegment gseg0{seg0};
        GenSegment gseg1{lSeg};
        validatePointVector(seg0, lSeg);
    }
    
    validatePointVectorInside(turnPath);
}

/**
 検査対象セグメント接続ベクトル検査
 
 検査対象セグメントセグメント間の接続検査をする。スムーズに繋がっていない箇所を発見した時点で例外を投げる。
    - 端点が一致し、ベクトルが並行かどうかを検査する。
 @see Segment2D::checkConnection()
 
 @param[in] fromSeg  検査対象セグメント
 @param[in] toSeg    検査対象セグメント
 */
void PathValidator::validatePointVector(const GenSegment& fromSeg, const GenSegment& toSeg) {
//	LOGV(LOG_TAG "::validatePointVector(fromSeg, toSeg)", "");
    LOGV(LOG_TAG "::validatePointVector", "()\n%s\n%s",
         Svg::to_path_d(fromSeg).c_str(), Svg::to_path_d(toSeg).c_str());

    const int retval = fromSeg.checkConnection(toSeg);
    if (!((retval == Segment2D::Connection::SMOOTH) ||  // 直進接続
          ((retval == Segment2D::Connection::REFLECTED) && (fromSeg.direction != toSeg.direction)))) { // バック接続
        const char* errCode = "";
        const char* errDesc = "";
        if (retval == Segment2D::Connection::DISCONNECT) {
            // 繋がっていない
            errCode = ErrorCode::PathGeneration::PostValidation::SEGMENT_DISCONNECTED;
            errDesc = "[EXCEPTION:TURN_GENERATION_ISSUE] segment disconnected.";
            LOGE(LOG_TAG "::validatePointVector", "disconnect segments:\n%s\n%s", to_string(fromSeg, " from").c_str(), to_string(toSeg, " to  ").c_str());
        } else {
            // スムースでない
            errCode = ErrorCode::PathGeneration::PostValidation::CONNECTION_VECTOR_MISMATCH;
            errDesc = "[EXCEPTION:TURN_GENERATION_ISSUE] mismatch a point enter - leave vector.";
            LOGE(LOG_TAG "::validatePointVector", "enter-leave angle %0.7g : %0.7g (cross product:%g, epsilon:%g)\n%s\n%s",
                 Degree::convert(fromSeg.getLeaveVector().getAngle()), Degree::convert(toSeg.getEnterVector().getAngle()),
                 abs(fromSeg.getLeaveVector().getCrossProduct(toSeg.getEnterVector())), std::numeric_limits<float>::epsilon(),
                 Svg::to_path_d(fromSeg).c_str(), Svg::to_path_d(toSeg).c_str());
        }

        ErrorPathGenerator err(errCode);
        err.setDescription(errDesc, "::validatePointVector");
        err.points.push_back(fromSeg.point2());
        err.path.emplace_back(static_cast<LineSegment>(fromSeg));
        err.path.emplace_back(static_cast<LineSegment>(toSeg));
        err.addCircle(fromSeg.Circ);
        err.addCircle(toSeg.Circ);
        throw err;
    }
}

/**
 出力パスデータ検査
 
 OutPathDataの単体の検証。
 - セグメント間の接続のみ
 @param[in,out] turnPath    検査対象パス
 */
void PathValidator::validateOutputPathData(OutPathData& pathdata) {
    if (pathdata.size() < 2) {
        return;
    }

    auto fromIt = pathdata.cbegin();
    // ターンパス内
    for (auto toIt = next(fromIt); toIt != pathdata.cend(); ++fromIt, ++toIt) {
        validatePointVector(*fromIt, *toIt);
    }
}
    
/**
 ターンパス内バック移動検査
 
 ターンパスでバック移動可否に抵触していないかどうかを検査する。抵触していれば例外を投げる。
 
 @param[in,out] turnPath    検査対象パス
 */
void PathValidator::validateWithReverseSegment(const TurnPath& turnPath) const {
	LOGV(LOG_TAG "::validateWithReverseSegment", "(%d)", gauge.implement.canBackward);
	
	if (gauge.permitBackward) {
		// バックが許可されていれば常に有効
		return;
	}
	
	for (auto& pathSeg : turnPath) {
		if (!gauge.implement.canBackward && pathSeg.LineSegment::direction == LineSegment::REVERSE) {
			ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::PostValidation::INCLUDE_BACKWARD);
			err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] path includes reverse segment without backward permission.", "::validateWithReverseSegment");
            err.path.push_back(pathSeg);
			throw err;
		}
	}
}

/**
 ターンパス直線交差検査
 
 ターンパス内のカーブを挟む直線同士が交差するかどうかを検査する。交差を発見した時点で例外を投げる。
    - 接線同士が同一直線上にあり、重なっている場合も交差とする
    - カーブセグメントの長さが0、すなわち接線同士が直接接続している場合は検査対象外とする
 
 @param[in,out] turnPath    検査対象パス
 */
void PathValidator::validateTangents(const TurnPath& turnPath) const {
	LOGV(LOG_TAG "::validateTangents", "()");
	
	for (int i = 1; i < (int)turnPath.size() - 2; i++) {
		if ((turnPath[i].segmentType == ARCSEG) && (turnPath[i - 1].segmentType == LINESEG) && (turnPath[i + 1].segmentType == LINESEG)) {
			LineSegment SG1 = turnPath.getSegment<LineSegment>(i - 1);
            LineSegment AS = turnPath.getSegment<ArcSegment>(i);
			LineSegment SG2 = turnPath.getSegment<LineSegment>(i + 1);
            if (AS.isNull() && SG1.isConnected(SG2)) {
                // カーブ長さ0で接線が直接接続している場合はベクトル検査の担当
                LOGD(LOG_TAG "::validateTangents()", "[INFO] found ignored curve.");
            } else if (SG1.checkIntersection(SG2) == Intersection::YES) {
				ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::PostValidation::TANGENT_CROSS_TANGENT);
				err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] same curve legs were crossed.", "::validateTangents");
                err.path.emplace_back(SG1);
                err.path.emplace_back(SG2);
				throw err;
			}
		}
	}
}

/**
ターンパスセグメント属性チェック
*/
void PathValidator::validateSegmentPropaties(const TurnPath& turnPath) {
    LOGV(LOG_TAG "::validateSegmentPropaties", "()");
#if 0
    for (const auto& seg : turnPath) {
        if (seg.term) {
            continue;
        }
        if (!checkSegmentPropaties(seg)) {
            ErrorPathGenerator err(ErrorCode::PathGeneration::FATAL);
            err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] PATH SEGMENT has invalid propaties.", "::validateSegmentPropaties");
            err.path.emplace_back(seg);
            throw err;
        }
    }
#endif
}

/**
 セグメント単体属性チェック
 */
bool PathValidator::checkSegmentPropaties(const PathSegment& pseg) {
    if (pseg.segmentType == LINESEG) {
        if (pseg.pathAttr.rideType == PathParam::Segment::RideType::WORKING &&
            pseg.turnType != PathParam::Turn::Type::UNDEFINED) {
            LOGE(LOG_TAG "::checkSegmentPropaties", "[ERROR] WORKSEG in TURN PATH: %s", Svg::to_path(pseg).c_str());
            // ターンパス中に作業セグメントは無い
            return false;
        }
    } else if (pseg.segmentType == ARCSEG) {
        if (pseg.pathAttr.rideType == PathParam::Segment::RideType::WORKING) {
            LOGE(LOG_TAG "::checkSegmentPropaties", "[ERROR] WORKSEG in CURVE: %s", Svg::to_path(pseg).c_str());
            // カーブでは作業しない
            return false;
        }
    }
    
    if (pseg.pathAttr.rideType == PathParam::Segment::RideType::NON_WORKING &&
        pseg.turnType == PathParam::Turn::Type::UNDEFINED) {
        LOGE(LOG_TAG "::checkSegmentPropaties", "[ERROR] NON_WORK SEG in NON TURN PATH: %s", Svg::to_path(pseg).c_str());
        // 非作業パスはターンに属している必要がある
        return false;
    }

    return true;
}



}} // namespace yanmar::PathPlan

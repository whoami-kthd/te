// Yanmar Confidential 20200918
/**
 @file PathValidator.hpp
 
 パス検証クラス
 */
#pragma once

#include "PathPlanIF.hpp"
#include "PathPlanConstant.hpp"

#include <vector>

//#include "PathLib.h"
#include "PathGeneratorData.hpp"
#include "PathGeneratorError.hpp"
#include "Gauge.hpp"
#include "Segment.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

/////////////////////////
/**
 パス検証クラス
 
 生成したパスの有効性を検証するクラス
 */
class PathValidator {
	friend class PathGeneratorTest;
    friend class PathGenerator;

    using TurnPath = PathGeneratorData::TurnPath;
    using BoundarySet = PathGeneratorData::BoundarySet;
    using TraverseInfo = PathGeneratorData::TraverseInfo;
    using HLTCList = PathGeneratorData::HLTCList;
    using PathFPS = PathGeneratorData::PathFPS;
    using PathSPS = PathGeneratorData::PathSPS;
    
    static constexpr int SUCCESS = PathGeneratorData::SUCCESS;
    static constexpr int FAILURE = PathGeneratorData::FAILURE;
    static constexpr int VALID = SUCCESS;
    static constexpr int INVALID = FAILURE;

public:
    /// Uターンパスセグメント数
    static constexpr int NUM_OF_U_TURN_SEGMENTS	= 3;
    /// フックターンパスセグメント数
    static constexpr int NUM_OF_HOOK_TURN_SEGMENTS	= 5;
    /// フラットターンパスセグメント数
    static constexpr int NUM_OF_FLAT_TURN_SEGMENTS	= 5;
    /// フィッシュテールターンパスセグメント数
    static constexpr int NUM_OF_FISHTAIL_TURN_SEGMENTS	= 6;

    
	/// パス生成限界パラメータ
    // 
    const Gauge& gauge;
    const TraverseInfo& traverseInfo;
    const HLTCList& HCP;
    const PathGeneratorData::BoundarySet& boundarySet;

    size_t NoBP = 0; // 圃場外形の頂点数(障害物を含まない)
    size_t NoOB = 0; // 障害物の数
    size_t NoOBP = 0; // 全障害物の合計頂点数

    // constructor
    PathValidator() = delete;
    PathValidator(const Gauge& aGauge,
                  const TraverseInfo& aTraverseInfo, const HLTCList& aHLTCList,
                  const BoundarySet& boundarySet) :
        gauge(aGauge), traverseInfo(aTraverseInfo), HCP(aHLTCList),
        boundarySet(boundarySet)
    {}
    
//
//	using Polygon = OutVertexList;
//	using Polygons = vector<Polygon>;


    /// リザルト反転
    static int invertResult(int result) {
        switch(result) {
        case SUCCESS:
            return FAILURE;
            break;
        case FAILURE:
            return SUCCESS;
            break;
        default:
            PGASSERT(false, "invertResult");
            break;
        }

        return result;
    }

    /*
	 * 通常ターンパスバリデーション関数群
	 */
	int checkTurnPath(TurnPath& turnPath, int type) const;
    int checkTurnPath(TurnPath& turnPath) const;
	int checkIntersectionWithHp(const TurnPath& turnPath) const;
	int validateFishtailTurn(TurnPath& turnPath) const;
	int validateHookTurn(TurnPath& turnPath) const;
	int validateUTurn(TurnPath& turnPath) const;
	int validateFlatTurn(TurnPath& turnPath) const;

	/*
	 * ターンパス有効性検査
     * - 失敗時例外を投げる
	 */
	// 存在検査
	void validateEmpty(const TurnPath& turnPath) const;
	// バック移動検査
	void validateWithReverseSegment(const TurnPath& turnPath) const;
	// 頂点はみ出し検査
	void validatePoints(const TurnPath& turnPath) const;
	// 対SHP衝突検査
	void validateIntersectionWithShp(const TurnPath& turnPath) const;
    void validateIntersectionWithShp(TurnPath::const_iterator beginIt, TurnPath::const_iterator endIt) const;
	// カーブ出入口検査
	void validateTangents(const TurnPath& turnPath) const;
    // 作業パス有効性検査
    void validateWorkPath(OutPathData& outPathData) const;
	// パスセグメント接続検査
	void validatePointVector(const TurnPath& turnPath) const;
    static void validatePointVectorInside(const TurnPath& turnPath);
    static void validatePointVector(TurnPath::const_iterator beginIt, TurnPath::const_iterator endIt);
    static void validatePointVector(const LineSegment& eSeg, const TurnPath& turnPath, const LineSegment& lSeg);
    static void validatePointVector(const GenSegment& fromSeg, const GenSegment& toSeg);
    // セグメント属性検査
    static void validateSegmentPropaties(const TurnPath& turnPath);
    static bool checkSegmentPropaties(const PathSegment& pseg);

    static void validateOutputPathData(OutPathData& pathdata);

	// 圃場境界交差検査
    int checkBoundaryIntersection(TurnPath& turnPath, BoundaryType::Kind::Set targetFlag = PathPlan::BoundaryType::Kind::Mask::ALL) const;
    int checkBoundaryIntersection(const LineSegment& SG, BoundaryType::Kind::Set targetFlag = PathPlan::BoundaryType::Kind::Mask::ALL) const;
    int checkBoundaryIntersection(const ArcSegment& SG, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const;
    int checkBoundaryIntersection(const GenSegment& gseg, BoundaryType::Kind::Set targetFlag = BoundaryType::Kind::Mask::ALL) const {
        if (gseg.segmentType == SegmentType::ARCSEG) {
            return checkBoundaryIntersection(static_cast<ArcSegment>(gseg), targetFlag);
        } else {
            return checkBoundaryIntersection(static_cast<LineSegment>(gseg), targetFlag);
        }
    };
    int checkIntersectionEhp(const LineSegment& eTS) const;

    // パスセグメント間交差検査
    int checkIntersection(const OutPathData::value_type& seg, OutPathData::iterator begin, OutPathData::iterator end) const;

    // パスセグメント間交差検査
    int checkIntersection(const TurnPath& turnPath, const std::vector<LineSegment>& seg) const;

    /**
    FPSパス脚長チェック
     */
    bool checkFPSLegLength(const LineSegment& seg) const noexcept {
        const double legLen = seg.length();
        return ((gauge.minFpsLegLength - TOL_ONE_CM) < legLen);
    }

    /**
    SPSパス脚長チェック
     */
    bool checkSPSLegLength(const LineSegment& seg) const noexcept {
        const double legLen = seg.length();
        return ((gauge.minSpsLegLength - TOL_ONE_CM) < legLen);
    }

    /*
	 * デバッグダンプ
	 */
    class ResultString {
    public:
        ResultString(int result) :
            value(result)
        {}
        
        const char* c_str() const {
            return (value == SUCCESS) ? "SUCCESS" : "FAILURE";
        }

        int value = VALID;
    };

    class ValidString {
    public:
        ValidString(int result) :
            value(result)
        {}
        
        const char* c_str() const {
            return (value == VALID) ? "VALID" : "INVALID";
        }
        
        int value = VALID;
    };

	void dumpParam() const;
	void dumpSHP(const char* filename) const;
	void dumpSOHP(const char* filename) const;
	void dumpHCP(const char* filename, const HLTCList& hcp) const;
	void dumpTrnPath(const char* filename) const;
	void dumpBoundary(const char* filename, const vector<Boundary>& boundaries) const;
	void dumpTraverseInfo(const char* filename) const;
};

}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 * @file Segment.cpp
 *
 * PathDataクラスのデータクラス群
 */

//#define DEBUG_LOG
#define LOG_TAG "PathPlan:Segment"

#include "PolyLib/Common.h"
#include "Segment.hpp"

#include <cstdlib>
#include <string>
#include <stdexcept>
#include <iostream>
#include <ostream>

#include "PathLib.h"
#include "PathPlanConstant.hpp"
#include "Geometry/Geometry.hpp"

using namespace std;

using namespace yanmar::PathPlan::Param::Path;
using namespace yanmar::PathPlan::SegmentDir;
using namespace yanmar::PathPlan::DataType;
using namespace yanmar::PathPlan::SegmentType;
using namespace yanmar::PathPlan::VertexType;
using namespace yanmar::PathPlan::RotateDirection;

namespace yanmar { namespace PathPlan {

// static object
const XY_Point XY_Point::nullobj{0.0, 0.0};


#pragma mark - Segment2D

/**
 接続判定
 
 自セグメントのpoin2から指定セグメントのpoint1への接続状態を返す。
    - 端点の接続に関しては完全一致のみ。
    - 接続角度には単位ベクトルでの外積に対する許容差 TOL_CONNECTION_CP がある。
        - セグメントの角度によって実質の許容量が異なるが、微小な値なので無視する。
        - 水平または垂直のときが最も寛容、45度のときがその1/sqrt(2)になる。
          この差が問題になるように大きな値にしないこと。
 
 @see TOL_CONNECTION_CP

 @return 接続状態
 @retval Connection::DISCONNECT     端点が繋がっていない
 @retval Connection::ANGLED         接続しているが接続点でのベクトルが不一致(角がある)
 @retval Connection::REFLECTED      接続しているが接続点でのベクトルが逆向き(前進/後退が切り替わる)
 @retval Connection::SMOOTH         接続しており接続点でのベクトルが一致(角が無い)
 */
int Segment2D::checkConnection(const Segment2D& seg) const noexcept {
	
	if (!isConnected(seg)) {
		// 繋がっていない
		return Connection::DISCONNECT;
	}
	
	if (isNegrective() || seg.isNegrective()) {
		// 長さが0ならばベクトルが定義できないので常にSMOOTH
		return Connection::SMOOTH;
	}

    const Vector2D fromVec = getLeaveVector();
    const Vector2D toVec = seg.getEnterVector();
    if (fromVec.isParallel(toVec, TOL_CONNECTION_CP)) {
		// 接続されていて並行
		const double dot = fromVec.getDotProduct(toVec);
		// 平行であることは既知なので反対かどうかだけでよい
		if (dot < 0) {
			// 反対向き
			return Connection::REFLECTED;
		} else {
			// 同方向
			return Connection::SMOOTH;
		}
	} else {
		// 接続されているが平行でない
		return Connection::ANGLED;
	}
}


#pragma mark - LineSegment

/**
 点と直線の距離
 
 指定の点と直線の距離を返す。
 - 点と線分の距離ではない。点と直線への垂線の交点(足)がLineSegmentの線分の範囲内かどうかは考慮しない。
 - LineSegmentの長さが0の場合は端点との距離を返す
 
 @param[in] p 対象点
 @return 距離
 */
double LineSegment::distance(const XY_Point& p) const {
	const XY_Point& sgPoint1 = point1();
	const XY_Point& sgPoint2 = point2();
	const XY_Point diff21 = sgPoint2 - sgPoint1;
	const double len = length();
	double dist = 0.0;
	if (len == 0.0) {
		// 線分の長さが0のときは端点との距離
		dist = p.distance(sgPoint1);
	} else {
		// 点と直線の距離公式
		dist = abs(diff21.y * p.x - diff21.x * p.y + sgPoint2.x * sgPoint1.y - sgPoint2.y * sgPoint1.x) / len;
	}
	
	return dist;
}

/**
 セグメント延長(前方)
 
 直線セグメントを前方(point1()側)に指定長だけ延長する。
	- 負の長さを与えると長さが縮む。ただし、0未満にはならない。
 
 @param[in] extLen 延長する長さ
 @return 延長後の自分への参照
 */
LineSegment& LineSegment::extendHead(double extLen) {
	LOGV(LOG_TAG ":LineSegment", "extendHead(%g)", extLen);
    if (isNegrective()) {
        return *this;
    }
	const double curLen = length();
	
	// 長さが負になることはできない
	if ((curLen + extLen) <= 0) {
		point1() = point2();
		return *this;
	}

	XY_Point diff = point1() - point2();
	LOGV(LOG_TAG, "[LS(ORG)] (%g, %g) - (%g, %g)", point1().x, point1().y, point2().x, point2().y);
	point1() = point2() + diff * Vector2D(1.0 + (extLen / curLen));
	LOGV(LOG_TAG, "[LS(ext)] (%g, %g) - (%g, %g)", point1().x, point1().y, point2().x, point2().y);

	return *this;
}

/**
 セグメント延長(後方)
 
 直線セグメントを後方(point2()側)に指定長だけ延長する。
	- 負の長さを与えると長さが縮む。ただし、0未満にはならない。
 
 @param[in] extLen 延長する長さ
 @return 延長後の自分への参照
 */
LineSegment& LineSegment::extendTail(double extLen) {
	LOGV(LOG_TAG ":LineSegment", "extendTail(%g)", extLen);
    if (isNegrective()) {
        return *this;
    }
    const double curLen = length();

	// 長さが負になることはできない
	if ((curLen + extLen) <= 0.0) {
		point2() = point1();
		return *this;
	}

	XY_Point diff = point2() - point1();
	LOGV(LOG_TAG, "[LS(ORG)] (%g, %g) - (%g, %g)", point1().x, point1().y, point2().x, point2().y);
	point2() = point1() + diff * Vector2D(1.0 + (extLen / curLen));
	LOGV(LOG_TAG, "[LS(ext)] (%g, %g) - (%g, %g)", point1().x, point1().y, point2().x, point2().y);

	return *this;
}

/**
 セグメント延長(両方)
 直線セグメント両端を指定長だけ延長する。
 - 負の長さを与えると長さが縮む方向に端点を移動する。この移動範囲は延長後の反対側の端点を超えない。
    - 即ち、長さは0未満にはならないが端点が元の線分内とは限らない。
    - 両方から縮めた場合に長さが0になる場合は、端点は互いの縮める量の比率で線分を分割した点になる。
 @param[in] extHeadLen 先頭を延長する長さ
 @param[in] extTailLen 末尾を延長する長さ
 @return 延長後の自分への参照
 */
LineSegment& LineSegment::extendBoth(double extHeadLen, double extTailLen) {
    LOGV(LOG_TAG ":LineSegment", "extendBoth(%g, %g)", extHeadLen, extTailLen);
    if (isNegrective()) {
        return *this;
    }
    LOGV(LOG_TAG, "[LS(ORG)] %s", to_string(*this).c_str());
    const double curLen = length();
    const double afterLen = curLen + extHeadLen + extTailLen;
    if (0.0 < afterLen) {
        shiftEnterPointHeadward(extHeadLen);
        shiftLeavePointTailward(extTailLen);
    } else {
        // 長さが0になる場合
        if (0.0 <= extHeadLen) {
            // 片方が伸びる時は伸びた場所
            shiftEnterPointHeadward(extHeadLen);
            leavePoint() = enterPoint();
        } else if (0.0 <= extTailLen) {
            // 片方が伸びる時は伸びた場所
            shiftLeavePointTailward(extTailLen);
            enterPoint() = leavePoint();
        } else {
            // 両方から縮む時は互いの比率の内分点
            const double d = curLen * extHeadLen / std::abs(extHeadLen + extTailLen);
            shiftEnterPointHeadward(d);
            leavePoint() = enterPoint();
        }
    }
  
    LOGV(LOG_TAG, "[LS(ext)] %s", to_string(*this).c_str());
    return *this;
}

/**
シフト
ベクトル指定のシフト
@param[in] vec シフトベクトル
@return シフト後の自分への参照
*/
LineSegment& LineSegment::shift(const Vector2D& vec) noexcept {
    enterPoint() += vec;
    leavePoint() += vec;
    
    return *this;
}

/**
 シフト
 ベクトル・量指定のシフト
 @param[in] vec シフトベクトル
 @param[in] val シフト量
 @return シフト後の自分への参照
 */
LineSegment& LineSegment::shift(Vector2D vec, double val) {
    const double length = vec.getLength();
    if (length != 0.0)
    {
        vec *= Vector2D{val / vec.getLength()};
        shift(vec);
    }
    
    return *this;
}

/**
 接線検査
 
 接線であるこのLineSegmentが接線対象のターンサークルの回転方向に対して順方向か逆方向かを返す
 - 接線でない場合正しい結果を返さない場合がある。
 
 @param[in] C 接線対象のターンサークル
 @return 検査結果
 @retval SegmentDir::FORWARD 回転方向である
 @retval SegmentDir::REVERSE 逆向きである
 */
int LineSegment::checkTangent(const Circle& C) const {
	/*
	 TS : Tangent on the circle
	 C : Circle
	 */
	
	// x,y axis componet of vectors
	XY_Point A = point1() - C.center;
	XY_Point B = point2() - C.center;
	
	// dirction of cross product of A and B vector
	/*
	 dir =1 : anti-clockwise
	 dir =-1 : clockwise
	 */
	int dir = (int) ((A.x * B.y - A.y * B.x) / fabs(A.x * B.y - A.y * B.x));
	if (dir == C.orient) {
		return SegmentDir::FORWARD; // Circle rotation and Tangent dirction are same
	} else {
		return SegmentDir::REVERSE; // Circle rotation and Tangent dirction are not same
	}
}

/**
 交差判定
 
 @overload
 @param[in] SG	検査する直線セグメント

 @return 交差判定結果
 @retval Intersection::YES 交差あり
 @retval その他 交差あり
 */
int LineSegment::checkIntersection(const LineSegment& SG) const {
	LOGV(LOG_TAG, "LineSegment - checkIntersection with LineSegment");
    int retval = Intersection::NO;
	
    const auto v1 = getVector();
    const auto v2 = SG.getVector();
    const double det = v2.getCrossProduct(v1);
    Vector2D v3{point1(), SG.point1()};
	if (isIsometric(det, 0, 0.0001)) {
        // 二つの線分が平行なとき
        if (checkIntersection(SG.point1()) != Intersection::NO ||
            checkIntersection(SG.point2()) != Intersection::NO) {
            retval = Intersection::YES;
        }
	} else {
        const double t1 = v2.getCrossProduct(v3);
		if (signbit(t1) == signbit(det) && abs(t1) <= abs(det)) {
            const double t2 = v1.getCrossProduct(v3);
            if (signbit(t2) == signbit(det) && abs(t2) <= abs(det)) {
				// Line segment intersects
				retval = Intersection::YES;
			}
        }
	}

    return retval;
}

/**
 交差判定
 
 点との交差判定、即ちPntがLineSegment上にあるかどうか。
 - 端点と一致する場合は交差する
 
 @overload
 @param[in] p 対象の点
 
 @return 判定結果
 @retval Intersection::NO 交差なし
 @retval その他 交差あり
 */
int LineSegment::checkIntersection(const XY_Point& p) const {
    LOGV(LOG_TAG "::LineSegment::checkIntersection(p)", "");
    const bool aside = isAside(p, numeric_limits<float>::epsilon());
    return (aside) ? Intersection::YES : Intersection::NO;
}

/**
 並近接判定
 
 点pとの鉛直距離がrange未満かどうかを返す。
    - LineSegmentにpを通る垂線(脚)が存在しない場合は偽を返す
    - pが端点と一致する場合は真を返す
 
 @overload
 @param[in] p       対象の点
 @param[in] range   判定距離

 @return 判定結果
 @retval true   range未満
 @retval false  range以上
 */
bool LineSegment::isAside(const XY_Point& p, double range) const {
    LOGV(LOG_TAG "::LineSegment::isAside", "(p, range = %g)", range);
    const double d = distance(p);
    return ((d == 0.0 || d < range) && isAside(p));
}

/**
 近接判定(距離のみ)
 
 点pとの距離がraneg未満かどうかを返す。
    - 点がLineSegmentに対して脚を持たない場合も対象(端点からの距離)
 
 @overload
 @param[in] p       対象の点
 @param[in] range   判定距離
 
 @return 判定結果
 @retval true   range未満
 @retval false  range以上
 */
bool LineSegment::isNearBy(const XY_Point& p, double range) const {
    LOGV(LOG_TAG "::LineSegment::isNearBy", "(p, range = %g)", range);
    const double d = distance(p);
    return isIsometric(d, 0.0, range);
}

#pragma mark - ArcSegment

/**
 交差判定
 
 対象LineSegmentとの交差があるかどうかを返す
 
 @overload
 @param[in] LineSG 検査するセグメント

 @return 交差判定結果
 @retval Intersection::NO 交差なし
 @retval その他 交差あり
 */
int ArcSegment::checkIntersection(const LineSegment& LineSG) const {
    LOGV(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "\nASG: %s vs LSG: %s", to_string(*this).c_str(), to_string(LineSG).c_str());

	// Intesection flg
	int IntrsctnFlg = Intersection::NO;
	
    const auto& sgPoint1 = LineSG.point1();
    const auto& sgPoint2 = LineSG.point2();

    // Line segmentが長さ0.0ではないか?
    double sgLength = LineSG.length();
    if (LineSG.isNegrective()) {
        LOGV(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "LineSegment length is 0.0.");
        return checkIntersection(sgPoint1);
    }
    
    // Arc gement自身の長さが0ではないか?
    if (isNegrective()) {
        LOGV(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "Arc length is 0.0.");
        return LineSG.checkIntersection(Circ.center);
    }

    Vector2D sgVec{sgPoint1, sgPoint2};
    
	// Point on Line form circle center through perpendicular
	// 1.中心座標と半径、線分の端点座標から以下の距離が求まる
	//  LnDist 線分の長さ
	//  PerDist 中心と中心から直線への垂線の交点(足)の距離
	//  tmpD1, tmpD2 中心と線分の端点の距離
	// 2.以上の距離と三平方の定理から以下の距離が求まる
	//  tmpLD1, tmpLD2 足と線分の端点の距離
	//  tmpPD1, tmpPD2 線分の端点と直線と円の交点の距離
	// 3.以上の比率により線分の端点を直線に沿って移動すると座標が求まる
	//  PerPnt 足の座標
	//  crossPoint1, crossPoint2 円と直線の交点座標
	// 4.交点が円弧の終点・始点の間にあるかどうか判定する

	// tmpD1 = Distance between circle center and line segment first point
	double tmpD1 = sgPoint1.distance(Circ.center);
	
	// tmpD2 = Distance between circle center and line segment second point
	double tmpD2 = sgPoint2.distance(Circ.center);


	// Perpendicular distance between arcsegment center and line
	double PerDist = LineSG.distance(Circ.center);
	
	// Distance between perpendicular point and segment first point
	double tmpLD1 = leg(tmpD1, PerDist);
	// Distance between perpendicular point and segment second point
	double tmpLD2 = leg(tmpD2, PerDist);
	
	//Point on Line form circle center through perpendicular
	XY_Point PerPnt;
    double tmpPD1 = 0.0;
    double tmpPD2 = 0.0;
	const double legPC = leg(Circ.radius, PerDist);
	const Vector2D tmpDL{tmpD1 / sgLength};
	if ((tmpLD1 <= sgLength) && (tmpLD2 <= sgLength)) {
		PerPnt = sgPoint1 + sgVec * tmpDL;
		// distance from Line segment point1 to of intersection point1
		tmpPD1 = tmpLD1 - legPC;
		// distance from Line segment point1 to of intersection point2
		tmpPD2 = tmpLD1 + legPC;
	} else {
		if (tmpLD1 > tmpLD2) {
			PerPnt = sgPoint1 + sgVec * tmpDL;
			// distance from Line segment point1 to intersection point1
			tmpPD1 = tmpLD1 - legPC;
			// distance from Line segment point1 to intersection point2
			tmpPD2 = tmpLD1 + legPC;
		} else {
			PerPnt = sgPoint1 - sgVec * tmpDL;
			// distance from Line segment point1 to of intersection point1
			tmpPD1 = -tmpLD1 - legPC;
			// distance from Line segment point1 to of intersection point2
			tmpPD2 = -tmpLD1 + legPC;
		}
	}
	
//    LOGV(LOG_TAG ":ArcSegment", "PerPnt(%g, %g), sgLength:%g, tmpD1:%g, tmpD2:%g, tmpPD1:%g, tmpPD2:%g, tmpLD1:%g, tmpLD2:%g", PerPnt.x, PerPnt.y, sgLength, tmpD1, tmpD2, tmpPD1, tmpPD2, tmpLD1, tmpLD2);
	if (PerDist <= Circ.radius) {
		// Line segment intersects circle.
		if (isIsometric(PerDist, Circ.radius)) {
			// tangent to circle
			if ((tmpLD1 < sgLength) && (tmpLD2 < sgLength)) {
				// 足がセグメントの範囲内にある
				const XY_Point crossPoint = sgPoint1 + sgVec * Vector2D(tmpPD1 / sgLength);
                PPASSERT(isIsometric(Circ.center.distance(crossPoint), Circ.radius), ErrorCode::FATAL);
				if (checkIntersection(crossPoint) == Intersection::YES) {
                    LOGV(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "INTRESECTION: crossPoint(%g, %g)", crossPoint.x, crossPoint.y);
					IntrsctnFlg = Intersection::YES;
				}
			}
		} else {
			// Secant
			// An intersection point
			if (isInRangeClose(-TOL_ZERO_PNT_ONE_CM, tmpPD1, (sgLength + TOL_ZERO_PNT_ONE_CM))) {
				const XY_Point crossPoint1 = sgPoint1 + sgVec * Vector2D(tmpPD1 / sgLength);
//              LOGE(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "INTRESECTION: crossPoint2(%.15g, %.15g) d:%.15g: R:%.15g", crossPoint2.x, crossPoint2.y, Circ.center.distance(crossPoint1), Circ.radius);
                PPASSERT(isIsometric(Circ.center.distance(crossPoint1), Circ.radius, TOL_ZERO_PNT_ONE_CM), ErrorCode::FATAL);
				if (checkIntersection(crossPoint1) == Intersection::YES) {
                    LOGV(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "INTRESECTION: crossPoint1(%g, %g)", crossPoint1.x, crossPoint1.y);
					IntrsctnFlg = Intersection::YES;
				}
			}

			// Another intersection point
			if (IntrsctnFlg == Intersection::NO &&
                isInRangeClose(-TOL_ZERO_PNT_ONE_CM, tmpPD2, (sgLength + TOL_ZERO_PNT_ONE_CM))) {
				const XY_Point crossPoint2 = sgPoint1 + sgVec * Vector2D(tmpPD2 / sgLength);
//              LOGE(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "INTRESECTION: crossPoint2(%.15g, %.15g) d:%.15g: R:%.15g", crossPoint2.x, crossPoint2.y, Circ.center.distance(crossPoint2), Circ.radius);
                PPASSERT(isIsometric(Circ.center.distance(crossPoint2), Circ.radius, TOL_ZERO_PNT_ONE_CM), ErrorCode::FATAL);   // 1.0E-6未満の誤差は再現済み。floatのepsilonでは足りない。
				if (checkIntersection(crossPoint2) == Intersection::YES) {
                    LOGV(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "INTRESECTION: crossPoint2(%g, %g)", crossPoint2.x, crossPoint2.y);
					IntrsctnFlg = Intersection::YES;
				}
			}
		}
	} else {
		// None of intersection.
		LOGV(LOG_TAG "::ArcSegment::checkIntersection(LSG)", "NO INTRESECTION");
	}

	return IntrsctnFlg;
}

/**
 交差判定

 円弧どうしの交差判定
	- 端点が円周上に無いArcSegmentは不正であり、正しい結果を返さない。

 @note この関数は2円の半径が異なる場合もサポートする必要がある。
 @overload
 @param[in] CircSG 検査対象のArcSegment

 @return 交差判定結果
 @retval Intersection::NO 交差なし
 @retval その他 交差あり
 */
int ArcSegment::checkIntersection(const ArcSegment& CircSG) const {
	LOGV(LOG_TAG "::ArcSegment::checkIntersection", "(ArcSeg)");
	using namespace PathPlan;

	const double tmpDst = CircSG.Circ.center.distance(Circ.center);
	if ((Circ.radius + CircSG.Circ.radius) < tmpDst) {
		// 中心が半径の合計より離れている = 円が重なっていない
		return Intersection::NO;
	}

	if (CircSG.isNegrective() || isIsometric(CircSG.Circ.radius, 0.0)) {
		// 相手が点とみなせる
		if (isNegrective() || isIsometric(Circ.radius, 0.0)) {
			// 自分も点とみなせる
			return Circ.center.isIsolocation(CircSG.Circ.center) ? Intersection::YES : Intersection::NO;
		} else {
			// 点との交差
			return checkIntersection(CircSG.Circ.center);
		}
	}
	
	// 交差があるかもしれない
	int IntrsctnFlg = Intersection::NO;
	if (isIsometric(tmpDst, 0.0) && isIsometric(Circ.radius, CircSG.Circ.radius)) {
		// both circle coincide
		// 同一円上にある場合は端点の範囲チェックで済む
		const XY_Point& p1 = CircSG.point1();
		const XY_Point& p2 = CircSG.point2();
		if (isInSight(p1) || isInSight(p2)) {
			// Segments intersects
			// 相手のどちらかの端点が範囲内にある
			IntrsctnFlg = Intersection::YES;
		}
	} else {
		// 2円の交差条件(接する場合を除く)
		//  中心が互いの外側にある: abs(R1 - R2) < dist
		//  中心1が円2の内側にある、すなわち(R1 < R2): R2 < dist + R1 = R2 - R1 < dist
		//  但し、R2 > R1 によりabs(R1 - R2) < distと等価
		//  従って abs(R1 - R2) < dist 一つで良い。
		// 接する場合は上記が等しい、つまり
		//  外側に在りて接する: R1 + R2 = dist
		//  内側に在りて接する: abs(R1 - R2) = dist
		if (isIsometric((Circ.radius + CircSG.Circ.radius), tmpDst) || isIsometric(abs(Circ.radius - CircSG.Circ.radius), abs(tmpDst)))	{
			// 接している:
			// 大円から小円の中心方向のベクトル
			const Vector2D vec = (Circ.radius < CircSG.Circ.radius) ? Vector2D{CircSG.Circ.center, Circ.center} : Vector2D{Circ.center, CircSG.Circ.center};
			// 接点: 小円の中心をvecに沿って大円の半径まで移動
			const XY_Point p = Circ.center + vec * Vector2D{Circ.radius / tmpDst};
			// check if point is on both arcs
			LOGD(LOG_TAG, "Circles are just touch at (%g, %g): (%g, %g) R:%g - (%g, %g) R:%g, dist:%g", p.x, p.y, Circ.center.x, Circ.center.y, Circ.radius, CircSG.Circ.center.x, CircSG.Circ.center.y, CircSG.Circ.radius, tmpDst);
			if (isInSight(p) && CircSG.isInSight(p)) {
				// Segments intersects
				IntrsctnFlg = Intersection::YES;
			}
		} else if (abs(Circ.radius - CircSG.Circ.radius) < tmpDst)	{
			// 交差がある:
			// 交点2点の角度
			std::pair<double, double> cAngles = Circ.getIntersectAngles(CircSG.Circ);
			const double ftAngle = Vector2D{Circ.center}.getAngleTo(CircSG.Circ.center);
			const double tfAngle = Vector2D{CircSG.Circ.center}.getAngleTo(Circ.center);
			// いずれかの点(角度)が両円弧の範囲かどうか
			LOGD(LOG_TAG, " intersecs point angles: th1:%g, th2:%g", cAngles.first, cAngles.second);
			if ((isInSightAngle(normalize(-M_PI, M_PI, 2 * M_PI, (tfAngle + cAngles.first))) && CircSG.isInSightAngle(normalize(-M_PI, M_PI, 2 * M_PI, (ftAngle - cAngles.second)))) ||
				(isInSightAngle(normalize(-M_PI, M_PI, 2 * M_PI, (tfAngle - cAngles.first))) && CircSG.isInSightAngle(normalize(-M_PI, M_PI, 2 * M_PI, (ftAngle + cAngles.second))))) {
				// Segments intersects
				IntrsctnFlg = Intersection::YES;
			}
		} else {
			// 交差が無い
			// 事前に処理済み
		}
	}

	return IntrsctnFlg;
}

/**
 交差判定
 
 円弧と点との交差判定
 - 点が円周上かつ始点・終点間にあるかどうかを返す。
 
 @overload
 @param[in] point 対象の点

 @return 交差判定結果
 @retval Intersection::YES 交差あり
 @retval Intersection::NO 交差なし

 @see isInSight()
 */
int ArcSegment::checkIntersection(const XY_Point& point) const {
	
	int retval = Intersection::NO;
	
	const double distance = point.distance(Circ.center);
	if (isIsometric(Circ.radius, distance) && isInSight(point)) {
		retval = Intersection::YES;
	}
	
	return retval;
}

/**
 半径設定
 
 半径を設定し、始点・終点を再計算する。
 
 @param[in] newRadius 新しい半径
 
 @return 自分自身の参照
 */
ArcSegment& ArcSegment::setRadius(double newRadius) {
    const double diffRadius = (newRadius - Circ.radius);
    Circ.radius = newRadius;

    LineSegment tmp1{Circ.center, point1()};
    tmp1.extendTail(diffRadius);
    point1() = tmp1.point2();

    LineSegment tmp2{Circ.center, point2()};
    tmp2.extendTail(diffRadius);
    point2() = tmp2.point2();
    
    return *this;
}


#pragma mark - GenSegment
/// nullオブジェクト
const GenSegment GenSegment::nullobj = GenSegment{};


#pragma mark - WorkPath
    
/**
 サイドエッジパス判定
 
 サイドマージン辺に脱出またはサイドマージン辺から進入しているかどうか
 
 @retval true サイドエッジである
 @retval false サイドエッジではない
 */
bool WorkPath::isSideEdgePath() const {
    return (angleToEdge < Radian::convert(10.0));
}

/**
 パス方向計算
 
 開始点から終了点へのy軸が増加方向か減少方向かを求めてdirに保存する。
 算出後のdirの値を返す。
	- 作業パスFPS、SPSはどちらもターン側がhead(point1)で、(通常ターンの)FPS/SPSで FPS.dir == SPS.dir が真になるようになっている。
	- 作業パスはY軸平行が前提。パスが長さが0、もしくはx軸に平行な場合は考慮しない。

 @attention  歴史的経緯によりFPS上のトラクターのy軸移動方向がdirと一致する。y座標値 y1 < y2 の増減方向とは逆である。
 
 @return dirの値{1 , -1}
 @retval ASCEND (1) 増加方向
 @retval DESCEND (-1) 減少方向
 */
int WorkPath::Dir() {
	const double y1 = point1().y;
	const double y2 = point2().y;
	dir = (y1 < y2) ? DESCEND : ASCEND;
	return dir;
}

/**
 前脚設定(出入口ターンサークルまでの距離)
 
 point1側に脚を設定する。
 @warning パス計算(Y軸平行)しか考慮していない
 
 @param[in] length ターンサークルまでの距離
 */
void WorkPath::setHeadLeg(double length) {
	if (dir != 0) {
		foot.x = point1().x;
		foot.y = point1().y + dir * length;
        Circ.center.y = foot.y;
	}
}

/**
 前脚長保証
 point1側の脚の最低長を保証する
 @warning パス脚が設定済みである必要がある
 @return 設定後のパス脚長
*/
double WorkPath::ensureMinimalHeadLegLength() {
    
    double legLen = getHeadLeg().length();
    const double minLen = leg.minLength;
    if (legLen < minLen) {
        LOGD(LOG_TAG "::ensureMinimalHeadLegLength()", "HEAD LEG LENGTH: %g -> %g", legLen, minLen);
        extended = false;
        legLen = minLen;
        setHeadLeg(legLen);
    }
    
    return legLen;
}

/**
 出口ターンサークル配置(FPS用)

 このパスのパス出口側のターンサークルを指定の回転方向で配置する。ターンパス生成時のFPS側用。
 - パスに対してターンサークルの回転方向が枕地周回方向に従うように配置する。

 @param[in] rotation 枕地周回方向
 @param[in] radius サークル半径
 */
void WorkPath::setLeaveTurnCircle(int rotation, double radius) {
	Circ.orient = rotation;
	Circ.center.x = foot.x + -dir * Circ.orient * radius;
	Circ.center.y = foot.y;
	Circ.radius = radius;
}
	
/**
 入口ターンサークル配置(SPS用)

 このパスの入口側のターンサークルを指定の回転方向で配置する。ターンパス生成時のSPS側用。
 - パスに対してターンサークルの回転方向が枕地周回方向に従うように配置する。
 
 @param[in] rotation 枕地周回方向
 @param[in] radius サークル半径
 */
void WorkPath::setEnterTurnCircle(int rotation, double radius) {
	Circ.orient = rotation;
	Circ.center.x = foot.x + dir * Circ.orient * radius;
	Circ.center.y = foot.y;
	Circ.radius = radius;
}

/**
 補助ターンサークル取得(固定幅)
 
 パスの出入口ターンサークルとの間でフィッシュテールが構成できるターンサールを返す。(出入り口ターンのコンパクション用)
 - 現在、パスターンサークルの中心位置(x軸)をパス上に移動したものを返す。サークルの回転方向は同じ。
 
 @return 補助ターンサークル
 */
Circle WorkPath::getAuxTurnCircle() const {
	Circle aux{Circ};
	// 単純だが半径の距離で凡そ最適解
    if (0.0 < auxCircle.distance) {
        aux.center.x += dirX(foot, Circ.center) * (auxCircle.distance);
    } else {
        aux.center.x = foot.x;
    }
	
	return aux;
}

/**
 パスターンサークル再配置
 
 現在のターンサークルを逆位置に配置し直す。
 */
void WorkPath::alternateTurnCircle() {
	Circ.orient = -Circ.orient;
	Circ.center.x = foot.x + (foot.x - Circ.center.x);
}

void WorkPath::dump(const char* filename) const {
#ifdef DEBUG_LOG
	LOGD(LOG_TAG ":dump", "[%s] (%g, %g) - (%g, %g)", filename, point1().x, point1().y, point2().x, point2().y);
#endif // DEBUG_LOG

#ifdef TXT_FILE_ENABLE
	ofstream ofile;
	ofile.open(filename);
	ofile << ss << point1().x << "\t" << point1().y << "\t" << point2().x << "\t" << point2() << endl;
	ofile.close();
#endif // TXT_FILE_ENABLE
}


#pragma mark - PathSegment
/// nullオブジェクト
const PathSegment PathSegment::nullobj = PathSegment{};

PathSegment::PathSegment(const PathGeneratorData::PathFPS& fps) :
    GenSegment(fps.getSegment()),
    status(VALID),
    term(true),
    pathAttr(PathAttr::RideType::WORKING)
{
}

PathSegment::PathSegment(const PathGeneratorData::PathSPS& sps) :
    GenSegment(sps.getSegment()),
    status(VALID),
    term(true),
    pathAttr(PathAttr::RideType::WORKING)
{
}


#pragma mark - PathSegmentAB
/**
 ABパス構築用クラス
 */
PathSegmentAB::PathSegmentAB(const tData& st, const tData& ed) :
    OutPathSegment(LineSegment{st.point(), ed.point()})
{
    pathAttr.rideType = Param::Path::Segment::RideType::WORKING;
    turnType = Param::Path::Turn::Type::STRAIGHT;
}


#pragma mark - Boundary
/// nullオブジェクト
const Boundary Boundary::nullobj = Boundary{};


#pragma mark - functions

/**
共線上位置関係判定
同一直線上にある2線分の位置関係を返す
@param[in] seg0  基準セグメント
@param[in] point  対象点
@return 位置関係。InlinePos を参照
*/
unsigned int inlinePosition(const LineSegment& seg, const XY_Point& point) {
    int retval = 0;

    auto dp0 = seg.getDotProductFrom(point);
    retval |= (unsigned int)std::signbit(dp0);
    retval <<= 1;
    auto dp1 = seg.getDotProductTo(point);
    retval |= (unsigned int)std::signbit(-dp1);
    
    return retval;
}

unsigned int inlinePosition(const XY_Point& point, const LineSegment& seg) {
    int retval = 0;

    retval |= (unsigned int)std::signbit(-seg.getDotProductFrom(point));
    retval <<= 1;
    retval |= (unsigned int)std::signbit(seg.getDotProductTo(point));
    
    return retval;
}

/**
共線上位置関係判定
同一直線上にある2線分の位置関係を返す
@param[in] seg0  基準セグメント
@param[in] seg1  対象セグメント
@return 位置関係。InlinePos を参照
*/
unsigned int inlinePosition(const LineSegment& seg0, const LineSegment& seg1) {
    int retval = 0;

    if (!seg0.isNegrective()) {
        retval |= inlinePosition(seg0, seg1.enterPoint());
        retval <<= 4;
        retval |= inlinePosition(seg0, seg1.leavePoint());
    } else if (!seg1.isNegrective()) {
        retval |= inlinePosition(seg0.enterPoint(), seg1);
        retval <<= 4;
        retval |= inlinePosition(seg0.leavePoint(), seg1);
    } else {
        retval = InlinePos::UNDEFINED;
    }
    
    return retval;
}

/**
 ポリゴン内外判定
 
 指定の点がポリゴンの内側かどうかを返す。
 - ポリゴンの辺は外側と判定する
 
 @param[in] polygon 対象ポリゴン
 @param[in] p 判定する点
 
 @retval true 内側
 @retval false 外側
 */
bool within(const std::vector<XY_Point>& polygon, const XY_Point& p) {
	namespace bg = boost::geometry;
	namespace bgm = boost::geometry::model;
	using BgVertex = bgm::d2::point_xy<double>;
	using BgPolygon = bgm::polygon<BgVertex, true, false>;
	using BgBox = bgm::box<BgVertex>;

	BgPolygon pp;
	for (auto v : polygon) {
		pp.outer().push_back(v);
	}
	
	BgBox bb;
	bg::envelope(pp, bb);
	
	BgVertex v{p.x, p.y};
	return (bg::within(v, bb) && bg::within(v, pp));
}

/**
 ポリゴン内外判定
 
 指定セグメントの両端点がポリゴンの内側かどうかを返す。
 - ポリゴンの辺は外側と判定する
 
 @param[in] polygon 対象ポリゴン
 @param[in] seg 判定するセグメント
 
 @retval true 内側
 @retval false 外側
 */
bool isStandIn(const std::vector<XY_Point>& polygon, const LineSegment& seg) {
	return (within(polygon, seg.point1()) || within(polygon, seg.point2()));
}

/**
 最近傍点検索
 点のリスト内の基準点に最も近い要素のイテレータを返す。
 @param[in] points  点のリスト
 @param[in] p0      基準点

 @reurn 結果の要素を指すイテレータ
 @retval cend() 要素が存在しない
 */
std::vector<XY_Point>::const_iterator findNearest(const std::vector<XY_Point>& points, const XY_Point& p0) {
    auto minIt = points.cend();
    double minD = 0.0;
    for (auto it = points.cbegin(); it != points.cend(); ++it) {
        auto p = *it;
        double d = p0.distance(p);
        if (minIt == points.cend() || d < minD) {
            minIt = it;
            minD = d;
        }
    }
    
    return minIt;
}

/**
 交差点取得(線分対線分)
 
 LineSegments同士の交差点を求めて結果を返す。
 - 交差が無い場合、pも変更しない
 
 @param[in] 対象線分1
 @param[in] 対象線分2
 @param[in, out] p 交差点を格納する XY_Point
 
 @retval true 交差する
 @retval false 交差しない
 */
bool intersection(const LineSegment& ls1, const LineSegment& ls2, XY_Point& p) {
	namespace bg = boost::geometry;
	namespace bgm = boost::geometry::model;
	using BgVertex = bgm::d2::point_xy<double>;
	using BgSegment = bgm::segment<BgVertex>;
	
	std::vector<BgVertex> output;
	BgSegment bs1{BgVertex{ls1.point1().x, ls1.point1().y}, BgVertex{ls1.point2().x, ls1.point2().y}};
	BgSegment bs2{BgVertex{ls2.point1().x, ls2.point1().y}, BgVertex{ls2.point2().x, ls2.point2().y}};
	bg::intersection(bs1, bs2, output);	// このintersection()の戻り値は無意味

	const bool retval = !output.empty();
	if (retval) {
		p = XY_Point{output.front()};
	}
	
	return retval;
}
	
/**
 接線算出(同回転方向)
 
 2円の接線を求めてTangentPairで返す。
	- 2円の中心間を結ぶ線分を平行移動したものである
    - C1の半径は0より大きいこと
 
 @note 片方の円が片方の内側にあったりしてはいけない。
 @note TODO: 三角関数なしで可能なはずである
 
 @param[in] C1 円1
 @param[in] C2 円2
 
 @return 2接線の入ったTangentPairインスタンス
 */
TangentPair getTangentsParalleled(const Circle &C1, const Circle &C2) {
	LOGV(LOG_TAG "::getTangentsParalleled", "(C,C)");
	
    if (isIsometric(C1.radius, 0.0) && isIsometric(C2.radius, 0.0) ) {
        // 両方の半径が0ならば中心間の直線である
        return TangentPair{{C1.center, C2.center}, {C1.center, C2.center}};
    }
    
	LineSegment FTS, STS;
	// length of the tangent
	const double d1 = leg(C2.distance(C1), (C1.radius - C2.radius));
	
	double alp1, alp2;
	if (C1.radius > C2.radius) {
		// when circle C1 radius is more than C2
		alp1 = atan(d1 / (C1.radius - C2.radius));
		alp2 = M_PI - alp1;
	} else {
		alp1 = (M_PI / 2) + atan((C2.radius - C1.radius) / d1);
		alp2 = M_PI - alp1;
	}
	
	const double t1 = sqrt((pow(C1.radius, 2) * C2.distance2(C1)) / C2.distance2(C1));
	const double t2 = sqrt((pow(C2.radius, 2) * C2.distance2(C1)) / C2.distance2(C1));
	
	const double x1t = C1.center.x + (C2.center.x - C1.center.x) * t1;
	const double y1t = C1.center.y + (C2.center.y - C1.center.y) * t1;
	
	const double x2t = C2.center.x + (C1.center.x - C2.center.x) * t2;
	const double y2t = C2.center.y + (C1.center.y - C2.center.y) * t2;
	
	const double th1 = atan2((y1t - C1.center.y), (x1t - C1.center.x));
	const double th2 = atan2((y2t - C2.center.y), (x2t - C2.center.x));
	
	// Tangents cordinates
	FTS.point1().x = C1.center.x + C1.radius * cos(th1 + alp1);
	FTS.point1().y = C1.center.y + C1.radius * sin(th1 + alp1);
	
	STS.point1().x = C1.center.x + C1.radius * cos(th1 - alp1);
	STS.point1().y = C1.center.y + C1.radius * sin(th1 - alp1);
	
	FTS.point2().x = C2.center.x + C2.radius * cos(th2 - alp2);
	FTS.point2().y = C2.center.y + C2.radius * sin(th2 - alp2);
	
	STS.point2().x = C2.center.x + C2.radius * cos(th2 + alp2);
	STS.point2().y = C2.center.y + C2.radius * sin(th2 + alp2);
	
	return TangentPair{FTS, STS};
}

/**
 接線算出(逆回転方向)
 
 2円の接線を求めてTangentPairで返す。
 - 現在のところ2円の半径は同じ長さであることを要求する
 
 @note 2円が交差していたり、片方の内側にあったりしてはいけない。接するのは可。
 
 @param[in] C1 円1
 @param[in] C2 円2
 
 @return 2接線の入ったTangentPairインスタンス
 */
TangentPair getTangentsCrossed(const Circle &C1, const Circle &C2) {
	LOGV(LOG_TAG "::getTangentsCrossed", "(C,C)");

	LineSegment FTS, STS;
	const double d = C2.distance(C1);

	const XY_Point center1 = C1.center;
	const XY_Point center2 = C2.center;
	const XY_Point delta = center2 - center1;

	//to check equality condition
	if (isIsometric(d, (C1.radius + C2.radius))) {
		// 2円が接しているとき、接線は点である。
		const double rRacio = (C1.radius / (C1.radius + C2.radius));
		const XY_Point pos = {center1 + delta * Vector2D{rRacio}};
		FTS.point1() =
		FTS.point2() =
		STS.point1() =
		STS.point2() = pos;
		
		return TangentPair{FTS, STS};
	}

	// 二つの円が重なっている場合は処理できない
	if (d < (C1.radius + C2.radius)) {
		throw runtime_error("cross tangent unavailable.");
	}

	const double d1 = d * C1.radius / (C1.radius + C2.radius);
	const double d2 = d - d1;

	double alp = atan2(leg(d1, C1.radius), C1.radius);
	if (std::isfinite(alp)) {
		alp = normalizeInc(0.0, (2 * M_PI), alp);
	} else {
		// fail-safe 2円が交差している場合 d1 < C1.radius になって、sqrtがNaNを返す->alpもNaNになる。
		throw runtime_error("cross tangent unavailable.");
	}
	
	XY_Point pp1 = center1 + delta * XY_Point(C1.radius / d);
	pp1 -= center1;
	const double th10 = Vector2D(pp1).getAngle();
	const double th11 = normalizeInc(0.0, (2 * M_PI), th10);

	const double th12 = normalizeInc(0.0, (2 * M_PI), th11 + alp);
	const double th13 = normalizeInc(0.0, (2 * M_PI), th11 - alp);

	const XY_Point point11 = center1 + XY_Point(C1.radius) * XY_Point(cos(th12), sin(th12));
	const XY_Point point12 = center1 + XY_Point(C1.radius) * XY_Point(cos(th13), sin(th13));

	XY_Point pp2 = center1 + delta * XY_Point((d - C2.radius) / d);
	pp2 -= center2;
	const double th20 = Vector2D(pp2).getAngle();
	const double th21 = normalizeInc(0.0, (2 * M_PI), th20);

	const double th22 = normalizeInc(0.0, (2 * M_PI), th21 + alp);
	const double th23 = normalizeInc(0.0, (2 * M_PI), th21 - alp);

	const XY_Point point21 = center2 + XY_Point(C2.radius) * XY_Point(cos(th22), sin(th22));
	const XY_Point point22 = center2 + XY_Point(C2.radius) * XY_Point(cos(th23), sin(th23));

	const double dd1 = leg(d1, C1.radius) + leg(d2, C2.radius);
	const double dd2 = point11.distance(point21);

	// Cordinates of tangents
	if (abs(dd1 - dd2) < TOL_ZERO_PNT_ONE_CM) {
		FTS.point1() = point11;
		FTS.point2() = point21;
		STS.point1() = point12;
		STS.point2() = point22;
	} else {
		FTS.point1() = point11;
		FTS.point2() = point22;
		STS.point1() = point12;
		STS.point2() = point21;
	}

	return TangentPair{FTS, STS};
}

/**
 2円間の接線計算
 
 二つのCircle間の接線を求める。
 - 2円間の接線は二つ引けるため、第1円の進入点によりどちらかを決定する。
 - 2円が完全に重なっている場合は接線が定義できないため進入点位置の長さ0の接線を返す。
 - directionは接線のターンサークルに対する接続向きである。結果の接線上のトラクターの移動向き(前進/後退)LineSegment::directionはここでは考慮しない。(常にFORWARD)
 
 @param[in] enterPos 出発円に対する進入点
 @param[in] currCirc 接線の出発円
 @param[in] nextCirc 接線の行先円
 @param[in] direction 接線接続方向フラグ
 - SegmentDir::FORWARD: 順方向
 - SegmentDir::REVERSE: 逆方向
 
 @return 接線セグメント
 */
PathSegment getTangent(const LineSegment& eTS, const Circle& currCirc, const Circle& nextCirc, int direction) {
    
    const XY_Point& enterPos = eTS.point2();
    PathSegment TS{enterPos, enterPos};
    
    // 完全に重なっている場合、長さ0のセグメントを返す
    if (isIsometric(currCirc.center, nextCirc.center)) {
        LOGD(LOG_TAG "::getTangent", "[INFO] 0 length tangent; %s", to_string(TS, " TS:").c_str());
        TS.validate();
        return TS;
    }

    // 回転方向が逆で重なっている
    if (currCirc.checkIntersection(nextCirc) && (currCirc.orient != nextCirc.orient)) {
        LOGD(LOG_TAG "::getTangent", "[INFO] There's no valid tangent");
        // 無効なセグメントを返す
        TS.invalidate();
        return TS;
    }
    
    // Tangents between circles
    TangentPair tangents = getTangents(currCirc, nextCirc);
    LineSegment& FTS = tangents.first;
    LineSegment& STS = tangents.second;
    
    // point on circle C1
    // Tangent points on C1
    XY_Point Pnt1_FTS = FTS.point1();
    XY_Point Pnt1_STS = STS.point1();
    
    // Next point on the circle from point Pnt
    const int PntOnCirc = currCirc.isNextPoint(enterPos, Pnt1_FTS, Pnt1_STS);
    
    const int ChkTangent1 = FTS.checkTangent(currCirc);
    const int ChkTangent2 = STS.checkTangent(currCirc);
    
    if ((PntOnCirc == Circle::NextPoint::FIRST) && (ChkTangent1 == direction)) {
        // FTS is the tangent: 前のもの(FTS)が向き一致
        TS = PathSegment{FTS, PathSegment::VALID};
    } else if ((PntOnCirc == Circle::NextPoint::FIRST) && (ChkTangent1 != direction) && (ChkTangent2 == direction)) {
        // STS is the tangent: 前のもの(FTS)の向きが不一致、STSが向き一致。
        TS = PathSegment{STS, PathSegment::VALID};
    } else if ((PntOnCirc == Circle::NextPoint::SECOND) && (ChkTangent2 == direction)) {
        // STS is the tangent: 前のもの(STS)が向き一致
        TS = PathSegment{STS, PathSegment::VALID};
    } else if ((PntOnCirc == Circle::NextPoint::SECOND) && (ChkTangent2 != direction) && (ChkTangent1 == direction)) {
        // FTS is the tangent: 前のもの(STS)の向きが不一致、FTSが向き一致。
        TS = PathSegment{FTS, PathSegment::VALID};
    } else if (FTS.point1() == FTS.point2() && FTS.point1() == FTS.point2()) {
        // just touch at point: 2円が接している
        TS = PathSegment{FTS, PathSegment::VALID};
    } else {
        if (LineSegment{FTS.point2(), FTS.point1()}.checkTangent(nextCirc) != direction) {
            TS = PathSegment{FTS, PathSegment::VALID};
        } else if (LineSegment{STS.point2(), STS.point1()}.checkTangent(nextCirc) != direction) {
            TS = PathSegment{STS, PathSegment::VALID};
        } else {
            LOGD(LOG_TAG "::getTangent", "Could not found any valid tangent.");
        }
    }

    if (TS.isValid() && eTS.checkIntersection(TS)) {
        if (tryUnite(eTS, TS)) {
            LOGV(LOG_TAG "::getTangent", "Collinear Enter - Leave tangent.");
            TS.validate();
        } else {
            LOGD(LOG_TAG "::getTangent", "[INFO] INVALID: Enter - Leave tangent intersected.\n %s\n %s", to_string(eTS, "eTS:").c_str(), to_string(TS, " TS:").c_str());
            TS.invalidate();
        }
    }

    return TS;
}

/**
 2円間の接線計算
 
 二つのCircle間の接線を求める。
 - 2円間の接線は二つ引けるため、向きによってどちらかを決定する。
 - 2円が完全に重なっている場合は接線が定義できないためcurrCircの中心の長さ0の無効なパスセグメントを返す。
 - directionは接線のターンサークルに対する接続向きである。結果の接線上のトラクターの移動向き(前進/後退)LineSegment::directionはここでは考慮しない。(常にFORWARD)
 
 @param[in] currCirc 接線の出発円
 @param[in] nextCirc 接線の行先円
 @param[in] direction 接線接続方向フラグ
 - SegmentDir::FORWARD: 順方向
 - SegmentDir::REVERSE: 逆方向
 
 @return 接線パスセグメント
 */
PathSegment getTangent(const Circle &currCirc, const Circle &nextCirc, int direction) {
    PathSegment TS{};
    
    // 完全に重なっているか、または回転方向が逆で重なっている
    if (isIsometric(currCirc.center, nextCirc.center) ||
        (currCirc.checkIntersection(nextCirc) && currCirc.orient != nextCirc.orient)) {
        // 無効なセグメントを返す
        TS.invalidate();
        return TS;
    }
    
    const TangentPair tangents = getTangents(currCirc, nextCirc);
    const Vector2D refV{currCirc.center, nextCirc.center};
    if (tangents.first.checkTangent(nextCirc) == direction) {
        TS = PathSegment{tangents.first};
        TS.validate();
    } else if (tangents.second.checkTangent(nextCirc) == direction) {
        TS = PathSegment{tangents.second};
        TS.validate();
    }
    
    return TS;
}

/**
 2円間の接線取得
 
 2円間に存在する2接線を返す。
 - 取得に失敗したら例外を投げる (ErrorCode::PathGeneration::TANGENT_UNAVAILABLE)
 
 @param[in] C1 円1
 @param[in] C2 円2
 @return 2接線の入ったTangentPairインスタンス
 */
TangentPair getTangents(const Circle &C1, const Circle &C2) {
    TangentPair tangents;
    try {
        if (C1.orient == C2.orient || isIsometric(C2.radius, 0.0)) {
            //common tangent
            tangents = getTangentsParalleled(C1, C2);
        } else if (isIsometric(C1.radius, 0.0)) {
            //common tangent
            tangents = getTangentsParalleled(C2, C1);
            tangents.first.exchange();
            tangents.second.exchange();
        } else {
            //cross tangent (二つの円の回転方向が逆の時)
            tangents = getTangentsCrossed(C1, C2);
        }
    } catch (...) {
        ErrorPathGenerator err{ErrorCode::PathGeneration::TANGENT_UNAVAILABLE};
        err.setDescription("[EXCEPTION:TURN_GENERATION_ISSUE] tangent unavailable.", "::getTangents");
        err.addCircle(C1);
        err.addCircle(C2);
        throw err;
    }
    
    return tangents;
}

/**
 円点間の接線取得
 
 円に接し指定点で終わる2接線を返す。
 - 取得に失敗したら例外を投げる (ErrorCode::PathGeneration::TANGENT_UNAVAILABLE)
 
 @param[in] C1      開始円
 @param[in] dstPos  目標点
 @return 2接線の入ったTangentPairインスタンス
 */
TangentPair getTangents(const Circle &C1, const XY_Point &dstPos) {
    Circle C2{C1};
    C2.center = dstPos;
    C2.radius = 0.0;
    return getTangentsParalleled(C1, C2);
}

/**
 点円間の接線取得
 
 点から始まり円の接点で終わる2接線を返す。
 - 取得に失敗したら例外を投げる (ErrorCode::PathGeneration::TANGENT_UNAVAILABLE)
 
 @param[in] srcPos  開始点
 @param[in] C2      目標円
 @return 2接線の入ったTangentPairインスタンス
 */
TangentPair getTangents(const XY_Point& srcPos, const Circle& C2) {
    Circle C1{C2};
    C1.center = srcPos;
    C1.radius = 0.0;
    return getTangentsParalleled(C1, C2);
}

/**
 点円間の接線取得
 
 点から始まり円の接点で終わる接線を返す。
 - 接線は二つ引けるため、向きの指定によってどちらかを決定する。
 - 2円が完全に重なっている場合は接線が定義できないためcurrCircの中心の長さ0の無効なパスセグメントを返す。
 - directionは接線のターンサークルに対する接続向きである。結果の接線上のトラクターの移動向き(前進/後退)LineSegment::directionはここでは考慮しない。(常にFORWARD)
 
 @param[in] currCirc 接線の出発円
 @param[in] nextCirc 接線の行先円
 @param[in] direction 接線接続方向フラグ
     @arg SegmentDir::FORWARD: 順方向
     @arg SegmentDir::REVERSE: 逆方向
 
 @return 接線パスセグメント
 */
PathSegment getTangent(const XY_Point& enterPos, const Circle& nextCirc, int direction) {
    PathSegment TS{LineSegment{enterPos, enterPos}};
    
    // 点が円に接している
    if (nextCirc.isContact(enterPos)) {
        // 長さ0のセグメントを返す
        TS.validate();
        return TS;
    }
    
    // 点が円に重なっている
    if (nextCirc.checkIntersection(enterPos)) {
        // 無効なセグメントを返す
        TS.invalidate();
        return TS;
    }
    
    // 円の半径が0
    if (isIsometric(nextCirc.radius, 0.0)) {
        // 点と円の中心の直線セグメントを返す
        TS = PathSegment{enterPos, nextCirc.center};
        TS.validate();
        return TS;
    }
    
    // 接線を求める
    TangentPair tangents = getTangents(enterPos, nextCirc);
    
    if (tangents.first.checkTangent(nextCirc) == direction) {
        TS = PathSegment{tangents.first};
        TS.validate();
    } else if (tangents.second.checkTangent(nextCirc) == direction) {
        TS = PathSegment{tangents.second};
        TS.validate();
    }
    
    return TS;
}

/**
 接線取得

 円currCircに進入するベクトルlVecを持ち長さlengthの接線セグメントを返す。

 @param[in] lVec currCircへの進入ベクトル
 @param[in] currCirc 進入する円
 @param[in] length 線分の長さ
 @return 接線セグメント
 */
LineSegment getTangent(const Vector2D& lVec, const Circle& currCirc, double length) {
    LineSegment lseg{currCirc.center, lVec, length};
    return getCollateralSegment(lseg, currCirc.orient * currCirc.radius);
}

/**
 接線取得

 円currCircから脱出するベクトルlVecを持ち長さlengthの接線セグメントを返す。

 @param[in] currCirc 脱出する円
 @param[in] lVec currCircへの進入ベクトル
 @param[in] length 線分の長さ
 @return 接線セグメント
 */
LineSegment getTangent(const Circle& currCirc, const Vector2D& lVec, double length) {
    LineSegment lseg{lVec, currCirc.center, length};
    return getCollateralSegment(lseg, -currCirc.orient * currCirc.radius);
}

/**
 接線の向き取得
 
 2円と進入点から有効な接線の向きを返す
 - 2円間の距離は考慮しない
 
 @note 幾何学的には進入点の位置に依存して半周ずつRESVERSE/FORWARDであるが、実際のパスでは不正な方向となる場合が存在する。
 現在の方法は幾分か考慮した結果を返している。完全な決定は現在のこの関数(の引数)では出来ない。
 
 @param[in] enterPoint currCirc上の進入点
 @param[in] currCirc 円1
 @param[in] nextCirc 円2
 @return 接線の向き
 @arg TangentDir::FORWARD 順方向接線
 @arg TangentDir::REVERSE 逆方向接線
 */
int getTangentDirection(const XY_Point& enterPoint, const Circle& currCirc, const Circle& nextCirc) {
    return (nextCirc.distance(enterPoint) < currCirc.distance(enterPoint)) ? TangentDir::REVERSE : TangentDir::FORWARD;
}

#if 0
/**
 接線算出(円対点)
 
 ターンサークルから目標点への接線を求める
 
 @param[in] srcPoint ターンサークルの進入点(接線の開始点ではない)
 @param[in] C1 対象のターンサークル
 @param[in] dstPoint 接線の終点
 @return 接線 LineSegment
 */
LineSegment getTangent(const XY_Point& srcPoint, const Circle &C1, const XY_Point& dstPoint) {
	LOGV(LOG_TAG "::getTangent", "(src(%g, %g), C(%g, %g), dst(%g, %g))", srcPoint.x, srcPoint.y, C1.center.x, C1.center.y, dstPoint.x, dstPoint.y);

	LineSegment tangentSG{C1.getCenter(), dstPoint};
	Vector2D leaveVec = dstPoint - C1.getCenter();
	double thLeave = leaveVec.getAngle();
	double thT1 = thLeave + (M_PI / 2);
	double thT2 = thLeave - (M_PI / 2);
	Vector2D enterVec = srcPoint - C1.getCenter();
	double thEnter = enterVec.getAngle();

	int PntOnCirc = C1.isNextAngle(thEnter, thT1, thT2);
	LOGD(LOG_TAG "::getTangent", "Enter:%g T1:%g, T2:%g, orient:%d", DEGREE.convert(thEnter), DEGREE.convert(thT1), DEGREE.convert(thT2), C1.orient);
	if (PntOnCirc == Circle::NextPoint::FIRST) {
		LOGD(LOG_TAG "::getTangent", "SELECT T1");
		tangentSG.point1() = C1.getCenter() + XY_Point(C1.radius) * XY_Point(cos(thT1), sin(thT1));
	} else if (PntOnCirc == Circle::NextPoint::SECOND) {
		LOGD(LOG_TAG "::getTangent", "SELECT T2");
		tangentSG.point1() = C1.getCenter() + XY_Point(C1.radius) * XY_Point(cos(thT2), sin(thT2));
	}

	LOGD(LOG_TAG "::getTangent", "%s", to_string(tangentSG, "TG:").c_str());
	return tangentSG;
}

/**
 接線算出(点対円)
 
 ターンサークルから目標点への接線を求める
 
 @param[in] srcPoint ターンサークルの進入点(接線の開始点ではない)
 @param[in] C1 対象のターンサークル
 @param[in] dstPoint 接線の終点
 @return 接線 LineSegment
 */
LineSegment getTangent(const XY_Point& srcPoint, const Circle &C1) {
    LOGV(LOG_TAG "::getTangent", "(src(%g, %g), C(%g, %g))", srcPoint.x, srcPoint.y, C1.center.x, C1.center.y, dstPoint.x, dstPoint.y);
    
    LineSegment tangentSG{C1.getCenter(), dstPoint};
    Vector2D leaveVec = dstPoint - C1.getCenter();
    double thLeave = leaveVec.getAngle();
    double thT1 = thLeave + (M_PI / 2);
    double thT2 = thLeave - (M_PI / 2);
    Vector2D enterVec = srcPoint - C1.getCenter();
    double thEnter = enterVec.getAngle();
    
    int PntOnCirc = C1.isNextAngle(thEnter, thT1, thT2);
    LOGD(LOG_TAG "::getTangent", "Enter:%g T1:%g, T2:%g, orient:%d", DEGREE.convert(thEnter), DEGREE.convert(thT1), DEGREE.convert(thT2), C1.orient);
    if (PntOnCirc == Circle::NextPoint::FIRST) {
        LOGD(LOG_TAG "::getTangent", "SELECT T1");
        tangentSG.point1() = C1.getCenter() + XY_Point(C1.radius) * XY_Point(cos(thT1), sin(thT1));
    } else if (PntOnCirc == Circle::NextPoint::SECOND) {
        LOGD(LOG_TAG "::getTangent", "SELECT T2");
        tangentSG.point1() = C1.getCenter() + XY_Point(C1.radius) * XY_Point(cos(thT2), sin(thT2));
    }
    
    LOGD(LOG_TAG "::getTangent", "%s", to_string(tangentSG, "TG:").c_str());
    return tangentSG;
}
#endif // commentout

/**
 ターンサークルフリップ
 
 ターンサークルを与えられた2接線に接するもう一つの位置に移動し、処理結果を返す。
 - 進入接線の進入点、脱出する接線の脱出点も調整する。
 - 次の場合は調整対象外
     - 2接線に交差が無い。
     - 2接線の交点が進入接線の中央よりも遠い。(前のターンサークルよりも遠くへフリップする)
 
 @param[in, out] currCirc 移動するターンサークル
 @param[in, out] enterLine currCircに進入する接線
 @param[in, out] leaveLine currCircから脱出する接線
 
 @return 処理結果
 @retval true		移動した
 @retval false	移動しなかった
 */
bool flipTurnCircle(Circle& currCirc, LineSegment& enterLine, LineSegment& leaveLine) {
    LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "");
    
    LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "[INPUT]");
    LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "circle:    %s", to_string(currCirc).c_str());
    LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "enterLine: %s", to_string(enterLine).c_str());
    LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "leaveLine: %s", to_string(leaveLine).c_str());
    LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "enter/leave pos distance: %g / %g", currCirc.distance(enterLine.point2()), currCirc.distance(leaveLine.point1()));
    
    if (enterLine.isNegrective()) {
        LOGV(LOG_TAG "::flipTurnCircle", "[NOT FLIPPED] 0 enterline.");
        return false;
    }
    
    XY_Point p;
    const bool retval = intersection(enterLine, leaveLine, p);
    const Vector2D enterVec{enterLine.point2(), p};
    const Vector2D leaveVec{leaveLine.point1(), p};
    LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "enter/leave seg length: %g / %g", enterLine.length(), leaveLine.length());
    LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "enter/leave xpos length: %g / %g", leaveVec.getLength(), enterVec.getLength());
    if (retval &&
        (enterVec.getLength() < enterLine.length() / 2) &&
        (leaveVec.getLength() < leaveLine.length() / 2)) {
        // フリップしたとき、接線が反転する距離はフリップ禁止
        // ターンサークル移動
        Vector2D moveVec{currCirc.center, p};
        currCirc.center = p + moveVec;
        currCirc.orient = -currCirc.orient;
        // 進入接線の調整
        enterLine.point2() = p + enterVec;
        // 脱出接線の調整
        leaveLine.point1() = p + leaveVec;
        
        LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "[FLIPPED]");
        LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "circle:    %s", to_string(currCirc).c_str());
        LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "enterLine: %s", to_string(enterLine).c_str());
        LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "leaveLine: %s", to_string(leaveLine).c_str());
        LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "enter/leave pos distance: %g / %g", currCirc.distance(enterLine.point2()), currCirc.distance(enterLine.point1()));
    } else {
        LOGV(LOG_TAG "::flipTurnCircle(C,T,T)", "[NOT FLIPPED]");
    }
    
    return retval;
}

/**
 線分接続
 指定の2線分を直線とみなして交点を求め、2線分をその交点で接続する。
 - 線分の方向と接続点の位置を問わない。
 - 接続に失敗した場合はfalseを返す
 @param[in] eSeg    進入辺
 @param[in] lSeg    脱出辺
 @return 処理結果
 */
bool connectAny(LineSegment& eSeg, LineSegment& lSeg) {
    
    const int connection = eSeg.checkConnection(lSeg);
    if (isInline(eSeg, lSeg) &&
        (connection == Line::Connection::SMOOTH || connection == Line::Connection::REFLECTED)) {
        LOGD(LOG_TAG "::Segment", "BENDCONNECT:\n<path d=\"\n%s%s\n\"/>\n",
                  Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());

        return true;
    }
    
    XY_Point px;
    try {
        px = getCrossPoint(eSeg, lSeg);
    } catch (...) {
        LOGE(LOG_TAG "::Segment", "CONNECT ERROR PARALLEL:\n<path d=\"\n%s%s\n\"/>\n",
                  Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
        return false;
    }
    eSeg.leavePoint() = px;
    lSeg.enterPoint() = px;
    
    return true;
}

/**
 線分接続
 指定の2線分を直線とみなして交点を求め、2線分をその交点で接続する。
 - 接続後に線分のベクトルが変化しないように接続する。すなわち進入辺の始点の後方、脱出辺の終点の前方での交差は行わない
 - 接続に失敗した場合はfalseを返す
 @param[in] eSeg    進入辺
 @param[in] lSeg    脱出辺
 @return 処理結果
 */
bool connectForward(LineSegment& eSeg, LineSegment& lSeg) {
    
    if (isInline(eSeg, lSeg) && eSeg.checkConnection(lSeg) == Line::Connection::REFLECTED) {
        LOGD(LOG_TAG "::Segment", "BENDCONNECT:\n<path d=\"\n%s%s\n\"/>\n",
                  Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());

        return true;
    }
    
    const auto eVec1 = eSeg.getEnterVector();
    const auto lVec1 = lSeg.getLeaveVector();
    XY_Point px;
    try {
        px = getCrossPoint(eSeg, lSeg);
    } catch (...) {
        return false;
    }
    Vector2D eVec2{eSeg.enterPoint(), px};
    Vector2D lVec2{px, lSeg.leavePoint()};
    // 線分の元のベクトルと始点から交点までのベクトルの向きを比較する。
    const auto eDp = eVec1.getDotProduct(eVec2);
    const auto lDp = lVec1.getDotProduct(lVec2);
    const bool retval = (0.0 < eDp) && (0.0 < lDp);
    if (retval) {
        eSeg.leavePoint() = px;
        lSeg.enterPoint() = px;
    } else {
        LOGD(LOG_TAG "::Segment", "UNABLE TO CONNECT:\n<path d=\"\n%s%s\n\"/>\n",
             Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
    }
    
    return retval;
}

/**
 線分接続(進入)
 指定の2線分を直線とみなした交点で接続し、結果を返す。
 - eSegの前方(出口側)で接続する。入口側で接続する場合は失敗する。
 @param[in] eSeg    進入辺
 @param[in] lSeg    対象辺
 @return 処理結果
 */
bool connectEntering(LineSegment& eSeg, LineSegment& lSeg) {
    XY_Point px;
    try {
        px = getCrossPoint(eSeg, lSeg);
    } catch (...) {
        return false;
    }
    auto exDist = eSeg.enterPoint().distance(px);
    auto lxDist = eSeg.leavePoint().distance(px);
    const bool retval = (lxDist <= exDist);
    if (retval) {
        eSeg.leavePoint() = lSeg.enterPoint() = px;
    } else {
        LOGD(LOG_TAG "::Segment", "UNABLE TO CONNECT as entering:\n<path d=\"\n%s%s\n\"/>\n",
             Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
    }
    
    return retval;
}

/**
 線分接続(脱出)
 指定の2線分を直線とみなした交点で接続し、結果を返す。
 - lSegの後方(入口側)で接続する。出口側で接続する場合は失敗する。
 @param[in] eSeg    対象辺
 @param[in] lSeg    脱出辺
 @return 処理結果
 */
bool connectLeaving(LineSegment& eSeg, LineSegment& lSeg) {
    XY_Point px;
    try {
        px = getCrossPoint(eSeg, lSeg);
    } catch (...) {
        return false;
    }
    auto exDist = lSeg.enterPoint().distance(px);
    auto lxDist = lSeg.leavePoint().distance(px);
    const bool retval = (exDist <= lxDist);
    if (retval) {
        eSeg.leavePoint() = lSeg.enterPoint() = px;
    } else {
        LOGD(LOG_TAG "Segment", "UNABLE TO CONNECT as leaving:\n<path d=\"\n%s%s\n\"/>\n",
             Svg::to_path_d(eSeg).c_str(), Svg::to_path_d(lSeg).c_str());
    }
    
    return retval;
}

/**
コーナー接続(リスト)
指定の線分リストの線分間を全てconnectAny()で接続する。
- 始点・終点は接続しないが、端点がコーナーに揃うように、先頭・末尾に辺を追加して処理する。
@param[in] edgeList    対象辺のリスト
@param[in] orgEdgeCount  一周の要素数
@return 処理結果
*/
bool joinCorner(vector<PathSegment>& edgeList, int orgEdgeCount) {
    if (edgeList.size() < 3) {
        return false;
    }

    // 始点・終点をコーナーまで伸ばしておくため、先頭・末尾に辺を追加して処理する。
    auto its = edgeList.cbegin();
    its = std::next(its, orgEdgeCount - 1);
    auto ite = edgeList.cend();
    ite = std::prev(ite, orgEdgeCount);
    vector<PathSegment> tmpList;
    tmpList.push_back(*its);
    tmpList.insert(tmpList.cend(), edgeList.cbegin(), edgeList.cend());
    tmpList.push_back(*ite);

    // 接続
    if (!joinCorner(tmpList)) {
        return false;
    }
    
    // 書き戻す
    edgeList = std::move(tmpList);
    // 追加した辺を削除する
    edgeList.pop_back();
    edgeList.erase(edgeList.cbegin());

    return true;
}

/**
 先端揃え
 segの進入点を変更して長さを揃える。
 @param[in] refSeg  参照セグメント
 @param[in] seg         進入点を揃えるセグメント
 @return 処理結果
 @retval true 始点を変更した
 @retval false 変更しなかった
 */
 bool justifyHead(const LineSegment& refSeg, LineSegment& seg) noexcept {
    bool retval = false;
    try {
        XY_Point px = getCrossPoint(refSeg, seg);
        auto dx = px.distance(refSeg.leavePoint());
        seg.enterPoint() = px;
        seg.extendHead(-dx);
        retval = true;
    } catch(...) {
        LOGD("::justifyHead", "[WARN] parallel segs have no cross.");
        // NOP
    }
    
    try {
        if (!retval) {
            auto lVec = refSeg.getLeaveVector();
            LineSegment oSeg{refSeg.leavePoint(), lVec.getOrthogonal(1), 1.0};
            seg.enterPoint() = getCrossPoint(oSeg, seg);
            retval = true;
        }
    } catch(...) {
        LOGD("::justifyHead", "[WARN] segs have no cross.");
        // NOP
    }
    
    return retval;
}

/**
 末尾揃え
 脱出点を変更して長さを揃える。
 @param[in] refSeg  参照セグメント
 @param[in] seg         脱出点を揃えるセグメント
 @return 処理結果
 @retval true 終点を変更した
 @retval false 変更しなかった
 */
bool justifyTail(const LineSegment& refSeg, LineSegment& seg) noexcept {
    bool retval = false;
    try {
        XY_Point px = getCrossPoint(refSeg, seg);
        auto dx = px.distance(refSeg.enterPoint());
        seg.leavePoint() = px;
        seg.extendTail(-dx);
        retval = true;
    } catch(...) {
        LOGD("::justifyTail", "[WARN] parallel segs have no cross.");
        // NOP
    }
    
    try {
        if (!retval) {
            auto lVec = refSeg.getEnterVector();
            LineSegment oSeg{refSeg.enterPoint(), lVec.getOrthogonal(1), 1.0};
            seg.leavePoint() = getCrossPoint(oSeg, seg);
            retval = true;
        }
    } catch(...) {
        LOGD("::justifyTail", "[WARN] segs have no cross.");
        // NOP
    }
    
    return retval;
}

/**
 ポリゴンの指定頂点から1周分の辺のリストを得る
 */
vector<LineSegment> getEdgeList(const vector<XY_Point>& polygon, const vector<XY_Point>::const_iterator& startIt) {
    vector<LineSegment> edgeList;
    const size_t size = polygon.size();
    auto it = startIt;
    
    for (size_t i = 0; i < size; i++) {
        auto it1 = nextCyclic(polygon, it);
        edgeList.emplace_back(*it, *it1);
        it = it1;
    }
    
    return edgeList;
}

#pragma mark - デバッグ用ダンプ関数
/**
 境界データダンプ
 
 境界ポリゴンBoundaryの配列をダンプする
 */
void dumpBoundary(const char* filename, const vector<Boundary>& boundaries) {
#ifdef TXT_FILE_ENABLE
    ofstream myfile;
    OutputDataStream os;
    for (Boundary boundary : boundaries) {
        os  << boundary.BP << ", "
            << boundary.HP << ", "
            << boundary.SHP << EOL;
    }
    myfile.open(string(LOG_DIR) + filename);
    myfile << os.str();
    myfile.close();
#endif // TXT_FILE_ENABLE
}

}} // yanmar::PathPlan

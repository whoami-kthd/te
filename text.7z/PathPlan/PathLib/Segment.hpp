// Yanmar Confidential 20200918
/**
 * @file Segment.hpp
 *
 * パスセグメントクラス群
 */
#pragma once

#include "PathPlanIF.hpp"
#include "Geometry/Geometry.hpp"

#include "boost/geometry.hpp"
#include "boost/geometry/geometries/point_xy.hpp"
#include "boost/geometry/geometries/polygon.hpp"
#include "boost/geometry/geometries/box.hpp"

#include <iostream>
#include <list>
#include <vector>
#include <array>
#include <queue>
#include <bitset>
#include <fstream>

namespace yanmar { namespace PathPlan {
using namespace std;
    namespace PathGeneratorData {
        class PathFPS;
        class PathSPS;
    }

//Constants
constexpr double TOL_MICRO = 0.000001;
constexpr double TOL_MILLI = 0.001;
constexpr double TOL_ZERO_PNT_ONE_CM = 0.001;
constexpr double TOL_ONE_CM = 0.01;
constexpr double TOL_TEN_CM = 0.1;
// セグメント接続角度許容差。1000mに対し1cmのズレ = 約0.000573度。@see Segment2D::checkConnection()
constexpr double TOL_CONNECTION_CP = (10.0 / 1000.0)  / 1000.0;
// 線分の最小長。
constexpr double TOL_MIN_SEG = 0.1;

class XY_Point : public GeoPoint
{
public:
	operator boost::geometry::model::d2::point_xy<double>() { return boost::geometry::model::d2::point_xy<double>{x, y}; }

	using GeoPoint::GeoPoint;
	
	constexpr XY_Point() : GeoPoint()
	{}
	
	constexpr XY_Point(double aLat, double aLon) :
		GeoPoint(aLat, aLon)
	{}
	
	explicit XY_Point(double val) :
		GeoPoint(val)
	{}
	
	constexpr XY_Point(const GeoPoint& aPoint) :
		GeoPoint(aPoint)
	{}

    constexpr XY_Point(const XY_Point& aPoint) :
        GeoPoint(aPoint)
    {}

    XY_Point(XY_Point&& p) noexcept {
        *this = std::move(p);
    }

    XY_Point(const XY_Point& p, const Vector2D& vec, double length) :
        XY_Point(p)
    {
        (*this) += vec.getUnitVector() * Vector2D{length};
    }

    template<typename T>
    XY_Point& operator=(const T& p) noexcept {
        x = p.x;
        y = p.y;
        
        return *this;
    }
    
    XY_Point& operator=(XY_Point&& p) noexcept {
        if (this != &p) {
            x = p.x;
            y = p.y;
        }
        
        return *this;
    }

    GeoPoint& operator=(const XY_Point& p) noexcept {
        if (this != &p) {
            x = p.x;
            y = p.y;
        }
        
        return *this;
    }

    XY_Point(const boost::geometry::model::d2::point_xy<double>& aPoint) :
		GeoPoint(aPoint.x(), aPoint.y())
	{}
    
    static const XY_Point nullobj;
};
    
/**
 ポリゴンクラス
 
 頂点リストのラッパークラス。エイリアスではない理由はoperatorがあるため。
 */
class XY_Polygon : protected std::vector<XY_Point> {
	typedef std::vector<XY_Point> super;
public:
	XY_Polygon() :
		std::vector<XY_Point>()
	{}

	XY_Polygon(const std::vector<XY_Point>& pointList) :
		std::vector<XY_Point>(pointList)
	{}

	XY_Polygon(std::vector<XY_Point>&& pointList) :
		std::vector<XY_Point>(pointList)
	{}

    /**
     頂点追加(コンテナから)
     */
    template<typename T>
    inline
    XY_Polygon& append(const T& src) {
        insert(cend(), src.cbegin(), src.cend());
        return *this;
    }

	using iterator = super::iterator;
	using const_iterator = super::const_iterator;
    using super::push_back;
    using super::emplace_back;
    using super::begin;
	using super::end;
    using super::cbegin;
    using super::cend;
    using super::insert;

    using bgPointList = std::vector<boost::geometry::model::d2::point_xy<double>>;
	operator bgPointList() { return bgPointList(begin(), end()); }
};
	
	
/**
 * 接線移動方向
 *
 * ターンサークル接線セグメントのトラクター移動方向。
 * 例えばフィッシュテールターンの場合バックで移動する。
 */
namespace SegmentDir = PathPlan::Param::Path::Segment::Direction;

namespace DataType
{
	static constexpr int TURN = 0;
	static constexpr int PATH = 1;
}

namespace SegmentType
{
	static constexpr int LINESEG = PathPlan::Param::Path::Segment::Type::STRAIGHT;
	static constexpr int ARCSEG = PathPlan::Param::Path::Segment::Type::CURVE;
}

namespace VertexType
{
	static constexpr int CONVEX = 1;
	static constexpr int CONCAVE = -1;
}

#pragma mark - Segment classes
/////////////////////////
/**
 セグメント基本クラス
 
 セグメントのベースクラス。端点と共通のインターフェースを持つ。
 */
struct Segment2D {
    // TODO: LineSegmentとArcSegmentをリファクタリングして当クラスを般化してGenSegmentを削除する。
	//		歴史的経緯でGenSegmentなどというものがあるが、クラス設計として正しくない。
	//		おそらくLineSegmentの半分くらいはここに来る。ArcSegnetも当クラスからの直接派生になると思われる。

    friend class PathGenerator;

	/// 接続判定結果定数
	struct Connection {
		static constexpr int DISCONNECT = 0; ///< 端点が繋がっていない
		static constexpr int ANGLED = 1;	///< 接続しているが接続点でのベクトルが不一致(角がある)
		static constexpr int REFLECTED = 2;	///< 接続点でベクトルが反転(バックする)
		static constexpr int SMOOTH = 3;	///< 接続点でベクトルが一致(角が無い)
	};

	Segment2D() = default;

	Segment2D(const Segment2D&) = default;

	Segment2D(const XY_Point& point1, const XY_Point& point2) {
		set(point1, point2);
	}

    virtual ~Segment2D() = default;

	XY_Point& point1() noexcept {
		return points[0];
	}
	
	XY_Point& point2() noexcept {
		return points[1];
	}
	
	const XY_Point& point1() const noexcept {
		return points[0];
	}
	
	const XY_Point& point2() const noexcept {
		return points[1];
	}
	
    virtual const XY_Point& enterPoint() const noexcept { return point1(); }
    virtual XY_Point& enterPoint() noexcept { return point1(); }
    virtual const XY_Point& leavePoint() const noexcept { return point2(); }
    virtual XY_Point& leavePoint() noexcept { return point2(); }
    
	void set(const XY_Point& point1, const XY_Point& point2) noexcept {
		points[0] = point1;
		points[1] = point2;
	}

	/// 先頭対末尾交換
	void exchange() noexcept {
		std::swap(point1(), point2());
	}

	// 進入ベクトル
	virtual Vector2D getEnterVector() const = 0;
	// 脱出ベクトル
	virtual Vector2D getLeaveVector() const = 0;
	
	/**
	 接続判定
	 
	 自セグメントのpoint2と指定セグメントのpoint1が一致しているかどうかを返す。
		- 許容差は無い

	 @retval true 端点が一致する
	 @retval false 端点が一致しない
	 */
	bool isConnected(const Segment2D& seg) const noexcept {
		return point2() == seg.point1();
	}
	
	// 接続判定
	int checkConnection(const Segment2D& seg) const noexcept;
    
	// 無視可能判定
	bool isNegrective() const noexcept {
		return point1().isIsolocation(point2());
	}

    // 内積
    double getDotProduct(const Segment2D& seg) const {
        return getLeaveVector().getDotProduct(seg.getEnterVector());
    }
    
    // 内積(指定点からの進入ベクトルと)
    double getDotProductFrom(const XY_Point& point) const {
        const Vector2D eVec{point, enterPoint()};
        return eVec.getDotProduct(getEnterVector());
    }
    
    // 内積(指定点への脱出ベクトルと)
    double getDotProductTo(const XY_Point& point) const {
        const Vector2D lVec{leavePoint(), point};
        return getLeaveVector().getDotProduct(lVec);
    }

    // 内積
    double getDotProductNormalized(const Segment2D& seg) const {
        return getLeaveVector().getDotProductNormalized(seg.getEnterVector());
    }

    // 外積
    double getCrossProduct(const Segment2D& seg) const {
        return getLeaveVector().getCrossProduct(seg.getEnterVector());
    }

    // 外積(指定点からの進入ベクトルと)
    double getCrossProductFrom(const XY_Point& point) const {
        const Vector2D eVec{point, enterPoint()};
        return eVec.getCrossProduct(getEnterVector());
    }

    // 外積(指定点への脱出ベクトルと)
    double getCrossProductTo(const XY_Point& point) const {
        const Vector2D lVec{leavePoint(), point};
        return getLeaveVector().getCrossProduct(lVec);
    }

    // 外積
    double getCrossProductNormalized(const Segment2D& seg) const {
        return getLeaveVector().getCrossProductNormalized(seg.getEnterVector());
    }

    // 無効判定
    virtual bool isNull() const noexcept {
        return (point1() == point2());
    }

public:
	std::array<XY_Point, 2> points;	///< セグメントの両端点
};

/**
 直線セグメント
 
 端点のみを持つ。
 */
struct LineSegment : public Segment2D {
private:
	using super = Segment2D;

public:
	static constexpr int FORWARD = Param::Path::Segment::Direction::FORWARD;
	static constexpr int REVERSE = Param::Path::Segment::Direction::REVERSE;

    /// デフォルトコンストラクタ
    LineSegment() = default;

    /// 両端点から構築
	LineSegment(const XY_Point& point1, const XY_Point& point2) :
		super(point1, point2)
	{}

    /// 両端点から構築。向きも指定
    LineSegment(const XY_Point& point1, const XY_Point& point2, int dir) :
        super(point1, point2),
        direction(dir)
    {}

    /// 始点とベクトルから構築
    LineSegment(const XY_Point& point1, const Vector2D& vec, double length, int dir = FORWARD) :
        super(point1, point1),
        direction(dir)
    {
        const double vlength = vec.getLength();
        if (length <= 0.0) {
            return;
        }

        leavePoint() += Vector2D{length} * vec / Vector2D{vlength};
    }

    /// ベクトルと終点から構築
    LineSegment(const Vector2D& vec, const XY_Point& point1, double length, int dir = FORWARD) :
        super(point1, point1),
        direction(dir)
    {
        const double vlength = vec.getLength();
        if (length <= 0.0) {
            return;
        }
        
        enterPoint() += Vector2D{length} * -vec / Vector2D{vlength};
    }

    /// コピーコンストラクタ
    LineSegment(const LineSegment& src) = default;

    LineSegment& operator=(const Segment2D& seg) {
        enterPoint() = seg.enterPoint();
        leavePoint() = seg.leavePoint();
        return *this;
    }
    
protected:
    /// 向きのみ指定して構築
    /// - ReverseSegmentが使用
    explicit LineSegment(int dir) :
        direction(dir)
    {}

    /// 向き変更コピーコンストラクタ
    /// - ReverseSegmentが使用
    LineSegment(const LineSegment& src, int dir) :
        super(src),
        direction(dir)
    {}

public:
    /// GeoSegmetから構築
    explicit LineSegment(const GeoSegment& src) :
        super(src[0], src[1]),
        direction(FORWARD)
    {}

    /// GeoSegmet変換
    explicit operator GeoSegment() const {
        return GeoSegment{point1(), point2()};
    }

    /// boostのsegmentに変換
	operator boost::geometry::model::segment<boost::geometry::model::d2::point_xy<double>>() {
		namespace bgm = boost::geometry::model;
		using BgVertex = bgm::d2::point_xy<double>;
		using BgSegment = bgm::segment<BgVertex>;

		return BgSegment{BgVertex{point1()}, BgVertex{point2()}};
	}

	// 長さ
	double length() const {
		return point1().distance(point2());
	}
	
	// 直線と点の距離
	double distance(const XY_Point& p) const;

    // 直線の傾き
	Vector2D getVector() const {
		return Vector2D{point1(), point2()};
	}

	// 進入ベクトル
	virtual Vector2D getEnterVector() const {
		return getVector();
	}

	// 脱出ベクトル
	virtual Vector2D getLeaveVector() const {
		return getVector();
	}

	// この角度はLineSegmentにしかない
	virtual double angle() const {
		return getVector().getAngle();
	}

	void dump(const char* filename) const {
#ifdef DEBUG_LOG
		ofstream ofile;
		ofile.open(filename);
		ofile << point1().x << "\t" << point1().y << "\n" << point2().x << "\t" << point2().y << endl;
		ofile.close();
#endif // DEBUG_LOG
	}

	// 先頭延長
	LineSegment& extendHead(double extLength);

	// 末尾延長
	LineSegment& extendTail(double extLength);

    // 両端延長
    LineSegment& extendBoth(double extHeadLen, double extTailLen);
    inline
    LineSegment& extendBoth(double extLength) { return extendBoth(extLength, extLength); };
    
    LineSegment& shift(const Vector2D& vec) noexcept;
    LineSegment& shift(Vector2D vec, double val);

    // 先頭延長(無制限)
    LineSegment& shiftEnterPointHeadward(double extLength) {
        enterPoint() = getShifted(enterPoint(), getEnterVector(), -extLength);
        return *this;
    }
    
    // 末尾延長(無制限)
    LineSegment& shiftLeavePointTailward(double extLength) {
        leavePoint() = getShifted(leavePoint(), getLeaveVector(), extLength);
        return *this;
    }

    // 共線上(サジタル前方)移動
    LineSegment& shiftHeadward(double val) {
        return shift(getEnterVector(), -val);
    }
    // 共線上(サジタル後方)移動
    LineSegment& shiftTailward(double val) {
        return shift(getLeaveVector(), val);
    }

	// 交差判定
	int checkIntersection(const LineSegment& LineSG) const;
    int checkIntersection(const struct ArcSegment& aseg) const;
    int checkIntersection(const struct GenSegment& gseg) const;
    int checkIntersection(const XY_Point& p) const;
    bool isAside(const XY_Point& p, double range) const;
    // 点が直線に直交する脚を持つかどうか
    bool isAside(const XY_Point& p) const {
        const Vector2D v1{point1(), p};
        const Vector2D v2{point2(), p};
        const Vector2D vseg = getVector();
        return (signbit(vseg.getDotProduct(v1)) != signbit(vseg.getDotProduct(v2)));
    }
    bool isNearBy(const XY_Point& p, double range) const;
	/*Checks if the tangent is along the direction or not*/
	int checkTangent(const PathPlan::Circle& C) const;

public:
	int direction = FORWARD;	///< トラクター移動方向(前後進)
};

/**
 後退セグメント
 トラクターの向きが後退(LineSegment::REVERSE)のLineSegmentを生成するファクトリーラッパークラス。
 セグメント上の移動方向は逆にはならないことに注意する。
 */
struct ReverseSegment : public LineSegment {
	ReverseSegment() :
		LineSegment(LineSegment::REVERSE)
	{}

	ReverseSegment(const XY_Point& point1, const XY_Point& point2) :
		LineSegment(point1, point2, LineSegment::REVERSE)
	{}

    ReverseSegment(const XY_Point& point1, const Vector2D& vec, double length) :
        LineSegment(point1, vec, length, LineSegment::REVERSE)
    {}

    ReverseSegment(const Vector2D& vec, const XY_Point& point1, double length) :
        LineSegment(vec, point1, length, LineSegment::REVERSE)
    {}

    ReverseSegment(const ReverseSegment& src) :
		LineSegment(src)
	{}

	ReverseSegment(const LineSegment& src) :
		LineSegment(src, LineSegment::REVERSE)
	{}
    
    // データメンバーの定義は禁止
};

	
/**
 円弧セグメント
 
 端点以外に転回円のCircleを持つ。
 */
struct ArcSegment : public LineSegment {
	ArcSegment()
	{}

	ArcSegment(const XY_Point& point1, const XY_Point& point2, const PathPlan::Circle& aCirc) :
		LineSegment(point1, point2),
		Circ(aCirc)
	{}

	explicit ArcSegment(const LineSegment& lineSegment, const PathPlan::Circle& aCirc = PathPlan::Circle::nullobj) :
		LineSegment(lineSegment),
		Circ(aCirc)
	{}

	void set(const XY_Point& point1, const XY_Point& point2, const PathPlan::Circle& aCirc) {
		points[0] = point1;
		points[1] = point2;
		Circ = aCirc;
    }
    
    // 長さ(孤長)
    double length() const {
        return (centralAngle() * Circ.radius);
    }

    // 中心角
    double centralAngle() const {
         if (isIsometric(Circ.radius, 0.0)) {
            return 0.0;
        }

        const Vector2D centerVec = Circ.center;
        const double start = centerVec.getAngleTo(point1());
        const double end = centerVec.getAngleTo(point2());
        const double angle = Radian::distance(start, end, Circ.orient);
        return angle;
    }

    // 優弧がどうか
    bool isMajorArc() const {
        return (M_PI < centralAngle());
    }
    
	// 進入ベクトル
	virtual Vector2D getEnterVector() const {
		PPASSERT((Circ.orient == Circle::Orient::CLOCKWISE || Circ.orient == Circle::Orient::ANTICLOCKWISE), ErrorCode::FATAL);
		Vector2D tmp{Circ.center, point1()};
		return (Circ.orient == Circle::Orient::CLOCKWISE) ? Vector2D{tmp.y, -tmp.x} : Vector2D{-tmp.y, tmp.x};
	}
	
	// 脱出ベクトル
    virtual Vector2D getLeaveVector() const {
        PPASSERT((Circ.orient == Circle::Orient::CLOCKWISE || Circ.orient == Circle::Orient::ANTICLOCKWISE), ErrorCode::FATAL);
        Vector2D tmp{Circ.center, point2()};
        return (Circ.orient == Circle::Orient::CLOCKWISE) ? Vector2D{tmp.y, -tmp.x} : Vector2D{-tmp.y, tmp.x};
    }

    // 半径変更
    ArcSegment& setRadius(double newRadius);

	/**
	 点が円弧の角度内にあるか(距離は判定しない)
	 
	 @param[in] point	対象の点座標

	 @see checkIntersection(const XY_Point& point) const
	 */
	bool isInSight(const XY_Point& point) const {
		return (Circ.isNextPoint(point1(), point, point2()) == Circle::NextPoint::FIRST);
	}

	/**
	 指定の角度が円弧の角度内にあるか
	 
	 @param[in] target 判定角度
	 */
	bool isInSightAngle(double target) const {
		const Vector2D centerVec = Circ.center;
		// angle of refernce point
		const double start = centerVec.getAngleTo(point1());
		// angle of second point
		const double end = centerVec.getAngleTo(point2());

		return (Circ.isNextAngle(start, target, end) == Circle::NextPoint::FIRST) ;
	}

	//　交差判定
	int checkIntersection(const LineSegment& LineSG) const;
	int checkIntersection(const ArcSegment& CircSG) const;
    int checkIntersection(const struct GenSegment& seg) const;
	int checkIntersection(const XY_Point& point) const;

    // 無効判定
    virtual bool isNull() const noexcept {
        return ((Circ.radius == 0.0) || (point1() == point2()));
    }

    Circle Circ; ///< 円弧母体円
};

/**
 汎用セグメント
 
 PathSegmentで使用するLineSegmentでもArcSegmentでもあるクラス。
 */
struct GenSegment : ArcSegment {
	explicit GenSegment(int type = 0) :
		segmentType(type)
	{}
	
	GenSegment(const LineSegment& lineSegment) :
		ArcSegment(lineSegment),
		segmentType(SegmentType::LINESEG)
	{}
	
	GenSegment(const ArcSegment& arcSegment) :
		ArcSegment(arcSegment),
		segmentType(SegmentType::ARCSEG)
	{}

	virtual Vector2D getLeaveVector() const {
		return (segmentType == SegmentType::LINESEG) ?
									LineSegment::getLeaveVector() :
									ArcSegment::getLeaveVector();
	}

	virtual Vector2D getEnterVector() const {
		return (segmentType == SegmentType::LINESEG) ?
									LineSegment::getEnterVector() :
									ArcSegment::getEnterVector();
	}

    double length() const {
        return (segmentType == SegmentType::LINESEG) ?
                                    LineSegment::length() :
                                    ArcSegment::length();
    }

    //　交差判定
    int checkIntersection(const XY_Point& point) const {
        if (segmentType == SegmentType::ARCSEG) {
            return ArcSegment::checkIntersection(point);
        } else {
            return LineSegment::checkIntersection(point);
        }
    }
	int checkIntersection(const std::vector<struct Boundary>& PP) const;
    int checkIntersection(const LineSegment& lseg) const {
        if (segmentType == SegmentType::ARCSEG) {
            return ArcSegment::checkIntersection(lseg);
        } else {
            return LineSegment::checkIntersection(lseg);
        }
    }
    int checkIntersection(const ArcSegment& aseg) const {
        if (segmentType == SegmentType::ARCSEG) {
            return ArcSegment::checkIntersection(aseg);
        } else {
            return LineSegment::checkIntersection(aseg);
        }
    }
    int checkIntersection(const GenSegment& gseg) const {
        if (gseg.segmentType == SegmentType::ARCSEG) {
            return checkIntersection(static_cast<ArcSegment>(gseg));
        } else {
            return checkIntersection(static_cast<LineSegment>(gseg));
        }
    }

	int segmentType;	///< セグメントの種別 (ArcSegmentまたはLineSegment)
    
    static const GenSegment nullobj;  ///< nullオブジェクト
};

    
// 交差判定メンバ関数エイリアス
inline
int LineSegment::checkIntersection(const struct ArcSegment& aseg) const {
    return aseg.checkIntersection(*this);
}

inline
int LineSegment::checkIntersection(const struct GenSegment& gseg) const {
    return gseg.checkIntersection(*this);
}

inline
int ArcSegment::checkIntersection(const struct GenSegment& aseg) const {
    return aseg.checkIntersection(*this);
}

/**
 パス属性クラス
 
 拡張作業属性値 Param::Path::Segment::ExtType を扱うクラス。
 - 属性値についてエイリアス定数メンバーを持つ。
 - メンバー変数rideTypeは従来のRideTypeと同値となっている。拡張属性部分はextAttrに別途保管する。
 - 拡張部分と合成した拡張作業属性値は getExtType() 等で得られる。
 */
struct PathAttr {
    /// RideType属性値
    /// - Param::Path::Segment::RideType のエイリアス
    struct RideType {
        static constexpr int MASK = Param::Path::Segment::RideType::MASK;
        static constexpr int MASK_FOR_GUIDANCE = Param::Path::Segment::RideType::MASK_FOR_GUIDANCE;    ///< Guidance data 用マスク
        static constexpr int MASK_FOR_DISPLAY = Param::Path::Segment::RideType::MASK_FOR_DISPLAY;       ///< Display data 用マスク
        static constexpr int UNDEFINED = Param::Path::Segment::RideType::UNDEFINED;
        static constexpr int WORKING = Param::Path::Segment::RideType::WORKING;
        static constexpr int DUMMY = Param::Path::Segment::RideType::DUMMY;
        static constexpr int NON_WORKING = Param::Path::Segment::RideType::NON_WORKING;
        static constexpr int ORBITAL_WORKING = Param::Path::Segment::RideType::ORBITAL_WORKING;
        static constexpr int ORBITAL_NON_WORKING = Param::Path::Segment::RideType::ORBITAL_NON_WORKING;
        static constexpr int BLOCK_DIVIDER = Param::Path::Segment::RideType::BLOCK_DIVIDER;
        static constexpr int COUNTER_ORBITAL = Param::Path::Segment::RideType::COUNTER_ORBITAL; ///< 周回パス
    };
    
    /// 拡張属性値
    struct ExtAttr {
        // RideTypeのうちの拡張属性部分
        static constexpr int MASK = Param::Path::Segment::ExtAttr::MASK;       ///< 拡張属性マスク
        static constexpr int NONE = Param::Path::Segment::ExtAttr::NONE;       ///< 無し
        static constexpr int ORBITAL = Param::Path::Segment::ExtAttr::ORBITAL; ///< 周回パス
        static constexpr int COUNTER_ORIENT = Param::Path::Segment::ExtAttr::COUNTER_ORIENT; ///< 逆走周回パス
    };

    constexpr PathAttr() = default;
    constexpr PathAttr(const PathAttr&) = default;
    PathAttr& operator=(const PathAttr&) = default;

    /**
     コンストラクタ
     単一のパス作業属性値から構築する。基本/拡張属性は内部で分離する。
     - つまり、与える値はRideType、ExtTypeのどちらでも良い。
     @param[in] aExtType   パス拡張作業属性
     */
    constexpr explicit PathAttr(int aExtType) :
        PathAttr((aExtType & RideType::MASK), (aExtType & ExtAttr::MASK))
    {}

    /**
     コンストラクタ
     パス属性を独立した引数で初期化する。それぞれ不要なビットはクリアして格納する。
     @param[in] aRideType   パス基本作業属性
     @param[in] aExtType    パス拡張属性
     */
    constexpr explicit PathAttr(int aRideType, int aExtAttr) :
        rideType(aRideType & RideType::MASK),
        extAttr(aExtAttr & ExtAttr::MASK)
    {}

    /**
     パス拡張作業属性設定
     パス拡張作業属性値(ExtType)を設定する。基本/拡張属性を分離して格納する。
     @param[in] aExtType   パス拡張作業属性
     @return 自身の参照
     */
    PathAttr& setExtType(int aExtType) noexcept {
        rideType = (aExtType & RideType::MASK);
        extAttr = (aExtType & ExtAttr::MASK);
        return *this;
    }

    PathAttr& setExtAttr(int aExtAttr) noexcept {
        extAttr = aExtAttr;
        return *this;
    }
    
    int valueForGuidance() const noexcept {
        return (getExtType() & RideType::MASK_FOR_GUIDANCE);
    }

    int valueForDisplay() const noexcept {
        return (getExtType() & RideType::MASK_FOR_DISPLAY);
    }

    /**
     int代入演算子
     @copy setExtType
     */
    PathAttr& operator=(int aExtType) noexcept {
        return setExtType(aExtType);
    }
    
    /**
     拡張作業属性取得
     拡張属性ビット込みの値(ExtType)を返す。DisplayData出力用の値。
     @return 拡張作業属性値
     */
    int getExtType() const noexcept {
        return (extAttr | rideType);
    }

    /// 作業セグメント
    bool isWorking() const noexcept { return (rideType == RideType::WORKING); }
    /// 周回セグメント
    bool isOrbital() const noexcept { return ((extAttr & ExtAttr::ORBITAL) != 0); }
    /// 逆走周回セグメント
    bool isCounterOrbital() const noexcept { return ((extAttr & RideType::COUNTER_ORBITAL) == RideType::COUNTER_ORBITAL); }

    /**
     int変換演算子
     @see getExtType()
     */
    operator int() const noexcept { return getExtType(); }
    
    /** パス基本作業属性
     元来のRideTypeのみを格納する。歴史的経緯により0が作業パスを表しているので注意。
     @see Param::Path::Segment::RideType
     */
    int rideType = RideType::NON_WORKING;
    /** パス拡張属性
     拡張属性のビットマスクフラグであるので注意
     @see Param::Path::Segment::ExtAttr
     */
    int extAttr = ExtAttr::NONE;
    /// セグメントの属性
//    int segAttr = 0;
};

/**
 セグメント属性管理クラス
 */
struct WhiskerParams {
    double headAdjustLength = 0.0;
    double tailAdjustLength = 0.0;
};

/**
 TurnTypeハンドルクラス
 ターンタイプを管理する。
 - 標準ターンの種別とその他属性を操作する。
 
 @see Param::Path::Turn::Type
 */
struct TurnType {
    // エイリアス
    static constexpr int UNDEFINED = Param::Path::Turn::Type::UNDEFINED;
    static constexpr int STRAIGHT = Param::Path::Turn::Type::STRAIGHT;
    static constexpr int FISHTAIL = Param::Path::Turn::Type::FISHTAIL;
    static constexpr int HOOK     = Param::Path::Turn::Type::HOOK;
    static constexpr int U        = Param::Path::Turn::Type::U;
    static constexpr int FLAT     = Param::Path::Turn::Type::FLAT;
    static constexpr int NAVIGATION = Param::Path::Turn::Type::NAVIGATION;
    static constexpr int ALPHA    = Param::Path::Turn::Type::ALPHA;
    static constexpr int PLAIN    = Param::Path::Turn::Type::PLAIN;
    static constexpr int PIVOT    = Param::Path::Turn::Type::PIVOT;
    static constexpr int SPIN     = Param::Path::Turn::Type::SPIN;
    
    static constexpr int STARTNAV_MIN = Param::Path::Turn::Type::STARTNAV_MIN;
    static constexpr int ENDNAV_MIN  = Param::Path::Turn::Type::ENDNAV_MIN;
    
public:
    TurnType() = default;
    TurnType(const TurnType&) = default;
    TurnType(int aValue) :
        value(aValue)
    {}
    
    TurnType& operator=(const TurnType& rhs) noexcept {
        value = rhs.value;
        return *this;
    }
    
    /** 標準ターンタイプ値
        基本的なターン形状で分岐する場合はこれを使用する。
     */
    int std() const noexcept { return (value & Param::Path::Turn::Type::MASK); }
    /// 標準ターン判定
    bool isStd() const noexcept { return bool(value & ~Param::Path::Turn::Type::MASK); }
    /// GuidanceData出力値
    int valueForGuidance() const noexcept { return (value & Param::Path::Turn::Type::MASK_EXTERNAL); }
    /// DisplayData出力値
    int valueForDisplay() const noexcept { return std(); }

public:
    int value = UNDEFINED;
};

inline static
bool operator==(const TurnType& lhs, const TurnType& rhs) noexcept {
    return (lhs.value == rhs.value);
}

inline static
bool operator==(const TurnType& lhs, int rhs) noexcept {
    return (lhs.value == rhs);
}

inline static
bool operator!=(const TurnType& lhs, int rhs) noexcept {
    return (lhs.value != rhs);
}

/**
 作業パスクラス
 
 作業パス一個を表すクラス。
	- FPS/SPS何れでも間のターンパス側の端点がpoint1となり、トラクター移動方向は FPS:point2 -> point1 / SPS:point1 -> point2 とFPS/SPSで逆になる。
	- ターンパスにはFPS::point1 から入り、SPS::point1 へ出る。ターンパス側から見た端点の取得はFPS:leavePoint() / SPS:enterPoint()がある。
	- enterPoint/leavePointからパスターンサークルの接点までを脚(leg)と呼ぶ。脚は作業パスとターンパスの間に位置する非作業セグメントであり、パスデータ出力としてはターンパス側に含まれる。
	- 脚の長さをsetHeadLeg()で設定する。legを設定した状態でsetTurnCircle()を呼ぶとターンサークルが設定可能。
	- 脚とターンサークルとの接点を足(foot)と呼ぶ。getPoint()で取得できる。
 */
struct WorkPath : public ArcSegment {
	static constexpr int ASCEND = 1;
	static constexpr int DESCEND = -1;
    static constexpr int MINIMUM_LEG_LENGTH = 1.0;   /// ヒッチアップに必要な脱出長
    
	WorkPath() :
		foot(0.0),
		dir(0),
		angleToEdge(M_PI_2),
		org(XY_Point(), XY_Point())
	{}

	XY_Point getPoint() const {
		return foot;
	}

	// ここではオーバーライドしない。PathFPSとPathSPSでオーバーライドする
	// leavePoint() enterPoint() 

	// 入口ターンサークル配置
	void setEnterTurnCircle(int rotation, double radius);
	// 出口ターンサークル配置
	void setLeaveTurnCircle(int rotation, double radius);
	// 出入口ターンサークル再配置
	void alternateTurnCircle();
    // 最小パス脚長設定
    void setMinimalLeg() { setHeadLeg(leg.minLength); }
    // 最小パス脚長保証
    double ensureMinimalHeadLegLength();
    // 先頭側(point1)ターンサークルまでの接線(前脚)設定
    void setHeadLeg(double length);
    // 先頭側(point1)ターンサークルまでの接線(前脚)延長
    void extendHeadLeg(double length) {
        if (length != 0.0) {
            setHeadLeg(headLegLength() + length);
        }
    }
    // 先頭側(point1)ターンサークルまでの接線(前脚)ｓ長取得
    double headLegLength() const {
        return (point1().y - foot.y);
    }
    // 末尾側(point2)ターンサークルまでの接線(後脚)設定
//    void setTailLeg(double length);
    // 先頭側ターンサークルまでの接線セグメント(前脚)取得
    virtual LineSegment getHeadLeg() const = 0;
    // 末尾側ターンサークルまでの接線セグメント(後脚)取得
//    virtual LineSegment getTailLeg() const = 0;
    // 最小パス脚長保証
    virtual double ensureMinimalLegLength() = 0;
	// ターンから見た脚を含むセグメント全体取得
	virtual LineSegment getSegmentWithLeg() const = 0;
	// サイドマージン辺判定
	bool isSideEdgePath() const;
    double getEscapeLength(double width) const { return (width * abs(tan(M_PI_2 - abs(angleToEdge)))); }

	/// 交差判定(脚も対象)
	int checkIntersection(const LineSegment& LSG) const { return getSegmentWithLeg().checkIntersection(LSG); }
	/// 交差判定(脚も対象)
	int checkIntersection(const ArcSegment& ASEG) const { return getSegmentWithLeg().checkIntersection(ASEG); }
    /// 交差判定(脚も対象)
    int checkIntersection(const GenSegment& genSG) const {
        return (genSG.segmentType == SegmentType::LINESEG) ?
                    checkIntersection(static_cast<LineSegment>(genSG)) :
                    checkIntersection(static_cast<ArcSegment>(genSG));
    }
    /// 交差判定(許可しない)
    int checkIntersection(const WorkPath&) const = delete;

    /// パス長
    double length() const {
        return (ArcSegment::length() + LineSegment::length());
    }
    
	/**
	 補助ターンサークル存在設定
	 
	 @param[in] flag 補助ターンサークルの有無
		@arg true  補助ターンサークル有り
		@arg false 補助ターンサークル無し
	 @param[in] distance 補助ターンサークルとの距離
     */
	void setAuxTurnCircle(bool flag, double distance = 0.0) {
        auxCircle.present = flag;
        auxCircle.distance = distance;
	}
	/// 補助ターンサークル存在確認
	bool isAuxTurnCirclePresent() const {
		return auxCircle.present;
	}
    // 補助ターンサークル取得
    Circle getAuxTurnCircle() const;

    /// フィッシュテール可否チェック
    virtual bool isFishtailAvailable(const LineSegment& lTS) const = 0;

    /*Calculates direction of path*/
	int Dir();
    
    void dump(const char* filename) const;

public:
    struct Leg {
        double minLength = 0.0;
        double orgLength = 0.0;
    } leg;
	XY_Point foot;	///< パス足。耕作機の位置を考慮したパス端点。
	int dir;	///< 進行方向(1または-1)。Xの増加方向(1)か減少方向(-1)、回転の反時計回り(1:ANTICLOCKWISE)時計回り(-1:CLOCKWISE)。
	bool extended = false;	///< 足を伸ばしたかどうか
    struct {
        bool present = false;	///< 補助ターンサークルを持っているかどうか
        double distance = 0.0;	///< パスターンサークルト補助ターンサークルとの距離
    } auxCircle;
	double angleToEdge = M_PI_2;	///< 作業領域辺となす角度
	LineSegment org;
    LineSegment edge;   /// パスが属する作業領域辺(head側ノードがある辺)
    PathAttr pathAttr{PathAttr::RideType::WORKING, PathAttr::ExtAttr::NONE}; ///< パスの属性
};

#pragma mark - BounadryType as represent boundary types of the field polygons as BP and derived.
/**
 境界種別
 
 圃場または障害物の外形境界に関する定数など。
 */
namespace BoundaryType
{
	static constexpr int UNDEFINED = 0;	/// 不明
	static constexpr int FIELD = 1;		/// 圃場境界
	static constexpr int OBSTACLE = -1;	/// 障害物境界

	/**
	 境界サブタイプ
	 
     交差判定対象の境界を表す。
     複数のORがあるためビットマップフラグである。
     - BoundaryのうちのBP/HP、またはその他の拡張領域。
	 */
	struct Kind {
		/// 境界サブタイプ(インデックス)
        enum Index : unsigned int {
			BP = 0,     // BP
            SBP = 1,    // 拡張BP
            HP,         // = 2 作業領域
            EHP,        // = 3 拡張作業領域(HPに対し踏み荒らし防止マージン付き交差検査)
        };
        static constexpr int NUM_OF_KIND = 4;	// 種類を追加したとき更新を忘れないように!
		
		/// 境界サブタイプフラグ(ビットマスク)
		/// -  インデックスに対応するマスク
        struct Mask {
            static constexpr unsigned int NONE = 0U;
			static constexpr unsigned int BP = (1U << Index::BP);   ///< セグメントのみBP交差
            static constexpr unsigned int SBP = (1U << Index::SBP); ///< 安全マージン付きBP交差
            static constexpr unsigned int HP = (1U << Index::HP);
            static constexpr unsigned int EHP = (1U << Index::EHP); ///< ラスター作業領域との交差
            static constexpr unsigned int ALL = (SBP | HP | EHP);    ///< 圃場境界全て。圃場境界ではないRSEは対象にしていない。
        };
        
        // Avoid collision targets
        static constexpr unsigned int FOR_IGNORE = Kind::Mask::NONE;
        static constexpr unsigned int FOR_DEFAULT = Kind::Mask::ALL;
        /// コーナー間用
        static constexpr unsigned int FOR_INTER_CORNER = FOR_DEFAULT;
        /// パス脚用
        // - 作業パス脚なので走行中にトラクターが踏む範囲のHPは耕されない部分である。(耕すならぱ作業パスのはず)
        static constexpr unsigned int FOR_WORKPATH_LEG = Kind::Mask::SBP;
        /// フィッシュテール部分用
        // - フィッシュテールがHPに食い込むのは現在の制限事項。
        static constexpr unsigned int FOR_FISHTAIL = Kind::Mask::SBP;
        /// フィッシュテール角度探索用
        static constexpr unsigned int FOR_SEEK_FISHTAIL_ANGLE = Kind::Mask::SBP | Kind::Mask::HP;
        /// 共線パス間用
        /// - 作業パスを直進して接続するためHPとの交差は有り得ない。(交差していたらその部分も作業パスのはず)
        static constexpr unsigned int FOR_COLLINEAR = Kind::Mask::SBP;
        // - 障害物は矩形のみなので検査に値しない
        static constexpr unsigned int FOR_COLLINEAR_OBSTACLE = Kind::Mask::SBP;
        /// 作業パス脚間
        static constexpr unsigned int FOR_INTER_WORKPATH_LEG = Kind::Mask::HP;
        /// 終了ナビゲーション終了接線(短縮前用)
        static constexpr unsigned int FOR_ENDNAV_END_SEG = Kind::Mask::BP | Kind::Mask::EHP;
        /// 開始ナビゲーション開始接線
        static constexpr unsigned int FOR_STARTNAV_START_SEG = Kind::Mask::EHP;
        /// 開始ナビゲーション開始接線(周回パス向用)
        static constexpr unsigned int FOR_STARTNAV_PRE_ORBITAL = Kind::Mask::SBP;
        /// バックターン用
        static constexpr unsigned int FOR_BACKTURN1 = Kind::Mask::SBP;   // TODO: 要検討
        static constexpr unsigned int FOR_BACKTURN2 = Kind::Mask::SBP;   // TODO: 要検討
        static constexpr unsigned int FOR_BACKTURN3 = Kind::Mask::SBP;   // TODO: 要検討
        static constexpr unsigned int FOR_SEEK_WHISKER_LENGTH = Kind::Mask::SBP;
        static constexpr unsigned int FOR_SEEK_WHISKER_LENGTH_CONCAVE = Kind::Mask::SBP;   // TODO: 要検討
        /// R-O遷移ラスター脱出ターン用
        static constexpr unsigned int FOR_LEAVE_RASTER_TURN = Kind::Mask::SBP;  // ターン自体がAWPを踏まない形状前提
        /// O-R遷移ラスター進入ターン用
        static constexpr unsigned int FOR_ENTER_RASTER_TURN = Kind::Mask::SBP;  // ターン自体がAWPを踏まない形状前提

        /**
		 境界サブタイプセットクラス
		 
		 対象にするか指定するためのフラグセットクラス
			- 交差判定などで複数指定が必要なのでフラグ集合とする。
			  インデックスもしくはマスクでアクセスできる。詳しくはstd::bitsetを参照。
		 */
		typedef std::bitset<NUM_OF_KIND> Set;
	};
};

#pragma mark - PathSegment class as segment for path data that has not only geometry properties.
/**
 パスセグメントクラス

 TernPathの要素クラス。生成時点では進入点のみ確定している。脱出点は次のセグメントの進入点であり、次のセグメントが決まらないと脱出点が確定しないからである。
 Segmentから生成しても同様である。
 - termはパス(TurnPath)の終端を示すフラグであって、当クラスの終端を示すフラグではない。
 
 @see TurnPath
*/
struct PathSegment : public GenSegment {
public:
    static constexpr int SUCCESS = yanmar::PathPlan::ResultCode::SUCCESS;
    static constexpr int FAILURE = yanmar::PathPlan::ResultCode::FAILURE;
    static constexpr int VALID = SUCCESS;
    static constexpr int INVALID = FAILURE;
	static constexpr int FORWARD = LineSegment::FORWARD;
	static constexpr int REVERSE = LineSegment::REVERSE;

	PathSegment() :
		GenSegment()
	{}

    PathSegment(const PathSegment& src) = default;

    PathSegment& operator=(const PathSegment& src) = default;
	
	// construct from GenSegment
	explicit PathSegment(GenSegment& seg, int aStatus = INVALID) :
        GenSegment(seg),
        status(aStatus)
	{}

    // !ATTENTION: 生成用のセグメントクラスからの暗黙変換は判定を誤るので許さないこと
    
    // construct from LineSegment
    explicit PathSegment(const LineSegment& seg, int aStatus = INVALID) :
        GenSegment(seg),
        status(aStatus)
	{}

    // construct from ArcSegment
    explicit PathSegment(const ArcSegment& seg, int aStatus = INVALID) :
        GenSegment(seg),
        status(aStatus)
	{}

    // FPS/SPSからのコピーコンストラクタ
    // WorkPathは抽象クラスなので実体化できない
    // 作業パスなので初期化時にVALIDとする
    explicit PathSegment(const WorkPath& wseg) :
        GenSegment(LineSegment(wseg)),
        status(VALID),
        term(true),
        pathAttr(PathAttr::RideType::WORKING)
    {}

    explicit PathSegment(const PathGeneratorData::PathFPS& fps);
    explicit PathSegment(const PathGeneratorData::PathSPS& sps);

	// constructor for LINESEG
	PathSegment(const XY_Point& startPoint, const XY_Point& endPoint, int aDirection = FORWARD) :
		GenSegment(SegmentType::LINESEG)
	{
		point1() = startPoint;
        point2() = endPoint;
		direction = aDirection;
	}

    PathSegment(const XY_Point& startPoint, int aDirection = FORWARD) :
        GenSegment(SegmentType::LINESEG)
    {
        point1() = startPoint;
        direction = aDirection;
    }

	// constructor for ARCSEG
	PathSegment(const XY_Point& startPoint, const Circle& aCircle, int aDirection = FORWARD) :
		GenSegment(SegmentType::ARCSEG)
	{
		point1() = startPoint;
		Circ = aCircle;
		direction = aDirection;
	}

    // セグメント値をコピー
    PathSegment& set(const LineSegment& lseg) {
        enterPoint() = lseg.enterPoint();
        leavePoint() = lseg.leavePoint();
        direction = lseg.direction;

        return *this;
    }
    
	// parentと変化は無いのでオーバーライドしない

	XY_Point& point() noexcept {
		return points[0];
	}

	const XY_Point& point() const noexcept {
		return points[0];
	}

    void validate() {
        status = VALID;
    }

    void invalidate() {
        status = INVALID;
    }

    bool isValid() const noexcept {
        return (status == VALID);
    }
    
    /// 状態 - セグメント取得時に検査結果を返す場合がある
    int status = INVALID;
    /// パス終端フラグ - セグメント単位ではなく生成中TurnPathの終端かどうかを示す
    bool term = false;
    
    /// 交差検査対象境界
	BoundaryType::Kind::Set collisionBoundary{BoundaryType::Kind::Mask::ALL};
    /// 交差検査結果境界
    BoundaryType::Kind::Set collidesBoundary{BoundaryType::Kind::Mask::ALL};

    /// パス属性 @see PathAttr, Param::Path::Segment::RideType
    PathAttr pathAttr;
    /// セグメントマーク
    WhiskerParams whisker;
    /// ターン種別 (セグメントの属するパス種別) @see Param::Path::Turn::Type
    TurnType turnType{Param::Path::Turn::Type::UNDEFINED};
    
    static const PathSegment nullobj;  ///< nullオブジェクト
};

template<typename T>
inline static
void setTurnType(std::vector<T>& list, TurnType turnType) {
    for_each(list.begin(), list.end(),
            [turnType](T& v) {
                v.turnType = turnType;
            });
}

/**
 作業パスセグメント生成クラス
 */
struct PathSegmentWork : public PathSegment {
    // constructor for LINESEG
    PathSegmentWork(const XY_Point& startPoint, int aDirection = FORWARD) :
        PathSegment(startPoint, aDirection)
    {
        pathAttr.rideType = PathAttr::RideType::WORKING;
    }

    PathSegmentWork(const LineSegment& seg) :
        PathSegment(seg)
    {
        pathAttr.rideType = PathAttr::RideType::WORKING;
    }

    // constructor for ARCSEG
    PathSegmentWork(const XY_Point& startPoint, const Circle& aCircle, int aDirection = FORWARD) :
        PathSegment(startPoint, aCircle, aDirection)
    {
        pathAttr.rideType = PathAttr::RideType::WORKING;
    }
};

#pragma mark - PathSegment class as segment for path data that has not only geometry properties.
/**
 出力パスデータセグメント
 
 出力CSVデータのパスを表すクラス。CSVのパスデータに必要な情報のみを保持する。
 */
struct OutPathSegment : public GenSegment {
public:
    static constexpr int SUCCESS = yanmar::PathPlan::ResultCode::SUCCESS;
    static constexpr int FAILURE = yanmar::PathPlan::ResultCode::FAILURE;
    static constexpr int VALID = SUCCESS;
    static constexpr int INVALID = FAILURE;
    static constexpr int FORWARD = LineSegment::FORWARD;
    static constexpr int REVERSE = LineSegment::REVERSE;
    
    struct RideType {
        static constexpr int UNDEFINED = Param::Path::Segment::RideType::UNDEFINED;
        static constexpr int WORKING = Param::Path::Segment::RideType::WORKING;
        static constexpr int NON_WORKING = Param::Path::Segment::RideType::NON_WORKING;
        static constexpr int DUMMY = Param::Path::Segment::RideType::DUMMY;
    };


    
    OutPathSegment() = default;
    OutPathSegment(const OutPathSegment& src) = default;
    OutPathSegment& operator=(const OutPathSegment& src) = default;
    
    // construct from GenSegment
    explicit OutPathSegment(GenSegment& seg) :
        GenSegment(seg)
    {}
    
    explicit OutPathSegment(const LineSegment& seg) :
        GenSegment(seg)
    {}
    
    explicit OutPathSegment(const ArcSegment& seg) :
        GenSegment(seg)
    {}
    
    // FPS/SPSからのコピーコンストラクタ
    // WorkPathは抽象クラスなので実体化できない
    OutPathSegment(const WorkPath& wseg, const PathAttr& aPathAttr) :
        GenSegment(LineSegment(wseg)),
        pathAttr(aPathAttr),
        turnType(PathParam::Turn::Type::STRAIGHT)
    {
        // FPSは前後逆なので直接代入してはいけない
        enterPoint() = wseg.enterPoint();
        leavePoint() = wseg.leavePoint();
    }
    
    // constructor for PathSegment
    OutPathSegment(const PathSegment& pathSeg) :
        GenSegment(static_cast<GenSegment>(pathSeg)),
        pathAttr(pathSeg.pathAttr),
        turnType(pathSeg.turnType)
    {}

    const XY_Point& enterPoint() const noexcept {
        return point1();
    }
    
    XY_Point& enterPoint() noexcept {
        return point1();
    }
    
    const XY_Point& leavePoint() const noexcept {
        return point2();
    }
    
    XY_Point& leavePoint() noexcept {
        return point2();
    }
    
    XY_Point& point() noexcept {
        return points[0];
    }
    
    const XY_Point& point() const noexcept {
        return points[0];
    }
    
    /// 移動時動作種別(当セグメント上で作業するかどうか) @see Param::Path::Segment::RideType
    PathAttr pathAttr;
    /// ターン種別 (セグメントの属するパス種別) @see Param::Path::Turn::Type
    TurnType turnType{TurnType::UNDEFINED};

    /// ポストプロセス用属性
    struct PostProcessInfo {
        int promoRideType = TurnType::UNDEFINED;
        bool intersectTarget = false;
    } ppInfo;
};

/// 出力パスデータクラス(パスセグメントのリスト)
using OutPathData = std::vector<OutPathSegment>;

#pragma mark - PathSegment class as segment for path data that has not only geometry properties.

struct tData;
/**
 ABパス用セグメント
 */
struct PathSegmentAB : public OutPathSegment {
    PathSegmentAB() = delete;
    PathSegmentAB(const PathSegmentAB&) = delete;
    PathSegmentAB& operator=(const PathSegmentAB& src) = delete;
    explicit PathSegmentAB(const tData& st, const tData& ed);
};

/// 出力パスデータクラス(パスセグメントのリスト)
using OutPathData = std::vector<OutPathSegment>;
    
#pragma mark - Boundary class as handling a virtex of field boundary polygon.
/**
 境界情報要素クラス
 
 対応する境界/作業領域/安全作業領域の頂点を管理するクラス。
 */
struct Boundary {
	Boundary() = default;
    Boundary(const Boundary& src) = default;

    Boundary(const XY_Point& bpPoint, const XY_Point& hpPoint, int aBndFlg, int aNodeIndex) :
		BP(bpPoint),
		HP(hpPoint),
        EHP(hpPoint),
        bndFlg(aBndFlg),
        nodeIndex(aNodeIndex)
	{
        return;
    }
	
	Boundary(const XY_Polygon::iterator& bpIt, const XY_Polygon::iterator& hpIt, int aBndFlg, int aNodeIndex) :
		BP(*bpIt),
		HP(*hpIt),
        EHP(*hpIt),
        bndFlg(aBndFlg),
        nodeIndex(aNodeIndex)
	{}
	
    // 外部供給値
	XY_Point BP;			///< Boundary Point (圃場ポリゴンの頂点)
	XY_Point HP;			///< Headland Point (作業領域ポリゴンの頂点)
    XY_Point EHP;            ///< Extended Headland Point (拡張作業領域ポリゴンの頂点)
    int bndFlg = BoundaryType::FIELD;     ///< 圃場か障害物か
    int nodeIndex = -1;     ///< ノードのインデックス

    // 内部設定値
    int CvCnF;				///< Convex or Concave Flag (頂点が凸点か凹点か)
	PathPlan::Vector2D bisector;	///< BP頂点の2等分線の方向ベクトル
	double r2Length = 0.0;		///< 頂点をはさむ2辺から距離1だけ離れるために2等分線上を進む長さ (r(旋回半径+a)を掛けて使用する)
    
    const static Boundary nullobj;  ///< 共通参照用nullオブジェクト
};

/// 枕地ターンサークル
struct HeadlandTurnCircle : public Boundary
{
	HeadlandTurnCircle()
	{}

	HeadlandTurnCircle(const PathPlan::Circle& aCirc, const Boundary& bnd) :
   		Boundary(bnd),
		Circ(aCirc),
		CvCnF(bnd.CvCnF)
	{}

	/// 数値有効性チェック
	bool validate() const{
		return Circ.validate();
	}
	
	PathPlan::Circle Circ;	///< ターンサークル情報本体

	// 参照情報
	int CvCnF = 0;		///< コーナーの凹凸
    std::bitset<4> flags = 0;
    
    static const unsigned int IGNORED_BY_FPS = 0;
    static const unsigned int REACHED_BY_FPS = 1;
    static const unsigned int IGNORED_BY_SPS = 2;
    static const unsigned int REACHED_BY_SPS = 3;
    bool isIgnoredByFps() const { return flags.test(IGNORED_BY_FPS); }
    bool isIgnoredBySps() const { return flags.test(IGNORED_BY_SPS); }
    bool isSubatableByFps() const { return flags.test(REACHED_BY_FPS); }
    bool isSubatableBySps() const { return flags.test(REACHED_BY_SPS); }
};

#pragma mark - Segment classes for field boundary. to check collision with path segment.
/////////////////////////
/**
 境界セグメント
 
 Boundaryのセグメント。交差判定用。
 */
class BoundaryLineSegment
{
public:
	BoundaryLineSegment() = default;
	explicit BoundaryLineSegment(const BoundaryLineSegment& src) = default;
	
	BoundaryLineSegment(const Boundary& aFirst, const Boundary& aSecond, int aCornerType) :
		first(aFirst),
		second(aSecond),
		cornerType(aCornerType)
	{}
	
	LineSegment getSegmentBP() const {
		return LineSegment(first.BP, second.BP);
	}
	
	LineSegment getSegmentHP() const {
		return LineSegment(first.HP, second.HP);
	}
	
    LineSegment getSegmentEHP() const {
        return LineSegment(first.EHP, second.EHP);
    }
    
	Boundary first;		///< 一つ目のBoundary
	Boundary second;	///< 二つ目のBoundary
	int cornerType;	///< 交差判定時に凹凸頂点のどちらを対象にするか @see VertexType
};

/// 圃場境界セグメント
class FieldLineSegment : public BoundaryLineSegment
{
public:
	FieldLineSegment(const Boundary& aFirst, const Boundary& aSecond) :
		BoundaryLineSegment(aFirst, aSecond, VertexType::CONCAVE)
	{}
};

/// 障害物用境界セグメント
class ObstacleLineSegment : public BoundaryLineSegment
{
public:
	ObstacleLineSegment(const Boundary& aFirst, const Boundary& aSecond) :
		BoundaryLineSegment(aFirst, aSecond, VertexType::CONVEX)
	{}
};

#pragma mark - functions for checking intersection.
// 交差判定
inline
int checkIntersection(const LineSegment& segL, const GenSegment& segR) {
    return (segR.segmentType == SegmentType::LINESEG) ?
                                    segL.checkIntersection(static_cast<LineSegment>(segR)) :
                                    segL.checkIntersection(static_cast<ArcSegment>(segR));
}

inline
int checkIntersection(const ArcSegment& segL, const GenSegment& segR) {
    return (segR.segmentType == SegmentType::LINESEG) ?
                                    segL.checkIntersection(static_cast<LineSegment>(segR)) :
                                    segL.checkIntersection(static_cast<ArcSegment>(segR));
}

inline
int checkIntersection(const GenSegment& segL, const GenSegment& segR) {
    return (segL.segmentType == SegmentType::LINESEG) ?
                                    checkIntersection(static_cast<LineSegment>(segL), segR) :
                                    checkIntersection(static_cast<ArcSegment>(segL), segR);
}

#pragma mark - functions for geometric manipurations.

/**
 共線上位置関係定数値
 直線上(一次元)の位置関係を表す。前方とはLineSegmentが持つ向きでトラクターの移動方向である。
 - 有向線分LLに対する点の位置。LLに対し点Pがどの位置にあるか。LLは左が進入点、右が脱出点とする。
     -  LLP: 前方(脱出点側で外)
     -  LPL: 線分区間内
     -  PLL: 後方(進入点側で外)
 - 線分LLとMMの両端点の位置関係。
 */
namespace InlinePos {
    // 線分LLに対する点Pの位置
    static constexpr unsigned int UNDEFINED = 0x0FU;   // 定義できない
    static constexpr unsigned int LLP  = 0x03U;   // 線分のベクトル前方(脱出点側で線分外) {seg0.enter, seg0.leave} point
    static constexpr unsigned int LPL  = 0x02U;   // 線分内 {seg0.enter, point, seg0.leave}
    static constexpr unsigned int PLL  = 0x00U;     // 線分のベクトル後方(進入点側で線分外) point {seg0.enter, seg0.leave}

    // 線分LLに対する線分MMの位置
    static constexpr unsigned int LLMM = (LLP << 4) | LLP; ///< (seg0.enter, seg0.leave} [seg1.enter, seg1.leave]; 交差無し seg0 -> seg1　seg1完全先行
    static constexpr unsigned int LMLM = (LPL << 4) | LLP; ///< (seg0.enter, [seg1.enter, seg0.leave), seg1.leave]; 交差あり seg0 -> seg1 seg1進入点のみseg0内
    static constexpr unsigned int LMML = (LPL << 4) | LPL; ///< [seg1.enter, (seg0.enter, seg0.leave), seg1.leave]; 交差あり seg1 の両端点とも seg0内
    static constexpr unsigned int MLLM = (PLL << 4) | LLP; ///< (seg0.enter, [seg1.enter, seg1.leave], seg0.leave); 交差あり seg0 の両端点とも seg1内
    static constexpr unsigned int MLML = (PLL << 4) | LPL; ///< [seg1.enter, (seg0.enter, seg1.leave], seg0.leave); 交差あり seg1 -> seg0 seg1脱出点のみseg0内
    static constexpr unsigned int MMLL = (PLL << 4) | PLL; ///< [seg1.enter, seg1.leave], (seg0.enter, seg0.leave); 交差無し seg1 -> seg0 seg0完全先行
}
// 共線上の線分位置関係
unsigned int inlinePosition(const LineSegment& fromSeg, const LineSegment& toSeg);
unsigned int inlinePosition(const LineSegment& seg, const XY_Point& point);

// ポリゴン内外判定
bool within(const std::vector<XY_Point>& polygon, const XY_Point& p);
bool isStandIn(const std::vector<XY_Point>& polygon, const LineSegment& seg);
// 線分交差点取得
bool intersection(const LineSegment& ls1, const LineSegment& ls2, XY_Point& p);

inline
bool isIsometric(const Segment2D& lhs, const Segment2D& rhs) {
	return isIsometric(lhs.point1(), rhs.point1()) && isIsometric(lhs.point2(), rhs.point2());
}

inline
bool isIsometric(const LineSegment& lhs, const LineSegment& rhs) {
	return ((lhs.direction == rhs.direction) &&
			isIsometric(static_cast<const Segment2D&>(lhs), static_cast<const Segment2D&>(rhs)));
}

inline
bool isIsometric(const ArcSegment& lhs, const ArcSegment& rhs) {
	return (isIsometric(static_cast<const LineSegment&>(lhs), static_cast<const LineSegment&>(rhs)) &&
			isIsometric(lhs.Circ, rhs.Circ));
}

inline
bool operator==(const LineSegment& lhs, const LineSegment& rhs) {
	return (&lhs == &rhs) || (lhs.point1() == rhs.point1() && lhs.point2() == rhs.point2());
}

inline
bool operator!=(const LineSegment& lhs, const LineSegment& rhs) {
	return !(lhs == rhs);
}

/**
 差分方向符号取得
 
 dst までの src からの値の変化方向を返す。つまり、offsetSign(src, dst) のとき (dst - src) の符号を 1 か -1 で返す。
 
 @param[in] src 現在値
 @param[in] dst 目標値
 @retval 1 増加する(変化しない場合も含む)
 @retval -1 減少する
 */
template<typename T>
int offsetSign(const T& src, const T& dst) {
    return (dst < src) ? -1 : 1;
}

/**
 符号取得
 
 0 から dst の値の変化方向を返す。つまり、dstの符号を 1 か -1 で返す。
 
 @param[in] dst 目標値
 @retval 1 増加する(変化しない場合も含む)
 @retval -1 減少する
 */
template<typename T>
int offsetSign(const T& dst) {
    return signbit(dst) ? -1 : 1;
}

/// X方向差分符号 (dst <- src)
// TODO: src, dst順を逆にする
inline
int dirX(const GeoPoint& dst, const GeoPoint& src) {
    return offsetSign(src.x, dst.x);
}

/// Y方向差分符号 (dst <- src)
// TODO: src, dst順を逆にする
inline
int dirY(const GeoPoint& dst, const GeoPoint& src) {
    return offsetSign(src.y, dst.y);
}

/**
 外積
 2線分間の外積を返す。
 */
inline
double getCrossProduct(const LineSegment& eSeg, const LineSegment& lSeg) {
    return eSeg.getCrossProduct(lSeg);
}

/**
 外積
 3点で表す2線分間の外積を返す。
 */
inline
double getCrossProduct(const GeoPoint& a, const GeoPoint& b, const GeoPoint& c) {
    LineSegment eSeg{a, b};
    LineSegment lSeg{b, c};
    return eSeg.getCrossProduct(lSeg);
}

/**
 鋭角交差判定
 2線分の成す角度が90度未満のときtrueを返す。
 */
inline
bool isAcute(const LineSegment& eSeg, const LineSegment& lSeg) {
    const double dp = eSeg.getDotProduct(lSeg);
    return (dp < 0.0);
}

/**
 鈍角交差判定
 2線分の成す角度が90度を超えるときtrueを返す。
 */
inline
bool isObtuse(const LineSegment& eSeg, const LineSegment& lSeg) {
    const double dp = eSeg.getDotProduct(lSeg);
    return (0.0 < dp);
}

/**
 平行判定(無向)
 向きを無視した平行検査
 - 同一直線上にある場合もtrue。
 @see isCollateral
 */
inline
bool isParallel(const LineSegment& eSeg, const LineSegment& lSeg) {
    const double cp = eSeg.getCrossProduct(lSeg);
    return (isIsometric(cp, 0.0, TOL_CONNECTION_CP));
}

/**
 平行判定(有向)
 有向線分の向きを含めた平行検査
 - 向きのみの判定。同一直線上にある場合もtrue。
 @see isParallel, isCollinear
 */
inline
bool isCollateral(const LineSegment& eSeg, const LineSegment& lSeg) {
    const double dp = eSeg.getDotProductNormalized(lSeg);
    return (isIsometric(dp, 1.0, TOL_CONNECTION_CP));
}

/**
 共線判定(無向)
 2線分が一直線上にあればtrueを返す。
 - 方向と重なりは考慮しない。
 @see isCollinear, isLineAhead
 */
inline
bool isInline(const LineSegment& eSeg, const LineSegment& lSeg) {
    if (eSeg.isNegrective() || lSeg.isNegrective()) {
        return true;
    }
    
    LineSegment tSeg{eSeg.enterPoint(), lSeg.leavePoint()};
    return isParallel(eSeg, tSeg);
}

/**
 共線判定(有向)
 2線分と線分間を結ぶ直線が一直線上、かつ向きが一致する場合にtrueを返す。
 - 重なりは判定しない。
 @see isInline, isLineAhead
 @note eSeg始点 - lSeg終点を使うと線分が長いため誤差によって異なる結果になる可能性がある。
 */
inline
bool isCollinear(const LineSegment& eSeg, const LineSegment& lSeg) {
    if (eSeg.isNegrective() && lSeg.isNegrective()) {
        // どちらのも長さ0のとき、接続していれば良い。
        return (eSeg.leavePoint() == lSeg.enterPoint());
    } else if (!eSeg.isNegrective() || !lSeg.isNegrective()) {
        // どちらかが長さを持っていれば、それぞれの端点同士を結んだ2線分が長さを持つ。
        LineSegment tmpSeg0{eSeg.enterPoint(), lSeg.enterPoint()};
        LineSegment tmpSeg1{eSeg.leavePoint(), lSeg.leavePoint()};
        return (isCollateral(eSeg, lSeg) && isParallel(tmpSeg0, tmpSeg1));
    }

    // どちらも長さがあるので中間線分で判定。
    LineSegment tmpSeg{eSeg.enterPoint(), lSeg.enterPoint()};
    return (isCollateral(eSeg, lSeg) && isParallel(eSeg, tmpSeg));
}

/**
 縦列判定
 2線分が一直線上、かつ向きが一致しており、eSegの延長線上にlSegがある(重なりが無い)場合にtrueを返す。
 - 端点の接続は重なっていないものとみなす。
 @see isInline, isCollinear
 */
inline
bool isLineAhead(const LineSegment& eSeg, const LineSegment& lSeg) {
    if (lSeg.isNegrective()) {
        return true;
    }

    LineSegment tmpSeg{eSeg.leavePoint(), lSeg.enterPoint()};
    return (isCollinear(eSeg, lSeg) && isCollinear(eSeg, tmpSeg));
}

// 最近傍点検索
std::vector<XY_Point>::const_iterator findNearest(const std::vector<XY_Point>& points, const XY_Point& p0);

/**
 旋回方向判定
 @param[in] dst 目標値
 @retval -1 時計回り(CLOCKWISE)
 @retval 1 反時計回り(ANTICLOCKWISE)
 */
inline int turnDirection(const LineSegment& eSeg, const LineSegment& lSeg) {
    const double cp = eSeg.getCrossProduct(lSeg);
    return offsetSign(cp);
}


#pragma mark - functions for tangent line segment with a circle.
/**
 接線の向き
 
 yanmar::PathPlan::SegmentDirと同値
 */
struct TangentDir {
    static constexpr int FORWARD = yanmar::PathPlan::SegmentDir::FORWARD;
    static constexpr int REVERSE = yanmar::PathPlan::SegmentDir::REVERSE;
    
    /// 値の反転
    /// - 無効値はFORWARDにする。
    static inline constexpr
    int invert(int d) { return SegmentDir::invert(d); }
};

using TangentPair = pair<PathPlan::LineSegment, PathPlan::LineSegment>;
TangentPair getTangentsParalleled(const Circle& c1, const Circle& c2);
TangentPair getTangentsCrossed(const Circle& c1, const Circle& c2);

inline bool isTangentAvailable(const Circle& c1, const Circle& c2) {
    return (c1.orient == c2.orient || c1.checkIntersection(c2) == Intersection::NO);
}

// 2円間の接線セグメント取得
PathSegment getTangent(const LineSegment& eTS, const Circle& currCirc, const Circle& nextCirc, int direction = TangentDir::FORWARD);
inline PathSegment getTangent(const LineSegment& eTS, const Circle& currCirc, const XY_Point& dstPoint) {
    return getTangent(eTS, currCirc, Circle{dstPoint, 0.0});
}

PathSegment getTangent(const Circle& currCirc, const Circle &nextCirc, int direction = TangentDir::FORWARD);
PathSegment getTangent(const XY_Point& srcPoint, const Circle &nextCirc, int direction = TangentDir::FORWARD);
inline PathSegment getTangent(const Circle& currCirc, const XY_Point& dstPoint, int direction = TangentDir::FORWARD) {
    auto ts = getTangent(dstPoint, currCirc, TangentDir::invert(direction));
    ts.exchange();
    return ts;
}
LineSegment getTangent(const Vector2D& lVec, const Circle& currCirc, double length);
LineSegment getTangent(const Circle& currCirc, const Vector2D& lVec, double length);

TangentPair getTangents(const Circle& C1, const Circle& C2);
TangentPair getTangents(const Circle& C1, const XY_Point& dstPos);
TangentPair getTangents(const XY_Point& srcPos, const Circle& C2);
int getTangentDirection(const XY_Point& PntP, const Circle& currCirc, const Circle& nextCirc);

bool flipTurnCircle(Circle& currCirc, LineSegment& enterLine, LineSegment& leaveLine);

/**
 コーナー旋回方向取得

 進入線分から脱出線分へのコーナーにおけるターンの旋回方向を返す。
 - 並行で、2線分のベクトルが逆向きの場合はdefaultOrientを返す。デフォルトはUNDEFINED。
 - 線分の持つベクトルの外積に基づいて判定するので端点が接続している必要はない。
 - 線分同士の位置関係が想定しているものかどうかは別途判定すること。
 
 @param[in] eTS    進入線分
 @param[in] lTS    脱出線分

 @return ターンの旋回方向
 @retval UNDEFINED      ターンしない
 @retval ANTICLOCKWIZE  反時計回り
 @retval CLOCKWIZE      時計回り
 */
inline
int getCornerOrient(const LineSegment& eTS, const LineSegment& lTS, int defaultOrient = Circle::Orient::UNDEFINED) {
    const double cp = eTS.getCrossProduct(lTS);
    if (isIsometric(cp, 0.0, TOL_CONNECTION_CP)) {
        const double dp = eTS.getDotProduct(lTS);
        if (dp < 0.0) {
            return defaultOrient;
        }
        
        return Circle::Orient::UNDEFINED;
    }

    return offsetSign(cp);
}

/**
 ターン旋回方向取得
 
 進入線分終点から脱出線分始点への旋回方向を返す。
 - getCornerOrientと違い、並行な線分間のターン方向も位置関係に基づいて返す。
 - 共線上の2線分でベクトルが逆向きの場合はdefaultOrientを返す。デフォルトはUNDEFINED。
 
 @param[in] eTS    進入線分
 @param[in] lTS    脱出線分
 
 @return ターンの旋回方向
 @retval UNDEFINED      ターンしない(直進するか折り返す)
 @retval ANTICLOCKWIZE  反時計回り
 @retval CLOCKWIZE      時計回り
 */
inline
int getTurnOrient(const LineSegment& eTS, const LineSegment& lTS, int defaultOrient = Circle::Orient::UNDEFINED) {
    const double cp = eTS.getCrossProductTo(lTS.enterPoint());
    if (isIsometric(cp, 0.0, TOL_CONNECTION_CP)) {
        // 並行である
        const double cp2 = eTS.getCrossProductTo(lTS.leavePoint());
        if (isIsometric(cp2, 0.0, TOL_CONNECTION_CP)) {
            const double dp = eTS.getDotProductTo(lTS.leavePoint());
            return (dp < 0.0) ? defaultOrient : Circle::Orient::UNDEFINED;
        } else {
            return offsetSign(cp);
        }
    }

    return offsetSign(cp);
}


#pragma mark - functions for line segments and segment list.

// 線分接続
bool connectAny(LineSegment& eSeg, LineSegment& lSeg);
bool connectForward(LineSegment& eSeg, LineSegment& lSeg);
bool connectEntering(LineSegment& eSeg, LineSegment& lSeg);
bool connectLeaving(LineSegment& eSeg, LineSegment& lSeg);
// 線分リスト接続
template<typename T>
inline static
bool joinCorner(vector<T>& edgeList) {
    bool retval = false;
    
    for (auto it = edgeList.begin(); it != edgeList.cend(); it++) {
        auto it2 = next(it);
        if (it2 == edgeList.cend()) {
            break;
        }
        auto& eSeg = *it;
        auto& lSeg = *it2;
        retval = connectAny(eSeg, lSeg);
        if (!retval) {
            break;
        }
    }
    
    return retval;
}

bool joinCorner(vector<PathSegment>& edgeList, int orgEdgeCount);

/**
 2線融合試行(前方)
 eTSの終点をlTS始点に変更して接続がSMOOTHであればeTSを変更する。

 @param[in,out] eTS 線分1
 @param[in]     lTS 線分2

 @return 接合したかどうか
 @retval true : 融合した
 @retval false: 融合しなかった
 */
inline
bool tryUnite(LineSegment& eTS, const LineSegment& lTS) {
    const LineSegment tmpTS{eTS.point1(), lTS.point1()};
    const bool check = (tmpTS.checkConnection(lTS) == Segment2D::Connection::SMOOTH);
    if (check) {
        eTS.point2() = tmpTS.point2();
    }
    
    return check;
}

/**
 2線分融合試行(後方)
 lTSの始点をeTS終点に変更して接続がSMOOTHであればlTSを変更する。
 
 @param[in,out] eTS 線分1
 @param[in]     lTS 線分2
 
 @return 融合したかどうか
 @retval true : 融合した
 @retval false: 融合しなかった
 */
inline
bool tryUnite(const LineSegment& eTS, LineSegment& lTS) {
    const LineSegment tmpTS{eTS.point2(), lTS.point2()};
    const bool check = (eTS.checkConnection(tmpTS) == Segment2D::Connection::SMOOTH);
    if (check) {
        lTS.point1() = tmpTS.point1();
    }
    
    return check;
}

/**
 平行線分取得
 
 指定直線セグメントからshift値離れた平行なセグメントを返す。
    - 指定セグメントの向きに対し、shift 値が正なら左側、負ならば右側のセグメントになる

 @return 並行なLineSegment
 */
inline
LineSegment getCollateralSegment(LineSegment lseg, double shift) {
    if (!lseg.isNegrective() || shift != 0.0) {
        const Vector2D v = lseg.getVector();
        Vector2D sv{-v.y, v.x};
        sv = sv * Vector2D{shift} / Vector2D{lseg.length()};
        lseg.point1() += sv;
        lseg.point2() += sv;
    }
    return lseg;
}

/**
 セグメント先頭コピー
 lsegのコピーの終点を指定長さの位置にした線分を返す。
 - 元のlsegの長さが無効な場合は何もせずlsegのコピーを返す。
 */
inline
LineSegment getFromHead(const LineSegment& lseg, double length) {
    if (!lseg.isNegrective()) {
        return {lseg.enterPoint(), lseg.getEnterVector(), length};
    }
    return lseg;
}

/**
 セグメント先頭コピー
 @warning LINESEGのみ対象
 @see getFromHead(const LineSegment& lseg, double length)
 */
inline
PathSegment getFromHead(PathSegment lseg, double length) {
    if (!lseg.isNegrective()) {
        LineSegment seg{lseg.enterPoint(), lseg.getEnterVector(), length};
        lseg.set(seg);
    }
    return lseg;
}

/**
 セグメント末尾コピー
 lseg lsegのコピーの始点を指定長さの位置にした線分を返す。
 - 元のlsegの長さが無効な場合は何もせずlsegのコピーを返す。
 */
inline
LineSegment getFromTail(const LineSegment& lseg, double length) {
    if (!lseg.isNegrective()) {
        return {lseg.getLeaveVector(), lseg.leavePoint(), length};
    }
    return lseg;
}

/**
 セグメント末尾コピー
 @warning LINESEGのみ対象
 @see getFromTail(const LineSegment& lseg, double length)
 */
inline
PathSegment getFromTail(PathSegment lseg, double length) {
    if (!lseg.isNegrective()) {
        LineSegment seg{lseg.getLeaveVector(), lseg.leavePoint(), length};
        lseg.set(seg);
    }
    return lseg;
}

/**
 セグメント末尾コピー(後退)
 lsegの末尾からlength後退する線分を返す。
 - 元のlsegの長さが無効な場合はlsegと同じ長さの後退セグメントを返す。
 */
inline
LineSegment getReflected(const LineSegment& lseg, double length) {
    if (!lseg.isNegrective()) {
        // ReverseSegmentはトラクター向きがREVERSEであるのみなのでベクトルは反転して渡す
        return ReverseSegment{lseg.leavePoint(), -lseg.getLeaveVector(), length};
    }
    return ReverseSegment{lseg};
}

/**
 セグメント末尾コピー(後退)
 lsegの末尾から後退する線分を返す。長さは同じ。
*/
inline
ReverseSegment getReflected(const LineSegment& lseg) {
    return ReverseSegment{lseg.leavePoint(), lseg.enterPoint()};
}

/**
 進入パス脚取得
 
 指定直線セグメントに進入するパス脚を返す。
 */
template<typename T>
inline
T getHeadLeg(T lseg, double length) {
    if (!lseg.isNegrective()) {
        auto epos = lseg.enterPoint();
        lseg.extendHead(length);
        lseg.leavePoint() = epos;
    } else {
        lseg.leavePoint() = lseg.enterPoint();
    }
    return lseg;
}

/**
 脱出パス脚取得
 
 指定直線セグメントから脱出するパス脚を返す。
 */
template<typename T>
inline
T getTailLeg(T lseg, double length) {
    if (!lseg.isNegrective()) {
        auto epos = lseg.leavePoint();
        lseg.extendTail(length);
        lseg.enterPoint() = epos;
    } else {
        lseg.enterPoint() = lseg.leavePoint();
    }
    return lseg;
}

/// 直線への進入ターンサークル取得
inline
Circle getEnterTurnCircle(LineSegment lseg, double radius, int orient) {
    Circle tc{{0.0, 0.0}, radius, orient};

    if (!lseg.isNegrective()) {
        double shift = radius * orient;
        auto sseg = getCollateralSegment(lseg, shift);
        tc.center = sseg.enterPoint();
    }
    return tc;
}

/// 直線からの脱出ターンサークル取得
inline
Circle getLeaveTurnCircle(LineSegment lseg, double radius, int orient) {
    Circle tc{{0.0, 0.0}, radius, orient};
    
    if (!lseg.isNegrective()) {
        double shift = radius * orient;
        auto sseg = getCollateralSegment(lseg, shift);
        tc.center = sseg.leavePoint();
    }
    return tc;
}

/// 直線への進入パス脚取得
inline
LineSegment getEnterLeg(LineSegment lseg, double length) {
    if (!lseg.isNegrective()) {
        LineSegment seg{lseg.getEnterVector(), lseg.enterPoint(), length};
        lseg.set(seg.enterPoint(), seg.leavePoint());
    } else {
        lseg.leavePoint() = lseg.enterPoint();
    }

    return lseg;
}

/// 円弧への進入脚取得
inline
LineSegment getEnterLeg(const ArcSegment& aSeg, double length) {
    LineSegment lseg{aSeg};

    if (!aSeg.isNegrective()) {
        LineSegment seg{aSeg.getEnterVector(), aSeg.enterPoint(), length};
        lseg.set(seg.enterPoint(), seg.leavePoint());
    } else {
        lseg.leavePoint() = lseg.enterPoint();
    }

    return lseg;
}


/// パスセグメントへの進入パス脚取得
inline
PathSegment getEnterLeg(const PathSegment& pseg, double length) {
    LineSegment lseg{pseg};

    if (pseg.segmentType == SegmentType::ARCSEG) {
        lseg = getEnterLeg(static_cast<ArcSegment>(pseg), length);
    } else {
        lseg = getEnterLeg(static_cast<LineSegment>(pseg), length);
    }
    
    return PathSegment{lseg};
}


/// 直線からの脱出パス脚取得
inline
LineSegment getLeaveLeg(LineSegment lseg, double length) {
    if (!lseg.isNegrective()) {
        LineSegment seg{lseg.leavePoint(), lseg.getLeaveVector(), length};
        lseg.set(seg.enterPoint(), seg.leavePoint());
    } else {
        lseg.enterPoint() = lseg.leavePoint();
    }

    return lseg;
}

/// 円弧からの脱出パス脚取得
inline
LineSegment getLeaveLeg(const ArcSegment& aSeg, double length) {
    LineSegment lseg{aSeg};

    if (!aSeg.isNegrective()) {
        LineSegment seg{aSeg.leavePoint(), aSeg.getLeaveVector(), length};
        lseg.set(seg.enterPoint(), seg.leavePoint());
    } else {
        lseg.enterPoint() = lseg.leavePoint();
    }

    return lseg;
}

/// パスセグメントからの脱出パス脚取得
inline
PathSegment getLeaveLeg(const PathSegment& pseg, double length) {
    LineSegment lseg{pseg};

    if (pseg.segmentType == SegmentType::ARCSEG) {
        lseg = getLeaveLeg(static_cast<ArcSegment>(pseg), length);
    } else {
        lseg = getLeaveLeg(static_cast<LineSegment>(pseg), length);
    }
    
    return PathSegment{lseg};
}

class Line : public LineSegment {
    using LineSegment::LineSegment;
};

/**
 交点取得(直線対直線)
 
 線分lseg1, lseg2を直線とみなして交点を求める。
 - lseg1.point1 -> lseg1.point2 (交点p0) lseg2.point1 -> lseg2.point2　のベクトルを持つとし、
   交点を持たない場合はlseg1.point2 - lseg2.point1 間の中点を返す

 @note
 @verbatim
 直線1: a1 * x + b1 * y + c1 = 0
 直線2: a2 * x + b2 * y + c2 = 0
 の交点p0(x0, y0)の座標
 x0 = (b1 * c2 - b2 * c1) / (a1 * b2 - a2 * b1);
 y0 = (a2 * c1 - a1 * c2) / (a1 * b2 - a2 * b1);
 2点(x1, y1) (x2, y2)を通る直線の式
 y - y1 = ((y2 -y1) / (x2 - x1)) * (x - x1)
 * 但し、この式は y1 != y2 かつ x1 == x2 のときはx軸平行、y1 == y2 かつ x1 == x2 の場合は2点が同一で定義できないのでこのまま使用しない方が良い。
 以上より直線L1{p1(a, b)、p2(c, d)} と L2{p3(e, f)、p4(g, h)}の交点 p0(x0, y0) の座標を求める式は
 x0 = ((f * g - e * h)(c - a) - (b * c - a * d)(g - e)) / ((d - b)(g - e) - (c - a)(h - f));
 y0 = ((f * g - e * h)(d - b) - (b * c - a * d)(h - f)) / ((d - b)(g - e) - (c - a)(h - f));
 * 但し、((d - b)(g - e) - (c - a)(h - f)) は L1 L2のベクトルの外積であり、これが0の場合は2直線は平行であり交点を持たない。
 * 線分を対象としないのでp0が線分の区間内かどうかの判定は不要。
 * 除数は上記外積のみしか現れないので、x軸平行でも同一点でも場合分けは不要。
 @endverbatim
 */
inline
GeoPoint getCrossPoint(LineSegment lseg1, LineSegment lseg2, double toleranceIsometric = TOL_CONNECTION_CP) {
    
    const Vector2D v1 = lseg1.getVector();
    const Vector2D v2 = lseg2.getVector();
    const double d = (v1.y * v2.x) - (v1.x * v2.y); // L1, L2のベクトルの外積
    if (isIsometric(d, 0.0, toleranceIsometric)) {
        // 平行検査
//        return lseg1.point2();
        throw std::runtime_error("get cross poiont");
    }
    
    const auto& p1 = lseg1.point1();
    const auto& p2 = lseg1.point2();
    const auto& p3 = lseg2.point1();
    const auto& p4 = lseg2.point2();
    const double d1 = (p3.y * p4.x) - (p3.x * p4.y);    // L2端点の位置ベクトルの外積
    const double d2 = (p1.y * p2.x) - (p1.x * p2.y);    // L1端点の位置ベクトルの外積
    Vector2D vd{d1, d2};
    const double x0 = vd.x * v1.x - vd.y * v2.x;
    const double y0 = vd.x * v1.y - vd.y * v2.y;
    GeoPoint p0{x0, y0};
    p0 /= d;
    
    return p0;
}

// 先頭揃え
bool justifyHead(const LineSegment& refSeg, LineSegment& seg) noexcept;
// 末尾揃え
bool justifyTail(const LineSegment& refSeg, LineSegment& seg) noexcept;
/**
 コーナーターンポイント取得
 
 ポリゴンのコーナー頂点を挟む2辺lseg0,lseg1に接する指定半径のターンサークルの中心点を返す。
 - ポリゴン辺を前提にしているまので、引数にorientとcvcnをとる。　@see getCornerTurnCircle
 - ２線分は実際には交差していなくても良い。直線とみなして交点を求める。 @see getCrossPoint
 
 @param[in] seg0    辺1
 @param[in] seg1    辺2
 @param[in] radius  旋回半径
 @param[in] orient  周回方向 {CLOCKWIZE, ANTICLOCKWISE} 2辺のポリゴン上での周回方向
 @param[in] cvcn    コーナーの凹凸 {CONVEX, CONCAVE}、2辺が作るのコーナーの凹凸
 */
inline
GeoPoint getCornerTurnPoint(const LineSegment& seg0, const LineSegment& seg1, double radius, int orient, int cvcn) {
    GeoPoint px;
    const double crossShift = radius * orient * cvcn;
    
    const auto seg0x = getCollateralSegment(seg0, crossShift);
    const auto seg1x = getCollateralSegment(seg1, crossShift);
    px = getCrossPoint(seg0x, seg1x);
    
    return px;
}

/**
 コーナーターンサークル取得
 
 ポリゴンのコーナー頂点を挟む2辺lseg0,lseg1に接する指定半径のターンサークルを返す。
 @see getCornerTurnPoint
 
 @param[in] seg0    辺1
 @param[in] seg1    辺2
 @param[in] radius  旋回半径
 @param[in] orient  周回方向 {CLOCKWIZE, ANTICLOCKWISE} 2辺のポリゴン上での周回方向
 @param[in] cvcn    コーナーの凹凸 {CONVEX, CONCAVE}、2辺が作るのコーナーの凹凸
 */
inline
Circle getCornerTurnCircle(const LineSegment& seg0, const LineSegment& seg1, double radius, int orient, int cvcn) {
    const GeoPoint px = getCornerTurnPoint(seg0, seg1, radius, orient, cvcn);
    
    return Circle{px, radius, orient};
}

/**
 エッジリスト生成
 */
vector<LineSegment> getEdgeList(const vector<XY_Point>& polygon, const vector<XY_Point>::const_iterator& startIt);

// 道程長
template<typename T, typename iterator = typename std::vector<T>::iterator>
inline static
double getMileage(const iterator& its, const iterator& ite) {
    double d = 0.0;
    for_each(its, ite, [&](T& v) {
        d += v.length();
    });
                                                            
    return d;
}

// 全道程長
template<typename T>
inline static
double getMileage(std::vector<T>& edgeList) {
    return getMileage<T>(edgeList.begin(), edgeList.end());
}

/**
 分割長
 seg1をpxで分割した二つの長さを返す。
 */
template<typename T>
inline static
std::pair<double, double> getDivisionLengths(const T& seg1, const XY_Point& px) noexcept {
    return {px.distance(seg1.enterPoint()), px.distance(seg1.leavePoint())};
}

/**
分割長
seg1をseg2で分割した二つの長さを返す。交差しない場合どちらも0が帰る。
*/
template<typename T>
inline static
std::pair<double, double> getDivisionLengths(const T& seg1, const T& seg2) {
    try {
        auto px = getCrossPoint(seg1, seg2);
        return getDivisionLengths(seg1, px);
    } catch(...) {
        return {0.0, 0.0};
    }
}

/**
 逆順
 */
template<typename T>
inline
void reverse(std::vector<T>& edges) {
    std::reverse(edges.begin(), edges.end());
    std::for_each(edges.begin(), edges.end(), [](T& seg) { seg.exchange(); });
}

/**
 逆順
 */
template<typename T>
inline
void reverse(T& seg) {
    seg.exchange();
}

/**
 逆順オブジェクト生成
 */
template<typename T>
inline
std::vector<T> getReversed(const std::vector<T>& edges) {
    std::vector<T> tmp;

    tmp.reserve(edges.size());
    std::copy_if(edges.crbegin(), edges.crend(), tmp.begin(), [](T& seg) { reverse(seg); return true; });

    return tmp;
}

/**
 逆順オブジェクト生成
 */
template<typename T>
inline
T getReversed(const T& seg) {
    return seg.exchange();
}

/*
 * デバッグダンプ
 */
void dumpBoundary(const char* filename, const vector<Boundary>& boundaries);

}} // yanmar::PathPlan

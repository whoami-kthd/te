// Yanmar Confidential 20200918
/**
 @file StandardTurnGenerator.cpp
 
 PathGeneartorクラス実装ファイル(PathLib.cppの一部)
 
 通常ターンパス生成処理
 */
/// @internal @defgroup PathGenerator  PathGenerator interface

//#define LOGLEVEL 5
#define FLATTURN_WHISKER false

#include "PolyLib/Common.h"
#include "PathLib.h"

#include <cstdlib>
#include <string>
#include <stdexcept>
#include <ostream>
#include <utility>
#include <algorithm>

#include "PolyLib/PolygonUtil.hpp"
#include "DataConverter/OutputDataStream.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

using namespace Param::Path;
using namespace SegmentType;
using namespace VertexType;
using namespace RotateDirection;
using namespace ResultCode;
using namespace PathGeneratorData;

#pragma mark - PathGenerator:: Standard Turn Path creation
#undef LOG_TAG
#define LOG_TAG "PathPlan::PathGenerator"

/**
 フィッシュテールターン生成
 
 フィッシュテールターンパスを生成しPathGeneratorに積む。
 - dapative がtrueの場合、フィッシュテール角度を適応的探索し、生成失敗したら角度固定で生成する。
 - バック禁止の場合は生成に失敗し、例外を投げる。
 - ナビゲーションターン生成中の場合、リトライしない。
 
 @param[in] adaptive 適応的角度探索フラグ
 
 @see createFishtailTurnAdapive(), createFishtailTurnfixed()
 
 @return 生成結果
 @retval SUCCESS 生成成功
 @retval FAILURE 生成失敗
 */
int PathGenerator::createFishtailTurn(bool adaptive) {
    LOGV(LOG_TAG "::createFishtailTurn", "()");
    
    int valid = INVALID;
    int result = FAILURE;
    if (adaptive) {
        // - 適応的
        result = createFishtailTurnAdapive();
        if (result == SUCCESS) {
            valid = pathValidator.checkTurnPath(pathBuffer, Turn::Type::FISHTAIL);
        }
    }
    
    if (traverseInfo.isStandardTurn()) {
        // 通常ターンのとき
        // - 固定角度でリトライする
        if (valid != VALID) {
            pathBuffer.clear();
            // 作業パス脚を脱出長にリセット
            setEscapeLeg(traverseInfo.fps);
            setEscapeLeg(traverseInfo.sps);
            result = createFishtailTurnFixed();
            if (result == SUCCESS) {
                valid = pathValidator.checkTurnPath(pathBuffer, Turn::Type::FISHTAIL);
            }
        }
        
        // 作業パス脚を妥協してみる
        if (valid != VALID) {
            // 作業パス脚を最小にリセット
            pathBuffer.clear();
            traverseInfo.fps.setMinimalLeg();
            traverseInfo.sps.setMinimalLeg();
            result = createFishtailTurnFixed();
            // これの検証は戻ってから
        }
    } else {
        // ナビゲーションパスのときは即失敗
        traverseInfo.turnType = Turn::Type::FISHTAIL;				// this is Fishtail turn
        result = (valid == VALID) ? SUCCESS : FAILURE;
    }
    
    return result;
}

/**
 フィッシュテールターン生成(固定)
 
 FPS/SPS間に切り返し角度固定でフィッシュテールターンパスを生成し、pathBufferに出力する。
	- 初期FPS/SPSターンサークルは設定済みであるとする。
	- FPS/SPSをセットアップし、getTurnPath(const PathFPS& fps, const PathSPS& sps, double tailLen) を呼ぶ。
 	- 切り返し接線はパスに対して常に直角となる
		- 作業パスが作業領域辺に直角でない場合はターンサークルy位置を内部で揃える。
	- パス間隔に依存せずフィッシュテールターンを生成する。以下の場合は補助ターンサークルを挿入する。
      その場合、作業パス間に追加のターンを挟むのでナビゲーションパスとする。
		- FPS/SPS間隔が(旋回直径 - 10cm)より広い
        - さの他の理由で失敗

 @see getTurnPath(const PathFPS& fps, const PathSPS& sps, double tailLen)
 
 @return 生成結果
 @retval SUCCSESS 成功
 @retval FAILURE  失敗
 */
int PathGenerator::createFishtailTurnFixed() {
	LOGV(LOG_TAG "::createFishtailTurnPath", "(fixed)");
    if (!gauge.permitBackward) {
        // バック移動禁止
        ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::StdTurn::INCLUDE_BACKWARD);
        err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] path includes reverse segment without backward permission.", "::createFishtailTurnPath");
        throw err;
    }

    int result = FAILURE;
	pathBuffer.clear();

    const double preBackLength = gauge.turn.fishtail.preBackLength;
    auto modFPS = traverseInfo.fps;
    auto modSPS = traverseInfo.sps;
	const XY_Point& startPoint = modFPS.leavePoint();
	const XY_Point& endPoint = modSPS.enterPoint();
	const int rotDir = -modFPS.dir * dirX(endPoint, startPoint);

    const Vector2D pathDelta = endPoint - startPoint;
    const double pathGap = abs(pathDelta.x);
    // ナビゲーションターンの場合、脚が延長されているので足で位置関係を判断すること
    int pth = (modFPS.dir == dirY(modSPS.foot, modFPS.foot)) ? 1 : -1;

    // この関数はUターンを生成しないのでちょうど旋回直径付近で計算誤差を考慮しなければならない
    if (pathGap < ((gauge.turnRadius * 2) - TOL_ONE_CM)) {
        auto tmpFPS = traverseInfo.fps;
        auto tmpSPS = traverseInfo.sps;
        LineSegment extendedleg;

        // 単純フィッシュテール
        // - パス間隔が十分狭い場合のみ
        traverseInfo.turnType = Turn::Type::FISHTAIL;
        // 強制的に直角に切り返すためy軸を合わせる
        if (pth == 1) {
            // SPS is the path on which fixed circle is present
            tmpFPS.foot.y = tmpSPS.foot.y;
            extendedleg = tmpFPS.getHeadLeg();
            extendedleg.extendHead(-TOL_ONE_CM);
        } else {
            // FPS is the path on which fixed circle is present
            tmpSPS.foot.y = tmpFPS.foot.y;
            extendedleg = tmpSPS.getHeadLeg();
            extendedleg.extendTail(-TOL_ONE_CM);
        }

        if (checkBoundaryIntersection(extendedleg, BoundaryType::Kind::FOR_WORKPATH_LEG) == Intersection::NO) {
            // 伸ばした脚が交差していない
            tmpFPS.setLeaveTurnCircle(rotDir, gauge.turnRadius);
            tmpSPS.setEnterTurnCircle(rotDir, gauge.turnRadius);
            auto tmpPath = pathAssembler.getTurnPath(tmpFPS, tmpSPS, preBackLength);
            // 通常ターンは無効でも空を返さないため結果は無条件で格納する
            pathBuffer.pushTurnPath(tmpPath);
            if (tmpPath.isValid()) {
                pathBuffer.completeSegment(tmpSPS.enterPoint());
                pathBuffer.validate();
                result = SUCCESS;
                modFPS = tmpFPS;
                modSPS = tmpSPS;
            }
        }
    }
    
    if (result != SUCCESS) {
        // 補助付きフィッシュテール
        // - パス間隔が半径以上の場合を想定したもの
        LOGD(LOG_TAG "::createFishtailTurnPath(fixed)", "try assisted");
        auto tmpFPS = traverseInfo.fps;
        auto tmpSPS = traverseInfo.sps;
        double extend = 0.0;
        if (!traverseInfo.isStandardTurn() && isIsometric(tmpFPS.getPoint().y, tmpSPS.getPoint().y, TOL_ZERO_PNT_ONE_CM)) {
            // 補助ターンからフィッシュテールに水平に渡れない(切り返し接線と衝突する)のでわずかにずらしておく。
            // ナビゲーションターンから適用したとき、最初からFPS/SPSが並んでいる可能性があるため。通常ターンでは生じないはずである。
            LOGD(LOG_TAG "::createFishtailTurnPath(fixed)", "adjust head leg length.");
            extend = std::max(TOL_ONE_CM, abs(tmpFPS.getPoint().x - tmpSPS.getPoint().x) * TOL_CONNECTION_CP * 4.0);
        }
        // 足の長さが揃えられているので脱出点で再判定
        pth = (modFPS.dir == dirY(modSPS.enterPoint(), modFPS.leavePoint())) ? 1 : -1;
        // 補助付きフィッシュテール
        traverseInfo.turnType = Turn::Type::NAVIGATION;
        // フィッシュテールの二つのターン間は作業パス間隔未満にする
        // - その場合補助ターン無しで成功しているはずである。
        double turnDistance = gauge.turnRadius;
        if (gauge.turnRadius < (pathGap - TOL_ONE_CM)) {
            turnDistance += (gauge.turnRadius - pathGap + TOL_ONE_CM);
        }
        // 中間カーブ設置
        
        if (pth == 1) {
            tmpFPS.extendHeadLeg(-extend);
            tmpFPS.setLeaveTurnCircle(rotDir, gauge.turnRadius);
            tmpSPS.setEnterTurnCircle(rotDir, gauge.turnRadius);
            tmpSPS.setAuxTurnCircle(true, turnDistance);
        } else {
            tmpSPS.extendHeadLeg(-extend);
            tmpSPS.setEnterTurnCircle(rotDir, gauge.turnRadius);
            tmpFPS.setLeaveTurnCircle(rotDir, gauge.turnRadius);
            tmpFPS.setAuxTurnCircle(true, turnDistance);
        }
        
        auto tmpPath = pathAssembler.getTurnPath(tmpFPS, tmpSPS, preBackLength);
        if (tmpPath.isValid()) {
            pathBuffer.pushTurnPath(tmpPath);
            pathBuffer.completeSegment(tmpSPS.enterPoint());
            pathBuffer.validate();
            result = SUCCESS;
            modFPS = tmpFPS;
            modSPS = tmpSPS;
        } else if (pathBuffer.empty()) {
            // 補助無しのターンパスが生成できていなかった場合
            // - 通常ターンパスは空では返さない(生成のみして返す)
            pathBuffer.pushTurnPath(tmpPath);
        }
    }

    if (result == SUCCESS) {
        traverseInfo.fps = modFPS;
        traverseInfo.sps = modSPS;
    }

    LOGD(LOG_TAG "::createFishtailTurnPath(fixed)", "%s", ResultString(result).c_str());
    pathBuffer.setTurnType(PathParam::Turn::Type::FISHTAIL);
	return result;
}

/**
 フィッシュテールターン生成(適応的)
 
 フィッシュテールターンパスを生成しPathGeneratorに積む。
	- サイドマージンのようなパスとの角度が小さい辺での適用は想定していない。ほぼ間違いなく生成に失敗するのでそのようなケースならば角度固定版を使うこと。
	- バック禁止の場合は生成に失敗し、例外を投げる。
 
 @see seekFishtailAngle()
 
 @return 生成結果
 @retval SUCCESS 生成成功
 @retval FAILURE 生成失敗
 */
int PathGenerator::createFishtailTurnAdapive() {
    LOGV(LOG_TAG "::createFishtailTurnAdapive", "()");

    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    auto tmpFPS = traverseInfo.fps;
    auto tmpSPS = traverseInfo.sps;
    traverseInfo.turnType = Turn::Type::FISHTAIL;				// this is Fishtail turn
    
    if (!gauge.permitBackward) {
        // バック移動禁止
        ErrorPathGenerator err(traverseInfo, ErrorCode::PathGeneration::StdTurn::INCLUDE_BACKWARD);
        err.setDescription("[EXCEPTION:PROB_TURN_GENERATION] path includes reverse segment without backward permission.");
        throw err;
    }
    
    const XY_Point startPoint = tmpFPS.leavePoint();
    const XY_Point endPoint = tmpSPS.enterPoint();

    // Determine the path for fix circle
    // fixedPath =1 means FPS path for fix circle
    // fixedPath =-1 means SPS path for fix circle
    const int fixedPath = (endPoint.y > startPoint.y) ? -tmpFPS.dir : tmpFPS.dir;
    
    auto result = seekFishtailAngle(tmpFPS, tmpSPS, fixedPath);
    if (result != SUCCESS) {
        LOGD(LOG_TAG "::createFishtailTurnAdapive", "SEEK INVERSE");
        // 角度を逆にして試行
        tmpFPS = traverseInfo.fps;
        tmpSPS = traverseInfo.sps;
        result = seekFishtailAngle(tmpFPS, tmpSPS, -fixedPath);
    }

    if (result == SUCCESS) {
        LOGD(LOG_TAG "::createFishtailTurnAdapive", "SUCCESS");
        // 成功した
        FPS = tmpFPS;
        SPS = tmpSPS;
        // 生成本体
        TurnPath path = pathAssembler.getFishTailPath(FPS, SPS, gauge.turn.fishtail.preBackLength);
        pathBuffer.pushTurnPath(path);
        pathBuffer.completeSegment(SPS.enterPoint());
    } else {
        LOGD(LOG_TAG "::createFishtailTurnAdapive", "FAIL");
    }

    pathBuffer.setTurnType(PathParam::Turn::Type::FISHTAIL);
    return result;
}

/**
 フィッシュテールターン角度探索
 
 パスの存在する辺に合わせてフィッシュテールの切り返し部分の角度を変える。
	- 生成した切り返し接線、即ちターンサークル間接線のバックする部分とBP、HPとの交差が無い角度を探索する。
	- 探索は片方のターンサークルを移動して実際に有効かどうかを検査して試行する
    - 有効な接線が発見できなかった場合は初期位置(作業パスに対して直交)で生成する。
    - 初期位置でパス足が境界と交差している場合は生成に失敗し、FAILUREを返す。
    .
 - 移動するターンサークルはフィッシュテール接線の作業領域辺に近い端点と接する側
     - 移動ステップは10cmずつ
     - 移動開始位置は固定ターンサークルと同じ高さ(フィッシュテールの切り返し接線がパスに垂直)
     - 移動終了位置(作業パス間隔が近くなるにつれて長さが無限大となるため以下の制限で終了)
        - フィッシュテール接線が存在する作業領域辺に並行になる位置
        - ただし、パス間隔および両ターンサークル幅が1cm未満の場合は開始位置と同じ
        .
 - 切り返し接線は以下の候補を得る
    - トラクター前後方分を延長したセグメントでHP検査をパスするものを第1候補とする。
    - 元のパスのみでHP交差しないものを第2候補とする。
 - 全体が真に有効なパスかどうかはターン生成時には検査しない。通常ターンは全般に生成に成功することが前提である。
 
 @note  交差検査は圃場境界全体に対して行う。隣もしくはそれ以外の辺との交差が無いとも限らない(凹頂点近くなど)ので検査辺を限定するのは検討が必要。
        フィッシュテールターンはHPに侵入してでもターン生成に成功する必要がある。

 @param[in,out] FPS FPS参照
 @param[in,out] SPS SPS参照
 @param[in]     fixedPath 固定側作業パス
    @arg 1  FPSが固定
    @arg -1 SPSが固定
 
 @return 生成結果
 @retval SUCCESS 生成成功
 @retval FAILURE 生成失敗
 */
int PathGenerator::seekFishtailAngle(PathFPS& FPS, PathSPS& SPS, int fixedPath) const {
    LOGV(LOG_TAG "::seekFishtailAngle", "(%d)\n %s\n %s", fixedPath, to_string(FPS, "FPS:").c_str(), to_string(SPS, "SPS:").c_str());
    
    const XY_Point startPoint = FPS.leavePoint();
    const XY_Point endPoint = SPS.enterPoint();
    // delta of between FPS and SPS.
    const Vector2D deltaPath = Vector2D{startPoint, endPoint}.abs();
    const int delta = (endPoint.y > startPoint.y) ? -FPS.dir : FPS.dir;
    
    // 最小脚長:切り返し接線が作業パスに垂直::createFishtailTurn
    const double minLeg = deltaPath.y + gauge.minFpsLegLength;
    // 最長脚長:切り返し接線が作業領域辺と平行になる長さ(後で計算)
    
    // Circles
    Circle fixedCirc, floatCirc;
    struct {
        bool available = false;
        Circle fixed;
        Circle floated;
    } savedCirc;
    LineSegment eTS;

    //initialization of circle
    SPS.setMinimalLeg();
    FPS.setMinimalLeg();
    if (delta == 1) {
        FPS.setTurnCircle(-FPS.dir * dirX(endPoint, startPoint), gauge.turnRadius);
        SPS.setTurnCircle(SPS.dir * dirX(startPoint, endPoint), gauge.turnRadius);
    } else {
        SPS.setTurnCircle(SPS.dir * dirX(startPoint, endPoint), gauge.turnRadius);
        FPS.setTurnCircle(-FPS.dir * dirX(endPoint, startPoint), gauge.turnRadius);
    }
    // ターンサークル間最大座標差
    const Vector2D deltaCirc = Vector2D{FPS.Circ.center, SPS.Circ.center}.abs();
    if (delta == 1) {
        SPS.setHeadLeg(minLeg);
    } else {
        FPS.setHeadLeg(minLeg);
    }

    if (fixedPath == 1) {
        // FPS is the path on which fixed circle is present
        eTS = FPS.getHeadLeg();
        fixedCirc = FPS.Circ;
        floatCirc = SPS.Circ;
    } else {
        // SPS is the path on which fixed circle is present
        // SPS->FPSで接線計算をさせるためターン方向を逆転する(さもないと無効なパスができる)
        eTS = SPS.getHeadLeg();
        fixedCirc = -SPS.Circ;
        floatCirc = -FPS.Circ;
    }
    
    // 最長脚長算出
    // - この計算は両円の半径が同じであることが前提
    double maxLeg = minLeg;
    const double maxExtend = gauge.turn.fishtail.maxAngleTan * deltaCirc.x;
    if (TOL_ONE_CM <= deltaCirc.x) {
        maxLeg += maxExtend;
    }

    LOGV(LOG_TAG "::seekFishtailAngle", "[deltaPath] x:%g, y:%g", deltaPath.x, deltaPath.y);
    LOGV(LOG_TAG "::seekFishtailAngle", "[deltaCirc] x:%g, y:%g", deltaCirc.x, deltaCirc.y);
    LOGV(LOG_TAG "::seekFishtailAngle", "[LastAngle] %g", Degree::convert(Vector2D{deltaCirc.x, maxExtend}.getAngle()));
    LOGV(LOG_TAG "::seekFishtailAngle", "[EdgeAngle] %g", Degree::convert(deltaPath.getAngle()));
    
    const double stepLen = TOL_TEN_CM;	//steps of 10 cm for circle
    const int retries = (int)ceil(maxExtend / stepLen);
    LOGV(LOG_TAG "::seekFishtailAngle", "[leg Min -> Max] %g -> %g; step by %g step, up to %d times.", minLeg, maxLeg, stepLen, retries);
    
    // check legs
    const int collFpsLeg = checkBoundaryIntersection(FPS.getHeadLeg().extendHead(-TOL_ONE_CM), BoundaryType::Kind::FOR_WORKPATH_LEG);
    if (collFpsLeg != Intersection::NO) {
        LOGV(LOG_TAG "::seekFishtailAngle", "min FPS leg already collides with HP");
        return FAILURE;
    }
    const int collSpsLeg = checkBoundaryIntersection(SPS.getHeadLeg().extendTail(-TOL_ONE_CM), BoundaryType::Kind::FOR_WORKPATH_LEG);
    if (collSpsLeg != Intersection::NO) {
        LOGV(LOG_TAG "::seekFishtailAngle", "min SPS leg already collides with HP");
        return FAILURE;
    }
    
    // 切り返し角度探索ループ
    BoundaryCollisions collisions;
    // save origin position
    const XY_Point floatCircOrigin = floatCirc.center;
    const double stepY = FPS.dir * stepLen;

    for (int i = 0; i <= retries; i++) {
        // Finding tangent between circles
        // 切り返し角度探索ルーブ: floatCircを移動しつつ接線計算
        // - [minLeg ... minLeg]までstepLenずつ移動する
        
        // pre update floating circle.
        if (0 < i && i == retries) {
            // at last (except first): use maxLeg.
            floatCirc.center.y = floatCircOrigin.y + FPS.dir * maxExtend;
        }
        
        // Tangent
        // FPS/SPSは変更しないこと
        PathSegment PS = getTangent(eTS, fixedCirc, floatCirc, TangentDir::REVERSE);
        if (!PS.isValid()) {
            LOGV(LOG_TAG "::seekFishtailAngle", "no valid tangent.");
            continue;
        }
        LineSegment baseSG = PS;
        // Reverse Segment
        if (fixedPath == -1) {
            baseSG.exchange();
        }
        baseSG.extendHead(gauge.turn.fishtail.preBackLength);
        LineSegment fullSG = baseSG;
        fullSG.extendHead(gauge.tractor.noseLength);
        fullSG.extendTail(gauge.tractor.tailLength);
        LOGV(LOG_TAG "::seekFishtailAngle", "[RvsSG] %s, length:%g", to_string(baseSG, "BASE:").c_str(), baseSG.length());
        LOGV(LOG_TAG "::seekFishtailAngle", "[RvsSG] %s, length:%g", to_string(fullSG, "FULL:").c_str(), fullSG.length());
        
        // Baoundaryチェック
        collisions.HP = checkBoundaryIntersection(fullSG, BoundaryType::Kind::Mask::HP);
        baseSG.direction = SegmentDir::REVERSE;
        collisions.BP = checkBoundaryIntersection(baseSG, BoundaryType::Kind::Mask::SBP);   // BPはクリアランスつき

        if (collisions.isValid()) {
            // segment is ok
            LOGD(LOG_TAG "::seekFishtailAngle", "Succeed at %dth / %d; angle:%g", i, retries, Degree::convert(baseSG.angle()));
            savedCirc.available = true;
            savedCirc.fixed = fixedCirc;
            savedCirc.floated = floatCirc;
            break;
        } else if (!savedCirc.available && (collisions.BP == Intersection::NO)) {
            // save if first acceptable
            if (checkBoundaryIntersection(baseSG, BoundaryType::Kind::Mask::HP) == Intersection::NO) {
                LOGD(LOG_TAG "::seekFishtailAngle", "Saved sub candidate at %dth / %d; angle:%g", i, retries, Degree::convert(baseSG.angle()));
                savedCirc.available = true;
                savedCirc.fixed = fixedCirc;
                savedCirc.floated = floatCirc;
            }
        }
        
        LOGV(LOG_TAG  "::seekFishtailAngle", "Failed at %dth / %d; angle:%g; Collied BP:0x%x, HP:0x%x", i, retries, Degree::convert(baseSG.angle()), collisions.BP, collisions.HP);
        // post update floating circle for next trial.
        floatCirc.center.y += stepY;
    }

    // setup FPS/SPS
    if (savedCirc.available) {
        LOGV(LOG_TAG "::seekFishtailAngle", "Succeed: make optimized fishtail.");
        // 生成成功
        if (fixedPath == 1) {
            FPS.Circ = savedCirc.fixed;
            SPS.Circ = savedCirc.floated;
        } else {
            FPS.Circ = -savedCirc.floated;
            SPS.Circ = -savedCirc.fixed;
        }
        
        FPS.foot.y = FPS.Circ.center.y;
        SPS.foot.y = SPS.Circ.center.y;
    } else {
        LOGV(LOG_TAG "::seekFishtailAngle", "Failed: will make default fishtail.");
    }
    
    return (savedCirc.available) ? SUCCESS : FAILURE;
}

/**
 フックターン生成
 
 FPS/SPS間のフックターンを生成する。
	- FPS - SPS間隔が直径より小さいことを前提としている。角度条件については検査しない。
	  成功を返しても正しく生成できない条件を与えていた場合は不正なターンパスを返す。
	- 間隔対幅の関係により両ターンサークルが交差する場合、バック不可であれば生成失敗を返す。(外部でフィッシュテールターン適用を期待する)
	  バック不可の場合はこの生成失敗は返さない。
 
 @return 生成結果
 @retval SUCCESS	生成成功
 @retval FALSE		生成失敗(ターンサークルが重なる)
 */
int PathGenerator::createHookTurn() {
    LOGV(LOG_TAG "::createHookTurn", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    traverseInfo.turnType = Turn::Type::HOOK;	// Hook turn
    LOGV(LOG_TAG "::createHookTurn()", "%s\n %s", to_string(FPS, "FPS:").c_str(), to_string(SPS, "SPS:").c_str());

	//gauge.turnRadius : Turn Radius
	const double dir = dirX(SPS.enterPoint(), FPS.leavePoint());
	// Calculate the appropriate turning circle centers for Hook turn
	if (FPS.dir == WorkPath::ASCEND)	// Paths are along positive y-axis
	{
		if (SPS.foot.y > FPS.foot.y) {
			FPS.Circ.center.x = FPS.foot.x - dir * gauge.turnRadius;
			FPS.Circ.center.y = FPS.foot.y;
			SPS.Circ.center.x = SPS.foot.x - dir * gauge.turnRadius;
			SPS.Circ.center.y = SPS.foot.y;
		} else	//yy2<yy1
		{
			FPS.Circ.center.x = FPS.foot.x + dir * gauge.turnRadius;
			FPS.Circ.center.y = FPS.foot.y;
			SPS.Circ.center.x = SPS.foot.x + dir * gauge.turnRadius;
			SPS.Circ.center.y = SPS.foot.y;
		}
	} else	// Paths are along neagative y-axis
	{
		if (SPS.foot.y < FPS.foot.y) {
			FPS.Circ.center.x = FPS.foot.x - dir * gauge.turnRadius;
			FPS.Circ.center.y = FPS.foot.y;
			SPS.Circ.center.x = SPS.foot.x - dir * gauge.turnRadius;
			SPS.Circ.center.y = SPS.foot.y;
		} else	//yy2<yy1
		{
			FPS.Circ.center.x = FPS.foot.x + dir * gauge.turnRadius;
			FPS.Circ.center.y = FPS.foot.y;
			SPS.Circ.center.x = SPS.foot.x + dir * gauge.turnRadius;
			SPS.Circ.center.y = SPS.foot.y;
		}
	}

	// check if hook turn is possible or not
	LOGV(LOG_TAG "::createHookTurn", "FPS circle(%g, %g) - SPS circle(%g, %g) : distance %g", FPS.Circ.center.x, FPS.Circ.center.y, SPS.Circ.center.x, SPS.Circ.center.y, SPS.Circ.distance(FPS.Circ));
	if (SPS.Circ.checkIntersection(FPS.Circ) != Intersection::NO) {
		LOGD(LOG_TAG "::createHookTurn", "FAILURE: turn circles were intersected.");
		// バック可の場合でターンサークルが重なっている
		// - 呼び出し元からリトライする(fishtail適用)
		pathBuffer.clear();
		return FAILURE;
	}
	
	// Cross tangent to the circles
	// dirction of movement on first turn circle
	int RotDir = (int) (-FPS.dir * dirX(FPS.Circ.center, FPS.leavePoint()));

	// Turning circles
	Circle C1(FPS.Circ.center, gauge.turnRadius, RotDir);
	Circle C2(SPS.Circ.center, gauge.turnRadius, -RotDir);
	
	// Tangent between turning circles
    PathSegment PS = getTangent(FPS.getHeadLeg(), C1, C2, TangentDir::FORWARD);
    if (PS.isValid()) {
        LineSegment TS = PS;
        // Returning the Turn Path points
        // Update turn path
        pathBuffer.pushTurnPath(FPS.leavePoint());
        pathBuffer.pushTurnPath(FPS.getPoint(), Circle(FPS.Circ.center, gauge.turnRadius, RotDir));
        pathBuffer.pushTurnPath(TS.point1());
        pathBuffer.pushTurnPath(TS.point2(), Circle(SPS.Circ.center, gauge.turnRadius, -RotDir));
        pathBuffer.pushTurnPath(SPS.getPoint());
        pathBuffer.pushTurnPath(SPS.enterPoint());

        pathBuffer.completeSegment(SPS.enterPoint());
        LOGD(LOG_TAG "::createHookTurn", "SUCCESS");
    }

    pathBuffer.setTurnType(PathParam::Turn::Type::HOOK);
    return SUCCESS;
}

/**
 Uターン生成

 FPS/SPS間のUターンパスを生成する。
	- FPS - SPS間隔が直径と等しいことを前提としている。内部で確認はしないで生成する。
	  許容値を超えた差がある場合は不正なターンパスを生成する。内部で失敗はしない。

 @retval SUCCESS	生成成功
 */
int PathGenerator::createUTurn() {
	LOGV(LOG_TAG "::createUTurn", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
	traverseInfo.turnType = Turn::Type::U;	// U turn

	// パス脚だけ延ばす。ここで失敗させないので接線計算などしてはいけない(必要ない)
	if (FPS.dir == WorkPath::ASCEND)	// dirFL is along positive y-axis direction
	{
		FPS.foot.y = max(FPS.foot.y, SPS.foot.y);
		SPS.foot.y = max(FPS.foot.y, SPS.foot.y);
	} else	// dirFL is along negative y-axis direction
	{
		FPS.foot.y = min(FPS.foot.y, SPS.foot.y);
		SPS.foot.y = min(FPS.foot.y, SPS.foot.y);
	}

	// Define turning circle centres for U turn
	FPS.Circ.center.x = FPS.foot.x + dirX(SPS.enterPoint(), FPS.leavePoint()) * gauge.turnRadius;
	FPS.Circ.center.y = FPS.foot.y;

	int RotDir = (int) (-FPS.dir * dirX(FPS.Circ.center, FPS.leavePoint()));

	// Returning the Turn Path points
	// Update turn path information
	pathBuffer.pushTurnPath(FPS.leavePoint());
	pathBuffer.pushTurnPath(FPS.getPoint(), Circle(FPS.Circ.center, gauge.turnRadius, RotDir));
	pathBuffer.pushTurnPath(SPS.getPoint());
	pathBuffer.pushTurnPath(SPS.enterPoint());

	// デバッグ用
	// マージンがあるので端点は正確には接していない場合がある
	// assert(FPS.Circ.isContact(FPS.getPoint()));
	// assert(SPS.Circ.isContact(SPS.getPoint()));

    pathBuffer.completeSegment(SPS.enterPoint());
  	LOGD(LOG_TAG "::createUTurn", "SUCCESS");

    pathBuffer.setTurnType(PathParam::Turn::Type::U);
    return SUCCESS;
}

/*
 フラットターン生成

 フラットターンを生成して返す。
 
 FPS/SPS間のフラットターンパスを生成する。
	- FPS - SPS間隔が旋回直径より大きいことを前提としている。内部で確認はしないで生成する。
      許容値を超えた差がある場合は不正なターンパスを生成する。内部で失敗はしない。
 
 @retval SUCCESS	生成成功
 */
int PathGenerator::createFlatTurn() {
	LOGV(LOG_TAG "::createFlatTurn", "()");
    auto& FPS = traverseInfo.fps;
    auto& SPS = traverseInfo.sps;
    traverseInfo.turnType = Turn::Type::FLAT;	// Flat turn

	// Define turning circle centres for flat turn
	FPS.Circ.center.x = FPS.foot.x + dirX(SPS.enterPoint(), FPS.leavePoint()) * gauge.turnRadius;
	FPS.Circ.center.y = FPS.foot.y;
	SPS.Circ.center.x = SPS.foot.x - dirX(SPS.enterPoint(), FPS.leavePoint()) * gauge.turnRadius;
	SPS.Circ.center.y = SPS.foot.y;

	// Common tangent to the circles
	// Movement direction on turn
	int RotDir = (int) (-FPS.dir * dirX(FPS.Circ.center, FPS.leavePoint()));

	// Defining both turning circle of flat turn
	Circle C1(FPS.Circ.center, gauge.turnRadius, RotDir);
	Circle C2(SPS.Circ.center, gauge.turnRadius, RotDir);

	// Tangent between turning circle
    PathSegment PS = getTangent(FPS.getHeadLeg(), C1, C2, TangentDir::FORWARD);
    if (PS.isValid()) {
#if (FLATTURN_WHISKER)
        const double rLength = gauge.whisker.backwardLength;
        const double fLength = gauge.whisker.forwardLength;
        LineSegment TS = PS;
        // Returning the Turn Path points
        if (FPS.testWhisker(WhiskerType::FORWARD)) {
            // FPS後(FPSカーブ前)のヒゲ有り
            pathBuffer.pushTurnPath(pathAssembler.getWhiskerForward(FPS.getHeadLeg(), fLength));
        } else {
            // FPS後(FPSカーブ前)のヒゲ無し
            pathBuffer.pushTurnPath(FPS.leavePoint());
        }
        // FPSカーブ
        pathBuffer.pushTurnPath(FPS.getPoint(), Circle(FPS.Circ.center, gauge.turnRadius, RotDir));
        // 接線
        if (FPS.testWhisker(WhiskerType::BACKWARD)) {
            // 接線始点(FPSカーブ後)のヒゲ有り
            pathBuffer.pushTurnPath(pathAssembler.getWhiskerBackward(TS, rLength));
        } else {
            // 接線始点(FPSカーブ後)のヒゲ無し
            pathBuffer.pushTurnPath(TS.point1());
        }
        if (SPS.testWhisker(WhiskerType::FORWARD)) {
            // 接線後端(SPSカーブ前)のヒゲ有り
            auto path = pathAssembler.getWhiskerForward(TS, fLength);
            path.erase(path.cbegin());
            pathBuffer.pushTurnPath(path);
        }
        // SPSカーブ
        pathBuffer.pushTurnPath(TS.point2(), Circle(SPS.Circ.center, gauge.turnRadius, RotDir));
        // SPSへの進入
        if (SPS.testWhisker(WhiskerType::BACKWARD)) {
            // SPS進入前(SPSカーブ後)のヒゲ有り
            pathBuffer.pushTurnPath(pathAssembler.getWhiskerBackward(SPS.getHeadLeg(), rLength));
        } else {
            // SPS進入前(SPSカーブ後)のヒゲ無し
            pathBuffer.pushTurnPath(SPS.getPoint());
        }
        // SPS進入点
        pathBuffer.pushTurnPath(SPS.enterPoint());
        
        pathBuffer.completeSegment(SPS.enterPoint());
#else
        LineSegment TS = PS;
        // Returning the Turn Path points
        pathBuffer.pushTurnPath(FPS.leavePoint());
        pathBuffer.pushTurnPath(FPS.getPoint(), Circle(FPS.Circ.center, gauge.turnRadius, RotDir));
        pathBuffer.pushTurnPath(TS.point1());
        pathBuffer.pushTurnPath(TS.point2(), Circle(SPS.Circ.center, gauge.turnRadius, RotDir));
        pathBuffer.pushTurnPath(SPS.getPoint());
        pathBuffer.pushTurnPath(SPS.enterPoint());
        
        pathBuffer.completeSegment(SPS.enterPoint());
#endif
        LOGV(LOG_TAG "::createFlatTurn", "SUCCESS");
    }

    pathBuffer.setTurnType(PathParam::Turn::Type::FLAT);
    return SUCCESS;
}



}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
#pragma once

#include "PathPlanIF.hpp"

#include <iostream>
#include <list>
#include <vector>
#include <array>
#include <queue>
#include <fstream>

#include "boost/geometry.hpp"

#include "PolyLib/Context.hpp"
#include "Geometry/Geometry.hpp"
#include "OutLib/OutLib.h"
#include "Segment.hpp"
#include "Gauge.hpp"
#include "PathGeneratorData.hpp"
#include "PathGeneratorError.hpp"
#include "PathValidator.hpp"
#include "PathAssembler.hpp"

namespace yanmar { namespace PathPlan {
using namespace std;

/**
 パスデータ生成クラス
 
 パスノード間を結んでパスプランデータを生成するクラス
 */
class StandardTurnGenerator {

	/*
	 * 通常ターン生成関数群
	 */
	int createStandardTurnPath();
	int createUTurn();
	int createFlatTurn();
	int createHookTurn();
	// フィッシュテールターン生成
	int createFishtailTurn();
	int createFishtailTurnPath();

    // 生成中の現在の最新セグメント取得
    PathSegment getLastTangent();
    
	// 通常ターンパスバリデートとリトライ
	void validateTurnPathWithRetry();
};
    
}} // namespace yanmar::PathPlan

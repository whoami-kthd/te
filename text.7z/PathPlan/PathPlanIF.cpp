// Yanmar Confidential 20200918
// 項目名 (csvファイル出力時の項目名, 単位など)

#define LOG_TAG "PathPlan"

#include "PolyLib/Common.h"
#include "PathPlanIF.hpp"
#include "PathLib/PathGeneratorData.hpp"
#include "Geometry/Geometry.hpp"
#include "Geometry/Coordinates.hpp"
#include "PolyLib/Engine.hpp"
#include "PathLib/PathLib.h"
#include "DataConverter/Csv.hpp"
#include "PathLib/IteratorUtils.hpp"

#include <cstddef>
#include <cstdlib>
#include <string>
#include <vector>
#include <stdexcept>
#define _USE_MATH_DEFINES
#include <cmath>

using namespace std;

namespace yanmar { namespace PathPlan {
/**
 コンストラクタ
 @ingroup PathPlanIF
 */
PathPlanning::PathPlanning() :
	impl(new Engine{})
{}

/**
 デストラクタ
 @ingroup PathPlanIF
 */
PathPlanning::~PathPlanning() = default;

/**
 パスプラン生成データ設定

 パスプラン生成データを設定する。
	- 設定パラメータ内容については InputData クラスを参照
	- 設定内容をvalidate()で検査し、検査結果を返す。一部エラーではruntime_errorを投げる。@see validate
	- パス生成前のデータチェックであり、成功してもcreatePathDataで失敗する可能性はある。

 @param[in] inputData パスプラン入力データ
 @see validate()
 @ingroup PathPlanIF
 */
int PathPlanning::setInputData(const InputData& inputData) {
	int result = PathPlan::ResultCode::SUCCESS;

	result = impl->setInputData(inputData);

	return result;
}

/**
  パスプラン生成

 setInputDataで設定済みの入力データに対してパスプラン生成を実行する。
	- パス生成中にエラーが発生し、パスの生成が出来ない場合は例外std::runtime_errorを投げる。
	  エラーの定義内容については @ref PathPlanIF_exception 参照

 @throws runtime_error @ref PathPlanIF_exception
 @ingroup PathPlanIF
 */
void PathPlanning::createPathData() {
    try {
        impl->createPathData();
    } catch (Error& err) {
        throw;
    } catch (std::exception& e) {
        if (Error::isErrorCode(e.what())) {
            // TODO: throw する例外を全てError(もしくはその派生)に置き換えてこの条件を捨てる
            throw;
        } else {
            Error err{PathPlan::ErrorCode::FATAL};
            err.setDescription(e.what());
            throw err;
        }
    }
}

/**
  ABパスプラン生成

 setInputDataで設定済みの入力データに対してABパスプラン生成を実行する。
	- パス生成中にエラーが発生し、パスの生成が出来ない場合は例外std::runtime_errorを投げる。
	  エラーの定義内容については @ref PathPlanIF_exception 参照

 @throws runtime_error @ref PathPlanIF_exception
 @ingroup PathPlanIF
 */
void PathPlanning::createPathDataAB() {
	impl->createPathDataAB();
}

/**
 オート作業可能領域の計算

 setInputDataで設定済みの入力データに対してオート作業可能領域の計算を実行する。
 */
void PathPlanning::calculateWorkablePolygon(GeoPolygon& workablePolygon) {
	impl->calculateWorkablePolygon(workablePolygon);
}

/**
 パスプラン生成可能判定
 */
bool PathPlanning::isPathDataCreatable() {
	return impl->isPathDataCreatable();
}

/**
 推奨中割り回数の計算
 */
int PathPlanning::calculateRecommendNumDivide() {
	return impl->calculateRecommendNumDivide();
}

/**
 処理中止要求
 
 パス生成処理を中止する。ただし非同期要求である。
     - 処理を中断後にcreatePathData()から Exception::Abort 例外を投げる。
     - createPathData()実行前に呼んだ場合、その後createPathData()を呼ぶとabortする。
 */
void PathPlanning::requestAbort() {
    impl->requestAbort();
}
    
/**
 表示用データ取得

 パス生成済みであればディスプレイ用パスデータを返す。
	- パス生成前の場合、空文字列を返す。

 @return ディスプレイ用CSVデータ
 @ingroup PathPlanIF
 */
std::string PathPlanning::getDisplayData() const {
	return impl->getDisplayData();
}

/**
 ガイダンス用データ取得

 パス生成済みであればガイダンス用パスデータを返す。
	- パス生成前の場合、パス部分の無いデータを返す。

 @return ガイダンス用CSVデータ
 @ingroup PathPlanIF
 */
std::string PathPlanning::getGuidanceData() const {
	return impl->getGuidanceData();
}

/**
 適用された枕地幅の最大値(mm)

 パス生成時に適用された枕地幅のうち最大値を返す
	- パス生成前の場合不定

 @return 最大枕地幅(mm)
 @retval 負値:存在しない場合
 @ingroup PathPlanIF
 */
float PathPlanning::getAppliedHeadlandMax() const {
	return (float)(impl->appliedHeadlandMax * 1000.0);
}

/**
 適用されたサイドマージンの最大値

 パス生成時に適用されたサイドマージン幅のうち最大値を返す
	- パス生成前の場合不定

 @return 最大サイドマージン幅(mm)
 @retval 負値:存在しない場合
 @ingroup PathPlanIF
 */
float PathPlanning::getAppliedSideMarginMax() const {
	return (float)(impl->appliedSideMarginMax * 1000.0);
}

/**
 適用された枕地幅の最大値がパス間隔の何倍に相当するか

 パス生成時に適用された枕地幅の最大値がパス間隔の何倍に相当するかを返す
 - パス生成前の場合不定

 @return 最大枕地幅がパス間隔の何倍に相当するか
 @ingroup PathPlanIF
 */
int PathPlanning::getAppliedHeadlandN() const {
	return impl->appliedHeadlandN;
}

/**
 適用されたサイドマージンの最大値がパス間隔の何倍に相当するか

 パス生成時に適用されたサイドマージン幅の最大値がパス間隔の何倍に相当するかを返す
 - パス生成前の場合不定

 @return 最大サイドマージン幅がパス間隔の何倍に相当するか
 @ingroup PathPlanIF
 */
int PathPlanning::getAppliedSideMarginN() const {
	return impl->appliedSideMarginN;
}

/**
 枕地幅/サイドマージンの計算方法が2:パス間隔整数倍(統一)の場合に、計算上で目標としたN値

 - 計算方法が2:パス間隔整数倍(統一)以外の場合、0

 @return 計算上で目標としたN値
 @ingroup PathPlanIF
 */
int PathPlanning::getHeadlandSideMarginFactorUnityN() const {
	return impl->headlandSideMarginFactorUnityN;
}

/**
 圃場面積

 - パス生成前の場合不定

 @return 圃場面積
 @ingroup PathPlanIF
 */
double PathPlanning::getFieldArea() const {
	return impl->fieldArea;
}

/**
 実作業面積

 UI側で言うところの塗りつぶし面積
 - パス生成前の場合不定

 @return 実作業面積
 @ingroup PathPlanIF
 */
double PathPlanning::getEffectiveArea() const {
	return impl->effectiveArea;
}

/**
 ABパスをトラクターの現在地基準で生成した場合のシフト量

 - パス生成前の場合不定

 @return シフト量(mm)
 @ingroup PathPlanIF
 */
double PathPlanning::getShiftAB() const {
	return impl->tractorShiftAB * 1000.0;
}

/**
 1本目の作業パスの始点と終点を取得します
 */
void PathPlanning::getFirstWorkingPath(GeoPoint &p1, GeoPoint &p2) const {
    p1 = impl->firstWorkingPathP1;
    p2 = impl->firstWorkingPathP2;
}

/**
 外周作業の周回数
 */
double PathPlanning::getOrbitalLaps() {
	return impl->orbitalLaps;
}

/// デフォルトコンストラクタ
InputData::InputData() :
    meta(),
	field(),
	tractors(0),
	work()
{}

/**
 ログ出力先設定

 デバッグ用ログの出力先パスを指定する
    - デフォルトのログ出力先は LOG_DIR 定数で指定されているパスである。
    - パスプランはログ出力パスが予め存在する場合にのみログ出力を行う。当関数で設定してもディレクトリ作成は行わない。

 @param[in] path ログ出力先パス
 */
void PathPlanning::setLogPath(const std::string& path) {
    auto right = path.find_last_not_of("/\\");
    impl->logDir = path.substr(0, right + 1);
    impl->logDir += "/";
}

/**
 設定値検査

 設定値を検査する。主にデバッグ用。一部エラーについては例外を投げる。
 
 @return 検査結果
 @retval ResultCode::Param::SUCCESS (0) パスした
 @retval その他エラー
 @see ResultCode::Param
 @see ErrorCode::Input
 */
int InputData::validate() const {

	// トラクター設定
	if (tractors.size() < 1) {
		LOGE(LOG_TAG, "[InputData:ERROR] too less number of tractors.");
		return ResultCode::Param::Tractor::LESS;
	}
    // - 現状、トラクターは2台以内
	if (tractors.size() > 2) {
		LOGE(LOG_TAG, "[InputData:ERROR] too many number of tractors: %d", (int)tractors.size());
		return ResultCode::Param::Tractor::MANY;
	}

    // ロボットトラクター
	const auto& tractor0 = tractors[0];
    // - トラクター幅
    if (tractor0.width < 1.0) {
        LOGE(LOG_TAG, "[InputData:ERROR] invalid tractor dimansions. %g", tractor0.width);
        throw runtime_error(ErrorCode::Input::Tractor::DIMENSION);
    }

    // - 旋回半径
    if (tractor0.turnRadius < 1.0) {
        LOGE(LOG_TAG, "[InputData:ERROR] invalid tractor turn radius. %g", tractor0.turnRadius);
        throw runtime_error(ErrorCode::Input::Tractor::PARAM);
    }
    
    // 有人トラクター
    if (tractors.size() > 1) {
        // - 作業幅
        const auto& tractor1 = tractors[1];
        if (tractor1.implement.cultivationWidth < 1.0) {
            LOGE(LOG_TAG, "[InputData:ERROR] invalid implement cultivationWidth. %g", tractor1.implement.cultivationWidth);
            throw runtime_error(ErrorCode::Input::Tractor::PARAM);
        }
    }

	// 圃場設定
	if (field.outline.size() < 3) {
		// 圃場の頂点が少なすぎる
		LOGE(LOG_TAG, "[InputData:ERROR] too less number of field vertices.");
		return ResultCode::Param::Field::LESS;
	}

	if (field.outline.size() > 30) {
		// 圃場の頂点が多すぎる
		LOGD(LOG_TAG, "[InputData:WARN] too many number of field vertices.");
		return ResultCode::Param::Field::MANY;
	}

	if (field.obstacles.size() > 3) {
		// 障害物が多すぎる
		LOGE(LOG_TAG, "[InputData:WARN] too many number of obstacles.");
		return ResultCode::Param::Obstacle::MANY;
	}

	for (auto obstacle : field.obstacles) {
		// 障害物の頂点が少なすぎる
		if (obstacle.size() < 3) {
			LOGE(LOG_TAG, "[InputData:ERROR] too less obstacle vertices.");
			return ResultCode::Param::Obstacle::VERTEX;
		}
	}

	// 作業設定
	if (work.overlapWidth >= tractor0.implement.cultivationWidth) {
		// オーバーラップ幅が広すぎる(作業進捗方向が逆向き、もしくは全く進行しなくなってしまう)
		LOGE(LOG_TAG, "[InputData:ERROR] too wide of overlapWidth.");
		throw runtime_error("E-PP-999");
	}

	if (work.workPattern == Param::Work::Pattern::UNIDIRECTION) {
		// 単方向のとき
		if (work.numSkip != 0) {
			// スキップパターンは選択不可
			LOGE(LOG_TAG, "[InputData:ERROR] conflicts: unidirection with interleave (skip) path.");
			return ResultCode::Param::Work::CONFLICT_DIRECTION;
		}
	}

	if (work.numSkip != 0) {
		// スキップ有りのとき
		if (tractors.size() > 1 && tractors[1].followPos != Param::Tractor::FollowPos::CENTER) {
			// 有人トラクターの並走はできない(追走は可能)
			LOGE(LOG_TAG, "[InputData:ERROR] conflicts: interleave (skip) path pattern with parallel manned tractor.");
			return ResultCode::Param::Work::CONFLICT_SKIPNUM;
		}
	}

	return ResultCode::Param::SUCCESS;
}

/** テスト用サンプルデータ */
InputData InputData::getSampleData() {

	InputData inData;
	Tractor tractor0;
	Tractor tractor1;

	// 走行位置
	tractor0.followPos = Param::Tractor::FollowPos::UNDEFINED;

	// 機種名
	tractor0.model = "YT5113";
	// トラクター幅
	tractor0.width = 2100.0;
	// ホイールベース
	tractor0.wheelbase = 2400.0;
	// トラクター高さ
	tractor0.height = 2750.0;
	// 旋回半径
	tractor0.turnRadius = 5000.0;

	// GNSSアンテナから後車軸までの長さ
	tractor0.gnss.lengthToRearAxle = 1000.0;
	// GNSSアンテナからフロントウェイトまでの長さ
	tractor0.gnss.lengthToFrontEnd = 2500.0;
	// GNSSアンテナからロアリンクまでの長さ
	tractor0.gnss.lengthToRearEnd = 1980.0;

	// 作業機取り付け位置
	tractor0.implement.pos = Param::Implement::Pos::CENTER;
	// 作業機取り付け方法
	tractor0.implement.mountType = Param::Implement::MountType::HITCH;
	// ロアリンクから作業機後端までの長さ
	tractor0.implement.length = 840;
	// ロアリンクから作業中心までの長さ
	tractor0.implement.cultivationPos = 600.0;
	// 作業機重量
	tractor0.implement.mass = 1000.0;
	// 作業機幅
	tractor0.implement.width = 2500.0;
	// 作業(耕運)幅
	tractor0.implement.cultivationWidth = 2400.0;

	inData.tractors.clear();
	inData.tractors.push_back(tractor0);

	// 作業時PTO設定
	inData.work.workingPtoMode = Param::Work::PtoMode::UNDEFINED;
	// 枕地PTO設定
	inData.work.headlandPtoMode = Param::Work::PtoMode::UNDEFINED;
	// 枕地ヒッチ設定
	inData.work.headlandHitchMode = Param::Work::HitchMode::UNDEFINED;

	// 単方向/双方向フラグ
	inData.work.workPattern = Param::Work::Pattern::BIDIRECTION;
	// パスのスキップ数
	inData.work.numSkip = 0;
	// 作業パスのオーバーラップ
	inData.work.overlapWidth = 0;

	// 枕地幅/サイドマージンの計算方法
	inData.work.headlandSideMarginType = Param::Work::HeadlandSideMarginType::MINIMUM;
	// 枕地幅
	inData.work.headlandWidthValue = 0;
	// サイドマージン
	inData.work.marginWidthValue = 0;

	// バック(後進)可能フラグ
	inData.work.canBackward = true;
	// 作業パスの接続方式
	inData.work.progressType = Param::Work::ProgressType::BLOCK;

	PathPlan::Field& field = inData.field;
	field.outline.push_back(GeoPoint{35.0000, 135.0000});
	field.outline.push_back(GeoPoint{35.0000, 135.0010});
	field.outline.push_back(GeoPoint{35.0010, 135.0010});
	field.outline.push_back(GeoPoint{35.0010, 135.0000});
	field.setRefPos(field.outline.front());
	field.start = GeoPoint{35.0000, 135.0000};
	field.end = GeoPoint{35.0000, 135.0000};
	field.endPointAvailable = true;
	field.directionPoints[0] = GeoPoint{35.0000, 135.0010};
	field.directionPoints[1] = GeoPoint{35.0000, 135.0000};
	field.endPointAvailable = true;
	field.bs.type = Param::BaseStation::Type::YANMAR;
	field.bs.pos = GeoPoint{35.0000, 135.0000};

	return inData;
}

std::ostream& operator<<(std::ostream& os, const GeoPoint& point) {
    os << std::fixed << std::setprecision(7);
	os << '(' << point.lat << ", " << point.lon << ')';
	return os;
}

std::ostream& operator<<(std::ostream& os, const GeoPointList& list) {
	for (const auto& value : list) {
		os << value << EOL;
	}
	return os;
}

std::ostream& operator<<(std::ostream& os, const Point3D& point3D) {
	os << '(' << point3D.x << ", " << point3D.y << ", " << point3D.z << ')';
	return os;
}

std::ostream& operator<<(std::ostream& os, const GeoPolygonList& list) {
	for (const auto& value : list) {
		os << value << EOL;
	}
	return os;
}

/**
 入力データフォーマットオペレータ
 
 パスプラン入力パラメータInputDataをOutputDataStreamに入力し、出力用文字列にフォーマットする
 */
std::ostream& operator<<(std::ostream& os, const InputData& inData) {
    Tractor tractor1;
    
    // bool値を文字列表示
    const auto saveflags = os.flags();
    os << std::boolalpha << std::fixed << setprecision(15);
    
    if (1 <= inData.tractors.size()) {
        const Tractor& tractor0 = inData.tractors[0];
        const ObstacleSensor& obstacleSensor = tractor0.obstacleSensor;
        const Implement& implement0 = tractor0.implement;
        const GNSS& gnss = tractor0.gnss;
        // tractor0
        os << "[InputData]" << EOL;
        os << "TractorFollowPos,"		<< tractor0.followPos		<< ",0:UNDEFINED(LEAD)/2:CENTER(FOLLOW)/5:PARALLEL" << EOL;
        os << "TractorModel  (TM),"		<< tractor0.model			<< ",string" << EOL;
        os << "TractorWidth  (TW),"		<< tractor0.width           << EOL;
        os << "TractorHeight (TH),"		<< tractor0.height          << EOL;
        os << "Wheelbase     (WB),"		<< tractor0.wheelbase       << EOL;
        os << "TractorTurnRadius (TR),"	<< tractor0.turnRadius      << EOL;
        os << "GNSSToFrontLIDAR (OLF),"	<< obstacleSensor.gnssToFrontLidar << ",Length from GNSS to Obstacle Sensor(front LIDAR)" << EOL;
        os << "GNSSToRearLIDAR  (OLR),"	<< obstacleSensor.gnssToRearLidar  << ",Length from GNSS to Obstacle Sensor(rear LIDAR)" << EOL;
        os << "RearAxleToYawCenter (YLRT),"	<< tractor0.rearAxleToYawCenter << ",Length from rear axle to yaw center" << EOL;
        // tractor0.gnss
        os << "GNSSToFrontEnd   (TLF),"	<< gnss.lengthToFrontEnd	<< EOL;
        os << "GNSSToRearEnd    (TLR),"	<< gnss.lengthToRearEnd     << EOL;
        os << "GNSSToRearAxle  (TLRT),"	<< gnss.lengthToRearAxle	<< EOL;
        // tractor0.implement
        os << "ImplementPos,"			<< implement0.pos				<< ",0:UNDEFINED/1:RIGHT/2:REAR/4:LEFT/8:FRONT" << EOL;
        os << "Implement_canBackward,"  << implement0.canBackward       << ",Backward maneuver capavility of implement." << EOL;
        os << "ImplementLength   (IL)," << implement0.length            << EOL;
        os << "MountType        (IMP)," << implement0.mountType         << ",0:HITCH/1:DRAWBAR" << EOL;
        os << "CultivationPos   (ILW),"	<< implement0.cultivationPos    << EOL;
        os << "ImplementWidth    (IW),"	<< implement0.width				<< EOL;
        os << "CultivationWidth (IWW),"	<< implement0.cultivationWidth	<< EOL;
        os << "ImplementWidthOffset  (ILTC)," << implement0.widthOffset << ",offset implement width center from tractor center.(mm)"   << EOL;
        os << "CultivationWidthOffset (IWO)," << implement0.cultivationWidthOffset << ",offset cultivation width center from tractor center.(mm)"   << EOL;
        os << "ImplementOverhang (IO)," << implement0.overhang          << ",no cultivation space in the implement width at inside edge.(mm)"  << EOL;
        os << "ImplementMass (IM),"		<< implement0.mass				<< EOL;
    }
    
    if (2 <= inData.tractors.size()) {
        tractor1 = inData.tractors[1];
        // tractor1
        os << "2ndTractorFollowPos,"	<< tractor1.followPos			<< ",0:UNDEFINED(LEAD)/2:CENTER(FOLLOW)/5:PARALLEL" << EOL;
        os << "2ndTractorWidth,"		<< tractor1.width                        << EOL;
        os << "2ndImplementWidth,"		<< tractor1.implement.width              << EOL;
        os << "2ndCultivationWidth,"	<< tractor1.implement.cultivationWidth   << EOL;
    }
    
    // WorkSettings
    const WorkSetting& work = inData.work;
    os << "WorkPattern,"            << work.workPattern             << ",1:UNIDIRECTION/2:BIDIRECTION/3:CYCLONE/4:SEMICYCLONE/5:ANTICYCLONE" << EOL;
    os << "WorkRotation,"           << work.rotation                << ",-1:CLOCKWISE/1:ANTICLOCKWISE" << EOL;
    os << "Headland_Process,"       << work.headland.process        << ",0:NOP/1:PRE/2:POST" << EOL;
    const auto& workPath = work.workPath;
    os << "WorkPath_LegType,"       << workPath.leg.type            << ",0:STRAIGHT/1:FOLD" << EOL;
    os << "WorkPath_Leg_Front_PreBack_mode," << workPath.leg.front.preBack.mode  << ",0:DISABLE/1:FIXED/2:LIMIT_MIN/3:LIMIT_MAX" << EOL;
    os << "WorkPath_Leg_Front_PreBack_value," << workPath.leg.front.preBack.value << ",for front leg of workpath(as rear leg of turn)" << EOL;
    const auto& headland = work.headland;
    os << "Headland_Pattern,"       << headland.pattern        << ",0:UNDEFIEND/3:CYCLONE/4:SEMICYCLONE/5:ANTICYCLONE" << EOL;
    os << "Headland_Rotation,"      << headland.rotation       << ",-1:CLOCKWISE/1:ANTICLOCKWISE" << EOL;
    os << "Headland_CornerTurn,"    << headland.cornerTurn     << ",0:ALTERNATIVE/1:BREAK_IF_ALT/2:ABORT_IF_ALT" << EOL;
    // - others
    os << "WorkingPtoMode (WP),"    << work.workingPtoMode          << ",0:OFF/1:ON/2:UNUSED/3:UNDEFINED" << EOL;
    os << "HeadlandPtoMode (HP),"   << work.headlandPtoMode         << ",0:OFF/1:ON/2:UNUSED/3:UNDEFINED" << EOL;
    os << "HeadlandHitchMode (HH)," << work.headlandHitchMode       << ",0:KEEP/1:UP/2:UNUSED/3:UNDEFINED" << EOL;
    os << "driveSystem (DS),"       << work.driveSystem             << ",0:UNDEFINED/1:2WD/2:AUTO BREAK(2WD)/3:4WD/4:AUTO-BREAK/5:DOUBLE-SPEED/DOUBLE-SPEED+AUTO-BREAK/7:2WD at TURN/:2WD at TURN+AUTO BREAK" << EOL;
    os << "NumSkip,"                << work.numSkip                 << ",num of working path" << EOL;
    os << "OverlapWidth,"           << work.overlapWidth            << EOL;
    os << "HeadlandSideMarginType,"	<< work.headlandSideMarginType	<< ",0:MINIMUM/1:FACTOR_EACH/2:FACTOR_UNITY" << EOL;
    os << "HeadlandWidth,"			<< work.headlandWidthValue		<< EOL;
    os << "SideMarginWidth,"		<< work.marginWidthValue		<< EOL;
    os << "CanBackward,"			<< work.canBackward				<< ",bool, backward maneuver permission by user." << EOL;
    os << "SkipPathProgressType,"	<< work.progressType			<< ",0:NORMAL/1:BLOCK" << EOL;
    os << "NumOfDivide,"            << work.numDivide               << ",times of divide" << EOL;
    os << "HitchUpDownMargin,"      << work.hitchUpDownMargin       << ",to compensate for hitch up/down timing at the both ends of working segment." << EOL;

    // field
    const Field& field = inData.field;
    
    // field.bs
    os << "BaseStationType (BS),"	<< field.bs.type				<< ",0:YANMAR/1:PUBLIC" << EOL;
    os << "BaseStationLat (LLAT),"	<< field.bs.pos.lat				<< ",degree" << EOL;
    os << "BaseStationLon (LLON),"	<< field.bs.pos.lon				<< ",degree" << EOL;
    
    // field.start
    os << "StartPoint (SP),"		<< field.start.lat << "," << field.start.lon << EOL;
    // field.end
    os << "EndPoint (EP),";
    if (field.endPointAvailable) {
        os << field.end.lat << "," << field.end.lon << EOL;
    } else {
        os << "N/A" << EOL;
    }
    // field.directionPoints
    os << "DirectionPoints," << field.directionPoints.size() << EOL;
    for (const auto& point: field.directionPoints) {
        os << "," << point.lat << "," << point.lon << EOL;
    }
    
    // Field parameters ouline point list
    os << "FieldPoints" << "," << field.outline.size() << EOL;
    for (const auto& point: field.outline) {
        os << "," << point.lat << "," << point.lon << EOL;
    }
    
    os << "WorkedSegments" << "," << field.workedSegments.size() << EOL;
    for (const auto& seg : field.workedSegments) {
        auto& p1 = seg[0];
        auto& p2 = seg[1];
        os << "," << p1.lat << "," << p1.lon << "," << p2.lat << "," << p2.lon << EOL;
    }
    
    // Obstacle ouline point list
    const auto& obstacles = field.obstacles;
    for (auto it = obstacles.begin(); it != obstacles.end(); ++it) {
        const int count = (int)distance(field.obstacles.begin(), it);
        os << "Obstacle" << count << "," << it->size() << EOL;
        os << *it;
    }
    
    os.setf(saveflags);
    return os;
}

/**
 * 文字列(operator<<の出力結果)からInputDataを生成(復元)する
 */
InputData InputData::fromCsvString(const std::string& csvString) {

	Csv::CsvData csvData = Csv::CsvData(csvString);
	InputData inData;
    // Tractor and Implement
	Tractor tractor0;
	tractor0.followPos = boost::lexical_cast<int>(csvData.row("TractorFollowPos")[1]);
	tractor0.model = csvData.row("TractorModel  (TM)")[1];
	tractor0.width  = boost::lexical_cast<double>(csvData.row("TractorWidth  (TW)")[1]);
	tractor0.height = boost::lexical_cast<double>(csvData.row("TractorHeight (TH)")[1]);
	tractor0.wheelbase  = boost::lexical_cast<double>(csvData.row("Wheelbase     (WB)")[1]);
	tractor0.turnRadius = boost::lexical_cast<double>(csvData.row("TractorTurnRadius (TR)")[1]);
	tractor0.obstacleSensor.gnssToFrontLidar = boost::lexical_cast<double>(csvData.row("GNSSToFrontLIDAR (OLF)")[1]);
	tractor0.obstacleSensor.gnssToRearLidar  = boost::lexical_cast<double>(csvData.row("GNSSToRearLIDAR  (OLR)")[1]);
	tractor0.rearAxleToYawCenter = boost::lexical_cast<double>(csvData.row("RearAxleToYawCenter (YLRT)")[1]);
	tractor0.gnss.lengthToFrontEnd = boost::lexical_cast<double>(csvData.row("GNSSToFrontEnd   (TLF)")[1]);
	tractor0.gnss.lengthToRearEnd  = boost::lexical_cast<double>(csvData.row("GNSSToRearEnd    (TLR)")[1]);
	tractor0.gnss.lengthToRearAxle = boost::lexical_cast<double>(csvData.row("GNSSToRearAxle  (TLRT)")[1]);
	tractor0.implement.pos = boost::lexical_cast<int>(csvData.row("ImplementPos")[1]);
	tractor0.implement.canBackward = (csvData.row("Implement_canBackward")[1] == "true");
	tractor0.implement.length = boost::lexical_cast<double>(csvData.row("ImplementLength   (IL)")[1]);
	tractor0.implement.mountType = boost::lexical_cast<int>(csvData.row("MountType        (IMP)")[1]);
	tractor0.implement.cultivationPos = boost::lexical_cast<double>(csvData.row("CultivationPos   (ILW)")[1]);
	tractor0.implement.width = boost::lexical_cast<double>(csvData.row("ImplementWidth    (IW)")[1]);
	tractor0.implement.cultivationWidth = boost::lexical_cast<double>(csvData.row("CultivationWidth (IWW)")[1]);
	tractor0.implement.widthOffset = boost::lexical_cast<double>(csvData.row("ImplementWidthOffset  (ILTC)")[1]);
	tractor0.implement.cultivationWidthOffset = boost::lexical_cast<double>(csvData.row("CultivationWidthOffset (IWO)")[1]);
	tractor0.implement.overhang = boost::lexical_cast<double>(csvData.row("ImplementOverhang (IO)")[1]);
	tractor0.implement.mass = boost::lexical_cast<double>(csvData.row("ImplementMass (IM)")[1]);
	inData.tractors.clear();
	inData.tractors.push_back(tractor0);
	Csv::CsvData::row_type row_2ndTractorFollowPos = csvData.row("2ndTractorFollowPos");
	if (row_2ndTractorFollowPos != csvData.nullrow) {
		Tractor tractor1;
		tractor1.followPos = boost::lexical_cast<double>(row_2ndTractorFollowPos[1]);
		tractor1.width = boost::lexical_cast<double>(csvData.row("2ndTractorWidth")[1]);
		tractor1.implement.width = boost::lexical_cast<double>(csvData.row("2ndImplementWidth")[1]);
		tractor1.implement.cultivationWidth = boost::lexical_cast<double>(csvData.row("2ndCultivationWidth")[1]);
		inData.tractors.push_back(tractor1);
	}

    // WorSettings
	inData.work.workPattern = boost::lexical_cast<int>(csvData.row("WorkPattern")[1]);
	inData.work.rotation = boost::lexical_cast<int>(csvData.row("WorkRotation")[1]);
    // - WorkPath(raster)
    auto workPath_LegType = csvData.row("WorkPath_LegType");
    if (workPath_LegType != csvData.nullrow) {
        inData.work.workPath.leg.type = boost::lexical_cast<int>(workPath_LegType[1]);
        auto WorkPath_Leg_Front_PreBack_mode = csvData.row("WorkPath_Leg_Front_PreBack_mode");
        if (WorkPath_Leg_Front_PreBack_mode != csvData.nullrow) {
            inData.work.workPath.leg.front.preBack.mode = boost::lexical_cast<int>(WorkPath_Leg_Front_PreBack_mode[1]);
            if (inData.work.workPath.leg.front.preBack.mode != OptionMode::DISABLED) {
                inData.work.workPath.leg.front.preBack.value = boost::lexical_cast<int>(csvData.row("WorkPath_Leg_Front_PreBack_value")[1]);
            }
        }
    }
    // - Headland(orbital)
	inData.work.headland.process = boost::lexical_cast<int>(csvData.row("Headland_Process")[1]);
	inData.work.headland.pattern = boost::lexical_cast<int>(csvData.row("Headland_Pattern")[1]);
	inData.work.headland.rotation = boost::lexical_cast<int>(csvData.row("Headland_Rotation")[1]);
	inData.work.headland.cornerTurn = boost::lexical_cast<int>(csvData.row("Headland_CornerTurn")[1]);
    // - others
	inData.work.workingPtoMode = boost::lexical_cast<int>(csvData.row("WorkingPtoMode (WP)")[1]);
	inData.work.headlandPtoMode = boost::lexical_cast<int>(csvData.row("HeadlandPtoMode (HP)")[1]);
	inData.work.headlandHitchMode = boost::lexical_cast<int>(csvData.row("HeadlandHitchMode (HH)")[1]);
	inData.work.driveSystem = boost::lexical_cast<int>(csvData.row("driveSystem (DS)")[1]);
	inData.work.numSkip = boost::lexical_cast<int>(csvData.row("NumSkip")[1]);
	inData.work.overlapWidth = boost::lexical_cast<double>(csvData.row("OverlapWidth")[1]);
	inData.work.headlandSideMarginType = boost::lexical_cast<int>(csvData.row("HeadlandSideMarginType")[1]);
	inData.work.headlandWidthValue = boost::lexical_cast<double>(csvData.row("HeadlandWidth")[1]);
	inData.work.marginWidthValue = boost::lexical_cast<double>(csvData.row("SideMarginWidth")[1]);
	inData.work.canBackward = (csvData.row("CanBackward")[1] == "true");
	inData.work.progressType = boost::lexical_cast<int>(csvData.row("SkipPathProgressType")[1]);
	inData.work.numDivide = boost::lexical_cast<int>(csvData.row("NumOfDivide")[1]);
	inData.work.hitchUpDownMargin = boost::lexical_cast<double>(csvData.row("HitchUpDownMargin")[1]);
    
    // Field
	inData.field.bs.type = boost::lexical_cast<int>(csvData.row("BaseStationType (BS)")[1]);
	inData.field.bs.pos.lat = boost::lexical_cast<double>(csvData.row("BaseStationLat (LLAT)")[1]);
	inData.field.bs.pos.lon = boost::lexical_cast<double>(csvData.row("BaseStationLon (LLON)")[1]);
	Csv::CsvData::row_type row_StartPoint = csvData.row("StartPoint (SP)");
	inData.field.start.lat = boost::lexical_cast<double>(row_StartPoint[1]);
	inData.field.start.lon = boost::lexical_cast<double>(row_StartPoint[2]);
	Csv::CsvData::row_type row_EndPoint = csvData.row("EndPoint (EP)");
	if (row_EndPoint.size() > 2) {
		inData.field.endPointAvailable = true;
		inData.field.end.lat = boost::lexical_cast<double>(row_EndPoint[1]);
		inData.field.end.lon = boost::lexical_cast<double>(row_EndPoint[2]);
	} else {
		// row_EndPoint[1] == "N/A"
		inData.field.endPointAvailable = false;
	}
	int size_DirectionPoints = boost::lexical_cast<int>(csvData.row("DirectionPoints")[1]);
	Csv::CsvData::data_store directionPoints = csvData.getRows("DirectionPoints");
	for (int i = 0; i < size_DirectionPoints; ++i) {
		double lat = boost::lexical_cast<double>(directionPoints[i][1]);
		double lon = boost::lexical_cast<double>(directionPoints[i][2]);
		inData.field.directionPoints[i] = GeoPoint(lat, lon);
	}
	inData.field.outline.clear();
	int size_FieldPoints = boost::lexical_cast<int>(csvData.row("FieldPoints")[1]);
	Csv::CsvData::data_store fieldPoints = csvData.getRows("FieldPoints");
	for (int i = 0; i < size_FieldPoints; ++i) {
		double lat = boost::lexical_cast<double>(fieldPoints[i][1]);
		double lon = boost::lexical_cast<double>(fieldPoints[i][2]);
		inData.field.outline.push_back(GeoPoint(lat, lon));
	}
	inData.field.workedSegments.clear();
	int size_WorkedSegments = boost::lexical_cast<int>(csvData.row("WorkedSegments")[1]);
	Csv::CsvData::data_store workedSegments = csvData.getRows("WorkedSegments");
	for (int i = 0; i < size_WorkedSegments; ++i) {
		double p1_lat = boost::lexical_cast<double>(workedSegments[i][1]);
		double p1_lon = boost::lexical_cast<double>(workedSegments[i][2]);
		double p2_lat = boost::lexical_cast<double>(workedSegments[i][3]);
		double p2_lon = boost::lexical_cast<double>(workedSegments[i][4]);
		GeoSegment geoSegment = { GeoPoint(p1_lat, p1_lon), GeoPoint(p2_lat, p2_lon) };
		inData.field.workedSegments.push_back(geoSegment);
	}
	inData.field.obstacles.clear();
	// TODO:障害物の読み込みは未実装

	return inData;
}

/**
 * デバッグダンプ
 */
std::ostream& InputData::dumpTo(ostream& osField, ostream& osTractor, ostream& osWork) const {
	osField << "[InputData values]\n";

	// 圃場設定
	field.dumpTo(osField);

	// トラクター情報
	int i = 0;
	for (auto it = tractors.begin(); it != tractors.end(); ++it) {
		osTractor << "[Tractor" << i << "values]" << EOL;
		it->dumpTo(osTractor);
		i++;
	}

	// 作業設定
	work.dumpTo(osWork);

	return osField;
}

std::ostream& operator<<(std::ostream& os, const GNSS& gnss) {
	os << "[GNSS values]" << EOL;
	os << "lengthToRearAxle: " << gnss.lengthToRearAxle << EOL;
	os << "lengthToFrontEnd: " << gnss.lengthToFrontEnd << EOL;
	os << "lengthToRearEnd:  " << gnss.lengthToRearEnd << EOL;
	return os;
}

std::ostream& operator<<(std::ostream& os, const Implement& implement) {
	os << "[Implement values]" << EOL;
	os << "pos:              " << implement.pos  << EOL;
	os << "mountType:        " << implement.mountType  << EOL;
	os << "length:           " << implement.length << EOL;
	os << "cultivationPos:   " << implement.cultivationPos << EOL;
	os << "mass:             " << implement.mass << EOL;
	os << "width:            " << implement.width << EOL;
	os << "cultivationWidth: " << implement.cultivationWidth << EOL;
    os << "widthOffset:            " << implement.widthOffset << EOL;
    os << "cultivationWidthOffset: " << implement.cultivationWidthOffset << EOL;
	return os;
}

std::ostream& Field::dumpTo(ostream& os) const {
    os << std::fixed << std::setprecision(15);
	os << "[Field values]" << EOL;
	os << "bs.type:            " << bs.type << EOL;
	os << "bs.pos:             " << bs.pos << EOL;
	os << "start:              " << start << EOL;
	os << "end:                " << end << EOL;
	os << "directionPoints[0]: " << directionPoints[0] << EOL;
	os << "directionPoints[1]: " << directionPoints[1] << EOL;
	os << "tractorPos:         " << tractorPos << EOL;
	os << "refpos:             " << refPos << EOL;
	os << "outline:\n" << outline;
	os << "obstacles:\n " << obstacles;
	return os;
}

std::ostream& Tractor::dumpTo(ostream& os) const {
	os << "[Tractor values]" << EOL;
	os << "followPos:  " << followPos << EOL;
	os << "model:      " << model << EOL;
	os << "width:      " << width << EOL;
	os << "wheelbase:  " << wheelbase << EOL;
	os << "height:     " << height << EOL;
	os << "turnRadius: " << turnRadius << EOL;
	os << gnss << EOL;
	os << implement << EOL;
	return os;
}

std::ostream& WorkSetting::dumpTo(ostream& os) const {
	os << "[WorkSetting values]" << EOL;
	os << "workingPtoMode:         " << workingPtoMode << EOL;
	os << "headlandPtoMode:        " << headlandPtoMode << EOL;
	os << "headlandHitchMode:      " << headlandHitchMode << EOL;
    os << "driveSystem:            " << driveSystem << EOL;
	os << "workPattern:            " << workPattern << EOL;
    os << "workRotation:           " << rotation << EOL;
    os << "headland.process:       " << headland.process << EOL;
    os << "headland.pattern:       " << headland.pattern << EOL;
    os << "headland.rotation:      " << headland.rotation << EOL;
    os << "headland.restriction:   " << headland.restriction << EOL;
    os << "numSkip:                " << numSkip << EOL;
    os << "overlapWidth:           " << overlapWidth << EOL;
    os << "headlandSideMarginType: " << headlandSideMarginType << EOL;
    os << "headlandWidthValue:     " << headlandWidthValue << EOL;
    os << "marginWidthValue:       " << marginWidthValue << EOL;
    os << "canBackward:            " << canBackward << EOL;
    os << "progressType:           " << progressType << EOL;
    os << "hitchUpDownMargin:      " << hitchUpDownMargin << EOL;
    os << "numDivide:              " << numDivide << EOL;
	return os;
}

/**
 角度単位変換
 
 内容の角度値を指定の単位系に変換する。
 
 @param[in] unit   変換先単位系(RADIAN, DEGREE)
 */
void Field::convAngleUnitTo(const AngleUnit& unit) {
	LOGV(LOG_TAG ":Field", "convAngleUnitTo()\n");
	unit.convert(outline);
	for (auto &obstacle : obstacles) {
		unit.convert(obstacle);
	}
	for (auto &segment : workedSegments) {
		unit.convert(segment);
	}
	LOGV(LOG_TAG ":Field", "start (%g, %g)\n", start.lat, start.lon);
	LOGV(LOG_TAG ":Field", "end (%g, %g)\n", end.lat, end.lon);
	start = unit.convert(start);
	end = unit.convert(end);
	LOGV(LOG_TAG ":Field", "start (%g, %g)\n", start.lat, start.lon);
	LOGV(LOG_TAG ":Field", "end (%g, %g)\n", end.lat, end.lon);
	directionPoints[0] = unit.convert(directionPoints[0]);
	directionPoints[1] = unit.convert(directionPoints[1]);
	LOGV(LOG_TAG ":Field", "directionPoints[0] (%g, %g)\n", directionPoints[0].lat, directionPoints[0].lon);
	LOGV(LOG_TAG ":Field", "directionPoints[1] (%g, %g)\n", directionPoints[1].lat, directionPoints[1].lon);
	tractorPos = unit.convert(tractorPos);
	LOGV(LOG_TAG ":Field", "tractorPos (%g, %g)\n", tractorPos.lat, tractorPos.lon);
	setRefPos(unit.convert(refPos));
}

/**
 座標系変換
 
 指定のCSで座標系変換をする。
    - 角度の単位系変換はしない。測地座標系ではラジアンであること。
    - 基準点はcsに設定されているものをそのまま使い、メンバーの基準点 refPosも変換する。
      メンバー refPos はデータ入力時の指定点に過ぎないのでこの座標系変換時には参照しない。
 
 @param[in] cs 変換座標系クラス
 */
void Field::convCoordinatesTo(CoordinateSystem& cs) {
	LOGV(LOG_TAG ":Field", "convCoordinatesTo()\n");

	cs.convert(outline);
	for (auto &obstacle : obstacles) {
		cs.convert(obstacle);
	}
	for (auto &segment : workedSegments) {
		cs.convert(segment);
	}
	LOGV(LOG_TAG ":Field", "start (%g, %g)\n", start.lat, start.lon);
	LOGV(LOG_TAG ":Field", "end (%g, %g)\n", end.lat, end.lon);
	start = cs.convert(start);
	end = cs.convert(end);
	LOGV(LOG_TAG ":Field", "start (%g, %g)\n", start.lat, start.lon);
	LOGV(LOG_TAG ":Field", "end (%g, %g)\n", end.lat, end.lon);
	directionPoints[0] = cs.convert(directionPoints[0]);
	directionPoints[1] = cs.convert(directionPoints[1]);
	LOGV(LOG_TAG ":Field", "directionPoints[0] (%g, %g)\n", directionPoints[0].lat, directionPoints[0].lon);
	LOGV(LOG_TAG ":Field", "directionPoints[1] (%g, %g)\n", directionPoints[1].lat, directionPoints[1].lon);
	tractorPos = cs.convert(tractorPos);
	LOGV(LOG_TAG ":Field", "tractorPos (%g, %g)\n", tractorPos.lat, tractorPos.lon);
    setRefPos(cs.convert(refPos));
}

/**
 基準点取得

 内部にモードを持たないので常にAB点用の基準点(A点)を返す。
 現在の基準点が知りたければメンバー refpos を参照すること。
 
 @warning AB点専用
 @deprecated
 */
GeoPoint Field::getReferencePoint() const {
	LOGV(LOG_TAG ":Field", "getReferencePoint()\n");
	auto dp0 = directionPoints[0];
	LOGV(LOG_TAG, "reference point (%g, %g)\n", dp0.lat, dp0.lon);
	return GeoPoint(dp0);
}

/**
 タイムスタンプ文字列生成
 
 現在時刻をstrftime()でフォーマットした文字列を返す。
    - デフォルトは"%Y-%m-%d %H:%M:%S"
 
 @param[in] format strftimeに渡すタイムスタンプフォーマット文字列
 */
std::string getCurrentDateTimeString(const std::string& format) {
    std::array<char, 64> buffer{{'\0'}};
    time_t rawtime;
    time(&rawtime);
    const auto timeinfo = localtime(&rawtime);
    strftime(buffer.data(), sizeof(buffer), format.c_str(), timeinfo);
    
    return std::string{buffer.data()};
}

/**
 凹角検査
 Field(緯度経度座標系)に凹角があるかどうかを返す。
 - Field(緯度経度座標系)はUIからの入力データそのままのため時計回り/反時計回り不明。
 - 頂点が2以下でもfalseを返す。
 @param[in] polygon 検査対象ポリゴン
 @retval true 凹角有り
 @retval false 凹角無し
 */
bool hasConcave(const Field& geoField) {
	EnuField enuField = geoField;
	const Polygon_ polygon = enuField.getFieldOutline();
	// 頂点数・座標重複・共線・自己交差・時計回りのチェック
	if (PolygonUtil::checkPolygon(polygon) < 0) {
		return false;
	}
	const std::vector<double> angles = PolygonUtil::getSegmentAngles(polygon);
	// 折れ曲がり角度 (左折(凹)なら正、右折(凸)なら負)
	for (int i = 0; i < angles.size(); ++i) {
		const double a0 = angles[i];
		const double a1 = angles[PolygonUtil::nextIndex(i, angles.size())];
		const double a = PolygonUtil::normalizeRadian(a1 - a0);
		if (a > 0) {
			return true;
		}
	}
	return false;
}


#pragma mark - Error as the base class for exception in PathPlan

Error::Error(const char* msg) :
    std::runtime_error(msg)
{}

Error::Error(const std::runtime_error& err) :
    std::runtime_error(err)
{}

Error::Error(const Error& src) = default;
        
void Error::setDescription(const char* desc, const char* tag) {
    description = desc;
    logtag = tag;
}

void Error::setDescription(const std::string& desc, const char* tag) {
    description = desc;
    logtag = tag;
}

void Error::set(const InputData& aInData) {
    inData = aInData;
    inDataRaw = aInData;
}

bool Error::isErrorCode(const std::string& str) {
    const string code{"E-PP-"};
    return (str.compare(0, code.size(), code) == 0);
}

bool Error::compareErrorCode(const std::string& errcode) {
    const string code{what()};
    return (errcode.compare(0, errcode.size(), code) == 0);
}
    
/**
 インスタンス生成
 
 runtime_errorからErrorインスタンスを生成し、shared_ptrで返す。
    - errのwhat()がパスプランエラーコード"E-PP-"で始まる場合はそれを使用し、そうでなければErrorCode::FATALのエラーコードを持つErrorを作成する。
      後者の場合、元のwhat()はdescriptoionに設定する。
 @return インスタンス
 */
std::shared_ptr<Error> Error::getInstance(const std::runtime_error& err) {
    std::shared_ptr<Error> spError;
    
    if (Error::isErrorCode(err.what())) {
        spError = std::make_shared<Error>(err);
    } else {
        spError = std::make_shared<Error>(ErrorCode::FATAL);
        spError->setDescription(err.what());
    }
    
    return spError;
}

void Error::printLog() const {
    LOGE("PathPlan", "%s", what());
}

/**
 条件付きthrow
 
 conditionが偽のときErrorをthrowする。assertの代わりに使用する条件付きthrow関数。
 - マクロ PPASSERT()等から使用する。

 @param[in] condition assert条件
 @param[in] code Errorに与えるエラーコード文字列
 @param[in] desc Errorに与える詳細文字列
 */
template<>
void throw_if_not<Error>(bool condition, const char* code, const char* desc) {
    if (!condition) {
        LOGE("[EXCEPTION]", "%s: %s", code, desc);
        Error err(code);
        throw err;
    }
}

}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918

#include <sstream>
#include <boost/lexical_cast.hpp>

#include "PathSearch.hpp"
#include "../Geometry/Coordinates.hpp"

namespace yanmar { namespace PathPlan {

/**
 * 引数なしコンストラクタ
 */
PathSearch::PathSearch() {
	_maxReturn = MAX_RETURN;
	_azimuthRange = AZIMUTH_RANGE;
	_searchAngle = SEARCH_ANGLE;
	_searchDistance = SEARCH_DISTANCE;
	_state = State::INIT;
}

/**
 * 引数ありコンストラクタ
 * @param[in] maxReturn      最大返却本数
 * @param[in] azimuthRange   トラクターと作業パスの角度ズレ閾値 (ラジアン単位)
 * @param[in] searchAngle    探索範囲の角度 (ラジアン単位)
 * @param[in] searchDistance 探索範囲の距離 (メートル単位)
 */
PathSearch::PathSearch(int maxReturn, double azimuthRange, double searchAngle, double searchDistance) {
	_maxReturn = maxReturn;
	_azimuthRange = azimuthRange;
	_searchAngle = searchAngle;
	_searchDistance = searchDistance;
	_state = State::INIT;
}

/**
 * デストラクタ
 */
PathSearch::~PathSearch() {
}

/**
 * パラメータを設定します。
 * @param[in] maxReturn      最大返却本数
 * @param[in] azimuthRange   トラクターと作業パスの角度ズレ閾値 (ラジアン単位)
 * @param[in] searchAngle    探索範囲の角度 (ラジアン単位)
 * @param[in] searchDistance 探索範囲の距離 (メートル単位)
 */
void PathSearch::setParameter(int maxReturn, double azimuthRange, double searchAngle, double searchDistance) {
	_maxReturn = maxReturn;
	_azimuthRange = azimuthRange;
	_searchAngle = searchAngle;
	_searchDistance = searchDistance;
}

/**
 * 基本パスデータを設定します。
 * @param[in] base 基本パスデータ
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
 *         ResultCode::ERROR_NUMBER_FORMAT 文字列から数値への変換に失敗した
 *         ResultCode::ERROR_NO_DIR_POINTS 作業方向を定義する2点のデータが読み取れなかった
 */
int PathSearch::setBase(const std::string &base) {
	if (_state != State::INIT) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}

	// 基本パスデータをパースして、圃場/障害物の外形データ、および作業方向ベクトルの始点/終点を読み込む
	std::vector<GeoPoint> fp;
	std::vector<GeoPoint> op1;
	std::vector<GeoPoint> op2;
	std::vector<GeoPoint> op3;
	std::vector<GeoPoint> *p = nullptr;
	GeoPoint dp1;
	GeoPoint dp2;
	bool dp1_Loaded = false;
	bool dp2_Loaded = false;
	std::stringstream ss(base);
	std::string buf;
	// 改行コードで1行ごとに分割する
	while (std::getline(ss, buf, '\n')) {
		std::stringstream ss2(buf);
		std::string buf2;
		// 1カラム目を取得
		if (!std::getline(ss2, buf2, ',')) {
			// 空行の場合
			continue;
		}
		if (p) {
			// 読み込み先ポインタがある場合 (外形データの読み込み中)
			if (buf2 == "") {
				// インデントあり (外形データの緯度経度情報を読み込む)
				try {
					std::getline(ss2, buf2, ',');
					double lat = boost::lexical_cast<double>(buf2);
					std::getline(ss2, buf2, ',');
					double lon = boost::lexical_cast<double>(buf2);
					p->push_back(radiansGeoPoint(lat, lon));
				} catch (const std::exception &err) {
					_state = State::ERROR;
					return ResultCode::ERROR_NUMBER_FORMAT;
				}
				continue;
			} else {
				// インデントなし (外形データの読み込み終了)
				p = nullptr;
			}
		}
		if (buf2 == "FP") {
			// 圃場外形データのヘッダ行 (圃場外形データの読み込み開始)
			p = &fp;
		} else if (buf2 == "OP1") {
			// 障害物外形データ1のヘッダ行 (障害物外形データ1の読み込み開始)
			p = &op1;
		} else if (buf2 == "OP2") {
			// 障害物外形データ2のヘッダ行 (障害物外形データ2の読み込み開始)
			p = &op2;
		} else if (buf2 == "OP3") {
			// 障害物外形データ3のヘッダ行 (障害物外形データ3の読み込み開始)
			p = &op3;
		} else if (buf2 == "DP1") {
			// 作業方向ベクトルの始点
			try {
				std::getline(ss2, buf2, ',');
				double lat = boost::lexical_cast<double>(buf2);
				std::getline(ss2, buf2, ',');
				double lon = boost::lexical_cast<double>(buf2);
				dp1 = radiansGeoPoint(lat, lon);
				dp1_Loaded = true;
			} catch (const std::exception &err) {
				_state = State::ERROR;
				return ResultCode::ERROR_NUMBER_FORMAT;
			}
		} else if (buf2 == "DP2") {
			// 作業方向ベクトルの終点
			try {
				std::getline(ss2, buf2, ',');
				double lat = boost::lexical_cast<double>(buf2);
				std::getline(ss2, buf2, ',');
				double lon = boost::lexical_cast<double>(buf2);
				dp2 = radiansGeoPoint(lat, lon);
				dp2_Loaded = true;
			} catch (const std::exception &err) {
				_state = State::ERROR;
				return ResultCode::ERROR_NUMBER_FORMAT;
			}
		}
	}
	if (!dp1_Loaded || !dp2_Loaded) {
		// 作業方向ベクトルの始点/終点が読み込めない場合
		_state = State::ERROR;
		return ResultCode::ERROR_NO_DIR_POINTS;
	}

	// 座標変換(1)
	// 緯度経度座標系からメートル単位平面座標系への座標変換
	if (fp.size() > 0) {
		// 圃場外形データの1点目を座標変換の基準点に設定する
		_refPos = fp[0];
	} else {
		// 作業方向ベクトルの始点を座標変換の基準点に設定する
		_refPos = dp1;
	}
	Cartesian converter;
	converter.setRefPos(_refPos);
	// 圃場ポリゴン
	_field = Polygon_(new Polygon);
	for (int i = 0; i < fp.size(); ++i) {
		_field->push_back(converter.convert(fp[i]));
	}
	// 障害物ポリゴンのリスト
	_obstacles = Polygons_(new Polygons);
	if (op1.size() > 0) {
		Polygon_ obstacle = Polygon_(new Polygon);
		for (int i = 0; i < op1.size(); ++i) {
			obstacle->push_back(converter.convert(op1[i]));
		}
		_obstacles->push_back(obstacle);
	}
	if (op2.size() > 0) {
		Polygon_ obstacle = Polygon_(new Polygon);
		for (int i = 0; i < op2.size(); ++i) {
			obstacle->push_back(converter.convert(op2[i]));
		}
		_obstacles->push_back(obstacle);
	}
	if (op3.size() > 0) {
		Polygon_ obstacle = Polygon_(new Polygon);
		for (int i = 0; i < op3.size(); ++i) {
			obstacle->push_back(converter.convert(op3[i]));
		}
		_obstacles->push_back(obstacle);
	}
	// 作業方向ベクトルの始点/終点
	converter.convert(dp1);
	converter.convert(dp2);

	// 座標変換(2)
	// 作業方向をy軸方向に合わせるための座標変換
	// 作業方向ベクトルから回転角度を求める
	double dx = dp2.x - dp1.x;
	double dy = dp2.y - dp1.y;
	_rotateAngle = M_PI_2 - atan2(dy, dx);
	// 圃場ポリゴン、障害物ポリゴンを回転
	double sin = std::sin(_rotateAngle);
	double cos = std::cos(_rotateAngle);
	PolygonUtil::rotate(_field, sin, cos);
	for (int i = 0; i < _obstacles->size(); ++i) {
		PolygonUtil::rotate(_obstacles->at(i), sin, cos);
	}

	// 正常終了
	_state = State::BASE;
	return ResultCode::SUCCESS;
}

/**
 * 走行パスデータを設定します。
 * @param[in] paths 走行パスのリスト
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
 */
int PathSearch::setPath(const std::vector<RunPath> &paths) {
	if (_state != State::BASE) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}

	// 走行パス拡張データの生成
	_paths.clear();
	for (int i = 0; i < paths.size(); ++i) {
		RunPathEx pathEx;
		pathEx.runPath = paths[i];
		_paths.push_back(pathEx);
		// 枕地パス(周回非作業パス)以外の場合 (作業パス, ダミーライド, 周回作業パス)
		if (getRideType(paths[i].pathType) != Param::Path::Segment::RideType::NON_WORKING) _lastWorkingPathIndex = i;
	}
	// 座標変換
	setShift_internal(0.0);
	// スタートナビゲーションフラグ、およびセグメントの方向/長さ
	bool inStartNavigation = true; // スタートナビゲーションの区間中であることを表すフラグ
	for (int i = 0; i < _paths.size(); ++i) {
		RunPathEx &pathEx = _paths[i];
		// スタートナビゲーションフラグの設定
		if (isWorkingPath(pathEx.runPath.pathType)) {
			// 1本目の作業パス(周回作業パス)が見つかった時点でスタートナビゲーション終了 (スタートナビゲーションの区間中であることを表すフラグを寝かす)
			inStartNavigation = false;
		}
		pathEx.isStartNavigation = inStartNavigation;
		// 直進/旋回、時計回り/反時計回りの種別
		int type = getType(pathEx);
		if (type == 0) {
			// 直進
			pathEx.dir = atan2(pathEx.end.y - pathEx.start.y, pathEx.end.x - pathEx.start.x);
			pathEx.length = PolygonUtil::length(pathEx.start, pathEx.end);
		} else {
			// 旋回
			pathEx.dir = 0.0;
			pathEx.length = turnAngle(pathEx.pivot, pathEx.start, pathEx.end, type == 1) * getRadius(pathEx);
		}
	}
	// スタートナビゲーションを無視するかどうかのフラグ(初期値:false)、および残距離/総距離
	setIgnoreStartNavigation_internal(false);
	// 作業パスの方向を無視するかどうかのフラグ(初期値:false)
	setIgnorePathDir_internal(false);

	// 正常終了
	_state = State::READY;
	return ResultCode::SUCCESS;
}

/**
 * 走行パスデータを取得します。
 * numに負の値、またはindex以降のパス本数よりも小さい値が指定された場合、index以降のパスを全て返します。
 * @param[in] index  取得するパスの1本目のインデックス
 * @param[in] num    取得するパスの本数
 * @param[out] paths 走行パスのリスト
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
 *         ResultCode::ERROR_INVALID_INDEX 無効なインデックス値が指定された
 */
int PathSearch::getPath(int index, int num, std::vector<RunPath> &paths) {
	paths.clear();
	if (_state != State::READY) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}
	if (index < 0 || index >= _paths.size()) {
		// 無効なインデックス値が指定された場合
		return ResultCode::ERROR_INVALID_INDEX;
	}

	// メートル単位平面座標系から緯度経度座標系への座標変換器
	Geodesic converter;
	converter.setRefPos(_refPos);
	// 作業方向をy軸方向に合わせたのを元に戻すための回転角度
	double sin = std::sin(-_rotateAngle);
	double cos = std::cos(-_rotateAngle);

	// 対象となる走行パス拡張データから、走行パスデータを生成
	for (int i = index; i < _paths.size() && i < index + num; ++i) {
		const RunPathEx &pathEx = _paths[i];
		// 走行パスデータのコピー
		RunPath runPath = pathEx.runPath;
		// 座標変換(2)の逆変換
		Point2D start = Point2D(pathEx.start.x, pathEx.start.y);
		Point2D end = Point2D(pathEx.end.x, pathEx.end.y);
		Point2D pivot = Point2D(pathEx.pivot.x, pathEx.pivot.y);
		PolygonUtil::rotatePoint(&start, sin, cos);
		PolygonUtil::rotatePoint(&end, sin, cos);
		PolygonUtil::rotatePoint(&pivot, sin, cos);
		// 座標変換(1)の逆変換
		GeoPoint startGP = GeoPoint(start.x, start.y);
		GeoPoint endGP = GeoPoint(end.x, end.y);
		GeoPoint pivotGP = GeoPoint(pivot.x, pivot.y);
		runPath.path.start = degreesPoint(converter.convert(startGP));
		runPath.path.end = degreesPoint(converter.convert(endGP));
		runPath.pivot = degreesPoint(converter.convert(pivotGP));
		// 直進セグメントの旋回軸点に対する例外処理
		if (pathEx.runPath.segmentType == 1) {
			runPath.pivot = { 0.0, 0.0 };
		}
		// 走行パスのリストに追加
		paths.push_back(runPath);
	}

	// 正常終了
	return ResultCode::SUCCESS;
}

/**
 * スタートナビゲーションを無視するかどうかを設定します。
 * スタートナビゲーションを無視する場合、枕地パスの総距離に計上しません。
 * @param[in] ignoreStartNavigation スタートナビゲーションを無視するかどうかのフラグ (true:無視する, false:無視しない)
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
 */
int PathSearch::setIgnoreStartNavigation(bool ignoreStartNavigation) {
	if (_state != State::READY) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}
	if (ignoreStartNavigation == _ignoreStartNavigation) {
		// 変更なしの場合
		return ResultCode::SUCCESS;
	}
	_state = State::RECALC;

	// スタートナビゲーションを無視するかどうかのフラグ、および残距離/総距離
	setIgnoreStartNavigation_internal(ignoreStartNavigation);

	// 正常終了
	_state = State::READY;
	return ResultCode::SUCCESS;
}
void PathSearch::setIgnoreStartNavigation_internal(bool ignoreStartNavigation) {
	_ignoreStartNavigation = ignoreStartNavigation;
	// 残距離/総距離
	_totalLengthWorkingSt = 0.0;
	_totalLengthWorkingTn = 0.0;
	_totalLengthHeadlandSt = 0.0;
	_totalLengthHeadlandTn = 0.0;
	for (auto itr = _paths.rbegin(); itr != _paths.rend(); ++itr) {
		itr->restWorkingSt = _totalLengthWorkingSt;
		itr->restWorkingTn = _totalLengthWorkingTn;
		itr->restHeadlandSt = _totalLengthHeadlandSt;
		itr->restHeadlandTn = _totalLengthHeadlandTn;
		if (isWorkingPath(itr->runPath.pathType)) {
			// パス種別が作業パス(周回作業パス)の場合
			if (itr->runPath.segmentType == 1) {
				// 直進作業パスの総距離に計上する
				_totalLengthWorkingSt += itr->length;
			} else {
				// 旋回作業パスの総距離に計上する
				_totalLengthWorkingTn += itr->length;
			}
		} else if (_ignoreStartNavigation && itr->isStartNavigation) {
			// スタートナビゲーションを無視する場合、枕地パスの総距離に計上しない
		} else {
			// 上記以外の場合
			if (itr->runPath.segmentType == 1) {
				if (itr->length < IMITATION_THRESHOLD) {
					// 10m未満の直進枕地パスは、旋回枕地パスに計上する
					_totalLengthHeadlandTn += itr->length;
				} else {
					// 直進枕地パスの総距離に計上する
					_totalLengthHeadlandSt += itr->length;
				}
			} else {
				// 旋回枕地パスの総距離に計上する
				_totalLengthHeadlandTn += itr->length;
			}
		}
	}
}

/**
 * 作業パスの方向を無視するかどうかを設定します。
 * @param[in] ignorePathDir 作業パスの方向を無視するかどうかのフラグ (true:無視する, false:無視しない)
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
 */
int PathSearch::setIgnorePathDir(bool ignorePathDir) {
	if (_state != State::READY) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}
	if (ignorePathDir == _ignorePathDir) {
		// 変更なしの場合
		return ResultCode::SUCCESS;
	}
	_state = State::RECALC;

	// 作業パスの方向を無視するかどうかのフラグ
	setIgnorePathDir_internal(ignorePathDir);

	// 正常終了
	_state = State::READY;
	return ResultCode::SUCCESS;
}
void PathSearch::setIgnorePathDir_internal(bool ignorePathDir) {
	_ignorePathDir = ignorePathDir;
}

/**
 * シフト値を設定します。
 * 正の値が指定された場合、基準ベクトルに対して右側にシフトします。
 * 負の値が指定された場合、基準ベクトルに対して左側にシフトします。
 * @param[in] shift シフト値 (メートル単位)
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
 */
int PathSearch::setShift(double shift) {
	if (_state != State::READY) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}
	_state = State::RECALC;

	// 座標変換/パスシフト
	setShift_internal(shift);

	// 正常終了
	_state = State::READY;
	return ResultCode::SUCCESS;
}
void PathSearch::setShift_internal(double shift) {
	// 緯度経度座標系からメートル単位平面座標系への座標変換器
	Cartesian converter;
	converter.setRefPos(_refPos);
	// 作業方向をy軸方向に合わせるための回転角度
	double sin = std::sin(_rotateAngle);
	double cos = std::cos(_rotateAngle);
	// 座標変換
	for (int i = 0; i < _paths.size(); ++i) {
		RunPathEx &pathEx = _paths[i];
		// 座標変換(1)
		// 緯度経度座標系からメートル単位平面座標系への座標変換
		GeoPoint start = radiansGeoPoint(pathEx.runPath.path.start.lat, pathEx.runPath.path.start.lon);
		GeoPoint end = radiansGeoPoint(pathEx.runPath.path.end.lat, pathEx.runPath.path.end.lon);
		GeoPoint pivot = radiansGeoPoint(pathEx.runPath.pivot.lat, pathEx.runPath.pivot.lon);
		pathEx.start = converter.convert(start);
		pathEx.end = converter.convert(end);
		pathEx.pivot = converter.convert(pivot);
		// 座標変換(2)
		// 作業方向をy軸方向に合わせるための座標変換
		PolygonUtil::rotatePoint(&pathEx.start, sin, cos);
		PolygonUtil::rotatePoint(&pathEx.end, sin, cos);
		PolygonUtil::rotatePoint(&pathEx.pivot, sin, cos);
		// 座標変換(3)
		// パスシフトによる座標変換
		PolygonUtil::translatePoint(&pathEx.start, shift, 0.0);
		PolygonUtil::translatePoint(&pathEx.end, shift, 0.0);
		PolygonUtil::translatePoint(&pathEx.pivot, shift, 0.0);
		// 直進セグメントの旋回軸点に対する例外処理
		if (pathEx.runPath.segmentType == 1) {
			pathEx.pivot = Point2D();
		}
	}
}

/**
 * パスサーチを実行します。
 * @param[in] pos         トラクターの位置 (度単位)
 * @param[in] azimuth     トラクターの方位角 (北を0度、時計回りを正、ラジアン単位)
 * @param[in] forward     前進フラグ (true:前進, false:後進)
 * @param[out] candidates パスサーチ結果
 * @return ResultCode::SUCCESS             正常終了 (パスサーチ結果が0件の場合も含む)
 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
 */
int PathSearch::search(const Point &pos, double azimuth, bool forward, std::vector<Path> &candidates) {
	if (!forward) {
		azimuth += M_PI;
	}
	return search_internal(pos, azimuth, candidates);
}
int PathSearch::search(const Point &pos, double azimuth, std::vector<Path> &candidates) {
	return search_internal(pos, azimuth, candidates);
}
int PathSearch::search(const Point &pos, double azimuth, bool forward, std::vector<RunPath> &candidates) {
	if (!forward) {
		azimuth += M_PI;
	}
	return search_internal(pos, azimuth, candidates);
}
int PathSearch::search(const Point &pos, double azimuth, std::vector<RunPath> &candidates) {
	return search_internal(pos, azimuth, candidates);
}
int PathSearch::search_internal(const Point &pos, double azimuth, std::vector<Path> &candidates) {
	candidates.clear();
	std::vector<RunPath> paths;
	int ret = search_internal(pos, azimuth, paths);
	if (ret == ResultCode::SUCCESS) {
		for (int i = 0; i < paths.size(); ++i) {
			candidates.push_back(paths[0].path);
		}
	}
	return ret;
}
int PathSearch::search_internal(const Point &pos, double azimuth, std::vector<RunPath> &candidates) {
	candidates.clear();
	if (_state != State::READY) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}

	// トラクターの位置、方位角に座標変換を適用する
	// 座標変換(1)
	// 緯度経度座標系からメートル単位平面座標系への座標変換
	Cartesian converter;
	converter.setRefPos(_refPos);
	GeoPoint tractorGP = radiansGeoPoint(pos.lat, pos.lon);
	Point2D tractorPos = converter.convert(tractorGP);
	// 座標変換(2)
	// 作業方向をy軸方向に合わせるための座標変換
	double sin = std::sin(_rotateAngle);
	double cos = std::cos(_rotateAngle);
	PolygonUtil::rotatePoint(&tractorPos, sin, cos);
	double tractorDir = PolygonUtil::normalizeRadian(M_PI_2 - azimuth + _rotateAngle);

	// トラクターと作業パスの角度ズレ閾値による判定
	// パス候補リスト(1)
	std::vector<RunPathEx> tmpCandidates1;
	for (int i = 0; i < _paths.size(); ++i) {
		const RunPathEx &pathEx = _paths[i];
		if (!isWorkingPath(pathEx.runPath.pathType)) {
			// パス種別が作業パス以外の場合、パスサーチの対象外 (周回作業パスはパスサーチの対象)
			continue;
		}
		if (_ignorePathDir) {
			// 作業パスの方向を無視する場合
			if (fabs(PolygonUtil::normalizeRadian(pathEx.dir - tractorDir)) > _azimuthRange &&
				fabs(PolygonUtil::normalizeRadian(pathEx.dir + M_PI - tractorDir)) > _azimuthRange) {
				// 順方向/逆方向のどちらと比較しても、角度ズレ閾値の範囲外の場合
				continue;
			}
		} else {
			// 作業パスの方向を無視しない場合
			if (fabs(PolygonUtil::normalizeRadian(pathEx.dir - tractorDir)) > _azimuthRange) {
				// 順方向と比較して、角度ズレ閾値の範囲外の場合
				continue;
			}
		}
		tmpCandidates1.push_back(pathEx);
	}
	if (tmpCandidates1.size() == 0) {
		// パス候補リスト(1)の件数が0件の場合、正常終了
		return ResultCode::SUCCESS;
	}

	// 探索範囲による判定
	// トラクターの前方[_searchDistance]メートル
	Point2D tractorF = tractorPos;
	tractorF.x += std::cos(tractorDir) * _searchDistance;
	tractorF.y += std::sin(tractorDir) * _searchDistance;
	// トラクターの左[_searchAngle]ラジアン、[_searchDistance]メートル
	Point2D tractorL = tractorPos;
	tractorL.x += std::cos(tractorDir + _searchAngle) * _searchDistance;
	tractorL.y += std::sin(tractorDir + _searchAngle) * _searchDistance;
	// トラクターの右[_searchAngle]ラジアン、[_searchDistance]メートル
	Point2D tractorR = tractorPos;
	tractorR.x += std::cos(tractorDir - _searchAngle) * _searchDistance;
	tractorR.y += std::sin(tractorDir - _searchAngle) * _searchDistance;
	// 探索範囲ポリゴン
	Polygon_ searchArea = Polygon_(new Polygon);
	searchArea->push_back(tractorPos);
	searchArea->push_back(tractorL);
	searchArea->push_back(tractorF);
	searchArea->push_back(tractorR);
	// 探索範囲ポリゴンのバウンディングボックス
	Point2D minArea;
	Point2D maxArea;
	PolygonUtil::boundingBox(searchArea, &minArea, &maxArea);
	// 交点探索用セグメント1(左)
	PolygonUtil::Segment searchSegment1 = PolygonUtil::Segment(tractorPos, tractorL);
	// 交点探索用セグメント2(右)
	PolygonUtil::Segment searchSegment2 = PolygonUtil::Segment(tractorPos, tractorR);
	// パス候補リスト(2)
	std::vector<RunPathEx> tmpCandidates2;
	for (int i = 0; i < tmpCandidates1.size(); ++i) {
		RunPathEx pathEx = tmpCandidates1[i];
		double minX = std::min(pathEx.start.x, pathEx.end.x);
		double maxX = std::max(pathEx.start.x, pathEx.end.x);
		double minY = std::min(pathEx.start.y, pathEx.end.y);
		double maxY = std::max(pathEx.start.y, pathEx.end.y);
		if (maxX < minArea.x || maxArea.x < minX || maxY < minArea.y || maxArea.y < minY) {
			// バウンディングボックス同士に交差がない
			continue;
		}
		std::vector<Point2D> candidatePoints;
		// 作業パスと交点探索用セグメントの交点を求める (共線は考慮しない)
		PolygonUtil::Segment workingSegment = PolygonUtil::Segment(pathEx.start, pathEx.end);
		Point2D p1;
		if (PolygonUtil::crossPoint(workingSegment, searchSegment1, &p1, true) == 0) {
			candidatePoints.push_back(p1);
		}
		Point2D p2;
		if (PolygonUtil::crossPoint(workingSegment, searchSegment2, &p2, true) == 0) {
			candidatePoints.push_back(p2);
		}
		// 作業パスの開始位置が探索範囲ポリゴンに含まれる場合、候補点に含める
		if (minArea.x < pathEx.start.x && pathEx.start.x < maxArea.x && minArea.y < pathEx.start.y && pathEx.start.y < maxArea.y) {
			if (PolygonUtil::within(searchArea, pathEx.start)) {
				candidatePoints.push_back(pathEx.start);
			}
		}
		// 作業パスの方向を無視する場合、作業パスの終了位置も考慮する
		if (_ignorePathDir) {
			if (minArea.x < pathEx.end.x && pathEx.end.x < maxArea.x && minArea.y < pathEx.end.y && pathEx.end.y < maxArea.y) {
				if (PolygonUtil::within(searchArea, pathEx.end)) {
					candidatePoints.push_back(pathEx.end);
				}
			}
		}
		if (candidatePoints.size() == 0) {
			// 探索範囲ポリゴンの範囲内に進入予想地点候補がない
			continue;
		}
		// 作業パスの開始位置を進入予想地点で上書きする
		pathEx.start = candidatePoints[0];
		// 作業パスの向きを進入予想地点までの距離で上書きする
		pathEx.dir = PolygonUtil::length(tractorPos, candidatePoints[0]);
		if (candidatePoints.size() == 1) {
			// 進入予想地点候補が1個の場合
			tmpCandidates2.push_back(pathEx);
			continue;
		}
		// 進入予想地点候補が2個以上の場合
		for (int i = 1; i < candidatePoints.size(); ++i) {
			double d = PolygonUtil::length(tractorPos, candidatePoints[i]);
			if (d < pathEx.dir) {
				// トラクターの位置からの距離が近い進入予想地点を優先する
				pathEx.start = candidatePoints[i];
				pathEx.dir = d;
			}
		}
		tmpCandidates2.push_back(pathEx);
	}
	if (tmpCandidates2.size() == 0) {
		// パス候補リスト(2)の件数が0件になった場合、正常終了
		return ResultCode::SUCCESS;
	}

	// 圃場境界、障害物の考慮
	// パス候補リスト(3)
	std::vector<RunPathEx> tmpCandidates3;
	for (int i = 0; i < tmpCandidates2.size(); ++i) {
		RunPathEx pathEx = tmpCandidates2[i];
		bool collinear;
		std::vector<Point2D> crossPoints;
		// トラクターの位置と進入予想地点を結んだ線分と圃場ポリゴンとの交点を求める
		collinear = PolygonUtil::getCrossPoints(_field, tractorPos, pathEx.start, &crossPoints);
		if (collinear || crossPoints.size() > 0) {
			// 共線または交点ありの場合、候補から除外する
			continue;
		}
		bool intersect = false;
		for (int i = 0; i < _obstacles->size(); ++i) {
			// トラクターの位置と進入予想地点を結んだ線分と障害物ポリゴンとの交点を求める
			collinear = PolygonUtil::getCrossPoints(_obstacles->at(i), tractorPos, pathEx.start, &crossPoints);
			if (collinear || crossPoints.size() > 0) {
				// 共線または交点ありの場合、交差フラグを立てる
				intersect = true;
				break;
			}
		}
		if (intersect) {
			// 障害物ポリゴンのいずれかひとつとでも交差する場合、候補から除外する
			continue;
		}
		tmpCandidates3.push_back(pathEx);
	}
	if (tmpCandidates3.size() == 0) {
		// パス候補リスト(3)の件数が0件になった場合、正常終了
		return ResultCode::SUCCESS;
	}

    // パス候補リスト(3)を、トラクター位置から進入予想地点までの距離の昇順にソート
    std::sort(tmpCandidates3.begin(), tmpCandidates3.end(), [](RunPathEx p1, RunPathEx p2) -> int { return (p1.dir < p2.dir); });
	// パス候補リスト(3)から最大[_maxReturn]件をパスサーチ結果にコピー
	for (int i = 0; i < tmpCandidates3.size() && i < _maxReturn; ++i) {
		std::vector<RunPath> paths;
		getPath(tmpCandidates3[i].runPath.path.index, 1, paths);
		candidates.push_back(paths[0]);
	}
	// パスサーチ結果をインデックスの昇順にソート
    // 20161213 距離順で返すことになったのでコメントアウト
	// std::sort(candidates.begin(), candidates.end(), [](RunPath p1, RunPath p2) -> int { return (p1.path.index < p2.path.index); });

	// 正常終了
	return ResultCode::SUCCESS;
}

/**
 * 残距離を計算します。
 * indexに負の値が指定された場合、総距離を返します。
 * @param[in] index           パスインデックス
 * @param[in] pos             トラクターの位置 (度単位)
 * @param[out] restWorkingSt  直進作業パスの残距離 (メートル単位)
 * @param[out] restWorkingTn  旋回作業パスの残距離 (メートル単位)
 * @param[out] restHeadlandSt 直進枕地パスの残距離 (メートル単位)
 * @param[out] restHeadlandTn 旋回枕地パスの残距離 (メートル単位)
 * @return ResultCode::SUCCESS             正常終了
 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
 *         ResultCode::ERROR_INVALID_INDEX 無効なインデックス値が指定された
 */
int PathSearch::rest(int index, const Point &pos, double *restWorkingSt, double *restWorkingTn, double *restHeadlandSt, double *restHeadlandTn) {
	if (_state != State::READY) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}
	if (index < 0) {
		// indexに負の値が指定された場合、総距離を返す
		*restWorkingSt = _totalLengthWorkingSt;
		*restWorkingTn = _totalLengthWorkingTn;
		*restHeadlandSt = _totalLengthHeadlandSt;
		*restHeadlandTn = _totalLengthHeadlandTn;
		return ResultCode::SUCCESS;
	}
	if (index >= _paths.size()) {
		// 無効なインデックス値が指定された場合
		return ResultCode::ERROR_INVALID_INDEX;
	}
	if (_ignoreStartNavigation && _paths[index].isStartNavigation) {
		// スタートナビゲーションを無視するように設定されているのに、スタートナビゲーションからの残距離を求められた場合
		return ResultCode::ERROR_INVALID_INDEX;
	}

	// トラクターの位置に座標変換を適用する
	// 座標変換(1)
	// 緯度経度座標系からメートル単位平面座標系への座標変換
	Cartesian converter;
	converter.setRefPos(_refPos);
	GeoPoint tractorGP = radiansGeoPoint(pos.lat, pos.lon);
	Point2D tractorPos = converter.convert(tractorGP);
	// 座標変換(2)
	// 作業方向をy軸方向に合わせるための座標変換
	double sin = std::sin(_rotateAngle);
	double cos = std::cos(_rotateAngle);
	PolygonUtil::rotatePoint(&tractorPos, sin, cos);

	// 走行パス拡張データ
	const RunPathEx &pathEx = _paths[index];
	// このセグメントを含めない、このセグメントより後の作業パスの残距離 (メートル単位)
	*restWorkingSt = pathEx.restWorkingSt;
	*restWorkingTn = pathEx.restWorkingTn;
	// このセグメントを含めない、このセグメントより後の枕地パスの残距離 (メートル単位)
	*restHeadlandSt = pathEx.restHeadlandSt;
	*restHeadlandTn = pathEx.restHeadlandTn;
	// 直進/旋回、時計回り/反時計回りの種別
	int type = getType(pathEx);
	// このセグメント内の残距離を計算
	double rest = 0.0;
	if (type == 0) {
		// 直進
		PolygonUtil::Segment s = PolygonUtil::Segment(pathEx.start, pathEx.end);
		Point2D p = PolygonUtil::perpendicularPoint(tractorPos, s);
		if (s.contains(p)) {
			// 垂線の足がセグメントの範囲内の場合
			rest = PolygonUtil::length(p, pathEx.end);
		} else if (PolygonUtil::length(p, pathEx.start) < PolygonUtil::length(p, pathEx.end)) {
			// 垂線の足がセグメントの範囲外で、セグメントの開始位置より前側の場合
			rest = pathEx.length;
		} else {
			// 垂線の足がセグメントの範囲外で、セグメントの終了位置より後側の場合
			rest = 0.0;
		}
	} else {
		// 旋回
		double a0 = turnAngle(pathEx.pivot, pathEx.start, pathEx.end, type == 1);
		double a1 = turnAngle(pathEx.pivot, tractorPos, pathEx.end, type == 1);
		if (a1 < a0) {
			// 旋回軸点から見たトラクター位置の角度がセグメント(円弧)の範囲内の場合
			rest = a1 * getRadius(pathEx);
		} else if (a1 < M_PI + a0 * 0.5) {
			// 旋回軸点から見たトラクター位置の角度がセグメント(円弧)の範囲外で、セグメントの開始位置より前側の場合
			rest = pathEx.length;
		} else {
			// 旋回軸点から見たトラクター位置の角度がセグメント(円弧)の範囲外で、セグメントの開始位置より後側の場合
			rest = 0.0;
		}
	}
	if (rest > pathEx.length) rest = pathEx.length;
	// このセグメント内の残距離を作業パス/枕地パスの残距離に加算する
	if (isWorkingPath(pathEx.runPath.pathType)) {
		// 作業パス(周回作業パス)
		if (type == 0) {
			// 直進
			*restWorkingSt += rest;
		} else {
			// 旋回
			*restWorkingTn += rest;
		}
	} else {
		// 枕地パス/ダミーライド
		if (type == 0) {
			if (pathEx.length < IMITATION_THRESHOLD) {
				// 10m未満の直進枕地パスは、旋回枕地パスに計上する
				*restHeadlandTn += rest;
			} else {
				// 直進
				*restHeadlandSt += rest;
			}
		} else {
			// 旋回
			*restHeadlandTn += rest;
		}
	}

	// 正常終了
	return ResultCode::SUCCESS;
}
int PathSearch::rest(int index, const Point &pos, double *restWorking, double *restHeadland) {
	double restWorkingSt = 0.0;
	double restWorkingTn = 0.0;
	double restHeadlandSt = 0.0;
	double restHeadlandTn = 0.0;
	int ret = PathSearch::rest(index, pos, &restWorkingSt, &restWorkingTn, &restHeadlandSt, &restHeadlandTn);
	*restWorking = restWorkingSt + restWorkingTn;
	*restHeadland = restHeadlandSt + restHeadlandTn;
	return ret;
}
int PathSearch::rest(int index, const Point &pos, double *rest) {
	double restWorking = 0.0;
	double restHeadland = 0.0;
	int ret = PathSearch::rest(index, pos, &restWorking, &restHeadland);
	*rest = restWorking + restHeadland;
	return ret;
}

int PathSearch::lastWorkingPathIndex() {
	if (_state != State::READY) {
		_state = State::ERROR;
		return ResultCode::ERROR_ILLEGAL_STATE;
	}
	return _lastWorkingPathIndex;
}

int PathSearch::divideGeoSegment(const int div, const GeoPoint &base, const GeoSegment &in, GeoPointList &out) {
	if (div < 1) {
		return -1;
	}
	out.clear();
	GeoPoint _base = radiansGeoPoint(base.lat, base.lon);

	// 座標変換器
	Cartesian converter1;
	converter1.setRefPos(_base);
	Geodesic converter2;
	converter2.setRefPos(_base);

	GeoPoint p1 = radiansGeoPoint(in.first.lat, in.first.lon);
	GeoPoint p2 = radiansGeoPoint(in.second.lat, in.second.lon);
	converter1.convert(p1);
	converter1.convert(p2);
	double dx = (p2.x - p1.x) / div;
	double dy = (p2.y - p1.y) / div;

	out.push_back(in.first);
	for (int i = 1; i < div; ++i) {
		GeoPoint p = GeoPoint(p1.x + dx * i, p1.y + dy * i);
		converter2.convert(p);
		out.push_back(p);
	}
	out.push_back(in.second);
	return 0;
}
int PathSearch::divideGeoSegments(const int div, const GeoPoint &base, const std::vector<GeoSegment> &in, std::vector<GeoPointList> &out) {
	if (div < 1) {
		return -1;
	}
	out.clear();
	GeoPoint _base = radiansGeoPoint(base.lat, base.lon);

	// 座標変換器
	Cartesian converter1;
	converter1.setRefPos(_base);
	Geodesic converter2;
	converter2.setRefPos(_base);

	for (auto itr = in.begin(); itr != in.end(); ++itr) {
		GeoPoint p1 = radiansGeoPoint(itr->first.lat, itr->first.lon);
		GeoPoint p2 = radiansGeoPoint(itr->second.lat, itr->second.lon);
		converter1.convert(p1);
		converter1.convert(p2);
		double dx = (p2.x - p1.x) / div;
		double dy = (p2.y - p1.y) / div;

		GeoPointList points;
		points.clear();
		points.push_back(itr->first);
		for (int i = 1; i < div; ++i) {
			GeoPoint p = GeoPoint(p1.x + dx * i, p1.y + dy * i);
			converter2.convert(p);
			points.push_back(p);
		}
		points.push_back(itr->second);
		out.push_back(points);
	}
	return 0;
}
int PathSearch::pointOnGeoSegment(const double d, const GeoPoint &base, const GeoSegment &in, GeoPoint &out) {
	GeoPoint _base = radiansGeoPoint(base.lat, base.lon);
	// 座標変換器
	Cartesian converter1;
	converter1.setRefPos(_base);
	Geodesic converter2;
	converter2.setRefPos(_base);

	GeoPoint p1 = radiansGeoPoint(in.first.lat, in.first.lon);
	GeoPoint p2 = radiansGeoPoint(in.second.lat, in.second.lon);
	converter1.convert(p1);
	converter1.convert(p2);
	double len = PolygonUtil::length(p1, p2);
	double dx = (p2.x - p1.x) / len;
	double dy = (p2.y - p1.y) / len;
	out = GeoPoint(p1.x + dx * d, p1.y + dy * d);
	converter2.convert(out);
	return 0;
}

}} // namespace yanmar::PathPlan

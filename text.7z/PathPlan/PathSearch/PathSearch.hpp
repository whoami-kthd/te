// Yanmar Confidential 20200918
#ifndef PathSearch_HPP
#define PathSearch_HPP

#define MAX_RETURN 5
#define AZIMUTH_RANGE M_PI / 6.0
#define SEARCH_ANGLE M_PI / 6.0
#define SEARCH_DISTANCE 30.0
#define IMITATION_THRESHOLD 10

#include <string>
#include <vector>
#include "../PolyLib/PolygonUtil.hpp"

namespace yanmar { namespace PathPlan {

class PathSearch {
public:

	/** 処理結果 (正常終了:0, 警告あり:正, 異常終了:負) */
	class ResultCode {
	public:
		static const int SUCCESS = 0;                 ///< 正常終了
		static const int WARNING_NO_WORKING_PATH = 1; ///< 作業パスが1本もなかった @deprecated このコード値は返却されなくなりました
		static const int WARNING_ERROR_TOO_LARGE = 2; ///< 想定外の誤差が出た @deprecated このコード値は返却されなくなりました
		static const int ERROR_ILLEGAL_STATE = -1;    ///< 不正な状態遷移が検出された
		static const int ERROR_NUMBER_FORMAT = -2;    ///< 文字列から数値への変換に失敗した
		static const int ERROR_NO_FIELD_POINTS = -3;  ///< 圃場の外形データが読み取れなかった @deprecated このコード値は返却されなくなりました
		static const int ERROR_INVALID_INDEX = -4;    ///< 無効なインデックス値が指定された
		static const int ERROR_NO_DIR_POINTS = -5;    ///< 作業方向を定義する2点のデータが読み取れなかった
	};

	/** 地点 */
	typedef struct {
		double lat; ///< 緯度
		double lon; ///< 経度
	} Point;

	/** パス */
	typedef struct {
		int index;   ///< セグメントのインデックス
		Point start; ///< セグメントの開始位置
		Point end;   ///< セグメントの終了位置
	} Path;

	/** 走行パス */
	typedef struct {
		int segmentType; ///< 直進/旋回種別 (1:直進, 0:旋回)
		Path path;       ///< パス
		Point pivot;     ///< 旋回軸点の緯度経度 (度単位)
		int turnRadius;  ///< 旋回半径 (cm単位)
		int turnDir;     ///< 旋回方向 (0:時計回り, 1:反時計回り, -1:旋回ではない(直進))
		int pathType;    ///< パス種別 (0:作業パス, 1:ダミーライド, 2:枕地パス, 0x0010:周回作業パス, 0x0012:周回非作業パス)
		int turnType;    ///< ターン種別 (Uターン/フラットターン/フィッシュテールターン/フックターン/αターン)
		int isForward;   ///< 前進/後進種別 (1:前進, 0:後進)
	} RunPath;

public:

	/**
	 * 引数なしコンストラクタ
	 */
	PathSearch();

	/**
	 * 引数ありコンストラクタ
	 * @param[in] maxReturn      最大返却本数
	 * @param[in] azimuthRange   トラクターと作業パスの角度ズレ閾値 (ラジアン単位)
	 * @param[in] searchAngle    探索範囲の角度 (ラジアン単位)
	 * @param[in] searchDistance 探索範囲の距離 (メートル単位)
	 */
	PathSearch(int maxReturn, double azimuthRange, double searchAngle, double searchDistance);

	/**
	 * デストラクタ
	 */
	~PathSearch();

	/**
	 * パラメータを設定します。
	 * @param[in] maxReturn      最大返却本数
	 * @param[in] azimuthRange   トラクターと作業パスの角度ズレ閾値 (ラジアン単位)
	 * @param[in] searchAngle    探索範囲の角度 (ラジアン単位)
	 * @param[in] searchDistance 探索範囲の距離 (メートル単位)
	 */
	void setParameter(int maxReturn, double azimuthRange, double searchAngle, double searchDistance);

	/**
	 * 基本パスデータを設定します。
	 * @param[in] base 基本パスデータ
	 * @return ResultCode::SUCCESS             正常終了
	 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
	 *         ResultCode::ERROR_NUMBER_FORMAT 文字列から数値への変換に失敗した
	 *         ResultCode::ERROR_NO_DIR_POINTS 作業方向を定義する2点のデータが読み取れなかった
	 */
	int setBase(const std::string &base);

	/**
	 * 走行パスデータを設定します。
	 * @param[in] paths 走行パスのリスト
	 * @return ResultCode::SUCCESS             正常終了
	 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
	 */
	int setPath(const std::vector<RunPath> &paths);

	/**
	 * 走行パスデータを取得します。
	 * numに負の値、またはindex以降のパス本数よりも小さい値が指定された場合、index以降のパスを全て返します。
	 * @param[in] index  取得するパスの1本目のインデックス
	 * @param[in] num    取得するパスの本数
	 * @param[out] paths 走行パスのリスト
	 * @return ResultCode::SUCCESS             正常終了
	 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
	 *         ResultCode::ERROR_INVALID_INDEX 無効なインデックス値が指定された
	 */
	int getPath(int index, int num, std::vector<RunPath> &paths);

	/**
	 * スタートナビゲーションを無視するかどうかを設定します。
	 * スタートナビゲーションを無視する場合、枕地パスの総距離に計上しません。
	 * @param[in] ignoreStartNavigation スタートナビゲーションを無視するかどうかのフラグ (true:無視する, false:無視しない)
	 * @return ResultCode::SUCCESS             正常終了
	 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
	 */
	int setIgnoreStartNavigation(bool ignoreStartNavigation);

	/**
	 * 作業パスの方向を無視するかどうかを設定します。
	 * @param[in] ignorePathDir 作業パスの方向を無視するかどうかのフラグ (true:無視する, false:無視しない)
	 * @return ResultCode::SUCCESS             正常終了
	 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
	 */
	int setIgnorePathDir(bool ignorePathDir);

	/**
	 * シフト値を設定します。
	 * 正の値が指定された場合、基準ベクトルに対して右側にシフトします。
	 * 負の値が指定された場合、基準ベクトルに対して左側にシフトします。
	 * @param[in] shift シフト値 (メートル単位)
	 * @return ResultCode::SUCCESS             正常終了
	 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
	 */
	int setShift(double shift);

	/**
	 * パスサーチを実行します。
	 * @param[in] pos         トラクターの位置 (度単位)
	 * @param[in] azimuth     トラクターの方位角 (北を0度、時計回りを正、ラジアン単位)
	 * @param[in] forward     前進フラグ (true:前進, false:後進)
	 * @param[out] candidates パスサーチ結果
	 * @return ResultCode::SUCCESS             正常終了 (パスサーチ結果が0件の場合も含む)
	 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
	 */
	int search(const Point &pos, double azimuth, bool forward, std::vector<Path> &candidates); ///< @deprecated
	int search(const Point &pos, double azimuth, bool forward, std::vector<RunPath> &candidates);
	int search(const Point &pos, double azimuth, std::vector<Path> &candidates); ///< @deprecated
	int search(const Point &pos, double azimuth, std::vector<RunPath> &candidates);

	/**
	 * 残距離を計算します。
	 * indexに負の値が指定された場合、総距離を返します。
	 * @param[in] index           パスインデックス
	 * @param[in] pos             トラクターの位置 (度単位)
	 * @param[out] restWorkingSt  直進作業パスの残距離 (メートル単位)
	 * @param[out] restWorkingTn  旋回作業パスの残距離 (メートル単位)
	 * @param[out] restHeadlandSt 直進枕地パスの残距離 (メートル単位)
	 * @param[out] restHeadlandTn 旋回枕地パスの残距離 (メートル単位)
	 * @return ResultCode::SUCCESS             正常終了
	 *         ResultCode::ERROR_ILLEGAL_STATE 不正な状態遷移が検出された
	 *         ResultCode::ERROR_INVALID_INDEX 無効なインデックス値が指定された
	 */
	int rest(int index, const Point &pos, double *restWorkingSt, double *restWorkingTn, double *restHeadlandSt, double *restHeadlandTn);
	int rest(int index, const Point &pos, double *restWorking, double *restHeadland);
	int rest(int index, const Point &pos, double *rest);

	/**
	 * 最後の作業パスまたはダミーライドのパスインデックスを取得します。
	 */
	int lastWorkingPathIndex();

private:

	/** 状態 */
	class State {
	public:
		static const int ERROR = -1; ///< エラー
		static const int INIT = 0;   ///< 初期状態
		static const int BASE = 1;   ///< 基本パスデータ設定完了
		static const int READY = 2;  ///< 走行パスデータ設定完了 (パスサーチ/残距離計算OK)
		static const int RECALC = 3; ///< 内部データ再計算中 (スタートナビゲーションフラグ/シフト値の再計算中)
	};

	/** 走行パス拡張 */
	typedef struct {
		RunPath runPath;        ///< 走行パスデータ (setPathで渡されたデータをそのまま保持する)
		Point2D start;          ///< 座標変換/シフト後のセグメントの開始位置 (メートル単位)
		Point2D end;            ///< 座標変換/シフト後のセグメントの終了位置 (メートル単位)
		Point2D pivot;          ///< 座標変換/シフト後の旋回軸点 (メートル単位)
		bool isStartNavigation; ///< このセグメントがスタートナビゲーションかどうかを表すフラグ (true:スタートナビゲーション, false:それ以外)
		double dir;             ///< 座標変換後のセグメントの進行方向 (x軸正方向を0度、反時計回りを正、ラジアン単位)
		double length;          ///< このセグメントの長さ (メートル単位)
		double restWorkingSt;   ///< このセグメントを含めない、このセグメントより後の直進作業パスの残距離 (メートル単位)
		double restWorkingTn;   ///< このセグメントを含めない、このセグメントより後の旋回作業パスの残距離 (メートル単位)
		double restHeadlandSt;  ///< このセグメントを含めない、このセグメントより後の直進枕地パスの残距離 (メートル単位)
		double restHeadlandTn;  ///< このセグメントを含めない、このセグメントより後の旋回枕地パスの残距離 (メートル単位)
	} RunPathEx;

private:

	int _maxReturn;         ///< 最大返却本数
	double _azimuthRange;   ///< トラクターと作業パスの角度ズレ閾値 (ラジアン単位)
	double _searchAngle;    ///< 探索範囲の角度 (ラジアン単位)
	double _searchDistance; ///< 探索範囲の距離 (メートル単位)

	int _state;             ///< インスタンスの状態
	Polygon_ _field;        ///< 圃場ポリゴン
	Polygons_ _obstacles;   ///< 障害物ポリゴンのリスト
	GeoPoint _refPos;       ///< 緯度経度座標系からメートル単位平面座標系への座標変換の基準点(ラジアン単位)
	double _rotateAngle;    ///< 作業パスをy軸方向に合わせるための回転角度
	std::vector<RunPathEx> _paths; ///< 走行パス拡張データのリスト
	double _totalLengthWorkingSt;  ///< 直進作業パスの総距離
	double _totalLengthWorkingTn;  ///< 旋回作業パスの総距離
	double _totalLengthHeadlandSt; ///< 直進枕地パスの総距離
	double _totalLengthHeadlandTn; ///< 旋回枕地パスの総距離
	bool _ignoreStartNavigation;   ///< スタートナビゲーションを無視するかどうかのフラグ (true:無視する, false:無視しない)
	bool _ignorePathDir;           ///< 作業パスの方向を無視するかどうかのフラグ (true:無視する, false:無視しない)
	int _lastWorkingPathIndex;     ///< 最後の作業パスまたはダミーライドのパスインデックス

private:

	void setIgnoreStartNavigation_internal(bool ignoreStartNavigation);
	void setIgnorePathDir_internal(bool ignorePathDir);
	void setShift_internal(double shift);
	int search_internal(const Point &pos, double azimuth, std::vector<Path> &candidates); ///< @deprecated
	int search_internal(const Point &pos, double azimuth, std::vector<RunPath> &candidates);

	/**
	 * 度単位の緯度経度からラジアン単位のGeoPointを生成します。
	 * @param[in] degLat 度単位の緯度
	 * @param[in] degLon 度単位の経度
	 * @return ラジアン単位のGeoPoint
	 */
	inline static GeoPoint radiansGeoPoint(double degLat, double degLon) {
		return GeoPoint(degLat * M_PI / 180.0, degLon * M_PI / 180.0);
	}

	/**
	 * 度単位のGeoPointから度単位のPointを生成します。
	 * @param[in] degGeoPoint 度単位のGeoPoint
	 * @return 度単位のPoint
	 */
	inline static Point degreesPoint(GeoPoint degGeoPoint) {
		Point p = { degGeoPoint.lat, degGeoPoint.lon };
		return p;
	}

	/**
	 * パス種別をマスクしてRideTypeを返します。
	 * @param[in] pathType パス種別 (0:作業パス, 1:ダミーライド, 2:枕地パス, 0x0010:周回作業パス, 0x0012:周回非作業パス)
	 * @return RideType (0:作業パス, 1:ダミーライド, 2:枕地パス)
	 */
	inline static int getRideType(int pathType) {
		return (pathType & Param::Path::Segment::RideType::MASK);
	}
	/**
	 * パス種別が 0:作業パス, 0x0010:周回作業パス の場合、trueを返します。
	 */
	inline static bool isWorkingPath(int pathType) {
		return (getRideType(pathType) == Param::Path::Segment::RideType::WORKING);
	}

	/**
	 * 直進/旋回、時計回り/反時計回りの種別を返します。
	 * @param[in] pathEx 走行パス拡張データ
	 * @return 直進/旋回、時計回り/反時計回りの種別 (0:直進, 1:旋回/時計回り, 2:旋回/反時計回り)
	 */
	inline static int getType(const RunPathEx &pathEx) {
		if (pathEx.runPath.segmentType == 0 && pathEx.runPath.turnDir == 0) return 1; // 旋回/時計回り
		if (pathEx.runPath.segmentType == 0 && pathEx.runPath.turnDir == 1) return 2; // 旋回/反時計回り
		return 0; // 直進
	}

	/**
	 * 旋回半径を返します。
	 * @param[in] pathEx 走行パス拡張データ
	 * @return 旋回半径 (メートル単位)
	 */
	inline static double getRadius(const RunPathEx &pathEx) {
		return pathEx.runPath.turnRadius * CM2M;
	}

	/**
	 * 旋回角度を計算します。
	 * @param[in] pivot     旋回軸点
	 * @param[in] start     旋回の開始位置
	 * @param[in] end       旋回の終了位置
	 * @param[in] clockwise 旋回方向 (true:時計回り, false:反時計回り)
	 * @return ラジアン単位の旋回角度 (時計回りでも反時計回りでも正の値を返します)
	 */
	inline static double turnAngle(const Point2D &pivot, const Point2D &start, const Point2D &end, bool clockwise) {
		double a = std::atan2(end.y - pivot.y, end.x - pivot.x) - std::atan2(start.y - pivot.y, start.x - pivot.x);
		if (clockwise) {
			if (a > 0.0) {
				a -= M_PI_X2;
			}
		} else {
			if (a < 0.0) {
				a += M_PI_X2;
			}
		}
		return std::fabs(a);
	}

public:
	typedef std::pair<GeoPoint, GeoPoint> GeoSegment;
	/**
	 * 補間点を追加して、地図描画用の近似曲線を生成します。
	 * @param[in]  div  分割数 (div-1個の補間点を追加)
	 * @param[in]  base 座標変換の基準点
	 * @param[in]  in   対象のGeoSegment
	 * @param[out] out  補間点追加後の点列 (頂点数はdiv+1)
	 * @return ResultCode::SUCCESS 正常終了
	 */
	static int divideGeoSegment(const int div, const GeoPoint &base, const GeoSegment &in, GeoPointList &out);
	static int divideGeoSegments(const int div, const GeoPoint &base, const std::vector<GeoSegment> &in, std::vector<GeoPointList> &out);

	/**
	 * GeoSegmentの始点側から距離dの位置の座標を返します。
	 * @param[in]  d    始点側からの距離 (メートル単位)
	 * @param[in]  base 座標変換の基準点
	 * @param[in]  in   対象のGeoSegment
	 * @param[out] out  GeoSegment上の点
	 * @return ResultCode::SUCCESS 正常終了
	 */
	static int pointOnGeoSegment(const double d, const GeoPoint &base, const GeoSegment &in, GeoPoint &out);

};

}} // namespace yanmar::PathPlan

#endif

// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] Common header file for all functions                           */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company                :            xxxx xxxxxxxxxxxx xxxx xxxxxxxxx     */
/* Client                 :            YANMAR Co. Ltd, JAPAN                */
/* Author                 :            MANUJ SHARMA,SACHIN BHISIKAR         */
/*                                     (YANMAR PathPlanning Team)           */
/* Version                :            1.1                                  */
/*                                                                          */
/* This header file provides macros used for enabling and disabling         */
/* specific code for Windows and Android.                                   */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140124                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/*                                                                          */
/****************************************************************************/
#pragma once
#include <cmath>
#include <string>

#define LNX_ENABLE

#ifdef __NDK__
#define ANDR_ENABLE
#endif // __NDK__

#ifdef ANDR_ENABLE
#include <android/log.h>
#endif

// LOGLEVEL for UNITTEST
#ifdef UNITTEST
#undef DEBUG_LOG
#define DEBUG_LOG 3
#endif // UNITTEST

// enables DEBUG_LOG in global
#ifndef DEBUG_LOG
#define DEBUG_LOG 1
#endif // DEBUG_LOG

// Platform dependant
#ifdef ANDR_ENABLE
// NOTE: Descrived variadic macro argument "args..." is not C++ standard.
#define LOG(args...) __android_log_print(args)
#define LOGE(tag, args...) __android_log_print(ANDROID_LOG_ERROR, tag, args)
#define LOGW(tag, args...) __android_log_print(ANDROID_LOG_WARN, tag, args)
#define LOGI(tag, args...) __android_log_print(ANDROID_LOG_INFO, tag, args)
#define LOGD(tag, args...) __android_log_print(ANDROID_LOG_DEBUG, tag, args)
#define LOGV(tag, args...) __android_log_print(ANDROID_LOG_VERBOSE, tag, args)
#define LOG_DIR "debug/"
#else
#include <cstdio>
// NOTE: Should use #if instead of #ifdef bacause always defined!!
#if TARGET_OS_SIMULATOR
#define LOG_DIR "/m/debug/"
#else // TARGET_OS_SIMULATOR
#define LOG_DIR "debug/"
#endif // TARGET_OS_SIMULATOR
#define LOG(...) printf(__VA_ARGS__); printf("\n")
#define LOGE(tag, ...) { printf("[%s]", tag); printf(__VA_ARGS__); printf("\n"); }
#define LOGW(tag, ...) { printf("[%s]", tag); printf(__VA_ARGS__); printf("\n"); }
#define LOGI(tag, ...) { printf("[%s]", tag); printf(__VA_ARGS__); printf("\n"); }
#define LOGD(tag, ...) { printf("[%s]", tag); printf(__VA_ARGS__); printf("\n"); }
#define LOGV(tag, ...) { printf("[%s]", tag); printf(__VA_ARGS__); printf("\n"); }
#endif // Platform dependant

// LOG if cond was NOT true
#define ASSERTLOGE(cond, tag, ...) {if (!(cond)) { LOGE(tag, __VA_ARGS__); }}
#define ASSERTLOGV(cond, tag, ...) {if (!(cond)) { LOGV(tag, __VA_ARGS__); }}
#define ASSERTLOGD(cond, tag, ...) {if (!(cond)) { LOGD(tag, __VA_ARGS__); }}
#define ASSERTLOGI(cond, tag, ...) {if (!(cond)) { LOGI(tag, __VA_ARGS__); }}
#define ASSERTLOGW(cond, tag, ...) {if (!(cond)) { LOGW(tag, __VA_ARGS__); }}

// LOGLEVEL_xxx overrides DEBUG_LOG value
// 1: LOGLEVEL_ERROR
// 2: LOGLEVEL_WARN
// 3: LOGLEVEL_INFO
// 4: LOGLEVEL_DEBUG
// 5: LOGLEVEL_VERBOSE
#ifdef LOGLEVEL_VERBOSE
#undef DEBUG_LOG
#define DEBUG_LOG 5
#elifdef LOGLEVEL_DEBUG
#undef DEBUG_LOG
#define DEBUG_LOG 4
#elifdef LOGLEVEL_INFO
#undef DEBUG_LOG
#define DEBUG_LOG 3
#elifdef LOGLEVEL_WARN
#undef DEBUG_LOG
#define DEBUG_LOG 2
#elifdef LOGLEVEL_ERROR
#undef DEBUG_LOG
#define DEBUG_LOG 1
#endif // LOGLEVEL_X

// LOGLEVEL in defailt
// - same as DEBUG_LOG value if it defined.
// - enables LOGE in default.
#ifndef LOGLEVEL
#ifdef DEBUG_LOG
#define LOGLEVEL DEBUG_LOG
#else // DEBUG_LOG
#define LOGLEVEL 1
#endif // DEBUG_LOG
#endif // default LOGLEVEL

#ifdef STANDALONE_DEBUG
// log output in current directory when stand-alone
#undef LOG_DIR
#define LOG_DIR ""
// stand-alone NDEBUG
#ifdef NDEBUG
#undef DEBUG
#undef DEBUG_LOG
#undef LOGLEVEL
#define LOGLEVEL 0
#endif // NDEBUG
#endif // STANDALONE_DEBUG

// Proceed LOGLEVEL
#if LOGLEVEL <= 5
// all levels enabled
#endif // LOGLEVEL <= 5

#if LOGLEVEL <= 4
#undef LOGV
#define LOGV(tag, args...)
#undef ASSERTLOGV
#define ASSERTLOGV(cond, tag, ...)
#endif // LOGLEVEL <= 4

#if LOGLEVEL <= 3
#undef LOGD
#define LOGD(tag, args...)
#undef ASSERTLOGD
#define ASSERTLOGD(cond, tag, ...)
#endif // LOGLEVEL <= 3

#if LOGLEVEL <= 2
#undef LOGI
#define LOGI(tag, args...)
#undef ASSERTLOGI
#define ASSERTLOGI(cond, tag, ...)
#endif // LOGLEVEL <= 2

#if LOGLEVEL <= 1
#undef LOGW
#define LOGW(tag, args...)
#undef ASSERTLOGW
#define ASSERTLOGW(cond, tag, ...)
#endif // LOGLEVEL <= 1

// diagnosis output to text files
//#define TXT_FILE_ENABLE

namespace yanmar {
namespace PathPlan {
	static constexpr unsigned char EOL = '\n';	/// End of line
} // PathPlan

namespace param { namespace guidance {
	/*For translating the values */
	static constexpr int  TRANS_VAL = 1;

	/*For translating back the values */
	static constexpr int  TRANS_BACK_VAL = -1;
}} // param::guidance

namespace gparam = param::guidance;

namespace PathPlan {
#pragma mark - Trivial urilities
	/// val範囲内チェック
	template<typename T>
	bool isInclude(T lower, T upper, const T& val) {
		return (lower <= val && val <= upper);
	}

	/// val範囲外チェック
	template<typename T>
	bool isExclude(T lower, T upper, const T& val) {
		return (val < lower || upper < val);
	}

	/// サイクリックインクリメント
	template<typename T, typename U, typename V>
	V incCyclic(const T lower, const U upper, V val) {
		val += 1;
        if (isExclude((V)lower, (V)upper, val)) {
			val = (V)lower;
		}
		return val;
	}

	/// サイクリックデクリメント
	template<typename T, typename U, typename V>
	V decCyclic(const T lower, const U upper, V val) {
		val -= 1;
		if (isExclude((V)lower, (V)upper, val)) {
			val = (V)upper;
		}
		return val;
	}

    /// サイクリックインクリメント(イテレータ用)
    template<typename T, typename U, typename V>
    V nextCyclic(const T& beginIt, const U& endIt, V it) {
        if (it == endIt) {
            return beginIt;
        }
        
        auto nextIt = next(it);
        if (nextIt == endIt) {
            nextIt = beginIt;
        }
        return nextIt;
    }

    /// サイクリックデクリメント(イテレータ用)
    template<typename T, typename U, typename V>
    V prevCyclic(const T& beginIt, const U& endIt, V it) {
        if (it == endIt) {
            return endIt;
        } else if (it == beginIt) {
            return next(it, distance(beginIt, endIt) - 1);
        }
        
        it = prev(it);
        return it;
    }

    /// サイクリックインクリメント(イテレータ用)
    template<typename T, typename U>
    U nextCyclic(const T& seq, U it) {
        return nextCyclic(seq.cbegin(), seq.cend(), it);
    }

    template<typename T, typename U>
    U nextCyclic(T& seq, U it) {
        return nextCyclic(seq.begin(), seq.end(), it);
    }

    /// サイクリックデクリメント(イテレータ用)
    template<typename T, typename U>
    U prevCyclic(const T& seq, U it) {
        return prevCyclic(seq.cbegin(), seq.cend(), it);
    }

    template<typename T, typename U>
    U prevCyclic(T& seq, U it) {
        return prevCyclic(seq.begin(), seq.end(), it);
    }

    // タイムスタンプ文字列
    std::string getCurrentDateTimeString(const std::string& format = "%Y-%m-%d %H:%M:%S");

} // PathPLan
} // yanmar

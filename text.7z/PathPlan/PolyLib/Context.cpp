// Yanmar Confidential 20200918
/**
 * @file Context.cpp
 *
 * PathPlan コンテキストクラス
 */
#define LOG_TAG "PathPlan:Context"

#include "Common.h"

#include <cstddef>
#include <string>
#include <thread>
#include <mutex>

#include "PathPlanIF.hpp"
#include "Context.hpp"

using namespace std;
namespace yanmar { namespace PathPlan {

/**
 処理中止要求(非同期)
 
 処理中断要求を受け付ける。
 */
void Context::requestAbort() noexcept
{
    lock_guard<std::mutex> lock(mMutex);
    signals.abort = true;
}

/**
 処理中断要求確認と中断

 中断要求されていれば中断例外 Exception::Abort を投げる。
 
 @param[in] msg 例外メッセージ
 */
void Context::abortIfRequested(const std::string& msg)
{
    lock_guard<std::mutex> lock(mMutex);
    if (signals.abort) {
        LOGI(LOG_TAG "::abortIfRequested", "aborted by request. at (%s)", msg.c_str());
        throw Exception::Abort(msg);
    }
}

}} // namespace yanmar::PathPlan

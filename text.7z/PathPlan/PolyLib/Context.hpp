// Yanmar Confidential 20200918
/**
 * @file Context.hpp
 *
 * PathPlan コンテキストクラス
 */
#pragma once

#include "Common.h"

#include <cstddef>
#include <string>
#include <thread>
#include <mutex>

namespace yanmar { namespace PathPlan {

/**
 パスプラン実行コンテキストインターフェース
 
 Contexは非同期通知を取り扱うためインターフェース関数を使用すること。
 */
class ContextIF {
public:
    ContextIF() = default;
    ContextIF(const ContextIF&) = default;
    
    // 処理中止要求(非同期)
    virtual void requestAbort() noexcept = 0;
    // 処理要求確認と中断
    virtual void abortIfRequested(const std::string& msg = "") = 0;
    
protected:
    virtual ~ContextIF() = default;
};


/**
 パスプラン実行コンテキストオブジェクトクラス
 
 パスプラン実行管理クラス。非同期要求の排他アクセスを実装する。
 */
class Context : public ContextIF {
public:
    Context() = default;
    Context(const Context&) = delete;   // inhibit copy
    const Context& operator=(const Context&) = delete;   // inhibit copy
    ~Context() = default;

    // 処理中止要求(非同期)
    virtual void requestAbort() noexcept override;
    // 処理要求確認と中断
    virtual void abortIfRequested(const std::string& msg = "") override;

private:
    std::mutex mMutex;
    struct {
        bool abort = false;
    } signals;
};

}} // namespace yanmar::PathPlan

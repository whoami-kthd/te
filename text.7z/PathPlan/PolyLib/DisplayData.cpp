// Yanmar Confidential 20200918
/**
 @file DisplayData.cpp
 
 DisplayData class implementation file.
 */
/// @internal @defgroup Display Display interface

//#define DEBUG_LOG
#define LOG_TAG "PathPlan::Display"

#include "Common.h"
#include "DisplayData.h"
#include "Geometry/Coordinates.hpp"
#include "DataConverter/GuidanceDataStream.hpp"
#include "DataConverter/DisplayDataStream.hpp"

#include <array>
#include <string>
#include <random>
#include <chrono>

#include <fstream>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>

using namespace std;
using namespace yanmar;
using namespace PathPlan::DataConverter;

namespace yanmar { namespace PathPlan {


/**
 デフォルトコンストラクタ
 
 @see Display(const std::string& aPathDataId)
 */
Display::Display() :
    Display("")
{
}

/**
 コンストラクタ
 
 ヘッダーを生成しておく。
    - パスデータIDを指定できる。特にIDを指定しない場合、空文字列を与えると当クラス生成ごとにユニークなIDを自動生成する。 (デフォルトコンストラクタからの移譲動作)
	- 自動生成するIDは文字列「ミリ秒時刻(16進12桁)」-「乱数(16進8桁)」である。
 
 @param[in] aPathDataId パスID
 */
Display::Display(const std::string& aPathDataId) :
    pathDataId(aPathDataId),
    noObs(0),
    boundaryVernum(0)
{
    if (pathDataId.empty()) {
        // ID生成
        stringstream ss;
        ss << hex << uppercase << setfill('0') << fixed ;
        // 現在時刻(epocからの経過ミリ秒)
        // - エポックの日時は処理系依存だがふつうUNIX時間と同じ。
        // - steady_clockはセッションごとにモノトニック増加であるだけなのであえて使うほどではない。
        chrono::system_clock::time_point now = chrono::system_clock::now();
        ss << setw(12) << (chrono::time_point_cast<chrono::milliseconds>(now).time_since_epoch().count() & 0xffffffffffffu);
        // 乱数付加
        // - 念のため。実際に乱数ハードウエアかどうかは処理系依存だがPRNだったとしてもこの用途に支障はない。
        std::random_device randDev;
        ss << "-" << setw(8) << (randDev() & 0xffffffffu);
        pathDataId = ss.str();
        LOGD(LOG_TAG , "random_device.entropy = %f", randDev.entropy());
    }

	LOGD(LOG_TAG , "pathDataID:%s", pathDataId.c_str());
}

/**
 デストラクタ
 */
Display::~Display() {

	/*Destructor of the Display class*/
}

/**
 基準点設定
 
 座標系変換に使用する基準点(測地系座標)を設定する

 @param[in] point 基準点(緯度経度/radian)
 @ingroup Display
 */
void Display::setReferencePoint(const GeoPoint& point) {
	LOGV(LOG_TAG "::setReferencePoint", "()");
	csGeo.setRefPos(point);
}

/**
 パスデータの入力
 
 ENU座標系のパスデータ等を測地系座標に変換して保持する。
	- 座標変換のため、予め setReferencePoint() で基準点を設定する必要がある
	- ディスプレイ用パスデータはカーブ分割する

 @param[in] tp	パスデータ
 @ingroup Display
 */
void Display::setPathData(const OutPathData& tp) {
	LOGV(LOG_TAG "::CopyNavPathData", "()");

    using seg_type = OutPathData::value_type;

	// DisplayNavPath will use for Guidance
	DisplayNavPath = tp;

	// PlanPathToDisplay will use for Display purpose
	PlanPathToDisplay = makePathForDisplay(DisplayNavPath);

	for_each(DisplayNavPath.begin(), DisplayNavPath.end(), [this](seg_type& seg){ seg = ConvertLatLongPD(seg); });
	for_each(PlanPathToDisplay.begin(), PlanPathToDisplay.end(), [this](seg_type& seg){ seg = ConvertLatLongPD(seg); });
}

/**
 作業領域境界ポリゴンデータの入力
 
 ENU座標系の作業領域境界ポリゴンデータを測地系座標に変換して保持する。
     - 座標変換のため、予め setReferencePoint() で基準点を設定する必要がある
 
 @param[in] DispHLand	作業領域境界ポリゴン頂点列
 @param[in] boundaryVerSize	圃場境界の要素数
 @param[in] fieldVerSize	圃場外形の頂点数
 @ingroup Display
 */
void Display::setHeadLandPolygon(const OutVertexList& DispHLand, int boundaryVerSize, int fieldVerSize) {
	// HP polygon
	auto ci = DispHLand.begin();
	for (int i = 0; i < boundaryVerSize; i++) {
		GeoPoint geoPoint = ENUToLatlong(*ci);
		DisplayBoundaryHeadlandVert.push_back(geoPoint);
		ci++;
	}
	// OHP prolygon(s)
	noObs = (int)((fieldVerSize - boundaryVerSize) / 4.0);
	for (int i = boundaryVerSize; i < fieldVerSize; i++) {
		GeoPoint geoPoint = ENUToLatlong(*ci);
		DisplayObsHeadlandvert.push_back(geoPoint);
		ci++;
	}
}

/**
 開始・終了点入力
 
 ENU座標系の作業開始点・終了点を測地系座標に変換して保持する。
    - 予めrefPosが設定済みでなければ座標系が正しく変換できない

 @param[in] points 開始・終了点列
 @ingroup Display
 */
void Display::copyStEdPoints(const vector<Vertex>& points) {
	LOGV(LOG_TAG "::copyStEdPoints", "()");
    assert(2 <= points.size());

	/*Storing the data of Start point and End Point in a vector*/
	/*Start point*/
	if (START < points.size()) {
		const auto& tmp = points[START];
		stPoint = ENUToLatlong(tmp);
	}
	
	/*End point*/
	if (END < points.size()) {
		const auto&  tmp = points[END];
		edPoint = ENUToLatlong(tmp);
	}
}

/**
 A点B点入力
 
 A点B点を入力する
    - ここではガイダンスデータにパススルーするのみ
 
 @param[in] points A点, B点リスト
 @ingroup Display
 */
void Display::setABpoints(const array<GeoPoint, 2>& points) {
    LOGV(LOG_TAG "::setABpoints", "()");
    
    stPoint = points[0];
    edPoint = points[1];
}

/**
 有人トラクターパスデータ入力
 
 有人トラクターパスデータを測地系座標に変換して保持する

 @param[in] ManTraVetex 有人トラクターパス頂点列
 @ingroup Display
 */
void Display::CopyManTracVertexs(const vector<Vertex>& ManTraVetex) {
	LOGV(LOG_TAG "::CopyManTracVertexs", "()");

	MannedTracVertexs.reserve(ManTraVetex.size());
	for (auto& carData : ManTraVetex) {
		Lat_Lon geoData = ENUToLatlong(carData);
		MannedTracVertexs.push_back(geoData);
	}
}

/**
 PathSegmentの座標系変換(測地系へ)

 @param[in] t tData
 @return 座標変換後のtData
 */
OutPathSegment Display::ConvertLatLongPD(OutPathSegment t) const{
	LOGV(LOG_TAG, "Display - ConvertLatLongPD");

	/*Pass it to convert from ENU coordinates to LatLong*/
	t.Circ.center = ENUToLatlong(t.Circ.center);

	for (auto& point : t.points) {
		 point = ENUToLatlong(point);
	}

	return t;
}

/**
 表示用パス処理
 
 表示用処理したパス配列を生成して返す。
	- カーブ分割を行う
	- 座標変換はしない
 
 @see GeneratePathPoints(const tData& ci)
 
 @param[in] pathRaw パス(tData列)
 @return 分割した座標の入ったoutVertexXY
 @ingroup Display
 */
OutPathData Display::makePathForDisplay(const OutPathData& pathRaw) {
	LOGV(LOG_TAG ":makePathForDisplay", "(path)");

	OutPathData pathDisplay;
	for (const auto& pathSeg : pathRaw) {
		const int Data_Type = pathSeg.segmentType;
		switch (Data_Type) {
            case SegmentType::LINESEG:
				pathDisplay.push_back(pathSeg);
				break;
            case SegmentType::ARCSEG:
				if (pathSeg.segmentType == Param::Path::Segment::Type::CURVE) {
					// カーブ分割
					auto tmp = divideCurvePath(pathSeg);
					pathDisplay.insert(pathDisplay.end(), tmp.begin(), tmp.end());
				} else if (pathSeg.segmentType == Param::Path::Segment::Type::STRAIGHT) {
					pathDisplay.push_back(pathSeg);
				}
				break;
			default:
				// 予期しないタイプ検出
				throw ErrorDisplay{ErrorCode::Output::DISPLAY};
				break;
		}
	}
	
	return pathDisplay;
}

/**
 カーブセグメント分割
 
 指定のカーブの円弧を近似するCURVE_DIVISION個の直線セグメント列を返す。
	- カーブであることをassertする

 @note もしCURVE_DIV_ANGLEが定義されていたら、円弧を中心角CURVE_DIV_ANGLE度で分割したセグメント列にする。
 @see CURVE_DIV_ANGLE

 @param[in] ps カーブのOutPathSegment
 @return 分割結果のOutPathSegment列
 @ingroup Display
 */
vector<OutPathSegment> Display::divideCurvePath(const OutPathSegment& ps) {
    LOGV(LOG_TAG "::divideCurvePath", "(ps)");
    assert(ps.segmentType == Param::Path::Segment::Type::CURVE);    // カーブでない場合エラー
	
	// curve spec
	const double radius = ps.Circ.radius;
	const int orient = ps.Circ.orient;
	const GeoPoint& center = ps.Circ.center;
	Vector2D p1 = ps.point1();
	Vector2D p2 = ps.point2();
	const double radTheta1 = p1.getAngleFrom(center);
	const double radTheta2 = p2.getAngleFrom(center);
	const double distance = Radian::distance(radTheta1, radTheta2, orient);
	const double delta = abs(distance);
	// num of divisions
#ifdef CURVE_DIVIDE_BY_ANGLE
	constexpr double radCurveDivAngle = CURVE_DIV_ANGLE * 180 / M_PI;
	const int division = (delta + radCurveDivAngle) / radCurveDivAngle;
#else
	const int division = CURVE_DIVISION;
#endif
	// angle of a division
	const double radDelta = orient * delta / division;
	LOGV(LOG_TAG , "divs:%d, div angle:%g(deg)", division, DEGREE.convert(delta / division));
	// calculate division points
	vector<OutPathSegment> tmp(division + 1);
	tmp.clear();
	
	GeoPoint prevDivPoint = center + Vector2D{radius} * Vector2D{cos(radTheta1), sin(radTheta1)};
	for (int i = 1; i <= division; i++) {
		const double radTh = radTheta1 + i * radDelta;
		const GeoPoint divPoint = center + Vector2D{radius} * Vector2D{cos(radTh), sin(radTh)};
		auto divData = ps;
        divData.segmentType = SegmentType::LINESEG;
		divData.point1() = prevDivPoint;
		divData.point2() = divPoint;
		tmp.push_back(divData);
		prevDivPoint = divPoint;
	}
	
	return tmp;
}

}} // yanmar::PathPlan

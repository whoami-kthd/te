// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] Common header file for all functions                           */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company                :            xxxx xxxxxxxxxxxx xxxx xxxxxxxxx     */
/* Client                 :            YANMAR Co. Ltd, JAPAN                */
/* Author                 :            KUMARA SWAMY ELURU                   */
/*                                     ( YANMAR PathPlanning Team )         */
/* Version                :            1.1                                  */
/*                                                                          */
/* This Display Data class is responsible for writing the generated path to */
/* display in the format of CSV file. Once the final path is created by the */
/* path planner, then display data class will get the Path List data from   */
/* the Path Data object then it will convert the information of path        */
/* coordinates like Start and End points of the Field, Headland area        */
/* information and Segments, Type of Turns, Direction of Turn etc., from    */
/* ENU coordinates to latitude-longitude coordinates and write in the FIFo  */
/* Path for display to read.                                                */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140115                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/*                                                                          */
/****************************************************************************/
#pragma once
#ifndef _DISPLAY_DATA_
#define _DISPLAY_DATA_

#include <string>
#include <vector>
#include <math.h>
#include "Common.h"
#include "Geometry/Coordinates.hpp"
#include "OutLib/OutLib.h"

/// カーブ分割を角度ベースで行う
//#define CURVE_DIVIDE_BY_ANGLE

namespace yanmar { namespace PathPlan {

/// Display用データのカーブ分割角度(degree)。CURVE_DIVIDE_BY_ANGLE定義時に使用
static constexpr int CURVE_DIV_ANGLE = 15;
/// Display用データのカーブ分割数。CURVE_DIVIDE_BY_ANGLE未定義時に使用
static constexpr int CURVE_DIVISION = 5;

/**
 出力データクラス
 
 パスプラン内部データを出力用変換するためのクラス。これをDataConverterのstreamに入力すると各フォーマットで出力データが得られる。
	- 入力データの座標を測地系変換して保持する。
	- 表示用パスデータの場合、カーブ分割も行う。

 @see GudianceDataStream, DisplayDataStream
 */
class Display {
	friend class DisplayTest;
private:
	using Lat_Lon = GeoPoint;
	using Vertex = GeoPoint;
	
	/*For Start Point*/
	static constexpr unsigned int START = 0;
	/*For End Point*/
	static constexpr unsigned int END = 1;

public:
	/*Variables for storing the Path Data points*/
	std::string pathDataId;	///< 出力パスデータID
	GeoPoint stPoint;	///< 開始点
	GeoPoint edPoint;	///< 終了点
	OutPathData DisplayNavPath;		///< ガイダンス用パスデータ
	OutPathData PlanPathToDisplay;	///< ディスプレイ用パスデータ
	OutVertexList MannedTracVertexs;		///< 有人トラクターパスデータ
	OutVertexList DisplayBoundaryHeadlandVert;	///< ディスプレイ用HPポリゴン
	OutVertexList DisplayObsHeadlandvert;			///< ディスプレイ用OHPポリゴン頂点列
	int noObs = 0;			///< 障害物の数
	int boundaryVernum = 0;	///< 圃場境界頂点数

public:
	/*Constructor for the Display class*/
	Display();

    // Constructor for specified path ID
    explicit Display(const std::string& id);

	/*Destructor for the Display class*/
	~Display();

	/* Coordinates System to convert coordinates. And store the reference latitude and longitude values. */
	Geodesic csGeo;

	/*Function for storing the Latitude Longitude values*/
	void setReferencePoint(const class GeoPoint& point);

	/*For copying the PathData to DisplayData class*/
	void setPathData(const OutPathData& tp);
    void setHeadLandPolygon(const OutVertexList& DispHLand, int boundaryVerSize, int fieldVerSize);
	
	// 有人トラクターパスデータ入力
	void CopyManTracVertexs(const OutVertexList& ManTraVetex);

	/*For copying the Start&End points to DisplayData*/
	void copyStEdPoints(const OutVertexList& points);
    void setABpoints(const array<GeoPoint, 2>& points);

	/*For converting the tData to ENU values*/
	OutPathSegment ConvertLatLongPD(OutPathSegment t) const;

	// 表示用パス生成
	static OutPathData makePathForDisplay(const OutPathData& pathRaw);
	// カーブ分割
	static vector<OutPathSegment> divideCurvePath(const OutPathSegment& ps);

private:
	/**
	 ENU/測地系変換

	 ENU座標(メートル)のVertexを受け取り測地系座標(度)のLat_Lon生成して返す。
		- 変換にはGeodesicクラスを使用する。
		- 変換基準点はsetReferencePoint()で設定する。
	 */
	Lat_Lon ENUToLatlong(Vertex point) const {
		return csGeo.convert(point);
	}
};


/**
 DisplayDataクラス用例外クラス
 */
class ErrorDisplay : public Error {
public:
    using Error::Error;
};

}} // namespace yanmar::PathPlan

#endif // _DISPLAY_DATA_

// Yanmar Confidential 20200918
/**
 * @file Engine.cpp
 *
 * PathPlan本体クラス
 */
/// @internal @defgroup Engine  Engine interface

//#define DEBUG_LOG 1

#include "Common.h"
#include "Engine.hpp"

#include <cstddef>
#include <string>
#include <vector>
#include <memory>

#include "PathPlanIF.hpp"
#include "Geometry/Coordinates.hpp"
#include "Geometry/Geometry.hpp"
#include "PolygonUtil.hpp"
#include "FieldPolygon.hpp"
#include "PathLib/PathLib.h"
#include "PathLib/PathGauge.hpp"
// internal interface
#include "DisplayData.h"
#include "DataConverter/GuidanceDataStream.hpp"
#include "DataConverter/DisplayDataStream.hpp"
#include "DataConverter/SvgDataStream.hpp"

namespace yanmar { namespace PathPlan {

// TODO: OutField をnamespaceに入れて以下の関数もメンバ関数化を検討する。
namespace {
// local aliases
using Polygon = OutVertexList;
using Polygons = std::vector<Polygon>;

/**
 ポリゴンリスト生成
 
 一次元頂点列から圃場と障害物のポリゴンリストを生成して返す。

 @param[in] vertices        全頂点リスト
 @param[in] fieldVertices   圃場頂点の数
 @return Polygonsインスタンス
 */
Polygons makePolygons(const Polygon& vertices, int fieldVertices) {
	Polygons polygons;
	const int obstacleVertices = 4;
	
	auto start = vertices.begin();
	auto end = next(start, fieldVertices);
	// 圃場安全境界の頂点
	polygons.emplace_back(start, end);
	
	// 障害物安全境界の頂点
	while (end != vertices.end()) {
		start = end;
		advance(end, obstacleVertices);
		polygons.emplace_back(start, end);
	}
	
	return polygons;
}

/**
 外周作業パラメータ構築
 FileldPlolygonの持つ値からHwParamを生成する
 
 @param[in] fp   FieldPolygon
 @return HwParamインスタンス
*/
HwParam makeHwParam(const InputData& inData,  const FieldPolygon& fp) {
    HwParam hwParam;

    // 開始インデックス要素を先頭にしてコピー
    const auto& orgWhp = *fp._headlandWorkingHP;
    const int startIndex = std::max(0, fp._headlandStartIndex);
    auto it = std::next(orgWhp.cbegin(), startIndex);
    for (int i = 0; i < orgWhp.size(); i++) {
        hwParam.whp.emplace_back(*it);
        it = nextCyclic(orgWhp, it);
    }
    
    hwParam.additionalWidth = fp._headlandWorkingAdditionalWidth;
    hwParam.startIndex = fp._headlandStartIndex;
    hwParam.startPos = fp._headlandStartPos;
    hwParam.endPos = fp._headlandEndPos;
    hwParam.endPos2 = fp._headlandEndPos2;
    hwParam.endPointAvailable = inData.field.endPointAvailable;
    
    return hwParam;
}

/**
 ダンプファイル出力

 @param[in] filename 出力ファイル名
 @param[in] content 出力するテキスト
 */
void dumpToFile(const string& filename, const string& content) {
	ofstream ofile(filename);
    if (!ofile) {
        return;
    }
	ofile << content << endl;
	ofile.close();
}

} // anonymous namespace

#pragma mark - Engine class
#undef LOG_TAG
#define LOG_TAG "PathPlan::Engine"

Engine::Engine(const InputData& inputData) :
	appliedHeadlandMax(0.0),
	appliedSideMarginMax(0.0),
	inData(inputData)
{}

/**
 パスプラン生成データ設定
 @ingroup Engine
 */
int Engine::setInputData(const InputData& inputData) {
	inData = inputData;
    return inData.validate();
}

/**
 リトライ管理クラス
 */
struct RetryCondition {
    int count = 0;
    std::vector<std::string> errHistory;
    
    struct Margin {
        int val = 1000; // 初期マージン
        int step = 500; // マージン増分
        int limit = 20000;   // 上限
        
        bool isNext() const {
            return (val < limit);
        }
        
        bool isContinue() const {
            return (val <= limit);
        }
        
        bool next() {
            if (!isNext()) {
                return false;
            }
            
            val += step;
            val = std::min(val, limit);
            return true;
        }
        
        double getMargin() const { return (val / 1000.0); }
        double getLimit() const { return (limit / 1000.0); }
    } margin;

    /**
     初回エラーの保存
     
     最初に呼んだ際にエラーを保存する。2度目以降は何もしない。
     
     @param[in] err 保存するError
     
     @return 当関数の呼び出し回数
     */
    int saveError(const Error& err) {
        errHistory.push_back(err.what());
        
        return (int)errHistory.size();
    }
    
    /**
     エラー履歴ダンプ
     最初に呼んだ際にエラーを保存する。2度目以降は何もしない。
     
     @param[in] err 保存するError
     @return 当関数の呼び出し回数
     */
    void dumpToLog() {
        int no = 0;
        for (const auto& msg: errHistory) {
            LOGE("PathPlan::Engine", "ERRORS[%d] %s", no, msg.c_str());
            no++;
        }
    }
    
    /**
     初回エラーの保存
     
     最初に呼んだ際にエラーを保存する。2度目以降は何もしない。
     
     @param[in] err 保存するruntime_error
     
     @return 当関数の呼び出し回数
     */
    int saveError(const std::runtime_error& err) {
        errHistory.push_back(err.what());
        
        return (int)errHistory.size();
    }
    
    /**
     次回条件設定
     
     @return 設定結果
     @retval true   次回設定成功
     @retval false  次回設定失敗
     */
    bool next() {
        return margin.next();
    }
    
    /**
     今回有効検査
     
     @retval true   次回有り
     @retval false  次回無し
     */
    bool isContinue() const {
        return margin.isContinue();
    }
    
    /**
     次回有効検査
     
     @retval true   次回有り
     @retval false  次回無し
     */
    bool isNext() const {
        return margin.isNext();
    }
};

/**
 パスプラン生成
 @ingroup Engine
 */
void Engine::createPathData() {
	LOGD(LOG_TAG, ":createPathData()");

#ifdef STANDALONE_DEBUG
    logfilename.svg.external = "PathData.svg";
    logfilename.svg.internal = "PathData_internal.svg";
    logfilename.csv.display = "DisplayData.csv";
    logfilename.csv.guidance = "GuidanceData.csv";
#else
    // 定常デバッグ出力用
    timeStump = getCurrentDateTimeString("%Y%m%d%H%M%S");
    logfilename.svg.external = timeStump + "e.svg";
    logfilename.svg.internal = timeStump + "i.svg";
    logfilename.csv.display = "DisplayData_" + timeStump + ".csv";
    logfilename.csv.guidance = "GuidanceData_" + timeStump + ".csv";
#endif

#ifdef DEBUG_LOG
	{	// 入力データのチェック用
		stringstream osField, osTractor, osWork;
		inData.dumpTo(osField, osTractor, osWork);
		LOGD(LOG_TAG ":createPathData", "[INPUT DATA]\n%s", osField.str().c_str());
		LOGD(LOG_TAG ":createPathData", "%s", osTractor.str().c_str());
		LOGD(LOG_TAG ":createPathData", "%s", osWork.str().c_str());
	}
#endif
    
    // 基準点
    // - ノーマルパスデータの場合、圃場ポリゴンの最初の頂点
    inData.field.setRefPos(inData.field.outline.front());

	// 計算用フィールドデータ保持
	// - 以降、ENU座標系(デカルト平面・メートル単位)のフィールドデータenuFieldが使用可能。
	enuField = inData.field;

	bool blockFailed = false;
    RetryCondition retry;
    while (retry.isContinue()) {
        LOGD(LOG_TAG ":createPathData", "[CREATE PATH] safty margin: %.03f m", retry.margin.getMargin());

        // 圃場形状からパスノード生成
        InputData fpInData = inData;
		if (blockFailed) {
			fpInData.work.progressType = Param::Work::ProgressType::NORMAL;
		}
        auto fieldPolygon = make_shared<FieldPolygon>(context, fpInData, retry.margin.getMargin(), logDir);
        FieldPolygon& field = *fieldPolygon;

		InputData inDataInt = convertUnit(inData, SRC_TO_INTERNAL);
		Gauge gauge = {field.hPara, inDataInt};
		PathGauge pathGauge = {context, gauge};
		field.pathGauge = &pathGauge;

		try {
			field.calculateCoordinates(&appliedHeadlandMax, &appliedSideMarginMax, &appliedHeadlandN, &appliedSideMarginN, &headlandSideMarginFactorUnityN, &fieldArea, &effectiveArea);
		} catch (std::runtime_error& error) {
			if (std::string(error.what()) == ErrorCode::WorkingArea::BLOCK && !blockFailed) {
				// ブロック単位の作業パス生成に失敗した場合、以降はブロック単位なしで生成する
				blockFailed = true;
				continue;
			}
			if (retry.next() && std::string(error.what()) == ErrorCode::FATAL) {
				continue;
			}
			throw;
		}

        // パスノード処理順決定
        OutField outF = field.outPoly;

        outF.workStartIndex = field.workStartIndex;
        outF.driveStartIndex = field.driveStartIndex;
        outF.driveEndIndex = field.driveEndIndex;
        outF.driveStart = field.driveStart;
        outF.driveEnd = field.driveEnd;
        // サイドマージンに作業パスを生成する場合、ダミーライドを生成しない
        outF.createDummyRide = !field.createWorkingSegmentsOnSideMargin;
        if (inData.tractors.size() > 1) {
            // 有人機ありの場合、ダミーライドを生成しない
            outF.createDummyRide = false;
        }
        // サイドマージンの角度閾値
        outF.sideMarginAngle = field.sideMarginAngle;
        // 作業領域の頂点数 (非作業領域の頂点数は含まない)
        outF.workingAreaSize = (int) field._workingAreas->at(0)->size();
        outF.vortexCount = field.vortexCount;

        outF.gtemp = field.gh;
        outF.ploughDirection = inData.tractors[0].implement.pos; // 現状は正しい値をもらえていない
        outF.sweepVertices = field.SweepVertex;
        outF.copyVertices(field.FieldVertex, field.NavFieldVertex);
        outF.processRegionSequence();
        outF.distributeSweepVertices(field.OrigVertexLen);
        outF.setWorkingOrders(field.workingOrders);
        outF.createSkippedPath(inData.work.workPattern, inData.work.numSkip, field.numSkipNoFish, inData.work.canBackward, fpInData.work.progressType, inData.work.rotation);

        OutPathData outputPathData; // パスプランデータ
        vector<GeoPoint> mannedPathData;    // 有人トラクターパスデータ
        try {
            // パス生成
            auto pathData = generatePathData(field, outF, inData);
           
            // SVGファイル出力(内部データ)
            // - 内部生成圃場ポリゴン及び、作業パス向き
            dumpToSvgInternal(field, pathData);
            
            // 座標逆変換(向きを元に戻す)
            pathData.rotatePathDataDisplay();
            field.transformInverse();
            
            // SVGファイル出力(出力データ)
            // - 入力圃場ポリゴン及び、北向き
            dumpToSvgExternal(enuField, field, pathData);

            // 生成したパスデータ
            outputPathData = pathData.outputPathData;
            if (pathData.orbitalHalfway) {
                orbitalLaps -= 0.5;
				appliedHeadlandMax += field._pathIntervalforN;
				appliedSideMarginMax += field._pathIntervalforN;
				appliedHeadlandN += 1;
				appliedSideMarginN += 1;
            }
            if (inData.tractors.size() == 2) {
                // 有人トラクターパスデータ
                mannedPathData = pathData.createMannedPath(field.MannedTractorVertex);
            }
        } catch (Error& error) {
            // エラー発生
            LOGE(LOG_TAG "::createPathData", "[CREATE PATH] FAILED;\n margin(%.03f m)\n error code: %s", retry.margin.getMargin(), error.what());
            retry.saveError(error);
            if (error.compareErrorCode(ErrorCode::PathGeneration::Orbital::CORNER_DISTANCE)) {
                // 周回パスのコーナーターン生成失敗は即時エラー終了
                retry.dumpToLog();
                throw;
            } else if (error.compareErrorCode(ErrorCode::PathGeneration::PostValidation::NO_WORK_SEGMENT)) {
                // 作業パス存在しない場合は即時エラー終了
                // - エラーコード変換
                std::runtime_error err(ErrorCode::Nodes::NOTHING);
                LOGE(LOG_TAG "::createPathData", "\n expressive error code: %s", err.what());
                retry.dumpToLog();
                throw err;
            }

            if (retry.next()) {
                // リトライ
                continue;
            } else {
                // リトライオーバー
                retry.dumpToLog();
                throw;
            }
        } catch (std::runtime_error& error) {
            // エラー発生
            LOGE(LOG_TAG ":createPathData", "[CREATE PATH] FAILED;\n margin(%.03f m)\n error: %s\n", retry.margin.getMargin(), error.what());
            retry.saveError(error);
            if (retry.next()) {
                // リトライ
                continue;
            } else {
                // リトライオーバー
                retry.dumpToLog();
                throw;
            }
        }
        
        // パスプランデータ出力
        // - データ出力用クラスインスタンス生成
        Display display{inData.meta.pathDataId};
        display.setReferencePoint(enuField.csGeodesic.refPos);
    
        // 生成したパスデータ設定
        display.setPathData(outputPathData);
        // 圃場ポリゴン設定
        // - (実際にFieldPolygonで使用したもの)
        display.setHeadLandPolygon(field.FieldVertex, field.noBoundayVertices, field.OrigVertexLen);

        for (const auto& path : display.DisplayNavPath) {
            if (path.pathAttr.getExtType() == PathAttr::RideType::WORKING) {
                // 1本目の作業パスの始点と終点を取得 (オート＋AB経路で使用)
                firstWorkingPathP1 = path.enterPoint();
                firstWorkingPathP2 = path.leavePoint();
                break;
            }
        }

        // 作業開始・終了点設定
        // - パスプランに入力されたものではなくパスプランで生成した開始・終了点がある
        vector<GeoPoint> startEndPoints(2);
        startEndPoints[0] = outputPathData.front().enterPoint();
        startEndPoints[1] = outputPathData.back().leavePoint();
        display.copyStEdPoints(startEndPoints);
    
        // ガイダンスデータの出力
        GuidanceDataStream osGuidance(display.pathDataId, display.csGeo);	// IDを与える
        osGuidance << inData;	// 入力パラメータ
        osGuidance.setObstacles(field._bbObstacles);
        osGuidance << display;	// 生成データ
        guidanceData = osGuidance.str();
        LOGV(LOG_TAG, "[guidanceData output]\n%s", guidanceData.c_str());
        dumpToLogdirD(logfilename.csv.guidance, guidanceData);
    
        // ディスプレイデータの出力
        DisplayDataStream osDisplay;
        //	osGuidance << display.header;	// ヘッダー(バーションとID)
        display.CopyManTracVertexs(mannedPathData);
        osDisplay << display;
        displayData = osDisplay.str();
        LOGV(LOG_TAG, "[DisplayData output]\n%s", displayData.c_str());
        dumpToLogdirD(logfilename.csv.display, displayData);
        
        // エラーが発生しなかった
        break;
    }
}

/**
 ABパスプラン生成
 @ingroup Engine
 */
void Engine::createPathDataAB() {
#ifdef STANDALONE_DEBUG
    logfilename.svg.external = "PathData.svg";
    logfilename.svg.internal = "PathData_internal.svg";
    logfilename.csv.display = "DisplayData.csv";
    logfilename.csv.guidance = "GuidanceData.csv";
#else
    // for debug
    timeStump = getCurrentDateTimeString("%Y%m%d%H%M%S");
    logfilename.svg.external = timeStump + "ABe.svg";
    logfilename.svg.internal = timeStump + "ABi.svg";
    std::string suffixAB = "AB_";
    if (inData.field.outline.size() > 0) {
        // 圃場が設定されている場合、枕地直進のcsvファイル名
        suffixAB = "HeadlandAB_";
    }
    logfilename.csv.display = "DisplayData" + suffixAB + timeStump + ".csv";
    logfilename.csv.guidance = "GuidanceData" + suffixAB + timeStump + ".csv";
#endif // STANDALONE_DEBUG

    // 基準点
    // - ABパスの場合、A点(directionPointの始点)
    inData.field.setRefPos(inData.field.directionPoints[0]);

    // ENUデカルト平面座標系のField
	enuField = inData.field;

	// A点B点からパスノード生成
	auto fieldPolygon = make_shared<FieldPolygon>(context, inData, 1.0, logDir, true);
	FieldPolygon& field = *fieldPolygon;
	field.calculateCoordinatesAB(&tractorShiftAB);

	// OutFieldによるデータ型の変換
	OutField outF = field.outPoly;
	outF.sweepVertices = field.SweepVertex;
	outF.createPathAB();

	// PathGeneratorによるパスデータ生成
	PathGenerator pathData(context);
	pathData.setRotationPara(XY_Point{field.translate.x, field.translate.y}, (float)field.rotateAngle);
	pathData.setNodePathList(outF.finalNodePath);
	pathData.generatePathDataAB();
	pathData.rotatePathDataDisplay();

#ifdef STANDALONE_DEBUG
    dumpToSvgInternal(field, pathData);
    dumpToSvgExternal(enuField, field, pathData);
#endif // STANDALONE_DEBUG

    // パスプランデータ出力
    Display display{inData.meta.pathDataId};
	display.setReferencePoint(enuField.csGeodesic.refPos);

	// パスデータ入力
    // - 圃場ポリゴンは使用しない
    display.setPathData(pathData.outputPathData);

	// A点B点
    // - 作業方向ベクトルの2点を使用する
	display.setABpoints(inData.field.directionPoints);

	// ガイダンスデータの出力
	GuidanceDataStream osGuidance(display.pathDataId, display.csGeo);	// IDを与える
	osGuidance << inData;	// 入力パラメータ
	osGuidance.setObstacles(field._bbObstacles);
	osGuidance << display;	// 生成データ
	guidanceData = osGuidance.str();
	LOGV(LOG_TAG, "[guidanceData output]\n%s", guidanceData.c_str());
	dumpToLogdirD(logfilename.csv.guidance, guidanceData);

	// ディスプレイデータの出力
	DisplayDataStream osDisplay;
	osDisplay << display;
	displayData = osDisplay.str();
	LOGV(LOG_TAG, "[DisplayData output]\n%s", displayData.c_str());
	dumpToLogdirD(logfilename.csv.display, displayData);
}

/**
 オート作業可能領域の計算
 */
void Engine::calculateWorkablePolygon(GeoPolygon& workablePolygon) {
#if defined(PATHPLAN_TYPE) && PATHPLAN_TYPE == PATHPLAN_TYPE_COMBINE
	// 基準点
	// - ノーマルパスデータの場合、圃場ポリゴンの最初の頂点
	inData.field.setRefPos(inData.field.outline.front());

	// 計算用フィールドデータ保持
	// - 以降、ENU座標系(デカルト平面・メートル単位)のフィールドデータenuFieldが使用可能。
	enuField = inData.field;

	RetryCondition retry;
	// 圃場形状からパスノード生成
	// TODO: 暫定: FPにヒッチアップダウンマージン分考慮させる
	InputData fpInData = inData;
	fpInData.tractors[0].implement.length += inData.work.hitchUpDownMargin;
	fpInData.tractors[0].implement.cultivationPos += inData.work.hitchUpDownMargin;

	auto fieldPolygon = make_shared<FieldPolygon>(context, fpInData, retry.margin.getMargin(), logDir);
	FieldPolygon& field = *fieldPolygon;

    InputData inDataInt = convertUnit(inData, SRC_TO_INTERNAL);
    Gauge gauge = {field.hPara, inDataInt};
    PathGauge pathGauge = {context, gauge};

	field.calculateWorkablePolygon(pathGauge, workablePolygon);
	// メートル単位から緯度経度に変換
	for (GeoPoint &p : workablePolygon) {
		enuField.csGeodesic.convert(p);
	}
#endif
}

/**
 パスプラン生成可能判定
 */
bool Engine::isPathDataCreatable() {
#if defined(PATHPLAN_TYPE) && PATHPLAN_TYPE == PATHPLAN_TYPE_COMBINE
	// 基準点
	// - ノーマルパスデータの場合、圃場ポリゴンの最初の頂点
	inData.field.setRefPos(inData.field.outline.front());
	// 計算用フィールドデータ保持
	// - 以降、ENU座標系(デカルト平面・メートル単位)のフィールドデータenuFieldが使用可能。
	enuField = inData.field;

	RetryCondition retry;
	// 圃場形状からパスノード生成
	// TODO: 暫定: FPにヒッチアップダウンマージン分考慮させる
	InputData fpInData = inData;
	fpInData.tractors[0].implement.length += inData.work.hitchUpDownMargin;
	fpInData.tractors[0].implement.cultivationPos += inData.work.hitchUpDownMargin;

	auto fieldPolygon = make_shared<FieldPolygon>(context, fpInData, retry.margin.getMargin(), logDir);
	FieldPolygon& field = *fieldPolygon;

	InputData inDataInt = convertUnit(inData, SRC_TO_INTERNAL);
	Gauge gauge = {field.hPara, inDataInt};
	PathGauge pathGauge = {context, gauge};

	return field.isPathDataCreatable(pathGauge);
#else
    return true;
#endif
}

/**
 推奨中割り回数の計算
 */
int Engine::calculateRecommendNumDivide() {
#if defined(PATHPLAN_TYPE) && PATHPLAN_TYPE == PATHPLAN_TYPE_COMBINE
	// 基準点
	// - ノーマルパスデータの場合、圃場ポリゴンの最初の頂点
	inData.field.setRefPos(inData.field.outline.front());
	// 計算用フィールドデータ保持
	// - 以降、ENU座標系(デカルト平面・メートル単位)のフィールドデータenuFieldが使用可能。
	enuField = inData.field;

	RetryCondition retry;
	// 圃場形状からパスノード生成
	// TODO: 暫定: FPにヒッチアップダウンマージン分考慮させる
	InputData fpInData = inData;
	fpInData.tractors[0].implement.length += inData.work.hitchUpDownMargin;
	fpInData.tractors[0].implement.cultivationPos += inData.work.hitchUpDownMargin;

	auto fieldPolygon = make_shared<FieldPolygon>(context, fpInData, retry.margin.getMargin(), logDir);
	FieldPolygon& field = *fieldPolygon;
	field.calculateRecommendNumDivide = true;
	field.calculateCoordinates(&appliedHeadlandMax, &appliedSideMarginMax, &appliedHeadlandN, &appliedSideMarginN, &headlandSideMarginFactorUnityN, &fieldArea, &effectiveArea);
	return field.numDivide;
#else
    return 0;
#endif
}

/**
 処理中断要求
 
 @see Context::requestAbort()
 */
void Engine::requestAbort() noexcept {
    context.requestAbort();
}

/**
 パス生成
 
 圃場頂点データとソート済みノードリストからパスデータを生成して返す。
 
 @param[in] field       圃場頂点データ
 @param[in] outField    ソート済みノードリスト
 @param[in] inData      パスプラン入力データ(外部単位)
 @return PathData
 */
PathGenerator Engine::generatePathData(const FieldPolygon& field, const OutField& outField, const InputData& inData) {
	using Polygon = OutVertexList;
	using Polygons = std::vector<Polygon>;

    InputData inDataInt = convertUnit(inData, SRC_TO_INTERNAL);
    
	PathGenerator pathGenerator(context);
	const int boundaryVerSize = field.noBoundayVertices;
	const Polygons extents = makePolygons(field.InFieldVertex, boundaryVerSize);	// 圃場・障害物外形ポリゴンの分離
	const Polygons hps = makePolygons(field.FieldVertex, boundaryVerSize);	// 圃場・障害物作業領域ポリゴンの分離
    HwParam tempHwParam = makeHwParam(inDataInt, field);   // 外周作業用パラメータ

    // Gaugeを生成
    auto hPara = field.getFpGauge();
    pathGenerator.setGauge(hPara, inDataInt);
    // - Gaugeを使用する
    pathGenerator.setBoundary(extents, hps, tempHwParam);
    pathGenerator.setRotationPara(XY_Point{field.translate.x, field.translate.y}, (float)field.rotateAngle);
    pathGenerator.setNodePathList(outField.finalNodePath);
    pathGenerator.initTrnPath();
    
	try {
		pathGenerator.generatePathData();
		orbitalLaps = field.hPara.headLandRasters;
    } catch (ErrorPathGenerator& pgerror) {
        LOGE(LOG_TAG, "%s", pgerror.what());
        // エラー時のログ出力
        pgerror.printLog();
        dumpToSvgInternal(field, pathGenerator, inData, pgerror);
        throw;
    } catch (Error& error) {
        LOGE(LOG_TAG, "%s", error.what());
		// エラー時のログ出力
        ErrorPathGenerator pgerror(error);
        pgerror.printLog();
		dumpToSvgInternal(field, pathGenerator, inData, pgerror);
		throw;
    } catch (std::exception& err) {
        LOGE(LOG_TAG, "%s", err.what());
        ErrorPathGenerator pgerror(ErrorCode::FATAL);
        pgerror.setDescription(err.what());
        pgerror.printLog();
        dumpToSvgInternal(field, pathGenerator, inData, pgerror);
        throw pgerror;
    }
	
	return pathGenerator;
}

/** @ingroup Engine
 表示用データ取得
 */
std::string Engine::getDisplayData() const {
	return displayData;
}

/** @ingroup Engine
 ガイダンス用データ取得
 */
std::string Engine::getGuidanceData() const {
	return guidanceData;
}

/**
 パスデータSVGダンプ
 
 圃場境界ポリゴンとパスをSVGでダンプする
 
 @param[in] field 圃場頂点データ
 @param[in] fieldPolygon ソート済みノードリスト
 @param[in] pathData パスデータ
 */
void Engine::dumpToSvgExternal(const EnuField& field, const FieldPolygon& fieldPolygon, const PathGenerator& pathData) {
	using Polygon = OutVertexList;
	using Polygons = std::vector<Polygon>;

	const int boundaryVerSize = fieldPolygon.noBoundayVertices;
    const int headlandVerSize = fieldPolygon.noHeadlandVertices;
	Polygons extents;
	extents.push_back(field.outline);
	extents.insert(extents.end(), field.obstacles.begin(), field.obstacles.end());
	Polygons hps = makePolygons(fieldPolygon.FieldVertex, headlandVerSize);	// 圃場・障害物作業領域ポリゴンの分離
	Polygons shps = makePolygons(fieldPolygon.SHPVertex, boundaryVerSize);		// 圃場・障害物安全境界ポリゴンの分離
    vector<XY_Point> rhp;
    auto& whp = pathData.hwParam.whp;
    auto& ehp = pathData.boundarySet.ehp();

	ErrorPathGenerator pgInfo{pathData};
	pgInfo.set(inData);
	pgInfo.inData.field = field;
    dumpInfoToSVG(logDir + logfilename.svg.external, extents, hps, shps, pgInfo, rhp, whp, ehp);
}

/**
 パスデータSVGダンプ
 
 圃場境界ポリゴンとパスをSVGでダンプする
 
 @param[in] fieldPolygon    圃場頂点データ
 @param[in] pathData        パスデータ
 */
void Engine::dumpToSvgInternal(const FieldPolygon& fieldPolygon, const PathGenerator& pathData) {
	using Polygon = OutVertexList;
	using Polygons = std::vector<Polygon>;

	const int boundaryVerSize = fieldPolygon.noBoundayVertices;
	Polygons extents = makePolygons(fieldPolygon.InFieldVertex, boundaryVerSize);	// 圃場・障害物外形ポリゴンの分離
	Polygons hps = makePolygons(fieldPolygon.FieldVertex, boundaryVerSize);	// 圃場・障害物作業領域ポリゴンの分離
	Polygons shps = makePolygons(fieldPolygon.SHPVertex, boundaryVerSize);		// 圃場・障害物安全境界ポリゴンの分離
    vector<XY_Point> rhp;
    auto& whp = pathData.hwParam.whp;
    auto& ehp = pathData.boundarySet.ehp();

	ErrorPathGenerator pgInfo{pathData};
	pgInfo.set(inData);
	EnuField tmpField = enuField;
	PathPlan::Rotater rotater(-fieldPolygon.rotateAngle, tmpField.refPos);
	Vector2D shift{fieldPolygon.translate.x, fieldPolygon.translate.y};
	for (auto& point : tmpField.outline) {
		point = rotater.rotate(point);
		point += fieldPolygon.translate;
	}
	tmpField.start = rotater.rotate(tmpField.start) + shift;
	tmpField.end = rotater.rotate(tmpField.end) + shift;
    for (auto& point : tmpField.directionPoints) {
        point = rotater.rotate(point) + shift;
    }
	pgInfo.inData.field = tmpField;
	dumpInfoToSVG(logDir + logfilename.svg.internal, extents, hps, shps, pgInfo, rhp, whp, ehp);
}

/**
 パスデータSVGダンプ
 
 圃場境界ポリゴンとパスをSVGでダンプする
 
 @param[in] fieldPolygon    圃場頂点データ
 @param[in] pathData        パスデータ
 */
void Engine::dumpToSvgInternal(const OutPathData& pathData) {
    using Polygon = OutVertexList;
    using Polygons = std::vector<Polygon>;
    
    Polygons extents;
    Polygons hps;
    Polygons shps;
    vector<XY_Point> rhp;

    ErrorPathGenerator pgInfo{pathData};
    pgInfo.set(inData);
    dumpInfoToSVG(logDir + logfilename.svg.internal, extents, hps, shps, pgInfo, rhp, rhp, rhp);
}

/**
 パスデータSVGダンプ
 
 圃場境界ポリゴンとパスをSVGでダンプする
 - 出力ファイルがオープンできなければ何もしない。
 
 @param[in] fieldPolygon 外形ポリゴンリスト
 @param[in] pg     エラー発生したPathGeneartor
 @param[in] inData パスプラン入力データ
 @param[in] error エラー情報
 */
void Engine::dumpToSvgInternal(const FieldPolygon& fieldPolygon, const PathGenerator& pg, const InputData inData, ErrorPathGenerator& error) const {
    using Polygon = OutVertexList;
    using Polygons = std::vector<Polygon>;
    const int boundaryVerSize = fieldPolygon.noBoundayVertices;
    const Polygons extents = makePolygons(fieldPolygon.InFieldVertex, boundaryVerSize);	// 圃場・障害物外形ポリゴンの分離
    const Polygons hps = makePolygons(fieldPolygon.FieldVertex, boundaryVerSize);	// 圃場・障害物作業領域ポリゴンの分離
    const Polygons shps = makePolygons(fieldPolygon.SHPVertex, boundaryVerSize);		// 圃場・障害物安全境界ポリゴンの分離
    vector<XY_Point> rhp;
    vector<XY_Point> whp;
    for (const auto& p : *fieldPolygon._headlandWorkingHP) {
        whp.emplace_back(p);
    }
    auto& ehp = pg.boundarySet.ehp();

    // SVGファイル出力(内部データ)
    // - 内部生成圃場ポリゴン及び、作業パス向き

    const EnuField& tmpField = inData.field;
  	PathPlan::Rotater rotater(-fieldPolygon.rotateAngle, tmpField.refPos);
  	Vector2D shift{fieldPolygon.translate.x, fieldPolygon.translate.y};

    error.outputPath = pg.outputPathData;
    error.gauge = pg.gauge;
    error.srcPoint = pg.endPoints.src;
    error.destPoint = pg.endPoints.dest;
    error.inData = inData;
    error.inData.field.start = rotater.rotate(tmpField.start) + shift;
    error.inData.field.end = rotater.rotate(tmpField.end) + shift;
    error.inDataRaw = inData;
    PathPlan::dumpInfoToSVG(logDir + logfilename.svg.internal, extents, hps, shps, error, rhp, whp, ehp);
}

/**
 debugフォルダファイル出力(DEBUG時のみ)
 
 @param[in] filename 出力ファイル名
 @param[in] content 出力するテキスト
 */
void Engine::dumpToLogdirD(const std::string& filename, const std::string& content) const {
#if !defined(NDEBUG) || defined(DEBUG) || defined(DEBUG_LOG)
    dumpToFile(logDir + filename, content);
#endif // DEBUG
}

/**
 入力データデバッグダンプ
 
 logDirが存在する場合 inData をファイルにダンプする
 
 @param[in] filename 出力ファイル名
 @param[in] inData パスプラン入力データ
 */
    void Engine::dumpToLogdirD(const std::string& filename, const InputData& inData) const {
#if !defined(NDEBUG) || defined(DEBUG) || defined(DEBUG_LOG)
    stringstream ss;
    ss << inData;
    dumpToLogdirD(filename, ss.str());
#endif
}


/**
 コンストラクタ
 
 度・測地系座標の圃場データを与えて構築する。
    - 座標系変換の基準点は引数degFieldのrefPosを使用する。
 
 @param[in] degField 度・測地系座標の圃場データ
 */
EnuField::EnuField(const Field& degField) :
	Field(degField) {
	
	// ラジアン変換
	convAngleUnitTo(RADIAN);

	// 座標系変換クラス初期化
    //  - 基準点はこれら自身が持つ。refPosは変換を受けるので逐次参照してはいけない。
	csGeodesic.setRefPos(refPos);
	csCartesian.setRefPos(refPos);
	// 座標系変換(平面へ)
	convCoordinatesTo(csCartesian);
}

/**
 圃場ポリゴン取得
 */
Polygon_ EnuField::getFieldOutline() const {
	return makePolygon_(outline);
}

/**
 障害物ポリゴン取得
 */
Polygons_ EnuField::getObstacles() const {
	return makePolygons_(obstacles);
}

}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/**
 * @file Engine.cpp
 *
 * PathPlan本体クラス
 */
#pragma once

#include <cstddef>
#include <string>

#include "PathPlanIF.hpp"
#include "Context.hpp"
#include "Geometry/Coordinates.hpp"
#include "PolygonUtil.hpp"
#include "PathLib/PathGeneratorError.hpp"

namespace yanmar { namespace PathPlan {

class FieldPolygon;
class PathGenerator;
class OutField;

/**
 内部圃場形状データクラス
 
 内部で使用するメートル・デカルト平面系座標の圃場ポリゴンクラス。
 */
class EnuField : public Field {
public:
    EnuField() = default;
    EnuField(const EnuField&) = default;
	EnuField(const Field& aField);

	void setField(const EnuField& degField);

	/// 座標変換用オブジェクト
	Cartesian csCartesian;
	/// 座標変換用オブジェクト
	Geodesic csGeodesic;

public:
	Polygons_ getObstacles() const;
	Polygon_ getFieldOutline() const;

#ifdef DEBUG_LOG
	std::ostream& dumpTo(std::ostream& os) const;
	std::ostream& dumpToCsv(std::ostream& os) const;
#endif // DEBUG_LOG
};

/**
 * パスプランエンジン
 */
class Engine {
public:
	Engine() = default;
	Engine(const InputData& inData);
	~Engine() = default;

	/** パスプラン生成データ設定　*/
	int setInputData(const InputData& inputData);
	/** パスプラン生成　*/
	void createPathData();
	/** ABパスプラン生成　*/
	void createPathDataAB();
	/** オート作業可能領域の計算 */
	void calculateWorkablePolygon(GeoPolygon& workablePolygon);
	/** パスプラン生成可能判定 */
	bool isPathDataCreatable();
	/** 推奨中割り回数の計算 */
	int calculateRecommendNumDivide();
    /** 処理中断要求　*/
    void requestAbort() noexcept;
	/** パス生成　*/
	PathGenerator generatePathData(const FieldPolygon& field, const OutField& outField, const InputData& inData);
	/** 表示用データ取得 */
	std::string getDisplayData() const;
	/** ガイダンス用データ取得 */
	std::string getGuidanceData() const;
    
    /** 適用された枕地幅の最大値 @ingroup Engine */
    double appliedHeadlandMax = 0.0;
    /** 適用されたサイドマージンの最大値 @ingroup Engine */
    double appliedSideMarginMax = 0.0;
    /** 適用された枕地幅の最大値がパス間隔の何倍に相当するか @ingroup Engine */
    int appliedHeadlandN = 0;
    /** 適用されたサイドマージンの最大値がパス間隔の何倍に相当するか @ingroup Engine */
    int appliedSideMarginN = 0;
    /** 枕地幅/サイドマージンの計算方法が2:パス間隔整数倍(統一)の場合に、計算上で目標としたN値 @ingroup Engine */
    int headlandSideMarginFactorUnityN = 0;
    /** 圃場面積 @ingroup Engine */
    double fieldArea = 0.0;
    /** 実作業面積 @ingroup Engine */
    double effectiveArea = 0.0;
    /** ABパスをトラクターの現在地基準で生成した場合のシフト量 */
    double tractorShiftAB = 0.0;

    /** 1本目の作業パスの始点 */
    GeoPoint firstWorkingPathP1;
    /** 1本目の作業パスの終点 */
    GeoPoint firstWorkingPathP2;

	/** 外周作業の周回数 */
	double orbitalLaps = 0;

	// デバッグダンプ
	void dumpToSvgExternal(const EnuField& field, const FieldPolygon& fieldPolygon, const PathGenerator& pathData);
	void dumpToSvgInternal(const FieldPolygon& fieldPolygon, const PathGenerator& pathData);
    void dumpToSvgInternal(const OutPathData& pathData);
    void dumpToSvgInternal(const FieldPolygon& fieldPolygon, const PathGenerator& pg, const InputData inData, ErrorPathGenerator& error) const;
    void dumpToLogdirD(const std::string& filename, const std::string& content) const;
    void dumpToLogdirD(const std::string& filename, const InputData& inData) const;

public:
    std::string timeStump;              // 生成時タイムスタンプ(ログファイル名用)
    std::string logDir = LOG_DIR;       // ログ出力先ディレクトリパス
    struct {
        struct {
            std::string external;    // NORTH-UP デカルト座標系SVGファイル
            std::string internal;    // WORKPATH-ORIENT デカルト座標系SVGファイル
        } svg;
        struct {
            std::string guidance;   // ガイダンスデータダンプファイル
            std::string display;    // ディスプレイ用データダンプファイル
        } csv;
    } logfilename;

private:
	InputData inData;
	OutputData outData;
	std::string displayData;
	std::string guidanceData;

    Context context;
    EnuField enuField;
};

}} // namespace yanmar::PathPlan

// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] Common header file for all functions                           */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company                :            KPIT TECHNOLOGIES LTD, BANGALORE     */
/* Client                 :            YANMAR Co. Ltd, JAPAN                */
/* Author                 :            MANUJ SHARMA,SACHIN BHISIKAR         */
/*                                     (YANMAR PathPlanning Team)           */
/* Version                :            1.1                                  */
/*                                                                          */
/* The purpose of field data class is to organize the field data and        */
/* obstacle information in the field object.This functionality is also      */
/* responsible for creating the headland area for field as well as for      */
/* obstacles.                                                               */
/* It Creates and identifies the regions in which tractor can move          */
/* autonomously and can take turns which are easy for the guidance          */
/* algorithm to negotiate.                                                  */
/* In addition to it, also creates an initial graph for navigation.         */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140107                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/*                                                                          */
/****************************************************************************/
//#define LOGLEVEL 5

#include "Common.h"
#include "FieldPolygon.hpp"
#include "Engine.hpp"

#define EXT_STRAIGHT 2.0
#define COMBINED_WA_NWA "COMBINED_WA_NWA"

using namespace yanmar::PathPlan;

/*For Handling the Exceptions in the Path Plan*/
extern void ExceptionHandler(int Excep_value);



/**
 * 各種ポリゴンをsvgファイルに出力します。
 */
#ifdef DEBUG_LOG
void dumpPolygon(std::ofstream &myFile, const Polygon_ &polygon, int *index, double width, const std::string &color) {
	if (polygon != Polygon_()) {
		PolygonUtil::debugPrintSvg(myFile, polygon, ++(*index), width, color);
	}
}
void dumpPolygons(std::ofstream &myFile, const Polygons_ &polygons, int *index, double width, const std::string &color) {
	if (polygons != Polygons_()) {
		for (int i = 0; i < polygons->size(); ++i) {
			PolygonUtil::debugPrintSvg(myFile, polygons->at(i), ++(*index), width, color);
		}
	}
}
void dumpSegments(std::ofstream &myFile, const PolygonUtil::Segments_ &segments, int *index, double width, const std::string &color) {
    if (segments != PolygonUtil::Segments_()) {
        PolygonUtil::debugPrintSvg(myFile, segments, ++(*index), width, color);
    }
}
#endif
inline void dumpToSvg(const std::string &logDir, const std::string &inDataString, const Polygon_ &orgField, const Polygon_ &modField, const Polygon_ &field,
					  const Polygons_ &orgObstacles, const Polygons_ &modObstacles, const Polygons_ &obstacles, const Polygon_ &headlandWorkingArea,
					  const Polygons_ &workingAreas, const Polygons_ &nonWorkingAreas, const Polygons_ &pathEnvelopePolygons, const PolygonUtil::Segments_ &segments,
					  int i = 0, const std::string &errCode = "") {
#ifdef DEBUG_LOG
	int index = 0;
	std::ostringstream path;
	path << logDir << "PathData_internal";
	if (i > 0) {
		path << "_" << std::setw(3) << std::setfill('0') << i << "_" << errCode;
	}
	path << ".svg";
	std::ofstream myFile;
	myFile.open(path.str());
	PolygonUtil::debugPrintSvgHeader(myFile, orgField);
	dumpPolygon(myFile, orgField, &index, 0.5, "#888");
	dumpPolygons(myFile, orgObstacles, &index, 0.5, "#888");
	dumpPolygon(myFile, modField, &index, 0.3, "#F00");
	dumpPolygons(myFile, modObstacles, &index, 0.3, "#F00");
	dumpPolygon(myFile, field, &index, 0.2, "#000");
	dumpPolygons(myFile, obstacles, &index, 0.2, "#000");
	dumpPolygon(myFile, headlandWorkingArea, &index, 0.5, "#008");
	dumpPolygons(myFile, workingAreas, &index, 0.2, "#F00");
	dumpPolygons(myFile, nonWorkingAreas, &index, 0.2, "#F00");
	dumpPolygons(myFile, pathEnvelopePolygons, &index, 0.2, "#800");
	dumpSegments(myFile, segments, &index, 0.2, "#0F0");
	myFile << "<!--" << std::endl;
	myFile << inDataString << std::endl;
	myFile << "-->" << std::endl;
	PolygonUtil::debugPrintSvgFooter(myFile);
	myFile.close();
#endif
}

FieldPolygon::FieldPolygon(ContextIF &context, InputData &inData, double safetyMargin, const std::string& logDir, bool ab) : _context(context)
{
	std::ostringstream inDataStringStream;
	inDataStringStream << inData;
	_inDataString = inDataStringStream.str();

	_safetyMargin = safetyMargin;
    // inDataの単位をmへ変換
    const auto tractor0 = convertUnit(inData.tractors[0], SRC_TO_INTERNAL);
    const auto work = convertUnit(inData.work, SRC_TO_INTERNAL);

    _gps2Front = tractor0.gnss.lengthToFrontEnd;
	_gps2Rear = tractor0.gnss.lengthToRearEnd;
	_gps2ImplementEnd = _gps2Rear + tractor0.implement.length;
	_gps2CultivationPos = _gps2Rear + tractor0.implement.cultivationPos;

	_tractorWidth = tractor0.width;
	_implementWidthOffset = tractor0.implement.widthOffset;
	_implementWidth = tractor0.implement.width + fabs(_implementWidthOffset) * 2;
	_implementWidthOuter = _implementWidth;
	if (work.workPattern == Param::Work::Pattern::CYCLONE || work.workPattern == Param::Work::Pattern::SEMICYCLONE || work.workPattern == Param::Work::Pattern::ANTICYCLONE || work.workPattern == Param::Work::Pattern::SEMIANTICYCLONE) {
		_implementWidthOuter = fabs(tractor0.implement.width * 0.5 - fabs(_implementWidthOffset)) * 2;
	}

	_cultivationOverlap = work.overlapWidth;
	_cultivationWidth1 = tractor0.implement.cultivationWidth;
	_cultivationWidthOffset = tractor0.implement.cultivationWidthOffset;
	_cultivationWidth2 = 0.0;
	_pathInterval1 = _cultivationWidth1 - _cultivationOverlap;
	_pathInterval2 = 0.0;
	if (inData.tractors.size() > 1 && inData.tractors[1].followPos != Param::Tractor::FollowPos::CENTER) {
        const auto tractor1 = convertUnit(inData.tractors[1], SRC_TO_INTERNAL);
		_cultivationWidth2 = tractor1.implement.cultivationWidth;
		_pathInterval2 = _cultivationWidth2 - _cultivationOverlap;
	}
	pathInterval = _pathInterval1 + _pathInterval2;
	_maxWidth = max(_tractorWidth, _implementWidth);
	_maxWidthOuter = max(_tractorWidth, _implementWidthOuter);

	_turnRadius = tractor0.turnRadius;
	double tmp1 = _turnRadius + _tractorWidth * 0.5;
	double tmp2 = max(_gps2Front, _gps2Rear);
	double tractorOuterRadius = sqrt(tmp1 * tmp1 + tmp2 * tmp2);
	double tmp3 = _turnRadius + _implementWidthOuter * 0.5;
	double tmp4 = _gps2ImplementEnd;
	double implementOuterRadius = sqrt(tmp3 * tmp3 + tmp4 * tmp4);
	double tmp3_ = _turnRadius + _implementWidth * 0.5;
	double implementOuterRadius_ = sqrt(tmp3_ * tmp3_ + tmp4 * tmp4);
	_outerRadius = max(tractorOuterRadius, implementOuterRadius);
	_outerRadius2 = max(tractorOuterRadius, implementOuterRadius_);
	// 内側は単純にトラクター幅と作業機幅の大きい方で計算する(SHPが対応できないため)
	_innerRadius = _turnRadius - _maxWidth * 0.5;

	_headlandSideMarginType = work.headlandSideMarginType;
	_headlandUser = work.headlandWidthValue;
	_sideMarginUser = work.marginWidthValue;
	if (_headlandUser > 0) _headlandUser -= TOLERANCE;
	if (_sideMarginUser > 0) _sideMarginUser -= TOLERANCE;
	double minMargin = _safetyMargin + (_outerRadius - _turnRadius) + (fabs(_cultivationWidthOffset) + _cultivationWidth1) * 0.5;
	_headlandUser = std::max(_headlandUser, minMargin);
	_sideMarginUser = std::max(_sideMarginUser, minMargin);
	_pathIntervalforN = _pathInterval1;
	if (inData.tractors.size() > 1 && (_headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_EACH || _headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_UNITY) && work.usePathInterval2forN) {
		// 有人機あり、かつ(枕地幅/サイドマージンの計算方法が1または2)、かつ整数倍の基準として有人機の作業間隔を使用するフラグがtrue
		// 追走の場合、_cultivationWidth2と_pathInterval2は0でないとマズイため
		// _pathInterval2に相当する値を直接計算する
		const auto tractor1 = convertUnit(inData.tractors[1], SRC_TO_INTERNAL);
		_pathIntervalforN = tractor1.implement.cultivationWidth - _cultivationOverlap;
	}

	_numSkipPath = inData.work.numSkip;
	numSkipNoFish = ceil((_turnRadius + fabs(_cultivationWidthOffset)) * 2.0 / pathInterval - 1.0);
	_canBackward = inData.work.canBackward;
	_canBackwardImplement = inData.tractors[0].implement.canBackward;
	if (!_canBackward) {
		// バック不可の場合
        _numSkipPath = std::max(_numSkipPath, numSkipNoFish);
	}
	_searchSuitableSideMarginAngle = work.searchSuitableSideMarginAngle;
	_progressType = work.progressType;

	if (work.workPattern == Param::Work::Pattern::CYCLONE || work.workPattern == Param::Work::Pattern::SEMICYCLONE ||
        work.workPattern == Param::Work::Pattern::ANTICYCLONE || work.workPattern == Param::Work::Pattern::SEMIANTICYCLONE
    ) {
		_clockwiseVortex = (work.rotation == Param::Work::Pattern::Rotation::CLOCKWISE);
		_firstLineDir = _clockwiseVortex ? 1 : -1;
		// オフセット作業機の場合
		_workPatternVortex = true;
		if (work.workPattern == Param::Work::Pattern::CYCLONE || work.workPattern == Param::Work::Pattern::ANTICYCLONE) {
			_fullVortex = true;
		}
		_searchSuitableSideMarginAngle = false;
		_numSkipPath = std::max(_numSkipPath, numSkipNoFish);
	} else if (fabs(tractor0.implement.widthOffset) > 0 || fabs(tractor0.implement.cultivationWidthOffset) > 0) {
		_searchSuitableSideMarginAngle = false;
	}
	_headlandWorking = work.headland.process;
	_headlandRotation = work.headland.rotation;
	_hitchUpDownMargin = work.hitchUpDownMargin;
	// ドン突き
	_fold = (work.workPath.leg.type == Param::Work::WorkPath::Leg::Type::FOLD);

    // 内部計算値受け渡し用
    hPara.turnRadius = _turnRadius; // 旋回半径
    hPara.maxWidth = _maxWidth; // 全体の幅
    hPara.gps2CultivationPos = _gps2CultivationPos; // GNSSユニットから作業(耕運)位置までの長さ(作業機が作業領域の端にかかるまで直進する距離)
    hPara.margin = _safetyMargin; // 安全マージン
    hPara.outerRadius = _outerRadius; // 旋回時外径(衝突判定用)
    hPara.innerRadius = _innerRadius; // 旋回時内径(衝突判定用)
    hPara.canBackward = _canBackward; // バック許可フラグ

	noBoundayVertices = 0;
	OrigVertexLen = 0;

	_combined = false;
    _logDir = logDir;

	// エラーコードの優先度(優先度の高い(数字の大きい)エラーコードをユーザに通知する)
	errorLevels[ErrorCode::FATAL] = -9; // 想定外のエラー
	errorLevels[ErrorCode::Nodes::LIMITS] = -1; // 作業パスの本数が上限を超えた(リトライ不要)
	errorLevels[ErrorCode::WorkingArea::COMPUTE] = 0; // 座標計算に失敗した
	errorLevels[ErrorCode::WorkingArea::NOTHING] = 1; // 作業領域が確保できなかった
	errorLevels[ErrorCode::WorkingArea::DIVIDED] = 2; // 作業領域が分断された
	errorLevels[ErrorCode::WorkingArea::SIZE] = 3; // 作業パスなし(作業領域が狭すぎた)
	errorLevels[ErrorCode::Nodes::NOTHING] = 4; // 作業パスなし(作業パスの候補は存在したが、無効なパスだった)

	// 入力情報の読み込みと座標変換
	if (ab) {
		// ABパス
		_pathTypeAB = work.pathTypeAB;         // 生成方法
		_shiftValueAB = work.shiftValueAB;     // シフト値
		_extendLengthAB = work.extendLengthAB; // 作業パスを延長する長さ
		_numHalfAB_L = (work.numLeftAB  < 0) ? work.numHalfAB : work.numLeftAB;  // ABパスの左側生成本数
		_numHalfAB_R = (work.numRightAB < 0) ? work.numHalfAB : work.numRightAB; // ABパスの右側生成本数

		const EnuField& inField = inData.field;
		uiStart = inField.directionPoints[0]; // A点
		uiEnd = inField.directionPoints[1];   // B点
		_tractorPosAB = inField.tractorPos;   // トラクターの現在地 (ABパスのシフト用)

		// 作業方向がy軸方向となるように回転
		rotateAngle = M_PI_2 - atan2(uiEnd.y - uiStart.y, uiEnd.x - uiStart.x);
		double sin = std::sin(rotateAngle);
		double cos = std::cos(rotateAngle);
		PolygonUtil::rotatePoint(&uiStart, sin, cos);
		PolygonUtil::rotatePoint(&uiEnd, sin, cos);
		PolygonUtil::rotatePoint(&_tractorPosAB, sin, cos);
		// 平行移動なし
		translate.x = 0.0;
		translate.y = 0.0;
	} else {
		transformCoordinates(inData);
	}
}

FieldPolygon::~FieldPolygon() {
}

/**
 * e1の方が優先度が高ければ、正の値を返します。
 */
int FieldPolygon::compareErrorLevel(const std::string &e1, const std::string &e2) {
	auto itr1 = errorLevels.find(e1);
	auto itr2 = errorLevels.find(e2);
	int errLevel1 = (itr1 == errorLevels.end() ? -10 : itr1->second);
	int errLevel2 = (itr2 == errorLevels.end() ? -10 : itr2->second);
	return (errLevel1 - errLevel2);
}

/**
 * 実作業面積
 * 前提条件:_workingSegments/_workingSegments2がソート済みであること
 */
double FieldPolygon::getEffectiveArea() {
	Segments::iterator itr1 = _workingSegments->begin();
	Segments::iterator end1 = _workingSegments->end();
	Segments::iterator itr2 = _workingSegments2->begin();
	Segments::iterator end2 = _workingSegments2->end();
	if (itr1 == end1 && itr2 == end2) {
		// 作業パスが1本もない場合
		return 0.0;
	}
	double sum = 0.0;
	bool isPrevLine1 = true;
	std::vector<Segment> prevLine;
	std::vector<Segment> nextLine1;
	std::vector<Segment> nextLine2;
	if (itr1 != end1) getEffectiveArea_getNextLine(itr1, end1, nextLine1);
	if (itr2 != end2) getEffectiveArea_getNextLine(itr2, end2, nextLine2);
	while (nextLine1.size() > 0 || nextLine2.size() > 0) {
		bool isNextLine1;
		std::vector<Segment> nextLine;
		if (nextLine2.size() == 0 || (nextLine1.size() > 0 && nextLine1[0].p1.x < nextLine2[0].p1.x)) {
			isNextLine1 = true;
			nextLine.swap(nextLine1);
			if (itr1 != end1) getEffectiveArea_getNextLine(itr1, end1, nextLine1);
		} else {
			isNextLine1 = false;
			nextLine.swap(nextLine2);
			if (itr2 != end2) getEffectiveArea_getNextLine(itr2, end2, nextLine2);
		}
		sum += getEffectiveArea_getIntervalArea(prevLine, nextLine, isPrevLine1 ? _cultivationWidth1 : _cultivationWidth2, isNextLine1 ? _cultivationWidth1 : _cultivationWidth2);
		prevLine.swap(nextLine);
		isPrevLine1 = isNextLine1;
	}
	sum += getEffectiveArea_getIntervalArea(prevLine, nextLine1, isPrevLine1 ? _cultivationWidth1 : _cultivationWidth2, _cultivationWidth1);
	return sum;
}
/**
 * 作業ライン1本分のデータを抽出します。
 * 前提条件:(itr != end)
 */
void FieldPolygon::getEffectiveArea_getNextLine(Segments::iterator &itr, const Segments::iterator &end, std::vector<Segment> &nextLine) {
	nextLine.clear();
	// 基準となるx座標
	const double lineX = itr->p1.x;
	// x座標が変わるまでループを回して、この作業ラインのセグメントを抽出
	for (; itr != end && itr->p1.x == lineX; ++itr) {
		nextLine.push_back(*itr);
	}
}
/**
 * 2本の作業ラインに挟まれた領域の実作業面積を求めます。
 */
double FieldPolygon::getEffectiveArea_getIntervalArea(const std::vector<Segment> &prevLine, const std::vector<Segment> &nextLine, const double width1, const double width2) {
	// 左側の作業ラインの長さ
	double length1 = 0.0;
	for (auto itr = prevLine.begin(); itr != prevLine.end(); ++itr) {
		length1 += (itr->p2.y - itr->p1.y);
	}
	// 右側の作業ラインの長さ
	double length2 = 0.0;
	for (auto itr = nextLine.begin(); itr != nextLine.end(); ++itr) {
		length2 += (itr->p2.y - itr->p1.y);
	}
	// 2本の作業ライン間で共有する部分の長さ
	double lengthC = 0.0;
	// 2本の作業ライン間の間隔
	double interval = 0.0;
	if (prevLine.size() > 0 && nextLine.size() > 0) {
		// 両方の作業ラインに作業パスがある場合
		interval = nextLine[0].p1.x - prevLine[0].p1.x;
		if (interval < (width1 + width2) * 0.5) {
			// 作業ライン間にオーバーラップがある場合
			auto itr1 = prevLine.begin();
			auto itr2 = nextLine.begin();
			while (itr1 != prevLine.end() && itr2 != nextLine.end()) {
				if (itr2->p2.y > itr1->p2.y) {
					// itr2が先行
					if (itr1->p2.y > itr2->p1.y) {
						// 共有部分あり
						lengthC += itr1->p2.y - std::max(itr1->p1.y, itr2->p1.y);
					}
					++itr1;
				} else {
					// itr1が先行
					if (itr2->p2.y > itr1->p1.y) {
						// 共有部分あり
						lengthC += itr2->p2.y - std::max(itr1->p1.y, itr2->p1.y);
					}
					++itr2;
				}
			}
		}
	}
	length1 -= lengthC;
	length2 -= lengthC;
	return length1 * width1 * 0.5 + length2 * width2 * 0.5 + lengthC * interval;
}

/**
 * 作業進捗方向の正順・逆順
 */
void FieldPolygon::calculateCoordinates_internal2() {
	if (!_workPatternVortex && (fabs(_implementWidthOffset) > 0 || fabs(_cultivationWidthOffset) > 0)) {
		// 半渦巻きでない、オフセット作業
		// 1本目は上向き
		_firstLineDir = 1;
		// 作業進捗方向が正順
		restoreCoordinates(_progressOrder);
		initVertices();
		createNavigationGraph();
		if (defineStartEndPoint(false)) return;
		// 作業進捗方向が逆順
		_progressOrder = 1 - _progressOrder;
		restoreCoordinates(_progressOrder);
		initVertices();
		createNavigationGraph();
		if (defineStartEndPoint(false)) return;
		// 1本目は下向き
		_firstLineDir = -1;
		// 作業進捗方向が正順
		_progressOrder = 1 - _progressOrder;
		restoreCoordinates(_progressOrder);
		initVertices();
		createNavigationGraph();
		if (defineStartEndPoint(false)) return;
		// 作業進捗方向が逆順
		_progressOrder = 1 - _progressOrder;
		restoreCoordinates(_progressOrder);
		initVertices();
		createNavigationGraph();
		if (defineStartEndPoint(true)) return;
		throw runtime_error("E-PP-999");
	}
	restoreCoordinates(_progressOrder);
	initVertices();
	createNavigationGraph();
	if (!defineStartEndPoint(false)) {
		// 作業進捗方向が逆向きだった場合、作業方向を反転させて、再計算
		_progressOrder = 1 - _progressOrder;
		restoreCoordinates(_progressOrder);
		initVertices();
		createNavigationGraph();
		if (!defineStartEndPoint(true)) {
			throw runtime_error("E-PP-999");
		}
	}
}

/**
 * サイドマージンに作業パスを生成しない条件で計算完了した場合
 * サイドマージンにも作業パスを生成する条件で再計算して
 * 実作業面積が広くなる方の条件を採用します。
 */
double FieldPolygon::calculateCoordinates_internal() {
	double effectiveArea = 0.0;
	forceCreateWorkingSegmentsOnSideMargin = false;
	bool failed = false;
	std::string errCode = ErrorCode::FATAL;
	try {
		calculateCoordinates_internal2();
		effectiveArea = getEffectiveArea();
		if (createWorkingSegmentsOnSideMargin) {
			// サイドマージンに作業パスを生成する条件の場合、リトライ不要(意味がない)
			return effectiveArea;
		}
	} catch (const Exception::Abort &e) {
		throw;
	} catch (const std::exception &e) {
		if (createWorkingSegmentsOnSideMargin) {
			// サイドマージンに作業パスを生成する条件の場合、リトライ不要(意味がない)
			throw;
		}
		failed = true;
		errCode = e.what();
	}
	// サイドマージンに作業パスを生成しない条件の場合(失敗の場合を含む)
	// 強制的にサイドマージンに作業パスを生成する設定で再計算
	forceCreateWorkingSegmentsOnSideMargin = true;
	try {
		calculateCoordinates_internal2();
		double tmp = getEffectiveArea();
		if (failed || tmp > effectiveArea) {
			// 失敗が成功に変わった場合、または実作業面積が増えた場合
			return tmp;
		}
	} catch (const Exception::Abort &e) {
		throw;
	} catch (const std::exception &e) {
		if (failed) {
			// 両方とも失敗だった場合、優先度の高いエラーを投げる
			if (compareErrorLevel(e.what(), errCode) > 0) {
				throw;
			} else {
				throw runtime_error(errCode);
			}
		}
	}
	// 強制的にサイドマージンに作業パスを生成する設定をリセットして再再計算
	forceCreateWorkingSegmentsOnSideMargin = false;
	calculateCoordinates_internal2();
	return effectiveArea;
}

/**
 * サイドマージンの角度閾値を刻んで、実作業面積が最大となる角度閾値を求めます。
 */
double FieldPolygon::calculateCoordinates_searchSideMarginAngle() {
	const double TICK = M_PI / 360.0;
	const std::vector<double> angles = PolygonUtil::getSegmentAngles(_orgCoordinates[0].field);
	int numSideMargin = 100;
	bool success = false;
	double maxEffectiveArea = 0.0;
	double tmpSideMarginAngle = sideMarginAngle;
	std::string errCode = ErrorCode::FATAL;
	// サイドマージンの角度閾値を刻む
	while (sideMarginAngle >= TICK) {
		try {
			// サイドマージンとして扱われる辺の数を数える
			int num = 0;
			for (int i = 0; i < angles.size(); ++i) {
				double angleY = fabs(fabs(angles[i]) - M_PI_2);
				if (angleY < sideMarginAngle) {
					++num;
				}
			}
			if (num != numSideMargin) {
				// 辺の数が変化した場合だけ計算する
				numSideMargin = num;
				double effectiveArea = calculateCoordinates_internal();
				success = true;
				if (effectiveArea > maxEffectiveArea) {
					// 実作業面積が増えた場合
					maxEffectiveArea = effectiveArea;
					// 角度閾値を保持
					tmpSideMarginAngle = sideMarginAngle;
				}
			}
		} catch (const Exception::Abort &e) {
			throw;
		} catch (const std::exception &e) {
			// 優先度の高いエラーコードを保持
			if (compareErrorLevel(e.what(), errCode) > 0) {
				errCode = e.what();
			}
		}
		sideMarginAngle -= TICK;
	}
	// 全て失敗だった場合、保持している(優先度の高い)エラーを投げる
	if (!success) {
		throw runtime_error(errCode);
	}
	// 実作業面積が最大となる角度閾値を返却
	return tmpSideMarginAngle;
}

void FieldPolygon::calculateCoordinates(double *headlandMax, double *sideMarginMax, int *headlandN, int *sideMarginN, int *headlandSideMarginFactorUnityN, double *fieldArea, double *effectiveArea) {
	if (_headlandWorking != Param::Work::Headland::Process::NOP) {
		// 外周作業ありの場合、外周作業に必要な幅を問い合わせて、枕地幅・サイドマージンの最小値に設定
		double orbitalHeadlandWidth = pathGauge->getHeadlandWidth(_headlandRotation);
		_headlandUser = std::max(_headlandUser, orbitalHeadlandWidth);
		_sideMarginUser = std::max(_sideMarginUser, orbitalHeadlandWidth);
	}
	if (_searchSuitableSideMarginAngle) {
		sideMarginAngle = calculateCoordinates_searchSideMarginAngle();
	}
	*fieldArea = PolygonUtil::area(_orgCoordinates[0].field);
	*effectiveArea = calculateCoordinates_internal();
	createGraphDirected();
	detachGraph();
	// UI側には、サイドマージンの閾値を10度で計算しなおした、枕地幅・サイドマージンを返す
	std::vector<double> widths;
	if (PolygonUtil::thin5_getShiftValueMax(_field, _workingAreas->at(0), M_PI / 180.0 * 10.0, &appliedHeadlandMax, &appliedSideMarginMax, &widths, _headlandWorking != Param::Work::Headland::Process::NOP) < 0) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}
	if (_headlandSideMarginType != Param::Work::HeadlandSideMarginType::MINIMUM) {
		if (PolygonUtil::thin5_getShiftValueMax2(_orgField, _workingAreas->at(0), M_PI / 180.0 * 10.0, &appliedHeadlandMax, &appliedSideMarginMax, &widths, _headlandWorking != Param::Work::Headland::Process::NOP) < 0) {
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
	}
	if (_fold) {
		// ドン突きありの場合
		double addHeadland = 0;
		double addSideMargin = 0;
		// 作業領域ポリゴンの辺の角度でループ
		const std::vector<double> angles = PolygonUtil::getSegmentAngles(_workingAreas->at(0));
		for (int i = 0; i < angles.size(); ++i) {
			double angleY = fabs(fabs(angles[i]) - M_PI_2);
			// ドン突き効果で枕地幅・サイドマージンが減る量を計算
			double d = pathGauge->gauge.workPath.expandLength * std::sin(angleY);
			// サイドマージンの角度判定
			if (angleY < sideMarginAngle) {
				// サイドマージン
				addSideMargin = max(addSideMargin, d);
			} else {
				// 枕地
				addHeadland = max(addHeadland, d);
			}
		}
		// 枕地幅に適用
		appliedHeadlandMax -= addHeadland;
		// サイドマージンにもパスを生成するか判定
		if (createWorkingSegmentsOnSideMargin || forceCreateWorkingSegmentsOnSideMargin) {
			appliedSideMarginMax -= addSideMargin;
		}
	}

	*headlandMax = appliedHeadlandMax;
	*sideMarginMax = appliedSideMarginMax;
	*headlandN = (int) std::ceil(appliedHeadlandMax / _pathIntervalforN - 0.001);
	*sideMarginN = (int) std::ceil(appliedSideMarginMax / _pathIntervalforN - 0.001);
	*headlandSideMarginFactorUnityN = _headlandSideMarginFactorUnityN;

	if (_headlandWorking != Param::Work::Headland::Process::NOP) {
		// 外周作業ありの場合
		double d = 1000000;
		for (int i = 0; i < widths.size(); ++i) {
			// 外周作業ありの場合、1cm未満の辺は枕地幅・サイドマージンに-1が入っている
			if (widths[i] < 0) continue;
			d = std::min(d, widths[i]);
		}
		if (_workPatternVortex) {
			d += _headlandWorkingAdditionalWidth;
		}
		// 一番キツイ凹頂点の角度(ポリゴンの外側の角度/凹頂点がない場合は0)
		double minConcaveAngle = 0;
		{
			const std::vector<double> angles = PolygonUtil::getSegmentAngles(_headlandWorkingHP);
			// 折れ曲がり角度(左折なら正、右折なら負)から最大値を求める
			for (int i = 0; i < angles.size(); ++i) {
				const double a0 = angles[i];
				const double a1 = angles[PolygonUtil::nextIndex(i, angles.size())];
				const double a = PolygonUtil::normalizeRadian(a1 - a0);
				if (a > minConcaveAngle) {
					minConcaveAngle = a;
				}
			}
			// 凹頂点がある場合、ポリゴンの外側の角度に変換
			if (minConcaveAngle > 0) {
				minConcaveAngle = M_PI - minConcaveAngle;
			}
		}
		hPara.headLandRasters = pathGauge->gauge.mesureOrbitalLaps(d, pathGauge->gauge.headland.rotation, minConcaveAngle);
		if (hPara.headLandRasters < 1) {
			throw runtime_error(ErrorCode::WorkingArea::NOTHING);
		}
		if (!_canBackwardImplement) {
			// 作業機自体が後進不能の場合、外周作業の周回数に関わらず、周回経路の走行自体に2R+の枕地幅が必要になる
			// 外周作業の最内周走行時のGNSS位置(無条件で外寄り)+遷移パス生成時のエッジのシフト量(2R)+旋回時外径-(旋回半径+w/2)+安全マージン
			const double margin = _cultivationWidth1 * 0.5 + fabs(_cultivationWidthOffset) + _turnRadius + _outerRadius - _maxWidth * 0.5 + SAFTY_MARGIN;
			Polygon_ tmp = Polygon_(new Polygon);
			tmp->assign(_headlandWorkingHP->begin(), _headlandWorkingHP->end());
			Polygons_ results = Polygons_(new Polygons);
			if (PolygonUtil::thin5_feedback(tmp, results, margin, false) < 0) {
				throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
			} else if (!PolygonUtil::within(_field, results->at(0))) {
				// フィードバックで圃場内に収まらない場合、NG
				throw runtime_error(ErrorCode::WorkingArea::ORBITAL);
			}
		}

		// 外周作業用HPの形状を判定 (辺の消失等で外周作業が不可能と判断した場合、周回数を減らす)
		const double margin = max(_outerRadius - (_turnRadius + fabs(_cultivationWidthOffset) + _cultivationWidth1 * 0.5), 0.0) + SAFTY_MARGIN;
		Polygon_ src = Polygon_(new Polygon);
		Polygons_ results = Polygons_(new Polygons);
		while (true) {
			src->assign(_headlandWorkingHP->begin(), _headlandWorkingHP->end());
			results->clear();
			if (PolygonUtil::thin5_feedback(src, results, _pathIntervalforN * hPara.headLandRasters + margin, false) < 0) {
				throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
			} else if (PolygonUtil::within(_field, results->at(0))) {
				// フィードバックで圃場内に収まる場合、OK
				break;
			}
			// フィードバックで圃場外にハミ出す場合、周回数を減らしてリトライ
			hPara.headLandRasters -= 1;
			if (hPara.headLandRasters < 1) {
				throw runtime_error(ErrorCode::WorkingArea::ORBITAL);
			}
		}
		// 外周ありの有効作業面積
		src->assign(_headlandWorkingHP->begin(), _headlandWorkingHP->end());
		results->clear();
		if (PolygonUtil::thin5_feedback(src, results, _pathIntervalforN * hPara.headLandRasters, false) < 0) {
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		} else {
			*effectiveArea = PolygonUtil::area(results->at(0));
		}
		// 外周作業の塗り潰し境界(results->at(0))上にゴール位置を設定する
		const PolygonUtil::Segments_ segments = PolygonUtil::createSegments(results->at(0));
		double nearest = 1000000;
		for (int i = 0; i < segments->size(); ++i) {
			const PolygonUtil::Segment &s = segments->at(i);
			Point2D pp = PolygonUtil::perpendicularPoint(uiEnd, s);
			double d = PolygonUtil::length(uiEnd, pp);
			if (!s.contains(pp)) {
				// ppが線分s上にない場合
				d = PolygonUtil::length(uiEnd, s.p1);
				pp = s.p1;
				double d2 = PolygonUtil::length(uiEnd, s.p2);
				if (d2 < d) {
					d = d2;
					pp = s.p2;
				}
			}
			if (d < nearest) {
				nearest = d;
				_headlandEndPos2 = pp;
			}
		}

		*headlandMax += _headlandWorkingAdditionalWidth - _pathIntervalforN * hPara.headLandRasters;
		*sideMarginMax += _headlandWorkingAdditionalWidth - _pathIntervalforN * hPara.headLandRasters;
		*headlandN = (int) std::ceil(*headlandMax / _pathIntervalforN - 0.001);
		*sideMarginN = (int) std::ceil(*sideMarginMax / _pathIntervalforN - 0.001);
		*headlandSideMarginFactorUnityN += (int) std::ceil(_headlandWorkingAdditionalWidth / _pathIntervalforN - 0.001) - hPara.headLandRasters;
	}
}
void FieldPolygon::calculateCoordinatesAB(double *tractorShift) {
	// A点B点からパスノード生成
	createWorkingSegmentsAB(tractorShift);

	// 初期化処理
	_field = Polygon_(new Polygon);
	_obstacles = Polygons_(new Polygons);
	_bbObstacles = Polygons_(new Polygons);
	_workingAreas = Polygons_(new Polygons);
	_nonWorkingAreas = Polygons_(new Polygons);
	_headlandWorkingHP = Polygon_(new Polygon);
	_startEndPolygons = Polygons_(new Polygons);
	_pathEnvelopePolygons = Polygons_(new Polygons);
	InFieldVertex.clear();
	FieldVertex.clear();
	noBoundayVertices = (int) FieldVertex.size();
	OrigVertexLen = (int) FieldVertex.size();
	SHPVertex.clear();
	delVertices.clear();
	delFlagObs.clear();
}

void FieldPolygon::initFlags() {
	// 作業パスから枕地領域に出て、Uターンして作業パスに入るための条件(フラットターン・フィッシュテールターンも同じ)
	HEAD_LAND_0 = true;
	// 45度未満の鋭角凹頂点(ターンサークルがシフト出来ない頂点)を回るための条件
	HEAD_LAND_1 = false;
	// サイドマージンを走るための条件
	SIDE_MARGIN_0 = false;
	// 作業領域の右端最後の作業パスに入るためのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件(サイドマージンを走らない場合はこの条件が採用可能)
	SIDE_MARGIN_1 = true;
	// 作業領域の右端最後の作業パスからサイドマージンに入るためのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件
	SIDE_MARGIN_2 = false;
	// 作業領域の左端最初の作業パスから次の作業パスに入るためのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件(サイドマージンを走らない場合はこの条件が採用可能)
	SIDE_MARGIN_3 = true;
	// サイドマージンから作業領域の左端最初の作業パスに入るためのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件
	SIDE_MARGIN_4 = false;
	// サイドマージンにも作業パスを生成する場合に、サイドマージン領域内でのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件
	SIDE_MARGIN_5 = false;
	// サイドマージンにも作業パスを生成する場合に、サイドマージン領域内でのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件
	SIDE_MARGIN_6 = false;
	// 作業領域の右端最後の作業パスからUターンしてサイドマージンに入る(または、サイドマージンからUターンして作業領域の左端最初の作業パスに入る)ための条件
	SIDE_MARGIN_7 = false;

	// サイドマージンに作業パスを生成する/しない
	createWorkingSegmentsOnSideMargin = false;

	if (_combined) {
		// 非作業領域の統合処理が発生すると思われる場合
		HEAD_LAND_1 = true;
		SIDE_MARGIN_0 = true;
		SIDE_MARGIN_2 = true;
		SIDE_MARGIN_4 = true;
		SIDE_MARGIN_5 = true;
		SIDE_MARGIN_6 = true;
		createWorkingSegmentsOnSideMargin = true;
		if (!_canBackward) {
			// バック不可の場合
			SIDE_MARGIN_7 = true;
		}
	}
}

/**
 * 入力情報の読み込みと座標変換
 */
void FieldPolygon::transformCoordinates(const InputData &inData) {
	const EnuField& inField = inData.field;

// ----------------
// 入力情報の読み込み
	// 圃場(全体)ポリゴン
	Polygon_ field = inField.getFieldOutline();
	PolygonUtil::simplify2(field);
	if (PolygonUtil::checkPolygon(field) < 0) {
		// 頂点の個数が3個未満、または自己交差あり
		throw runtime_error("E-PP-999");
	}
	_orgCoordinates[0].field = Polygon_(new Polygon);
	_orgCoordinates[1].field = Polygon_(new Polygon);
	_orgCoordinates[0].field->assign(field->begin(), field->end());
	_orgCoordinates[1].field->assign(field->begin(), field->end());
	// 障害物ポリゴンのリスト
	Polygons_ obstacles = inField.getObstacles();
	for (int i = 0; i < obstacles->size(); ++i) {
		Polygon_ obstacle = obstacles->at(i);
		if (PolygonUtil::checkPolygon(obstacle)) {
			// 頂点の個数が3個未満、または自己交差あり
			throw runtime_error("E-PP-999");
		}
	}
	_orgCoordinates[0].obstacles = Polygons_(new Polygons);
	_orgCoordinates[1].obstacles = Polygons_(new Polygons);
	copyPolygons(obstacles, _orgCoordinates[0].obstacles);
	copyPolygons(obstacles, _orgCoordinates[1].obstacles);
	// UIで設定したスタート・エンド位置
	_orgCoordinates[0].uiStart = inField.start;
	_orgCoordinates[1].uiStart = inField.start;
	_orgCoordinates[0].uiEnd = inField.end;
	_orgCoordinates[1].uiEnd = inField.end;
	uiEndAvailable = inField.endPointAvailable;
	// UIで設定した作業方向 (の始点・終点)
	_orgCoordinates[0].dp1 = inField.directionPoints[0];
	_orgCoordinates[1].dp1 = inField.directionPoints[0];
	_orgCoordinates[0].dp2 = inField.directionPoints[1];
	_orgCoordinates[1].dp2 = inField.directionPoints[1];

// ----------------
// 座標変換
	double dx = inField.directionPoints[1].x - inField.directionPoints[0].x;
	double dy = inField.directionPoints[1].y - inField.directionPoints[0].y;
	transformCoordinates2(_orgCoordinates[0], dx, dy);
	transformCoordinates2(_orgCoordinates[1], -dx, -dy);
}

void FieldPolygon::transformCoordinates2(Coordinates &coordinates, double dx, double dy) {
	// 作業方向がy軸方向となるように圃場ポリゴンを回転
	coordinates.rotateAngle = M_PI_2 - atan2(dy, dx);
	double sin = std::sin(coordinates.rotateAngle);
	double cos = std::cos(coordinates.rotateAngle);
	PolygonUtil::rotate(coordinates.field, sin, cos);
    if (false) {
        // 渦巻きの場合、圃場ポリゴンを完全な矩形に変換
        bool easySuccess = false;
        if (coordinates.field->size() == 4) {
            // 簡易版
            std::vector<double> xs;
            std::vector<double> ys;
            for (auto itr = coordinates.field->begin(); itr != coordinates.field->end(); ++itr) {
                xs.push_back(itr->x);
                ys.push_back(itr->y);
            }
            std::sort(xs.begin(), xs.end(), [](double x1, double x2) -> int { return (x1 < x2); });
            std::sort(ys.begin(), ys.end(), [](double y1, double y2) -> int { return (y1 < y2); });
            Point2D min = Point2D(xs[1], ys[1]);
            Point2D max = Point2D(xs[2], ys[2]);
            Polygon_ tmp = PolygonUtil::box2Polygon(min, max);
            double a0 = PolygonUtil::area(coordinates.field);
            double a1 = PolygonUtil::area(tmp);
            if (a1 > a0 * 0.999 && PolygonUtil::within(coordinates.field, tmp)) {
                coordinates.field->swap(*tmp);
                easySuccess = true;
            }
        }
        if (!easySuccess) {
            Polygon_ tmp = Polygon_(new Polygon);
            PolygonUtil::getMaxRightRect(coordinates.field, tmp);
            coordinates.field->swap(*tmp);
        }
    }
	// 回転後のバウンディングボックスを取得
	Point2D fieldMin;
	Point2D fieldMax;
	PolygonUtil::boundingBox(coordinates.field, &fieldMin, &fieldMax);
	coordinates.translate.x = -fieldMin.x;
	coordinates.translate.y = -fieldMin.y;
	// x座標・y座標の最小値が、それぞれ0となるように平行移動
	PolygonUtil::translate(coordinates.field, coordinates.translate);
	// 障害物ポリゴンのリストも同じ座標系に変換
	for (int i = 0; i < coordinates.obstacles->size(); ++i) {
		PolygonUtil::rotate(coordinates.obstacles->at(i), sin, cos);
		PolygonUtil::translate(coordinates.obstacles->at(i), coordinates.translate);
	}
	// UIで設定したスタート・エンド位置も同じ座標系に変換
	PolygonUtil::rotatePoint(&coordinates.uiStart, sin, cos);
	PolygonUtil::rotatePoint(&coordinates.uiEnd, sin, cos);
	PolygonUtil::translatePoint(&coordinates.uiStart, coordinates.translate.x, coordinates.translate.y);
	PolygonUtil::translatePoint(&coordinates.uiEnd, coordinates.translate.x, coordinates.translate.y);
	// UIで設定した作業方向 (の始点・終点)
	PolygonUtil::rotatePoint(&coordinates.dp1, sin, cos);
	PolygonUtil::rotatePoint(&coordinates.dp2, sin, cos);
	PolygonUtil::translatePoint(&coordinates.dp1, coordinates.translate.x, coordinates.translate.y);
	PolygonUtil::translatePoint(&coordinates.dp2, coordinates.translate.x, coordinates.translate.y);
}

void FieldPolygon::restoreCoordinates(int index) {
	_field = Polygon_(new Polygon);
	_field->assign(_orgCoordinates[index].field->begin(), _orgCoordinates[index].field->end());
	_obstacles = Polygons_(new Polygons);
	copyPolygons(_orgCoordinates[index].obstacles, _obstacles);
	uiStart = _orgCoordinates[index].uiStart;
	uiEnd = _orgCoordinates[index].uiEnd;
	_dp1 = _orgCoordinates[index].dp1;
	_dp2 = _orgCoordinates[index].dp2;
	rotateAngle = _orgCoordinates[index].rotateAngle;
	translate = _orgCoordinates[index].translate;
}

void FieldPolygon::copyPolygons(const Polygons_ &src, Polygons_ dst) {
	dst->clear();
	for (int i = 0; i < src->size(); ++i) {
		Polygon_ p = Polygon_(new Polygon);
		p->assign(src->at(i)->begin(), src->at(i)->end());
		dst->push_back(p);
	}
}

/**
 * 圃場ポリゴンの形状を単純化します。
 */
int FieldPolygon::simplify(Polygon_ field, double width, bool complement) {
	// ソースポリゴンを保持
	Polygon_ srcField = Polygon_(new Polygon);
	srcField->assign(field->begin(), field->end());
	// やせさせる
	Polygons_ results = Polygons_(new Polygons);
	int ret = PolygonUtil::thin5_simplify(field, results, width, complement);
	if (ret == -2) {
		return -2;
	} else if (ret < 0) {
		return -1;
	}
	Polygon_ result = results->at(0);
	// 簡易調整
	if (PolygonUtil::simplify_(result) < 0 || PolygonUtil::checkPolygon(result) < 0) {
		return -1;
	}
	// ふとらせる
	if (PolygonUtil::thin5_feedback(result, results, width) < 0) {
		return -1;
	} else if (results->size() != 1) {
		return -1;
	}
	Polygon_ feedback = results->at(0);
	// 簡易調整
	if (PolygonUtil::simplify_(feedback) < 0 || PolygonUtil::checkPolygon(feedback) < 0) {
		return -1;
	}
	// ソースポリゴンからはみ出していないかチェック
	if (!PolygonUtil::within(srcField, feedback)) {
		return -1;
	}
	field->swap(*feedback);
	return 0;
}

/**
 * 作業領域ポリゴンの辺がx軸と為す角度をもとに枕地幅を決定するラムダ式
 */
PolygonUtil::Angles2Widths FieldPolygon::getAngles2Widths() {
	PolygonUtil::Angles2Widths angles2Widths = [this](std::vector<double> angles) -> std::vector<double> {
		std::vector<double> widths;
		int maxFactor = 0;
		for (int i = 0; i < angles.size(); ++i) {
			// 辺がy軸と為す角度
			double angleY = fabs(fabs(angles[i]) - M_PI_2);
			double absSin = fabs(std::sin(angles[i]));
			double absCos = fabs(std::cos(angles[i]));
			if (angleY < sideMarginAngle) {
				// 10度未満ならサイドマージン
				double requiredSideMargin = _safetyMargin + _maxWidth * 0.5;
				if (true) {
					// 作業領域の右端最後の作業パスから枕地領域に出るための左旋回時に、作業機の右後端がはみ出さない条件
					double requiredSideMarginA = _safetyMargin + _outerRadius - _turnRadius * absSin + _gps2CultivationPos * absCos;
					requiredSideMargin = max(requiredSideMargin, requiredSideMarginA);
				}
				if (SIDE_MARGIN_0) {
					// サイドマージンを走るための条件
					double requiredSideMargin0 = _safetyMargin + _maxWidthOuter;
					requiredSideMargin = max(requiredSideMargin, requiredSideMargin0);
				}
				if (SIDE_MARGIN_1) {
					// 作業領域の右端最後の作業パスに入るためのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件(サイドマージンを走らない場合はこの条件が採用可能)
					double requiredSideMargin1 = _safetyMargin + absSin * (_gps2Front + EXT_STRAIGHT + _turnRadius - pathInterval * (1 + _numSkipPath)) + absCos * (_tractorWidth * 0.5 + _turnRadius + _gps2CultivationPos);
					requiredSideMargin = max(requiredSideMargin, requiredSideMargin1);
				}
				if (SIDE_MARGIN_2) {
					// 作業領域の右端最後の作業パスからサイドマージンに入るためのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件
					double requiredSideMargin2 = _safetyMargin + absSin * (_gps2Front + EXT_STRAIGHT + _turnRadius) + absCos * (_tractorWidth * 0.5 + _turnRadius + _gps2CultivationPos);
					requiredSideMargin = max(requiredSideMargin, requiredSideMargin2);
				}
				if (SIDE_MARGIN_3) {
					// 作業領域の左端最初の作業パスから次の作業パスに入るためのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件(サイドマージンを走らない場合はこの条件が採用可能)
					double requiredSideMargin3 = _safetyMargin + absSin * (_gps2ImplementEnd + _turnRadius - pathInterval * (1 + _numSkipPath)) + absCos * (_implementWidthOuter * 0.5 + _turnRadius + _gps2CultivationPos);
					requiredSideMargin = max(requiredSideMargin, requiredSideMargin3);
				}
				if (SIDE_MARGIN_4) {
					// サイドマージンから作業領域の左端最初の作業パスに入るためのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件
					double requiredSideMargin4 = _safetyMargin + absSin * (_gps2ImplementEnd + _turnRadius) + absCos * (_implementWidthOuter * 0.5 + _turnRadius + _gps2CultivationPos);
					requiredSideMargin = max(requiredSideMargin, requiredSideMargin4);
				}
				if (SIDE_MARGIN_5) {
					// サイドマージンにも作業パスを生成する場合に、サイドマージン領域内でのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件
					double requiredSideMargin5 = _safetyMargin + absSin * (_gps2Front + EXT_STRAIGHT + _turnRadius + _cultivationWidth1 * 0.5) + absCos * (_tractorWidth * 0.5 + _turnRadius + _gps2CultivationPos);
					requiredSideMargin = max(requiredSideMargin, requiredSideMargin5);
				}
				if (SIDE_MARGIN_6) {
					// サイドマージンにも作業パスを生成する場合に、サイドマージン領域内でのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件
					double requiredSideMargin6 = _safetyMargin + absSin * (_gps2ImplementEnd + _turnRadius + _cultivationWidth1 * 0.5) + absCos * (_implementWidthOuter * 0.5 + _turnRadius + _gps2CultivationPos);
					requiredSideMargin = max(requiredSideMargin, requiredSideMargin6);
				}
				if (SIDE_MARGIN_7) {
					// 作業領域の右端最後の作業パスからUターンしてサイドマージンに入る(または、サイドマージンからUターンして作業領域の左端最初の作業パスに入る)ための条件
					// サイドマージンが広くなりすぎるため削除予定
					double requiredSideMargin7 = _safetyMargin + _outerRadius + (_turnRadius + _cultivationWidth1 * 0.5) * absSin + _gps2CultivationPos * absCos;
					requiredSideMargin = max(requiredSideMargin, requiredSideMargin7);
				}
				requiredSideMargin = max(requiredSideMargin, _sideMarginUser);
				if (_headlandWorking != Param::Work::Headland::Process::NOP) {
					// 外周作業ありの場合、ヒッチUP/DOWN用のマージン分、幅を増やす
					requiredSideMargin += _hitchUpDownMargin;
				}
				if (_headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_EACH || _headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_UNITY) {
					int factor = (int) ceil(requiredSideMargin / _pathIntervalforN);
					maxFactor = std::max(maxFactor, factor);
					requiredSideMargin = _pathIntervalforN * factor;
				}
				widths.push_back(requiredSideMargin);
			} else {
				// 10度以上なら枕地
				double requiredHeadland = _safetyMargin;
				if (HEAD_LAND_0) {
					// 作業パスから枕地領域に出て、Uターンして作業パスに入るための条件(フラットターン・フィッシュテールターンも同じ)
					double requiredHeadland0 = _safetyMargin + _outerRadius + (_turnRadius + _cultivationWidth1 * 0.5) * absSin + _gps2CultivationPos * absCos;
					requiredHeadland = max(requiredHeadland, requiredHeadland0);
				}
				if (HEAD_LAND_1) {
					// 45度未満の鋭角凹頂点(ターンサークルがシフト出来ない頂点)を回るための条件
					double requiredHeadland1 = _turnRadius * (2.0 + absSin) + _cultivationWidth1 * 0.5 * absSin + _gps2CultivationPos * absCos;
					requiredHeadland = max(requiredHeadland, requiredHeadland1);
				}
				requiredHeadland = max(requiredHeadland, _headlandUser);
				if (_headlandWorking != Param::Work::Headland::Process::NOP) {
					// 外周作業ありの場合、ヒッチUP/DOWN用のマージン分、幅を増やす
					requiredHeadland += _hitchUpDownMargin;
				}
				if (_headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_EACH || _headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_UNITY) {
					int factor = (int) ceil(requiredHeadland / _pathIntervalforN);
					maxFactor = std::max(maxFactor, factor);
					requiredHeadland = _pathIntervalforN * factor;
				}
				widths.push_back(requiredHeadland);
			}
		}
		if (_headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_UNITY) {
			double maxWidth = 0.0;
			for (int i = 0; i < widths.size(); ++i) {
				maxWidth = max(maxWidth, widths[i]);
			}
			for (int i = 0; i < widths.size(); ++i) {
				widths[i] = maxWidth;
			}
			_headlandSideMarginFactorUnityN = maxFactor;
		}
		return widths;
	};
	return angles2Widths;
}

/**
 * 非作業領域の枕地幅とサイドマージンを決定するラムダ式
 */
PolygonUtil::Angles2Widths FieldPolygon::getAngles2WidthsObs() {
	PolygonUtil::Angles2Widths angles2Widths = [this](std::vector<double> angles) -> std::vector<double> {
		std::vector<double> widths;
		for (int i = 0; i < angles.size(); ++i) {
			// 辺がy軸と為す角度
			double angleY = fabs(fabs(angles[i]) - M_PI_2);
			if (angleY < sideMarginAngle) {
				// 10度未満ならサイドマージン
				double requiredSideMargin = _safetyMargin + _outerRadius;
				requiredSideMargin = max(requiredSideMargin, _sideMarginUser);
				if (_headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_EACH || _headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_UNITY) {
					int factor = (int) ceil(requiredSideMargin / _pathIntervalforN);
					requiredSideMargin = _pathIntervalforN * factor;
				}
				widths.push_back(requiredSideMargin);
			} else {
				// 10度以上なら枕地
				double requiredHeadland = _safetyMargin + _outerRadius + _gps2CultivationPos;
				requiredHeadland = max(requiredHeadland, _headlandUser);
				if (_headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_EACH || _headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_UNITY) {
					int factor = (int) ceil(requiredHeadland / _pathIntervalforN);
					requiredHeadland = _pathIntervalforN * factor;
				}
				widths.push_back(requiredHeadland);
			}
		}
		if (_headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_UNITY) {
			double maxWidth = 0.0;
			for (int i = 0; i < widths.size(); ++i) {
				maxWidth = max(maxWidth, widths[i]);
			}
			for (int i = 0; i < widths.size(); ++i) {
				widths[i] = maxWidth;
			}
		}
		return widths;
	};
	return angles2Widths;
}

/**
 * サイドマージン同士の繋がりを考慮した上で、x座標の最小値/最大値に繋がらないサイドマージンがあるか判定する
 * 両サイド以外にもサイドマージンがある場合、サイドマージンを走る
 * true: 両サイド以外にサイドマージンあり
 */
bool FieldPolygon::checkRunSideMargin(const Polygon_ &polygon, double *smMin, double *smMax) {
	Point2D min;
	Point2D max;
	PolygonUtil::boundingBox(polygon, &min, &max);
	std::vector<bool> isSideMargins;
	int indexMinX = 0;
	int indexMaxX = 0;
	double minX = max.x;
	double maxX = min.x;
	for (int i = 0; i < polygon->size(); ++i) {
		isSideMargins.push_back(false);
		double x = polygon->at(i).x;
		if (x < minX) {
			minX = x;
			indexMinX = i;
		}
		if (x > maxX) {
			maxX = x;
			indexMaxX = i;
		}
	}
	PolygonUtil::Segments_ segments = PolygonUtil::createSegments(polygon);
	// x座標の最小値を持つセグメントは、segments->at(indexMinX-1)とsegments->at(indexMinX)
	// x座標の最大値を持つセグメントは、segments->at(indexMaxX-1)とsegments->at(indexMaxX)
	// それぞれのセグメントからそれぞれの方向に探索して、サイドマージンが続く限りサイドマージンフラグを立てていく
	int index;
	index = indexMinX;
	while (true) {
		double a = segments->at(index).angle();
		double angleY = fabs(fabs(a) - M_PI_2);
		if (a > 0.0 && angleY < sideMarginAngle) {
			isSideMargins[index] = true;
			minX = std::max(minX, segments->at(index).p2.x);
			index = PolygonUtil::nextIndex(index, segments->size());
		} else {
			break;
		}
	}
	index = PolygonUtil::prevIndex(indexMinX, segments->size());
	while (true) {
		double a = segments->at(index).angle();
		double angleY = fabs(fabs(a) - M_PI_2);
		if (a > 0.0 && angleY < sideMarginAngle) {
			isSideMargins[index] = true;
			minX = std::max(minX, segments->at(index).p1.x);
			index = PolygonUtil::prevIndex(index, segments->size());
		} else {
			break;
		}
	}
	index = indexMaxX;
	while (true) {
		double a = segments->at(index).angle();
		double angleY = fabs(fabs(a) - M_PI_2);
		if (a < 0.0 && angleY < sideMarginAngle) {
			isSideMargins[index] = true;
			maxX = std::min(maxX, segments->at(index).p2.x);
			index = PolygonUtil::nextIndex(index, segments->size());
		} else {
			break;
		}
	}
	index = PolygonUtil::prevIndex(indexMaxX, segments->size());
	while (true) {
		double a = segments->at(index).angle();
		double angleY = fabs(fabs(a) - M_PI_2);
		if (a < 0.0 && angleY < sideMarginAngle) {
			isSideMargins[index] = true;
			maxX = std::min(maxX, segments->at(index).p1.x);
			index = PolygonUtil::prevIndex(index, segments->size());
		} else {
			break;
		}
	}
	if (smMin) *smMin = minX;
	if (smMax) *smMax = maxX;
	for (int i = 0; i < segments->size(); ++i) {
		if (isSideMargins[i]) {
			// isSideMarginsのフラグが立っているセグメントは両サイドのサイドマージン
			continue;
		}
		double a = segments->at(i).angle();
		double angleY = fabs(fabs(a) - M_PI_2);
		if (angleY < sideMarginAngle) {
			// y軸と為す角度が10度未満、かつサイドマージンフラグが立っていない場合
			// 両サイド以外にもサイドマージンが存在する(サイドマージンを走る)
			return true;
		}
	}
	return false;
}

/**
 * 凹頂点があるか判定する
 * true: 凹頂点がある
 */
bool FieldPolygon::checkConcave() {
	std::vector<double> angles = PolygonUtil::getSegmentAngles(_workingAreas->at(0));
	for (int i = 0; i < angles.size(); ++i) {
		double angle1 = angles[i];
		double angle2 = angles[PolygonUtil::nextIndex(i, angles.size())];
		if (PolygonUtil::normalizeRadian(angle2 - angle1) > M_PI_4) {
			// 折れ曲がり角度が+45度以上(内角が225度以上)の凹頂点がある
			return true;
		}
	}
	return false;
}

/**
 * 非作業領域ポリゴン同士の交差判定を行う
 * 交差する組み合わせが存在した場合、以下の処理を実行して、trueを返す
 * ・交差する非作業領域ポリゴン同士を結合してまとめる
 * ・対応する障害物ポリゴン同士も結合してまとめる
 * 交差する組み合わせが存在しない場合、falseを返す
 */
bool FieldPolygon::checkNonWorkingAreasIntersection() {
	Point2D min1;
	Point2D max1;
	Point2D min2;
	Point2D max2;
	for (int i = 0; i < (int) _nonWorkingAreas->size() - 1; ++i) {
		PolygonUtil::boundingBox(_nonWorkingAreas->at(i), &min1, &max1);
		for (int j = i + 1; j < _nonWorkingAreas->size(); ++j) {
			PolygonUtil::boundingBox(_nonWorkingAreas->at(j), &min2, &max2);
			// 現状の非作業領域ポリゴンは矩形しかないので、Rectの交差判定で良い
			if (min1.x < max2.x && min2.x < max1.x && min1.y < max2.y && min2.y < max1.y) {
				// 交差した非作業領域ポリゴンのインデックスはiとj
				// 結合前の非作業領域ポリゴンを削除
				Polygons_ tmp1 = Polygons_(new Polygons);
				for (int k = 0; k < _nonWorkingAreas->size(); ++k) {
					if (k != i && k != j) {
						tmp1->push_back(_nonWorkingAreas->at(k));
					}
				}
				_nonWorkingAreas->swap(*tmp1);
				// 結合後の非作業領域ポリゴンを追加
				min1.x = std::min(min1.x, min2.x);
				min1.y = std::min(min1.y, min2.y);
				max1.x = std::max(max1.x, max2.x);
				max1.y = std::max(max1.y, max2.y);
				_nonWorkingAreas->push_back(PolygonUtil::box2Polygon(min1, max1));
				// 障害物ポリゴンも同じ
				PolygonUtil::boundingBox(_obstacles->at(i), &min1, &max1);
				PolygonUtil::boundingBox(_obstacles->at(j), &min2, &max2);
				// 結合前の障害物ポリゴンを削除
				Polygons_ tmp2 = Polygons_(new Polygons);
				for (int k = 0; k < _obstacles->size(); ++k) {
					if (k != i && k != j) {
						tmp2->push_back(_obstacles->at(k));
					}
				}
				_obstacles->swap(*tmp2);
				// 結合後の障害物ポリゴンを追加
				min1.x = std::min(min1.x, min2.x);
				min1.y = std::min(min1.y, min2.y);
				max1.x = std::max(max1.x, max2.x);
				max1.y = std::max(max1.y, max2.y);
				_obstacles->push_back(PolygonUtil::box2Polygon(min1, max1));
				return true;
			}
		}
	}
	return false;
}

/**
 * 作業領域ポリゴンと非作業領域ポリゴンとの交差判定を行う
 * 作業領域ポリゴンと交差する非作業領域ポリゴンが存在する場合
 * ・枕地幅/サイドマージンを調整する
 * ・作業領域ポリゴンから非作業領域ポリゴンを減算する
 * ・非作業領域ポリゴンと対応する障害物ポリゴンを削除する
 * 連鎖時の処理を行う
 */
void FieldPolygon::checkWorkingAreasIntersection() {
	bool combined;
	Polygons_ tmpNonWorkingAreas = Polygons_(new Polygons);
	Polygons_ nonWorkingAreas = Polygons_(new Polygons);
	Polygons_ obstacles = Polygons_(new Polygons);
	_nonWorkingAreas->swap(*nonWorkingAreas);
	_obstacles->swap(*obstacles);
	for (int i = 0; i < nonWorkingAreas->size(); ++i) {
		combined = false;
		Polygon_ nonWorkingArea = nonWorkingAreas->at(i);
		Polygon_ obstacle = obstacles->at(i);
		Polygons_ workingAreas = Polygons_(new Polygons);
		_workingAreas->swap(*workingAreas);
		for (int j = 0; j < workingAreas->size(); ++j) {
			Polygon_ workingArea = workingAreas->at(j);
			std::vector<Point2D> crossPoints;
			bool collinear = PolygonUtil::getCrossPoints(nonWorkingArea, workingArea, &crossPoints);
			if (collinear || crossPoints.size() > 0) {
				// 辺の重なりがある場合、または交点を持つ場合
				// 作業領域ポリゴンから非作業領域ポリゴンを減算
				// 非作業領域の枕地幅/サイドマージンは、作業領域として必要な枕地幅/サイドマージンよりも狭い可能性がある
				// 不足分がある場合、枕地幅/サイドマージンを追加する
				PolygonUtil::Angles2Widths angles2WidthsObs = getAngles2WidthsObs();
				PolygonUtil::Angles2Widths angles2Widths = getAngles2Widths();
				std::vector<double> angles = { 0.0, M_PI_2 };
				std::vector<double> applied = angles2WidthsObs(angles);
				std::vector<double> required;
				if (_headlandSideMarginType == Param::Work::HeadlandSideMarginType::FACTOR_UNITY) {
					std::vector<double> angles2 = PolygonUtil::getSegmentAngles(_field);
					angles2.push_back(0.0);
					angles2.push_back(M_PI_2);
					required = angles2Widths(angles2);
				} else {
					required = angles2Widths(angles);
				}
				Point2D nonWorkingAreaMin;
				Point2D nonWorkingAreaMax;
				PolygonUtil::boundingBox(nonWorkingArea, &nonWorkingAreaMin, &nonWorkingAreaMax);
				if (required[0] > applied[0]) {
					nonWorkingAreaMin.y -= (required[0] - applied[0]);
					nonWorkingAreaMax.y += (required[0] - applied[0]);
				}
				if (required[1] > applied[1]) {
					nonWorkingAreaMin.x -= (required[1] - applied[1]);
					nonWorkingAreaMax.x += (required[1] - applied[1]);
				}
				nonWorkingArea->swap(*PolygonUtil::box2Polygon(nonWorkingAreaMin, nonWorkingAreaMax));
				tmpNonWorkingAreas->push_back(nonWorkingArea);
				// 作業領域ポリゴンから非作業領域ポリゴンを減算
				Polygons_ subtracted = Polygons_(new Polygons);
				PolygonUtil::getCrossPoints(workingArea, nonWorkingArea, &crossPoints);
				if (PolygonUtil::difference2(workingArea, nonWorkingArea, subtracted, &crossPoints) < 0) {
					throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
				}
				// 減算結果を追加
				for (int k = 0; k < subtracted->size(); ++k) {
					_workingAreas->push_back(subtracted->at(k));
				}
				combined = true;
			} else {
				// 交点を持たない場合、そのまま追加(元のリストに戻す)
				_workingAreas->push_back(workingArea);
			}
		}
		if (combined) {
			// 統合された場合、削除(元のリストに戻さない)
		} else {
			// 統合されなかった場合、そのまま追加(元のリストに戻す)
			_nonWorkingAreas->push_back(nonWorkingArea);
			_obstacles->push_back(obstacle);
		}
	}
	if (merge(tmpNonWorkingAreas)) {
		for (int i = 0; i < tmpNonWorkingAreas->size(); ++i) {
			Polygons_ tmpWorkingAreas = Polygons_(new Polygons);
			Polygons_ tmpResult = Polygons_(new Polygons);
			for (int j = 0; j < _workingAreas->size(); ++j) {
				if (PolygonUtil::difference(_workingAreas->at(j), tmpNonWorkingAreas->at(i), tmpResult) < 0) {
					throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
				}
				for (int k = 0; k < tmpResult->size(); ++k) {
					tmpWorkingAreas->push_back(tmpResult->at(k));
				}
			}
			_workingAreas->swap(*tmpWorkingAreas);
		}
	}
}
bool FieldPolygon::merge(Polygons_ polygons)
{
	bool merged = false;
	bool intersect = true;
	while (intersect) {
		intersect = false;
		int i = 0;
		int j = 1;
		Point2D min1;
		Point2D max1;
		Point2D min2;
		Point2D max2;
		for (i = 0; i < (int) polygons->size() - 1; ++i) {
			PolygonUtil::boundingBox(polygons->at(i), &min1, &max1);
			for (j = i + 1; j < polygons->size(); ++j) {
				PolygonUtil::boundingBox(polygons->at(j), &min2, &max2);
				// 現状の非作業領域ポリゴンは矩形しかないので、Rectの交差判定で良い
				if (min1.x < max2.x && min2.x < max1.x && min1.y < max2.y && min2.y < max1.y) {
					intersect = true;
					break; // インデックス値jを残すためbreak
				}
			}
			if (intersect) {
				break; // インデックス値iを残すためbreak
			}
		}
		if (intersect) {
			// 交差した非作業領域ポリゴンのインデックスはiとj
			// 結合前の非作業領域ポリゴンを削除
			Polygons_ tmp1 = Polygons_(new Polygons);
			for (int k = 0; k < polygons->size(); ++k) {
				if (k == i || k == j) {
					continue;
				}
				tmp1->push_back(polygons->at(k));
			}
			polygons->swap(*tmp1);
			// 結合後の非作業領域ポリゴンを追加
			min1.x = std::min(min1.x, min2.x);
			min1.y = std::min(min1.y, min2.y);
			max1.x = std::max(max1.x, max2.x);
			max1.y = std::max(max1.y, max2.y);
			polygons->push_back(PolygonUtil::box2Polygon(min1, max1));
			merged = true;
		}
	}
	return merged;
}

/**
 * 既存フォーマットのデータを生成する
 */
void FieldPolygon::generateOrgFormatData() {
	InFieldVertex.clear();
	for (int i = 0; i < _field->size(); ++i) {
		const Point2D &p = _field->at(i);
		InFieldVertex.push_back(p);
	}
    noBoundayVertices = (int) InFieldVertex.size();
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		for (int j = 0; j < obstacle->size(); ++j) {
			const Point2D &p = obstacle->at(j);
			InFieldVertex.push_back(p);
		}
	}

	FieldVertex.clear();
	for (int i = 0; i < _workingAreas->size(); ++i) {
		Polygon_ workingArea = _workingAreas->at(i);
		for (int j = 0; j < workingArea->size(); ++j) {
			const Point2D &p = workingArea->at(j);
			FieldVertex.push_back(p);
		}
	}
	noHeadlandVertices = (int) FieldVertex.size();
	for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
		Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
		for (int j = 0; j < nonWorkingArea->size(); ++j) {
			const Point2D &p = nonWorkingArea->at(j);
			FieldVertex.push_back(p);
		}
	}
	OrigVertexLen = (int) FieldVertex.size();

	SHPVertex.clear();
	for (int i = 0; i < _pathEnvelopePolygons->size(); ++i) {
		Polygon_ pathEnvelopePolygon = _pathEnvelopePolygons->at(i);
		for (int j = 0; j < pathEnvelopePolygon->size(); ++j) {
			const Point2D &p = pathEnvelopePolygon->at(j);
			SHPVertex.push_back(p);
		}
	}

	delVertices.clear();
	for (int i = 0; i < noBoundayVertices; ++i) {
		delVertices.push_back(0);
	}
	for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
		delFlagObs.push_back(0);
	}
}

/**
 * 各種ポリゴンの生成
 */
void FieldPolygon::generatePolygons() {
	int ret;
	std::vector<double> widths;
	// ポリゴンの辺がx軸と為す角度をもとに枕地幅を決定するラムダ式
	const PolygonUtil::Angles2Widths angles2Widths = getAngles2Widths();
	// 作業領域ポリゴンのリスト
	_workingAreas = Polygons_(new Polygons);
	Polygon_ tmpField = Polygon_(new Polygon);
	bool remake = false;

// ----------------
// 作業領域・非作業領域の生成(その1/5)
// 作業領域の計算(1回目)
	// サイドマージンにも強制的に作業パスを生成する設定(リトライ時など)の場合
	// または、外周作業ありの場合、1回目の計算はスキップ
	if (_workPatternVortex || (!forceCreateWorkingSegmentsOnSideMargin && _headlandWorking == Param::Work::Headland::Process::NOP)) {
		_workingAreas->clear();
		tmpField->clear();
		tmpField->assign(_field->begin(), _field->end());
		ret = PolygonUtil::thin5(tmpField, _workingAreas, angles2Widths);
		if (ret == -2) {
			// 作業領域が確保できなかった
			throw runtime_error(ErrorCode::WorkingArea::NOTHING);
		} else if (ret == -3) {
			// 作業領域が複数の領域に分断された
			throw runtime_error(ErrorCode::WorkingArea::DIVIDED);
		} else if (ret < 0) {
			// やせさせる処理が失敗した
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		if (PolygonUtil::thin5_getShiftValueMax(tmpField, _workingAreas->at(0), sideMarginAngle, &appliedHeadlandMax, &appliedSideMarginMax, &widths) < 0) {
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		} else {
			// 枕地幅、サイドマージンが必要な分だけ確保されているかチェック
			std::vector<double> requiredWidths = angles2Widths(PolygonUtil::getSegmentAngles(tmpField));
			if (requiredWidths.size() != widths.size()) {
				throw runtime_error(ErrorCode::FATAL);
			}
			for (int i = 0; i < widths.size(); ++i) {
				if (widths[i] + TOLERANCE_2 < requiredWidths[i]) {
					throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
				}
			}
		}
		if (checkConcave()) {
			// 凹頂点を安全に回るための条件を追加
			HEAD_LAND_1 = true;
			remake = true;
		}
	}

// ----------------
// 作業領域・非作業領域の生成(その2/5)
// 作業領域のチェックと再計算
	// 1回目の計算は厳しい(サイドマージン・枕地幅が小さくなる)条件で実行している
	// 作業領域をチェックして、緩い条件で再生成するか判定する
	if (_workPatternVortex) {
		// 半渦巻きの場合
	} else if (forceCreateWorkingSegmentsOnSideMargin || _headlandWorking != Param::Work::Headland::Process::NOP || checkRunSideMargin(_workingAreas->at(0)) || checkRunSideMargin(_field)) {
		// 両サイド以外にもサイドマージンが存在する場合、サイドマージンを走る
		SIDE_MARGIN_0 = true;
		SIDE_MARGIN_2 = true;
		SIDE_MARGIN_4 = true;
		SIDE_MARGIN_5 = true;
		SIDE_MARGIN_6 = true;
		// サイドマージンにも作業パスを生成する
		createWorkingSegmentsOnSideMargin = true;
		if (!_canBackward) {
			// バック不可の場合
			SIDE_MARGIN_7 = true;
		}
		remake = true;
	}
	if (remake) {
		// 作業領域ポリゴンのリスト
		_workingAreas->clear();
		tmpField->clear();
		tmpField->assign(_field->begin(), _field->end());
		ret = PolygonUtil::thin5(tmpField, _workingAreas, angles2Widths);
		if (ret == -2) {
			// 作業領域が確保できなかった
			throw runtime_error(ErrorCode::WorkingArea::NOTHING);
		} else if (ret == -3) {
			// 作業領域が複数の領域に分断された
			throw runtime_error(ErrorCode::WorkingArea::DIVIDED);
		} else if (ret < 0) {
			// やせさせる処理が失敗した
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		if (PolygonUtil::thin5_getShiftValueMax(tmpField, _workingAreas->at(0), sideMarginAngle, &appliedHeadlandMax, &appliedSideMarginMax, &widths) < 0) {
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		} else {
			// 枕地幅、サイドマージンが必要な分だけ確保されているかチェック
			std::vector<double> requiredWidths = angles2Widths(PolygonUtil::getSegmentAngles(tmpField));
			if (requiredWidths.size() != widths.size()) {
				throw runtime_error(ErrorCode::FATAL);
			}
			for (int i = 0; i < widths.size(); ++i) {
				if (widths[i] + TOLERANCE_2 < requiredWidths[i]) {
					throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
				}
			}
		}
	}
	// 圃場ポリゴンへのフィードバックを反映
	_field->clear();
	_field->assign(tmpField->begin(), tmpField->end());

// ----------------
// 作業領域・非作業領域の生成(その3/5)
// 非作業領域の計算
	// 非作業領域の枕地幅とサイドマージンを決定するラムダ式
	PolygonUtil::Angles2Widths angles2WidthsObs = getAngles2WidthsObs();
	// 非作業領域ポリゴンのリスト
	_nonWorkingAreas = Polygons_(new Polygons);
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		Polygons_ results = Polygons_(new Polygons);
		if (PolygonUtil::thin5_thick(obstacle, results, angles2WidthsObs) < 0) {
			// 加算処理失敗
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		_nonWorkingAreas->push_back(results->at(0));
	}

// ----------------
// 作業領域・非作業領域の生成(その4/5)
// 非作業領域ポリゴンの結合判定
	while (checkNonWorkingAreasIntersection()) {
		// 非作業領域ポリゴンの結合が発生した場合、全ての組み合わせに対して再チェックが必要となる
		// そのため、非作業領域ポリゴン同士の交差が発生しなくなるまでループを回し続ける
	}

// ----------------
// 作業領域・非作業領域の生成(その5/5)
// 作業領域ポリゴンと非作業領域ポリゴンの統合判定
	checkWorkingAreasIntersection();
	// TODO:非作業領域の統合で作業領域の形状が変化した場合、サイドマージンが増えるかもしれない
	// サイドマージンを狭くする条件で計算していた場合、再計算が必要になることがある

// ----------------
// 作業領域・非作業領域のチェック
	if (_workingAreas->size() == 0) {
		// 作業領域が確保できなかった
		throw runtime_error(ErrorCode::WorkingArea::NOTHING);
	} else if (_workingAreas->size() > 1) {
		// 作業領域が複数の領域に分断された
		throw runtime_error(ErrorCode::WorkingArea::DIVIDED);
	} else if (PolygonUtil::thin5_tryAddComplement(_workingAreas->at(0), _field) < 0) {
		// 非作業領域の統合で作業領域の形状が変わった場合
		if (!_combined) {
			_combined = true;
			throw runtime_error(COMBINED_WA_NWA);
		}
		Polygons_ feedbackPolygons = Polygons_(new Polygons);
		if (PolygonUtil::thin5_feedback(_workingAreas->at(0), feedbackPolygons, angles2Widths, false) < 0) {
			// シフト値の自動調整を抑止しなければ成功する可能性がある
			if (PolygonUtil::thin5_feedback(_workingAreas->at(0), feedbackPolygons, angles2Widths) < 0) {
				// 加算処理失敗
				throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
			}
		}
		if (feedbackPolygons->size() != 1) {
			// 結果ポリゴンの個数が1個以外
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		Polygon_ modifiedField = feedbackPolygons->at(0);
		// フィードバックポリゴンの形状判定と調整
		if (PolygonUtil::thin5_tryAddComplement(_workingAreas->at(0), modifiedField) < 0) {
			// 調整に失敗した
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		_field->swap(*modifiedField);
	}
	if (_workingAreas->at(0)->size() != _field->size()) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}

// ----------------
// スタート・ゴール位置を決定するためのポリゴン(リスト)の生成
	_startEndPolygons = Polygons_(new Polygons);
	double startEndMargin = SAFTY_MARGIN + _outerRadius - _turnRadius;
	if (_headlandWorking != Param::Work::Headland::Process::NOP && _workPatternVortex) {
		startEndMargin = SAFTY_MARGIN + _outerRadius2 - _turnRadius;
	}
	tmpField->clear();
	tmpField->assign(_field->begin(), _field->end());
	if (PolygonUtil::thin5_intersection(tmpField, _startEndPolygons, startEndMargin) < 0) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}
// 交差判定用ポリゴン(リスト)の生成
	_pathEnvelopePolygons = Polygons_(new Polygons);
	// 圃場(全体)
    // TODO: 値を変更するときはPathGeneratorも変更すること。
    double pathEnvelopeMargin = _safetyMargin + _maxWidth * 0.5 - 0.01;
	tmpField->clear();
	tmpField->assign(_field->begin(), _field->end());
	if (PolygonUtil::thin5_intersection(tmpField, _pathEnvelopePolygons, pathEnvelopeMargin) < 0) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}
	// 障害物
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		Polygons_ results = Polygons_(new Polygons);
		if (PolygonUtil::thin5_feedback(obstacle, results, pathEnvelopeMargin) < 0) {
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		if (results->size() != 1) {
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		_pathEnvelopePolygons->push_back(results->at(0));
	}

// ----------------
// 交差判定用ポリゴン(リスト)のチェックと補正
	if (_pathEnvelopePolygons->at(0)->size() > _field->size()) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	} else if (PolygonUtil::thin5_tryAddComplement(_field, _pathEnvelopePolygons->at(0)) < 0) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}

// ----------------
// 最終チェック
	if (_workingAreas->size() == 0) {
		// 作業領域が確保できなかった
		throw runtime_error(ErrorCode::WorkingArea::NOTHING);
	} else if (_workingAreas->size() > 1) {
		// 作業領域が複数の領域に分断された
		throw runtime_error(ErrorCode::WorkingArea::DIVIDED);
	} else if (_workingAreas->at(0)->size() != _field->size() || _pathEnvelopePolygons->at(0)->size() != _field->size()) {
		// 頂点数があっていない
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	} else if (PolygonUtil::checkAngles(PolygonUtil::getSegmentAngles(_workingAreas->at(0)), PolygonUtil::getSegmentAngles(_field)) != 0 ||
		PolygonUtil::checkAngles(PolygonUtil::getSegmentAngles(_pathEnvelopePolygons->at(0)), PolygonUtil::getSegmentAngles(_field)) != 0) {
		// 辺の対応が取れていない
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}

	double d1, d2;
	std::vector<double> appliedWidths1;
	std::vector<double> appliedWidths2;
	if (PolygonUtil::thin5_getShiftValueMax(_field, _workingAreas->at(0), sideMarginAngle, &appliedHeadlandMax, &appliedSideMarginMax, &appliedWidths1) < 0 ||
		PolygonUtil::thin5_getShiftValueMax(_field, _pathEnvelopePolygons->at(0), sideMarginAngle, &d1, &d2, &appliedWidths2) < 0) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	} else {
		// 枕地幅、サイドマージンが必要な分だけ確保されているかチェック
		std::vector<double> requiredWidths = angles2Widths(PolygonUtil::getSegmentAngles(_field));
		if (appliedWidths1.size() != requiredWidths.size() || appliedWidths2.size() != requiredWidths.size()) {
			throw runtime_error(ErrorCode::FATAL);
		}
		for (int i = 0; i < requiredWidths.size(); ++i) {
			if (appliedWidths1[i] - appliedWidths2[i] < requiredWidths[i] - pathEnvelopeMargin - 0.01) {
				throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
			}
		}
	}
}

/**
 * 各種ポリゴンを生成します。
 */
void FieldPolygon::initVertices() {

	// フラグの初期化
	_combined = false;
	initFlags();

	Polygons_ tmpObstacles = Polygons_(new Polygons);
	// 圃場と重なりのない(圃場外にある)障害物をリストから削除
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		if (PolygonUtil::disjoint(_field, obstacle)) {
			// 圃場と障害物に重なりがない場合
			continue;
		}
		// 圃場と障害物に重なりがある場合
		tmpObstacles->push_back(obstacle);
	}
	_obstacles->swap(*tmpObstacles);

	// 障害物のバウンディングボックスポリゴンを生成して、ガイダンスデータへの出力用リストに追加
	_bbObstacles = Polygons_(new Polygons);
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		Point2D obstacleMin;
		Point2D obstacleMax;
		PolygonUtil::boundingBox(obstacle, &obstacleMin, &obstacleMax);
		obstacleMin.x -= TOLERANCE_2;
		obstacleMin.y -= TOLERANCE_2;
		obstacleMax.x += TOLERANCE_2;
		obstacleMax.y += TOLERANCE_2;
		_bbObstacles->push_back(PolygonUtil::box2Polygon(obstacleMin, obstacleMax));
	}

	// 圃場ポリゴンと障害物ポリゴンの交差判定
	tmpObstacles->clear();
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		std::vector<Point2D> crossPoints;
		PolygonUtil::getCrossPoints(obstacle, _field, &crossPoints);
		if (crossPoints.size() == 0) {
			tmpObstacles->push_back(obstacle);
			continue;
		}
		// 交差する場合、圃場ポリゴンから障害物ポリゴンを減算する
		Polygons_ results = Polygons_(new Polygons);
		Point2D obstacleMin;
		Point2D obstacleMax;
		PolygonUtil::boundingBox(obstacle, &obstacleMin, &obstacleMax);
		obstacleMin.x -= TOLERANCE_2;
		obstacleMin.y -= TOLERANCE_2;
		obstacleMax.x += TOLERANCE_2;
		obstacleMax.y += TOLERANCE_2;
		PolygonUtil::difference(_field, PolygonUtil::box2Polygon(obstacleMin, obstacleMax), results);
		if (results->size() < 1) {
			throw runtime_error(ErrorCode::WorkingArea::NOTHING);
		}
		if (results->size() > 1) {
			throw runtime_error(ErrorCode::WorkingArea::DIVIDED);
		}
		_field->swap(*results->at(0));
	}
	_obstacles->swap(*tmpObstacles);

	tmpObstacles->clear();
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		// 圃場と交差する障害物は、上で除去済み
		if (PolygonUtil::within(_field, obstacle)) {
			// 障害物が圃場内に納まっている場合
			tmpObstacles->push_back(obstacle);
			continue;
		}
		if (PolygonUtil::within(obstacle, _field)) {
			// 障害物が圃場を完全に覆っている場合
			throw runtime_error(ErrorCode::WorkingArea::NOTHING);
		}
		// 障害物が圃場外の場合、無視(内部データから削除)
	}
	_obstacles->swap(*tmpObstacles);

	// 座標変換直後のオリジナルを保持
	_orgField = Polygon_(new Polygon);
	_orgField->assign(_field->begin(), _field->end());
	Polygons_ orgObstacles = Polygons_(new Polygons);
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ orgObstacle = Polygon_(new Polygon);
		orgObstacle->assign(_obstacles->at(i)->begin(), _obstacles->at(i)->end());
		orgObstacles->push_back(orgObstacle);
	}

	// 障害物ポリゴンをバウンディングボックスで作り直す
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		Point2D obstacleMin;
		Point2D obstacleMax;
		PolygonUtil::boundingBox(obstacle, &obstacleMin, &obstacleMax);
		obstacleMin.x -= TOLERANCE_2;
		obstacleMin.y -= TOLERANCE_2;
		obstacleMax.x += TOLERANCE_2;
		obstacleMax.y += TOLERANCE_2;
		const double requiredHeight = _innerRadius - _safetyMargin + TOLERANCE;
		if (requiredHeight > 0.0 && (obstacleMax.y - obstacleMin.y) < requiredHeight * 2.0) {
			double my = (obstacleMax.y + obstacleMin.y) * 0.5;
			obstacleMax.y = my + requiredHeight;
			obstacleMin.y = my - requiredHeight;
		}
		obstacle->swap(*PolygonUtil::box2Polygon(obstacleMin, obstacleMax));
	}

	// 内部用の中間形状
	Polygon_ modField = Polygon_(new Polygon);
	modField->assign(_field->begin(), _field->end());
	Polygons_ modObstacles = Polygons_(new Polygons);
	modObstacles->assign(_obstacles->begin(), _obstacles->end());

// ----------------
// 計算に失敗した場合、圃場形状を単純化してリトライする
	std::string errCode = ErrorCode::FATAL;
	int errLevel = -9;
	int ignoreError = 0;
	const int MAX_SIMPLIFY_WIDTH = 1;
	int simplifyWidth = 0;
	bool complement = true;
	bool success = false;
	while (!success) {
		_context.abortIfRequested("Abort: during FieldPolygon.");
		try {
			// 各種ポリゴンの生成
			_startEndPolygons = Polygons_();
			_pathEnvelopePolygons = Polygons_();
			generatePolygons();
			// チェック
			if (!PolygonUtil::within(_orgField, _field)) {
				// 領域の大小関係が不正
				Polygons_ resultPolygons = Polygons_(new Polygons);
				PolygonUtil::difference(_field, _orgField, resultPolygons);
				double a = 0;
				for (int i = 0; i < resultPolygons->size(); ++i) {
					a += PolygonUtil::area(resultPolygons->at(i));
				}
				if (a > 0.01) {
					throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
				}
			}
			if (!PolygonUtil::within(_field, _pathEnvelopePolygons->at(0)) ||
				!PolygonUtil::within(_pathEnvelopePolygons->at(0), _workingAreas->at(0))) {
				// 領域の大小関係が不正
				throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
			}
			for (int i = 0; i < orgObstacles->size(); ++i) {
				std::vector<Point2D> crossPoints;
				bool collinear = PolygonUtil::getCrossPoints(orgObstacles->at(i), _field, &crossPoints);
				if (collinear || crossPoints.size() > 0) {
					throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
				}
			}
			{
				// 単純化の過程などで、非作業領域が作業領域の外側に出てしまった場合、対象の非作業領域と障害物は無視する
				Polygons_ tmps1 = Polygons_(new Polygons);
				Polygons_ tmps2 = Polygons_(new Polygons);
				for (int i = 0; i < _obstacles->size(); ++i) {
					Polygon_ tmp1 = _obstacles->at(i);
					Polygon_ tmp2 = _nonWorkingAreas->at(i);
					if (PolygonUtil::within(_workingAreas->at(0), tmp2)) {
						tmps1->push_back(tmp1);
						tmps2->push_back(tmp2);
					}
				}
				_obstacles->swap(*tmps1);
				_nonWorkingAreas->swap(*tmps2);
			}
			// バウンディングボックスの計算
			PolygonUtil::boundingBox(_workingAreas, &_workingAreasMin, &_workingAreasMax);

			// 外周作業用HP
			_headlandWorkingHP = Polygon_(new Polygon);
			if (_headlandWorking != Param::Work::Headland::Process::NOP) {
				_headlandWorkingHP->assign(_workingAreas->at(0)->begin(), _workingAreas->at(0)->end());
				// 外周作業用HPとして短すぎる辺を削除
				omitEdge(_headlandWorkingHP);
				if (_workPatternVortex) {
					// 内側作業が外内(半渦巻き)
					_headlandWorkingAdditionalWidth = std::ceil((fabs(_cultivationWidthOffset) + _cultivationWidth1 * 0.5) / pathInterval) * pathInterval;
					Polygons_ resultHPs = Polygons_(new Polygons);
					int ret = PolygonUtil::thin5_offset(_headlandWorkingHP, resultHPs, _headlandWorkingAdditionalWidth);
					if (ret == -2) {
						throw runtime_error(ErrorCode::WorkingArea::NOTHING);
					} else if (ret == -3) {
						throw runtime_error(ErrorCode::WorkingArea::DIVIDED);
					} else if (ret < 0) {
						throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
					}
					_headlandWorkingHP->swap(*resultHPs->at(0));
					{
						// オフセット周回経路(ディスクモア)において、外周作業用HPの形状が、元のHPの形状から大きく変わる場合
						// 圃場形状の単純化ロジックに仕事をさせることで、元のHPの方を外周作業用HPに寄せる
						Polygon_ whp = Polygon_(new Polygon);
						whp->assign(_headlandWorkingHP->begin(), _headlandWorkingHP->end());
						Polygons_ feedbackHPs = Polygons_(new Polygons);
						// 外周作業用HPを太らせる
						PolygonUtil::thin5_feedback(whp, feedbackHPs, _headlandWorkingAdditionalWidth, false);
						double a1 = 0;
						for (int i = 0; i < feedbackHPs->size(); ++i) {
							Polygon_ feedbackHP = feedbackHPs->at(i);
							a1 += PolygonUtil::area(feedbackHP);
						}
						double a0 = PolygonUtil::area(_workingAreas->at(0));
						// 元のHPとの差分(面積の差)が一定以上ある場合、もう少し圃場形状の単純化ロジックに仕事をさせて、差分を解消する
						if (a0 > a1 + 100) {
							throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
						}
					}
					PolygonUtil::boundingBox(_headlandWorkingHP, &_headlandWorkingMin, &_headlandWorkingMax);
				}
			}
			// 既存フォーマットのデータ生成
			generateOrgFormatData();
			// 作業パスの生成
			if (_workPatternVortex) {
				if (_progressType == Param::Work::ProgressType::BLOCK) {
					createWorkingSegmentsOffsetBlock();
				} else {
					createWorkingSegmentsOffset();
				}
			} else {
				createWorkingSegments();
				if (_headlandWorking != Param::Work::Headland::Process::NOP) {
					// 隣接(またはスキップ)で外周作業ありの場合
					// 外周作業用HPから、内側作業で塗り潰せない領域を削る
					cutoffHeadlandWorkingHP();
				}
			}
			if (_headlandWorking != Param::Work::Headland::Process::NOP) {
				// 外周作業用HPとして短すぎる辺を削除
				omitEdge(_headlandWorkingHP);
			}
			PolygonUtil::Segments_ segments = PolygonUtil::Segments_(new PolygonUtil::Segments);
			for (int i = 0; i < _workingSegments->size(); ++i) {
				const Segment &s = _workingSegments->at(i);
				PolygonUtil::Segment segment = PolygonUtil::Segment(Point2D(s.p1.x, s.p1.y), Point2D(s.p2.x, s.p2.y));
				segments->push_back(segment);
			}
			dumpToSvg(_logDir, _inDataString, _orgField, modField, _field, orgObstacles, modObstacles, _obstacles, _headlandWorkingHP, _workingAreas, _nonWorkingAreas, _pathEnvelopePolygons, segments);
			success = true;
		} catch (const std::exception &e) {
			if (std::string(e.what()) == COMBINED_WA_NWA) {
				// 非作業領域の統合処理が発生
				// _obstaclesとmodObstaclesの差分をチェックして
				// 作業領域に統合された非作業領域に対する障害物ポリゴンを特定
				Polygons_ combinedObstacles = Polygons_(new Polygons);
				Polygons_ notCombinedObstacles = Polygons_(new Polygons);
				for (int i = 0; i < modObstacles->size(); ++i) {
					const Polygon_ &modObstacle = modObstacles->at(i);
					bool hit = false;
					for (int j = 0; j < _obstacles->size(); ++j) {
						const Polygon_ &obstacle = _obstacles->at(j);
						if (obstacle->size() != modObstacle->size()) continue;
						bool hit2 = true;
						for (int k = 0; k < obstacle->size(); ++k) {
							if (obstacle->at(k) != modObstacle->at(k)) hit2 = false;
						}
						if (hit2) {
							hit = true;
							break;
						}
					}
					if (hit) {
						// _obstaclesに残っている->統合されていない
						notCombinedObstacles->push_back(modObstacle);
					} else {
						// _obstaclesに残っていない->統合された
						combinedObstacles->push_back(modObstacle);
					}
				}
				if (combinedObstacles->size() == 0) {
					// 特定できなかった場合
					modField->assign(_orgField->begin(), _orgField->end());
					_field->assign(modField->begin(), modField->end());
					_obstacles->assign(modObstacles->begin(), modObstacles->end());
					errCode = ErrorCode::FATAL;
					errLevel = -9;
					ignoreError = 0;
					simplifyWidth = 0;
					complement = true;
					initFlags();
					continue;
				}
				// 特定できた場合
				// 圃場ポリゴンから障害物ポリゴンを特殊減算
				for (int i = 0; i < combinedObstacles->size(); ++i) {
					Polygons_ results = Polygons_(new Polygons);
					if (PolygonUtil::difference3(modField, combinedObstacles->at(i), results) < 0) {
						throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
					} else if (results->size() == 0) {
						throw runtime_error(ErrorCode::WorkingArea::NOTHING);
					} else if (results->size() > 1) {
						throw runtime_error(ErrorCode::WorkingArea::DIVIDED);
					}
					modField->assign(results->at(0)->begin(), results->at(0)->end());
				}
				_combined = false;
				_field->assign(modField->begin(), modField->end());
				modObstacles->swap(*notCombinedObstacles);
				_obstacles->assign(modObstacles->begin(), modObstacles->end());
				errCode = ErrorCode::FATAL;
				errLevel = -9;
				ignoreError = 0;
				simplifyWidth = 0;
				complement = true;
				initFlags();
				continue;
			}
			auto itr = errorLevels.find(e.what());
			if (itr == errorLevels.end() || itr->second < 0) {
				// 想定外のエラー/リトライ不要なエラー
				throw;
			}
			if (itr->second > errLevel) {
				// 優先度の高いエラーコードを保持
				errCode = itr->first;
				errLevel = itr->second;
				dumpToSvg(_logDir, _inDataString, _orgField, modField, _field, orgObstacles, modObstacles, _obstacles, _headlandWorkingHP, _workingAreas, _nonWorkingAreas, _pathEnvelopePolygons, PolygonUtil::Segments_());
			}
			if (itr->second > 0) {
				++ignoreError;
				// 優先度1以上のエラーで、何回までリトライするか(計算失敗は常にリトライ)
				if (ignoreError > 100) {
					// 保持している(優先度の高い)エラーコードでエラーを投げる
					throw runtime_error(errCode);
				}
			}
			// 各種ポリゴンの計算処理に失敗した場合、圃場形状を単純化してリトライする
			while (true) {
				if (complement) {
					++simplifyWidth;
					if (simplifyWidth > MAX_SIMPLIFY_WIDTH) {
						// 圃場形状の単純化->各種ポリゴンの生成が失敗し続ける場合
						// 凸頂点の削除
						Polygon_ tmp1 = Polygon_(new Polygon);
						tmp1->assign(modField->begin(), modField->end());
						double areaDecreased1;
						int ret1 = PolygonUtil::thin5_omitConvexPoint(tmp1, &areaDecreased1);
						// 凹頂点をはさむ辺での分割切除
						Polygon_ tmp2 = Polygon_(new Polygon);
						tmp2->assign(modField->begin(), modField->end());
						double areaDecreased2;
						int ret2 = PolygonUtil::thin5_cutOffConcaveEdge(tmp2, &areaDecreased2);
						if (ret1 < 0 && ret2 < 0) {
							// 凸頂点の削除は、究極的には3角形になるまで頂点を削除するので、ここにくることはないはず
							throw runtime_error(errCode);
						}
						if (areaDecreased1 < areaDecreased2) {
							modField->swap(*tmp1);
						} else {
							modField->swap(*tmp2);
						}
						// 凸頂点の削除、凹頂点をはさむ辺での分割切除、どちらの場合でも、元のポリゴンよりも大きくなることはあり得ないが
						// 計算誤差のせいでwithin判定に失敗することがある
						if (!PolygonUtil::within(_orgField, modField)) {
							int mag = 1;
							while (true) {
								Polygon_ tmp = Polygon_(new Polygon);
								tmp->assign(modField->begin(), modField->end());
								Polygons_ tmps = Polygons_(new Polygons);
								int ret = PolygonUtil::thin5_simplify(tmp, tmps, TOLERANCE_2 * mag, false);
								if (ret >= 0 && PolygonUtil::within(_orgField, tmps->at(0))) {
									// やせさせる処理が成功した
									modField->assign(tmps->at(0)->begin(), tmps->at(0)->end());
									break;
								}
								if (++mag > 10) {
									throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
								}
							}
						}
						simplifyWidth = 0;
						complement = true;
						_field->assign(modField->begin(), modField->end());
						_obstacles->assign(modObstacles->begin(), modObstacles->end());
						break;
					}
				}
				complement = !complement;
				_field->assign(modField->begin(), modField->end());
				_obstacles->assign(modObstacles->begin(), modObstacles->end());
				// 圃場形状の単純化
				int ret = simplify(_field, simplifyWidth, complement);
				if (ret == 0) {
					break;
				} else if (ret == -2) {
					// これ以上simplifyWidthを増やしても無駄
					simplifyWidth = MAX_SIMPLIFY_WIDTH + 1;
					complement = true;
				}
			}
			// フラグの再初期化
			initFlags();
		}
	}
}

/**
 * サイドマージンには作業パスを生成しない版
 */
bool FieldPolygon::getCrossPoints(const Polygon_ &polygon, const Point2D &p1, const Point2D &p2, std::vector<_Point2D> *crossPoints)
{
	bool collinear = false;
	crossPoints->clear();
	PolygonUtil::Segment s = PolygonUtil::Segment(p1, p2);
	PolygonUtil::Segments_ segments = PolygonUtil::createSegments(polygon);
	for (int i = 0; i < segments->size(); ++i) {
		PolygonUtil::Segment segment = segments->at(i);
		double angleY = fabs(fabs(segment.angle()) - M_PI_2);
		Point2D p;
		int ret = PolygonUtil::crossPoint(segment, s, &p, true);
		if (ret == 0) {
			// 線分の範囲内で交点あり(10度未満ならサイドマージンフラグを立てる)
			crossPoints->push_back(_Point2D(p, angleY < sideMarginAngle));
		}
		if (ret == 2) {
			// 同一直線上で線分に重なりがある
			// つまり辺の共有あり
			collinear = true;
		}
	}
	return collinear;
}

/**
 * 作業パス用セグメントのリストを生成します。
 */
// 有人トラクターありなら、1本目の作業パスの位置は、+有人トラクターの耕運幅-オーバーラップ幅の分だけズレる
void FieldPolygon::createWorkingSegments() {
	const int TYPE_HEAD_LAND   = 0;
	const int TYPE_SIDE_MARGIN = 1;
	const int TYPE_OBSTACLE    = 2;
	const double CONNECT_LENGTH = _turnRadius * 2.0 + _gps2CultivationPos;
	// 無効な作業パスが存在したかどうかを判定するフラグ
	bool unavailablePaths = false;
	_workingSegments = Segments_(new Segments);
	_unavailableSegments = Segments_(new Segments);
	double posXmin = _workingAreasMin.x + _pathInterval2 + _cultivationWidth1 * 0.5;
	double posXmax = _workingAreasMax.x + _cultivationWidth1 * 0.5;
	if (!createWorkingSegmentsOnSideMargin) {
		double smMin;
		double smMax;
		checkRunSideMargin(_pathEnvelopePolygons->at(0), &smMin, &smMax);
		double d = _outerRadius - (_turnRadius + _maxWidth * 0.5);
		posXmin = std::max(posXmin, smMin + d);
		posXmax = std::min(posXmax, smMax - d);
	}
	int lineCount = (_workingAreasMax.x - _workingAreasMin.x) / pathInterval + 1;
	vector<int> updown;
	while (true) {
		if (fabs(_cultivationWidthOffset) > 0) {
			updown.clear();
			getLineUpDown(lineCount, _numSkipPath, updown);
		}
		// posX:作業パスのx座標
		int lineIndex = 0;
		for (double posX = posXmin; posX < posXmax; posX += pathInterval) {
			double PX = posX;
			if (fabs(_cultivationWidthOffset) > 0) {
				if (lineIndex < updown.size()) {
					PX -= updown[lineIndex] * _cultivationWidthOffset;
				} else {
					PX += fabs(_cultivationWidthOffset);
				}
			}
			// TODO:作業パスは、幅を持った領域として考える必要があるが
			// とりあえず、直線x=posXと、作業領域と非作業領域との交点だけで考える
			Point2D pMinY = Point2D(PX, _workingAreasMin.y);
			Point2D pMaxY = Point2D(PX, _workingAreasMax.y);
			// 作業領域との交点から、障害物を考慮しない作業パス用セグメントのリストを生成
			Segments_ tmpSegments1 = Segments_(new Segments); // 作業パス
			for (int i = 0; i < _workingAreas->size(); ++i) {
				Polygon_ workingArea = _workingAreas->at(i);
				std::vector<_Point2D> crossPoints;
				if (createWorkingSegmentsOnSideMargin) {
					std::vector<Point2D> tmpCrossPoints;
					PolygonUtil::getCrossPoints(workingArea, pMinY, pMaxY, &tmpCrossPoints);
					for (int j = 0; j < tmpCrossPoints.size(); ++j) {
						crossPoints.push_back(_Point2D(tmpCrossPoints[j], false));
					}
				} else {
					getCrossPoints(workingArea, pMinY, pMaxY, &crossPoints);
				}
				// 交点を昇順にソート
				std::sort(crossPoints.begin(), crossPoints.end(), [](_Point2D p1, _Point2D p2) -> int { return (p1.p.y < p2.p.y); });
				for (int j = 1; j < crossPoints.size(); ++j) {
					_Point2D p1 = crossPoints[j - 1];
					_Point2D p2 = crossPoints[j];
					Point2D pm;
					pm.x = (p1.p.x + p2.p.x) * 0.5;
					pm.y = (p1.p.y + p2.p.y) * 0.5;
					if (PolygonUtil::within(workingArea, pm)) {
						// 中間点が作業領域の内側にあれば作業パス
						Segment s = Segment(p1.p, p2.p, (p1.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND), (p2.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND));
						tmpSegments1->push_back(s);
					}
				}
			}
			if (tmpSegments1->size() == 0) continue;
			// 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
			for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
				Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
				// 非作業領域は矩形
				Point2D min;
				Point2D max;
				PolygonUtil::boundingBox(nonWorkingArea, &min, &max);
				Segments_ tmpSegments2 = Segments_(new Segments);
				for (int j = 0; j < tmpSegments1->size(); ++j) {
					const Segment &tmpSegment = tmpSegments1->at(j);
					if ((min.x < tmpSegment.p1.x && tmpSegment.p2.x < max.x) && (tmpSegment.p1.y < min.y && max.y < tmpSegment.p2.y)) {
						// 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
						Segment s1 = Segment(Point2D(tmpSegment.p1.x, tmpSegment.p1.y), Point2D(tmpSegment.p1.x, min.y), tmpSegment.type1, TYPE_OBSTACLE);
						Segment s2 = Segment(Point2D(tmpSegment.p2.x, max.y), Point2D(tmpSegment.p2.x, tmpSegment.p2.y), TYPE_OBSTACLE, tmpSegment.type2);
						tmpSegments2->push_back(s1);
						tmpSegments2->push_back(s2);
					} else {
						// 横切らない場合、そのまま追加(元のリストに戻す)
						tmpSegments2->push_back(tmpSegment);
					}
				}
				tmpSegments1->swap(*tmpSegments2);
			}
			if (tmpSegments1->size() == 0) continue;
			// 作業パス間の間隔が旋回半径の2倍(+パス足長)未満の場合、作業パスを接続する(作業パス間の非作業領域も作業する)
			Segments_ tmpSegments3 = Segments_(new Segments);
			tmpSegments3->push_back(tmpSegments1->at(0));
			for (int i = 1; i < tmpSegments1->size(); ++i) {
				Segment &s3 = tmpSegments3->back();
				Segment &s1 = tmpSegments1->at(i);
				if (s1.p1.y - s3.p2.y >= CONNECT_LENGTH) {
					tmpSegments3->push_back(s1);
					continue;
				}
				if (s3.type2 == TYPE_OBSTACLE || s1.type1 == TYPE_OBSTACLE) {
					// 非作業領域で分割された作業パス用セグメントが、再接続された(想定外のエラー)
					throw runtime_error(ErrorCode::FATAL);
				}
				s3.p2 = s1.p2;
				s3.type2 = s1.type2;
			}
			// 作業パス用セグメントの妥当性チェック
			tmpSegments1->clear();
			for (int i = 0; i < tmpSegments3->size(); ++i) {
				const Segment &s3 = tmpSegments3->at(i);
				if (s3.type1 == TYPE_SIDE_MARGIN || s3.type2 == TYPE_SIDE_MARGIN) {
					// サイドマージンの作業パス
					if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
						// 非作業領域で分割された作業パス用セグメントは除外できない(サイドマージンにも作業パスを生成する条件でリトライする)
						_combined = true;
						throw runtime_error(COMBINED_WA_NWA);
					}
					// リストに戻さない(除外する)
					unavailablePaths = true;
					_unavailableSegments->push_back(s3);
					_unavailableSegments->back().p1.x = PX;
					_unavailableSegments->back().p2.x = PX;
					continue;
				}
				if (s3.p2.y - s3.p1.y < MINDISTSWEEP) {
					// 最低限の長さを満たしていない作業パス
					if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
						// 非作業領域で分割された作業パス用セグメントは除外できない
						// リストに戻す
						tmpSegments1->push_back(s3);
						continue;
					}
					// リストに戻さない(除外する)
					unavailablePaths = true;
					_unavailableSegments->push_back(s3);
					_unavailableSegments->back().p1.x = PX;
					_unavailableSegments->back().p2.x = PX;
					continue;
				}
				// 有効な作業パス
				// リストに戻す
				tmpSegments1->push_back(s3);
			}
			if (tmpSegments1->size() > 0) {
				++lineIndex;
			}
			// 作業パスを昇順にソート
			std::sort(tmpSegments1->begin(), tmpSegments1->end(), [](Segment s1, Segment s2) -> int { return (s1.p1.y < s2.p1.y); });
			for (int i = 0; i < tmpSegments1->size(); ++i) {
				Segment &s = tmpSegments1->at(i);
				// x座標は、==で判定しているところがあるので、posXで統一しておく
				s.p1.x = PX;
				s.p2.x = PX;
				_workingSegments->push_back(s);
			}
		}
		if (fabs(_cultivationWidthOffset) == 0 || lineIndex == lineCount) {
			break;
		}
		lineCount -= 1;
		if (lineCount < 1) {
			break;
		}
		_workingSegments->clear();
		_unavailableSegments->clear();
	}
	if (_workingSegments->size() == 0) {
		// 作業パスが1本も引けなかった
		if (unavailablePaths) {
			// 作業パスの候補はあったが、短すぎたか、サイドマージンと交わっていた
			throw runtime_error(ErrorCode::Nodes::NOTHING);
		} else {
			// 作業領域が狭すぎた
			throw runtime_error(ErrorCode::WorkingArea::SIZE);
		}
	}

	SweepVertex.clear();
	for (int i = 0; i < _workingSegments->size(); ++i) {
		Segment segment = _workingSegments->at(i);
		SweepVertex.push_back(segment.p1);
		SweepVertex.push_back(segment.p2);
	}

	_workingSegments2 = Segments_(new Segments);
	if (_cultivationWidth2 > 0.0) {
		createWorkingSegments2();
	}
}
/**
 * 2台目(有人)トラクターの作業パス用セグメントのリストを生成します。
 */
void FieldPolygon::createWorkingSegments2() {
	const int TYPE_HEAD_LAND   = 0;
	const int TYPE_SIDE_MARGIN = 1;
	const int TYPE_OBSTACLE    = 2;
	const double CONNECT_LENGTH = _turnRadius * 2.0 + _gps2CultivationPos;
	double posXmin = _workingAreasMin.x + _pathInterval2 + _cultivationWidth1 * 0.5;
	double posXmax = _workingAreasMax.x + _cultivationWidth1 * 0.5;
	if (!createWorkingSegmentsOnSideMargin) {
		double smMin;
		double smMax;
		checkRunSideMargin(_pathEnvelopePolygons->at(0), &smMin, &smMax);
		posXmin = std::max(posXmin, smMin);
		posXmax = std::min(posXmax, smMax);
	}
	// posX:作業パスのx座標
	for (double posX = posXmin - pathInterval * 0.5; posX < posXmax + pathInterval * 0.5; posX += pathInterval) {
		// TODO:作業パスは、幅を持った領域として考える必要があるが
		// とりあえず、直線x=posXと、作業領域と非作業領域との交点だけで考える
		Point2D pMinY = Point2D(posX, _workingAreasMin.y);
		Point2D pMaxY = Point2D(posX, _workingAreasMax.y);
		// 作業領域との交点から、障害物を考慮しない作業パス用セグメントのリストを生成
		Segments_ tmpSegments1 = Segments_(new Segments);
		for (int i = 0; i < _workingAreas->size(); ++i) {
			Polygon_ workingArea = _workingAreas->at(i);
			std::vector<_Point2D> crossPoints;
			if (createWorkingSegmentsOnSideMargin) {
				std::vector<Point2D> tmpCrossPoints;
				PolygonUtil::getCrossPoints(workingArea, pMinY, pMaxY, &tmpCrossPoints);
				for (int j = 0; j < tmpCrossPoints.size(); ++j) {
					crossPoints.push_back(_Point2D(tmpCrossPoints[j], false));
				}
			} else {
				getCrossPoints(workingArea, pMinY, pMaxY, &crossPoints);
			}
			// 交点を昇順にソート
			std::sort(crossPoints.begin(), crossPoints.end(), [](_Point2D p1, _Point2D p2) -> int { return (p1.p.y < p2.p.y); });
			for (int j = 1; j < crossPoints.size(); ++j) {
				_Point2D p1 = crossPoints[j - 1];
				_Point2D p2 = crossPoints[j];
				Point2D pm;
				pm.x = (p1.p.x + p2.p.x) * 0.5;
				pm.y = (p1.p.y + p2.p.y) * 0.5;
				if (PolygonUtil::within(workingArea, pm)) {
					// 中間点が作業領域の内側にあれば作業パス
					Segment s = Segment(p1.p, p2.p, (p1.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND), (p2.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND));
					tmpSegments1->push_back(s);
				}
			}
		}
		if (tmpSegments1->size() == 0) continue;
		// 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
		for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
			Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
			// 非作業領域は矩形
			Point2D min;
			Point2D max;
			PolygonUtil::boundingBox(nonWorkingArea, &min, &max);
			Segments_ tmpSegments2 = Segments_(new Segments);
			for (int j = 0; j < tmpSegments1->size(); ++j) {
				const Segment &tmpSegment = tmpSegments1->at(j);
				if ((min.x < tmpSegment.p1.x && tmpSegment.p2.x < max.x) && (tmpSegment.p1.y < min.y && max.y < tmpSegment.p2.y)) {
					// 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
					Segment s1 = Segment(Point2D(tmpSegment.p1.x, tmpSegment.p1.y), Point2D(tmpSegment.p1.x, min.y), tmpSegment.type1, TYPE_OBSTACLE);
					Segment s2 = Segment(Point2D(tmpSegment.p2.x, max.y), Point2D(tmpSegment.p2.x, tmpSegment.p2.y), TYPE_OBSTACLE, tmpSegment.type2);
					tmpSegments2->push_back(s1);
					tmpSegments2->push_back(s2);
				} else {
					// 横切らない場合、そのまま追加(元のリストに戻す)
					tmpSegments2->push_back(tmpSegment);
				}
			}
			tmpSegments1->swap(*tmpSegments2);
		}
		if (tmpSegments1->size() == 0) continue;
		// 作業パス間の間隔が旋回半径の2倍(+パス足長)未満の場合、作業パスを接続する(作業パス間の非作業領域も作業する)
		Segments_ tmpSegments3 = Segments_(new Segments);
		tmpSegments3->push_back(tmpSegments1->at(0));
		for (int i = 1; i < tmpSegments1->size(); ++i) {
			Segment &s3 = tmpSegments3->back();
			Segment &s1 = tmpSegments1->at(i);
			if (s1.p1.y - s3.p2.y >= CONNECT_LENGTH) {
				tmpSegments3->push_back(s1);
				continue;
			}
			if (s3.type2 == TYPE_OBSTACLE || s1.type1 == TYPE_OBSTACLE) {
				// 非作業領域で分割された作業パス用セグメントが、再接続された(想定外のエラー)
				// 有人機の作業パスはエラーを無視する
				tmpSegments3->push_back(s1);
				continue;
			}
			s3.p2 = s1.p2;
			s3.type2 = s1.type2;
		}
		// 作業パス用セグメントの妥当性チェック
		tmpSegments1->clear();
		for (int i = 0; i < tmpSegments3->size(); ++i) {
			const Segment &s3 = tmpSegments3->at(i);
			// 隣接する無人機の作業ライン上に有効な作業パスがないかチェックする
			bool adjacent = false;
			for (int j = 0; j < _workingSegments->size(); ++j) {
				const Segment &sr = _workingSegments->at(j);
				if (s3.p1.x - pathInterval < sr.p1.x && sr.p1.x < s3.p1.x + pathInterval) {
					adjacent = true;
					break;
				}
			}
			// 無人機の作業パスがある場合、除外しない
			if (adjacent) {
				// リストに戻す
				tmpSegments1->push_back(s3);
				continue;
			}
			// 無人機の作業パスがない場合、無人機の作業パスと同じ条件で処理する
			if (s3.type1 == TYPE_SIDE_MARGIN || s3.type2 == TYPE_SIDE_MARGIN) {
				// サイドマージンの作業パス
				if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
					// 非作業領域で分割された作業パス用セグメントは除外できない(サイドマージンにも作業パスを生成する条件でリトライする)
					// 有人機の作業パスはエラーを無視する
				}
				// リストに戻さない(除外する)
				continue;
			}
			if (s3.p2.y - s3.p1.y < MINDISTSWEEP) {
				// 最低限の長さを満たしていない作業パス
				if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
					// 非作業領域で分割された作業パス用セグメントは除外できない
					// リストに戻す
					tmpSegments1->push_back(s3);
					continue;
				}
				// リストに戻さない(除外する)
				continue;
			}
			// 有効な作業パス
			// リストに戻す
			tmpSegments1->push_back(s3);
		}
		// 作業パスを昇順にソート
		std::sort(tmpSegments1->begin(), tmpSegments1->end(), [](Segment s1, Segment s2) -> int { return (s1.p1.y < s2.p1.y); });
		for (int i = 0; i < tmpSegments1->size(); ++i) {
			Segment &s = tmpSegments1->at(i);
			// x座標は、==で判定しているところがあるので、posXで統一しておく
			s.p1.x = posX;
			s.p2.x = posX;
			_workingSegments2->push_back(s);
		}
	}

	// 2台目(有人)トラクターの作業パス用セグメントの座標は、あらかじめ逆変換までしておく
	double tx = -translate.x;
	double ty = -translate.y;
	double ra = -rotateAngle;
	double sin = std::sin(ra);
	double cos = std::cos(ra);
	MannedTractorVertex.clear();
	for (int i = 0; i < _workingSegments2->size(); ++i) {
		Segment segment = _workingSegments2->at(i);
		PolygonUtil::translatePoint(&segment.p1, tx, ty);
		PolygonUtil::translatePoint(&segment.p2, tx, ty);
		PolygonUtil::rotatePoint(&segment.p1, sin, cos);
		PolygonUtil::rotatePoint(&segment.p2, sin, cos);
		MannedTractorVertex.push_back(segment.p1);
		MannedTractorVertex.push_back(segment.p2);
	}
}
/**
 * ABパスの作業パス用セグメントのリストを生成します。
 */
void FieldPolygon::createWorkingSegmentsAB(double *shift) {
	if (_pathTypeAB == Param::Work::PathTypeAB::NO_SHIFT) {
		_shiftValueAB = 0;
	}
	*shift = _shiftValueAB;
	// 基準線 (x座標はA点B点の平均値にシフト値を適用、y座標は線分ABの両端を延長)
	const double x = (uiStart.x + uiEnd.x) * 0.5 + _shiftValueAB;
	const Point2D p1 = Point2D(x, uiStart.y - _extendLengthAB);
	const Point2D p2 = Point2D(x, uiEnd.y + _extendLengthAB);
	// トラクターの現在地に最も近いパスを、トラクターの現在地に合わせるためのシフト量
	double tractorShift = 1000000000.0;
	// 基準線の左右に(_numHalfAB_L, _numHalfAB_R)本の作業パスを生成
	_workingSegments = Segments_(new Segments);
	for (int i = -_numHalfAB_L; i <= _numHalfAB_R; ++i) {
		Segment segment = Segment(p1, p2, 0, 0);
		double s = pathInterval * i;
		segment.p1.x += s;
		segment.p2.x += s;
		_workingSegments->push_back(segment);
		if (_pathTypeAB == Param::Work::PathTypeAB::TRACTOR_POS) {
			double d = _tractorPosAB.x - segment.p1.x;
			if (fabs(d) < fabs(tractorShift)) {
				tractorShift = d;
			}
		}
	}
	if (_pathTypeAB == Param::Work::PathTypeAB::TRACTOR_POS) {
		if (fabs(tractorShift) > pathInterval * 0.5 + TOLERANCE_2) {
			// パス間隔の1/2より大きい場合はエラー
			throw runtime_error(ErrorCode::ABPath::Shift::LIMITS);
		}
		*shift += tractorShift;
		for (int i = 0; i < _workingSegments->size(); ++i) {
			Segment &s = _workingSegments->at(i);
			s.p1.x += tractorShift;
			s.p2.x += tractorShift;
		}
	}

	SweepVertex.clear();
	for (int i = 0; i < _workingSegments->size(); ++i) {
		Segment segment = _workingSegments->at(i);
		SweepVertex.push_back(segment.p1);
		SweepVertex.push_back(segment.p2);
	}
}
/**
 * オフセット作業機の半渦巻き（非ブロックパターン）パス生成用の順方向/逆方向セグメントのリストを生成します。
 */
void FieldPolygon::createWorkingSegmentsOffsetFR(Segments_ &workingSegmentsF, Segments_ &workingSegmentsR) {
	const double CULTIVATION_OFFSET_ROTATION = (_clockwiseVortex ? _cultivationWidthOffset : -_cultivationWidthOffset);
    // オフセット作業機の場合、10m未満の作業パスを除外しない
    // const double OFFSET_MINDISTSWEEP = MINDISTSWEEP;
    const double OFFSET_MINDISTSWEEP = 0;
    const int TYPE_HEAD_LAND   = 0;
    const int TYPE_SIDE_MARGIN = 1;
    const int TYPE_OBSTACLE    = 2;
    // FieldPolygonでの接続は廃止
    const double CONNECT_LENGTH = 0; // _turnRadius * 2.0 + _gps2CultivationPos;
    // 無効な作業パスが存在したかどうかを判定するフラグ
    bool unavailablePaths = false;
    workingSegmentsF->clear();
    double posXmin = _workingAreasMin.x + _cultivationWidth1 * 0.5 - CULTIVATION_OFFSET_ROTATION;
	if (_headlandWorking != Param::Work::Headland::Process::NOP) {
		posXmin = _headlandWorkingMin.x + _cultivationWidth1 * 0.5 - CULTIVATION_OFFSET_ROTATION;
	}
	while (posXmin < _workingAreasMin.x + TOLERANCE_2) {
		posXmin += pathInterval;
	}
    double posXmax = _workingAreasMax.x;
//    if (!createWorkingSegmentsOnSideMargin) {
//        double smMin;
//        double smMax;
//        checkRunSideMargin(_pathEnvelopePolygons->at(0), &smMin, &smMax);
//        double d = _outerRadius - (_turnRadius + _maxWidth * 0.5);
//        posXmin = std::max(posXmin, smMin + d);
//        posXmax = std::min(posXmax, smMax - d);
//    }
    // posX:作業パスのx座標
    for (double posX = posXmin; posX < posXmax; posX += pathInterval) {
        // TODO:作業パスは、幅を持った領域として考える必要があるが
        // とりあえず、直線x=posXと、作業領域と非作業領域との交点だけで考える
        Point2D pMinY = Point2D(posX, _workingAreasMin.y);
        Point2D pMaxY = Point2D(posX, _workingAreasMax.y);
        // 作業領域との交点から、障害物を考慮しない作業パス用セグメントのリストを生成
        Segments_ tmpSegments1 = Segments_(new Segments); // 作業パス
        for (int i = 0; i < _workingAreas->size(); ++i) {
            Polygon_ workingArea = _workingAreas->at(i);
            std::vector<_Point2D> crossPoints;
            if (createWorkingSegmentsOnSideMargin || _workPatternVortex) {
                std::vector<Point2D> tmpCrossPoints;
                PolygonUtil::getCrossPoints(workingArea, pMinY, pMaxY, &tmpCrossPoints);
                for (int j = 0; j < tmpCrossPoints.size(); ++j) {
                    crossPoints.push_back(_Point2D(tmpCrossPoints[j], false));
                }
            } else {
                getCrossPoints(workingArea, pMinY, pMaxY, &crossPoints);
            }
            // 交点を昇順にソート
            std::sort(crossPoints.begin(), crossPoints.end(), [](_Point2D p1, _Point2D p2) -> int { return (p1.p.y < p2.p.y); });
            for (int j = 1; j < crossPoints.size(); ++j) {
                _Point2D p1 = crossPoints[j - 1];
                _Point2D p2 = crossPoints[j];
                Point2D pm;
                pm.x = (p1.p.x + p2.p.x) * 0.5;
                pm.y = (p1.p.y + p2.p.y) * 0.5;
                if (PolygonUtil::within(workingArea, pm)) {
                    // 中間点が作業領域の内側にあれば作業パス
                    Segment s = Segment(p1.p, p2.p, (p1.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND), (p2.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND));
                    tmpSegments1->push_back(s);
                }
            }
        }
        if (tmpSegments1->size() == 0) continue;
        // 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
        for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
            Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
            // 非作業領域は矩形
            Point2D min;
            Point2D max;
            PolygonUtil::boundingBox(nonWorkingArea, &min, &max);
            Segments_ tmpSegments2 = Segments_(new Segments);
            for (int j = 0; j < tmpSegments1->size(); ++j) {
                const Segment &tmpSegment = tmpSegments1->at(j);
                if ((min.x < tmpSegment.p1.x && tmpSegment.p2.x < max.x) && (tmpSegment.p1.y < min.y && max.y < tmpSegment.p2.y)) {
                    // 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
                    Segment s1 = Segment(Point2D(tmpSegment.p1.x, tmpSegment.p1.y), Point2D(tmpSegment.p1.x, min.y), tmpSegment.type1, TYPE_OBSTACLE);
                    Segment s2 = Segment(Point2D(tmpSegment.p2.x, max.y), Point2D(tmpSegment.p2.x, tmpSegment.p2.y), TYPE_OBSTACLE, tmpSegment.type2);
                    tmpSegments2->push_back(s1);
                    tmpSegments2->push_back(s2);
                } else {
                    // 横切らない場合、そのまま追加(元のリストに戻す)
                    tmpSegments2->push_back(tmpSegment);
                }
            }
            tmpSegments1->swap(*tmpSegments2);
        }
        if (tmpSegments1->size() == 0) continue;
        // 作業パス間の間隔が旋回半径の2倍(+パス足長)未満の場合、作業パスを接続する(作業パス間の非作業領域も作業する)
        Segments_ tmpSegments3 = Segments_(new Segments);
        tmpSegments3->push_back(tmpSegments1->at(0));
        for (int i = 1; i < tmpSegments1->size(); ++i) {
            Segment &s3 = tmpSegments3->back();
            Segment &s1 = tmpSegments1->at(i);
            if (s1.p1.y - s3.p2.y >= CONNECT_LENGTH) {
                tmpSegments3->push_back(s1);
                continue;
            }
            if (s3.type2 == TYPE_OBSTACLE || s1.type1 == TYPE_OBSTACLE) {
                // 非作業領域で分割された作業パス用セグメントが、再接続された(想定外のエラー)
                throw runtime_error(ErrorCode::FATAL);
            }
            s3.p2 = s1.p2;
            s3.type2 = s1.type2;
        }
        // 作業パス用セグメントの妥当性チェック
        tmpSegments1->clear();
        for (int i = 0; i < tmpSegments3->size(); ++i) {
            const Segment &s3 = tmpSegments3->at(i);
//            if (s3.type1 == TYPE_SIDE_MARGIN || s3.type2 == TYPE_SIDE_MARGIN) {
//                // サイドマージンの作業パス
//                if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
//                    // 非作業領域で分割された作業パス用セグメントは除外できない(サイドマージンにも作業パスを生成する条件でリトライする)
//                    _combined = true;
//                    throw runtime_error(COMBINED_WA_NWA);
//                }
//                // リストに戻さない(除外する)
//                unavailablePaths = true;
//                continue;
//            }
            if (s3.p2.y - s3.p1.y < OFFSET_MINDISTSWEEP) {
                // 最低限の長さを満たしていない作業パス
                if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
                    // 非作業領域で分割された作業パス用セグメントは除外できない
                    // リストに戻す
                    tmpSegments1->push_back(s3);
                    continue;
                }
                // リストに戻さない(除外する)
                unavailablePaths = true;
                continue;
            }
            // 有効な作業パス
            // リストに戻す
            tmpSegments1->push_back(s3);
        }
        // 作業パスを昇順にソート
        std::sort(tmpSegments1->begin(), tmpSegments1->end(), [](Segment s1, Segment s2) -> int { return (s1.p1.y < s2.p1.y); });
        for (int i = 0; i < tmpSegments1->size(); ++i) {
            Segment &s = tmpSegments1->at(i);
            // x座標は、==で判定しているところがあるので、posXで統一しておく
            s.p1.x = posX;
            s.p2.x = posX;
        }
		// 外周作業用HPに対して塗り潰しがあるかチェックする
		checkWorkingSegmentsEffectiveArea(tmpSegments1, true);
		for (int i = 0; i < tmpSegments1->size(); ++i) {
			Segment &s = tmpSegments1->at(i);
			workingSegmentsF->push_back(s);
		}
    }
    if (workingSegmentsF->size() == 0) {
        // 作業パスが1本も引けなかった
        if (unavailablePaths) {
            // 作業パスの候補はあったが、短すぎたか、サイドマージンと交わっていた
            throw runtime_error(ErrorCode::Nodes::NOTHING);
        } else {
            // 作業領域が狭すぎた
            throw runtime_error(ErrorCode::WorkingArea::SIZE);
        }
    }

    // 逆順の作業パスを生成
    unavailablePaths = false;
    workingSegmentsR->clear();
    posXmax = posXmin + CULTIVATION_OFFSET_ROTATION * 2;
	double POS_MAX = _workingAreasMax.x - pathInterval;
	if (_headlandWorking != Param::Work::Headland::Process::NOP) {
		POS_MAX = _headlandWorkingMax.x - _cultivationWidth1 * 0.5 + CULTIVATION_OFFSET_ROTATION;
	}
	while (posXmax < POS_MAX) {
		posXmax += pathInterval;
	}
    posXmin = _workingAreasMin.x;
//    if (!createWorkingSegmentsOnSideMargin) {
//        double smMin;
//        double smMax;
//        checkRunSideMargin(_pathEnvelopePolygons->at(0), &smMin, &smMax);
//        double d = _outerRadius - (_turnRadius + _maxWidth * 0.5);
//        posXmin = std::max(posXmin, smMin + d);
//        posXmax = std::min(posXmax, smMax - d);
//    }
    // posX:作業パスのx座標
    for (double posX = posXmax; posX > posXmin; posX -= pathInterval) {
        // TODO:作業パスは、幅を持った領域として考える必要があるが
        // とりあえず、直線x=posXと、作業領域と非作業領域との交点だけで考える
        Point2D pMinY = Point2D(posX, _workingAreasMin.y);
        Point2D pMaxY = Point2D(posX, _workingAreasMax.y);
        // 作業領域との交点から、障害物を考慮しない作業パス用セグメントのリストを生成
        Segments_ tmpSegments1 = Segments_(new Segments); // 作業パス
        for (int i = 0; i < _workingAreas->size(); ++i) {
            Polygon_ workingArea = _workingAreas->at(i);
            std::vector<_Point2D> crossPoints;
            if (createWorkingSegmentsOnSideMargin || _workPatternVortex) {
                std::vector<Point2D> tmpCrossPoints;
                PolygonUtil::getCrossPoints(workingArea, pMinY, pMaxY, &tmpCrossPoints);
                for (int j = 0; j < tmpCrossPoints.size(); ++j) {
                    crossPoints.push_back(_Point2D(tmpCrossPoints[j], false));
                }
            } else {
                getCrossPoints(workingArea, pMinY, pMaxY, &crossPoints);
            }
            // 交点を昇順にソート
            std::sort(crossPoints.begin(), crossPoints.end(), [](_Point2D p1, _Point2D p2) -> int { return (p1.p.y < p2.p.y); });
            for (int j = 1; j < crossPoints.size(); ++j) {
                _Point2D p1 = crossPoints[j - 1];
                _Point2D p2 = crossPoints[j];
                Point2D pm;
                pm.x = (p1.p.x + p2.p.x) * 0.5;
                pm.y = (p1.p.y + p2.p.y) * 0.5;
                if (PolygonUtil::within(workingArea, pm)) {
                    // 中間点が作業領域の内側にあれば作業パス
                    Segment s = Segment(p1.p, p2.p, (p1.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND), (p2.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND));
                    tmpSegments1->push_back(s);
                }
            }
        }
        if (tmpSegments1->size() == 0) continue;
        // 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
        for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
            Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
            // 非作業領域は矩形
            Point2D min;
            Point2D max;
            PolygonUtil::boundingBox(nonWorkingArea, &min, &max);
            Segments_ tmpSegments2 = Segments_(new Segments);
            for (int j = 0; j < tmpSegments1->size(); ++j) {
                const Segment &tmpSegment = tmpSegments1->at(j);
                if ((min.x < tmpSegment.p1.x && tmpSegment.p2.x < max.x) && (tmpSegment.p1.y < min.y && max.y < tmpSegment.p2.y)) {
                    // 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
                    Segment s1 = Segment(Point2D(tmpSegment.p1.x, tmpSegment.p1.y), Point2D(tmpSegment.p1.x, min.y), tmpSegment.type1, TYPE_OBSTACLE);
                    Segment s2 = Segment(Point2D(tmpSegment.p2.x, max.y), Point2D(tmpSegment.p2.x, tmpSegment.p2.y), TYPE_OBSTACLE, tmpSegment.type2);
                    tmpSegments2->push_back(s1);
                    tmpSegments2->push_back(s2);
                } else {
                    // 横切らない場合、そのまま追加(元のリストに戻す)
                    tmpSegments2->push_back(tmpSegment);
                }
            }
            tmpSegments1->swap(*tmpSegments2);
        }
        if (tmpSegments1->size() == 0) continue;
        // 作業パス間の間隔が旋回半径の2倍(+パス足長)未満の場合、作業パスを接続する(作業パス間の非作業領域も作業する)
        Segments_ tmpSegments3 = Segments_(new Segments);
        tmpSegments3->push_back(tmpSegments1->at(0));
        for (int i = 1; i < tmpSegments1->size(); ++i) {
            Segment &s3 = tmpSegments3->back();
            Segment &s1 = tmpSegments1->at(i);
            if (s1.p1.y - s3.p2.y >= CONNECT_LENGTH) {
                tmpSegments3->push_back(s1);
                continue;
            }
            if (s3.type2 == TYPE_OBSTACLE || s1.type1 == TYPE_OBSTACLE) {
                // 非作業領域で分割された作業パス用セグメントが、再接続された(想定外のエラー)
                throw runtime_error(ErrorCode::FATAL);
            }
            s3.p2 = s1.p2;
            s3.type2 = s1.type2;
        }
        // 作業パス用セグメントの妥当性チェック
        tmpSegments1->clear();
        for (int i = 0; i < tmpSegments3->size(); ++i) {
            const Segment &s3 = tmpSegments3->at(i);
//            if (s3.type1 == TYPE_SIDE_MARGIN || s3.type2 == TYPE_SIDE_MARGIN) {
//                // サイドマージンの作業パス
//                if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
//                    // 非作業領域で分割された作業パス用セグメントは除外できない(サイドマージンにも作業パスを生成する条件でリトライする)
//                    _combined = true;
//                    throw runtime_error(COMBINED_WA_NWA);
//                }
//                // リストに戻さない(除外する)
//                unavailablePaths = true;
//                continue;
//            }
            if (s3.p2.y - s3.p1.y < OFFSET_MINDISTSWEEP) {
                // 最低限の長さを満たしていない作業パス
                if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
                    // 非作業領域で分割された作業パス用セグメントは除外できない
                    // リストに戻す
                    tmpSegments1->push_back(s3);
                    continue;
                }
                // リストに戻さない(除外する)
                unavailablePaths = true;
                continue;
            }
            // 有効な作業パス
            // リストに戻す
            tmpSegments1->push_back(s3);
        }
        // 作業パスを降順にソート
        std::sort(tmpSegments1->begin(), tmpSegments1->end(), [](Segment s1, Segment s2) -> int { return (s1.p1.y > s2.p1.y); });
        for (int i = 0; i < tmpSegments1->size(); ++i) {
            Segment &s = tmpSegments1->at(i);
            // x座標は、==で判定しているところがあるので、posXで統一しておく
            s.p1.x = posX;
            s.p2.x = posX;
        }
		// 外周作業用HPに対して塗り潰しがあるかチェックする
		checkWorkingSegmentsEffectiveArea(tmpSegments1, false);
		for (int i = 0; i < tmpSegments1->size(); ++i) {
			Segment &s = tmpSegments1->at(i);
			workingSegmentsR->push_back(s);
		}
    }
    if (workingSegmentsR->size() == 0) {
        // 作業パスが1本も引けなかった
        if (unavailablePaths) {
            // 作業パスの候補はあったが、短すぎたか、サイドマージンと交わっていた
            throw runtime_error(ErrorCode::Nodes::NOTHING);
        } else {
            // 作業領域が狭すぎた
            throw runtime_error(ErrorCode::WorkingArea::SIZE);
        }
    }
}
/**
 * オフセット作業機の半渦巻き（非ブロックパターン）の作業パス用セグメントのリストを生成します。
 */
void FieldPolygon::createWorkingSegmentsOffset() {
	const double CULTIVATION_OFFSET_ROTATION = (_clockwiseVortex ? _cultivationWidthOffset : -_cultivationWidthOffset);
    Segments_ workingSegmentsF = Segments_(new Segments);
    Segments_ workingSegmentsR = Segments_(new Segments);
    createWorkingSegmentsOffsetFR(workingSegmentsF, workingSegmentsR);

    _workingSegments = Segments_(new Segments);
    if (_canBackward) {
        // バックあり(ダミーライドなし)
        int indexF = 0;
        int indexR = 0;
        // 正順側作業パスの作業中心位置
        double xF = workingSegmentsF->at(indexF).p1.x + CULTIVATION_OFFSET_ROTATION;
        // 逆順側作業パスの作業中心位置
        double xR = workingSegmentsR->at(indexR).p1.x - CULTIVATION_OFFSET_ROTATION;
        if (xR - xF <= TOLERANCE_2) {
            // 正順と逆順が1本ずつ引けることが最低条件、満たさない場合はエラー
            throw runtime_error(ErrorCode::Nodes::NOTHING);
        }
        while (indexF + 1 < workingSegmentsF->size() && workingSegmentsF->at(indexF + 1).p1.x == workingSegmentsF->at(indexF).p1.x) {
            // 同じライン上にある作業パスの分だけスキップ
            ++indexF;
        }
        while (indexR + 1 < workingSegmentsR->size() && workingSegmentsR->at(indexR + 1).p1.x == workingSegmentsR->at(indexR).p1.x) {
            // 同じライン上にある作業パスの分だけスキップ
            ++indexR;
        }
        vortexCount = 1;
        while (true) {
            if (indexF + 1 >= workingSegmentsF->size()) break;
            xF = workingSegmentsF->at(indexF + 1).p1.x + CULTIVATION_OFFSET_ROTATION;
            if (xR - xF <= TOLERANCE_2) break; // 正順側作業パスと逆順側作業パスの本数は同じ
            ++indexF;
            while (indexF + 1 < workingSegmentsF->size() && workingSegmentsF->at(indexF + 1).p1.x == workingSegmentsF->at(indexF).p1.x) {
                // 同じライン上にある作業パスの分だけスキップ
                ++indexF;
            }
            ++vortexCount;
            if (indexR + 1 >= workingSegmentsR->size()) break;
            xR = workingSegmentsR->at(indexR + 1).p1.x - CULTIVATION_OFFSET_ROTATION;
            if (xR - xF <= TOLERANCE_2) break; // 正順側作業パスの本数が1本多い
            ++indexR;
            while (indexR + 1 < workingSegmentsR->size() && workingSegmentsR->at(indexR + 1).p1.x == workingSegmentsR->at(indexR).p1.x) {
                // 同じライン上にある作業パスの分だけスキップ
                ++indexR;
            }
        }
        // 正順側
        for (int i = 0; i <= indexF; ++i) {
            Segment s = workingSegmentsF->at(i);
            _workingSegments->push_back(s);
        }
        // 逆順側
        for (int i = indexR; i >= 0; --i) {
            Segment s = workingSegmentsR->at(i);
            _workingSegments->push_back(s);
        }
    } else {
        // バックなし(ダミーライドあり)
        int indexF = 0;
        int indexR = 0;
        // 正順側作業パスの走行位置
        double xF = workingSegmentsF->at(indexF).p1.x;
        // 逆順側作業パスの走行位置
        double xR = workingSegmentsR->at(indexR).p1.x;
        double xRmin = xR;
        if (xR - xF < _turnRadius * 2) {
            // 正順と逆順が1本ずつ引けることが最低条件、満たさない場合はエラー
            throw runtime_error(ErrorCode::Nodes::NOTHING);
        }
        while (indexF + 1 < workingSegmentsF->size() && workingSegmentsF->at(indexF + 1).p1.x == workingSegmentsF->at(indexF).p1.x) {
            // 同じライン上にある作業パスの分だけスキップ
            ++indexF;
        }
        while (indexR + 1 < workingSegmentsR->size() && workingSegmentsR->at(indexR + 1).p1.x == workingSegmentsR->at(indexR).p1.x) {
            // 同じライン上にある作業パスの分だけスキップ
            ++indexR;
        }
        vortexCount = 1;
        // 正順と逆順のペアで走行できる範囲を決定
        // 正順側作業パスと逆順側作業パスの本数は同じ
        while (true) {
            if (indexF + 1 >= workingSegmentsF->size()) throw runtime_error(ErrorCode::FATAL);
            if (indexR + 1 >= workingSegmentsR->size()) throw runtime_error(ErrorCode::FATAL);
            xF = workingSegmentsF->at(indexF + 1).p1.x;
            xR = workingSegmentsR->at(indexR + 1).p1.x;
            // 逆順側作業パスから、次の正順側作業パスに、バックなしで入れなくなったら抜ける
            if (xR - xF < _turnRadius * 2 + pathInterval) break;
            // 正順側作業パスの作業中心位置と、逆順側作業パスの作業中心位置の、大小関係が入れ替わったら抜ける
            // (ぴったり全て塗り潰せている場合と、あと1本だけ正順とダミーライドのペアで(正順側だけ)走行する場合がある)
            if (xR - xF < CULTIVATION_OFFSET_ROTATION * 2) break;
            ++indexF;
            while (indexF + 1 < workingSegmentsF->size() && workingSegmentsF->at(indexF + 1).p1.x == workingSegmentsF->at(indexF).p1.x) {
                // 同じライン上にある作業パスの分だけスキップ
                ++indexF;
            }
            ++indexR;
            while (indexR + 1 < workingSegmentsR->size() && workingSegmentsR->at(indexR + 1).p1.x == workingSegmentsR->at(indexR).p1.x) {
                // 同じライン上にある作業パスの分だけスキップ
                ++indexR;
            }
            ++vortexCount;
            xRmin = xR;
        }
        // 正順と逆順のペアで走行する範囲の正順側
        int index = 0;
        for (; index <= indexF; ++index) {
            Segment s = workingSegmentsF->at(index);
            _workingSegments->push_back(s);
        }
        // 正順とダミーライドのペアで走行する範囲の正順側
        for (; index < workingSegmentsF->size(); ++index) {
            Segment s = workingSegmentsF->at(index);
            if (s.p1.x > xRmin - CULTIVATION_OFFSET_ROTATION * 2 - TOLERANCE_2) {
                // 正順側作業パスの作業中心位置が、逆順側最後の作業パスの作業中心位置を超えるまで
                break;
            }
            _workingSegments->push_back(s);
            while (index + 1 < workingSegmentsF->size() && workingSegmentsF->at(index + 1).p1.x == workingSegmentsF->at(index).p1.x) {
                // 同じライン上にある作業パスを追加
                ++index;
                Segment s = workingSegmentsF->at(index);
                _workingSegments->push_back(s);
            }
        }
        // 正順と逆順のペアで走行する範囲の逆順側
        for (int i = indexR; i >= 0; --i) {
            Segment s = workingSegmentsR->at(i);
            _workingSegments->push_back(s);
        }
    }

    SweepVertex.clear();
    for (int i = 0; i < _workingSegments->size(); ++i) {
        Segment segment = _workingSegments->at(i);
        SweepVertex.push_back(segment.p1);
        SweepVertex.push_back(segment.p2);
    }

    _workingSegments2 = Segments_(new Segments);
    if (_cultivationWidth2 > 0.0) {
        createWorkingSegments2();
    }
}
/**
 * オフセット作業機の半渦巻き（ブロックパターン）パス生成用のセグメントを生成します。
 * x座標で指定された1ライン分だけの作業パスを生成します。
 */
void FieldPolygon::addWorkingSegments(double posX, bool up) {
    // オフセット作業機の場合、10m未満の作業パスを除外しない
    // const double OFFSET_MINDISTSWEEP = MINDISTSWEEP;
    const double OFFSET_MINDISTSWEEP = 0;
    const int TYPE_HEAD_LAND   = 0;
    const int TYPE_SIDE_MARGIN = 1;
    const int TYPE_OBSTACLE    = 2;
    // FieldPolygonでの接続は廃止
    const double CONNECT_LENGTH = 0; // _turnRadius * 2.0 + _gps2CultivationPos;
    // 無効な作業パスが存在したかどうかを判定するフラグ
    bool unavailablePaths = false;
    Segments_ workingSegments = Segments_(new Segments);
    // posX:作業パスのx座標
    // TODO:作業パスは、幅を持った領域として考える必要があるが
    // とりあえず、直線x=posXと、作業領域と非作業領域との交点だけで考える
    Point2D pMinY = Point2D(posX, _workingAreasMin.y);
    Point2D pMaxY = Point2D(posX, _workingAreasMax.y);
    // 作業領域との交点から、障害物を考慮しない作業パス用セグメントのリストを生成
    Segments_ tmpSegments1 = Segments_(new Segments); // 作業パス
    for (int i = 0; i < _workingAreas->size(); ++i) {
        Polygon_ workingArea = _workingAreas->at(i);
        std::vector<_Point2D> crossPoints;
        if (createWorkingSegmentsOnSideMargin || _workPatternVortex) {
            std::vector<Point2D> tmpCrossPoints;
            PolygonUtil::getCrossPoints(workingArea, pMinY, pMaxY, &tmpCrossPoints);
            for (int j = 0; j < tmpCrossPoints.size(); ++j) {
                crossPoints.push_back(_Point2D(tmpCrossPoints[j], false));
            }
        } else {
            getCrossPoints(workingArea, pMinY, pMaxY, &crossPoints);
        }
        // 交点を昇順にソート
        std::sort(crossPoints.begin(), crossPoints.end(), [](_Point2D p1, _Point2D p2) -> int { return (p1.p.y < p2.p.y); });
        for (int j = 1; j < crossPoints.size(); ++j) {
            _Point2D p1 = crossPoints[j - 1];
            _Point2D p2 = crossPoints[j];
            Point2D pm;
            pm.x = (p1.p.x + p2.p.x) * 0.5;
            pm.y = (p1.p.y + p2.p.y) * 0.5;
            if (PolygonUtil::within(workingArea, pm)) {
                // 中間点が作業領域の内側にあれば作業パス
                Segment s = Segment(p1.p, p2.p, (p1.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND), (p2.onSideMargin ? TYPE_SIDE_MARGIN : TYPE_HEAD_LAND));
                tmpSegments1->push_back(s);
            }
        }
    }
    if (tmpSegments1->size() == 0) throw runtime_error(ErrorCode::FATAL);
    // 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
    for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
        Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
        // 非作業領域は矩形
        Point2D min;
        Point2D max;
        PolygonUtil::boundingBox(nonWorkingArea, &min, &max);
        Segments_ tmpSegments2 = Segments_(new Segments);
        for (int j = 0; j < tmpSegments1->size(); ++j) {
            const Segment &tmpSegment = tmpSegments1->at(j);
            if ((min.x < tmpSegment.p1.x && tmpSegment.p2.x < max.x) && (tmpSegment.p1.y < min.y && max.y < tmpSegment.p2.y)) {
                // 作業パス用セグメントが非作業領域を横切る場合、作業パス用セグメントを分割する
                Segment s1 = Segment(Point2D(tmpSegment.p1.x, tmpSegment.p1.y), Point2D(tmpSegment.p1.x, min.y), tmpSegment.type1, TYPE_OBSTACLE);
                Segment s2 = Segment(Point2D(tmpSegment.p2.x, max.y), Point2D(tmpSegment.p2.x, tmpSegment.p2.y), TYPE_OBSTACLE, tmpSegment.type2);
                tmpSegments2->push_back(s1);
                tmpSegments2->push_back(s2);
            } else {
                // 横切らない場合、そのまま追加(元のリストに戻す)
                tmpSegments2->push_back(tmpSegment);
            }
        }
        tmpSegments1->swap(*tmpSegments2);
    }
    if (tmpSegments1->size() == 0) throw runtime_error(ErrorCode::FATAL);
    // 作業パス間の間隔が旋回半径の2倍(+パス足長)未満の場合、作業パスを接続する(作業パス間の非作業領域も作業する)
    Segments_ tmpSegments3 = Segments_(new Segments);
    tmpSegments3->push_back(tmpSegments1->at(0));
    for (int i = 1; i < tmpSegments1->size(); ++i) {
        Segment &s3 = tmpSegments3->back();
        Segment &s1 = tmpSegments1->at(i);
        if (s1.p1.y - s3.p2.y >= CONNECT_LENGTH) {
            tmpSegments3->push_back(s1);
            continue;
        }
        if (s3.type2 == TYPE_OBSTACLE || s1.type1 == TYPE_OBSTACLE) {
            // 非作業領域で分割された作業パス用セグメントが、再接続された(想定外のエラー)
            throw runtime_error(ErrorCode::FATAL);
        }
        s3.p2 = s1.p2;
        s3.type2 = s1.type2;
    }
    // 作業パス用セグメントの妥当性チェック
    tmpSegments1->clear();
    for (int i = 0; i < tmpSegments3->size(); ++i) {
        const Segment &s3 = tmpSegments3->at(i);
//        if (s3.type1 == TYPE_SIDE_MARGIN || s3.type2 == TYPE_SIDE_MARGIN) {
//            // サイドマージンの作業パス
//            if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
//                // 非作業領域で分割された作業パス用セグメントは除外できない(サイドマージンにも作業パスを生成する条件でリトライする)
//                _combined = true;
//                throw runtime_error(COMBINED_WA_NWA);
//            }
//            // リストに戻さない(除外する)
//            unavailablePaths = true;
//            continue;
//        }
        if (s3.p2.y - s3.p1.y < OFFSET_MINDISTSWEEP) {
            // 最低限の長さを満たしていない作業パス
            if (s3.type1 == TYPE_OBSTACLE || s3.type2 == TYPE_OBSTACLE) {
                // 非作業領域で分割された作業パス用セグメントは除外できない
                // リストに戻す
                tmpSegments1->push_back(s3);
                continue;
            }
            // リストに戻さない(除外する)
            unavailablePaths = true;
            continue;
        }
        // 有効な作業パス
        // リストに戻す
        tmpSegments1->push_back(s3);
    }
    // 作業パスを昇順にソート
    std::sort(tmpSegments1->begin(), tmpSegments1->end(), [](Segment s1, Segment s2) -> int { return (s1.p1.y < s2.p1.y); });
    for (int i = 0; i < tmpSegments1->size(); ++i) {
        Segment &s = tmpSegments1->at(i);
        // x座標は、==で判定しているところがあるので、posXで統一しておく
        s.p1.x = posX;
        s.p2.x = posX;
    }
	// 外周作業用HPに対して塗り潰しがあるかチェックする
	checkWorkingSegmentsEffectiveArea(tmpSegments1, up);
	for (int i = 0; i < tmpSegments1->size(); ++i) {
		Segment &s = tmpSegments1->at(i);
		workingSegments->push_back(s);
	}
    if (workingSegments->size() == 0) {
        throw runtime_error(ErrorCode::FATAL);
    }
    _workingSegments->insert(_workingSegments->end(), workingSegments->begin(), workingSegments->end());
}
/**
 * バックありオフセット作業機の半渦巻き（ブロックパターン）の作業パス用セグメントのリストを生成します。
 * バックなし: createWorkingSegmentsOffsetBlock_noBack
 */
void FieldPolygon::createWorkingSegmentsOffsetBlock() {
    if (!_canBackward) {
        // バックなし
        createWorkingSegmentsOffsetBlock_noBack();
        return;
    }
    // バックあり
	const double CULTIVATION_OFFSET_ROTATION = (_clockwiseVortex ? _cultivationWidthOffset : -_cultivationWidthOffset);
    _workingSegments = Segments_(new Segments);
    // 　0 　2   　4   　6   　5   　3   　1   　8    10　  12　  11　 　9   　7
    // 順0 順1_1 順1_2 順1_3 逆1_3 逆1_2 逆1_1 順2_1 順2_2 順2_3 逆2_3 逆2_2 逆2_1
    int BLOCK_SIZE_2 = std::ceil(_turnRadius / pathInterval);
    if (BLOCK_SIZE_2 < 3) {
        BLOCK_SIZE_2 = 3;
    }
	// 作業ラインの総数
	int numLine = std::ceil((_workingAreasMax.x - _workingAreasMin.x) / pathInterval) + 1;
	// 作業パス＝走行位置
	double posXmin = _workingAreasMin.x + _cultivationWidth1 * 0.5 - CULTIVATION_OFFSET_ROTATION;
	if (_headlandWorking != Param::Work::Headland::Process::NOP) {
		posXmin = _headlandWorkingMin.x + _cultivationWidth1 * 0.5 - CULTIVATION_OFFSET_ROTATION;
	}
	while (posXmin < _workingAreasMin.x + TOLERANCE_2) {
		posXmin += pathInterval;
	}
	double posXmax = posXmin + CULTIVATION_OFFSET_ROTATION * 2 + pathInterval * (numLine - 1);
	while (posXmax > _workingAreasMax.x) {
		posXmax -= pathInterval;
		numLine -= 1;
	}
	if (_headlandWorking != Param::Work::Headland::Process::NOP) {
		while (posXmax - pathInterval > _headlandWorkingMax.x - _cultivationWidth1 * 0.5 + CULTIVATION_OFFSET_ROTATION) {
			posXmax -= pathInterval;
			numLine -= 1;
		}
	}
    // ブロック(分割)数
    const int numBlock = (numLine - 1) / (BLOCK_SIZE_2 * 2);
    if (numBlock < 1) throw runtime_error(ErrorCode::WorkingArea::BLOCK);

    // 順0
    addWorkingSegments(posXmin, true);
    // ブロック単位
    for (int i = 0; i < numBlock - 1; ++i) {
        // 逆n_1のインデックス
        int indexR = BLOCK_SIZE_2 * 2 * (i + 1);
        // 順n_1のインデックス
        int indexF = BLOCK_SIZE_2 * 2 * i + 1;
        // ブロック内の作業パス (BLOCK_SIZE_2*2本)
        for (int j = 0; j < BLOCK_SIZE_2; ++j) {
            // 必ず(逆+順)のペアで生成
            addWorkingSegments(posXmin + pathInterval * indexR + CULTIVATION_OFFSET_ROTATION * 2, false);
            addWorkingSegments(posXmin + pathInterval * indexF, true);
            --indexR;
            ++indexF;
        }
    }
    // 最後のブロック
    // 逆n_1のインデックス
    int indexR2 = 0;
    // 順n_1のインデックス
    int indexF = BLOCK_SIZE_2 * 2 * (numBlock - 1) + 1;
    // 最後に追加した順方向作業パスの走行位置
    double prevSFX = _workingSegments->back().p1.x;
    double prevSRX;
    // 作業位置(!=走行位置)の間隔がpathInterval以下になるまでパスを生成 (走行位置の間隔がpathInterval+_cultivationWidthOffset*2以下)
    while (true) {
        // 逆n_i
        addWorkingSegments(posXmax - pathInterval * indexR2, false);
        ++indexR2;
        prevSRX = _workingSegments->back().p1.x;
        if (prevSRX - prevSFX <= pathInterval + CULTIVATION_OFFSET_ROTATION * 2 + TOLERANCE_2) break;
        // 順n_i
        addWorkingSegments(posXmin + pathInterval * indexF, true);
        ++indexF;
        prevSFX = _workingSegments->back().p1.x;
        if (prevSRX - prevSFX <= pathInterval + CULTIVATION_OFFSET_ROTATION * 2 + TOLERANCE_2) break;
    }

    // _workingSegmentsのx座標を覚えておく
    workingOrders.clear();
    for (auto segment = _workingSegments->begin(); segment != _workingSegments->end(); ++segment) {
        if (workingOrders.size() > 0 && segment->p1.x == workingOrders.back().x) {
            continue;
        }
        OutField::WorkingOrder workingOrder;
        workingOrder.x = segment->p1.x;
        workingOrder.dummy = (segment->type1 == 1);
        workingOrders.push_back(workingOrder);
    }
    // _workingSegmentsをx座標の昇順にソート
    std::sort(_workingSegments->begin(), _workingSegments->end(), [](Segment s1, Segment s2) -> int {
        return (s1.p1.x == s2.p1.x ? s1.p1.y < s2.p1.y : s1.p1.x < s2.p1.x);
    });
    // 重複を省く
	Segments_ tmp = Segments_(new Segments);
	tmp->push_back(_workingSegments->at(0));
	for (int i = 1; i < _workingSegments->size(); ++i) {
		const Segment &segment = _workingSegments->at(i);
		if (segment.p1.x == tmp->back().p1.x && segment.p1.y == tmp->back().p1.y) {
			// 全く同じ作業パスは除外
			continue;
		}
		if (segment.p1.x == tmp->back().p1.x && segment.p1.y != tmp->back().p1.y) {
			// 同じラインの別の作業パスは除外しない
			tmp->push_back(segment);
			continue;
		}
		if (segment.p1.x < tmp->back().p1.x + TOLERANCE_2) {
			// x座標の差がTOLERANCE_2未満の場合、すでに追加されている作業ラインの作業パスを走行するように変更する
			// tmpに追加しない(_workingSegmentsから削除する)のは==の場合と同じだけど、workingOrdersの更新が必要
			for (auto workingOrder = workingOrders.begin(); workingOrder != workingOrders.end(); ++workingOrder) {
				if (workingOrder->x == segment.p1.x) {
					workingOrder->x = tmp->back().p1.x;
				}
			}
			continue;
		}
		tmp->push_back(segment);
	}
	_workingSegments->swap(*tmp);
    // WorkingOrderのindexに_workingSegmentsのインデックスを設定 (x座標の昇順にソートされた_workingSegmentsをどういう順序で作業するか)
    for (auto workingOrder = workingOrders.begin(); workingOrder != workingOrders.end(); ++workingOrder) {
        double x = _workingSegments->at(0).p1.x;
        int index = 0;
        for (int i = 0; i < _workingSegments->size(); ++i) {
            if (_workingSegments->at(i).p1.x != x) {
                x = _workingSegments->at(i).p1.x;
                ++index;
            }
            if (_workingSegments->at(i).p1.x == workingOrder->x) {
                workingOrder->index = index;
                break;
            }
        }
        if (workingOrder->index < 0) {
            throw runtime_error(ErrorCode::FATAL);
        }
    }

    SweepVertex.clear();
    for (int i = 0; i < _workingSegments->size(); ++i) {
        Segment segment = _workingSegments->at(i);
        SweepVertex.push_back(segment.p1);
        SweepVertex.push_back(segment.p2);
    }

    _workingSegments2 = Segments_(new Segments);
    if (_cultivationWidth2 > 0.0) {
        createWorkingSegments2();
    }
}
/**
 * バックなしオフセット作業機の半渦巻き（ブロックパターン）の作業パス用セグメントのリストを生成します。
 * バックあり: createWorkingSegmentsOffsetBlock
 */
void FieldPolygon::createWorkingSegmentsOffsetBlock_noBack() {
    // バックなし
	const double CULTIVATION_OFFSET_ROTATION = (_clockwiseVortex ? _cultivationWidthOffset : -_cultivationWidthOffset);
    _workingSegments = Segments_(new Segments);
    // 　0　 2  　 4  　 6  　 8  　10  　12  　 5  　 3  　 1  　11  　 9  　 7  　14  　16  　18  　20  　22  　24  　17  　15  　13  　23  　21  　19
    // 順0 順111 順112 順113 順121 順122 順123 逆113 逆112 逆111 逆123 逆122 逆121 順211 順212 順213 順221 順222 順223 逆213 逆212 逆211 逆223 逆222 逆221
    // pathInterval * (BLOCK_SIZE_4 + 1) + _cultivationWidthOffset * 2 > _turnRadius * 2
    // 最後のブロックで余りをオーバーラップとして処理するため、最大でpathInterval分の余裕を見ておく必要がある
    // そのため、上式で決まるブロックサイズに+1する
    int BLOCK_SIZE_4 = std::floor((_turnRadius - CULTIVATION_OFFSET_ROTATION) * 2 / pathInterval) + 1;
    if (BLOCK_SIZE_4 < 2) {
        BLOCK_SIZE_4 = 2;
    }
	// 作業ラインの総数
	int numLine = std::ceil((_workingAreasMax.x - _workingAreasMin.x) / pathInterval) + 1;
	// 作業パス＝走行位置
	double posXmin = _workingAreasMin.x + _cultivationWidth1 * 0.5 - CULTIVATION_OFFSET_ROTATION;
	if (_headlandWorking != Param::Work::Headland::Process::NOP) {
		posXmin = _headlandWorkingMin.x + _cultivationWidth1 * 0.5 - CULTIVATION_OFFSET_ROTATION;
	}
	while (posXmin < _workingAreasMin.x + TOLERANCE_2) {
		posXmin += pathInterval;
	}
	double posXmax = posXmin + CULTIVATION_OFFSET_ROTATION * 2 + pathInterval * (numLine - 1);
	while (posXmax > _workingAreasMax.x) {
		posXmax -= pathInterval;
		numLine -= 1;
	}
	if (_headlandWorking != Param::Work::Headland::Process::NOP) {
		while (posXmax - pathInterval > _headlandWorkingMax.x - _cultivationWidth1 * 0.5 + CULTIVATION_OFFSET_ROTATION) {
			posXmax -= pathInterval;
			numLine -= 1;
		}
	}
    // ブロック(分割)数
    const int numBlock = (numLine - 1) / (BLOCK_SIZE_4 * 4);
    if (numBlock < 1) throw runtime_error(ErrorCode::WorkingArea::BLOCK);

    // 順0
    addWorkingSegments(posXmin, true);
    // ブロック単位
    for (int i = 0; i < numBlock - 1; ++i) {
        // 順n11のインデックス
        int indexF1 = BLOCK_SIZE_4 * 4 * i + 1;
        // 順n21のインデックス
        int indexF2 = indexF1 + BLOCK_SIZE_4;
        // 逆n11のインデックス
        int indexR1 = indexF2 + BLOCK_SIZE_4 * 2 - 1;
        // 逆n21のインデックス
        int indexR2 = indexR1 + BLOCK_SIZE_4;
        // 逆n1xと順n1xのペア (BLOCK_SIZE_4*2本)
        for (int j = 0; j < BLOCK_SIZE_4; ++j) {
            // 必ず(逆+順)のペアで生成
            addWorkingSegments(posXmin + pathInterval * indexR1 + CULTIVATION_OFFSET_ROTATION * 2, false);
            addWorkingSegments(posXmin + pathInterval * indexF1, true);
            --indexR1;
            ++indexF1;
        }
        // 逆n2xと順n2xのペア (BLOCK_SIZE_4*2本)
        for (int j = 0; j < BLOCK_SIZE_4; ++j) {
            // 必ず(逆+順)のペアで生成
            addWorkingSegments(posXmin + pathInterval * indexR2 + CULTIVATION_OFFSET_ROTATION * 2, false);
            addWorkingSegments(posXmin + pathInterval * indexF2, true);
            --indexR2;
            ++indexF2;
        }
    }
    // 最後のブロック、後半の作業ライン数 (順0の分-1)
    const int numLineL2 = numLine - BLOCK_SIZE_4 * 4 * (numBlock - 1) - BLOCK_SIZE_4 * 2 - 1;
    const int numLineL2F = numLineL2 / 2;
    const int numLineL2R = numLineL2 - numLineL2F;
    // 順n11のインデックス
    int indexF1 = BLOCK_SIZE_4 * 4 * (numBlock - 1) + 1;
    // 順n21のインデックス
    int indexF2 = indexF1 + BLOCK_SIZE_4;
    // 逆n11のインデックス
    int indexR1 = indexF2 + numLineL2F + BLOCK_SIZE_4 - 1;
    // 逆n21のインデックス
    int indexR2 = indexR1 + numLineL2R;
    // 逆n1xと順n1xのペア (BLOCK_SIZE_4*2本)
    for (int j = 0; j < BLOCK_SIZE_4; ++j) {
        // 必ず(逆+順)のペアで生成
        addWorkingSegments(posXmin + pathInterval * indexR1 + CULTIVATION_OFFSET_ROTATION * 2, false);
        addWorkingSegments(posXmin + pathInterval * indexF1, true);
        --indexR1;
        ++indexF1;
    }
    // 逆n2xと順n2xのペア (numLineL2F*2本)
    for (int j = 0; j < numLineL2F; ++j) {
        // 必ず(逆+順)のペアで生成
        addWorkingSegments(posXmin + pathInterval * indexR2 + CULTIVATION_OFFSET_ROTATION * 2, false);
        addWorkingSegments(posXmin + pathInterval * indexF2, true);
        --indexR2;
        ++indexF2;
    }
    if (numLineL2R > numLineL2F) {
        // 最後のブロック、後半の逆順パスが1本多い場合
        addWorkingSegments(posXmin + pathInterval * indexR2 + CULTIVATION_OFFSET_ROTATION * 2, false);
    }

    // _workingSegmentsのx座標を覚えておく
    workingOrders.clear();
    for (auto segment = _workingSegments->begin(); segment != _workingSegments->end(); ++segment) {
        if (workingOrders.size() > 0 && segment->p1.x == workingOrders.back().x) {
            continue;
        }
        OutField::WorkingOrder workingOrder;
        workingOrder.x = segment->p1.x;
        workingOrder.dummy = (segment->type1 == 1);
        workingOrders.push_back(workingOrder);
    }
    // _workingSegmentsをx座標の昇順にソート
    std::sort(_workingSegments->begin(), _workingSegments->end(), [](Segment s1, Segment s2) -> int {
        return (s1.p1.x == s2.p1.x ? s1.p1.y < s2.p1.y : s1.p1.x < s2.p1.x);
    });
    // 重複を省く
	Segments_ tmp = Segments_(new Segments);
	tmp->push_back(_workingSegments->at(0));
	for (int i = 1; i < _workingSegments->size(); ++i) {
		const Segment &segment = _workingSegments->at(i);
		if (segment.p1.x == tmp->back().p1.x && segment.p1.y == tmp->back().p1.y) {
			// 全く同じ作業パスは除外
			continue;
		}
		if (segment.p1.x == tmp->back().p1.x && segment.p1.y != tmp->back().p1.y) {
			// 同じラインの別の作業パスは除外しない
			tmp->push_back(segment);
			continue;
		}
		if (segment.p1.x < tmp->back().p1.x + TOLERANCE_2) {
			// x座標の差がTOLERANCE_2未満の場合、すでに追加されている作業ラインの作業パスを走行するように変更する
			// tmpに追加しない(_workingSegmentsから削除する)のは==の場合と同じだけど、workingOrdersの更新が必要
			for (auto workingOrder = workingOrders.begin(); workingOrder != workingOrders.end(); ++workingOrder) {
				if (workingOrder->x == segment.p1.x) {
					workingOrder->x = tmp->back().p1.x;
				}
			}
			continue;
		}
		tmp->push_back(segment);
	}
	_workingSegments->swap(*tmp);
    // WorkingOrderのindexに_workingSegmentsのインデックスを設定 (x座標の昇順にソートされた_workingSegmentsをどういう順序で作業するか)
    for (auto workingOrder = workingOrders.begin(); workingOrder != workingOrders.end(); ++workingOrder) {
        double x = _workingSegments->at(0).p1.x;
        int index = 0;
        for (int i = 0; i < _workingSegments->size(); ++i) {
            if (_workingSegments->at(i).p1.x != x) {
                x = _workingSegments->at(i).p1.x;
                ++index;
            }
            if (_workingSegments->at(i).p1.x == workingOrder->x) {
                workingOrder->index = index;
                break;
            }
        }
        if (workingOrder->index < 0) {
            throw runtime_error(ErrorCode::FATAL);
        }
    }

    SweepVertex.clear();
    for (int i = 0; i < _workingSegments->size(); ++i) {
        Segment segment = _workingSegments->at(i);
        SweepVertex.push_back(segment.p1);
        SweepVertex.push_back(segment.p2);
    }

    _workingSegments2 = Segments_(new Segments);
    if (_cultivationWidth2 > 0.0) {
        createWorkingSegments2();
    }
}
void FieldPolygon::createWorkingSegmentsOffsetBlock_rect() {
    _workingSegments = Segments_(new Segments);
    vortexCount = std::ceil(_turnRadius / pathInterval);
    for (int i = 0; i < vortexCount; ++i) {
        double d1 = pathInterval * i;
        double d2 = pathInterval * (i == 0 ? 0 : i - 1);
        _workingSegments->push_back(Segment(Point2D(_workingAreasMin.x + TOLERANCE_2 + d1, _workingAreasMin.y + d2), Point2D(_workingAreasMin.x + TOLERANCE_2 + d1, _workingAreasMax.y - d1), 0, 0));
        _workingSegments->push_back(Segment(Point2D(_workingAreasMax.x - TOLERANCE_2 - d1, _workingAreasMin.y + d1), Point2D(_workingAreasMax.x - TOLERANCE_2 - d1, _workingAreasMax.y - d1), 0, 0));
    }
    // ブロックの作業順序
    // 　0 　2   　4   　6   　5   　3   　1   　8    10　  12　  11　 　9   　7
    // 順0 順1_1 順1_2 順1_3 逆1_3 逆1_2 逆1_1 順2_1 順2_2 順2_3 逆2_3 逆2_2 逆2_1
    int BLOCK_SIZE_2 = std::ceil(_turnRadius / pathInterval);
    if (BLOCK_SIZE_2 < 3) {
        BLOCK_SIZE_2 = 3;
    }
    // 作業パス＝走行位置
    double posXmin = _workingAreasMin.x + TOLERANCE_2 + pathInterval * vortexCount;
    double posXmax = _workingAreasMax.x - TOLERANCE_2 - pathInterval * vortexCount;
    // 作業位置＝走行位置＋作業機オフセット
    double cXmin = posXmin + _cultivationWidthOffset;
    double cXmax = posXmax - _cultivationWidthOffset;
    // 作業ラインの総数
    int numLine = (cXmax - cXmin) / pathInterval + 1;
    // ブロック(分割)数
    int numBlock = (numLine - 1) / (BLOCK_SIZE_2 * 2);
    // 順方向(左詰め)の作業パス(仮)
    Segments_ workingSegmentsF = Segments_(new Segments);
    // 逆方向(左詰め)の作業パス(仮)
    Segments_ workingSegmentsR = Segments_(new Segments);
    // 逆方向(右詰め)の作業パス(仮)
    Segments_ workingSegmentsR2 = Segments_(new Segments);
    // 作業パス(仮)の生成
    for (int i = 0; i < numLine; ++i) {
        // cX:左詰め作業位置(!=走行位置)のx座標
        double cX = cXmin + pathInterval * i;
        // 順方向(左詰め)の走行位置
        double posXF = cX - _cultivationWidthOffset;
        Segment sF = Segment(Point2D(posXF, _workingAreasMin.y), Point2D(posXF, _workingAreasMax.y), 0, 0);
        workingSegmentsF->push_back(sF);
        // 逆方向(左詰め)の走行位置
        double posXR = cX + _cultivationWidthOffset;
        Segment sR = Segment(Point2D(posXR, _workingAreasMin.y), Point2D(posXR, _workingAreasMax.y), 0, 0);
        workingSegmentsR->push_back(sR);
        // cX2:右詰め作業位置(!=走行位置)のx座標
        double cX2 = cXmax - pathInterval * (numLine - 1 - i);
        // 逆方向(右詰め)の走行位置
        double posXR2 = cX2 + _cultivationWidthOffset;
        Segment sR2 = Segment(Point2D(posXR2, _workingAreasMin.y), Point2D(posXR2, _workingAreasMax.y), 0, 0);
        workingSegmentsR2->push_back(sR2);
    }
    // 3種類の作業パス(仮)から、作業パスを生成
    // 順0 (作業パスの始端側y座標を、CYCLONE側に合わせる)
    Segment sF0 = workingSegmentsF->at(0);
    sF0.p1.y += pathInterval * (vortexCount - 1);
    _workingSegments->push_back(sF0);
    // ブロック単位
    for (int i = 0; i < numBlock - 1; ++i) {
        // 逆n_1のインデックス
        int indexR = BLOCK_SIZE_2 * 2 * (i + 1);
        // 順n_1のインデックス
        int indexF = BLOCK_SIZE_2 * 2 * i + 1;
        // ブロック内の作業パス (BLOCK_SIZE_2*2本)
        for (int j = 0; j < BLOCK_SIZE_2; ++j) {
            // 必ず(逆+順)のペアで生成
            _workingSegments->push_back(workingSegmentsR->at(indexR));
            _workingSegments->push_back(workingSegmentsF->at(indexF));
            --indexR;
            ++indexF;
        }
    }
    // 最後のブロック
    // 逆n_1のインデックス
    int indexR2 = numLine - 1;
    // 順n_1のインデックス
    int indexF = BLOCK_SIZE_2 * 2 * (numBlock - 1) + 1;
    // 最後に追加した順方向作業パスの走行位置
    double prevSFX = _workingSegments->back().p1.x;
    // 作業位置(!=走行位置)の間隔がpathInterval以下になるまでパスを生成 (走行位置の間隔がpathInterval+_cultivationWidthOffset*2以下)
    while (true) {
        // 逆n_i
        const Segment &sR2 = workingSegmentsR2->at(indexR2);
        _workingSegments->push_back(sR2);
        --indexR2;
        if (sR2.p1.x - prevSFX <= pathInterval + _cultivationWidthOffset * 2) break;
        // 順n_i
        const Segment &sF = workingSegmentsF->at(indexF);
        _workingSegments->push_back(sF);
        ++indexF;
        if (sR2.p1.x - sF.p1.x <= pathInterval + _cultivationWidthOffset * 2) break;
        // 最後に追加した順方向作業パスの走行位置
        prevSFX = sF.p1.x;
    }

    // _workingSegmentsのx座標を覚えておく
    workingOrders.clear();
    for (auto segment = _workingSegments->begin(); segment != _workingSegments->end(); ++segment) {
        OutField::WorkingOrder workingOrder;
        workingOrder.x = segment->p1.x;
        workingOrder.dummy = (segment->type1 == 1);
        workingOrders.push_back(workingOrder);
    }
    // _workingSegmentsをx座標の昇順にソート
    std::sort(_workingSegments->begin(), _workingSegments->end(), [](Segment s1, Segment s2) -> int { return (s1.p1.x < s2.p1.x); });
    // 重複を省く
    Segments_ tmp = Segments_(new Segments);
    tmp->push_back(_workingSegments->at(0));
    for (int i = 1; i < _workingSegments->size(); ++i) {
        const Segment &segment = _workingSegments->at(i);
        if (segment.p1.x == tmp->back().p1.x) {
            // x座標が同じ場合、スキップ
            continue;
        } else if (segment.p1.x < tmp->back().p1.x + TOLERANCE_2) {
            // x座標の差がTOLERANCE_2未満の場合、作業パスを統合する
            // tmpに追加しない(_workingSegmentsから削除する)のは==の場合と同じだけど、workingOrdersの更新が必要
            for (auto workingOrder = workingOrders.begin(); workingOrder != workingOrders.end(); ++workingOrder) {
                if (workingOrder->x == segment.p1.x) {
                    workingOrder->x = tmp->back().p1.x;
                }
            }
            continue;
        }
        tmp->push_back(segment);
    }
    _workingSegments->swap(*tmp);
    // WorkingOrderのindexに_workingSegmentsのインデックスを設定 (x座標の昇順にソートされた_workingSegmentsをどういう順序で作業するか)
    for (auto workingOrder = workingOrders.begin(); workingOrder != workingOrders.end(); ++workingOrder) {
        for (int index = 0; index < _workingSegments->size(); ++index) {
            if (_workingSegments->at(index).p1.x == workingOrder->x) {
                workingOrder->index = index;
                break;
            }
        }
        if (workingOrder->index < 0) {
            throw runtime_error(ErrorCode::FATAL);
        }
    }

    SweepVertex.clear();
    for (int i = 0; i < _workingSegments->size(); ++i) {
        Segment segment = _workingSegments->at(i);
        SweepVertex.push_back(segment.p1);
        SweepVertex.push_back(segment.p2);
    }

    _workingSegments2 = Segments_(new Segments);
    if (_cultivationWidth2 > 0.0) {
        createWorkingSegments2();
    }
}

/**
 * 作業領域+非作業領域+作業パスの頂点をミックスした配列と、そのグラフを生成します。
 * たぶん枕地領域内の移動用
 */
void FieldPolygon::createNavigationGraph() {
    if (_workPatternVortex && false) {
        createNavigationGraphVortex();
        return;
    }
	NavFieldVertex.clear();
	for (int i = 0; i < gh.NumVertices(); ++i) {
		gh.RemoveVertex(i);
	}
	gh.vertices.clear();

	for (int i = 0; i < _workingAreas->size(); ++i) {
		Polygon_ workingArea = _workingAreas->at(i);
		int size = (int) NavFieldVertex.size();
		for (int j = 0; j < workingArea->size(); ++j) {
			Point2D p = workingArea->at(j);
			NavFieldVertex.push_back(p);
			int k = j + 1 < workingArea->size() ? j + 1 : 0;
			gh.AddEdge(size + j, size + k, Graph::SINGLE);
			gh.AddEdge(size + k, size + j, Graph::SINGLE);
		}
	}
	for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
		Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
		int size = (int) NavFieldVertex.size();
		for (int j = 0; j < nonWorkingArea->size(); ++j) {
			Point2D p = nonWorkingArea->at(j);
			NavFieldVertex.push_back(p);
			int k = j + 1 < nonWorkingArea->size() ? j + 1 : 0;
			gh.AddEdge(size + j, size + k, Graph::SINGLE);
			gh.AddEdge(size + k, size + j, Graph::SINGLE);
		}
	}
	int size = (int) NavFieldVertex.size();

	assert(gh.vertices.size() == gh.NumVertices());

	for (int i = 0; i < SweepVertex.size(); i++) {
		Point2D p = SweepVertex[i];

		bool divided = false;
		for (int j = 0; j < NavFieldVertex.size(); j++) {
			Point2D p1 = NavFieldVertex[j];

			for (auto itr = gh.begin(j); itr != gh.end(j); ++itr) {
				int k = itr->first;
				Point2D p2 = NavFieldVertex[k];

				double diff = fabs(PolygonUtil::length(p, p1) + PolygonUtil::length(p, p2) - PolygonUtil::length(p1, p2));
				if (diff < TOLERANCE) {
					Vertex v(p.x, p.y);
					NavFieldVertex.insert(NavFieldVertex.end(), v);

					if (gh.NumVertices() > Graph::NO_OF_VERTICES) {
						// 頂点数が限界値を超えた
						LOGE("FieldPolygon::createNavigationGraph()", "[Exception] too many verticies.");
						throw runtime_error(ErrorCode::Nodes::LIMITS);
					}

					gh.AddEdge(j, i + size, Graph::DOUBLE);
					gh.AddEdge(i + size, j, Graph::DOUBLE);
					gh.AddEdge(i + size, k, Graph::DOUBLE);
					gh.AddEdge(k, i + size, Graph::DOUBLE);

					gh.RemoveEdge(j, k);
					gh.RemoveEdge(k, j);
					assert(gh.vertices.size() == gh.NumVertices());

					divided = true;
					break;
				}
			}
			if (divided) {
				break;
			}
		}
		if (!divided) {
			// 作業パスの端点が、グラフ上のノードとして登録されなかった場合
			throw runtime_error(ErrorCode::FATAL);
		}
	}
}
/**
 * 渦巻きパスのグラフ生成
 * 作業領域が矩形で、作業パスの端点が上辺と下辺にしかないことが前提
 */
void FieldPolygon::createNavigationGraphVortex() {
    NavFieldVertex.clear();
    for (int i = 0; i < gh.NumVertices(); ++i) {
        gh.RemoveVertex(i);
    }
    gh.vertices.clear();

    for (int i = 0; i < _workingAreas->size(); ++i) {
        Polygon_ workingArea = _workingAreas->at(i);
        int size = (int) NavFieldVertex.size();
        for (int j = 0; j < workingArea->size(); ++j) {
            Point2D p = workingArea->at(j);
            NavFieldVertex.push_back(p);
            int k = j + 1 < workingArea->size() ? j + 1 : 0;
            gh.AddEdge(size + j, size + k, Graph::SINGLE);
            gh.AddEdge(size + k, size + j, Graph::SINGLE);
        }
    }
    for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
        Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
        int size = (int) NavFieldVertex.size();
        for (int j = 0; j < nonWorkingArea->size(); ++j) {
            Point2D p = nonWorkingArea->at(j);
            NavFieldVertex.push_back(p);
            int k = j + 1 < nonWorkingArea->size() ? j + 1 : 0;
            gh.AddEdge(size + j, size + k, Graph::SINGLE);
            gh.AddEdge(size + k, size + j, Graph::SINGLE);
        }
    }
    int size = (int) NavFieldVertex.size();

    assert(gh.vertices.size() == gh.NumVertices());

    // 下側
    int d0 = -1;
    int d1 = -1;
    // TODO:矩形前提なら、BLOCK以外の場合でも(0,3)で良い気がする
    if (_progressType == Param::Work::ProgressType::BLOCK && false) {
        d0 = 0;
        d1 = 3;
    } else {
        bool divided = false;
        Point2D p = SweepVertex[0];
        for (int i = 0; i < NavFieldVertex.size(); ++i) {
            Point2D p1 = NavFieldVertex[i];
            for (auto itr = gh.begin(i); itr != gh.end(i); ++itr) {
                int j = itr->first;
                Point2D p2 = NavFieldVertex[j];
                double diff = fabs(PolygonUtil::length(p, p1) + PolygonUtil::length(p, p2) - PolygonUtil::length(p1, p2));
                if (diff < TOLERANCE) {
                    divided = true;
                    if (p1.x < p2.x) {
                        d0 = i;
                        d1 = j;
                    } else {
                        d0 = j;
                        d1 = i;
                    }
                    break;
                }
            }
            if (divided) {
                break;
            }
        }
    }
    // 上側
    int u0 = -1;
    int u1 = -1;
    // TODO:矩形前提なら、BLOCK以外の場合でも(1,2)で良い気がする
    if (_progressType == Param::Work::ProgressType::BLOCK && false) {
        u0 = 1;
        u1 = 2;
    } else {
        bool divided = false;
        Point2D p = SweepVertex[1];
        for (int i = 0; i < NavFieldVertex.size(); ++i) {
            Point2D p1 = NavFieldVertex[i];
            for (auto itr = gh.begin(i); itr != gh.end(i); ++itr) {
                int j = itr->first;
                Point2D p2 = NavFieldVertex[j];
                double diff = fabs(PolygonUtil::length(p, p1) + PolygonUtil::length(p, p2) - PolygonUtil::length(p1, p2));
                if (diff < TOLERANCE) {
                    divided = true;
                    if (p1.x < p2.x) {
                        u0 = i;
                        u1 = j;
                    } else {
                        u0 = j;
                        u1 = i;
                    }
                    break;
                }
            }
            if (divided) {
                break;
            }
        }
    }
    // assert
    if (d0 < 0 || d1 < 0 || u0 < 0 || u1 < 0) {
        throw runtime_error(ErrorCode::FATAL);
    }
    gh.RemoveEdge(d0, d1);
    gh.RemoveEdge(d1, d0);
    gh.RemoveEdge(u0, u1);
    gh.RemoveEdge(u1, u0);
    // HPポリゴンを無視してグラフ生成
    for (int i = 0; i < SweepVertex.size(); i += 2) {
        // 下側
        Point2D pd = SweepVertex[i];
        Vertex vd(pd.x, pd.y);
        NavFieldVertex.insert(NavFieldVertex.end(), vd);
        gh.AddEdge(d0, size+i, Graph::DOUBLE);
        gh.AddEdge(size+i, d0, Graph::DOUBLE);
        d0 = size+i;
        // 上側
        Point2D pu = SweepVertex[i+1];
        Vertex vu(pu.x, pu.y);
        NavFieldVertex.insert(NavFieldVertex.end(), vu);
        gh.AddEdge(u0, size+i+1, Graph::DOUBLE);
        gh.AddEdge(size+i+1, u0, Graph::DOUBLE);
        u0 = size+i+1;
        if (gh.NumVertices() > Graph::NO_OF_VERTICES) {
            // 頂点数が限界値を超えた
            LOGE("FieldPolygon::createNavigationGraph()", "[Exception] too many verticies.");
            throw runtime_error(ErrorCode::Nodes::LIMITS);
        }
    }
    gh.AddEdge(d0, d1, Graph::DOUBLE);
    gh.AddEdge(d1, d0, Graph::DOUBLE);
    gh.AddEdge(u0, u1, Graph::DOUBLE);
    gh.AddEdge(u1, u0, Graph::DOUBLE);
}

/**
 * 作業開始位置を決定します。
 * (左端の作業パス(ライン)の上端/下端で、UIで設定したスタート位置に近い方の頂点インデックス)
 * 自動運転の開始・終了位置を決定します。
 * (作業領域+作業パスの頂点で、UIで設定したスタート・エンド位置に最も近い点の頂点インデックス)
 */
bool FieldPolygon::defineStartEndPoint(bool retry) {
	// 最初/最後の作業ラインの最初/最後の点が候補
	// 1本目の作業パスの前後の点
	Point2D p1 = _workingSegments->front().p1;
	Point2D p2 = _workingSegments->front().p2;
	// 1本目の作業パスと同じラインの作業パスが存在する場合、p2を更新
	for (int i = 1; i < _workingSegments->size(); ++i) {
		Segment s = _workingSegments->at(i);
		if (s.p2.x != p1.x) {
			break;
		}
		p2 = s.p2;
	}
	// 最後の作業パスの前後の点
	Point2D p3 = _workingSegments->back().p1;
	Point2D p4 = _workingSegments->back().p2;
	// 最後の作業パスと同じラインの作業パスが存在する場合、p3を更新
	for (int i = 1; i < _workingSegments->size(); ++i) {
		Segment s = _workingSegments->at(_workingSegments->size() - 1 - i);
		if (s.p1.x != p4.x) {
			break;
		}
		p3 = s.p1;
	}
	// NavFieldVertexにおけるインデックス値を求める
	int p1Index = -1;
	int p2Index = -1;
	int p3Index = -1;
	int p4Index = -1;
	for (int i = 0; i < NavFieldVertex.size(); ++i) {
		Point2D p = NavFieldVertex[i];
		if (p == p1) {
			p1Index = i;
		}
		if (p == p2) {
			p2Index = i;
		}
		if (p == p3) {
			p3Index = i;
		}
		if (p == p4) {
			p4Index = i;
		}
	}
	// 外周作業の開始位置
	if (_headlandWorking == Param::Work::Headland::Process::PRE) {
		// 外周作業が先の場合
		const double HEADLAND_START_STICKY = 10;
		// uiStartから一番近い_headlandWorkingHP上の点p
		// pが辺上の場合、pからpが乗る辺の両端までの距離を計算する
		//   どちらか片方でも{HEADLAND_START_STICKY}m未満の場合、近い方の頂点が外周作業の開始位置
		//   両方とも{HEADLAND_START_STICKY}m以上の場合、外周作業の回る方向にある頂点が外周作業の開始位置
		// pが頂点の場合、pが外周作業の開始位置
		const PolygonUtil::Segments_ segments = PolygonUtil::createSegments(_headlandWorkingHP);
		double dm = 1000000;
		for (int i = 0; i < segments->size(); ++i) {
			const PolygonUtil::Segment &s = segments->at(i);
			Point2D pp = PolygonUtil::perpendicularPoint(uiStart, s);
			if (s.contains(pp)) {
				// ppが線分s上にある場合
				const double d = PolygonUtil::length(uiStart, pp);
				if (d < dm) {
					dm = d;
					const double d1 = PolygonUtil::length(pp, s.p1);
					const double d2 = PolygonUtil::length(pp, s.p2);
					if (d1 < HEADLAND_START_STICKY || d2 < HEADLAND_START_STICKY) {
						if (d1 < d2) {
							_headlandStartIndex = i;
							if (_headlandRotation == Param::Work::Pattern::Rotation::ANTICLOCKWISE) {
								_headlandStartPos = pp;
							} else {
								_headlandStartPos = s.p1;
							}
						} else {
							_headlandStartIndex = PolygonUtil::nextIndex(i, segments->size());
							if (_headlandRotation == Param::Work::Pattern::Rotation::ANTICLOCKWISE) {
								_headlandStartPos = s.p2;
							} else {
								_headlandStartPos = pp;
							}
						}
					} else {
						if (_headlandRotation == Param::Work::Pattern::Rotation::ANTICLOCKWISE) {
							_headlandStartIndex = i;
						} else {
							_headlandStartIndex = PolygonUtil::nextIndex(i, segments->size());
						}
						_headlandStartPos = pp;
					}
				}
			} else {
				// ppが線分s上にない場合
				const double d1 = PolygonUtil::length(uiStart, s.p1);
				if (d1 < dm) {
					dm = d1;
					_headlandStartIndex = i;
					_headlandStartPos = s.p1;
				}
				const double d2 = PolygonUtil::length(uiStart, s.p2);
				if (d2 < dm) {
					dm = d2;
					_headlandStartIndex = PolygonUtil::nextIndex(i, segments->size());
					_headlandStartPos = s.p2;
				}
			}
		}
	} else if (_headlandWorking == Param::Work::Headland::Process::POST && uiEndAvailable) {
		// 外周作業が後の場合
		// uiEndから一番近い_headlandWorkingHP上の点p
		const PolygonUtil::Segments_ segments = PolygonUtil::createSegments(_headlandWorkingHP);
		double dm = 1000000;
		for (int i = 0; i < segments->size(); ++i) {
			const PolygonUtil::Segment &s = segments->at(i);
			Point2D pp = PolygonUtil::perpendicularPoint(uiEnd, s);
			if (s.contains(pp)) {
				// ppが線分s上にある場合
				const double d = PolygonUtil::length(uiEnd, pp);
				if (d < dm) {
					dm = d;
					if (_headlandRotation == Param::Work::Pattern::Rotation::ANTICLOCKWISE) {
						_headlandStartIndex = i;
						_headlandStartPos = s.p1;
					} else {
						_headlandStartIndex = PolygonUtil::nextIndex(i, segments->size());
						_headlandStartPos = s.p2;
					}
					_headlandEndPos = pp;
				}
			} else {
				// ppが線分s上にない場合
				const double d1 = PolygonUtil::length(uiEnd, s.p1);
				if (d1 < dm) {
					dm = d1;
					_headlandStartIndex = i;
					_headlandStartPos = s.p1;
					_headlandEndPos = s.p1;
				}
				const double d2 = PolygonUtil::length(uiEnd, s.p2);
				if (d2 < dm) {
					dm = d2;
					_headlandStartIndex = PolygonUtil::nextIndex(i, segments->size());
					_headlandStartPos = s.p2;
					_headlandEndPos = s.p2;
				}
			}
		}
	}
	// 自動運転の開始位置
	// uiStartから一番近い_startEndPolygons上の点、およびdriveStartから一番近いグラフ上の頂点インデックス
	defineStartEndPoint_getNearest(uiStart, _workingAreas->at(0), _startEndPolygons->at(0), driveStart, &driveStartIndex);

	int innerDriveStartIndex = driveStartIndex;
	Point2D innerDriveStart = driveStart;
	if (_headlandWorking == Param::Work::Headland::Process::PRE) {
		// 外周作業が先の場合、内側作業は、作業方向に設定した辺の近くから作業開始する
		const double dpx = (_dp1.x + _dp2.x) * 0.5;
		if (!retry && dpx > (_workingAreasMin.x + _workingAreasMax.x) * 0.5) {
			// 作業方向に設定した辺(の中点)がHPの中央よりも右側の場合、作業進捗方向が逆向きなのでリトライ (ただし、既にリトライ中の場合は無視)
			return false;
		}
		defineStartEndPoint_getNearest(_headlandWorkingHP->at(_headlandStartIndex), _workingAreas->at(0), _startEndPolygons->at(0), innerDriveStart, &innerDriveStartIndex);
	}

	// それぞれの候補点までのグラフ上の道のり距離を求める
	double d1 = distanceOnGraph(innerDriveStartIndex, p1Index);
	double d2 = distanceOnGraph(innerDriveStartIndex, p2Index);
	double d3 = distanceOnGraph(innerDriveStartIndex, p3Index);
	double d4 = distanceOnGraph(innerDriveStartIndex, p4Index);
	if (_workPatternVortex) {
		// 内側作業が外内
		if (_clockwiseVortex) {
			// 時計回りの場合、左上(p2)と右下(p3)は候補にならない
			d2 = 1000000.0;
			d3 = 1000000.0;
			// スタートナビゲーションは周回方向を気にしなくて良くなった
			if (false) {
				// 時計回りに回って近い方を判定
				PolygonUtil::Segments_ segments = PolygonUtil::createSegments(_workingAreas->at(0));
				const int SZ = segments->size();
				int idxS, idx1, idx4;
				double posS, pos1, pos4;
				PolygonUtil::getIndexPos(segments, innerDriveStart, &idxS, &posS);
				PolygonUtil::getIndexPos(segments, p1, &idx1, &pos1);
				PolygonUtil::getIndexPos(segments, p4, &idx4, &pos4);
				double clockwiseD1 = 0;
				if (idx1 == idxS && pos1 > posS) {
					clockwiseD1 = segments->at(idxS).length() * (pos1 - posS);
				} else {
					clockwiseD1 = segments->at(idxS).length() * (1 - posS);
					for (int i = PolygonUtil::nextIndex(idxS, SZ); i != idx1; i = PolygonUtil::nextIndex(i, SZ)) {
						clockwiseD1 += segments->at(i).length();
					}
					clockwiseD1 += segments->at(idx1).length() * pos1;
				}
				double clockwiseD4 = 0;
				if (idx4 == idxS && pos4 > posS) {
					clockwiseD4 = segments->at(idxS).length() * (pos4 - posS);
				} else {
					clockwiseD4 = segments->at(idxS).length() * (1 - posS);
					for (int i = PolygonUtil::nextIndex(idxS, SZ); i != idx4; i = PolygonUtil::nextIndex(i, SZ)) {
						clockwiseD4 += segments->at(i).length();
					}
					clockwiseD4 += segments->at(idx4).length() * pos4;
				}
				d1 = clockwiseD1;
				d4 = clockwiseD4;
			}
		} else {
			// 反時計回りの場合、左下(p1)と右上(p4)は候補にならない
			d1 = 1000000.0;
			d4 = 1000000.0;
			// スタートナビゲーションは周回方向を気にしなくて良くなった
			if (false) {
				// 反時計回りに回って近い方を判定
				PolygonUtil::Segments_ segments = PolygonUtil::createSegments(_workingAreas->at(0));
				const int SZ = segments->size();
				int idxS, idx2, idx3;
				double posS, pos2, pos3;
				PolygonUtil::getIndexPos(segments, innerDriveStart, &idxS, &posS);
				PolygonUtil::getIndexPos(segments, p2, &idx2, &pos2);
				PolygonUtil::getIndexPos(segments, p3, &idx3, &pos3);
				double clockwiseD2 = 0;
				if (idx2 == idxS && pos2 > posS) {
					clockwiseD2 = segments->at(idxS).length() * (pos2 - posS);
				} else {
					clockwiseD2 = segments->at(idxS).length() * (1 - posS);
					for (int i = PolygonUtil::nextIndex(idxS, SZ); i != idx2; i = PolygonUtil::nextIndex(i, SZ)) {
						clockwiseD2 += segments->at(i).length();
					}
					clockwiseD2 += segments->at(idx2).length() * pos2;
				}
				double clockwiseD3 = 0;
				if (idx3 == idxS && pos3 > posS) {
					clockwiseD3 = segments->at(idxS).length() * (pos3 - posS);
				} else {
					clockwiseD3 = segments->at(idxS).length() * (1 - posS);
					for (int i = PolygonUtil::nextIndex(idxS, SZ); i != idx3; i = PolygonUtil::nextIndex(i, SZ)) {
						clockwiseD3 += segments->at(i).length();
					}
					clockwiseD3 += segments->at(idx3).length() * pos3;
				}
				// 時計回りに回った場合の距離を全周から引く
				double dAll = 0;
				for (int i = 0; i < SZ; ++i) {
					dAll += segments->at(i).length();
				}
				d2 = dAll - clockwiseD2;
				d3 = dAll - clockwiseD3;
			}
		}
	}
	if (_headlandWorking == Param::Work::Headland::Process::PRE) {
		// 外周作業が先の場合、内側作業は、作業方向に設定した辺の近くから作業開始する (その2)
		// 作業進捗方向の判定は既に終わっている
		d3 = 1000000.0;
		d4 = 1000000.0;
	}
	// 一番距離の短い候補点が作業開始位置
	// d3/d4側に下駄を履かせて比較する
	double d = 0;
	if (min(d1, d2) < min(d3, d4) + pathInterval || retry) {
		// d1/d2の方が近ければ、近い方を作業開始位置に設定して処理継続
		// d3/d4の方が近い場合でも、リトライ時は、あきらめてd1/d2の近い方を設定して処理継続
		// (作業方向を反転させてリトライしたはずなのに、それでもダメな場合があるため)
		if (d1 < d2) {
			workStartIndex = p1Index;
			d = PolygonUtil::length(uiStart, p1);
			if (_firstLineDir == -1) {
				if (!retry) {
					return false;
				}
				workStartIndex = p2Index;
				d = PolygonUtil::length(uiStart, p2);
			}
		} else {
			workStartIndex = p2Index;
			d = PolygonUtil::length(uiStart, p2);
			if (_firstLineDir == 1) {
				if (!retry) {
					return false;
				}
				workStartIndex = p1Index;
				d = PolygonUtil::length(uiStart, p1);
			}
		}
	} else {
		// 作業進捗方向が逆向き、最初からやり直す
		return false;
	}
	// 距離のチェック
	if (d < MINSTARTNAV) {
		// 距離が近い場合の自動運転開始位置は作業開始位置を1mバックさせた位置
        // TODO: これはPathGeneratorに任せるようにする
		innerDriveStartIndex = -1;
	}
	// 自動運転の終了位置
	if (uiEndAvailable) {
		// uiEndから一番近い_startEndPolygons上の点、およびdriveEndから一番近いグラフ上の頂点インデックス
		defineStartEndPoint_getNearest(uiEnd, _workingAreas->at(0), _startEndPolygons->at(0), driveEnd, &driveEndIndex);
	} else {
		driveEndIndex = -1;
	}
	return true;
}

bool FieldPolygon::onWorkingAreasEdge(const Point2D &p0)
{
	PolygonUtil::Segments_ workingAreasEdge = PolygonUtil::createSegments(_workingAreas->at(0));
	for (int i = 0; i < workingAreasEdge->size(); ++i) {
		PolygonUtil::Segment s = workingAreasEdge->at(i);
		Point2D p1 = PolygonUtil::perpendicularPoint(p0, s);
		if (s.contains(p1) && PolygonUtil::length(p0, p1) < TOLERANCE) {
			return true;
		}
	}
	return false;
}

void FieldPolygon::defineStartEndPoint_getNearest(const Point2D &p, const Polygon_ &polygon1, const Polygon_ &polygon2, Point2D &outP, int *index) {
	// pから一番近いpolygon1上の点
	Point2D pw;
	Point2D pwp1;
	Point2D pwp2;
	PolygonUtil::Segments_ segments1 = PolygonUtil::createSegments(polygon1);
	double d1 = 1000000.0;
	for (int i = 0; i < segments1->size(); ++i) {
		const PolygonUtil::Segment &s = segments1->at(i);
		Point2D tmpP = PolygonUtil::perpendicularPoint(p, s);
		double tmpD;
		if (s.contains(tmpP)) {
			// tmpPが線分s上にある場合
			tmpD = PolygonUtil::length(p, tmpP);
		} else {
			// tmpPが線分s上にない場合
			double tmpD1 = PolygonUtil::length(p, s.p1);
			double tmpD2 = PolygonUtil::length(p, s.p2);
			if (tmpD1 < tmpD2) {
				// 線分sの始点の方が点pに近い場合
				tmpD = tmpD1;
				tmpP = s.p1;
			} else {
				// 線分sの終点の方が点pに近い場合
				tmpD = tmpD2;
				tmpP = s.p2;
			}
		}
		if (i == 0 || tmpD < d1) {
			d1 = tmpD;
			pw = tmpP;
			pwp1 = s.p1;
			pwp2 = s.p2;
		}
	}

	// グラフ上のノードで、線分(pwp1, pwp2)上、かつpwから一番近い点
	*index = -1;
	PolygonUtil::Segment segment = PolygonUtil::Segment(pwp1, pwp2);
	double d = 1000000.0;
	for (int i = 0; i < NavFieldVertex.size(); ++i) {
		Point2D tmpP = NavFieldVertex[i];
		if (!segment.contains(tmpP)) continue;
		if (PolygonUtil::perpendicularLength(tmpP, segment) > TOLERANCE_2) continue;
		double tmpD = PolygonUtil::length(pw, tmpP);
		if (tmpD < d) {
			d = tmpD;
			*index = i;
		}
	}
	if (*index < 0) throw runtime_error(ErrorCode::FATAL);

	// 凹頂点の有無によって処理を分岐
	bool concave = false;
	std::vector<double> angles = PolygonUtil::getSegmentAngles(polygon1);
	for (int i = 0; i < angles.size(); ++i) {
		double angle1 = angles[i];
		double angle2 = angles[PolygonUtil::nextIndex(i, angles.size())];
		if (PolygonUtil::normalizeRadian(angle2 - angle1) > 0) {
			// 凹頂点がある
			concave = true;
			break;
		}
	}
	if (concave) {
		// 凹頂点がある場合
		// polygon2と(p, pw)の交点
		std::vector<Point2D> crossPoints;
		PolygonUtil::getCrossPoints(polygon2, p, pw, &crossPoints);
		if (crossPoints.size() > 0) {
			// 交点が複数ある場合、pwに近い点を採用
			double d = 0.0;
			for (int i = 0; i < crossPoints.size(); ++i) {
				const Point2D &tmpP = crossPoints[i];
				double tmpD = PolygonUtil::length(pw, tmpP);
				if (i == 0 || tmpD < d) {
					d = tmpD;
					outP = tmpP;
				}
			}
			return;
		}
		// 交点がない場合 (想定外だけどスルー)
	}
	// 凹頂点がない場合
	PolygonUtil::Segments_ segments2 = PolygonUtil::createSegments(polygon2);
	double d2 = 1000000.0;
	// pから一番近いpolygon2上の任意の点
	for (int i = 0; i < segments2->size(); ++i) {
		const PolygonUtil::Segment &s = segments2->at(i);
		Point2D tmpP = PolygonUtil::perpendicularPoint(p, s);
		double tmpD;
		if (s.contains(tmpP)) {
			// tmpPが線分s上にある場合
			tmpD = PolygonUtil::length(p, tmpP);
		} else {
			// tmpPが線分s上にない場合
			double tmpD1 = PolygonUtil::length(p, s.p1);
			double tmpD2 = PolygonUtil::length(p, s.p2);
			if (tmpD1 < tmpD2) {
				// 線分sの始点の方が点pに近い場合
				tmpD = tmpD1;
				tmpP = s.p1;
			} else {
				// 線分sの終点の方が点pに近い場合
				tmpD = tmpD2;
				tmpP = s.p2;
			}
		}
		if (i == 0 || tmpD < d2) {
			d2 = tmpD;
			outP = tmpP;
		}
	}
}

double FieldPolygon::distanceOnGraph(int s, int e)
{
	// グラフを探索
	list<int> path;
	vector<int> dist;
	vector<int> pred;
	gh.SingleSourceShortestBF(s, dist, pred);
	gh.ConstructShortestPath(s, e, pred, path);
	// 距離を算出
	double d = 0;
	int i1;
	int i2;
	auto itr = path.begin();
	i1 = *itr;
	++itr;
	while (itr != path.end()) {
		i2 = *itr;
		d += PolygonUtil::length(NavFieldVertex[i1], NavFieldVertex[i2]);
		i1 = i2;
		++itr;
	}
	return d;
}

/**
 * 目的不明
 * 作業領域と非作業領域の単方向グラフを生成します。
 * 作業領域は順方向j->k
 * 非作業領域は逆方向k->j
 */
void FieldPolygon::createGraphDirected() {
	int size = 0;
	for (int i = 0; i < _workingAreas->size(); ++i) {
		Polygon_ workingArea = _workingAreas->at(i);
		for (int j = 0; j < workingArea->size(); ++j) {
			int k = j + 1 < workingArea->size() ? j + 1 : 0;
			g.AddEdge(size + j, size + k, Graph::SINGLE);
		}
		size += workingArea->size();
	}
	for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
		Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
		for (int j = 0; j < nonWorkingArea->size(); ++j) {
			int k = j + 1 < nonWorkingArea->size() ? j + 1 : 0;
			g.AddEdge(size + k, size + j, Graph::SINGLE);
		}
		size += nonWorkingArea->size();
	}
	
	assert(g.NumVertices() == size);
}


/*
 DetachGraph():
 ***********************
 his function DetachGraph detaches the detachable areas from the field.
 This function only operates over the Original graph data vertices
 (new vertices might have been inserted during CreateGraph() process.
 This function doesn't touches polygon/field data structure.It makes use of
 the DOUBLE and SINGLE edges weights inserted in the adjacency list of Graph
 data structure. It just looks for SINGLE edges in the original graph
 to calculate the path.The premise behind this is original SINGLE edges
 have a connectivity all over the graph.This process doesn't delete the
 vertices which are left hanging without any connection after some time but
 doesn't process them as for those cases IsEdge() should fail
 @param: None
 @return: void
 */
void FieldPolygon::detachGraph() {

	Graph g1 = g;

	// 障害物の周りをぐるぐる回ってしまうのを避けるため？
	// 障害物のエッジは2
	// 逆向きのエッジ
	std::vector<Edge> obstaclesEdges;
	int size = noBoundayVertices;
	for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
		Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
		for (int j = 0; j < nonWorkingArea->size(); ++j) {
			int k = j + 1 < nonWorkingArea->size() ? j + 1 : 0;
			obstaclesEdges.push_back(make_pair(size + k, size + j));
		}
		size += nonWorkingArea->size();
	}

	//　作業領域+非作業領域の頂点でループ
	for (int i = 0; i < FieldVertex.size() - 1; ++i) {

		// 作業領域と非作業領域のグラフのループ
		int j = 0;
		for (auto ci = g.begin(i); ci != g.end(i); ++ci) {
			j = ci->first;
			if (g.IsEdge(i, j) && ci->second != Graph::DOUBLE) {
				// gは単方向なので、ある頂点iから、別の頂点jに向かう辺が1個見つかるはず
				break;
			}
		}

		/*
		 It might happen that the last edge in the graph is a
		 Original vertex double edge. in that case
		 the break statement in the above loop cant help from
		 DOUBLE edge to come to this point.In this case don't send
		 the double edge for shortest path calculation,since it
		 might happen that the shortest path is calculated from
		 the adjacent edge and only one edge will be calculated
		 as a shortest path.Let this DOUBLE edge pass.Wait for the another
		 original vertex to calculate the shortest path.
		 */

		if (g.EdgeType(i, j) != Graph::DOUBLE) {

			// iからjに向かうシングルエッジを削除
			Graph::IntegerPair a1(j, 1);
			g.vertices[i].remove(a1);

			// iからjに向かう最短パスを計算
			vector<vector<int> > dist(g.NumVertices());
			vector<vector<int> > pred(g.NumVertices());
			AllPairShortest(dist, pred, obstaclesEdges);
			list<int> path;
			ConstructShortestPath(j, i, pred, path);

			// ベクターに入れ直す
			std::vector<int> myvec;
			for (list<int>::iterator it = path.begin(); it != path.end(); ++it) {
				myvec.push_back(*it);
			}

			OutQueue myQueue;
			/*
			 Calculate the edge path and remove those edges.
			 Remove the SINGLE edges completely
			 and convert DOUBLE edges to SINGLE edges
			 */
			int size = (int) myvec.size() - 1;
			for (int k = 0; k < size; k++) {
				int u1 = myvec[k];
				int v1 = myvec[k + 1];
				g.RemoveEdge(u1, v1);

				OutPair a0(u1, v1);
				myQueue.push_back(a0);
			}

			/* add last edge (end to start vertex) */
			if (myvec.size() > 1) {
				OutPair a0(myvec[size], myvec[0]);
				myQueue.push_back(a0);
				/*
				 Here is precisely when g1(which has a copy
				 constructor) is required.The graph g disintegrates as
				 edges are removed from it but we need the information
				 of double edges in the original graph for merging
				 */
				outPoly.addQueue(myQueue, g1);
			}
		} // end of DOUBLE edge condition
	}
}

void FieldPolygon::AllPairShortest(vector<vector<int> > &dist, vector<vector<int> > &pred, vector<Edge> &obstaclesEdges)
{
	// 作業領域+非作業領域の頂点数
	int num = g.NumVertices();

	// 頂点のインデックスでループ
	for (int i = 0; i < num; ++i) {
		dist[i].assign(num, 9999);
		dist[i][i] = 0;
		pred[i].assign(num, -1);

		// インデックスiの頂点と接続している辺をループ
		// gが単方向なので、このループは1回しか回らないと思う
		for (auto edge = g.begin(i); edge != g.end(i); ++edge) {
			// iに接続している頂点のインデックス
			int j = edge->first;

			// distはdistance？隣だから1？
			dist[i][j] = 1;

			// 障害物のエッジ(逆向き)のループ
			for (int k = 0; k < obstaclesEdges.size(); ++k) {
				if (obstaclesEdges[k].first == i && obstaclesEdges[k].second == j) {
					// 障害物周りのエッジの場合、1じゃなくて2
					dist[i][j] = 2;
				}
			}

			pred[i][j] = i;
		}
	}
	// 自分自身は距離0、隣(1方向しか見ないけど)は距離1、ただし障害物の場合は2

	// 頂点のインデックスで3重ループ
	for (int i = 0; i < num; ++i) {
		for (int j = 0; j < num; ++j) {
			if (dist[j][i] == 9999) {
				continue;
			}
			// j->iの距離が9999以外の場合
			// つまり、j=i、またはiがjの隣
			for (int k = 0; k < num; ++k) {
				// jからiを経由してkまでの距離
				int newDist = dist[j][i] + dist[i][k];
				if (newDist < dist[j][k]) {
					dist[j][k] = newDist;
					pred[j][k] = pred[i][k];
				}
			}
		}
	}
}

/*
 This functions computes the shortest path between
 two vertices s and t in a graph
 @param:
 int s : start vertex
 int t : end vertex
 vector<vector<int>> const &pred : array containing pred path
 list<int> &path : returned path
 @return val: void
 */
void FieldPolygon::ConstructShortestPath(int s, int t, vector<vector<int> > const &pred, list<int> &path) {

	path.clear();
	if (t < 0 || t >= (int) pred.size() || s < 0 || s >= (int) pred.size()) {
		return;
	}

	/*construct path*/
	path.push_front(t);
	while (t != s) {
		t = pred[s][t];
		if (t == -1) {
			path.clear();
			return;
		}
		path.push_front(t);
	}
}



/**
 逆変換
 
 座標の向きを元に戻す
 */
void FieldPolygon::transformInverse()
{
	translate.x = -translate.x;
	translate.y = -translate.y;
	rotateAngle = -rotateAngle;
	double sin = std::sin(rotateAngle);
	double cos = std::cos(rotateAngle);
	// 圃場(全体)
	PolygonUtil::translate(_field, translate);
	PolygonUtil::rotate(_field, sin, cos);
	// 障害物
	for (int i = 0; i < _obstacles->size(); ++i) {
		PolygonUtil::translate(_obstacles->at(i), translate);
		PolygonUtil::rotate(_obstacles->at(i), sin, cos);
	}
	// 障害物(バウンディングボックス)
	for (int i = 0; i < _bbObstacles->size(); ++i) {
		PolygonUtil::translate(_bbObstacles->at(i), translate);
		PolygonUtil::rotate(_bbObstacles->at(i), sin, cos);
	}
	// 作業領域
	for (int i = 0; i < _workingAreas->size(); ++i) {
		PolygonUtil::translate(_workingAreas->at(i), translate);
		PolygonUtil::rotate(_workingAreas->at(i), sin, cos);
	}
	// 非作業領域
	for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
		PolygonUtil::translate(_nonWorkingAreas->at(i), translate);
		PolygonUtil::rotate(_nonWorkingAreas->at(i), sin, cos);
	}
	// 外周作業用HP
	PolygonUtil::translate(_headlandWorkingHP, translate);
	PolygonUtil::rotate(_headlandWorkingHP, sin, cos);

	// スタート・ゴール位置を決定するためのポリゴン
	for (int i = 0; i < _startEndPolygons->size(); ++i) {
		PolygonUtil::translate(_startEndPolygons->at(i), translate);
		PolygonUtil::rotate(_startEndPolygons->at(i), sin, cos);
	}
	// 交差判定用ポリゴン
	for (int i = 0; i < _pathEnvelopePolygons->size(); ++i) {
		PolygonUtil::translate(_pathEnvelopePolygons->at(i), translate);
		PolygonUtil::rotate(_pathEnvelopePolygons->at(i), sin, cos);
	}

    // UIで設定したスタート・エンド位置
	PolygonUtil::translatePoint(&uiStart, translate.x, translate.y);
	PolygonUtil::translatePoint(&uiEnd, translate.x, translate.y);
	PolygonUtil::rotatePoint(&uiStart, sin, cos);
	PolygonUtil::rotatePoint(&uiEnd, sin, cos);

	InFieldVertex.clear();
	for (int i = 0; i < _field->size(); ++i) {
		const Point2D &p = _field->at(i);
		InFieldVertex.push_back(p);
	}
	for (int i = 0; i < _obstacles->size(); ++i) {
		Polygon_ obstacle = _obstacles->at(i);
		for (int j = 0; j < obstacle->size(); ++j) {
			const Point2D &p = obstacle->at(j);
			InFieldVertex.push_back(p);
		}
	}
	FieldVertex.clear();
	for (int i = 0; i < _workingAreas->size(); ++i) {
		Polygon_ workingArea = _workingAreas->at(i);
		for (int j = 0; j < workingArea->size(); ++j) {
			const Point2D &p = workingArea->at(j);
			FieldVertex.push_back(p);
		}
	}
	for (int i = 0; i < _nonWorkingAreas->size(); ++i) {
		Polygon_ nonWorkingArea = _nonWorkingAreas->at(i);
		for (int j = 0; j < nonWorkingArea->size(); ++j) {
			const Point2D &p = nonWorkingArea->at(j);
			FieldVertex.push_back(p);
		}
	}

    SHPVertex.clear();
	for (int i = 0; i < _pathEnvelopePolygons->size(); ++i) {
		Polygon_ pathEnvelopePolygon = _pathEnvelopePolygons->at(i);
		SHPVertex.insert(SHPVertex.end(), pathEnvelopePolygon->begin(), pathEnvelopePolygon->end());
	}
}

/**
 * 点が作業領域内か判定します。
 */
bool FieldPolygon::inWorkingAreas(const Point2D &p)
{
	for (int i = 0; i < _workingAreas->size(); ++i) {
		Polygon_ workingArea = _workingAreas->at(i);
		if (PolygonUtil::within(workingArea, p)) {
			return true;
		}
	}
	return false;
}

/**
 * 作業ラインごとの走行方向(上下)をリストで取得します。
 */
void FieldPolygon::getLineUpDown(int lineCount, int skip, vector<int> &updown) {
	updown.clear();
	int d = _firstLineDir;
	if (skip < 1) {
		// スキップ0(隣接)の場合
		for (int i = 0; i < lineCount; ++i) {
			updown.push_back(d);
			d *= -1;
		}
		return;
	}
	const int step = skip + 1;
	// ブロックサイズ
	int blockSize = skip * 2 + 3;
	if (lineCount < blockSize) {
		// 1ブロック分に足りない場合(折り返しが不可能な場合)、1ブロック分のパターンで作れるところまで作る
		updown.push_back(d);
		d *= -1;
		for (int i = 1; i < std::min(step + 1, lineCount); ++i) {
			updown.push_back(d);
		}
		d *= -1;
		for (int i = step + 1; i < lineCount; ++i) {
			updown.push_back(d);
		}
		return;
	}
	// ブロック単位の処理
	if (_progressType == Param::Work::ProgressType::BLOCK) {
		while (lineCount >= blockSize * 2) {
			lineCount -= blockSize;
			updown.push_back(d);
			d *= -1;
			for (int i = 1; i < step + 1; ++i) {
				updown.push_back(d);
			}
			d *= -1;
			for (int i = step + 1; i < step * 2 + 1; ++i) {
				updown.push_back(d);
			}
			d *= -1;
		}
	}
	// 最後のブロックの処理
	// (端数は最後のブロックに含めて処理する)
	// (ブロック単位の処理をしない場合は即ココ)
	if (lineCount > 0) {
		const int s = updown.size();
		for (int i = 0; i < lineCount; ++i) {
			updown.push_back(0);
		}
		updown[s] = d;
		d *= -1;
		for (int i = step; i > 0; --i) {
			for (int j = i; j < lineCount; j += step) {
				updown[s + j] = d;
				d *= -1;
			}
		}
	}
}

// 一番右端の半端部分だけ切り落とす処理
void FieldPolygon::cutoffRightSideEdge1() {
	int numLine = (_workingAreasMax.x - _workingAreasMin.x - _cultivationOverlap) / pathInterval;
	Point2D hpMax = _workingAreasMax;
	Point2D hpMin = _workingAreasMin;
	hpMax.x = _workingAreasMin.x + pathInterval * numLine + _cultivationOverlap - TOLERANCE_2;
	hpMax.y += TOLERANCE_2;
	hpMin.x -= TOLERANCE_2;
	hpMin.y -= TOLERANCE_2;
	if (_workingAreasMax.x - hpMax.x < TOLERANCE_2) {
		// TODO:切り落とす幅が小さい場合、処理をスキップ
	}
	Polygon_ hpBox = PolygonUtil::box2Polygon(hpMin, hpMax);
	Polygon_ hp = Polygon_(new Polygon);
	if (PolygonUtil::intersection(_workingAreas->at(0), hpBox, hp) < 0) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}
	// HPから消えた頂点の個数
	int count = 0;
	for (int i = 0; i < _workingAreas->at(0)->size(); ++i) {
		const Point2D &p = _workingAreas->at(0)->at(i);
		if (p.x > hpMax.x) {
			++count;
		}
	}
	// BPから消す頂点
	std::vector<Point2D> bpSort;
	bpSort.assign(_field->begin(), _field->end());
	std::sort(bpSort.begin(), bpSort.end(), [](Point2D p1, Point2D p2) -> int { return (p1.x > p2.x); });
	double limit = bpSort[count - 1].x - TOLERANCE_2;
	Point2D bpMin;
	Point2D bpMax;
	PolygonUtil::boundingBox(_field, &bpMin, &bpMax);
	bpMax.x -= (_workingAreasMax.x - hpMax.x);
	bpMax.x = std::min(bpMax.x, limit);
	bpMax.y += TOLERANCE_2;
	bpMin.x -= TOLERANCE_2;
	bpMin.y -= TOLERANCE_2;
	// HPから逆算したライン
	std::vector<double> angles;
	angles.push_back(M_PI_2);
	PolygonUtil::Angles2Widths angles2Widths = getAngles2Widths();
	std::vector<double> widths = angles2Widths(angles);
	if (bpMax.x < _workingAreasMax.x + widths[0]) {
		// TODO:必要なサイドマージンが確保出来ない
	}
	Polygon_ bpBox = PolygonUtil::box2Polygon(bpMin, bpMax);
	Polygon_ bp = Polygon_(new Polygon);
	if (PolygonUtil::intersection(_field, bpBox, bp) < 0) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}
	_field->swap(*bp);
	_workingAreas->at(0)->swap(*hp);
	PolygonUtil::boundingBox(_workingAreas, &_workingAreasMin, &_workingAreasMax);
	const double pathEnvelopeMargin = _safetyMargin + _maxWidth * 0.5 - 0.01;
	_pathEnvelopePolygons = Polygons_(new Polygons);
	Polygon_ tmpField = Polygon_(new Polygon);
	tmpField->assign(_field->begin(), _field->end());
	if (PolygonUtil::thin5_intersection(tmpField, _pathEnvelopePolygons, pathEnvelopeMargin) < 0) {
		throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
	}
}

void FieldPolygon::cutoffHeadlandWorkingHP() {
	PolygonUtil::simplify2(_headlandWorkingHP);
	// 短冊切り領域リストの生成
	Polygons_ fractions = Polygons_(new Polygons);
	for (double posX = _workingAreasMin.x; posX < _workingAreasMax.x; posX += pathInterval) {
		// 短冊切り矩形
		Point2D min = Point2D(posX                      - TOLERANCE, _workingAreasMin.y - TOLERANCE_2);
		Point2D max = Point2D(posX + _cultivationWidth1 + TOLERANCE, _workingAreasMax.y + TOLERANCE_2);
		Polygon_ box = PolygonUtil::box2Polygon(min, max);
		// 短冊切り
		Polygons_ results = Polygons_(new Polygons);
		if (PolygonUtil::intersection(_headlandWorkingHP, box, results) < 0) {
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		if (results->size() == 0) {
			// boost::geometryの計算精度が悪いせいで、明らかに交差しているポリゴン同士のintersectionで結果が返ってこないことがあるため、自前の処理で回避
			std::vector<Point2D> crossPoints;
			PolygonUtil::getCrossPoints(_headlandWorkingHP, box, &crossPoints);
			if (crossPoints.size() == 2) {
				// 交点が2個の場合だけ対応する
				const size_t SIZE = _headlandWorkingHP->size();
				const PolygonUtil::Segments_ segments = PolygonUtil::createSegments(_headlandWorkingHP);
				int index0 = -1;
				double d0 = 1;
				for (int i = 0; i < SIZE; ++i) {
					const PolygonUtil::Segment &s = segments->at(i);
					double tmp = PolygonUtil::perpendicularLength(crossPoints[0], s);
					if (tmp < d0) {
						d0 = tmp;
						index0 = i;
					}
				}
				int index1 = -1;
				double d1 = 1;
				for (int i = 0; i < SIZE; ++i) {
					const PolygonUtil::Segment &s = segments->at(i);
					double tmp = PolygonUtil::perpendicularLength(crossPoints[1], s);
					if (tmp < d1) {
						d1 = tmp;
						index1 = i;
					}
				}
				if (index0 != -1 && index1 != -1 && index0 != index1 && d0 < TOLERANCE && d1 < TOLERANCE) {
					// ポリゴンを分割できるラインが確定
					Polygon_ p01 = Polygon_(new Polygon);
					p01->push_back(crossPoints[0]);
					for (int i = PolygonUtil::nextIndex(index0, SIZE); i != PolygonUtil::nextIndex(index1, SIZE); i = PolygonUtil::nextIndex(i, SIZE)) {
						p01->push_back(_headlandWorkingHP->at(i));
					}
					p01->push_back(crossPoints[1]);
					Polygon_ p10 = Polygon_(new Polygon);
					p10->push_back(crossPoints[1]);
					for (int i = PolygonUtil::nextIndex(index1, SIZE); i != PolygonUtil::nextIndex(index0, SIZE); i = PolygonUtil::nextIndex(i, SIZE)) {
						p10->push_back(_headlandWorkingHP->at(i));
					}
					p10->push_back(crossPoints[0]);
					// 小さい方のポリゴンを採用
					if (PolygonUtil::area(p01) < PolygonUtil::area(p10)) {
						if (PolygonUtil::checkPolygon(p01) == 0) results->push_back(p01);
					} else {
						if (PolygonUtil::checkPolygon(p10) == 0) results->push_back(p10);
					}
				}
			}
		}
		for (int i = 0; i < results->size(); ++i) {
			fractions->push_back(results->at(i));
		}
	}
	// 仕分け.作業パスで塗り潰される領域
	Polygons_ fractionsOK = Polygons_(new Polygons);
	cutoffHeadlandWorkingHP_pickup(_workingSegments, fractions, fractionsOK);
	// (fractionsに残っているのが、作業パスが除外された/生成されなかった領域)
	// _headlandWorkingHPと短冊切りのミシン目に対してスティッキーになるように調整
	for (int i = 0; i < fractions->size(); ++i) {
		Polygon_ &fraction = fractions->at(i);
		cutoffHeadlandWorkingHP_sticky(_headlandWorkingHP, fraction);
	}
	// 再結合.隣接するfractions同士の再結合
	while (true) {
		const int count = fractions->size();
		cutoffHeadlandWorkingHP_reunion(fractions);
		if (fractions->size() == count) {
			// 再結合完了
			break;
		}
		// 再結合が実行された場合、スティッキー処理も再実行
		for (int i = 0; i < fractions->size(); ++i) {
			Polygon_ &fraction = fractions->at(i);
			cutoffHeadlandWorkingHP_sticky(_headlandWorkingHP, fraction);
		}
	}
	// 切り捨て処理1.
	Polygons_ fractions_tmp = Polygons_(new Polygons);
	for (int i = 0; i < fractions->size(); ++i) {
		const Polygon_ &fraction = fractions->at(i);
		if (fraction->size() == 4) {
			// ポリゴンに凹角がないかチェックします
			if (cutoffHeadlandWorkingHP_checkConcave(fraction)) {
				// 凹角がある場合はエラー
				throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
			}
			// 切断面が2個ないかチェックする (切断面が2個ある場合、外周作業用HPが分断されるのでエラー)
			Polygon_ tmp = Polygon_(new Polygon);
			Polygons_ tmps = Polygons_(new Polygons);
			tmp->assign(_headlandWorkingHP->begin(), _headlandWorkingHP->end());
			tmps->push_back(fraction);
			cutoffHeadlandWorkingHP_subtract(tmp, tmps);
			// 4角形の場合、切断面の対辺を平行移動して切り捨て
			cutoffHeadlandWorkingHP_shiftEdge4(_headlandWorkingHP, fraction);
		} else {
			fractions_tmp->push_back(fraction);
		}
	}
	fractions->swap(*fractions_tmp);
	// 切り捨て処理2.
	fractions_tmp->clear();
	for (int i = 0; i < fractions->size(); ++i) {
		const Polygon_ &fraction = fractions->at(i);
		if (fraction->size() == 3) {
			// 3角形の場合、切断面を除いた2辺の内、面積の損失が小さくなる方を平行移動して切り捨て
			cutoffHeadlandWorkingHP_shiftEdge3(_headlandWorkingHP, fraction);
		} else {
			fractions_tmp->push_back(fraction);
		}
	}
	fractions->swap(*fractions_tmp);
	// 切り捨て処理3.
	// 5角形以上の場合、そのまま切り捨て (_headlandWorkingHPからfractionsを減算処理)
	cutoffHeadlandWorkingHP_subtract(_headlandWorkingHP, fractions);
}
// segmentsで塗り潰される(はずだった)短冊切り領域をsrcからpickupに抽出する
void FieldPolygon::cutoffHeadlandWorkingHP_pickup(const Segments_ &segments, Polygons_ &src, Polygons_ &pickup) {
	for (int i = 0; i < segments->size(); ++i) {
		const Segment &s = segments->at(i);
		Polygons_ tmp = Polygons_(new Polygons);
		for (int j = 0; j < src->size(); ++j) {
			const Polygon_ &p = src->at(j);
			Point2D min;
			Point2D max;
			PolygonUtil::boundingBox(p, &min, &max);
			if (s.p2.x < min.x || max.x < s.p1.x || s.p2.y < min.y || max.y < s.p1.y) {
				// pとsは無関係
				tmp->push_back(p);
			} else {
				// pはsで塗り潰される(はずだった)領域
				pickup->push_back(p);
			}
		}
		src->swap(*tmp);
	}
}
// 隣接する短冊切り領域同士を再結合する
void FieldPolygon::cutoffHeadlandWorkingHP_reunion(Polygons_ &polygons) {
	bool united = true;
	while (united) {
		united = false;
		for (int i = 0; i < polygons->size(); ++i) {
			const Polygon_ &p1 = polygons->at(i);
			Point2D min1;
			Point2D max1;
			PolygonUtil::boundingBox(p1, &min1, &max1);
			for (int j = i + 1; j < polygons->size(); ++j) {
				const Polygon_ &p2 = polygons->at(j);
				Point2D min2;
				Point2D max2;
				PolygonUtil::boundingBox(p2, &min2, &max2);
				if (max1.x + TOLERANCE < min2.x || max2.x + TOLERANCE < min1.x || max1.y + TOLERANCE < min2.y || max2.y + TOLERANCE < min1.y) {
					// バウンディングボックスが離れている
					continue;
				}
				Polygons_ results = Polygons_(new Polygons);
				if (PolygonUtil::union_(p1, p2, results) < 0) {
					continue;
				}
				if (results->size() != 1) {
					// バウンディングボックスが隣接していても、再結合されない場合があり得る
					continue;
				}
				// 再結合できた場合
				// 継ぎ接ぎを消す
				PolygonUtil::simplify2(results->at(0));
				// p1(i)とp2(j)を削除(スキップ)して、iの位置に再結合した領域を挿入する
				Polygons_ tmp = Polygons_(new Polygons);
				for (int k = 0; k < polygons->size(); ++k) {
					if (k == i) tmp->push_back(results->at(0));
					if (k == i || k == j) continue;
					tmp->push_back(polygons->at(k));
				}
				polygons->swap(*tmp);
				// polygonsを更新したので再結合処理を頭からやり直し
				united = true;
				break;
			}
			if (united) break;
		}
	}
}
// ミシン目で接する2個のポリゴンを再結合する自前の処理 (動作確認したけど結局未使用)
bool FieldPolygon::cutoffHeadlandWorkingHP_reunion2(const Polygon_ &p1, const Polygon_ &p2, Polygons_ &results) {
	std::vector<int> indexes1;
	std::vector<int> indexes2;
	for (int i = 0; i < p1->size(); ++i) {
		Point2D p1i = p1->at(i);
		for (int j = 0; j < p2->size(); ++j) {
			Point2D p2j = p2->at(j);
			if (p1i == p2j) {
				indexes1.push_back(i);
				indexes2.push_back(j);
			}
		}
	}
	if (indexes1.size() != 2 || indexes2.size() != 2) {
		return false;
	}
	if (indexes1[0] == indexes1[1] || indexes2[0] == indexes2[1]) {
		return false;
	}
	// p1とp2で、共通する頂点が2組ある場合、片方は順方向で、もう片方は逆方向
	if (PolygonUtil::nextIndex(indexes1[0], p1->size()) != indexes1[1]) {
		// indexes1が順方向でない場合、入れ替える
		int tmp1 = indexes1[0];
		indexes1[0] = indexes1[1];
		indexes1[1] = tmp1;
		int tmp2 = indexes2[0];
		indexes2[0] = indexes2[1];
		indexes2[1] = tmp2;
	}
	// indexes1が順方向で、indexes2が逆方向になっているはず
	if (PolygonUtil::nextIndex(indexes1[0], p1->size()) != indexes1[1] || PolygonUtil::nextIndex(indexes2[1], p2->size()) != indexes2[0]) {
		return false;
	}
	Polygon_ result = Polygon_(new Polygon);
	for (int i = indexes1[1]; i < indexes1[0]; i = PolygonUtil::nextIndex(i, p1->size())) {
		result->push_back(p1->at(i));
	}
	for (int i = indexes2[0]; i < indexes2[1]; i = PolygonUtil::nextIndex(i, p2->size())) {
		result->push_back(p2->at(i));
	}
	if (PolygonUtil::checkPolygon(result) < 0) {
		return false;
	}
	results->clear();
	results->push_back(result);
	return true;
}
// orgに対してスティッキーになるように調整する
void FieldPolygon::cutoffHeadlandWorkingHP_sticky(const Polygon_ &org, Polygon_ &part) {
	// boost/geometryの計算精度が粗いため、ココだけ許容誤差を大きく設定する
	const double TOLERANCE_STICKY = 0.1;
	const PolygonUtil::Segments_ segments = PolygonUtil::createSegments(org);
	for (int i = 0; i < part->size(); ++i) {
		Point2D &p = part->at(i);
		// 近くに頂点がある場合、頂点に張り付く
		bool mod = false;
		for (int j = 0; j < org->size(); ++j) {
			const Point2D &p0 = org->at(j);
			if (fabs(p.x - p0.x) < TOLERANCE_2 && fabs(p.y - p0.y) < TOLERANCE_2) {
				p = p0;
				mod = true;
				break;
			}
		}
		if (mod) continue;
		// 近くに頂点がない場合、ミシン目と辺の交点に張り付く
		double d = 1000000;
		double x;
		for (double posX = _workingAreasMin.x; posX < _workingAreasMax.x; posX += pathInterval) {
			const double tmp1 = fabs(p.x - posX);
			if (tmp1 < d) {
				d = tmp1;
				x = posX;
			}
			const double tmp2 = fabs(p.x - posX - _cultivationWidth1);
			if (tmp2 < d) {
				d = tmp2;
				x = posX + _cultivationWidth1;
			}
		}
		if (d > TOLERANCE_STICKY) {
			// 計算誤差が想定以上
			throw runtime_error(ErrorCode::FATAL);
		}
		int index = -1;
		d = TOLERANCE_STICKY;
		for (int j = 0; j < segments->size(); ++j) {
			const PolygonUtil::Segment &s = segments->at(j);
			const Point2D pp = PolygonUtil::perpendicularPoint(p, s);
			const double tmp = PolygonUtil::length(p, pp);
			if (tmp < d && s.contains(pp)) {
				d = tmp;
				index = j;
			}
		}
		if (index < 0) {
			// 計算誤差が想定以上
			throw runtime_error(ErrorCode::FATAL);
		}
		PolygonUtil::Segment sx = PolygonUtil::Segment(Point2D(x, _workingAreasMin.y - TOLERANCE_2), Point2D(x, _workingAreasMax.y + TOLERANCE_2));
		Point2D cp;
		if (PolygonUtil::crossPoint(sx, segments->at(index), &cp) != 0) {
			// ミシン目と平行な辺があるのに頂点に張り付いてない
			throw runtime_error(ErrorCode::FATAL);
		}
		if (PolygonUtil::length(p, cp) > TOLERANCE_STICKY) {
			// 計算誤差が想定以上
			throw runtime_error(ErrorCode::FATAL);
		}
		p = cp;
		p.x = x;
	}
	PolygonUtil::simplify2(part);
}
void FieldPolygon::cutoffHeadlandWorkingHP_subtract(Polygon_ &src, const Polygons_ &polygons) {
	for (int i = 0; i < polygons->size(); ++i) {
		const Polygon_ &p = polygons->at(i);
		Polygons_ tmps = Polygons_(new Polygons);
		if (PolygonUtil::difference(src, p, tmps) < 0) {
			throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		}
		if (tmps->size() == 1) {
			src->swap(*tmps->at(0));
		} else if (tmps->size() == 0) {
			// 外周作業用HPが消滅した場合はエラー
			throw runtime_error(ErrorCode::WorkingArea::SIZE);
		} else {
			// 外周作業用HPが分断された場合はエラー
			throw runtime_error(ErrorCode::WorkingArea::DIVIDED);
		}
	}
}
// 3角形の場合、切断面を除いた2辺の内、面積の損失が小さくなる方を平行移動して切り捨て
void FieldPolygon::cutoffHeadlandWorkingHP_shiftEdge3(Polygon_ &src, const Polygon_ &fraction) {
	Point2D min;
	Point2D max;
	PolygonUtil::boundingBox(fraction, &min, &max);
	int count = 0;
	int index = -1;
	bool find = false;
	for (double posX = _workingAreasMin.x; posX < _workingAreasMax.x; posX += pathInterval) {
		const double x1 = posX;
		const double x2 = posX + _cultivationWidth1;
		if (x2 < min.x - TOLERANCE_2) continue;
		if (max.x + TOLERANCE_2 < x1) break;
		// x1
		count = 0;
		index = -1;
		for (int i = 0; i < fraction->size(); ++i) {
			const Point2D &p = fraction->at(i);
			if (x1 - TOLERANCE < p.x && p.x < x1 + TOLERANCE) {
				++count;
			} else {
				index = i;
			}
		}
		if (count == 2 && index != -1) {
			find = true;
			break;
		}
		// x2
		count = 0;
		index = -1;
		for (int i = 0; i < fraction->size(); ++i) {
			const Point2D &p = fraction->at(i);
			if (x2 - TOLERANCE < p.x && p.x < x2 + TOLERANCE) {
				++count;
			} else {
				index = i;
			}
		}
		if (count == 2 && index != -1) {
			find = true;
			break;
		}
	}
	if (!find) {
		// 切断面が特定できなかった場合
		throw runtime_error(ErrorCode::FATAL);
	}
	// index:切断面上にない頂点のインデックス
	const Point2D &p1 = fraction->at(PolygonUtil::prevIndex(index, fraction->size()));
	const Point2D &p2 = fraction->at(PolygonUtil::nextIndex(index, fraction->size()));
	const PolygonUtil::Segments_ segments = PolygonUtil::createSegments(src);
	const std::vector<double> angles = PolygonUtil::getAngles(segments);
	int index1;
	double d1min = 1000000;
	for (int i = 0; i < segments->size(); ++i) {
		const PolygonUtil::Segment &s = segments->at(i);
		if (s.contains_(p1)) {
			double d1 = PolygonUtil::perpendicularLength(p1, s);
			if (d1 < d1min) {
				d1min = d1;
				index1 = i;
			}
		}
	}
	int index2;
	double d2min = 1000000;
	for (int i = 0; i < segments->size(); ++i) {
		const PolygonUtil::Segment &s = segments->at(i);
		if (s.contains_(p2)) {
			double d2 = PolygonUtil::perpendicularLength(p2, s);
			if (d2 < d2min) {
				d2min = d2;
				index2 = i;
			}
		}
	}
	const int N = src->size();
	if (PolygonUtil::nextIndex(index1, N) != index2) {
		// 想定外のエラー
		throw runtime_error(ErrorCode::FATAL);
	}
	const int index0 = PolygonUtil::prevIndex(index1, N);
	const int index3 = PolygonUtil::nextIndex(index2, N);
	const PolygonUtil::Segment &s0 = segments->at(index0);
	const PolygonUtil::Segment &s1 = segments->at(index1);
	const PolygonUtil::Segment &s2 = segments->at(index2);
	const PolygonUtil::Segment &s3 = segments->at(index3);
	// s1(index1)側の処理
	Polygon_ r1 = Polygon_(new Polygon);
	// p2を通ってs1と平行な半直線
	const PolygonUtil::Segment s1_ = PolygonUtil::Segment(Point2D(p2.x - s1.x / s1.length() * 1000000, p2.y - s1.y / s1.length() * 1000000), p2);
	double a01 = PolygonUtil::normalizeRadian(angles[index1] - angles[index0]);
	if (a01 > 0) {
		// 頂点(index1)が凹頂点の場合
		Point2D cp;
		if (PolygonUtil::crossPoint(s0, s1_, &cp) != 0) {
			// 想定外のエラー
			throw runtime_error(ErrorCode::FATAL);
		}
		// (cp, p2)とs1の向きが同じであること (逆向きの場合は上手く切れていない)
		// TODO:上記のような場合、s0を延長してs2との交点で切り捨てる
		const PolygonUtil::Segment sTmp = PolygonUtil::Segment(cp, p2);
		if (PolygonUtil::angleEquals_(sTmp.angle(), s1.angle())) {
			// src->at(index0), cp, p2, src->at(index3)...
			r1->push_back(src->at(index0));
			r1->push_back(cp);
			r1->push_back(p2);
			for (int i = index3; i != index0; i = PolygonUtil::nextIndex(i, N)) {
				r1->push_back(src->at(i));
			}
		}
	} else {
		// srcとs1_の交点
		std::vector<Point2D> crossPoints;
		PolygonUtil::getCrossPoints(src, s1_.p1, s1_.p2, &crossPoints);
		Point2D cp;
		double dm = 1000000;
		for (int i = 0; i < crossPoints.size(); ++i) {
			const Point2D &p = crossPoints[i];
			if (p == p2) continue;
			const PolygonUtil::Segment s1_tmp = PolygonUtil::Segment(p, p2);
			if (fabs(PolygonUtil::normalizeRadian(s1_tmp.angle() - s1_.angle())) < TOLERANCE_ANGLE_2) {
				// 同じ側
				double d = s1_tmp.length();
				if (d < dm) {
					// 近い点
					dm = d;
					cp = p;
				}
			}
		}
		if (dm > 999999) {
			// 想定外のエラー (適切な交点が見つからない)
			throw runtime_error(ErrorCode::FATAL);
		}
		int indexC = -1;
		dm = 1000000;
		for (int i = 0; i < segments->size(); ++i) {
			const PolygonUtil::Segment &s = segments->at(i);
			if (s.contains_(cp)) {
				double d = PolygonUtil::perpendicularLength(cp, s);
				if (d < dm) {
					dm = d;
					indexC = i;
				}
			}
		}
		if (indexC < 0) {
			throw runtime_error(ErrorCode::FATAL);
		}
		// src->at(indexC), cp, p2, src->at(index3)...
		r1->push_back(src->at(indexC));
		r1->push_back(cp);
		r1->push_back(p2);
		for (int i = index3; i != indexC; i = PolygonUtil::nextIndex(i, N)) {
			r1->push_back(src->at(i));
		}
	}
	// s2(index2)側の処理
	Polygon_ r2 = Polygon_(new Polygon);
	// p1を通ってs2と平行な半直線
	const PolygonUtil::Segment s2_ = PolygonUtil::Segment(p1, Point2D(p1.x + s2.x / s2.length() * 1000000, p1.y + s2.y / s2.length() * 1000000));
	double a23 = PolygonUtil::normalizeRadian(angles[index3] - angles[index2]);
	if (a23 > 0) {
		// 頂点(index3)が凹頂点の場合
		Point2D cp;
		if (PolygonUtil::crossPoint(s2_, s3, &cp) != 0) {
			// 想定外のエラー
			throw runtime_error(ErrorCode::FATAL);
		}
		// (p1, cp)とs2の向きが同じであること (逆向きの場合は上手く切れていない)
		// TODO:上記のような場合、s3を延長してs1との交点で切り捨てる
		const PolygonUtil::Segment sTmp = PolygonUtil::Segment(p1, cp);
		if (PolygonUtil::angleEquals_(sTmp.angle(), s2.angle())) {
			// src->at(index1), p1, cp, src->at(index3+1)...
			r2->push_back(src->at(index1));
			r2->push_back(p1);
			r2->push_back(cp);
			for (int i = PolygonUtil::nextIndex(index3, N); i != index1; i = PolygonUtil::nextIndex(i, N)) {
				r2->push_back(src->at(i));
			}
		}
	} else {
		// srcとs2_の交点
		std::vector<Point2D> crossPoints;
		PolygonUtil::getCrossPoints(src, s2_.p1, s2_.p2, &crossPoints);
		Point2D cp;
		double dm = 1000000;
		for (int i = 0; i < crossPoints.size(); ++i) {
			const Point2D &p = crossPoints[i];
			if (p == p1) continue;
			const PolygonUtil::Segment s2_tmp = PolygonUtil::Segment(p1, p);
			if (fabs(PolygonUtil::normalizeRadian(s2_tmp.angle() - s2_.angle())) < TOLERANCE_ANGLE_2) {
				// 同じ側
				double d = s2_tmp.length();
				if (d < dm) {
					// 近い点
					dm = d;
					cp = p;
				}
			}
		}
		if (dm > 999999) {
			// 想定外のエラー (適切な交点が見つからない)
			throw runtime_error(ErrorCode::FATAL);
		}
		int indexC = -1;
		dm = 1000000;
		for (int i = 0; i < segments->size(); ++i) {
			const PolygonUtil::Segment &s = segments->at(i);
			if (s.contains_(cp)) {
				double d = PolygonUtil::perpendicularLength(cp, s);
				if (d < dm) {
					dm = d;
					indexC = i;
				}
			}
		}
		if (indexC < 0) {
			throw runtime_error(ErrorCode::FATAL);
		}
		// src->at(index1), p1, cp, src->at(indexC+1)...
		r2->push_back(src->at(index1));
		r2->push_back(p1);
		r2->push_back(cp);
		for (int i = PolygonUtil::nextIndex(indexC, N); i != index1; i = PolygonUtil::nextIndex(i, N)) {
			r2->push_back(src->at(i));
		}
	}
	int checkPolygon1 = PolygonUtil::checkPolygon(r1);
	int checkPolygon2 = PolygonUtil::checkPolygon(r2);
	if (checkPolygon1 < 0 && checkPolygon2 < 0) {
		return;
	}
	if (checkPolygon2 < 0) {
		src->swap(*r1);
		return;
	}
	if (checkPolygon1 < 0) {
		src->swap(*r2);
		return;
	}
	// 面積の損失が小さい方を選択
	double area1 = PolygonUtil::area(r1);
	double area2 = PolygonUtil::area(r2);
	if (area1 > area2) {
		src->swap(*r1);
		return;
	}
	src->swap(*r2);
}
// 4角形の場合、切断面の対辺を平行移動して切り捨て
void FieldPolygon::cutoffHeadlandWorkingHP_shiftEdge4(Polygon_ &src, const Polygon_ &fraction) {
	Point2D min;
	Point2D max;
	PolygonUtil::boundingBox(fraction, &min, &max);
	int count = 0;
	int index = -1;
	bool find = false;
	for (double posX = _workingAreasMin.x; posX < _workingAreasMax.x; posX += pathInterval) {
		const double x1 = posX;
		const double x2 = posX + _cultivationWidth1;
		if (x2 < min.x - TOLERANCE_2) continue;
		if (max.x + TOLERANCE_2 < x1) break;
		// x1
		count = 0;
		index = -1;
		for (int i = 0; i < fraction->size(); ++i) {
			const Point2D &p = fraction->at(i);
			if (x1 - TOLERANCE < p.x && p.x < x1 + TOLERANCE) {
				++count;
			} else {
				index = i; // 切断面上にない頂点のインデックス
			}
		}
		if (count == 2 && index != -1) {
			// 切断面上にある頂点のインデックス
			for (int i = PolygonUtil::nextIndex(index, fraction->size()); i != index; i = PolygonUtil::nextIndex(i, fraction->size())) {
				const Point2D &p = fraction->at(i);
				if (x1 - TOLERANCE < p.x && p.x < x1 + TOLERANCE) {
					index = i; // 先に見つかるのはp2
					find = true;
					break;
				}
			}
			if (find) break;
		}
		// x2
		count = 0;
		index = -1;
		for (int i = 0; i < fraction->size(); ++i) {
			const Point2D &p = fraction->at(i);
			if (x2 - TOLERANCE < p.x && p.x < x2 + TOLERANCE) {
				++count;
			} else {
				index = i; // 切断面上にない頂点のインデックス
			}
		}
		if (count == 2 && index != -1) {
			// 切断面上にある頂点のインデックス
			for (int i = PolygonUtil::nextIndex(index, fraction->size()); i != index; i = PolygonUtil::nextIndex(i, fraction->size())) {
				const Point2D &p = fraction->at(i);
				if (x2 - TOLERANCE < p.x && p.x < x2 + TOLERANCE) {
					index = i; // 先に見つかるのはp2
					find = true;
					break;
				}
			}
			if (find) break;
		}
	}
	if (!find) {
		// 切断面が特定できなかった場合
		throw runtime_error(ErrorCode::FATAL);
	}
	// index:切断面上にある頂点のうち、fraction上で前側のインデックス (src上で考えた場合は後側)
	const Point2D &p1 = fraction->at(PolygonUtil::nextIndex(index, fraction->size()));
	const Point2D &p2 = fraction->at(index);
	const PolygonUtil::Segments_ segments = PolygonUtil::createSegments(src);
	const std::vector<double> angles = PolygonUtil::getAngles(segments);
	int index1;
	double d1min = 1000000;
	for (int i = 0; i < segments->size(); ++i) {
		const PolygonUtil::Segment &s = segments->at(i);
		if (s.contains_(p1)) {
			double d1 = PolygonUtil::perpendicularLength(p1, s);
			if (d1 < d1min) {
				d1min = d1;
				index1 = i;
			}
		}
	}
	int index2;
	double d2min = 1000000;
	for (int i = 0; i < segments->size(); ++i) {
		const PolygonUtil::Segment &s = segments->at(i);
		if (s.contains_(p2)) {
			double d2 = PolygonUtil::perpendicularLength(p2, s);
			if (d2 < d2min) {
				d2min = d2;
				index2 = i;
			}
		}
	}
	const int N = src->size();
	if (PolygonUtil::nextIndex(index1, N) != PolygonUtil::prevIndex(index2, N)) {
		// 想定外のエラー
		throw runtime_error(ErrorCode::FATAL);
	}
	const int indexM = PolygonUtil::nextIndex(index1, N);
	const int index3 = PolygonUtil::nextIndex(index2, N);
	const PolygonUtil::Segment &sM = segments->at(indexM);
	// s1(index1)側の処理
	Polygon_ r1 = Polygon_(new Polygon);
	{
		// p1を通ってsMと平行な半直線
		const PolygonUtil::Segment s1_ = PolygonUtil::Segment(p1, Point2D(p1.x + sM.x / sM.length() * 1000000, p1.y + sM.y / sM.length() * 1000000));
		// srcとs1_の交点
		std::vector<Point2D> crossPoints;
		PolygonUtil::getCrossPoints(src, s1_.p1, s1_.p2, &crossPoints);
		Point2D cp;
		double dm = 1000000;
		for (int i = 0; i < crossPoints.size(); ++i) {
			const Point2D &p = crossPoints[i];
			if (p == p1) continue;
			const PolygonUtil::Segment s1_tmp = PolygonUtil::Segment(p1, p);
			if (fabs(PolygonUtil::normalizeRadian(s1_tmp.angle() - s1_.angle())) < TOLERANCE_ANGLE_2) {
				// 同じ側
				double d = s1_tmp.length();
				if (d < dm) {
					// 近い点
					dm = d;
					cp = p;
				}
			}
		}
		if (dm > 999999) {
			// TODO:想定外のエラー (fractionが凹ポリゴン)
		} else {
			int indexC = -1;
			dm = 1000000;
			for (int i = 0; i < segments->size(); ++i) {
				const PolygonUtil::Segment &s = segments->at(i);
				if (s.contains_(cp)) {
					double d = PolygonUtil::perpendicularLength(cp, s);
					if (d < dm) {
						dm = d;
						indexC = i;
					}
				}
			}
			if (indexC < 0) {
				// TODO:想定外のエラー (適切な交点が見つからない)
			} else {
				// src->at(index1), p1, cp, src->at(indexC+1)...
				r1->push_back(src->at(index1));
				r1->push_back(p1);
				r1->push_back(cp);
				for (int i = PolygonUtil::nextIndex(indexC, N); i != index1; i = PolygonUtil::nextIndex(i, N)) {
					r1->push_back(src->at(i));
				}
			}
		}
	}
	// s2(index2)側の処理
	Polygon_ r2 = Polygon_(new Polygon);
	{
		// p2を通ってsMと平行な半直線
		const PolygonUtil::Segment s2_ = PolygonUtil::Segment(Point2D(p2.x - sM.x / sM.length() * 1000000, p2.y - sM.y / sM.length() * 1000000), p2);
		// srcとs2_の交点
		std::vector<Point2D> crossPoints;
		PolygonUtil::getCrossPoints(src, s2_.p1, s2_.p2, &crossPoints);
		Point2D cp;
		double dm = 1000000;
		for (int i = 0; i < crossPoints.size(); ++i) {
			const Point2D &p = crossPoints[i];
			if (p == p2) continue;
			const PolygonUtil::Segment s2_tmp = PolygonUtil::Segment(p, p2);
			if (fabs(PolygonUtil::normalizeRadian(s2_tmp.angle() - s2_.angle())) < TOLERANCE_ANGLE_2) {
				// 同じ側
				double d = s2_tmp.length();
				if (d < dm) {
					// 近い点
					dm = d;
					cp = p;
				}
			}
		}
		if (dm > 999999) {
			// TODO:想定外のエラー (fractionが凹ポリゴン)
		} else {
			int indexC = -1;
			dm = 1000000;
			for (int i = 0; i < segments->size(); ++i) {
				const PolygonUtil::Segment &s = segments->at(i);
				if (s.contains_(cp)) {
					double d = PolygonUtil::perpendicularLength(cp, s);
					if (d < dm) {
						dm = d;
						indexC = i;
					}
				}
			}
			if (indexC < 0) {
				// TODO:想定外のエラー (適切な交点が見つからない)
			} else {
				// src->at(indexC), cp, p2, src->at(index3)...
				r2->push_back(src->at(indexC));
				r2->push_back(cp);
				r2->push_back(p2);
				for (int i = index3; i != indexC; i = PolygonUtil::nextIndex(i, N)) {
					r2->push_back(src->at(i));
				}
			}
		}
	}
	int checkPolygon1 = PolygonUtil::checkPolygon(r1);
	int checkPolygon2 = PolygonUtil::checkPolygon(r2);
	if (checkPolygon1 < 0 && checkPolygon2 < 0) {
		return;
	}
	if (checkPolygon2 < 0) {
		src->swap(*r1);
		return;
	}
	if (checkPolygon1 < 0) {
		src->swap(*r2);
		return;
	}
	// 面積が小さくなる方を選択
	double area1 = PolygonUtil::area(r1);
	double area2 = PolygonUtil::area(r2);
	if (area1 < area2) {
		src->swap(*r1);
		return;
	}
	src->swap(*r2);
}
// ポリゴンに凹角がないかチェックします
bool FieldPolygon::cutoffHeadlandWorkingHP_checkConcave(const Polygon_ &p) {
	const std::vector<double> angles = PolygonUtil::getSegmentAngles(p);
	double a0 = angles.back();
	for (int i = 0; i < angles.size(); ++i) {
		double a1 = angles[i];
		if (PolygonUtil::normalizeRadian(a1 - a0) > 0) {
			// 左折=凹角
			return true;
		}
		a0 = a1;
	}
	return false;
}

// 外周作業用HPとして短すぎる辺を削除します
void FieldPolygon::omitEdge(Polygon_ polygon) {
	bool united = true;
	while (united) {
		united = false;
		const PolygonUtil::Segments_ segments = PolygonUtil::createSegments(polygon);
		for (int i = 0; i < segments->size(); ++i) {
			const PolygonUtil::Segment &s = segments->at(i);
			if (s.length() < 0.01) {
				// 外周作業用HPに1cm未満の短い辺がある場合、2個の頂点を1個にまとめて短い辺を消す
				Point2D pm = s.p1;
				pm.x += s.x * 0.5;
				pm.y += s.y * 0.5;
				Polygon_ tmp = Polygon_(new Polygon);
				tmp->push_back(pm);
				int i2 = PolygonUtil::nextIndex(PolygonUtil::nextIndex(i, segments->size()), segments->size());
				for (int j = i2; j != i; j = PolygonUtil::nextIndex(j, segments->size())) {
					tmp->push_back(polygon->at(j));
				}
				polygon->swap(*tmp);
				united = true;
				break;
			}
		}
	}
}

// 同じ作業ライン上に乗っている1本以上の作業パスに対して外周作業用HPの作業領域を割り当て可能かチェックします。
// 外周作業用HPの作業領域を割り当てることが出来なかった作業パスはリストから除外します。
void FieldPolygon::checkWorkingSegmentsEffectiveArea(Segments_ &workingSegments, bool up) {
	const Polygon_ workingArea = Polygon_(new Polygon);
	if (_headlandWorking == Param::Work::Headland::Process::NOP) {
		workingArea->assign(_workingAreas->at(0)->begin(), _workingAreas->at(0)->end());
	} else {
		workingArea->assign(_headlandWorkingHP->begin(), _headlandWorkingHP->end());
	}
	// 作業領域のバウンディングボックス
	Point2D waMin, waMax;
	PolygonUtil::boundingBox(workingArea, &waMin, &waMax);
	// 作業ラインのx座標
	const double lineX = workingSegments->at(0).p1.x;
	// 作業パスの向きを考慮した作業幅オフセット
	const double offset = up ? _cultivationWidthOffset : -_cultivationWidthOffset;
	// x方向は、この作業パスが塗りつぶす幅
	waMin.x = lineX + offset - _cultivationWidth1 * 0.5;
	waMax.x = lineX + offset + _cultivationWidth1 * 0.5;
	// y方向は、HPが確実に納まるように拡大
	waMin.y -= 1;
	waMax.y += 1;
	// HPから切り抜く矩形
	Polygon_ box = PolygonUtil::box2Polygon(waMin, waMax);
	// 有効な(塗り潰しが必要な)作業領域のリスト
	Polygons_ effectiveAreas = Polygons_(new Polygons);
	PolygonUtil::intersection(workingArea, box, effectiveAreas);
	if (effectiveAreas->size() > workingSegments->size()) {
		// 作業領域のリストの方が多い場合
		// エラーにするのはヤリ過ぎっぽい
		// throw runtime_error(ErrorCode::WorkingArea::COMPUTE);
		// TODO:残耕が発生する場合は対策が必要
		return;
	}
	if (effectiveAreas->size() == workingSegments->size()) {
		// 数が一致している場合は処理不要
		return;
	}
	// 作業パスの方が多い場合、有効な作業領域を持たない(不要な)作業パスが含まれている
	std::vector<std::pair<int, double>> eval;
	for (int i = 0; i < workingSegments->size(); ++i) {
		const Segment &s = workingSegments->at(i);
		eval.push_back({ i, -1000000 });
		for (int j = 0; j < effectiveAreas->size(); ++j) {
			const Polygon_ &a = effectiveAreas->at(j);
			Point2D eaMin, eaMax;
			PolygonUtil::boundingBox(a, &eaMin, &eaMax);
			double e;
			if (s.p2.y < eaMin.y || eaMax.y < s.p1.y) {
				// オーバーラップがない場合、ギャップのマイナス
				e = -std::min(fabs(eaMin.y - s.p2.y), fabs(eaMax.y - s.p1.y));
			} else {
				// オーバーラップがある場合、オーバーラップの大きさ
				e = std::min(eaMax.y, s.p2.y) - max(eaMin.y, s.p1.y);
			}
			if (e > eval[i].second) {
				eval[i].second = e;
			}
		}
	}
	// 評価値の低い順に必要な本数だけ削除
	// =>評価値の高い作業パスを必要な本数だけ残す
	std::sort(eval.begin(), eval.end(), [](std::pair<int, double> e1, std::pair<int, double> e2) -> int { return (e1.second < e2.second); });
	const int count = workingSegments->size() - effectiveAreas->size();
	Segments_ tmp = Segments_(new Segments);
	for (int i = 0; i < workingSegments->size(); ++i) {
		for (int j = count; j < eval.size(); ++j) {
			if (eval[j].first == i) {
				tmp->push_back(workingSegments->at(i));
				break;
			}
		}
	}
	workingSegments->swap(*tmp);
}

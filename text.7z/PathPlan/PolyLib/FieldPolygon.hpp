// Yanmar Confidential 20200918
/****************************************************************************/
/* [Program] Common header file for all functions                           */
/* [(C) COPYRIGHT] YANMAR Co., Ltd. Electronics Development Centre          */
/*                                                                          */
/* Company                :            xxxx xxxxxxxxxxxx xxxx xxxxxxxxx     */
/* Client                 :            YANMAR Co. Ltd, JAPAN                */
/* Author                 :            MANUJ SHARMA,SACHIN BHISIKAR         */
/*                                     (YANMAR PathPlanning Team)           */
/* Version                :            1.1                                  */
/*                                                                          */
/* The purpose of field data class is to organize the field data and        */
/* obstacle information in the field object.This functionality is also      */
/* responsible for creating the headland area for field as well as for      */
/* obstacles.                                                               */
/* It Creates and identifies the regions in which tractor can move          */
/* autonomously and can take turns which are easy for the guidance          */
/* algorithm to negotiate.                                                  */
/* In addition to it, also creates an initial graph for navigation.         */
/****************************************************************************/

/****************************************************************************/
/* Date:                     -              Version history                 */
/* 20140107                  -              Initial version                 */
/* 20140430                  -              Version 1.1                     */
/*                                                                          */
/****************************************************************************/
#ifndef _POLYGONLIB_
#define _POLYGONLIB_

/*Right now obs_edge_size is defined to be four*/
#define MARGIN_ANGLE 10.0
#define MINCULTPATH 50.0
#define MINSTARTNAV 10.0

#include <iostream>
#include <list>
#include <vector>
#include <algorithm>    // std::sort
#include <math.h>

#include "Context.hpp"
#include "OutLib/OutLib.h"
#include "PolygonUtil.hpp"
#include "PathLib/Gauge.hpp"
#include "PathLib/PathGauge.hpp"

namespace yanmar { namespace PathPlan {

// Engine.cppから参照されている
enum TractorNum {
	OneTractor = 1, TwoTractor
};

class FieldPolygon {
private:
	/** 頂点 */
	typedef GeoPoint Vertex;
	/** 頂点のリスト */
	typedef std::vector<Vertex> VertexXY;
	/** 辺(頂点のインデックス2個で、頂点同士の接続を表現する) */
	typedef pair<int, int> Edge;
	/** 辺のリスト */
	typedef std::list<Edge> PolyList;

	class Segment {
	public:
		Point2D p1;
		Point2D p2;
		int type1; // p1の属性(0=枕地, 1=サイドマージン, 2=障害物)
		int type2; // p2の属性(0=枕地, 1=サイドマージン, 2=障害物)
		Segment(const Point2D &_p1, const Point2D &_p2, int _type1, int _type2) {
			p1 = _p1;
			p2 = _p2;
			type1 = _type1;
			type2 = _type2;
		}
	};
	typedef std::vector<Segment> Segments;
	typedef boost::shared_ptr<Segments> Segments_;

	/** Point2Dに属性を追加したラッパクラス */
	class _Point2D {
	public:
		Point2D p;
		bool onSideMargin;
		_Point2D(const Point2D &_p, bool _onSideMargin) {
			p.x = _p.x;
			p.y = _p.y;
			onSideMargin = _onSideMargin;
		}
	};

	class Coordinates {
	public:
		Polygon_ field;
		Polygons_ obstacles;
		Point2D uiStart;
		Point2D uiEnd;
		Point2D dp1;
		Point2D dp2;
		double rotateAngle = 0.0;
		Point2D translate;
	};

private:

	/** 基点(GPSユニット)からトラクター前端までの長さ */
	double _gps2Front = 0.0;
	/** 基点(GPSユニット)からトラクター後端までの長さ */
	double _gps2Rear = 0.0;

	/** 基点(GPSユニット)から作業機後側までの長さ */
	double _gps2ImplementEnd = 0.0;
	/** 基点(GPSユニット)から作業中心までの長さ */
	double _gps2CultivationPos = 0.0;

	/** 全体の幅 */
	double _maxWidth = 0.0;
	double _maxWidthOuter = 0.0;
	/** トラクターの幅 */
	double _tractorWidth = 0.0;
	/** 作業機の幅 */
	double _implementWidth = 0.0;
	double _implementWidthOuter = 0.0;

	/** 作業パスのオーバーラップ幅 */
	double _cultivationOverlap = 0.0;

	/** 作業パスの幅 */
	double _cultivationWidth1 = 0.0;
	/** 2台目(有人)トラクターの作業パスの幅 */
	double _cultivationWidth2 = 0.0;

	/** 作業機幅のオフセット */
	double _implementWidthOffset = 0.0;
	/** 作業(耕耘)幅のオフセット */
	double _cultivationWidthOffset = 0.0;

	/** 無人機の作業パスの間隔(次の無人機または有人機の作業パスまでの間隔) */
	double _pathInterval1 = 0.0;
	/** 有人機の作業パスの間隔(次の無人機の作業パスまでの間隔) */
	double _pathInterval2 = 0.0;
	/** 作業パスの間隔 */
	double pathInterval = 0.0;

	/** 旋回半径 */
	double _turnRadius = 0.0;
	/** 旋回時に外側を擦らないために必要な半径 */
	double _outerRadius = 0.0;
	double _outerRadius2 = 0.0;
	/** 旋回時に内側を擦らないために必要な半径(作業機の幅が大きい場合、マイナスになることがある) */
	double _innerRadius = 0.0;

	/** ユーザが指定した枕地幅 */
	double _headlandUser = 0.0;
	/** ユーザが指定したサイドマージン */
	double _sideMarginUser = 0.0;
	/** 枕地幅/サイドマージンの計算方法(0:最小、1:パス間隔整数倍(個別)、2:パス間隔整数倍(統一)) */
	int _headlandSideMarginType = 0;
	/** 枕地幅/サイドマージンの計算方法が2:パス間隔整数倍(統一)の場合に、計算上で目標としたN値 */
	int _headlandSideMarginFactorUnityN = 0;

	/** スキップパターン時のスキップ数 */
	int _numSkipPath = 0;
	/** バック(後進)可能フラグ(true:バック可、false:バック不可) */
	bool _canBackward = false;
	/** 作業機自体のバック(後進)可能フラグ */
	bool _canBackwardImplement = true;

	// 作業領域全体のバウンディングボックス
	Point2D _workingAreasMin;
	Point2D _workingAreasMax;
	// 外周作業用HPのバウンディングボックス (半渦巻き)
	Point2D _headlandWorkingMin;
	Point2D _headlandWorkingMax;

    // ログディレクトリ
    std::string _logDir;
    std::string _inDataString;

    int _progressType = Param::Work::ProgressType::NORMAL;
    bool _workPatternVortex = false;
    bool _clockwiseVortex = false;
    // 半グルグルと全グルグルのフラグ
    bool _fullVortex = false;

// 枕地、サイドマージンの計算式の使用条件フラグ
	// 作業パスから枕地領域に出て、Uターンして作業パスに入るための条件(フラットターン・フィッシュテールターンも同じ)
	bool HEAD_LAND_0 = false;
	// 45度未満の鋭角凹頂点(ターンサークルがシフト出来ない頂点)を回るための条件
	bool HEAD_LAND_1 = false;
	// サイドマージンを走るための条件
	bool SIDE_MARGIN_0 = false;
	// 作業領域の右端最後の作業パスに入るためのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件(サイドマージンを走らない場合)
	bool SIDE_MARGIN_1 = false;
	// 作業領域の右端最後の作業パスからサイドマージンに入るためのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件
	bool SIDE_MARGIN_2 = false;
	// 作業領域の左端最初の作業パスから次の作業パスに入るためのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件(サイドマージンを走らない場合)
	bool SIDE_MARGIN_3 = false;
	// サイドマージンから作業領域の左端最初の作業パスに入るためのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件
	bool SIDE_MARGIN_4 = false;
	// サイドマージンにも作業パスを生成する場合に、サイドマージン領域内でのフィッシュテールターンで、1個目のターン後の前進時にトラクターの前側がはみ出さない条件
	bool SIDE_MARGIN_5 = false;
	// サイドマージンにも作業パスを生成する場合に、サイドマージン領域内でのフィッシュテールターンで、後進時に作業機の後側がはみ出さない条件
	bool SIDE_MARGIN_6 = false;
	// 作業領域の右端最後の作業パスからUターンしてサイドマージンに入る(または、サイドマージンからUターンして作業領域の左端最初の作業パスに入る)ための条件
	bool SIDE_MARGIN_7 = false;

	// 非作業領域の統合処理発生フラグ(1回でも統合処理が発生したらtrue、リトライしても寝ない)
	bool _combined = false;

	// 安全マージン
	double _safetyMargin = 1.0;

	// (圃場、障害物、開始位置、終了位置、回転角度、平行移動量) * (作業進捗方向の正順、逆順)
	std::array<Coordinates, 2> _orgCoordinates;
	// 作業進捗方向(0:正順、1:逆順)
	int _progressOrder = 0;
	// 最適なサイドマージンの角度閾値を求めるフラグ
	bool _searchSuitableSideMarginAngle = true;

	/** ABパスの生成方法 */
	int _pathTypeAB = Param::Work::PathTypeAB::NO_SHIFT;
	/** ABパスのシフト用トラクターの現在地 */
	Point2D _tractorPosAB;
	/** ABパスのシフト値 */
	double _shiftValueAB = 0.0;
	/** ABパス生成で作業パスを延長する長さ */
	double _extendLengthAB = 10000.0;
	/** ABパスの片側生成本数 (実際の本数は*2+1) */
	int _numHalfAB_L = 500;
	int _numHalfAB_R = 500;
	/** 1本目(左端)の作業パスの向き (0:双方向, 1:上向き, -1:下向き) 作業開始位置の決定に使用 */
	int _firstLineDir = 0;

	// エラーコードの優先度
	std::map<std::string, int> errorLevels;
	// パス生成コンテキスト
	ContextIF &_context;
	/** UIで設定した作業方向 (の始点) */
	Point2D _dp1;
	/** UIで設定した作業方向 (の終点) */
	Point2D _dp2;
	/** 外周作業の有無と種別 */
	int _headlandWorking = Param::Work::Headland::Process::NOP;
	int _headlandRotation = Param::Work::Pattern::Rotation::UNDEFINED;
	/** ヒッチUP/DOWN用のマージン */
	double _hitchUpDownMargin;
	/** ドン突き */
	bool _fold = false;
	/** 除外された作業パスのリスト */
	Segments_ _unavailableSegments;
	/** スタート・ゴール位置を決定するためのポリゴンのリスト */
	Polygons_ _startEndPolygons;

public:
	/** フィッシュテールターンしないためのスキップ数 */
	int numSkipNoFish = 0;
	/** 整数倍の基準値 */
	double _pathIntervalforN = 0.0;

	/** UIで設定したスタート位置 */
	Point2D uiStart;
	/** UIで設定したエンド位置 */
	Point2D uiEnd;
	/** UIでエンド位置が設定されているか */
	bool uiEndAvailable = false;
	/** 作業開始位置(左端の作業パスの上端/下端で、UIで設定したスタート位置に近い方の頂点インデックス) */
	int workStartIndex = 0;
	/** 自動運転の開始位置(作業領域+作業パスの頂点で、UIで設定したスタート位置に最も近い点の頂点インデックス) */
	int driveStartIndex = 0;
	/** 自動運転の終了位置(作業領域+作業パスの頂点で、UIで設定したエンド位置に最も近い点の頂点インデックス) */
	int driveEndIndex = 0;
	/** 自動運転の開始位置の座標 */
	Point2D driveStart;
	/** 自動運転の終了位置の座標 */
	Point2D driveEnd;

	// 強制的にサイドマージンに作業パスを生成する/しない
	bool forceCreateWorkingSegmentsOnSideMargin = false;
	// サイドマージンに作業パスを生成する/しない
	bool createWorkingSegmentsOnSideMargin = false;
	// サイドマージンの角度閾値
	double sideMarginAngle = M_PI / 180.0 * 10.0;

	/** ガイダンスデータへの出力用 */
	Polygons_ _bbObstacles;

	/** オリジナルの圃場(全体)ポリゴン */
	Polygon_ _orgField;
	/** 圃場(全体)ポリゴン */
	Polygon_ _field;
	/** 障害物ポリゴンのリスト */
	Polygons_ _obstacles;

	/** 作業領域ポリゴンのリスト */
	Polygons_ _workingAreas;
	/** 非作業領域ポリゴンのリスト */
	Polygons_ _nonWorkingAreas;
	/** 生成したパスとの交差判定用ポリゴンのリスト(ディスプレイ用のパスがこのポリゴンと交差したらNG) */
	Polygons_ _pathEnvelopePolygons;

	/** 外周作業用HP */
	Polygon_ _headlandWorkingHP;
	/** HPと外周作業用HPとの差 */
	double _headlandWorkingAdditionalWidth = 0;
	/** 外周作業の開始位置 (外周作業が先の場合だけ利用可能) */
	int _headlandStartIndex = -1;
	/** 外周作業の自動運転開始位置 (外周作業が先の場合だけ利用可能、外周作業用HP上の点) */
	Point2D _headlandStartPos;
	/** 外周作業の自動運転終了位置 (外周作業が後の場合だけ利用可能、外周作業用HP上の点) */
	Point2D _headlandEndPos;
	/** 外周作業の自動運転終了位置2 (外周作業が塗り潰す境界線上の点、ゴールライン設定用) */
	Point2D _headlandEndPos2;

	/** 作業パス用セグメントのリスト */
	Segments_ _workingSegments;
	/** 2台目(有人)トラクター用の作業パス用セグメントのリスト */
	Segments_ _workingSegments2;

	/** 回転角度(座標系の逆変換用) */
	double rotateAngle = 0.0;
	/** 平行移動量(座標系の逆変換用) */
	Point2D translate;

	/** 適用された枕地幅の最大値 */
	double appliedHeadlandMax = 0.0;
	/** 適用されたサイドマージンの最大値 */
	double appliedSideMarginMax = 0.0;

    /** FieldPolygon算出パラメータ値 */
    FpGauge hPara;
    FpGauge getFpGauge() const {
        FpGauge fpGauge{hPara};
        fpGauge.whpDiff = _headlandWorkingAdditionalWidth;
        return fpGauge;
    }

	int noBoundayVertices = 0; // 圃場の頂点数 = 作業領域の頂点数 = poly[0].size()
    int noHeadlandVertices = 0; // 作業領域の頂点数 != 圃場の頂点数
	int OrigVertexLen = 0; // 圃場+障害物の頂点数 = 作業領域+非作業領域の頂点数

	VertexXY InFieldVertex; // 圃場+障害物の頂点
	VertexXY FieldVertex; // 作業領域+非作業領域の頂点
	VertexXY SweepVertex; // 作業パスの頂点
	VertexXY NavFieldVertex; // 作業領域+非作業領域+作業パスの頂点
	VertexXY SHPVertex; // パスがはみ出してはいけないライン(ディスプレイ用のパスと交差したらアウト)
	VertexXY MannedTractorVertex; // 有人トラクターの作業パスの頂点

	// 作業領域と非作業領域の単方向グラフを作って最終的に全てのエッジを削除？
	Graph g;

	// NavFieldVertexのグラフ
	Graph gh;

	OutField outPoly;
	vector<int> delVertices;
	vector<int> delFlagObs;
	int vortexCount = 0;
	std::vector<OutField::WorkingOrder> workingOrders;
	PathGauge *pathGauge;

private:
	bool onWorkingAreasEdge(const Point2D &p);
	bool inWorkingAreas(const Point2D &p);
	void AllPairShortest(vector<vector<int> > &dist, vector<vector<int> > &pred, vector<Edge> &obstaclesEdges);
	void ConstructShortestPath(int s, int t, vector<vector<int> > const &pred, list<int> &path);

	double distanceOnGraph(int i1, int i2);

	void transformCoordinates(const InputData &inData);
	void transformCoordinates2(Coordinates &coordinates, double dx, double dy);
	void restoreCoordinates(int index);
	void copyPolygons(const Polygons_ &src, Polygons_ dst);

	int simplify(Polygon_ field, double width, bool complement);
	PolygonUtil::Angles2Widths getAngles2Widths();
	PolygonUtil::Angles2Widths getAngles2WidthsObs();
	bool checkRunSideMargin(const Polygon_ &polygon, double *smMin = nullptr, double *smMax = nullptr);
	bool checkConcave();
	bool checkNonWorkingAreasIntersection();
	void checkWorkingAreasIntersection();
	bool merge(Polygons_ polygons);
	void generateOrgFormatData();
	void generatePolygons();

	void initFlags();
	void initVertices();
	bool getCrossPoints(const Polygon_ &polygon, const Point2D &p1, const Point2D &p2, std::vector<_Point2D> *crossPoints);
	void createWorkingSegments();
	void createWorkingSegments2();
	void createWorkingSegmentsAB(double *tractorShift);
    void createWorkingSegmentsOffsetFR(Segments_ &workingSegmentsF, Segments_ &workingSegmentsR);
	void createWorkingSegmentsOffset();
    void addWorkingSegments(double posX, bool up);
    void createWorkingSegmentsOffsetBlock();
    void createWorkingSegmentsOffsetBlock_noBack();
	void createWorkingSegmentsOffsetBlock_rect();
	void checkWorkingSegmentsEffectiveArea(Segments_ &workingSegments, bool up);

	void createNavigationGraph();
	void createNavigationGraphVortex();
	bool defineStartEndPoint(bool retry);
	void defineStartEndPoint_getNearest(const Point2D &p, const Polygon_ &polygon1, const Polygon_ &polygon2, Point2D &outP, int *index);

	void createGraphDirected();
	void detachGraph();

	void calculateCoordinates_internal2();
	double calculateCoordinates_internal();
	double calculateCoordinates_searchSideMarginAngle();
	double getEffectiveArea();
	void getEffectiveArea_getNextLine(Segments::iterator &itr, const Segments::iterator &end, std::vector<Segment> &nextLine);
	double getEffectiveArea_getIntervalArea(const std::vector<Segment> &prevLine, const std::vector<Segment> &nextLine, const double width1, const double width2);
	int compareErrorLevel(const std::string &e1, const std::string &e2);
	void getLineUpDown(int lineCount, int skip, vector<int> &updown);
	void cutoffRightSideEdge1();
	void cutoffHeadlandWorkingHP();
	void cutoffHeadlandWorkingHP_pickup(const Segments_ &segments, Polygons_ &src, Polygons_ &pickup);
	void cutoffHeadlandWorkingHP_reunion(Polygons_ &polygons);
	bool cutoffHeadlandWorkingHP_reunion2(const Polygon_ &p1, const Polygon_ &p2, Polygons_ &results);
	void cutoffHeadlandWorkingHP_sticky(const Polygon_ &org, Polygon_ &part);
	void cutoffHeadlandWorkingHP_subtract(Polygon_ &src, const Polygons_ &polygons);
	void cutoffHeadlandWorkingHP_shiftEdge3(Polygon_ &src, const Polygon_ &fraction);
	void cutoffHeadlandWorkingHP_shiftEdge4(Polygon_ &src, const Polygon_ &fraction);
	bool cutoffHeadlandWorkingHP_checkConcave(const Polygon_ &p);
	void omitEdge(Polygon_ polygon);

public:
    FieldPolygon(ContextIF &context, InputData &inData, double safetyMargin, const std::string &aLogDir = "", bool ab = false);
	~FieldPolygon();
	void calculateCoordinates(double *headlandMax, double *sideMarginMax, int *headlandN, int *sideMarginN, int *headlandSideMarginFactorUnityN, double *fieldArea, double *effectiveArea);
	void calculateCoordinatesAB(double *tractorShift);
	void transformInverse();
};

}} // namespace yanmar::PathPlan

#endif

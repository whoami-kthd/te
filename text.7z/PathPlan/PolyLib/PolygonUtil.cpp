// Yanmar Confidential 20200918
// #define LOGLEVEL 5
#include "Common.h"

#include "boost/geometry.hpp"
#include "boost/geometry/geometries/point_xy.hpp"
#include "boost/geometry/geometries/polygon.hpp"

#include "PathPlanIF.hpp"
#include "PolygonUtil.hpp"

using namespace yanmar::PathPlan;

namespace yanmar { namespace PathPlan {

/**
 * GeoPolygonのPolygon変換
 */
Polygon_ makePolygon_(const GeoPolygon& geoPolygon) {
	Polygon_ polygon_(new Polygon(geoPolygon.size()));
	polygon_->clear();
	for (auto geoPoint : geoPolygon) {
		polygon_->push_back(geoPoint);
	}
	
	return polygon_;
}

/**
 * GeoPolygonのPolygon変換
 */
Polygons_ makePolygons_(const GeoPolygonList& geoPolygonList) {
	Polygons_ polygons_(new Polygons(geoPolygonList.size()));
	polygons_->clear();
	for (auto polygon : geoPolygonList) {
		polygons_->push_back(makePolygon_(polygon));
	}
	
	return polygons_;
}

typedef boost::geometry::model::d2::point_xy<double> BoostPoint;
typedef boost::geometry::model::polygon<BoostPoint> BoostPolygon;

inline BoostPoint point2BoostPoint(const Point2D &p) {
	return BoostPoint(p.x, p.y);
}

inline Point2D boostPoint2Point(const BoostPoint &bp) {
	return Point2D(bp.x(), bp.y());
}

inline BoostPolygon polygon2BoostPolygon(const Polygon_ &p) {
	BoostPolygon bp;
	for (int i = 0; i < p->size(); ++i) {
		bp.outer().push_back(point2BoostPoint(p->at(i)));
	}
	bp.outer().push_back(point2BoostPoint(p->at(0)));
	return bp;
}

inline Polygon_ boostPolygon2Polygon(const BoostPolygon &bp) {
	Polygon_ p = Polygon_(new Polygon);
	for (int i = 0; i < (int) bp.outer().size() - 1; ++i) {
		p->push_back(boostPoint2Point(bp.outer()[i]));
	}
	return p;
}

int PolygonUtil::checkPolygon(Polygon_ polygon)
{
	if (polygon->size() < 3) return -1; // 点の個数が3個未満
	if (correctSamePoints(polygon) < 0) return -1; // 削除された結果、点の個数が3個未満になった
	if (correctColinearPoints(polygon) < 0) return -1; // 削除された結果、点の個数が3個未満になった
	if (correctSamePoints(polygon) < 0) return -1; // 共線上の点が削除されたことで、同じ点が連続する状態になることがあるため要再チェック
	if (checkSelfIntersection(polygon) < 0) return -2; // 自己交差あり
	if (!isClockwise(polygon)) reverse(polygon); // 反時計回りの場合、点列の順序を逆転
	return 0;
}
int PolygonUtil::simplify_(Polygon_ polygon)
{
	Polygon_ tmp = Polygon_(new Polygon);
	tmp->assign(polygon->begin(), polygon->end());
	if (correctSamePoints_(tmp) < 0) return -1;
	if (correctColinearPoints_(tmp) < 0) return -1;
	if (correctSamePoints_(tmp) < 0) return -1;
	polygon->swap(*tmp);
	return 0;
}

int PolygonUtil::simplify2_correctSamePoints(Polygon_ polygon)
{
	const size_t n = polygon->size();
	int s = -1;
	for (int i = 0; i < n; ++i) {
		if (polygon->at(prevIndex(i, n)) == polygon->at(i)) continue;
		s = i;
		break;
	}
	if (s < 0) return -1;
	Polygon_ tmp = Polygon_(new Polygon);
	tmp->push_back(polygon->at(s));
	for (int i = nextIndex(s, n); i != s; i = nextIndex(i, n)) {
		const Point2D &p = polygon->at(i);
		if (p == tmp->back()) continue;
		tmp->push_back(p);
	}
	polygon->swap(*tmp);
	return 0;
}
int PolygonUtil::simplify2_correctColinearPoints(Polygon_ polygon)
{
	const size_t n = polygon->size();
	Polygon_ tmp = Polygon_(new Polygon);
	const std::vector<double> angles = getSegmentAngles(polygon);
	for (int i = 0; i < n; ++i) {
		double a0 = angles[prevIndex(i, n)];
		double a1 = angles[i];
		if (angleEquals(a0, a1) || angleEquals(a0, a1 + M_PI)) continue;
		tmp->push_back(polygon->at(i));
	}
	polygon->swap(*tmp);
	return 0;
}
int PolygonUtil::simplify2_checkPolygon(Polygon_ polygon)
{
	while (true) {
		const size_t n = polygon->size();
		if (simplify2_correctSamePoints(polygon) < 0) return -1;
		if (polygon->size() < 3) return -1;
		simplify2_correctColinearPoints(polygon);
		if (polygon->size() < 3) return -1;
		if (polygon->size() == n) break;
	}
	return 0;
}
int PolygonUtil::simplify2_omitConvexPoint(Polygon_ polygon, double *areaDecreased)
{
	const double areaMax = area(polygon);
	*areaDecreased = areaMax;
	const size_t n = polygon->size();
	const std::vector<double> angles = getSegmentAngles(polygon);
	typedef struct {
		int index;
		double area;
	} IndexArea;
	std::vector<IndexArea> indexAreas;
	for (int i = 0; i < n; ++i) {
		double a0 = angles[prevIndex(i, n)];
		double a1 = angles[i];
		if (normalizeRadian(a1 - a0) > 0.0) continue; // 凹頂点の場合
		IndexArea indexArea;
		indexArea.index = i;
		indexArea.area = area(polygon->at(prevIndex(i, n)), polygon->at(i), polygon->at(nextIndex(i, n)));
		indexAreas.push_back(indexArea);
	}
	std::sort(indexAreas.begin(), indexAreas.end(), [](IndexArea ia1, IndexArea ia2) -> int { return (ia1.area < ia2.area); });
	for (int i = 0; i < indexAreas.size(); ++i) {
		const IndexArea &indexArea = indexAreas[i];
		Polygon_ tmp = Polygon_(new Polygon);
		tmp->assign(polygon->begin(), polygon->end());
		omitPoint(tmp, indexArea.index);
		if (simplify2_checkPolygon(tmp) < 0) continue;
		if (checkSelfIntersection(tmp) < 0) continue;
		polygon->swap(*tmp);
		*areaDecreased = indexArea.area;
		return 0;
	}
	// 想定外のエラー
	return -1;
}
int PolygonUtil::simplify2_cutOffConcaveEdge(Polygon_ polygon, double *areaDecreased)
{
	Point2D bbMin;
	Point2D bbMax;
	boundingBox(polygon, &bbMin, &bbMax);
	const double lengthMax = length(bbMin, bbMax);
	const double areaMax = area(polygon);
	*areaDecreased = areaMax;

	const size_t n = polygon->size();
	const Segments_ segments = createSegments(polygon);
	const std::vector<double> angles = getAngles(segments);

	Polygon_ result = Polygon_(new Polygon);
	result->assign(polygon->begin(), polygon->end());
	double areaMin = areaMax;
	for (int i = 0; i < n; ++i) {
		const int prev = prevIndex(i, n);
		const int next = nextIndex(i, n);
		const Point2D &p0 = polygon->at(prev);
		const Point2D &p1 = polygon->at(i);
		const Point2D &p2 = polygon->at(next);
		const Segment &s01 = segments->at(prev);
		const Segment &s12 = segments->at(i);
		const double angle01 = angles[prev];
		const double angle12 = angles[i];
		if (normalizeRadian(angle12 - angle01) < 0.0) continue; // 凸頂点の場合
		Point2D pc;
		int index;
		double lengthMin;

		for (int dummy = 0; dummy < 1; ++dummy) {
			// 凹頂点の前側の辺(s01)の凹頂点(p1)側を延長して最初にぶつかる他の辺との交点を求める
			index = -1;
			lengthMin = lengthMax;
			for (int j = 0; j < n; ++j) {
				if (j == prev || j == i) continue; // 頂点iをはさむ2辺は対象外
				const Segment &sTmp = segments->at(j);
				Point2D pcTmp;
				if (crossPoint(s01, sTmp, &pcTmp) != 0) continue; // 交点なし(平行、または同一直線上)
				if (!sTmp.contains_(pcTmp)) continue; // 交点が相手側セグメントの範囲外
				const double length0 = length(p0, pcTmp);
				const double length1 = length(p1, pcTmp);
				if (length0 < length1) continue; // 交点がp0側
				if (length1 < lengthMin) {
					lengthMin = length1;
					index = j;
					pc = pcTmp;
				}
			}
			if (index < 0) {
				break; // 想定外のエラー
			}
			// 分割線[p1, pc]の左側のポリゴン(polygon[i]...polygon[j], pc)
			Polygon_ polygon01L = Polygon_(new Polygon);
			for (int j = i; j != nextIndex(index, n); j = nextIndex(j, n)) {
				polygon01L->push_back(polygon->at(j));
			}
			polygon01L->push_back(pc);
			simplify2_checkPolygon(polygon01L); // 頂点数が3個未満でも続行
			// 分割線[p1, pc]の右側のポリゴン(polygon[j+1]...polygon[i-1], pc)
			Polygon_ polygon01R = Polygon_(new Polygon);
			for (int j = nextIndex(index, n); j != i; j = nextIndex(j, n)) {
				polygon01R->push_back(polygon->at(j));
			}
			polygon01R->push_back(pc);
			simplify2_checkPolygon(polygon01R); // 頂点数が3個未満でも続行
			// 小さい方のポリゴンの面積がareaMinより小さい場合、大きい方のポリゴンを結果ポリゴンとする
			double area01L = polygon01L->size() < 3 ? 0.0 : area(polygon01L);
			double area01R = polygon01R->size() < 3 ? 0.0 : area(polygon01R);
			if (area01L < 0.0 || area01R < 0.0) {
				break; // 想定外のエラー
			}
			if (area01L + area01R < areaMax - 1 || area01L + area01R > areaMax + 1) {
				break; // 面積のズレが大きすぎる
			}
			if (area01L < areaMin || area01R < areaMin) {
				if (area01L < area01R) {
					areaMin = area01L;
					result->swap(*polygon01R);
				} else {
					areaMin = area01R;
					result->swap(*polygon01L);
				}
			}
		}

		for (int dummy = 0; dummy < 1; ++dummy) {
			// 凹頂点の後側の辺(s12)の凹頂点(p1)側を延長して最初にぶつかる他の辺との交点を求める
			index = -1;
			lengthMin = lengthMax;
			for (int j = 0; j < n; ++j) {
				if (j == prev || j == i) continue; // 頂点iをはさむ2辺は対象外
				const Segment &sTmp = segments->at(j);
				Point2D pcTmp;
				if (crossPoint(s12, sTmp, &pcTmp) != 0) continue; // 交点なし(平行、または同一直線上)
				if (!sTmp.contains_(pcTmp)) continue; // 交点が相手側セグメントの範囲外
				const double length1 = length(p1, pcTmp);
				const double length2 = length(p2, pcTmp);
				if (length2 < length1) continue; // 交点がp2側
				if (length1 < lengthMin) {
					lengthMin = length1;
					index = j;
					pc = pcTmp;
				}
			}
			if (index < 0) {
				break; // 想定外のエラー
			}
			// 分割線[p1, pc]の左側のポリゴン(polygon[i+1]...polygon[j], pc)
			Polygon_ polygon21L = Polygon_(new Polygon);
			for (int j = nextIndex(i, n); j != nextIndex(index, n); j = nextIndex(j, n)) {
				polygon21L->push_back(polygon->at(j));
			}
			polygon21L->push_back(pc);
			simplify2_checkPolygon(polygon21L); // 頂点数が3個未満でも続行
			// 分割線[p1, pc]の右側のポリゴン(polygon[j+1]...polygon[i], pc)
			Polygon_ polygon21R = Polygon_(new Polygon);
			for (int j = nextIndex(index, n); j != nextIndex(i, n); j = nextIndex(j, n)) {
				polygon21R->push_back(polygon->at(j));
			}
			polygon21R->push_back(pc);
			simplify2_checkPolygon(polygon21R); // 頂点数が3個未満でも続行
			// 小さい方のポリゴンの面積がareaMinより小さい場合、大きい方のポリゴンを結果ポリゴンとする
			double area21L = polygon21L->size() < 3 ? 0.0 : area(polygon21L);
			double area21R = polygon21R->size() < 3 ? 0.0 : area(polygon21R);
			if (area21L < 0.0 || area21R < 0.0) {
				break; // 想定外のエラー
			}
			if (area21L + area21R < areaMax - 1 || area21L + area21R > areaMax + 1) {
				break; // 面積のズレが大きすぎる
			}
			if (area21L < areaMin || area21R < areaMin) {
				if (area21L < area21R) {
					areaMin = area21L;
					result->swap(*polygon21R);
				} else {
					areaMin = area21R;
					result->swap(*polygon21L);
				}
			}
		}
	}
	if (areaMin < areaMax) {
		polygon->swap(*result);
		*areaDecreased = areaMin;
		return 0;
	}
	// 凹頂点なし、または想定外のエラー
	return -1;
}
int PolygonUtil::simplify2_internal(Polygon_ polygon)
{
	Polygon_ tmp1 = Polygon_(new Polygon);
	Polygon_ tmp2 = Polygon_(new Polygon);
	tmp1->assign(polygon->begin(), polygon->end());
	tmp2->assign(polygon->begin(), polygon->end());
	double areaDecreased1;
	double areaDecreased2;
	int ret1 = simplify2_omitConvexPoint(tmp1, &areaDecreased1);
	int ret2 = simplify2_cutOffConcaveEdge(tmp2, &areaDecreased2);
	if (ret1 < 0 && ret2 < 0) {
		return -1;
	}
	if (areaDecreased1 < areaDecreased2) {
		polygon->swap(*tmp1);
	} else {
		polygon->swap(*tmp2);
	}
	return 0;
}
int PolygonUtil::simplify2(Polygon_ polygon)
{
	const int SUCCESS = 0; // 正常終了
	const int ERR_01 = -1; // 頂点数が3個未満(結果ポリゴンは使用不可)
	const int ERR_02 = -2; // 自己交差あり(結果ポリゴンは使用不可)
	const int ERR_03 = -3; // 想定外のエラー(単純化の処理は途中までしか成功していないが、結果ポリゴンは使用可能)

	Polygon_ src1 = Polygon_(new Polygon);
	src1->assign(polygon->begin(), polygon->end());

	if (polygon->size() < 3) return ERR_01;
	if (simplify2_checkPolygon(polygon) < 0) return ERR_01;
	if (checkSelfIntersection(polygon) < 0) return ERR_02;
	if (!isClockwise(polygon)) reverse(polygon);

	Polygon_ src2 = Polygon_(new Polygon);
	src2->assign(polygon->begin(), polygon->end());

	while (true) {
		const size_t n = polygon->size();
		if (n == 3) break;
		const Segments_ segments = createSegments(polygon);
		const std::vector<double> angles = getAngles(segments);
		bool done = true;
		for (int i = 0; i < n; ++i) {
			double a0 = angles[prevIndex(i, n)];
			double a1 = angles[i];
			if (segments->at(i).length() < TOLERANCE_2 || fabs(normalizeRadian(a1 - a0)) < TOLERANCE_ANGLE_2 || fabs(normalizeRadian(a1 - a0 - M_PI)) < TOLERANCE_ANGLE_2) {
				done = false;
				break;
			}
		}
		if (done) break;
		Polygon_ tmp = Polygon_(new Polygon);
		tmp->assign(polygon->begin(), polygon->end());
		if (simplify2_internal(tmp) < 0) {
			return ERR_03; // 想定外のエラー
		}
		if (tmp->size() >= n) {
			return ERR_03; // 想定外のエラー
		}
		if (within(polygon, tmp)) {
			polygon->swap(*tmp);
			continue;
		}
		// 元のポリゴンからはみ出した場合
		// はみ出した部分のポリゴンを求める
		Polygons_ results = Polygons_(new Polygons);
		if (difference(tmp, polygon, results) == 0) {
			// 面積がTOLERANCE_AREA以下のポリゴンは返ってこない
			if (results->size() == 0) {
				polygon->swap(*tmp);
				continue;
			}
		}
		// はみ出した部分で、面積がTOLERANCE_AREAより大きいものがある場合 (または減算処理失敗)
		return ERR_03; // 想定外のエラー
	}
	return SUCCESS;
}

void PolygonUtil::omitPoint(Polygon_ polygon, int index)
{
	Polygon_ tmp = Polygon_(new Polygon);
	tmp->swap(*polygon);
	for (int i = 0; i < tmp->size(); ++i) {
		if (i == index) continue;
		polygon->push_back(tmp->at(i));
	}
}

PolygonUtil::Segments_ PolygonUtil::createSegments(const Polygon_ polygon)
{
	Segments_ segments = Segments_(new Segments);
	for (int i = 0; i < polygon->size(); ++i) {
		int next = nextIndex(i, polygon->size());
		const Point2D &p1 = polygon->at(i);
		const Point2D &p2 = polygon->at(next);
		segments->push_back(Segment(p1, p2));
	}
	return segments;
}

int PolygonUtil::correctSamePoints(Polygon_ polygon)
{
	Polygon_ tmp = Polygon_(new Polygon);
	for (int i = 0; i < polygon->size(); ++i) {
		const Point2D &p1 = polygon->at(i);
		const Point2D &p2 = polygon->at(nextIndex(i, polygon->size()));
		if (p2 == p1) continue; // 同じ点が連続した場合、前側の点を削除
		tmp->push_back(p1);
	}
	polygon->swap(*tmp);
	if (polygon->size() < 3) return -1;
	return 0;
}
int PolygonUtil::correctSamePoints_(Polygon_ polygon)
{
	Polygon_ tmp = Polygon_(new Polygon);
	for (int i = 0; i < polygon->size(); ++i) {
		const Point2D &p1 = polygon->at(i);
		Point2D &p2 = polygon->at(nextIndex(i, polygon->size()));
		if (fabs(p2.x - p1.x) < TOLERANCE_2 && fabs(p2.y - p1.y) < TOLERANCE_2) {
			p2.x = (p2.x + p1.x) * 0.5;
			p2.y = (p2.y + p1.y) * 0.5;
			continue;
		}
		tmp->push_back(p1);
	}
	polygon->swap(*tmp);
	if (polygon->size() < 3) return -1;
	return 0;
}

int PolygonUtil::correctColinearPoints(Polygon_ polygon)
{
	Polygon_ tmp = Polygon_(new Polygon);
	Segments_ segments = createSegments(polygon);
	double a0 = segments->at(segments->size() - 1).angle();
	double a1;
	for (int i = 0; i < segments->size(); ++i) {
		a1 = segments->at(i).angle();
		if (angleEquals(a0, a1) || angleEquals_(a0, a1 + M_PI)) {
			// ベクトルの向きが同じ、または逆向きの場合、中間点は削除
			// 逆向きの場合は共線の判定閾値を下げる
			continue;
		}
		tmp->push_back(polygon->at(i));
		a0 = a1;
	}
	polygon->swap(*tmp);
	if (polygon->size() < 3) return -1;
	return 0;
}
int PolygonUtil::correctColinearPoints_(Polygon_ polygon)
{
	Polygon_ tmp = Polygon_(new Polygon);
	Segments_ segments = createSegments(polygon);
	double a0 = segments->at(segments->size() - 1).angle();
	double a1;
	for (int i = 0; i < segments->size(); ++i) {
		a1 = segments->at(i).angle();
		if (angleEquals_(a0, a1) || angleEquals_(a0, a1 + M_PI)) {
			// ベクトルの向きが同じ、または逆向きの場合、中間点は削除
			// 逆向きの場合は共線の判定閾値を下げる
			continue;
		}
		tmp->push_back(polygon->at(i));
		a0 = a1;
	}
	polygon->swap(*tmp);
	if (polygon->size() < 3) return -1;
	return 0;
}

int PolygonUtil::checkSelfIntersection(Polygon_ polygon)
{
	Segments_ segments = createSegments(polygon);
	// 同じ辺同士、または隣り合う2辺ではチェックしない
	for (int i = 0; i + 2 < segments->size(); ++i) {
		int jmax = (i == 0) ? (int) segments->size() - 1 : (int) segments->size();
		for (int j = i + 2; j < jmax; ++j) {
			const Segment &s1 = segments->at(i);
			const Segment &s2 = segments->at(j);
			Point2D p;
			int ret = crossPoint(s1, s2, &p, true);
			if (ret == 0) {
				// 線分の範囲内で交点あり、つまり自己交差あり
				return -1;
			}
			if (ret == 2) {
				// 同一直線上で線分に重なりがある場合、自己交差ありと判定する
				return -1;
			}
			// 交点が線分の範囲外/平行線/同一直線上だが線分に重なりがない
			// つまり無関係
		}
	}
	return 0;
}

bool PolygonUtil::isClockwise(const Polygon_ &polygon)
{
	Segments_ segments = createSegments(polygon);
	// 角度の総和
	double sum = 0.0;
	for (int i = 0; i < segments->size(); ++i) {
		int next = nextIndex(i, segments->size());
		const Segment &s1 = segments->at(i);
		const Segment &s2 = segments->at(next);
		double angle = normalizeRadian(s2.angle() - s1.angle());
		sum += angle;
	}
	// 角度の総和は(自己交差がないかぎり)360度(反時計回り)か-360度(時計回り)のどちらかとなる
	return (sum < 0.0);
}

void PolygonUtil::reverse(Polygon_ polygon)
{
	Polygon_ tmp = Polygon_(new Polygon);
	tmp->swap(*polygon);
	polygon->push_back(tmp->at(0)); // 開始位置は変更しない
	for (int i = 1; i < tmp->size(); ++i) {
		polygon->push_back(tmp->at(tmp->size() - i));
	}
}



/**
 * ポリゴンをふとらせます。
 * UI用
 */
int PolygonUtil::thick(const Polygon_ &src, Polygon_ result, double width)
{
	if (width < 0) {
		return -4;
	}
	int ret;
	Polygon_ polygon = Polygon_(new Polygon);
	polygon->assign(src->begin(), src->end());
	ret = checkPolygon(polygon);
	if (ret < 0) {
		return ret;
	}
	Segments_ segments = createSegments(polygon);
	// シフト値の決定(領域の外側方向が正)
	std::vector<double> shiftValues;
	for (int i = 0; i < segments->size(); ++i) {
		shiftValues.push_back(width);
	}
	Polygons_ shiftPolygons = Polygons_(new Polygons);
	if (createShiftPolygons(segments, shiftValues, shiftPolygons) < 0) {
		return -3;
	}
	Polygons_ results = Polygons_(new Polygons);
	if (src->size() < 100) {
		// 頂点数が100個未満の場合、通常版を使用する
		ret = add(polygon, shiftPolygons, results);
	} else {
		// 頂点数が100個以上の場合、簡易版を使用する
		ret = add_(polygon, shiftPolygons, results);
	}
	if (ret < 0) {
		return -3;
	}
	if (results->size() == 0) {
		// 結果ポリゴンが返ってこない場合、加算処理失敗とみなす
		return -3; // boostの不具合回避のためにチェックしているが、現状では通らない
	}
	result->swap(*results->at(0));
	return 0;
}

/**
 * ポリゴンをやせさせます。
 * UI用
 */
int PolygonUtil::thin(const Polygon_ &src, Polygons_ results, double width) {
	if (width < 0) {
		return -4;
	}
	int ret;
	Polygon_ polygon = Polygon_(new Polygon);
	polygon->assign(src->begin(), src->end());
	ret = checkPolygon(polygon);
	if (ret < 0) {
		return ret;
	}
	Segments_ segments = createSegments(polygon);
	// シフト値の決定(領域の内側方向が負)
	std::vector<double> shiftValues;
	for (int i = 0; i < segments->size(); ++i) {
		shiftValues.push_back(-width);
	}
	Polygons_ shiftPolygons = Polygons_(new Polygons);
	if (createShiftPolygons(segments, shiftValues, shiftPolygons) < 0) {
		return -3;
	}
	ret = subtract_(polygon, shiftPolygons, results);
	if (ret < 0) {
		return -3;
	}
	return 0;
}



/**
 * ポリゴンをやせさせます。
 * @return 0 正常終了
 *        -1 異常終了(やせさせる処理が失敗した)
 *        -2 異常終了(結果ポリゴンの個数が0個)
 *        -3 異常終了(結果ポリゴンの個数が2個以上)
 * @throw E-PP-999 angle2Widthがマイナスの値を返した
 */
int PolygonUtil::thin5(Polygon_ src, Polygons_ results, Angles2Widths angles2Widths)
{
	int ret;
	// ポリゴンをやせさせる処理(1回目)凹頂点の補完点追加あり
	ret = thin5_main(src, results, angles2Widths, true, true);
	if (ret == 0) {
		return 0;
	}
	// ポリゴンをやせさせる処理(2回目)凹頂点の補完点追加なし
	ret = thin5_main(src, results, angles2Widths, false, true);
	if (ret == 0) {
		return 0;
	}
	return ret;

	// TODO:シフトポリゴンの生成に失敗した場合、凹凸凹頂点の削除を検討
}
// 圃場形状の単純化用
int PolygonUtil::thin5_simplify(Polygon_ src, Polygons_ results, double width, bool complement)
{
	return thin5_main(src, results, getAngles2Widths(&width), complement, true);
}
// 交差判定用ポリゴン(圃場)の計算用
int PolygonUtil::thin5_intersection(Polygon_ src, Polygons_ results, double width)
{
	return thin5_main(src, results, getAngles2Widths(&width), false, false);
}
// オフセット作業機(回り耕)の外周作業用HP
int PolygonUtil::thin5_offset(Polygon_ src, Polygons_ results, double width)
{
	return thin5_main(src, results, getAngles2Widths(&width), true, true);
}
/**
 * ポリゴンをやせさせます。
 * @param src 対象となるポリゴン
 * @param results やせさせたポリゴン
 * @param angle2Width 辺がx軸と為す角度を元に、やせさせる幅を返す関数(0未満の値が返ってきた場合、エラー)
 * @param complement 凹頂点に補完点を追加する/しない
 * @param feedback srcへのフィードバックを許可する/しない(trueの場合、srcポリゴンが書き換えられることがある)
 * @return 0 正常終了
 *        -1 異常終了(やせさせる処理が失敗した)
 *        -2 異常終了(結果ポリゴンの個数が0個)
 *        -3 異常終了(結果ポリゴンの個数が2個以上)
 * @throw E-PP-999 angle2Widthがマイナスの値を返した
 */
int PolygonUtil::thin5_main(Polygon_ src, Polygons_ results, Angles2Widths angles2Widths, bool complement, bool feedback)
{
	if (!feedback && complement) {
		throw std::runtime_error("E-PP-999");
	}
	Polygon_ tmpSrc = Polygon_(new Polygon);
	tmpSrc->assign(src->begin(), src->end());
	if (complement && thin5_easeConcave(tmpSrc) < 0) {
		// 凹頂点の補完点追加に失敗した
		return -1;
	}
	int ret = thin5_fraction(tmpSrc, results, angles2Widths);
	if (ret == -1) {
		// シフト値の刻み幅が閾値より小さくなった
		return -1;
	} else if (ret == -2 || ret == -3) {
		// 結果ポリゴンの個数が1個以外
		return ret;
	}
	// やせさせる処理が成功した
	Polygon_ result = results->at(0);

	// 結果ポリゴンの形状判定と調整
	Polygon_ tmpResult = Polygon_(new Polygon);
	tmpResult->assign(result->begin(), result->end());
	if (thin5_tryAddComplement(tmpSrc, tmpResult) == 0) {
		// 調整に成功した
		src->swap(*tmpSrc);
		result->swap(*tmpResult);
		debugPrint("thin5_main1.svg", src, result);
		return 0;
	}
	// 調整に失敗した場合、結果ポリゴンをふとらせてソースポリゴンへのフィードバックを試す
	if (!feedback) {
		// フィードバック不可の場合
		return -1;
	}

	// 簡易調整とチェック
	if (simplify_(result) < 0 || checkPolygon(result) < 0) {
		// 簡易調整とチェックに失敗した
		return -1; // フェールセーフのためにチェックしているが、現状では通らない
	}
	Polygons_ feedbackPolygons = Polygons_(new Polygons);
	if (thin5_feedback(result, feedbackPolygons, angles2Widths) < 0) {
		// ふとらせる処理が失敗した
		return -1;
	}
	if (feedbackPolygons->size() != 1) {
		// 結果ポリゴンの個数が1個以外
		return -1; // boostの不具合回避のためにチェックしているが、現状では通らない
	}
	Polygon_ feedbackPolygon = feedbackPolygons->at(0);
	// フィードバックポリゴンの形状判定と調整
	if (thin5_tryAddComplement(result, feedbackPolygon) < 0) {
		// 調整に失敗した
		return -1;
	}
	// フィードバックポリゴンがソースポリゴンからはみ出していないかチェック
	if (!within(src, feedbackPolygon)) {
		// フィードバックポリゴンがソースポリゴンからはみ出している
		return -1;
	}
	src->swap(*feedbackPolygon);
	debugPrint("thin5_main2.svg", src, result);
	return 0;
}
/**
 * ポリゴンをやせさせます。(分割シフト対応版の本体)
 * @return 0 正常終了
 *        -1 異常終了(シフト値の刻み幅が閾値より小さくなった)
 *        -2 異常終了(結果ポリゴンの個数が0個)
 *        -3 異常終了(結果ポリゴンの個数が2個以上)
 * @throw E-PP-999 angle2Widthがマイナスの値を返した
 */
int PolygonUtil::thin5_fraction(const Polygon_ &src, Polygons_ results, Angles2Widths angles2Widths)
{
	const double ERROR_THRESHOLD = 0.01;
	Polygon_ tmpSrc = Polygon_(new Polygon);
	tmpSrc->assign(src->begin(), src->end());
	double rest = 1.0;
	int div = 1;
	while (rest > 0.0) {
		// シフト値の刻み幅
		double fraction = rest / div;
		if (fraction < ERROR_THRESHOLD) {
			// シフト値の刻み幅が閾値より小さくなった場合は諦める
			return -1;
		}
		// やせさせる
		if (thin5_fractionBase(tmpSrc, results, angles2Widths, fraction) < 0) {
			// やせさせる処理が失敗した場合、シフト値の分割係数を増やして(刻み幅を小さくして)リトライ
			div *= 2;
			continue;
		}
		if (results->size() < 1) {
			// 結果ポリゴンの個数が0個の場合
			return -2;
		}
		if (results->size() > 1) {
			// 結果ポリゴンの個数が2個以上の場合
			return -3;
		}
		// 結果ポリゴンの個数が1個の場合
		Polygon_ result = results->at(0);
		// やせさせた前後で形状が維持できているか判定する(辺が消えるのは許容するが、増えるのは不許可)
		if (checkAngles(getSegmentAngles(src), getSegmentAngles(result)) < 0) {
			// 形状が維持できていない場合、シフト値の分割係数を増やして(刻み幅を小さくして)リトライ
			div *= 2;
			continue;
		}
		// 形状が維持できている場合、成功した刻み幅分減らして、分割係数を1に戻して処理継続
		rest -= fraction;
		div = 1;
		tmpSrc->clear();
		tmpSrc->assign(result->begin(), result->end());
	}
	return 0;
}
/**
 * ポリゴンをやせさせます。(分割シフト対応版の基本ロジック)
 * @return 0 正常終了
 *        -1 異常終了(やせさせる処理が失敗した)
 * @throw E-PP-999 angle2Widthがマイナスの値を返した
 */
int PolygonUtil::thin5_fractionBase(const Polygon_ &src, Polygons_ results, Angles2Widths angles2Widths, double fraction)
{
	Segments_ segments = createSegments(src);
	std::vector<double> shiftValues = angles2Widths(getAngles(segments));
	for (int i = 0; i < shiftValues.size(); ++i) {
		if (shiftValues[i] < 0.0) {
			// システムエラー
			throw std::runtime_error("E-PP-999");
		}
		shiftValues[i] *= -fraction;
	}
	Polygons_ shiftPolygons = Polygons_(new Polygons);
	if (createShiftPolygons(segments, shiftValues, shiftPolygons) < 0) {
		// シフトポリゴンの生成に失敗した場合
		debugPrint("thin5_fractionBase_createShiftPolygons.svg", src);
		return -1;
	}
	if (subtract(src, shiftPolygons, results) < 0) {
		// 減算処理に失敗した場合
		debugPrint("thin5_fractionBase_subtract.svg", src, shiftPolygons);
		return -1;
	}
	return 0;
}
/**
 * 折れ曲がり角度が+120度以上の鋭角凹頂点に補完点を追加してスパイクを緩和します。
 * @return 0 正常終了
 *        -1 異常終了(checkPolygon失敗)
 */
int PolygonUtil::thin5_easeConcave(Polygon_ polygon)
{
	const double M_2PI_3 = M_PI * 2.0 / 3.0;
	std::vector<double> angles = getSegmentAngles(polygon);
	double a0 = angles[prevIndex(0, (int) angles.size())];
	double a1;
	Polygon_ tmp = Polygon_(new Polygon);
	for (int i = 0; i < angles.size(); ++i) {
		a1 = angles[i];
		if (normalizeRadian(a1 - a0) < M_2PI_3) {
			tmp->push_back(polygon->at(i));
		} else {
			const Point2D &p = polygon->at(i);
			tmp->push_back(Point2D(p.x - std::cos(a0) * TOLERANCE_2, p.y - std::sin(a0) * TOLERANCE_2));
			tmp->push_back(Point2D(p.x + std::cos(a1) * TOLERANCE_2, p.y + std::sin(a1) * TOLERANCE_2));
		}
		a0 = a1;
	}
	if (checkPolygon(tmp) < 0) {
		debugPrint("thin5_easeConcave.svg", polygon);
		return -1;
	}
	polygon->swap(*tmp);
	return 0;
}
/**
 * 折れ曲がり角度が-120度以下の鋭角凸頂点に補完点を追加してスパイクを緩和します。
 * @return 0 正常終了
 *        -1 異常終了(checkPolygon失敗)
 */
int PolygonUtil::thin5_easeConvex(Polygon_ polygon)
{
	const double M_2PI_3 = M_PI * 2.0 / 3.0;
	std::vector<double> angles = getSegmentAngles(polygon);
	double a0 = angles[prevIndex(0, (int) angles.size())];
	double a1;
	Polygon_ tmp = Polygon_(new Polygon);
	for (int i = 0; i < angles.size(); ++i) {
		a1 = angles[i];
		if (normalizeRadian(a1 - a0) > -M_2PI_3) {
			tmp->push_back(polygon->at(i));
		} else {
			const Point2D &p = polygon->at(i);
			tmp->push_back(Point2D(p.x - std::cos(a0) * TOLERANCE_2, p.y - std::sin(a0) * TOLERANCE_2));
			tmp->push_back(Point2D(p.x + std::cos(a1) * TOLERANCE_2, p.y + std::sin(a1) * TOLERANCE_2));
		}
		a0 = a1;
	}
	if (checkPolygon(tmp) < 0) {
		debugPrint("thin5_easeConvex.svg", polygon);
		return -1;
	}
	polygon->swap(*tmp);
	return 0;
}
/**
 * dstを調整してsrcと同じ形状にします。
 * @return 0 正常終了
 *        -1 異常終了(調整失敗)
 */
int PolygonUtil::thin5_tryAddComplement(const Polygon_ &src, Polygon_ dst)
{
	if (src->size() < dst->size()) {
		// srcの方が頂点数が少ない場合
		return -1;
	}
	std::vector<double> srcAngles = getSegmentAngles(src);
	std::vector<double> dstAngles = getSegmentAngles(dst);
	// 辺の角度を比較
	int pos = checkAngles(srcAngles, dstAngles);
	if (pos < 0) {
		// 対応する辺が存在しないものがあった(または、辺の角度の並び順が一致しなかった)
		return -1;
	}
	// dst側の辺は全て、src側に対応する辺が存在していた(かつ、辺の角度の並び順も一致していた)

	// 位置ずれを修正(最終的にはdst側を調整することになるが、ここではいったんsrc側を調整する)
	Polygon_ tmp = Polygon_(new Polygon);
	for (int i = pos; i < src->size(); ++i) {
		tmp->push_back(src->at(i));
	}
	for (int i = 0; i < pos; ++i) {
		tmp->push_back(src->at(i));
	}
	srcAngles.clear();
	srcAngles = getSegmentAngles(tmp);

	// dst側に欠けている辺を特定して、順番に追加していく
	while (dst->size() < src->size()) {
		dstAngles.clear();
		dstAngles = getSegmentAngles(dst);
		if (checkAngles(srcAngles, dstAngles) != 0) {
			// src側が調整済みなので、0でなければ何かが失敗している
			return -1;
		}
		// src側にだけ含まれている辺の位置を特定する
		pos = 0;
		while (pos < dstAngles.size() && angleEquals_(dstAngles[pos], srcAngles[pos])) {
			++pos;
		}
		// src側の次の辺と比較する
		if (!angleEquals_(dstAngles[pos == dstAngles.size() ? 0 : pos], srcAngles[nextIndex(pos, srcAngles.size())])) {
			// src側の次の辺とも一致しない場合、連続する2個以上の辺が欠けている
			return -1;
		}
		// dst側に欠けている辺を追加する
		tmp->clear();
		// 辺の角度が一致するところまで追加
		for (int i = 0; i < pos; ++i) {
			tmp->push_back(dst->at(i));
		}
		// 欠けている辺の追加
		double dx = cos(srcAngles[pos]) * TOLERANCE;
		double dy = sin(srcAngles[pos]) * TOLERANCE;
		if (pos == dstAngles.size()) {
			pos = 0;
		}
		Point2D p1 = dst->at(pos);
		Point2D p2 = dst->at(pos);
		p1.x -= dx;
		p1.y -= dy;
		p2.x += dx;
		p2.y += dy;
		tmp->push_back(p1);
		if (pos == 0) {
			tmp->at(0) = p2;
		} else {
			tmp->push_back(p2);
			// 残りの辺の追加
			for (int i = pos + 1; i < dst->size(); ++i) {
				tmp->push_back(dst->at(i));
			}
		}
		dst->swap(*tmp);
	}
	// 調整後のポリゴンに対して形状を判定する
	srcAngles.clear();
	srcAngles = getSegmentAngles(src);
	dstAngles.clear();
	dstAngles = getSegmentAngles(dst);
	pos = checkAngles(srcAngles, dstAngles);
	if (pos < 0) {
		return -1;
	}
	// アライメントの調整
	tmp->clear();
	for (int i = (int) dst->size() - pos; i < dst->size(); ++i) {
		tmp->push_back(dst->at(i));
	}
	for (int i = 0; i < dst->size() - pos; ++i) {
		tmp->push_back(dst->at(i));
	}
	dst->swap(*tmp);
	return 0;
}
/**
 * 簡易版
 */
int PolygonUtil::thin5_feedback(Polygon_ src, Polygons_ results, double width, bool complement)
{
	return thin5_feedback(src, results, getAngles2Widths(&width), true, complement);
}
/**
 * ポリゴンをふとらせます。
 * @return 0 正常終了
 *        -1 異常終了(ふとらせる処理が失敗した)
 * @throw E-PP-999 angle2Widthがマイナスの値を返した
 */
int PolygonUtil::thin5_feedback(Polygon_ src, Polygons_ results, Angles2Widths angles2Widths, bool increase, bool complement)
{
	// フィードバック時は凸頂点に補完点を追加する
	if (complement && thin5_easeConvex(src) < 0) {
		// 凸頂点の補完点追加に失敗した場合
		return -1;
	}
	Segments_ segments = createSegments(src);
	std::vector<double> shiftValues = angles2Widths(getAngles(segments));
	for (int i = 0; i < shiftValues.size(); ++i) {
		if (shiftValues[i] < 0.0) {
			// システムエラー
			throw std::runtime_error("E-PP-999");
		}
		shiftValues[i] = std::max(shiftValues[i] - TOLERANCE, TOLERANCE);
	}
	Polygons_ shiftPolygons = Polygons_(new Polygons);
	if (createShiftPolygons(segments, shiftValues, shiftPolygons, increase) < 0) {
		// シフトポリゴンの生成に失敗した場合
		debugPrint("thin5_feedback_createShiftPolygons.svg", src);
		return -1;
	}
	if (add(src, shiftPolygons, results) < 0 && add_(src, shiftPolygons, results) < 0) {
		// 加算処理に失敗した場合
		debugPrint("thin5_feedback_add.svg", src, shiftPolygons);
		return -1;
	}
	return 0;
}
int PolygonUtil::thin5_thick(Polygon_ src, Polygons_ results, Angles2Widths angles2Widths, bool increase)
{
	// フィードバック時は凸頂点に補完点を追加する
	if (thin5_easeConvex(src) < 0) {
		// 凸頂点の補完点追加に失敗した場合
		return -1;
	}
	Segments_ segments = createSegments(src);
	std::vector<double> shiftValues = angles2Widths(getAngles(segments));
	for (int i = 0; i < shiftValues.size(); ++i) {
		if (shiftValues[i] < 0.0) {
			// システムエラー
			throw std::runtime_error("E-PP-999");
		}
	}
	Polygons_ shiftPolygons = Polygons_(new Polygons);
	if (createShiftPolygons(segments, shiftValues, shiftPolygons, increase) < 0) {
		// シフトポリゴンの生成に失敗した場合
		debugPrint("thin5_thick_createShiftPolygons.svg", src);
		return -1;
	}
	if (add(src, shiftPolygons, results) < 0 && add_(src, shiftPolygons, results) < 0) {
		// 加算処理に失敗した場合
		debugPrint("thin5_thick_add.svg", src, shiftPolygons);
		return -1;
	}
	return 0;
}
/**
 * シフトの最大値を取得します。
 */
int PolygonUtil::thin5_getShiftValueMax(const Polygon_ &src, const Polygon_ &result, double sideMarginAngle, double *headlandMax, double *sideMarginMax, std::vector<double> *widths, bool skipShortEdge)
{
	if (!headlandMax || !sideMarginMax || result->size() != src->size()) throw std::runtime_error("E-PP-999");
	widths->clear();
	*headlandMax = -1.0;
	*sideMarginMax = -1.0;
	Segments_ srcSegments = createSegments(src);
	Segments_ resultSegments = createSegments(result);
	for (int i = 0; i < src->size(); ++i) {
		const Segment &s1 = srcSegments->at(i);
		const Segment &s2 = resultSegments->at(i);
		if (skipShortEdge && (s1.length() < 0.01 || s2.length() < 0.01)) {
			// フラグが立っている場合、1cm未満の辺は枕地幅・サイドマージンの最大値計算から除外する
			widths->push_back(-1);
			continue;
		}
		// 線分の位置関係をチェック (平行性のチェックはしていないが、左右(s1が左であること)のチェックはすべき)
		// 位置関係が正しければ、s1.p2->s2.p2が右折
		const Segment &s12 = Segment(s1.p2, s2.p2);
		double a1 = s1.angle();
		double a12 = s12.angle();
		if (normalizeRadian(a12 - a1) > 0) {
			// 位置関係が入れ替わっている場合はエラー
			return -1;
		}
		// 平行な2線分間の距離(幅)
		double sum = 0.0;
		sum += PolygonUtil::perpendicularLength(s1.p1, s2);
		sum += PolygonUtil::perpendicularLength(s1.p2, s2);
		sum += PolygonUtil::perpendicularLength(s2.p1, s1);
		sum += PolygonUtil::perpendicularLength(s2.p2, s1);
		double d = sum / 4.0;
		double angle = s1.angle();
		double angleY = fabs(fabs(angle) - M_PI_2);
		if (angleY < sideMarginAngle) {
			*sideMarginMax = std::max(*sideMarginMax, d);
		} else {
			*headlandMax = std::max(*headlandMax, d);
		}
		widths->push_back(d);
	}
	return 0;
}
/**
 * orgField(オリジナルの圃場形状)とworkingArea(作業領域ポリゴン)の対応が取れていない場合を想定
 * 対応が取れる辺だけを対象として、枕地幅とサイドマージンの最大値を取得します。
 * headlandMax,sideMarginMax,widthsには計算済みの値が入っているものとします。
 */
double diffAngle(double angles1, double angles2) {
	double diff = angles2 - angles1;
	if (diff >  M_PI) diff -= M_PI_X2;
	if (diff < -M_PI) diff += M_PI_X2;
	return diff;
}
int PolygonUtil::thin5_getShiftValueMax2(const Polygon_ &orgField, const Polygon_ &workingArea, double sideMarginAngle, double *headlandMax, double *sideMarginMax, std::vector<double> *widths, bool skipShortEdge) {
	if (!headlandMax || !sideMarginMax || !widths || widths->size() != workingArea->size()) throw std::runtime_error("E-PP-999");
	const Segments_ segmentsF = createSegments(orgField);
	const Segments_ segmentsW = createSegments(workingArea);

	typedef std::pair<int, double> index2width;
	std::vector<index2width> index2widths;
	index2widths.assign(workingArea->size(), { -1, -1 });
	bool updated = true;
	while (updated) {
		updated = false;
		for (int i = 0; i < segmentsW->size(); ++i) {
			const Segment sW = segmentsW->at(i);
			for (int j = 0; j < segmentsF->size(); ++j) {
				const Segment sF = segmentsF->at(j);
				if (!angleEquals_(sF.angle(), sW.angle())) {
					// 角度が違う場合
					continue;
				}
				const Segment sTmp = Segment(sF.p1, sW.p2);
				if (diffAngle(sF.angle(), sTmp.angle()) > 0) {
					// sWがsFの左にある場合
					continue;
				}
				// 角度が同じ、かつsWがsFの右にある場合
				double sum = 0.0;
				sum += PolygonUtil::perpendicularLength(sF.p1, sW);
				sum += PolygonUtil::perpendicularLength(sF.p2, sW);
				sum += PolygonUtil::perpendicularLength(sW.p1, sF);
				sum += PolygonUtil::perpendicularLength(sW.p2, sF);
				double d = sum / 4.0;
				if (index2widths[i].first < 0 || d < index2widths[i].second) {
					// 初回、または現在ペアリング中の辺より近い場合
					bool hasPair = false;
					for (int k = 0; k < index2widths.size(); ++k) {
						if (index2widths[k].first == j) {
							// 他の辺とペアリング中
							hasPair = true;
							if (d < index2widths[k].second) {
								// 相手側が現在ペアリング中の辺より近い場合、現在のペアリングを切る
								index2widths[k] = { -1, -1 };
								index2widths[i] = { j, d };
								updated = true;
							}
							break;
						}
					}
					if (!hasPair) {
						// 相手側がペアリング中でなければペアリング
						index2widths[i] = { j, d };
					}
				}
			}
		}
	}
	// 念の為、index2widthsに同じindexが設定されていないかチェック
	for (int i = 0; i < index2widths.size(); ++i) {
		for (int j = 0; j < index2widths.size(); ++j) {
			if (i == j) continue;
			if (index2widths[i].first < 0 || index2widths[j].first < 0) continue;
			if (index2widths[i].first == index2widths[j].first) {
				// index2widthsに同じindexが設定されている
				throw std::runtime_error("E-PP-999");
			}
		}
	}
	// ペアリング結果のチェック
	int indexW = -1;
	for (int i = 0; i < index2widths.size(); ++i) {
		if (index2widths[i].first >= 0) {
			indexW = i;
			break;
		}
	}
	if (indexW < 0) {
		// ペアリングできた辺が1個もない場合
		return 0;
	}
	int indexF = index2widths[indexW].first;
	for (int i = nextIndex(indexW, index2widths.size()); i != indexW; i = nextIndex(i, index2widths.size())) {
		if (index2widths[i].first < 0) {
			// ペアリングされてない辺はスキップ
			continue;
		}
		while (true) {
			indexF = nextIndex(indexF, orgField->size());
			if (indexF == index2widths[indexW].first) {
				// 1周回ってしまった場合、オリジナルのBPを使用した枕地幅の計算を諦める (エラーにはしない)
				// return -1;
				return 0;
			}
			if (indexF == index2widths[i].first) {
				break;
			}
		}
	}
	// ペアリング結果OK
	for (int i = 0; i < index2widths.size(); ++i) {
		if (index2widths[i].first >= 0 && index2widths[i].second > widths->at(i)) {
			if (skipShortEdge && widths->at(i) < 0) {
				// フラグが立っている場合、枕地幅・サイドマージンが事前に計算されていない辺を除外する
				continue;
			}
			widths->at(i) = index2widths[i].second;
			double angleY = fabs(fabs(segmentsW->at(i).angle()) - M_PI_2);
			if (angleY < sideMarginAngle) {
				*sideMarginMax = std::max(*sideMarginMax, index2widths[i].second);
			} else {
				*headlandMax = std::max(*headlandMax, index2widths[i].second);
			}
		}
	}
	return 0;
}
/**
 * 凸頂点の削除を試します。(削除によって減少する面積が最小となるような凸頂点を削除します)
 * @param polygon 対象となるポリゴン(処理成功時、書き換えられます)
 * @param areaDecreased 分割切除によって減少した面積
 * @return 0 正常終了
 *        -1 異常終了
 */
int PolygonUtil::thin5_omitConvexPoint(Polygon_ polygon, double *areaDecreased)
{
	Point2D bbMin;
	Point2D bbMax;
	boundingBox(polygon, &bbMin, &bbMax);
	const double areaMax = (bbMax.x - bbMin.x) * (bbMax.y - bbMin.y);
	*areaDecreased = areaMax;
	const size_t n = polygon->size();
	const Segments_ segments = createSegments(polygon);
	const std::vector<double> angles = getAngles(segments);

	std::set<int> failed;
	while (polygon->size() - failed.size() > 3) {
		int index = -1;
		double areaMin = areaMax;
		double angle01 = angles[prevIndex(0, n)];
		double angle12;
		// その頂点を削除した場合に減少する面積が、最小な凸頂点を探す
		for (int i = 0; i < n; ++i) {
			if (failed.find(i) != failed.end()) {
				continue;
			}
			angle12 = angles[i];
			if (normalizeRadian(angle12 - angle01) < 0.0) {
				// 凸頂点の場合、面積を計算
				double areaTmp = area(polygon->at(prevIndex(i, n)), polygon->at(i), polygon->at(nextIndex(i, n)));
				if (areaTmp < areaMin) {
					areaMin = areaTmp;
					index = i;
				}
			}
			angle01 = angle12;
		}
		if (index < 0) {
			return -1;
		}
		Polygon_ tmp = Polygon_(new Polygon);
		tmp->assign(polygon->begin(), polygon->end());
		omitPoint(tmp, index);
		if (simplify_(tmp) == 0 && checkPolygon(tmp) == 0 && within(polygon, tmp)) {
			// 頂点の削除に成功した
			debugPrint("thin5_omitConvexPoint.svg", polygon, tmp);
			polygon->swap(*tmp);
			*areaDecreased = areaMin;
			return 0;
		}
		failed.insert(index);
	}
	return -1;
}
/**
 * 凹頂点をはさむ辺での分割切除を試します。
 * @param polygon 対象となるポリゴン(処理成功時、書き換えられます)
 * @param areaDecreased 分割切除によって減少した面積
 * @return 0 正常終了
 *        -1 異常終了
 */
int PolygonUtil::thin5_cutOffConcaveEdge(Polygon_ polygon, double *areaDecreased)
{
	Point2D bbMin;
	Point2D bbMax;
	boundingBox(polygon, &bbMin, &bbMax);
	const double lengthMax = length(bbMin, bbMax);
	const double areaMax = (bbMax.x - bbMin.x) * (bbMax.y - bbMin.y);
	*areaDecreased = areaMax;
	const size_t n = polygon->size();
	const Segments_ segments = createSegments(polygon);
	const std::vector<double> angles = getAngles(segments);

	Polygon_ result = Polygon_(new Polygon);
	result->assign(polygon->begin(), polygon->end());
	double areaMin = areaMax;
	for (int i = 0; i < n; ++i) {
		const int prev = prevIndex(i, n);
		const int next = nextIndex(i, n);
		const Point2D &p0 = polygon->at(prev);
		const Point2D &p1 = polygon->at(i);
		const Point2D &p2 = polygon->at(next);
		const Segment &s01 = segments->at(prev);
		const Segment &s12 = segments->at(i);
		const double angle01 = angles[prev];
		const double angle12 = angles[i];
		if (normalizeRadian(angle12 - angle01) < 0.0) {
			// 凸頂点の場合
			continue;
		}
		// 凹頂点の場合
		int index = -1;
		Point2D pc;
		double lengthMin;

		// 凹頂点の前側の辺(s01)の凹頂点(p1)側を延長して最初にぶつかる他の辺との交点を求める
		lengthMin = lengthMax;
		for (int j = 0; j < n; ++j) {
			if (j == prev || j == i) {
				// 頂点iをはさむ2辺は対象外
				continue;
			}
			Point2D pcTmp;
			const Segment &sTmp = segments->at(j);
			if (crossPoint(s01, sTmp, &pcTmp) != 0) {
				// 交点なし(平行、または同一直線上)
				// 同一直線上の場合、交点の求まる別の辺が存在するはずなので、ここでは処理不要
				continue;
			} else if (!sTmp.contains_(pcTmp)) {
				// 交点が相手側セグメントの範囲外
				continue;
			}
			const double length0 = length(p0, pcTmp);
			const double length1 = length(p1, pcTmp);
			if (length1 > length0) {
				// 交点がp0側
				continue;
			}
			// 最初にぶつかる他の辺か
			if (length1 < lengthMin) {
				lengthMin = length1;
				index = j;
				pc = pcTmp;
			}
		}
		if (index < 0) {
			return -1;
		}
		// 分割線[p1, pc]の左側のポリゴン(polygon[i]...polygon[j], pc)
		Polygon_ polygon01L = Polygon_(new Polygon);
		for (int j = i; j != nextIndex(index, n); j = nextIndex(j, n)) {
			polygon01L->push_back(polygon->at(j));
		}
		polygon01L->push_back(pc);
		correctSamePoints_(polygon01L);
		checkPolygon(polygon01L);
		// 分割線[p1, pc]の右側のポリゴン(polygon[j+1]...polygon[i-1], pc)
		Polygon_ polygon01R = Polygon_(new Polygon);
		for (int j = nextIndex(index, n); j != i; j = nextIndex(j, n)) {
			polygon01R->push_back(polygon->at(j));
		}
		polygon01R->push_back(pc);
		correctSamePoints_(polygon01R);
		checkPolygon(polygon01R);
		// 小さい方のポリゴンの面積がareaMinより小さい場合、大きい方のポリゴンを結果ポリゴンとする
		double area01L = polygon01L->size() < 3 ? 0.0 : area(polygon01L);
		double area01R = polygon01R->size() < 3 ? 0.0 : area(polygon01R);
		if (area01L < area01R) {
			if (area01L < areaMin) {
				areaMin = area01L;
				result->swap(*polygon01R);
			}
		} else {
			if (area01R < areaMin) {
				areaMin = area01R;
				result->swap(*polygon01L);
			}
		}

		// 凹頂点の後側の辺(s12)の凹頂点(p1)側を延長して最初にぶつかる他の辺との交点を求める
		lengthMin = lengthMax;
		for (int j = 0; j < n; ++j) {
			if (j == prev || j == i) {
				// 頂点iをはさむ2辺は対象外
				continue;
			}
			Point2D pcTmp;
			const Segment &sTmp = segments->at(j);
			if (crossPoint(s12, sTmp, &pcTmp) != 0) {
				// 交点なし(平行、または同一直線上)
				// 同一直線上の場合、交点の求まる別の辺が存在するはずなので、ここでは処理不要
				continue;
			} else if (!sTmp.contains_(pcTmp)) {
				// 交点が相手側セグメントの範囲外
				continue;
			}
			const double length1 = length(p1, pcTmp);
			const double length2 = length(p2, pcTmp);
			if (length1 > length2) {
				// 交点がp2側
				continue;
			}
			// 最初にぶつかる他の辺か
			if (length1 < lengthMin) {
				lengthMin = length1;
				index = j;
				pc = pcTmp;
			}
		}
		if (index < 0) {
			return -1;
		}
		// 分割線[p1, pc]の左側のポリゴン(polygon[i+1]...polygon[j], pc)
		Polygon_ polygon21L = Polygon_(new Polygon);
		for (int j = nextIndex(i, n); j != nextIndex(index, n); j = nextIndex(j, n)) {
			polygon21L->push_back(polygon->at(j));
		}
		polygon21L->push_back(pc);
		correctSamePoints_(polygon21L);
		checkPolygon(polygon21L);
		// 分割線[p1, pc]の右側のポリゴン(polygon[j+1]...polygon[i], pc)
		Polygon_ polygon21R = Polygon_(new Polygon);
		for (int j = nextIndex(index, n); j != nextIndex(i, n); j = nextIndex(j, n)) {
			polygon21R->push_back(polygon->at(j));
		}
		polygon21R->push_back(pc);
		correctSamePoints_(polygon21R);
		checkPolygon(polygon21R);
		// 小さい方のポリゴンの面積がareaMinより小さい場合、大きい方のポリゴンを結果ポリゴンとする
		double area21L = polygon21L->size() < 3 ? 0.0 : area(polygon21L);
		double area21R = polygon21R->size() < 3 ? 0.0 : area(polygon21R);
		if (area21L < area21R) {
			if (area21L < areaMin) {
				areaMin = area21L;
				result->swap(*polygon21R);
			}
		} else {
			if (area21R < areaMin) {
				areaMin = area21R;
				result->swap(*polygon21L);
			}
		}
	}
	if (areaMin < areaMax) {
		debugPrint("thin5_cutOffConcaveEdge.svg", polygon, result);
		polygon->swap(*result);
		*areaDecreased = areaMin;
		return 0;
	}
	return -1;
}





// やせさせた前後で形状が変化していないかチェックする
// やせさせることで辺の数が減少することは許容する
// 各辺の角度について、angles1がangles2を全て含んでいる、かつ並び順が同じ
// 条件を満たす場合、位置がどれだけずれたかを返す(>=0)
// 条件を満たさない場合、-1を返す
int PolygonUtil::checkAngles(const std::vector<double> &angles1, const std::vector<double> &angles2)
{
	for (int i = 0; i < angles1.size(); ++i) {
		if (!angleEquals_(angles1[i], angles2[0])) {
			// 1個目がマッチングしない場合は、すぐ次へ
			continue;
		}
		// 2個目以降のマッチング処理
		int i1 = nextIndex(i, angles1.size());
		int i2 = 1;
		// どちらかがぐるっと回るまでループを回す
		while (i1 != i && i2 < angles2.size()) {
			if (angleEquals_(angles1[i1], angles2[i2])) {
				++i2;
			}
			i1 = nextIndex(i1, angles1.size());
		}
		if (i2 == angles2.size()) {
			// angles2側がぐるっと回った場合
			// angles2は、順序も含めて全てangles1に含まれていた
			return i;
		}
	}
	return -1;
}
PolygonUtil::Angles2Widths PolygonUtil::getAngles2Widths(double *width)
{
	Angles2Widths angles2Widths = [width](std::vector<double> angles) -> std::vector<double> {
		std::vector<double> widths;
		for (int i = 0; i < angles.size(); ++i) {
			widths.push_back(*width);
		}
		return widths;
	};
	return angles2Widths;
}


int PolygonUtil::createShiftPolygons(const Segments_ &segments, std::vector<double> &shiftValues, Polygons_ shiftPolygons, bool increase)
{
	const int RETRY_MAX = (int) segments->size() * 10;
	int retry = 0;
	while (retry < RETRY_MAX) {
		int ret = createShiftPolygons_internal(segments, shiftValues, shiftPolygons, increase);
		if (ret == 0) {
			// 正常終了
			return 0;
		} else if (ret < 0) {
			// エラー(シフト値の調整が限界)
			return -1;
		}
		++retry;
	}
	// リトライ回数の上限を超えた
	return -1;
}
int PolygonUtil::createShiftPolygons_internal(const Segments_ &segments, std::vector<double> &shiftValues, Polygons_ shiftPolygons, bool increase)
{
	shiftPolygons->clear();
	// シフトさせたセグメントをを生成
	// ベクトルの向きを反時計回りに90度回転させたものがシフト方向(領域の外側方向が正)
	Segments_ shiftSegments = Segments_(new Segments);
	for (int i = 0; i < segments->size(); ++i) {
		shiftSegments->push_back(shiftSegment(segments->at(i), shiftValues.at(i)));
	}
	// セグメントごとに加算用／減算用ポリゴンのリストを生成
	for (int i = 0; i < shiftSegments->size(); ++i) {
		int prev = prevIndex(i, shiftSegments->size());
		int next = nextIndex(i, shiftSegments->size());
		Segment &src0 = segments->at(prev);
		Segment &src1 = segments->at(i);
		Segment &src2 = segments->at(next);
		Segment &shiftSegment0 = shiftSegments->at(prev);
		Segment &shiftSegment1 = shiftSegments->at(i);
		Segment &shiftSegment2 = shiftSegments->at(next);
		double shiftValue0 = shiftValues.at(prev);
		double shiftValue1 = shiftValues.at(i);
		double shiftValue2 = shiftValues.at(next);
		double angle01 = normalizeRadian(shiftSegment1.angle() - shiftSegment0.angle());
		double angle12 = normalizeRadian(shiftSegment2.angle() - shiftSegment1.angle());
		// シフトポリゴン用の頂点を生成
		Polygon_ shiftPolygon = Polygon_(new Polygon);
		shiftPolygon->push_back(src1.p1);
		shiftPolygon->push_back(src1.p2);
		// shiftSegment1.p2側の頂点
		Point2D crossPoint12;
		crossPoint(shiftSegment1, shiftSegment2, &crossPoint12);
		if (shiftValue1 * angle12 > 0.0) {
			// シフト方向と折れ曲がり方向が同じ場合
			// やせさせる(-)、凸頂点(-)
			// ふとらせる(+)、凹頂点(+)
			if (fabs(angle12) > M_PI_2 + 0.1) {
				// 折れ曲がりの角度が90度より大きい場合
				// シフトさせたセグメントの端点をそのまま採用
				shiftPolygon->push_back(shiftSegment1.p2);
			} else if (fabs(angle12) > M_PI_2 - 0.1) {
				// 折れ曲がりの角度が90度付近の場合
				// シフトさせたセグメントと隣の辺との交点を採用
				Point2D pTmp;
				crossPoint(shiftSegment1, src2, &pTmp);
				shiftPolygon->push_back(pTmp);
			} else {
				// 折れ曲がりの角度が90度より小さい場合
				if (!angleEquals(Segment(shiftSegment1.p1, crossPoint12).angle(), shiftSegment1.angle()) || !angleEquals(Segment(crossPoint12, shiftSegment2.p2).angle(), shiftSegment2.angle())) {
					if (fabs(shiftValue1) < fabs(shiftValue2)) {
						double newShiftValue1;
						if (shiftSegment1.contains(perpendicularPoint(shiftSegment2.p1, shiftSegment1))) {
							// shiftValue1を増やしていくと、shiftSegment2.p1がshiftSegment1にぶつかる場合
							// src1からshiftSegment2.p1までの距離が必要なシフト値
							newShiftValue1 = perpendicularLength(shiftSegment2.p1, src1);
						} else {
							// shiftValue1を増やしていくと、shiftSegment1.p1がshiftSegment2にぶつかる場合
							// src1.p1からshiftSegment2までの距離をcos(fabs(angle12))で割ったものが必要なシフト値
							newShiftValue1 = perpendicularLength(src1.p1, shiftSegment2) / cos(fabs(angle12));
						}
						if (newShiftValue1 > fabs(shiftValue1) && newShiftValue1 < fabs(shiftValue2) && increase) {
							if (shiftValue1 < 0.0) {
								newShiftValue1 *= -1.0;
							}
							shiftValues[i] = newShiftValue1;
							// リトライ
							return 1;
						}
					}
				}
				if (angleEquals(Segment(shiftSegment1.p2, crossPoint12).angle(), shiftSegment1.angle())) {
					Point2D pTmp;
					pTmp.x = crossPoint12.x + shiftSegment1.x / shiftSegment1.length() * 0.001;
					pTmp.y = crossPoint12.y + shiftSegment1.y / shiftSegment1.length() * 0.001;
					shiftPolygon->push_back(pTmp);
				} else {
					shiftPolygon->push_back(shiftSegment1.p2);
				}
			}
		} else {
			// シフト方向と折れ曲がり方向が違う場合
			// やせさせる(-)、凹頂点(+)
			// ふとらせる(+)、凸頂点(-)
			Segment sTmp1 = Segment(shiftSegment1.p1, crossPoint12);
			Segment sTmp2 = Segment(crossPoint12, shiftSegment2.p2);
			if (angleEquals(sTmp1.angle(), shiftSegment1.angle()) && sTmp1.length() > shiftSegment1.length() - TOLERANCE &&
				angleEquals(sTmp2.angle(), shiftSegment2.angle()) && sTmp2.length() > shiftSegment2.length() - TOLERANCE) {
				// crossPoint12がshiftSegment1.p2の外側、かつshiftSegment2.p1の外側の場合
				// シフトさせたセグメント同士の交点を採用
				shiftPolygon->push_back(crossPoint12);
			} else if (!increase) {
				shiftPolygon->push_back(crossPoint12);
			} else {
				// angle12の角度が浅い、かつshiftValue1とshiftValue2の差が大きい、かつシフト値が小さい方のセグメントが短い場合
				// 小さい方のシフト値を必要な分だけ増やす
				if (fabs(shiftValue1) < fabs(shiftValue2)) {
					// src1からshiftSegment2.p1までの距離が必要なシフト値
					double newShiftValue1 = perpendicularLength(shiftSegment2.p1, src1);
					if (newShiftValue1 < fabs(shiftValue1) - TOLERANCE_2) {
						// リトライしても無駄なのでエラー
						return -1;
					}
					if (shiftValue1 < 0.0) {
						newShiftValue1 *= -1.0;
					}
					shiftValues[i] = newShiftValue1;
				} else {
					// src2からshiftSegment1.p2までの距離が必要なシフト値
					double newShiftValue2 = perpendicularLength(shiftSegment1.p2, src2);
					if (newShiftValue2 < fabs(shiftValue2) - TOLERANCE_2) {
						// リトライしても無駄なのでエラー
						return -1;
					}
					if (shiftValue2 < 0.0) {
						newShiftValue2 *= -1.0;
					}
					shiftValues[next] = newShiftValue2;
				}
				// リトライ
				return 1;
			}
		}
		// shiftSegment1.p1側の頂点
		Point2D crossPoint01;
		crossPoint(shiftSegment0, shiftSegment1, &crossPoint01);
		if (shiftValue1 * angle01 > 0.0) {
			// シフト方向と折れ曲がり方向が同じ場合
			// やせさせる(-)、凸頂点(-)
			// ふとらせる(+)、凹頂点(+)
			if (fabs(angle01) > M_PI_2 + 0.1) {
				// 折れ曲がりの角度が90度より大きい場合
				// シフトさせたセグメントの端点をそのまま採用
				shiftPolygon->push_back(shiftSegment1.p1);
			} else if (fabs(angle01) > M_PI_2 - 0.1) {
				// 折れ曲がりの角度が90度付近の場合
				// シフトさせたセグメントと隣の辺との交点を採用
				Point2D pTmp;
				crossPoint(shiftSegment1, src0, &pTmp);
				shiftPolygon->push_back(pTmp);
			} else {
				// 折れ曲がりの角度が90度より小さい場合
				if (!angleEquals(Segment(crossPoint01, shiftSegment1.p2).angle(), shiftSegment1.angle()) || !angleEquals(Segment(shiftSegment0.p1, crossPoint01).angle(), shiftSegment0.angle())) {
					if (fabs(shiftValue1) < fabs(shiftValue0)) {
						double newShiftValue1;
						if (shiftSegment1.contains(perpendicularPoint(shiftSegment0.p2, shiftSegment1))) {
							// shiftValue1を増やしていくと、shiftSegment0.p2がshiftSegment1にぶつかる場合
							// src1からshiftSegment0.p2までの距離が必要なシフト値
							newShiftValue1 = perpendicularLength(shiftSegment0.p2, src1);
						} else {
							// shiftValue1を増やしていくと、shiftSegment1.p2がshiftSegment0にぶつかる場合
							// src1.p2からshiftSegment2までの距離をcos(fabs(angle01))で割ったものが必要なシフト値
							newShiftValue1 = perpendicularLength(src1.p2, shiftSegment0) / cos(fabs(angle01));
						}
						if (newShiftValue1 > fabs(shiftValue1) && newShiftValue1 < fabs(shiftValue0) && increase) {
							if (shiftValue1 < 0.0) {
								newShiftValue1 *= -1.0;
							}
							shiftValues[i] = newShiftValue1;
							// リトライ
							return 1;
						}
					}
				}
				if (angleEquals(Segment(crossPoint01, shiftSegment1.p1).angle(), shiftSegment1.angle())) {
					Point2D pTmp;
					pTmp.x = crossPoint01.x - shiftSegment1.x / shiftSegment1.length() * 0.001;
					pTmp.y = crossPoint01.y - shiftSegment1.y / shiftSegment1.length() * 0.001;
					shiftPolygon->push_back(pTmp);
				} else {
					shiftPolygon->push_back(shiftSegment1.p1);
				}
			}
		} else {
			// シフト方向と折れ曲がり方向が違う場合
			// やせさせる(-)、凹頂点(+)
			// ふとらせる(+)、凸頂点(-)
			Segment sTmp1 = Segment(crossPoint01, shiftSegment1.p2);
			Segment sTmp0 = Segment(shiftSegment0.p1, crossPoint01);
			if (angleEquals(sTmp1.angle(), shiftSegment1.angle()) && sTmp1.length() > shiftSegment1.length() - TOLERANCE &&
				angleEquals(sTmp0.angle(), shiftSegment0.angle()) && sTmp0.length() > shiftSegment0.length() - TOLERANCE) {
				// crossPoint01がshiftSegment1.p1の外側、かつshiftSegment0.p2の外側の場合
				// シフトさせたセグメント同士の交点を採用
				shiftPolygon->push_back(crossPoint01);
			} else if (!increase) {
				shiftPolygon->push_back(crossPoint01);
			} else {
				// angle01の角度が浅い、かつshiftValue1とshiftValue0の差が大きい、かつシフト値が小さい方のセグメントが短い場合
				// 小さい方のシフト値を必要な分だけ増やす
				if (fabs(shiftValue1) < fabs(shiftValue0)) {
					// src1からshiftSegment0.p2までの距離が必要なシフト値
					double newShiftValue1 = perpendicularLength(shiftSegment0.p2, src1);
					if (newShiftValue1 < fabs(shiftValue1) - TOLERANCE_2) {
						// リトライしても無駄なのでエラー
						return -1;
					}
					if (shiftValue1 < 0.0) {
						newShiftValue1 *= -1.0;
					}
					shiftValues[i] = newShiftValue1;
				} else {
					// src0からshiftSegment1.p1までの距離が必要なシフト値
					double newShiftValue0 = perpendicularLength(shiftSegment1.p1, src0);
					if (newShiftValue0 < fabs(shiftValue0) - TOLERANCE_2) {
						// リトライしても無駄なのでエラー
						return -1;
					}
					if (shiftValue0 < 0.0) {
						newShiftValue0 *= -1.0;
					}
					shiftValues[prev] = newShiftValue0;
				}
				// リトライ
				return 1;
			}
		}
		if (shiftValue1 > 0.0) {
			// 外側にシフトする場合、点列の順序を逆転
			reverse(shiftPolygon);
		}
		if (checkPolygon(shiftPolygon) < 0) {
			// TODO:不正なポリゴンを生成してしまうことがある。リトライで回避可能なので暫定で-1を返しておく
			return -1;
		}
		shiftPolygons->push_back(shiftPolygon);
	}
	// 正常終了
	return 0;
}


int PolygonUtil::add(const Polygon_ &srcPolygon, const Polygons_ &shiftPolygons, Polygons_ resultPolygons)
{
	try {
		std::vector<BoostPolygon> results;
		results.push_back(polygon2BoostPolygon(srcPolygon));
		for (int i = 0; i < shiftPolygons->size(); ++i) {
			BoostPolygon addPolygon = polygon2BoostPolygon(shiftPolygons->at(i));
			std::vector<BoostPolygon> tmp;
			boost::geometry::union_(results[0], addPolygon, tmp);
			if (tmp.size() != 1) {
				// boostの不具合回避(辺を共有している図形同士の加算処理で結果が1個の図形にまとまらないことがある)
				// または、simplify_/checkPolygonのせいで隙間が出来た可能性もあり
				// 面積がTOLERANCE_AREA未満のポリゴンは計算誤差によるゴミとして無視する
				Polygons_ tmpPolygons = Polygons_(new Polygons);
				for (int j = 0; j < tmp.size(); ++j) {
					Polygon_ tmpPolygon = boostPolygon2Polygon(tmp[j]);
					if (area(tmpPolygon) < TOLERANCE_AREA) {
						continue;
					}
					tmpPolygons->push_back(tmpPolygon);
				}
				if (tmpPolygons->size() != 1) {
					return -1;
				}
				// ゴミを除外して1個の場合は処理を継続
				tmp.clear();
				tmp.push_back(polygon2BoostPolygon(tmpPolygons->at(0)));
			}
			Polygon_ p = boostPolygon2Polygon(tmp[0]);
			// boostの不具合回避(計算誤差のためと思われるが、自己交差する図形を返してくることがある)
			if (simplify_(p) < 0 || checkPolygon(p) < 0) {
				return -1;
			}
			results.clear();
			results.push_back(polygon2BoostPolygon(p));
		}
		resultPolygons->clear();
		resultPolygons->push_back(boostPolygon2Polygon(results[0]));
	} catch (const std::exception& e) {
		return -1;
	}
	return 0;
}
// 頂点数が多い場合に処理時間が長くなりすぎるための簡易版(boost::geometry::union_が失敗することがある)
int PolygonUtil::add_(const Polygon_ &srcPolygon, const Polygons_ &shiftPolygons, Polygons_ resultPolygons)
{
	try {
		std::vector<BoostPolygon> results;
		results.push_back(polygon2BoostPolygon(srcPolygon));
		for (int i = 0; i < shiftPolygons->size(); ++i) {
			BoostPolygon addPolygon = polygon2BoostPolygon(shiftPolygons->at(i));
			std::vector<BoostPolygon> tmp;
			boost::geometry::union_(results[0], addPolygon, tmp);
			if (tmp.size() != 1) {
				// boostの不具合回避(辺を共有している図形同士の加算処理で結果が1個の図形にまとまらないことがある)
				return -1;
			}
			results.clear();
			results.push_back(tmp[0]);
		}
		Polygon_ p = boostPolygon2Polygon(results[0]);
		if (simplify_(p) < 0 || checkPolygon(p) < 0) {
			return -1;
		}
		resultPolygons->clear();
		resultPolygons->push_back(p);
	} catch (const std::exception& e) {
		return -1;
	}
	return 0;
}

int PolygonUtil::subtract(const Polygon_ &srcPolygon, const Polygons_ &shiftPolygons, Polygons_ resultPolygons)
{
	try {
		std::vector<BoostPolygon> results;
		results.push_back(polygon2BoostPolygon(srcPolygon));
		for (int i = 0; i < shiftPolygons->size(); ++i) {
			BoostPolygon subtractPolygon = polygon2BoostPolygon(shiftPolygons->at(i));
			std::vector<BoostPolygon> out;
			for (int j = 0; j < results.size(); ++j) {
				std::vector<BoostPolygon> tmp;
				boost::geometry::difference(results[j], subtractPolygon, tmp);
				int count = 0;
				for (int k = 0; k < tmp.size(); ++k) {
					Polygon_ p = boostPolygon2Polygon(tmp[k]);
					// boostの不具合回避(計算誤差のためと思われるが、微小な面積を持つゴミ図形や、自己交差する図形を返してくることがある)
					if (simplify_(p) < 0) {
						continue;
					}
					if (checkPolygon(p) < 0) {
						return -1;
					}
					++count;
					out.push_back(polygon2BoostPolygon(p));
				}
				if (count == 0 && boost::geometry::area(results[j]) > boost::geometry::area(subtractPolygon)) {
					// boostの不具合回避(面積の大きい図形から面積の小さい図形を引いているのに、結果が返ってこないことがある)
					return -1;
				}
			}
			results.swap(out);
		}
		resultPolygons->clear();
		double areaMax = TOLERANCE_AREA;
		for (int i = 0; i < results.size(); ++i) {
			const BoostPolygon &bp = results[i];
			double a = boost::geometry::area(bp);
			if (a > areaMax) {
				areaMax = a;
				resultPolygons->clear();
				resultPolygons->push_back(boostPolygon2Polygon(bp));
			}
		}
	} catch (const std::exception& e) {
		return -1;
	}
	return 0;
}
// UI用
int PolygonUtil::subtract_(const Polygon_ &srcPolygon, const Polygons_ &shiftPolygons, Polygons_ resultPolygons)
{
	try {
		std::vector<BoostPolygon> results;
		results.push_back(polygon2BoostPolygon(srcPolygon));
		for (int i = 0; i < shiftPolygons->size(); ++i) {
			BoostPolygon subtractPolygon = polygon2BoostPolygon(shiftPolygons->at(i));
			std::vector<BoostPolygon> out;
			for (int j = 0; j < results.size(); ++j) {
				std::vector<BoostPolygon> tmp;
				boost::geometry::difference(results[j], subtractPolygon, tmp);
				int count = 0;
				for (int k = 0; k < tmp.size(); ++k) {
					Polygon_ p = boostPolygon2Polygon(tmp[k]);
					// boostの不具合回避(計算誤差のためと思われるが、微小な面積を持つゴミ図形や、自己交差する図形を返してくることがある)
					if (simplify_(p) < 0) {
						continue;
					}
					if (checkPolygon(p) < 0) {
						return -1;
					}
					++count;
					out.push_back(polygon2BoostPolygon(p));
				}
				if (count == 0 && boost::geometry::area(results[j]) > boost::geometry::area(subtractPolygon)) {
					// boostの不具合回避(面積の大きい図形から面積の小さい図形を引いているのに、結果が返ってこないことがある)
					return -1;
				}
			}
			results.swap(out);
		}
		resultPolygons->clear();
		for (int i = 0; i < results.size(); ++i) {
			const BoostPolygon &bp = results[i];
			double a = boost::geometry::area(bp);
			if (a > TOLERANCE_AREA) {
				resultPolygons->push_back(boostPolygon2Polygon(bp));
			}
		}
	} catch (const std::exception& e) {
		return -1;
	}
	return 0;
}

double PolygonUtil::area(const Polygon_ &polygon)
{
	return boost::geometry::area(polygon2BoostPolygon(polygon));
}
double PolygonUtil::area(const Point2D &p1, const Point2D &p2, const Point2D &p3)
{
	Segment s = Segment(p1, p2);
	return s.length() * perpendicularLength(p3, s) * 0.5;
}

bool PolygonUtil::intersects(const Polygon_ &polygon1, const Polygon_ &polygon2)
{
	return boost::geometry::intersects(polygon2BoostPolygon(polygon1), polygon2BoostPolygon(polygon2));
}

int PolygonUtil::union_(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygons_ resultPolygons) {
	std::vector<BoostPolygon> results;
	try {
		boost::geometry::union_(polygon2BoostPolygon(polygon1), polygon2BoostPolygon(polygon2), results);
	} catch (const std::exception& e) {
		return -1;
	}
	for (int i = 0; i < results.size(); ++i) {
		const BoostPolygon &bp = results[i];
		Polygon_ p = boostPolygon2Polygon(bp);
		int ret = checkPolygon(p);
		if (p->size() < 3) continue;
		if (ret < 0) return -1;
		resultPolygons->push_back(p);
	}
	return 0;
}

int PolygonUtil::difference(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygons_ resultPolygons)
{
	std::vector<BoostPolygon> results;
	try {
		boost::geometry::difference(polygon2BoostPolygon(polygon1), polygon2BoostPolygon(polygon2), results);
	} catch (const std::exception& e) {
		return -1;
	}
	for (int i = 0; i < results.size(); ++i) {
		const BoostPolygon &bp = results[i];
		double area = boost::geometry::area(bp);
		if (area > TOLERANCE_AREA) {
			Polygon_ p = boostPolygon2Polygon(bp);
			int ret = checkPolygon(p);
			if (p->size() < 3) continue;
			if (ret < 0) return -1;
			resultPolygons->push_back(p);
		}
	}
	return 0;
}
/**
 * 作業領域から非作業領域を減算します。
 * 作業領域と非作業領域の統合判定専用
 */
int PolygonUtil::difference2(const Polygon_ &workingArea, const Polygon_ &nonWorkingArea, Polygons_ subtracted, std::vector<Point2D> *crossPoints)
{
	// 交点が非作業領域ポリゴン上のどこにあるか
	std::set<int> indexes;
	Segments_ nwaSegments = createSegments(nonWorkingArea);
	for (int i = 0; i < crossPoints->size(); ++i) {
		for (int j = 0; j < nwaSegments->size(); ++j) {
			if (perpendicularLength(crossPoints->at(i), nwaSegments->at(j)) < TOLERANCE) {
				indexes.insert(j);
			}
		}
	}
	if (indexes.size() == 2) {
		// 交点の存在する辺が2個
		auto itr = indexes.begin();
		int i0 = *itr;
		++itr;
		int i1 = *itr;
		if (i1 - i0 == 2) {
			// 対面する2辺上にある場合
			return difference(workingArea, nonWorkingArea, subtracted);
		}
	}
	// 上記以外の場合
	// 交点の存在する辺の方向に非作業領域ポリゴンを拡張する
	Segments_ waSegments = createSegments(workingArea);
	Polygons_ modifiedNonWorkingAreas = Polygons_(new Polygons);
	for (auto itr = indexes.begin(); itr != indexes.end(); ++itr) {
		int index = *itr;
		int prev = prevIndex(index, nwaSegments->size());
		int next = nextIndex(index, nwaSegments->size());
		Segment prevSegment = nwaSegments->at(prev);
		Segment nextSegment = nwaSegments->at(next);
		if (!within(workingArea, prevSegment.p1) || !within(workingArea, nextSegment.p2)) {
			// prevSegment.p1がworkingAreaの外側、またはnextSegment.p2がworkingAreaの外側の場合、拡張不可
			continue;
		}
		double a;
		double d;
		bool b;
		// prevSegmentとworkingAreaの交点
		std::vector<Point2D> prevCrossPoints;
		for (int i = 0; i < waSegments->size(); ++i) {
			Segment s = waSegments->at(i);
			Point2D p;
			int ret = crossPoint(s, prevSegment, &p, false);
			if (ret == 0 && s.contains(p)) {
				// workingArea側の線分の範囲内で交点あり
				prevCrossPoints.push_back(p);
			}
		}
		// p1から見てp2と同じ方向で、p1からの距離が最も近い点を求める
		Point2D prevCrossPoint;
		a = prevSegment.angle();
		d = 1000000.0;
		b = false;
		for (int i = 0; i < prevCrossPoints.size(); ++i) {
			Point2D &p = prevCrossPoints[i];
			Segment s = Segment(prevSegment.p1, p);
			if (angleEquals_(s.angle(), a) && s.length() < d) {
				b = true;
				prevCrossPoint = p;
			}
		}
		if (!b) {
			continue;
		}
		// nextSegmentとworkingAreaの交点
		std::vector<Point2D> nextCrossPoints;
		for (int i = 0; i < waSegments->size(); ++i) {
			Segment s = waSegments->at(i);
			Point2D p;
			int ret = crossPoint(s, nextSegment, &p, false);
			if (ret == 0 && s.contains(p)) {
				// workingArea側の線分の範囲内で交点あり
				nextCrossPoints.push_back(p);
			}
		}
		// p2から見てp1と同じ方向で、p2からの距離が最も近い点を求める
		Point2D nextCrossPoint;
		a = nextSegment.angle();
		d = 1000000.0;
		b = false;
		for (int i = 0; i < nextCrossPoints.size(); ++i) {
			Point2D &p = nextCrossPoints[i];
			Segment s = Segment(p, nextSegment.p2);
			if (angleEquals_(s.angle(), a) && s.length() < d) {
				b = true;
				nextCrossPoint = p;
			}
		}
		if (!b) {
			continue;
		}
		// 拡張した非作業領域ポリゴン
		Polygon_ modifiedNonWorkingArea = Polygon_(new Polygon);
		Point2D ex = Point2D(prevSegment.x / prevSegment.length() * TOLERANCE_2, prevSegment.y / prevSegment.length() * TOLERANCE_2);
		modifiedNonWorkingArea->push_back(Point2D(nextCrossPoint.x + ex.x, nextCrossPoint.y + ex.y));
		for (int i = nextIndex(next, nonWorkingArea->size()); i != index; i = nextIndex(i, nonWorkingArea->size())) {
			modifiedNonWorkingArea->push_back(nonWorkingArea->at(i));
		}
		modifiedNonWorkingArea->push_back(Point2D(prevCrossPoint.x + ex.x, prevCrossPoint.y + ex.y));
		// prevCrossPointからnextCrossPointまでの間にあるworkingArea上の頂点を追加する
		int prevOnWorkingArea = -1;
		int nextOnWorkingArea = -1;
		for (int i = 0; i < waSegments->size(); ++i) {
			if (perpendicularLength(prevCrossPoint, waSegments->at(i)) < TOLERANCE) {
				prevOnWorkingArea = i;
				break;
			}
		}
		for (int i = 0; i < waSegments->size(); ++i) {
			if (perpendicularLength(nextCrossPoint, waSegments->at(i)) < TOLERANCE) {
				nextOnWorkingArea = i;
				break;
			}
		}
		if (prevOnWorkingArea < 0 || nextOnWorkingArea < 0) {
			continue;
		}
		for (int i = nextIndex(prevOnWorkingArea, workingArea->size()); i != nextIndex(nextOnWorkingArea, workingArea->size()); i = nextIndex(i, workingArea->size())) {
			modifiedNonWorkingArea->push_back(Point2D(workingArea->at(i).x + ex.x, workingArea->at(i).y + ex.y));
		}

		modifiedNonWorkingAreas->push_back(modifiedNonWorkingArea);
	}
	// 面積が最小のものを採用
	int index = -1;
	double minArea = 1000000.0;
	for (int i = 0; i < modifiedNonWorkingAreas->size(); ++i) {
		if (checkPolygon(modifiedNonWorkingAreas->at(i)) < 0) {
			continue;
		}
		BoostPolygon bp = polygon2BoostPolygon(modifiedNonWorkingAreas->at(i));
		double a = boost::geometry::area(bp);
		if (a < minArea) {
			minArea = a;
			index = i;
		}
	}
	if (index < 0) {
		return difference(workingArea, nonWorkingArea, subtracted);
	}
	return difference(workingArea, modifiedNonWorkingAreas->at(index), subtracted);
}
/**
 * 圃場領域から障害物領域を特殊減算します。
 */
int PolygonUtil::difference3(const Polygon_ &field, const Polygon_ &obstacle, Polygons_ results)
{
	assert(obstacle->size() == 4);
	results->clear();

	// 交差していないかチェック
	std::vector<Point2D> crossPoints;
	getCrossPoints(field, obstacle, &crossPoints);
	if (crossPoints.size() > 0) {
		// 交差している場合
		return difference2(field, obstacle, results, &crossPoints);
	}
	// 交差していない場合
	if (!within(field, obstacle)) {
		// 単純化の結果、障害物が完全に圃場外になっている場合
		// TODO:厳密に言えば within(obstacle, field)==true の可能性もある
		results->push_back(field);
		return 0;
	}
	// 障害物が完全に圃場内にある場合
	const Segments_ ssF = createSegments(field);
	const Segments_ ssO = createSegments(obstacle);
	Polygon_ newField = Polygon_(new Polygon);
	double areaMax = 0;
	// 4方向にチェック
	for (int i = 0; i < 4; ++i) {
		const int io0 = i;
		const int io1 = nextIndex(io0, obstacle->size());
		const int io2 = nextIndex(io1, obstacle->size());
		const int io3 = nextIndex(io2, obstacle->size());
		const Segment &so0 = ssO->at(io0);
		const Segment &so2 = ssO->at(io2);
		// so0をp2方向に延長した半直線とfieldの交点で、最も近い点を求める
		double dMin0 = 1000000;
		Point2D cp0;
		int if0 = -1;
		for (int j = 0; j < ssF->size(); ++j) {
			Segment sf = ssF->at(j);
			Point2D cp;
			int ret = crossPoint(so0, sf, &cp, false);
			if (ret == 0 && sf.contains_(cp)) {
				// field側の線分の範囲内で交点あり
				double d1 = length(so0.p1, cp);
				double d2 = length(so0.p2, cp);
				if (d2 < d1 && d2 < dMin0) {
					// 交点がso0.p2側、かつ近い
					dMin0 = d2;
					cp0 = cp;
					if0 = j;
				}
			}
		}
		if (if0 < 0) {
			// 想定外のエラー
			continue;
		}
		// so2をp1方向に延長した半直線とfieldの交点で、最も近い点を求める
		double dMin2 = 1000000;
		Point2D cp2;
		int if2 = -1;
		for (int j = 0; j < ssF->size(); ++j) {
			Segment sf = ssF->at(j);
			Point2D cp;
			int ret = crossPoint(so2, sf, &cp, false);
			if (ret == 0 && sf.contains_(cp)) {
				// field側の線分の範囲内で交点あり
				double d1 = length(so2.p1, cp);
				double d2 = length(so2.p2, cp);
				if (d1 < d2 && d1 < dMin2) {
					// 交点がso2.p1側、かつ近い
					dMin2 = d1;
					cp2 = cp;
					if2 = j;
				}
			}
		}
		if (if2 < 0) {
			// 想定外のエラー
			continue;
		}
		// 統合後の図形は
		// obstacle[io3], cp2, field[if2+1, if0], cp0, obstacle[io0]
		Polygon_ tmp = Polygon_(new Polygon);
		tmp->push_back(obstacle->at(io3));
		tmp->push_back(cp2);
		// if0==if2の可能性があるため、終了条件をj!=if0+1には出来ない
		for (int j = nextIndex(if2, field->size()); j != if0; j = nextIndex(j, field->size())) {
			tmp->push_back(field->at(j));
		}
		tmp->push_back(field->at(if0));
		tmp->push_back(cp0);
		tmp->push_back(obstacle->at(io0));
		if (simplify2(tmp) < 0) {
			// 想定外のエラー
			continue;
		}
		// 面積が最大となる統合方向を選択
		double a = area(tmp);
		if (a > areaMax) {
			areaMax = a;
			newField->swap(*tmp);
		}
	}
	if (areaMax == 0) {
		// 想定外のエラー
		return -1;
	}
	results->push_back(newField);
	return 0;
}

bool PolygonUtil::getCrossPoints(const Polygon_ &polygon1, const Polygon_ &polygon2, std::vector<Point2D> *crossPoints)
{
	bool collinear = false;
	crossPoints->clear();
	Segments_ segments1 = createSegments(polygon1);
	Segments_ segments2 = createSegments(polygon2);
	for (int i = 0; i < segments1->size(); ++i) {
		Segment s1 = segments1->at(i);
		for (int j = 0; j < segments2->size(); ++j) {
			Segment s2 = segments2->at(j);
			Point2D p;
			int ret = crossPoint(s1, s2, &p, true);
			if (ret == 0) {
				// 線分の範囲内で交点あり
				crossPoints->push_back(p);
			}
			if (ret == 2) {
				// 同一直線上で線分に重なりがある
				// つまり辺の共有あり
				collinear = true;
			}
		}
	}
	return collinear;
}

bool PolygonUtil::getCrossPoints(const Polygon_ &polygon, const Point2D &p1, const Point2D &p2, std::vector<Point2D> *crossPoints, bool checkSegment)
{
	bool collinear = false;
	crossPoints->clear();
	Segment s = Segment(p1, p2);
	Segments_ segments = createSegments(polygon);
	for (int i = 0; i < segments->size(); ++i) {
		Segment segment = segments->at(i);
		Point2D p;
		int ret = crossPoint(segment, s, &p, checkSegment);
		if (ret == 0) {
			// 線分の範囲内で交点あり
			crossPoints->push_back(p);
		}
		if (ret == 2) {
			// 同一直線上で線分に重なりがある
			// つまり辺の共有あり
			collinear = true;
		}
	}
	return collinear;
}

int PolygonUtil::crossPoint(const Segment &s1, const Segment &s2, Point2D *p, bool segment)
{
	if (segment && !checkRectIntersection(s1, s2)) {
		// 線分の交点を求める場合、矩形の交差判定に失敗した時点で交点なし(線分の重なりもないので1を返す)
		return 1;
	}
	double cross = crossProduct(s1, s2);
	double sin = cross / (s1.length() * s2.length());
	if (fabs(sin) < TOLERANCE_ANGLE) {
		double a, b, c;
		lineFormula(s2.p1, s2.p2, &a, &b, &c);
		double d1 = perpendicularLength(s1.p1, a, b, c);
		double d2 = perpendicularLength(s1.p2, a, b, c);
		if (d1 > TOLERANCE && d2 > TOLERANCE) {
			// 平行線
			return 1;
		}
		// 同一直線
		if (!segment) {
			return 2;
		}
		// 線分の重なりを判定
		Point2D s1min, s1max, s2min, s2max;
		s1.range(&s1min, &s1max);
		s2.range(&s2min, &s2max);
		if ((s1min.x < s2max.x + TOLERANCE && s2min.x < s1max.x + TOLERANCE) || (s1min.y < s2max.y + TOLERANCE && s2min.y < s1max.y + TOLERANCE)) {
			// 線分に重なりがある
			// (ロバストならxとyのどちらか片方だけチェックすれば十分だけど、誤差を許容しているため両方チェックしてorを取る)
			return 2;
		}
		// 線分に重なりがない
		return 1;
	}
	// 交点あり
	double rate = (s2.y * (s2.p1.x - s1.p1.x) - s2.x * (s2.p1.y - s1.p1.y)) / cross;
	p->x = s1.p1.x + rate * s1.x;
	p->y = s1.p1.y + rate * s1.y;
	if (!segment) {
		return 0;
	}
	// 交点が線分上の点か判定
	if (s1.contains(*p) && s2.contains(*p)) {
		// 交点が線分の範囲内
		return 0;
	}
	// 交点が線分の範囲外
	return 1;
}

bool PolygonUtil::within(const Polygon_ &polygon, const Point2D &p)
{
	return boost::geometry::within(point2BoostPoint(p), polygon2BoostPolygon(polygon));
}
bool PolygonUtil::within(const Polygon_ &outer, const Polygon_ &inner)
{
	return boost::geometry::within(polygon2BoostPolygon(inner), polygon2BoostPolygon(outer));
}

bool PolygonUtil::disjoint(const Polygon_ &polygon1, const Polygon_ &polygon2)
{
	return boost::geometry::disjoint(polygon2BoostPolygon(polygon1), polygon2BoostPolygon(polygon2));
}

int PolygonUtil::intersection(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygons_ results)
{
	std::vector<BoostPolygon> bps;
	try {
		boost::geometry::intersection(polygon2BoostPolygon(polygon1), polygon2BoostPolygon(polygon2), bps);
	} catch (const std::exception& e) {
		return -1;
	}
	results->clear();
	for (int i = 0; i < bps.size(); ++i) {
		const BoostPolygon &bp = bps[i];
		Polygon_ p = boostPolygon2Polygon(bp);
		if (simplify2_checkPolygon(p) < 0) continue;
		double a = boost::geometry::area(bp);
		if (a < TOLERANCE_AREA) continue;
		results->push_back(p);
	}
	return 0;
}
// 結果が必ず1個だけ返ってくる特殊なケースを想定した関数
int PolygonUtil::intersection(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygon_ result)
{
	std::vector<BoostPolygon> results;
	try {
		boost::geometry::intersection(polygon2BoostPolygon(polygon1), polygon2BoostPolygon(polygon2), results);
	} catch (const std::exception& e) {
		return -1;
	}
	double area = 0;
	for (int i = 0; i < results.size(); ++i) {
		const BoostPolygon &bp = results[i];
		Polygon_ p = boostPolygon2Polygon(bp);
		if (simplify2_checkPolygon(p) < 0) continue;
		double a = boost::geometry::area(bp);
		if (a > area) {
			area = a;
			result->swap(*p);
		}
	}
	if (area == 0) {
		return -1;
	}
	return 0;
}

void PolygonUtil::getIndexPos(const Segments_ &segments, const Point2D &p, int *index, double *pos) {
    *index = -1;
    *pos = 0;
    double minD = 1000000;
    for (int i = 0; i < segments->size(); ++i) {
        const Segment &s = segments->at(i);
        double a, b, c;
        lineFormula(s.p1, s.p2, &a, &b, &c);
        double coef1 = a * p.x + b * p.y + c;
        double coef2 = a * a + b * b;
        double d = fabs(coef1) / sqrt(coef2);
        if (d < minD) {
            double coef = coef1 / coef2;
            Point2D pp = Point2D(p.x - coef * a, p.y - coef * b);
            if (s.contains_(pp)) {
                minD = d;
                *index = i;
                *pos = length(s.p1, pp) / s.length();
            } else {
                double d1 = length(p, s.p1);
                double d2 = length(p, s.p2);
                d = d1 < d2 ? d1 : d2;
                if (d < minD) {
                    minD = d;
                    *index = i;
                    *pos = d1 < d2 ? 0 : 1;
                }
            }
        }
    }
}



// ポリゴンの加算/減算処理で頂点の対応がずれた場合に、頂点の順序を訂正する
double PolygonUtil::correctAlignment(const Polygon_ &src, Polygon_ &p)
{
	// オリジナルのセグメントがx軸と為す角度のリスト
	std::vector<double> srcAngles = getAngles(createSegments(src));
	// 結果ポリゴンのセグメントがx軸と為す角度のリストと比較して
	// 対応するセグメント同士の角度差の総和を求める
	double minDiffAngle = diffAngles(srcAngles, getAngles(createSegments(p)));

	Polygon_ shifted = Polygon_(new Polygon);
	shifted->assign(p->begin(), p->end());
	// 頂点の個数-1回のループ
	for (int i = 1; i < src->size(); ++i) {
		// 頂点配列の順序を1つ前にずらす
		shifted = shiftOrder(shifted);
		// 頂点配列の順序をずらしたポリゴンのセグメントがx軸と為す角度のリストと比較して
		// 対応するセグメント同士の角度差の総和を求める
		double diffAngle = diffAngles(srcAngles, getAngles(createSegments(shifted)));
		if (diffAngle < minDiffAngle) {
			// 角度差の総和が、より小さくなったら結果ポリゴンを更新する
			minDiffAngle = diffAngle;
			p->assign(shifted->begin(), shifted->end());
		}
	}
	return minDiffAngle;
}
// セグメントがx軸と為す角度のリストを取得する
std::vector<double> PolygonUtil::getAngles(const Segments_ &s)
{
	std::vector<double> angles;
	for (int i = 0; i < s->size(); ++i) {
		angles.push_back(s->at(i).angle());
	}
	return angles;
}
// 角度差の総和を求める
double PolygonUtil::diffAngles(const std::vector<double> &angles1, const std::vector<double> &angles2)
{
	double d = 0.0;
	for (int i = 0; i < angles1.size(); ++i) {
		double a = fabs(angles2[i] - angles1[i]);
		if (a > M_PI) {
			// 角度差が180度を超えている場合、反対側の角度を採用する
			a = M_PI_X2 - a;
		}
		d += a;
	}
	return d;
}
// 頂点配列の順序を1つ前にずらす
Polygon_ PolygonUtil::shiftOrder(const Polygon_ &p)
{
	Polygon_ shifted = Polygon_(new Polygon);
	// インデックスが1からsize()-1までの頂点を追加
	for (int i = 1; i < p->size(); ++i) {
		shifted->push_back(p->at(i));
	}
	// インデックスが0の頂点を追加
	shifted->push_back(p->at(0));
	return shifted;
}

int PolygonUtil::getEnvelopePolygon2(const Polygon_ &_points, Polygon_ result, bool removeCollinear)
{
	result->clear();

	Polygons_ tmps1 = Polygons_(new Polygons);
	Polygons_ tmps2 = Polygons_(new Polygons);
	tmps1->push_back(_points);
	while (tmps1->size() > 0) {
		Polygon_ tmp1 = tmps1->at(0);
		tmps1->erase(tmps1->begin());
		bool divided = false;
		for (int i = 0; i < tmp1->size() - 1; ++i) {
			for (int j = i + 1; j < tmp1->size(); ++j) {
				if (tmp1->at(i) == tmp1->at(j)) {
					Polygon_ div1 = Polygon_(new Polygon);
					Polygon_ div2 = Polygon_(new Polygon);
					for (int k = i; k < j; ++k) {
						div1->push_back(tmp1->at(k));
					}
					for (int k = j; k != i; k = PolygonUtil::nextIndex(k, tmp1->size())) {
						div2->push_back(tmp1->at(k));
					}
					tmps1->push_back(div1);
					tmps1->push_back(div2);
					divided = true;
					break;
				}
			}
			if (divided) {
				break;
			}
		}
		if (!divided) {
			tmps2->push_back(tmp1);
		}
	}

	int num = 0;
	for (int i = 0; i < tmps2->size(); ++i) {
		num += tmps2->at(i)->size();
	}
	if (num != _points->size()) {
		return -1;
	}

//	bool warning = false;   // 現在未使用
	Polygons_ tmps3 = Polygons_(new Polygons);
	for (int i = 0; i < tmps2->size(); ++i) {
		Polygon_ tmp3 = Polygon_(new Polygon);
		if (PolygonUtil::getEnvelopePolygon(tmps2->at(i), tmp3, removeCollinear) < 0) {
//			warning = true;
		} else {
			tmps3->push_back(tmp3);
		}
	}

	if (tmps3->size() == 0) {
		return -1;
	}
	if (tmps3->size() == 1) {
		result->swap(*tmps3->at(0));
		return 0;
	}

	try {
		bool combined = true;
		while (combined) {
			combined = false;
			for (int i = 0; i < tmps3->size() - 1; ++i) {
				BoostPolygon bp1 = polygon2BoostPolygon(tmps3->at(i));
				for (int j = i + 1; j < tmps3->size(); ++j) {
					BoostPolygon bp2 = polygon2BoostPolygon(tmps3->at(j));
					std::vector<BoostPolygon> bps;
					boost::geometry::union_(bp1, bp2, bps);
					if (bps.size() == 1) {
						Polygons_ tmps4 = Polygons_(new Polygons);
						tmps4->push_back(boostPolygon2Polygon(bps[0]));
						for (int k = 0; k < tmps3->size(); ++k) {
							if (k == i || k == j) {
								continue;
							}
							tmps4->push_back(tmps3->at(k));
						}
						tmps3->swap(*tmps4);
						combined = true;
						break;
					}
				}
				if (combined) {
					break;
				}
			}
		}
	} catch (const std::exception &e) {
		return -1;
	}
	if (tmps3->size() == 0) {
		return -1;
	}
	if (tmps3->size() == 1) {
		result->swap(*tmps3->at(0));
		return 0;
	}

	double ma = area(tmps3->at(0));
	int index = 0;
	for (int i = 1; i < tmps3->size(); ++i) {
		double a = area(tmps3->at(i));
		if (a > ma) {
			ma = a;
			index = i;
		}
	}
	result->swap(*tmps3->at(index));
	return 0;
}
int PolygonUtil::getEnvelopePolygon(const Polygon_ &_points, Polygon_ result, bool removeCollinear)
{
	Polygon_ points = Polygon_(new Polygon);
	points->assign(_points->begin(), _points->end());
	if (points->size() < 3) return -1; // 点の個数が3個未満
	correctSamePoints(points);
	correctColinearPoints(points);
	correctSamePoints(points);
	if (points->size() < 3) return -1; // 点の個数が3個未満

	// 開始(終了)頂点のインデックスを決定する
	// x座標が最小の頂点が開始(終了)頂点
	int minXi = 0;
	double minX = points->at(0).x;
	for (int i = 1; i < points->size(); ++i) {
		double tmpX = points->at(i).x;
		if (tmpX < minX) {
			minX = tmpX;
			minXi = i;
		}
	}
	int start = minXi;
	int end = minXi;
	// 開始(終了)頂点の左側は領域外
	// 開始頂点から図形の外周を時計回りに回って、終了(=開始)頂点に戻ってくるまで、頂点座標を収拾する

	const bool FORWARD = true;
	const bool BACKWARD = false;
	typedef struct {
		int index; // セグメントのインデックス
		Point2D p; // 交点の座標
		double d; // 距離
	} CrossPoint;

	const int n = (int) points->size();
	const int ENDLESS_LOOP = n * (n + 1) / 2;
	Segments_ segments = createSegments(points);
	Polygon_ tmp = Polygon_(new Polygon);

	// 基点座標
	Point2D p0 = points->at(start);
	tmp->push_back(p0);
	// 次(最初)に向かうべき頂点のインデックス
	int next;
	// 元ポリゴン上の進行方向
	bool dir;
	{
		int i0 = prevIndex(start, points->size());
		int i1 = nextIndex(start, points->size());
		double a0 = Segment(points->at(start), points->at(i0)).angle();
		double a1 = Segment(points->at(start), points->at(i1)).angle();
		if (a1 > a0) {
			next = i1;
			dir = FORWARD;
		} else {
			next = i0;
			dir = BACKWARD;
		}
	}
	// 1個前のセグメントに戻ってしまうのを防ぐため、1個前のセグメントのインデックスを覚えておく
	int prev = -1;

	while (true) {
		if (tmp->size() > ENDLESS_LOOP) {
			return -1;
		}
		// 次に向かうべき頂点
		Point2D p1 = points->at(next);
		Segment s0 = Segment(p0, p1);
		// 線分の範囲内で、交差するセグメントまたは共線セグメントがないかチェックする
		// 自分自身、および隣接するセグメントは、交差判定不要
		int skip1, skip2, skip3;
		if (dir == FORWARD) {
			skip3 = next;
			skip2 = prevIndex(skip3, n);
			skip1 = prevIndex(skip2, n);
		} else {
			skip2 = next;
			skip1 = prevIndex(skip2, n);
			skip3 = nextIndex(skip2, n);
		}
		std::vector<CrossPoint> crossPoints; // 交差するセグメント
		std::vector<int> collinearSegments; // 共線セグメント
		for (int i = 0; i < n; ++i) {
			if (i == skip1 || i == skip2 || i == skip3) {
				continue;
			}
			if (i == prev) {
				// 1個前のセグメントに戻ってしまうのを防ぐ
				continue;
			}
			Segment s = segments->at(i);
			Point2D p;
			int ret = crossPoint(s0, s, &p, true);
			if (ret == 0) {
				// 交差するセグメントの場合
				CrossPoint cp = { i, p, length(p0, p) };
				crossPoints.push_back(cp);
			} else if (ret == 2) {
				// 共線セグメントの場合
				collinearSegments.push_back(i);
			}
		}
		if (crossPoints.size() > 0) {
			// 交差するセグメントがある場合
			// 交点までの距離の昇順にソート
			std::sort(crossPoints.begin(), crossPoints.end(), [](CrossPoint cp1, CrossPoint cp2) -> int { return (cp1.d < cp2.d); });
			double a0 = s0.angle();
			bool branched = false;
			for (int i = 0; i < crossPoints.size(); ++i) {
				CrossPoint cp = crossPoints[i];
				Segment s = segments->at(cp.index);
				int i1 = cp.index;
				int i2 = nextIndex(cp.index, n);
				Segment s1 = Segment(cp.p, s.p1);
				Segment s2 = Segment(cp.p, s.p2);
				if (s.p1 == cp.p) {
					// 交点が相手側セグメントの端点だった場合、その端点に繋がる前側のセグメントを採用する
					s1 = Segment(cp.p, segments->at(prevIndex(cp.index, n)).p1);
					i1 = prevIndex(i1, n);
				}
				if (s.p2 == cp.p) {
					// 交点が相手側セグメントの端点だった場合、その端点に繋がる後側のセグメントを採用する
					s2 = Segment(cp.p, segments->at(nextIndex(cp.index, n)).p2);
					i2 = nextIndex(i2, n);
				}
				double a1 = s1.angle();
				double a2 = s2.angle();
				double a01 = normalizeRadian(a1 - a0);
				double a02 = normalizeRadian(a2 - a0);
				if (cp.p == p1) {
					// 交点がp1(現在目指している頂点)と同じだった場合
					// p1に繋がる次のセグメントも含めて左折角度を比較する
					Point2D tmpP3;
					if (dir == FORWARD) {
						tmpP3 = points->at(nextIndex(next, n));
					} else {
						tmpP3 = points->at(prevIndex(next, n));
					}
					Segment tmpS3 = Segment(p1, tmpP3);
					double a03 = normalizeRadian(tmpS3.angle() - a0);
					if (a03 > 0.0 && a03 > a01 && a03 > a02) {
						// p1に繋がる次のセグメントが左折、かつs1、s2より左折角度が大きい場合
						// 交点を無視してp1に繋がる次のセグメントを採用するため
						// branchedを立てずにbreakして、p1まで進む処理へ
						break;
					}
				}
				if (a01 > 0.0 && a01 > a02) {
					// s1が左折、かつs2よりs1の方が左折角度が大きい場合
					// 頂点を追加
					tmp->push_back(cp.p);
					// 基点座標を更新
					p0 = cp.p;
					// 今まで乗っていたセグメントのインデックスを覚えておく
					// 次に向かうべき頂点のインデックスを更新
					// 進行方向を更新
					if (dir == FORWARD) {
						prev = prevIndex(next, n);
					} else {
						prev = next;
					}
					next = i1;
					dir = BACKWARD;
					branched = true;
					break;
				} else if (a02 > 0.0) {
					// s2が左折
					// 頂点を追加
					tmp->push_back(cp.p);
					// 基点座標を更新
					p0 = cp.p;
					// 今まで乗っていたセグメントのインデックスを覚えておく
					// 次に向かうべき頂点のインデックスを更新
					// 進行方向を更新
					if (dir == FORWARD) {
						prev = prevIndex(next, n);
					} else {
						prev = next;
					}
					next = i2;
					dir = FORWARD;
					branched = true;
					break;
				}
				// どちらも左折していないなら直進(次の交点をチェックする)
			}
			if (branched) {
				// どこかで左折した
				continue;
			}
			// 全ての交点をチェックしたが、左折ポイントがなかった(直進)
		}
		if (collinearSegments.size() > 0) {
			// 共線セグメントがある場合
			// セグメントが伸びないかチェック
			double a0 = s0.angle();
			int tmpNext = next;
			bool tmpDir = dir;
			double d = length(p0, p1);
			for (int i = 0; i < collinearSegments.size(); ++i) {
				Segment s1 = segments->at(collinearSegments[i]);
				double a1 = s1.angle();
				if (angleEquals(a0, a1)) {
					// 順方向の場合、s1.p2をテスト
					double d1 = length(p0, s1.p2);
					if (d1 > d) {
						// セグメントの長さが伸びる場合
						tmpNext = nextIndex(collinearSegments[i], n);
						tmpDir = FORWARD;
						d = d1;
					}
				} else if (angleEquals(a0, a1 + M_PI)) {
					// 逆方向の場合、s1.p1をテスト
					double d1 = length(p0, s1.p1);
					if (d1 > d) {
						// セグメントの長さが伸びる場合
						tmpNext = collinearSegments[i];
						tmpDir = BACKWARD;
						d = d1;
					}
				} else {
					// 共線と判定されたのに、どちら向きでも一致しなかった場合
					assert(false);
				}
			}
			if (tmpNext != next) {
				// 今より長いセグメントに出来ると判定されたのでセグメントを乗り換える
				// 同じ方向に進むので頂点は追加しない
				// 基点座標は更新する(交差判定済みの区間を省くため)
				p0 = p1;
				// 今まで乗っていたセグメントのインデックスを覚えておく
				if (dir == FORWARD) {
					prev = prevIndex(next, n);
				} else {
					prev = next;
				}
				// 次に向かうべき頂点のインデックスを更新
				// 進行方向を更新
				next = tmpNext;
				dir = tmpDir;
				continue;
			}
			// セグメントが伸びなかったので今のセグメントを維持
		}
		// 交点はあったが左折できなかった場合
		// 共線はあったがセグメントが伸びなかった場合
		// 交点/共線がない場合
		// p1まで進む
		if (next == end) {
			// p1が終了(=開始)頂点の場合、頂点の収拾が完了したので処理を抜ける
			break;
		}
		// 頂点を追加
		tmp->push_back(p1);
		// 基点座標を更新
		p0 = p1;
		// 今まで乗っていたセグメントのインデックスを覚えておく
		// 次に向かうべき頂点のインデックスを更新
		if (dir == FORWARD) {
			prev = prevIndex(next, n);
			next = nextIndex(next, n);
		} else {
			prev = next;
			next = prevIndex(next, n);
		}
	}

	// 元の図形で自己交差していた箇所が、包絡線ポリゴンの外形にも、そのまま残るような場合
	// この時点の包絡線ポリゴンは、クビレの幅が0のようなヒョウタン型(？)になっている
	// そのため、このクビレの部分でポリゴンを分割する
	Polygons_ results = Polygons_(new Polygons);
	Polygons_ tmps = Polygons_(new Polygons);
	tmps->push_back(tmp);
	bool divided = true;
	int index1;
	int index2;
	while (divided) {
		divided = false;
		for (int i = 0; i < tmps->size(); ++i) {
			const Polygon_ &tmp = tmps->at(i);
			if (findSamePointIndex(tmp, &index1, &index2)) {
				dividePolygon(tmp, index1, index2, results);
				divided = true;
			} else {
				results->push_back(tmp);
			}
		}
		if (divided) {
			results->swap(*tmps);
			results->clear();
		}
	}

	// 面積が最大のものを採用
	int resultIndex = -1;
	double area = 0.0;
	for (int i = 0; i < results->size(); ++i) {
		if (checkPolygon(results->at(i)) < 0) {
			continue;
		}
		BoostPolygon bp = polygon2BoostPolygon(results->at(i));
		double a = boost::geometry::area(bp);
		if (a > area) {
			area = a;
			resultIndex = i;
		}
	}
	if (resultIndex < 0) {
		return -1;
	}
	result->clear();
	result->swap(*results->at(resultIndex));
	if (!removeCollinear) {
		// 入力点列を全てチェック
		for (int i = 0; i < _points->size(); ++i) {
			const Point2D &_point = _points->at(i);
			bool exist = false;
			for (int j = 0; j < result->size(); ++j) {
				const Point2D &p = result->at(j);
				if (p == _point) {
					// resultに同じ座標の点が存在する場合
					exist = true;
					break;
				}
			}
			if (exist) {
				// resultに同じ座標の点が存在する場合、処理なし
				continue;
			}
			Segments_ resultSegments = createSegments(result);
			int index;
			for (index = 0; index < resultSegments->size(); ++index) {
				const Segment &resultSegment = resultSegments->at(index);
				if (resultSegment.contains(_point) && perpendicularLength(_point, resultSegment) < TOLERANCE) {
					// セグメントに乗っている場合
					break;
				}
			}
			if (index == resultSegments->size()) {
				// どのセグメントにも乗っていない場合、処理なし
				continue;
			}
			// result->at(index)の次に_pointを挿入
			Polygon_ tmp = Polygon_(new Polygon);
			for (int j = 0; j < index + 1; ++j) {
				tmp->push_back(result->at(j));
			}
			tmp->push_back(_point);
			for (int j = index + 1; j < result->size(); ++j) {
				tmp->push_back(result->at(j));
			}
			result->swap(*tmp);
		}
	}
	return 0;
}
bool PolygonUtil::findSamePointIndex(const Polygon_ &polygon, int *index1, int *index2)
{
	for (int i = 0; i < polygon->size(); ++i) {
		const Point2D &p1 = polygon->at(i);
		for (int j = i + 1; j < polygon->size(); ++j) {
			const Point2D &p2 = polygon->at(j);
			if (p1 == p2) {
				*index1 = i;
				*index2 = j;
				return true;
			}
		}
	}
	return false;
}
void PolygonUtil::dividePolygon(const Polygon_ &polygon, int index1, int index2, Polygons_ results)
{
	Polygon_ p1 = Polygon_(new Polygon);
	for (int i = index1; i < index2; ++i) {
		p1->push_back(polygon->at(i));
	}
	results->push_back(p1);
	Polygon_ p2 = Polygon_(new Polygon);
	for (int i = index2; i != index1; i = nextIndex(i, polygon->size())) {
		p2->push_back(polygon->at(i));
	}
	results->push_back(p2);
}

void PolygonUtil::debugPrint(const std::string &filename, const Polygon_ &polygon) {
#ifdef DEBUG_LOG
	std::ofstream myFile;
	myFile.open(LOG_DIR + filename);
	debugPrintSvgHeader(myFile, polygon);
	debugPrintSvg(myFile, polygon, 1, 1.0, "black");
	debugPrintSvgFooter(myFile);
	myFile.close();
#endif
}
void PolygonUtil::debugPrint(const std::string &filename, const Polygon_ &polygon1, const Polygon_ &polygon2) {
#ifdef DEBUG_LOG
	std::ofstream myFile;
	myFile.open(LOG_DIR + filename);
	debugPrintSvgHeader(myFile, polygon1);
	debugPrintSvg(myFile, polygon1, 1, 1.0, "black");
	debugPrintSvg(myFile, polygon2, 2, 0.5, "red");
	debugPrintSvgFooter(myFile);
	myFile.close();
#endif
}
void PolygonUtil::debugPrint(const std::string &filename, const Polygon_ &polygon, const Polygons_ &polygons) {
#ifdef DEBUG_LOG
	std::ofstream myFile;
	myFile.open(LOG_DIR + filename);
	debugPrintSvgHeader(myFile, polygon);
	debugPrintSvg(myFile, polygon, 1, 1.0, "black");
	for (int i = 0; i < polygons->size(); ++i) {
		debugPrintSvg(myFile, polygons->at(i), i+2, 0.5, "red");
	}
	debugPrintSvgFooter(myFile);
	myFile.close();
#endif
}
void PolygonUtil::debugPrintSvgHeader(std::ofstream &myFile, const Polygon_ &polygon) {
#ifdef DEBUG_LOG
	Point2D min, max;
	boundingBox(polygon, &min, &max);
	myFile << "<?xml version=\"1.0\" standalone=\"no\"?>" << std::endl;
	myFile << "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.1//EN\" \"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd\">" << std::endl;
	myFile << "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"" << min.x << " " << -max.y << " " << (max.x - min.x) << " " << (max.y - min.y) << "\" width=\"100%\" height=\"100%\" preserveAspectRatio=\"xMidYMid meet\">" << std::endl;
#endif
}
void PolygonUtil::debugPrintSvg(std::ofstream &myFile, const Polygon_ &polygon, int index, double width, const std::string &color) {
#ifdef DEBUG_LOG
	myFile << "<g id=\"G" << index << "\" stroke=\"" << color << "\" fill=\"none\">" << std::endl;
	myFile << "<polygon id=\"P" << index << "\" stroke-width=\"" << width << "\" points=\"" << std::endl;
	for (int i = 0; i < polygon->size(); ++i) {
		myFile << std::setprecision(16) << polygon->at(i).x << "," << std::setprecision(16) << -polygon->at(i).y << std::endl;
	}
	myFile << "\"/>" << std::endl;
	myFile << "</g>" << std::endl;
#endif
}
void PolygonUtil::debugPrintSvg(std::ofstream &myFile, const Segments_ &segments, int index, double width, const std::string &color) {
#ifdef DEBUG_LOG
	myFile << "<g id=\"G" << index << "\" stroke=\"" << color << "\" fill=\"none\">" << std::endl;
	myFile << "<path id=\"P" << index << "\" stroke-width=\"" << width << "\" d=\"" << std::endl;
	for (int i = 0; i < segments->size(); ++i) {
		myFile << "M " << std::setprecision(16) << segments->at(i).p1.x << "," << std::setprecision(16) << -segments->at(i).p1.y << std::endl;
		myFile << "L " << std::setprecision(16) << segments->at(i).p2.x << "," << std::setprecision(16) << -segments->at(i).p2.y << " Z" << std::endl;
	}
	myFile << "\"/>" << std::endl;
	myFile << "</g>" << std::endl;
#endif
}
void PolygonUtil::debugPrintSvgFooter(std::ofstream &myFile) {
#ifdef DEBUG_LOG
	myFile << "</svg>" << std::endl;
#endif
}

int PolygonUtil::getMaxRightRect(const Polygon_ &src, Polygon_ result) {
	Point2D min, max;
	boundingBox(src, &min, &max);
	// 分割単位
	const double UNIT = std::sqrt((max.x - min.x) * (max.y - min.y) / 900);
	// 基準点
	const double MIN_X = min.x;
	const double MIN_Y = min.y;
	// サイズ
	const int SIZE_X = std::ceil((max.x - min.x) / UNIT);
	const int SIZE_Y = std::ceil((max.y - min.y) / UNIT);
	// 格子状に分割した単位領域の利用可能(true)/利用不可(false)を保持する配列
	std::vector<bool> squares;
	squares.resize(SIZE_X * SIZE_Y, false);
	// 格子状に分割して、それぞれの単位領域が利用可能か判定する
	int sum = 0;
	for (int iy = 0; iy < SIZE_Y; ++iy) {
		min.y = MIN_Y + UNIT * iy;
		max.y = MIN_Y + UNIT * (iy + 1);
		for (int ix = 0; ix < SIZE_X; ++ix) {
			min.x = MIN_X + UNIT * ix;
			max.x = MIN_X + UNIT * (ix + 1);
			// 単位領域の矩形ポリゴン
			Polygon_ p = box2Polygon(min, max);
			if (within(src, p)) {
				// 完全に含まれている場合のみ利用可能
				squares[iy * SIZE_X + ix] = true;
				++sum;
			}
		}
	}
	if (sum == 0) {
		// 利用可能な単位領域がひとつも存在しない場合
		return -1;
	}
	// 利用可能矩形領域: 利用可能な単位領域だけで構成される矩形領域
	int ix1 = 0; // 利用可能矩形領域の左端のインデックス
	int ix2 = 0; // 利用可能矩形領域の右端のインデックス
	int iy1 = 0; // 利用可能矩形領域の下端のインデックス
	int iy2 = 0; // 利用可能矩形領域の上端のインデックス
	// 最大利用可能矩形領域の探索
	if (getMaxRightRect_internal(squares, SIZE_X, SIZE_Y, &ix1, &ix2, &iy1, &iy2) < 0) {
		// 探索失敗(想定外のエラー)
		return -1;
	}
	// もともとの(入力ポリゴンと同じ)座標系に復元
	min.x = MIN_X + UNIT * ix1;
	max.x = MIN_X + UNIT * (ix2 + 1);
	min.y = MIN_Y + UNIT * iy1;
	max.y = MIN_Y + UNIT * (iy2 + 1);
	// 最大利用可能矩形領域は、上下左右それぞれの方向に、最大で1単位領域分まで拡大できる可能性がある
	BoostPolygon _src = polygon2BoostPolygon(src);
	std::vector<BoostPolygon> _results;
	Polygons_ results = Polygons_(new Polygons);
	Point2D min2, max2;
	// 上方向
	min2.x = min.x;
	max2.x = max.x;
	min2.y = max.y;
	max2.y = max.y + UNIT;
	BoostPolygon ext1 = polygon2BoostPolygon(box2Polygon(min2, max2));
	try {
		_results.clear();
		boost::geometry::difference(ext1, _src, _results);
		results->clear();
		for (int i = 0; i < _results.size(); ++i) {
			results->push_back(boostPolygon2Polygon(_results[i]));
		}
		if (results->size() > 0) {
			boundingBox(results, &min2, &max2);
			max.y = min2.y;
		}
	} catch (const std::exception& e) {
	}
	// 下方向
	min2.x = min.x;
	max2.x = max.x;
	min2.y = min.y - UNIT;
	max2.y = min.y;
	BoostPolygon ext2 = polygon2BoostPolygon(box2Polygon(min2, max2));
	try {
		_results.clear();
		boost::geometry::difference(ext2, _src, _results);
		results->clear();
		for (int i = 0; i < _results.size(); ++i) {
			results->push_back(boostPolygon2Polygon(_results[i]));
		}
		if (results->size() > 0) {
			boundingBox(results, &min2, &max2);
			min.y = max2.y;
		}
	} catch (const std::exception& e) {
	}
	// 左方向
	min2.x = min.x - UNIT;
	max2.x = min.x;
	min2.y = min.y;
	max2.y = max.y;
	BoostPolygon ext3 = polygon2BoostPolygon(box2Polygon(min2, max2));
	try {
		_results.clear();
		boost::geometry::difference(ext3, _src, _results);
		results->clear();
		for (int i = 0; i < _results.size(); ++i) {
			results->push_back(boostPolygon2Polygon(_results[i]));
		}
		if (results->size() > 0) {
			boundingBox(results, &min2, &max2);
			min.x = max2.x;
		}
	} catch (const std::exception& e) {
	}
	// 右方向
	min2.x = max.x;
	max2.x = max.x + UNIT;
	min2.y = min.y;
	max2.y = max.y;
	BoostPolygon ext4 = polygon2BoostPolygon(box2Polygon(min2, max2));
	try {
		_results.clear();
		boost::geometry::difference(ext4, _src, _results);
		results->clear();
		for (int i = 0; i < _results.size(); ++i) {
			results->push_back(boostPolygon2Polygon(_results[i]));
		}
		if (results->size() > 0) {
			boundingBox(results, &min2, &max2);
			max.x = min2.x;
		}
	} catch (const std::exception& e) {
	}
	// 結果を格納
	result->swap(*box2Polygon(min, max));
	return 0;
}
int PolygonUtil::getMaxRightRect_internal(const std::vector<bool> &squares, const int SIZE_X, const int SIZE_Y, int *_ix1, int *_ix2, int *_iy1, int *_iy2) {
	int ret = -1;
	int maxArea = 0;
	for (int iy = 0; iy < SIZE_Y; ++iy) {
		for (int ix = 0; ix < SIZE_X; ++ix) {
			if (!squares[iy * SIZE_X + ix]) {
				// 当該単位領域が利用不可
				continue;
			}
			if (iy > 0 && squares[(iy - 1) * SIZE_X + ix]) {
				// 下の単位領域が利用可能
				continue;
			}
			// 左方向に探索して、最初に見つかる利用不可な単位領域のインデックス
			int minX = ix;
			for (; minX >= 0 && squares[iy * SIZE_X + minX]; --minX) ;
			// 右方向に探索して、最初に見つかる利用不可な単位領域のインデックス
			int maxX = ix;
			for (; maxX < SIZE_X && squares[iy * SIZE_X + maxX]; ++maxX) ;
			// 上方向に探索して、最初に見つかる利用不可な単位領域のインデックス
			int maxY = iy;
			for (; maxY < SIZE_Y && squares[maxY * SIZE_X + ix]; ++maxY) ;
			// 計算済みの最大面積を超える可能性がなければスキップ
			if ((maxX - minX - 1) * (maxY - iy) <= maxArea) {
				continue;
			}
			// 当該単位領域を下辺とする利用可能矩形領域の中で、面積が最大となる領域を探索する
			for (int iy2 = iy; iy2 < maxY; ++iy2) {
				int ix2;
				// 左方向に探索して、最初に見つかる利用不可な単位領域のインデックス
				ix2 = ix;
				for (; ix2 > minX && squares[iy2 * SIZE_X + ix2]; --ix2) ;
				minX = ix2; // 次の段(iy2+1)の左方向は、(ix2+1)までしか探索してはいけない
				// 右方向に探索して、最初に見つかる利用不可な単位領域のインデックス
				ix2 = ix;
				for (; ix2 < maxX && squares[iy2 * SIZE_X + ix2]; ++ix2) ;
				maxX = ix2; // 次の段(iy2+1)の右方向は、(ix2-1)までしか探索してはいけない
				// 利用可能矩形領域の面積
				int area = (maxX - minX - 1) * (iy2 - iy + 1);
				if (area > maxArea) {
					maxArea = area;
					*_ix1 = minX + 1;
					*_ix2 = maxX - 1;
					*_iy1 = iy;
					*_iy2 = iy2;
					ret = 0;
				}
			}
		}
	}
	return ret;
}

int PolygonUtil::insertMidOffset(Polygon_ &polygon, double offset) {
    Point2D bbMin;
    Point2D bbMax;
    boundingBox(polygon, &bbMin, &bbMax);
    const double mx = (bbMin.x + bbMax.x) * 0.5;
    const Segment ms = Segment(Point2D(mx, bbMin.y - TOLERANCE_2), Point2D(mx, bbMax.y + TOLERANCE_2));
    const Segments_ segments = createSegments(polygon);
    Polygon_ result = Polygon_(new Polygon);
    for (int i = 0; i < segments->size(); ++i) {
        const Segment &s = segments->at(i);
        const bool isLeft1 = (s.p1.x < mx);
        const bool isLeft2 = (s.p2.x < mx);
        bool cross = false;
        if (isLeft1) {
            // 左にシフト
            result->push_back(Point2D(s.p1.x - offset, s.p1.y));
            if (!isLeft2) cross = true;
        } else {
            // 右にシフト
            result->push_back(Point2D(s.p1.x + offset, s.p1.y));
            if (isLeft2) cross = true;
        }
        if (cross) {
            // 中心線をまたぐ場合
            Point2D cp;
            if (crossPoint(ms, s, &cp) != 0) return -1;
            // 左にシフト
            Point2D cpL = Point2D(cp.x - offset, cp.y);
            // 右にシフト
            Point2D cpR = Point2D(cp.x + offset, cp.y);
            if (isLeft1) {
                // 左から右
                result->push_back(cpL);
                result->push_back(cpR);
            } else {
                // 右から左
                result->push_back(cpR);
                result->push_back(cpL);
            }
        }
    }
    polygon->swap(*result);
    simplify_(polygon);
    return 0;
}

}} // yanmar::PathPlan

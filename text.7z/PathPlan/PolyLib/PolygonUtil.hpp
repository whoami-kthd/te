// Yanmar Confidential 20200918
#ifndef PolygonUtil_HPP
#define PolygonUtil_HPP

// 誤差の許容範囲(距離0、面積0、角度0の判定で同じ値を使用している)
#define TOLERANCE 1.0 / 1000000.0
#define TOLERANCE_2 1.0 / 1000.0
#define TOLERANCE_AREA 1.0 / 1000.0
#define TOLERANCE_ANGLE 1.0 / 1000000.0
#define TOLERANCE_ANGLE_2 1.0 / 1000.0
#define M_PI_X2 M_PI * 2.0

#include "../../include/PathPlanIF.hpp"

#include <fstream>
#include <iomanip>

#include <vector>
#include <cmath>
#include "boost/shared_ptr.hpp"

namespace yanmar { namespace PathPlan {
	
	/** 点(x, y)を表現するクラス */
	class Point2D {
	public:
		double x;
		double y;
		Point2D() {
			x = 0.0;
			y = 0.0;
		}
		Point2D(double _x, double _y) {
			x = _x;
			y = _y;
		}
		Point2D(const GeoPoint& point) :
			x(point.x),
			y(point.y)
		{}
		inline bool operator==(const Point2D &p) const {
			return (fabs(p.x - x) < TOLERANCE && fabs(p.y - y) < TOLERANCE);
		}
		operator GeoPoint() const {
			return GeoPoint(x, y);
		}
		Point2D toFloat() const {
			return Point2D{x, y};
		}
	};
	typedef std::vector<Point2D> Polygon;
	typedef boost::shared_ptr<Polygon> Polygon_;
	typedef std::vector<Polygon_> Polygons;
	typedef boost::shared_ptr<Polygons> Polygons_;

	Polygon_ makePolygon_(const GeoPolygon& geoPolygon);
	Polygons_ makePolygons_(const GeoPolygonList& geoPolygonList);
	
	class PolygonUtil
	{
	public:
		/** 2点(p1, p2)で定義されるものを表現するクラス */
		class Segment {
		public:
			Point2D p1;
			Point2D p2;
			double x;
			double y;
			Segment(const Point2D &_p1, const Point2D &_p2) {
				p1 = Point2D(_p1.x, _p1.y);
				p2 = Point2D(_p2.x, _p2.y);
				x = p2.x - p1.x;
				y = p2.y - p1.y;
			}
			/** 線分の長さ(ベクトルの大きさ) */
			inline double length() const {
				return sqrt(x * x + y * y);
			}
			/** 直線(ベクトル)がx軸と為す角度 */
			inline double angle() const {
				return atan2(y, x);
			}
			/** 矩形が点pを含む場合、true */
			inline bool contains(const Point2D &p) const {
				double xmin = std::min(p1.x, p2.x);
				double xmax = std::max(p1.x, p2.x);
				double ymin = std::min(p1.y, p2.y);
				double ymax = std::max(p1.y, p2.y);
				return (xmin < p.x + TOLERANCE && p.x < xmax + TOLERANCE && ymin < p.y + TOLERANCE && p.y < ymax + TOLERANCE);
			}
			/** 矩形が点pを含む場合、true (凹頂点での分割切除で使用。延長線と線分の交点を求める場合、かつ交点の座標自体はそれほど重要ではない場合に使用) */
			inline bool contains_(const Point2D &p) const {
				double xmin = std::min(p1.x, p2.x);
				double xmax = std::max(p1.x, p2.x);
				double ymin = std::min(p1.y, p2.y);
				double ymax = std::max(p1.y, p2.y);
				return (xmin < p.x + TOLERANCE_2 && p.x < xmax + TOLERANCE_2 && ymin < p.y + TOLERANCE_2 && p.y < ymax + TOLERANCE_2);
			}
			/** 範囲を取得 */
			inline void range(Point2D *min, Point2D *max) const {
				min->x = std::min(p1.x, p2.x);
				max->x = std::max(p1.x, p2.x);
				min->y = std::min(p1.y, p2.y);
				max->y = std::max(p1.y, p2.y);
			}
		};
		typedef std::vector<Segment> Segments;
		typedef boost::shared_ptr<Segments> Segments_;

	public:
		/** 角度を幅に変換する関数 */
		typedef std::function<std::vector<double>(std::vector<double>)> Angles2Widths;

	public:
		/**
		 * セグメント(ポリゴンを構成する辺)のリストを生成して返します。
		 * @param polygon 対象となるポリゴン
		 * @return セグメントのリスト
		 */
		static Segments_ createSegments(const Polygon_ polygon);

		/**
		 * ポリゴンをチェックして適切に修正します。
		 * 同じ点が連続した場合、前側の点を削除します。
		 * 同じ直線上の点が3個以上連続した場合、中間点を削除します。
		 * 点の個数が3個未満の場合、-1を返します。(不要な点を削除した結果も含みます)
		 * 自己交差する場合、-2を返します。
		 * 点列の順序が反時計回りの場合、時計回りとなるように順序を逆転させます。
		 * @param polygon チェック／修正対象となるポリゴン
		 * @return 0 正常終了
		 *        -1 異常終了(点の個数が3個未満)
		 *        -2 異常終了(自己交差あり)
		 */
		static int checkPolygon(Polygon_ polygon);
		/**
		 * 計算誤差回避用のポリゴン単純化ロジックです。
		 * 比較的ゆるい条件で、同じ点、同じ直線上の点を削除します。
		 * 点の個数が3個未満の場合、-1を返します。(不要な点を削除した結果も含みます)
		 * @param polygon チェック／修正対象となるポリゴン
		 * @return 0 正常終了
		 *        -1 異常終了(点の個数が3個未満)
		 */
		static int simplify_(Polygon_ polygon);
		/**
		 * 計算誤差回避用のポリゴン単純化ロジックです。
		 * 圃場ポリゴンに対して、最初に1回だけ実行することを想定しています。
		 */
		static int simplify2(Polygon_ polygon);
		static int simplify2_correctSamePoints(Polygon_ polygon);
		static int simplify2_correctColinearPoints(Polygon_ polygon);
		static int simplify2_checkPolygon(Polygon_ polygon);
		static int simplify2_omitConvexPoint(Polygon_ polygon, double *areaDecreased);
		static int simplify2_cutOffConcaveEdge(Polygon_ polygon, double *areaDecreased);
		static int simplify2_internal(Polygon_ polygon);

		/**
		 * ポリゴンをふとらせます。
		 * @param src 対象となるポリゴン
		 * @param result ふとらせたポリゴン
		 * @param width ふとらせる幅(0未満の場合、エラー)
		 * @param angle2Width 辺がx軸と為す角度を元に、ふとらせる幅を返す関数(0未満の値が返ってきた場合、エラー)
		 * @return 0 正常終了
		 *        -1 異常終了(点の個数が3個未満)
		 *        -2 異常終了(自己交差あり)
		 *        -3 異常終了(加算処理失敗)
		 *        -4 異常終了(widthまたはangle2Widthから返ってきた値が0未満)
		 */
		static int thick(const Polygon_ &src, Polygon_ result, double width);

		/**
		 * ポリゴンをやせさせます。
		 * @param src 対象となるポリゴン
		 * @param results やせさせたポリゴン
		 * @param width やせさせる幅(0未満の場合、エラー)
		 * @param angle2Width 辺がx軸と為す角度を元に、やせさせる幅を返す関数(0未満の値が返ってきた場合、エラー)
		 * @return 0 正常終了
		 *        -1 異常終了
		 * 20161111 整理/再構築
		 */
		static int thin(const Polygon_ &src, Polygons_ results, double width);
		static int thin5(Polygon_ src, Polygons_ results, Angles2Widths angles2Widths);
		static int thin5_simplify(Polygon_ src, Polygons_ results, double width, bool complement);
		static int thin5_intersection(Polygon_ src, Polygons_ results, double width);
		static int thin5_offset(Polygon_ src, Polygons_ results, double width);
		static int thin5_main(Polygon_ src, Polygons_ results, Angles2Widths angles2Widths, bool complement, bool feedback);
		static int thin5_fraction(const Polygon_ &src, Polygons_ results, Angles2Widths angles2Widths);
		static int thin5_fractionBase(const Polygon_ &src, Polygons_ results, Angles2Widths angles2Widths, double fraction);
		static int thin5_easeConcave(Polygon_ polygon);
		static int thin5_easeConvex(Polygon_ polygon);
		static int thin5_tryAddComplement(const Polygon_ &src, Polygon_ dst);
		static int thin5_feedback(Polygon_ src, Polygons_ results, double width, bool complement = true);
		static int thin5_feedback(Polygon_ src, Polygons_ results, Angles2Widths angles2Widths, bool increase = true, bool complement = true);
		static int thin5_thick(Polygon_ src, Polygons_ results, Angles2Widths angles2Widths, bool increase = true);
		static int thin5_getShiftValueMax(const Polygon_ &src, const Polygon_ &result, double sideMarginAngle, double *headlandMax, double *sideMarginMax, std::vector<double> *widths, bool skipShortEdge = false);
		static int thin5_getShiftValueMax2(const Polygon_ &src, const Polygon_ &result, double sideMarginAngle, double *headlandMax, double *sideMarginMax, std::vector<double> *widths, bool skipShortEdge = false);
		static int thin5_omitConvexPoint(Polygon_ polygon, double *areaDecreased);
		static int thin5_cutOffConcaveEdge(Polygon_ polygon, double *areaDecreased);

		static int checkAngles(const std::vector<double> &angles1, const std::vector<double> &angles2);
		static Angles2Widths getAngles2Widths(double *width);

		/**
		 * 2個のポリゴンに重なりがあるか判定します。
		 * @param polygon1 対象となるポリゴン
		 * @param polygon2 対象となるポリゴン
		 * @return 重なりがある場合、true
		 */
		static bool intersects(const Polygon_ &polygon1, const Polygon_ &polygon2);

		/**
		 * polygon1からpolygon2を減算処理して、結果をresultsに格納します。
		 * @param polygon1 減算対象となるポリゴン
		 * @param polygon2 減算するポリゴン
		 * @param resultPolygons 結果ポリゴンのリスト
		 * @return 0 正常終了
		 *        -1 異常終了
		 */
		static int difference(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygons_ resultPolygons);
		static int difference2(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygons_ resultPolygons, std::vector<Point2D> *crossPoints);
		static int difference3(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygons_ resultPolygons);

		/**
		 * polygon1とpolygon2を加算処理して、結果をresultPolygonsに格納します。
		 * @param polygon1 ポリゴン1
		 * @param polygon2 ポリゴン2
		 * @param resultPolygons 結果ポリゴンのリスト
		 * @return 0 正常終了
		 *        -1 異常終了
		 */
		static int union_(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygons_ resultPolygons);

		/**
		 * 2個のポリゴンの交点を求めます。
		 * @param polygon1 対象となるポリゴン
		 * @param polygon2 対象となるポリゴン
		 * @param crossPoints 交点のリスト
		 * @return 辺の重なりがある場合、true
		 */
		static bool getCrossPoints(const Polygon_ &polygon1, const Polygon_ &polygon2, std::vector<Point2D> *crossPoints);

		/**
		 * ポリゴンと線分(p1, p2)との交点を求めます。
		 * @param polygon 対象となるポリゴン
		 * @param p1 対象となる線分の端点
		 * @param p2 対象となる線分の端点
		 * @param crossPoints 交点のリスト
		 * @return 辺の重なりがある場合、true
		 */
		static bool getCrossPoints(const Polygon_ &polygon, const Point2D &p1, const Point2D &p2, std::vector<Point2D> *crossPoints, bool checkSegment = true);

		/**
		 * pがpolygonの内側にあるか判定します。
		 * @param polygon 対象となるポリゴン
		 * @param p 対象となる点
		 * @return 内側にある場合、true
		 */
		static bool within(const Polygon_ &polygon, const Point2D &p);

		/**
		 * innerがouterの内側にあるか判定します。
		 * @param outer 大きい方のポリゴン
		 * @param inner 小さい方のポリゴン
		 * @return 内側にある場合、true
		 */
		static bool within(const Polygon_ &outer, const Polygon_ &inner);

		/**
		 * ポリゴン同士に重なりがないか判定します。
		 * @return true 重なりがない場合
		 */
		static bool disjoint(const Polygon_ &polygon1, const Polygon_ &polygon2);

		/**
		 * 共通部分を計算します。
		 * @param polygon1 ポリゴン1
		 * @param polygon2 ポリゴン2
		 * @param result 結果ポリゴン
		 * @return 0 正常終了
		 *        -1 異常終了
		 */
		static int intersection(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygons_ results);
		static int intersection(const Polygon_ &polygon1, const Polygon_ &polygon2, Polygon_ result);

		/**
		 * セグメントがx軸と為す角度のリストを取得します。
		 */
		static std::vector<double> getAngles(const Segments_ &s);

		/**
		 * polygonの面積を返します。
		 */
		static double area(const Polygon_ &polygon);
		static double area(const Point2D &p1, const Point2D &p2, const Point2D &p3);

        /**
         * polygon上の一番近い点の情報を返します。
         */
        static void getIndexPos(const Segments_ &segments, const Point2D &p, int *index, double *pos);

        /**
         * オフセット作業機用の作業領域を生成します。
         */
        static int insertMidOffset(Polygon_ &polygon, double offset);

	public: // inline
		inline static Polygon_ box2Polygon(Point2D min, Point2D max) {
			Polygon_ p = Polygon_(new Polygon);
			p->push_back(Point2D(min.x, min.y));
			p->push_back(Point2D(min.x, max.y));
			p->push_back(Point2D(max.x, max.y));
			p->push_back(Point2D(max.x, min.y));
			return p;
		}
		/**
		 * バウンディングボックスを計算します。
		 * @param polygon 対象となるポリゴン
		 * @param min バウンディングボックスの左下の座標を格納するポインタ
		 * @param max バウンディングボックスの右上の座標を格納するポインタ
		 */
		inline static void boundingBox(const Polygon_ &polygon, Point2D *min, Point2D *max) {
			Point2D p = polygon->at(0);
			*min = p;
			*max = p;
			for (int i = 1; i < polygon->size(); ++i) {
				p = polygon->at(i);
				min->x = std::min(min->x, p.x);
				min->y = std::min(min->y, p.y);
				max->x = std::max(max->x, p.x);
				max->y = std::max(max->y, p.y);
			}
		}
		inline static void boundingBox(const Polygons_ &polygons, Point2D *min, Point2D *max) {
			boundingBox(polygons->at(0), min, max);
			for (int i = 1; i < polygons->size(); ++i) {
				const Polygon_ &polygon = polygons->at(i);
				Point2D minTmp;
				Point2D maxTmp;
				boundingBox(polygon, &minTmp, &maxTmp);
				min->x = std::min(min->x, minTmp.x);
				min->y = std::min(min->y, minTmp.y);
				max->x = std::max(max->x, maxTmp.x);
				max->y = std::max(max->y, maxTmp.y);
			}
		}

		/**
		 * ポリゴンを平行移動します。
		 * @param polygon 対象となるポリゴン
		 * @param tx x方向の移動量
		 * @param ty y方向の移動量
		 */
		inline static void translate(Polygon_ polygon, Point2D t) {
			translate(polygon, t.x, t.y);
		}
		inline static void translate(Polygon_ polygon, double tx, double ty) {
			for (int i = 0; i < polygon->size(); ++i) {
				translatePoint(&polygon->at(i), tx, ty);
			}
		}
		inline static void translatePoint(Point2D *point, double tx, double ty) {
			point->x += tx;
			point->y += ty;
		}

		/**
		 * ポリゴンを拡大縮小します。
		 * @param polygon 対象となるポリゴン
		 * @param sx x方向の拡大率
		 * @param sy y方向の拡大率
		 */
		inline static void scale(Polygon_ polygon, double sx, double sy) {
			for (int i = 0; i < polygon->size(); ++i) {
				polygon->at(i).x *= sx;
				polygon->at(i).y *= sy;
			}
		}

		/**
		 * ポリゴンを回転します。
		 * @param polygon 対象となるポリゴン
		 * @param angle 回転角度(反時計回りが正、ラジアン単位)
		 */
		inline static void rotate(Polygon_ polygon, double angle) {
			double sin = std::sin(angle);
			double cos = std::cos(angle);
			rotate(polygon, sin, cos);
		}
		/**
		 * ポリゴンを回転します。
		 * @param polygon 対象となるポリゴン
		 * @param sin 回転角度のsin値
		 * @param cos 回転角度のcos値
		 */
		inline static void rotate(Polygon_ polygon, double sin, double cos) {
			for (int i = 0; i < polygon->size(); ++i) {
				rotatePoint(&polygon->at(i), sin, cos);
			}
		}
		inline static void rotatePoint(Point2D *point, double sin, double cos) {
			Point2D p = *point;
			point->x = p.x * cos - p.y * sin;
			point->y = p.x * sin + p.y * cos;
		}
		/** 2点(p1, p2)を通る直線ax+by+c=0の式 */
		inline static void lineFormula(const Point2D &p1, const Point2D &p2, double *a, double *b, double *c) {
			// (y2-y1)x+(x1-x2)y+(x2y1-x1y2)=0
			*a = p2.y - p1.y;
			*b = p1.x - p2.x;
			*c = p2.x * p1.y - p1.x * p2.y;
		}
		/** 点pから直線ax+by+c=0に下ろした垂線の長さ */
		inline static double perpendicularLength(const Point2D &p, double a, double b, double c) {
			return fabs(a * p.x + b * p.y + c) / sqrt(a * a + b * b);
		}
		/** 点pから直線sに下ろした垂線の長さ */
		inline static double perpendicularLength(const Point2D &p, const Segment &s) {
			double a, b, c;
			lineFormula(s.p1, s.p2, &a, &b, &c);
			return perpendicularLength(p, a, b, c);
		}
		/** 点pから直線ax+by+c=0に下ろした垂線の足の座標 */
		inline static Point2D perpendicularPoint(const Point2D &p, double a, double b, double c) {
			double coef = (a * p.x + b * p.y + c) / (a * a + b * b);
			return Point2D(p.x - coef * a, p.y - coef * b);
		}
		/** 点pから直線sに下ろした垂線の足の座標 */
		inline static Point2D perpendicularPoint(const Point2D &p, const Segment &s) {
			double a, b, c;
			lineFormula(s.p1, s.p2, &a, &b, &c);
			return perpendicularPoint(p, a, b, c);
		}
		/** 2点間の距離(長さ) */
		inline static double length(const Point2D &p1, const Point2D &p2) {
			double x = p2.x - p1.x;
			double y = p2.y - p1.y;
			return sqrt(x * x + y * y);
		}
		/** 矩形の交差判定 */
		inline static bool checkRectIntersection(const Segment &s1, const Segment &s2) {
			Point2D min1, max1, min2, max2;
			s1.range(&min1, &max1);
			s2.range(&min2, &max2);
			return (min1.x < max2.x + TOLERANCE && min2.x < max1.x + TOLERANCE && min1.y < max2.y + TOLERANCE && min2.y < max1.y + TOLERANCE);
		}

		/**
		 * 2直線(線分)の交点
		 * @param s1 対象となる直線(線分)
		 * @param s2 対象となる直線(線分)
		 * @param p 交点
		 * @param segment falseの場合、単に直線の交点を求める。trueの場合、線分(範囲を持った直線)として交点を求める。
		 * @return segmentがfalseの場合
		 *         0 交点あり
		 *         1 交点なし(平行線)
		 *         2 交点なし(同一直線)
		 *         segmentがtrueの場合
		 *         0 交点あり(交点が線分の範囲内)
		 *         1 交点なし(交点が線分の範囲外/平行線/同一直線上だが線分に重なりがない)
		 *         2 交点なし(同一直線上で線分に重なりがある)
		 */
		static int crossPoint(const Segment &s1, const Segment &s2, Point2D *p, bool segment = false);

		/**
		 * srcを進行方向左にdだけシフトさせたセグメントを返します。
		 * dがマイナスの場合は右にシフトさせます。
		 */
		inline static Segment shiftSegment(const Segment &src, double d) {
			double sx = d * (-src.y) / src.length();
			double sy = d * (+src.x) / src.length();
			Point2D p1(src.p1.x + sx, src.p1.y + sy);
			Point2D p2(src.p2.x + sx, src.p2.y + sy);
			Segment shifted(p1, p2);
			return shifted;
		}

		/**
		 * ポリゴンの各辺がx軸と為す角度のリストを取得します。
		 * @param polygon 対象となるポリゴン
		 * @return 角度のリスト(最初の要素は、対象となるポリゴンの頂点インデックス0と1で構成される辺の角度)
		 */
		inline static std::vector<double> getSegmentAngles(const Polygon_ &p) {
			return getAngles(createSegments(p));
		}

		/** [-M_PI, M_PI]の範囲の角度 */
		inline static double normalizeRadian(double radian) {
			assert(std::isfinite(radian));
			while (radian > M_PI) radian -= M_PI_X2;
			while (radian < -M_PI) radian += M_PI_X2;
			return radian;
		}
		/** 角度が同じか判定 */
		inline static bool angleEquals(double a1, double a2) {
			double d = normalizeRadian(a2 - a1);
			return fabs(d) < TOLERANCE_ANGLE;
		}
		inline static bool angleEquals_(double a1, double a2) {
			double d = normalizeRadian(a2 - a1);
			return fabs(d) < TOLERANCE_ANGLE_2;
		}
		/** 周期境界条件下で1個前の頂点インデックス */
		inline static int prevIndex(size_t i, size_t size) {
			return (int) (i == 0 ? size - 1 : i - 1);
		}
		/** 周期境界条件下で1個後の頂点インデックス */
		inline static int nextIndex(size_t i, size_t size) {
			return (int) (i == size - 1 ? 0 : i + 1);
		}

	private:
		/**
		 * 点を削除します。
		 * @param polygon 対象となるポリゴン
		 * @param index 削除対象点のインデックス
		 */
		static void omitPoint(Polygon_ polygon, int index);

		/**
		 * 同じ点が連続していないかチェックします。
		 * 同じ点が連続した場合、前側の点を削除します。
		 * @param polygon 対象となるポリゴン
		 * @return 0 正常終了
		 *        -1 異常終了(点の個数が3個未満)
		 */
		static int correctSamePoints(Polygon_ polygon);
		static int correctSamePoints_(Polygon_ polygon);

		/**
		 * 同じ直線上の点が3個以上連続していないかチェックします。
		 * 同じ直線上の点が3個以上連続した場合、中間点を削除します。
		 * @param polygon 対象となるポリゴン
		 * @return 0 正常終了
		 *        -1 異常終了(点の個数が3個未満)
		 */
		static int correctColinearPoints(Polygon_ polygon);
		static int correctColinearPoints_(Polygon_ polygon);

		/**
		 * ポリゴンが自己交差していないかチェックします。
		 * @param polygon 対象となるポリゴン
		 * @return 0 正常終了
		 *        -1 異常終了(自己交差あり)
		 */
		static int checkSelfIntersection(Polygon_ polygon);

		/**
		 * 点列の順序が時計回りになっているか判定します。
		 * @param polygon 対象となるポリゴン
		 * @return 時計回りになっている場合、true
		 */
		static bool isClockwise(const Polygon_ &polygon);

		/**
		 * 点列の順序を逆転させます。
		 * @param polygon 対象となるポリゴン
		 */
		static void reverse(Polygon_ polygon);

		/**
		 * 加算用／減算用ポリゴンのリストを生成します。
		 * @param segments セグメントのリスト
		 * @param shiftValues シフト値のリスト(領域の外側方向が正、内側方向が負)
		 */
		static int createShiftPolygons(const Segments_ &segments, std::vector<double> &shiftValues, Polygons_ shiftPolygons, bool increase = true);
		static int createShiftPolygons_internal(const Segments_ &segments, std::vector<double> &shiftValues, Polygons_ shiftPolygons, bool increase);

		/**
		 * srcPolygonにshiftPolygonsを加算処理して、結果をresultPolygonsに格納します。
		 * @param srcPolygon 加算対象となるポリゴン
		 * @param shiftPolygons 加算するポリゴンのリスト
		 * @param resultPolygons 結果ポリゴンのリスト
		 * @return 0 正常終了
		 *        -1 異常終了
		 */
		static int add(const Polygon_ &srcPolygon, const Polygons_ &shiftPolygons, Polygons_ resultPolygons);
		static int add_(const Polygon_ &srcPolygon, const Polygons_ &shiftPolygons, Polygons_ resultPolygons);

		/**
		 * srcPolygonからshiftPolygonsを減算処理して、結果をresultPolygonsに格納します。
		 * @param srcPolygon 減算対象となるポリゴン
		 * @param shiftPolygons 減算するポリゴンのリスト
		 * @param resultPolygons 結果ポリゴンのリスト
		 * @return 0 正常終了
		 *        -1 異常終了
		 */
		static int subtract(const Polygon_ &srcPolygon, const Polygons_ &shiftPolygons, Polygons_ resultPolygons);
		static int subtract_(const Polygon_ &srcPolygon, const Polygons_ &shiftPolygons, Polygons_ resultPolygons);

	private: // inline
		/** ベクトルs1, s2の内積 */
		inline static double innerProduct(const Segment &s1, const Segment &s2) {
			return (s1.x * s2.x + s1.y * s2.y);
		}
		/** ベクトルs1, s2の外積 */
		inline static double crossProduct(const Segment &s1, const Segment &s2) {
			return (s1.x * s2.y - s1.y * s2.x);
		}
		/** ラジアンを度に変換 */
		inline static double radian2Degree(double radian) {
			return (180.0 * radian / M_PI);
		}

	private:
		/** ポリゴンの加算/減算処理で頂点の対応がずれた場合に、頂点の順序を訂正します */
		static double correctAlignment(const Polygon_ &src, Polygon_ &p);
		static double diffAngles(const std::vector<double> &angles1, const std::vector<double> &angles2);
		static Polygon_ shiftOrder(const Polygon_ &p);

	public:
		/** 任意の点列を、その点列で描かれる図形の包絡線ポリゴンに変換します */
		static int getEnvelopePolygon2(const Polygon_ &points, Polygon_ result, bool removeCollinear = true);
		static int getEnvelopePolygon(const Polygon_ &points, Polygon_ result, bool removeCollinear = true);
		static bool findSamePointIndex(const Polygon_ &polygon, int *index1, int *index2);
		static void dividePolygon(const Polygon_ &polygon, int index1, int index2, Polygons_ results);

		static void debugPrint(const std::string &filename, const Polygon_ &polygon);
		static void debugPrint(const std::string &filename, const Polygon_ &polygon1, const Polygon_ &polygon2);
		static void debugPrint(const std::string &filename, const Polygon_ &polygon, const Polygons_ &polygons);
		static void debugPrintSvgHeader(std::ofstream &myFile, const Polygon_ &polygon);
		static void debugPrintSvg(std::ofstream &myFile, const Polygon_ &polygon, int index, double width, const std::string &color);
		static void debugPrintSvg(std::ofstream &myFile, const Segments_ &segments, int index, double width, const std::string &color);
		static void debugPrintSvgFooter(std::ofstream &myFile);

		static int getMaxRightRect(const Polygon_ &src, Polygon_ result);
		static int getMaxRightRect_internal(const std::vector<bool> &squares, const int SIZE_X, const int SIZE_Y, int *_ix1, int *_ix2, int *_iy1, int *_iy2);

	};
}} // namespace yanmar::PathPlan

#endif

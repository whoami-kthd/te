// Yanmar Confidential 20200918
//
//  FieldGenerator.cpp
//  FieldGenerator
//

#include <iostream>
#include <fstream>
#include <iomanip>
#include <random>

#include <boost/lexical_cast.hpp>

#include "FieldGenerator.hpp"
#include "Geometry/Coordinates.hpp"

using namespace yanmar::PathPlan;

/**
 * ランダムに圃場を生成して、ファイルに出力します。
 * @param numFields 生成する圃場の個数
 * @param scaleX 圃場のx軸方向の大きさ
 * @param scaleY 圃場のy軸方向の大きさ
 * @param numPoints 初期配置する頂点数
 */
void FieldGenerator::generateRandomField(const std::string &path, int numFields, int scaleX, int scaleY, int numPoints) {

	// 基準点
	const GeoPoint REF_POS = GeoPoint(35.0 * M_PI / 180.0, 135.0 * M_PI / 180.0);

	// 通し番号の桁数
	int digit = 0;
	for (int i = numFields; i > 0; i /= 10) {
		++digit;
	}

	std::random_device rd;
	const double sx = scaleX / (double) rd.max();
	const double sy = scaleY / (double) rd.max();
	Polygon_ points = Polygon_(new Polygon);
	Polygon_ randomPolygon = Polygon_(new Polygon);
	Geodesic converter;
	converter.setRefPos(REF_POS);
	std::vector<GeoPoint> randomField;
	int errCount = 0;

	for (int i = 0; i < numFields; ++i) {
		randomPolygon->clear();
		while (randomPolygon->size() == 0) {
			// numPoints個の頂点をランダムに配置する
			points->clear();
			for (int j = 0; j < numPoints; ++j) {
				points->push_back(Point2D(rd() * sx, rd() * sy));
			}
			// 上記の点列で描かれる図形の包絡線ポリゴンを求める
			if (PolygonUtil::getEnvelopePolygon(points, randomPolygon) < 0) {
				// 包絡線ポリゴンの計算に失敗した場合
				// 出力ファイル名の生成
				std::ostringstream oss;
				oss << path << "EnvelopeFailed_" << std::setw(digit) << std::setfill('0') << (++errCount) << ".txt";
				const std::string filename = oss.str();
				// ファイル出力
				output(filename, points);
				randomPolygon->clear();
				continue;
			}
			if (randomPolygon->size() < numPoints) {
				// 包絡線ポリゴンの頂点数が少ない場合
				randomPolygon->clear();
				continue;
			}
			int retryCount = ((int) randomPolygon->size() - numPoints) * 2 + 5;
			while (randomPolygon->size() > numPoints && --retryCount > 0) {
				Polygon_ tmp = Polygon_(new Polygon);
				int omit = rd() / (double) rd.max() * randomPolygon->size();
				for (int j = 0; j < randomPolygon->size(); ++j) {
					if (j == omit) continue;
					tmp->push_back(randomPolygon->at(j));
				}
				if (PolygonUtil::checkPolygon(tmp) < 0 || PolygonUtil::simplify_(tmp)) continue;
				randomPolygon->swap(*tmp);
			}
			if (randomPolygon->size() != numPoints) {
				// 包絡線ポリゴンの頂点数がnumPointsと異なる場合
				randomPolygon->clear();
				continue;
			}
		}
		// 基準点で座標変換する
		randomField.clear();
		for (int j = 0; j < randomPolygon->size(); ++j) {
			GeoPoint gp = randomPolygon->at(j);
			randomField.push_back(converter.convert(gp));
		}
		// 出力ファイル名の生成
		std::ostringstream oss;
		oss << path << "Field_" << scaleX << "x" << scaleY << "_" << numPoints << "_" << std::setw(digit) << std::setfill('0') << (i + 1) << ".txt";
		const std::string filename = oss.str();
		// ファイル出力
		output(filename, randomField);
	}
	std::cout << "Info, getEnvelopePolygon failed count[" << errCount << "].\n";
}

/**
 * 圃場ファイルを出力します。
 * @param filename 出力先
 * @param field 圃場データ
 */
void FieldGenerator::output(const std::string &filename, const std::vector<GeoPoint> &field) {
	std::ofstream myFile;
	myFile.open(filename);
	if (myFile.fail()) {
		std::cout << "Warning, failed to open filename[" << filename << "].\n";
		return;
	}
	for (int j = 0; j < field.size(); ++j) {
		myFile << std::setprecision(16) << field[j].x << "," << std::setprecision(16) << field[j].y << std::endl;
	}
	myFile.close();
	std::cout << "Info, output field, filename[" << filename << "].\n";
}

/**
 * 包絡線ポリゴンの計算に失敗した場合に、点列データを出力します。
 * @param filename 出力先
 * @param points 点列データ
 */
void FieldGenerator::output(const std::string &filename, const Polygon_ &points) {
	std::ofstream myFile;
	myFile.open(filename);
	if (myFile.fail()) {
		std::cout << "Warning, failed to open filename[" << filename << "].\n";
		return;
	}
	for (int j = 0; j < points->size(); ++j) {
		myFile << std::setprecision(16) << points->at(j).x << "," << std::setprecision(16) << points->at(j).y << std::endl;
	}
	myFile.close();
	std::cout << "Warning, getEnvelopePolygon failed, filename[" << filename << "].\n";
}

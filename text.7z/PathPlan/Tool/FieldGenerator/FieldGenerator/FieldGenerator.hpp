// Yanmar Confidential 20200918
//
//  FieldGenerator.hpp
//  FieldGenerator
//

#ifndef FieldGenerator_hpp
#define FieldGenerator_hpp

#include "PolyLib/PolygonUtil.hpp"

namespace yanmar { namespace PathPlan {
	class FieldGenerator
	{
	public:
		static void generateRandomField(const std::string &path, int numFields, int scaleX, int scaleY, int numPoints);
		static void output(const std::string &filename, const std::vector<GeoPoint> &field);
		static void output(const std::string &filename, const Polygon_ &points);
	};
}} // namespace yanmar::PathPlan

#endif /* FieldGenerator_hpp */

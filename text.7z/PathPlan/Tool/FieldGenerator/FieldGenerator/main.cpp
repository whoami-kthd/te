// Yanmar Confidential 20200918
//
//  main.cpp
//  FieldGenerator
//

#include <iostream>

#include <sys/stat.h>
#include <boost/lexical_cast.hpp>

#include "FieldGenerator.hpp"

using namespace yanmar::PathPlan;

void printUsage() {
	std::cout << "Usage\n";
	std::cout << " FieldGenerator [OPTION]...\n";
	std::cout << "Options\n";
	std::cout << " -o=PATH\n";
	std::cout << "    output path. [./field/]\n";
	std::cout << " -n=INTEGER\n";
	std::cout << "    number of fields to generate. [>=1, default=100]\n";
	std::cout << " -x=INTEGER\n";
	std::cout << "    field size for x‐axis in meter (Lon). [>=30, default=1000]\n";
	std::cout << " -y=INTEGER\n";
	std::cout << "    field size for y‐axis in meter (Lat). [>=30, default=1000]\n";
	std::cout << " -c=INTEGER\n";
	std::cout << "    number of random-generated points per field. [>=3, default=30]\n";
	std::cout << "    NOT equals to number of vertexes of generated field.\n";
	std::cout << "Example\n";
	std::cout << " FieldGenerator -o=./field_20161031/ -n=3 -x=100 -y=100 -c=10\n";
}

bool validate(const std::string &s, int *n, int min, const std::string &arg) {
	int num = 0;
	try {
		num = boost::lexical_cast<int>(s);
	} catch (const std::exception &err) {
		std::cout << "Number Format Error.\n";
		std::cout << " [" << arg << "]\n";
		printUsage();
		return false;
	}
	if (num < min) {
		std::cout << "Invalid Argument Error.\n";
		std::cout << " [" << arg << "], " << num << " < " << min << "\n";
		printUsage();
		return false;
	}
	*n = num;
	return true;
}

bool validate(std::string &path) {
	size_t len = path.length();
	if (len == 0) {
		// 空文字列の場合はエラー
		std::cout << "Invalid Argument Error.\n";
		std::cout << " PATH is empty string.\n";
		printUsage();
		return false;
	}
	if (path.substr(len - 1, 1) != "/") {
		// 末尾に"/"を追加
		path += "/";
	}
	// 情報の取得
	struct stat st;
	if (stat(path.c_str(), &st) == 0) {
		// 情報の取得に成功
		if ((st.st_mode & S_IFMT) == S_IFDIR) {
			// 出力先パスがディレクトリ
			return true;
		}
		// 出力先パスがディレクトリではない
		std::cout << "Invalid Argument Error.\n";
		std::cout << " PATH[" << path << "] is NOT a directory.\n";
		printUsage();
		return false;
	}
	// 情報の取得に失敗 (権限がない、または存在しない?)
	std::cout << "Info, PATH[" << path << "] does NOT exist.\n";
	// ディレクトリの作成
	if (mkdir(path.c_str(), 0777) == 0) {
		// ディレクトリの作成に成功
		std::cout << "Info, mkdir(" << path << ", 0777) success.\n";
		return true;
	}
	// ディレクトリの作成に失敗 (権限がない、または同名のファイルが存在する?)
	std::cout << "Error, mkdir(" << path << ", 0777) failed.\n";
	printUsage();
	return false;
}

int main(int argc, const char * argv[]) {

	// デフォルトのパラメータ
	std::string path = "./field/"; // 出力先
	int numFields = 100; // 生成する圃場の個数
	int scaleX = 1000; // 圃場のx軸方向の大きさ
	int scaleY = 1000; // 圃場のy軸方向の大きさ
	int numPoints = 30; // 初期配置する頂点数

	for (int i = 1; i < argc; ++i) {
		std::string arg = argv[i];
		if (arg.length() < 4) {
			// 無効なオプションが指定された
			std::cout << "Invalid Option Error.\n";
			std::cout << " [" << arg << "]\n";
			printUsage();
			return 0;
		}
		std::string option = arg.substr(0, 3);
		std::string parameter = arg.substr(3);
		if (option == "-o=") {
			// 出力先
			path = parameter;
		} else if (option == "-n=") {
			// 生成する圃場の個数
			if (!validate(parameter, &numFields, 1, arg)) return 0;
		} else if (option == "-x=") {
			// 圃場のx軸方向の大きさ
			if (!validate(parameter, &scaleX, 30, arg)) return 0;
		} else if (option == "-y=") {
			// 圃場のy軸方向の大きさ
			if (!validate(parameter, &scaleY, 30, arg)) return 0;
		} else if (option == "-c=") {
			// 初期配置する頂点数
			if (!validate(parameter, &numPoints, 3, arg)) return 0;
		} else {
			// 無効なオプションが指定された
			std::cout << "Invalid Option Error.\n";
			std::cout << " [" << arg << "]\n";
			printUsage();
			return 0;
		}
	}
	// 出力先のチェック
	if (!validate(path)) return 0;

	FieldGenerator::generateRandomField(path, numFields, scaleX, scaleY, numPoints);
	return 0;
}

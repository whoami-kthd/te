// Yanmar Confidential 20200918
/**
 @file GuidanceDataChecker.cpp
 */
#include "GuidanceDataChecker.hpp"

#include <dirent.h>
#include <cstdio>
#include <string>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdexcept>
#include <sys/stat.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include "Geometry/Geometry.hpp"
#include "Geometry/Coordinates.hpp"
#include "PathLib/Segment.hpp"

using namespace yanmar::PathPlan;

namespace {
    std::string to_string(const GeoPoint& point, const char* caption = "") {
        std::stringstream ss;
        ss << std::setprecision(15) << std::showpoint
        << caption << "(" << point.lat << ", " << point.lon << ")";
        return ss.str();
    }
} // anonymous namespace

GuidanceDataChecker::GuidanceDataChecker() = default;
GuidanceDataChecker::~GuidanceDataChecker() = default;

/**
 * パラメータ設定
 * @param[in] files テスト対象ファイルリスト
 */
void GuidanceDataChecker::setParameter(const std::vector<std::string>& files) {
	inputFiles = files;
}

/**
 * 対象ファイルチェック
 * @return 0:正常終了
 */
int GuidanceDataChecker::start() {
	// 圃場ファイルのパスリストの数だけループ
	for (const auto& filename: inputFiles) {
        const std::string filepath = inputPath + filename;
		// パス生成条件
		check(filepath);
	}

	return 0;
}

struct PpSegment : public yanmar::PathPlan::LineSegment {
    int segType = 0;
    int rideType = 0;
    int turnType = 0;
//    int moveDirection = 0;
};

GeoPoint makeGeoPoint(const std::string& strLat, const std::string& strLon) {
    const double lat = boost::lexical_cast<double>(strLat);
    const double lon = boost::lexical_cast<double>(strLon);
    GeoPoint point{lat, lon};
    return point;
}

namespace PP {
    enum {
        Name,
        SegType,
        RideType,
        StartLon,
        StartLat,
        EndLon,
        EndLat,
        CenterLon,
        CenterLat,
        TurnType,
        TurnRadius,
        TurnDirection,
        MoveDirection
    };
};

int GuidanceDataChecker::check(const std::string& filepath) {
    
    auto csv = readGuidanceData(filepath);
    if (csv.empty()) {
        return -1;
    }
    
    auto errors = check(csv);
    
    if (errors.empty()) {
        std::cout << filepath << "\t" << "VALID" << EOL;
    } else {
        std::cout << filepath << "\t" << errors.size() << " errors" << EOL;
        for (auto msg : errors) {
            std::cout << msg << EOL;
        }
    }
        
    return 0;
}

GuidanceDataChecker::Errors GuidanceDataChecker::check(const Csv::CsvData& csv) {
    errors.clear();

    auto pathData = csv.getRows("PP");
    if (pathData.empty()) {
        errorOut(-1, "ERROR_EMPTY_PP");
        return errors;
    }

    std::vector<PpSegment> path;
    for (const auto& ppseg : pathData) {
        PpSegment seg;
        seg.segType = boost::lexical_cast<int>(ppseg.at(PP::SegType));
        seg.enterPoint() = makeGeoPoint(ppseg.at(PP::StartLat), ppseg.at(PP::StartLon));
        seg.leavePoint() = makeGeoPoint(ppseg.at(PP::EndLat), ppseg.at(PP::EndLon));
        seg.rideType = boost::lexical_cast<int>(ppseg.at(PP::RideType));
        seg.turnType = boost::lexical_cast<int>(ppseg.at(PP::TurnType));
        seg.direction = boost::lexical_cast<int>(ppseg.at(PP::MoveDirection));
        path.push_back(seg);
    }

    // 先頭のチェック
    {
        auto startNav = path.front();
        if (startNav.direction == SegmentDir::REVERSE) {
            // 先頭がバックになっている
            errorOut(0, "ERROR_START_WITH_REVERSE");
        }

        if (startNav.segType == SegmentType::ARCSEG) {
            std::string err;
            // 先頭がカーブになっている
            errorOut(0, "ERROR_START_WITH_CURVE");
        }
    }

    // 終端のチェック
    {
        auto endNav = path.back();
        if (endNav.direction == SegmentDir::REVERSE) {
            std::string err;
            // 終端折り返しになっているのにLEGFOLDフラグが立っていない
            if ((endNav.turnType & Param::Path::Turn::Type::Flag::LEGFOLD) != Param::Path::Turn::Type::Flag::LEGFOLD) {
                const int index = (int)path.size() - 1;
                errorOut(index, "ERROR_MIN_ENDNAV_LEGFOLD_TURNTYPE_MISMACH");
            }
        }
    }
    
    for (auto its = path.cbegin(); its != path.cend(); its++) {
        auto ite = std::next(its);
        if (ite == path.cend()) {
            break;
        }

        auto eSeg = *its;
        auto lSeg = *ite;
        int index = (int)distance(path.cbegin(), its);

        // 全セグメント対象
        {
            const double ONE_M  = 0.0000100;
            const double length = eSeg.length();
            if (lSeg.direction == SegmentDir::REVERSE &&
                eSeg.direction == SegmentDir::FORWARD && length < ONE_M) {
                // バックセグメント前の前進セグメントが1m未満である
                // - 折り返し移動する場合、制動距離を担保できないため。
                std::string err = "ERROR_SHORT_BEFORE_REFRECT\t" +  to_string(length);
                errorOut(index, err);
            }
        }

        // この後ろは直線セグメントのみ対象
        if (!(eSeg.segType == 1 && lSeg.segType == 1)) {
            continue;
        }

        const double length = eSeg.length();
        const double connect = (eSeg.leavePoint() == lSeg.enterPoint());
        const double dp = eSeg.getDotProduct(lSeg);
        
        if (length == 0.0) {
            // 長さ0のセグメントがある
            errorOut(index, "ERROR_ZERO_LENGTH");
        } else if (!connect) {
            // 接続していないセグメントがある
            errorOut(index, "ERROR_DISCONNECT");
        } else if (0.0 <= dp && eSeg.direction != lSeg.direction) {
            // セグメント間は折り返していないが前進/後退が変化する
            errorOut(index, "ERROR_SMOOTH_BUT_REVERSED");
        } else if (dp < 0.0 &&  eSeg.direction == lSeg.direction) {
            // セグメント向きは折り返しているが前進/後退が変化しない
            errorOut(index, "ERROR_REFRECT_NOT_REVERSED");
        }
    }

    struct IteratorRange {
        using value_type = std::vector<PpSegment>::const_iterator;
        IteratorRange(const std::vector<PpSegment>& path) :
            begin(path.cbegin()), end(path.cbegin())
        {}

        value_type begin;
        value_type end;
    };

    // αターン間接続
    // - αターン間はナビゲーションセグメントを挟む必要がある
    for (IteratorRange range{path}; range.begin != path.cend(); range.begin = range.end) {
        // αターンの範囲
        range.begin = std::find_if(range.begin, path.cend(), [](const PpSegment& seg) { return (seg.turnType == 6); });
        range.end = std::find_if_not(range.begin, path.cend(), [](const PpSegment& seg) { return (seg.turnType == 6); });

        if (range.begin == path.cend()) {
            break;
        }
        int index = (int)std::distance(path.cbegin(), range.begin);

        // αターン中のバックカーブセグメント数
        const auto revCurveCount = std::count_if(range.begin, range.end, [](const PpSegment& seg) { return (seg.segType == 0 && seg.direction == SegmentDir::REVERSE); });

        if (revCurveCount != 1) {
            // アルファターンが癒合している
            // - バックカーブが一つでない
            errorOut(index, "ERROR_COALESCENT_ALPHATURN");
        }
    }

    return errors;
}

/**
 * ガイダンスデータCSV読み込み
 * @param[in] filename ファイルパス
 * @return 0:正常終了
 */
Csv::CsvData GuidanceDataChecker::readGuidanceData(const std::string &filename) {
    Csv::CsvData csvData{};

    std::ifstream inFile{filename, std::ios::binary | std::ios::ate};
    if (inFile.fail()) {
        std::cout << "[Warning] failed to open filename[" << filename << EOL;
        return csvData;
    }

    try {
        auto size = inFile.tellg();
        std::string csvString(size, '\0'); // construct string to stream size
        inFile.seekg(0);
        if (inFile.read(&csvString[0], size)) {
//            std::cout << csvString << '\n';
            csvData.parse(csvString);
        }
	} catch (const std::exception &err) {
		inFile.close();
		std::cout << "[Warning] failed to read filename[" << filename << "]" << EOL;
		return csvData;
	}

    return csvData;
}

/**
 ディレクトリ作成
 
 @param[in] dir 生成するディレクトリパス
 
 @return 処理後の指定ディレクトリの状態
 @retval true   存在する
 @retval false  不明
 */
bool makeSureDir(const std::string& dir) {
    int result = mkdir(dir.c_str(), 0777);
    return (result == 0 || result == EEXIST);
}
    
int movefile(const std::string &src, const std::string &dst) {
    const int result = rename(src.c_str(), dst.c_str());
    if (result != 0) {
        std::cout << "[Warning] failed to move from filename[" << src << "]" << EOL;
        std::cout << "                          to filename[" << dst << "]." << EOL;
    }
    return result;
}

int copyfile(const std::string &src, const std::string &dst) {
    std::ifstream inFile;
    inFile.open(src);
    if (inFile.fail()) {
        std::cout << "[Warning] failed to copy from filename[" << src << "]" << EOL;
        std::cout << "                          to filename[" << dst << "]." << EOL;
        std::cout << "         failed to open src file." << EOL;
        return -1;
    }
    std::ofstream outFile;
    outFile.open(dst);
    if (outFile.fail()) {
        std::cout << "[Warning] failed to copy from filename[" << src << "]" << EOL;
        std::cout << "                          to filename[" << dst << "]." << EOL;
        std::cout << "         failed to open dst file." << EOL;
        return -1;
    }
    outFile << inFile.rdbuf() << std::flush;
    outFile.close();
    inFile.close();
    return 0;
}


void GuidanceDataChecker::errorOut(int lineIndex, const std::string& err) {
    if (!err.empty()) {
        std::stringstream ss;
        ss << lineIndex << "\t" << err;
        errors.push_back(ss.str());
    }
}

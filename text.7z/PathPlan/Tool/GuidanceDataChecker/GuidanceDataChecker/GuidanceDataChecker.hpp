// Yanmar Confidential 20200918
/**
 @file GuidanceDataChecker.hpp
 */
#pragma once

#include "Option.hpp"

#include <map>
#include <array>
#include <fstream>
#include <stdexcept>

#include "PathPlanIF.hpp"
#include "DataConverter/Csv.hpp"

using GeoPoint = yanmar::PathPlan::GeoPoint;
namespace Csv = yanmar::PathPlan::Csv;

class GuidanceDataChecker
{
public:
    using Errors = std::vector<std::string>;
    
    GuidanceDataChecker();
    ~GuidanceDataChecker();
    void setParameter(const std::vector<std::string>& inputFiles);
    int start();
    int check(const std::string& filepath);
    Errors check(const Csv::CsvData& csv);

    // パラメータ変換用テンプレート
    template<typename T, typename U>
    static T getValue(U str);

private:
    int getFilenames(std::vector<std::string> &filenames);
    Csv::CsvData readGuidanceData(const std::string &filename);
    void errorOut(int lineIndex, const std::string& err);

public:
//    std::string _inputFilename;

public:
    std::string inputPath;
    std::vector<std::string> inputFiles;
    std::vector<std::string> errors;
};

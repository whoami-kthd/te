// Yanmar Confidential 20200918
/**
 @file Option.cpp
 */

#include "Option.hpp"

#include <cstdio>
#include <string>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdexcept>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace yanmar::PathPlan;

namespace {
#pragma mark - local scope free functions

    std::string to_string(const GeoPoint& point, const char* caption = "") {
        std::stringstream ss;
        ss << std::setprecision(15) << std::showpoint
        << caption << "(" << point.lat << ", " << point.lon << ")";
        return ss.str();
    }
    

} // anonymous namespace


namespace yanmar { namespace PathPlan { namespace Options {
#pragma mark - other functions

    template<>
    GeoPoint parse(const std::string& instr) {
        GeoPoint p;
        std::vector<std::string> strs;
        boost::split(strs, instr, boost::is_any_of(","));
        std::for_each(strs.begin(), strs.end(), [](std::string& str) { boost::trim(str); });
        p.lat = boost::lexical_cast<double>(strs[0]);
        p.lon = boost::lexical_cast<double>(strs[1]);
        
        return GeoPoint{};
    }


#pragma mark - Option value name tables
    // テーブル定義マクロ
#define DEF_VALUE_NAME_TABLE(v) v::table_t v::vnTable
    // オプションテーブルの実体化
//    DEF_VALUE_NAME_TABLE(GeneratePathType_t);

}}} // namespace yanmar::PathPlan::Option

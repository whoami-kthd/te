// Yanmar Confidential 20200918
/**
 @file Option.hpp
 
 handling command-line options.
 */
#pragma once

#include "../../PathPlanTest/PathPlanTest/ValueKey.hpp"

#include <map>
#include <array>
#include <fstream>
#include <stdexcept>

#include "PathPlanIF.hpp"

namespace yanmar { namespace PathPlan {
namespace Options {

    // パラメータ変換用テンプレート
    template<typename T, typename U>
    static T getValue(U str);
    
    //
    // オプション値-値名称
    //

    // 作業方向モード
    struct InputPath {
        static constexpr auto signature = "-inFile";
        static constexpr auto usage =
                " -inFile=PATH [./result/]\n"
                "    path of directory or a file.\n";
        static constexpr auto defaultValue = "./result/";
        std::string value = defaultValue;
        
        InputPath& operator=(const std::string& str) {
            value = str;
            return *this;
        }
    };

} // namespace Options
}} // namespace yanmar::PathPlan

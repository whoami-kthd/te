// Yanmar Confidential 20200918
/**
 @file main.cpp
 */

#define _USE_MATH_DEFINES
#include <cstddef>
#include <cstdlib>
#include <cmath>
#include <iostream>
#include <iomanip>
// #include <filesystem>
#include <dirent.h>
#include <sys/stat.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include "GuidanceDataChecker.hpp"
#include "Geometry/Geometry.hpp"
#include "PolyLib/Common.h"

using namespace yanmar::PathPlan;

namespace {
const std::string inputPath_default = "./result/";

}
// constexpr static auto EOL = "\n";;

void printUsage() {
    GuidanceDataChecker ppt;
    
    std::cout << "Usage\n" <<
    " GuidanceDataChecker [OPTION]...\n"
    << std::endl;
    
    std::cout <<
    "[Options]\n"
    "     -OPTIONNAME={option values 1 | 2 | 3 ...} [the value in default]\n"
    " note:All OPTIONNAMEs are case sensitive, value strings are case insensitive.\n"
    "      Additionally, there are general alias for boolean value as: {0|1} = {off | on} = {false | true}.\n"
    "Path:\n"
    " -infile=FILENAME\n"
    "	Just one input field file to test.\n"
    << std::endl;
}

/**
 * 範囲クラス
 *
 * @tparam T 数値型
 */
template<typename T>
class Range
{
public:
    Range() = default;
    Range(T aLower, T aUpper) :
    lower(aLower), upper(aUpper)
    {}
    
    /// 範囲内検査
    bool within(T value) const
    {
        return (lower <= value) && (value <= upper);
    }
    
    T lower = 0;
    T upper = 0;
};

/**
 * パラメータ取得(有効範囲付き)
 *
 *  sが数値として解釈でき、rangeの範囲内であればその値をnに格納しtrueを返す。
 *  - もしsがパラメータとして無効な場合、falseを返す。このときnは不定。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   range   パラメータ値の有効範囲
 * @param[in]   arg     1パラメータの全体
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
template<typename T>
bool validate(const std::string& s, T& n, Range<T>&& range, const std::string& arg) {
    T num = 0;
    try {
        num = boost::lexical_cast<T>(s);
    } catch (const std::exception &err) {
        std::cout << "Number Format Error.\n";
        std::cout << " [" << arg << "]\n";
        return false;
    }
    if (!range.within(num)) {
        std::cout << "Invalid Argument Error.\n";
        std::cout << " [" << arg << "] out of range: [" << range.lower << ", " << range.upper << "]\n";
        return false;
    }
    n = num;
    return true;
}

/**
 * パラメータ取得(最小値付き)
 *
 * sが数値として解釈でき、min以上であればその値をnに格納しtrueを返す。
 *  - sがパラメータとして無効な場合、falseを返す。このときnは不定。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   min     パラメータ値の最小値
 * @param[in]   arg     1パラメータの全体
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
template<typename T>
bool validate(const std::string& s, T& n, T min, const std::string& arg) {
    T num = 0;
    try {
        num = boost::lexical_cast<T>(s);
    } catch (const std::exception &err) {
        std::cout << "Number Format Error.\n";
        std::cout << " [" << arg << "]\n";
        return false;
    }
    if (num < min) {
        std::cout << "Invalid Argument Error.\n";
        std::cout << " [" << arg << "] less than " << min << "\n";
        return false;
    }
    n = num;
    return true;
}


/**
 * パラメータ取得(bool)
 *
 * sがbool値として解釈できればnに格納し、trueを返す。
 *  - sがパラメータとして無効な場合、falseを返す。このときnは不定。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   arg     1パラメータの全体(エラー出力用)
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
bool validate(std::string s, bool& n, const std::string& arg) {
    for_each(s.begin(), s.end(), [](char& it) { it = tolower(it); } );
    
    int num = 0;
    try {
        if (s == "true" || s == "on") {
            num = 1;
        } else if (s == "false" || s == "off") {
            num = 0;
        } else {
            num = boost::lexical_cast<int>(s);
        }
    } catch (const std::exception &err) {
        std::cout << "Boolean Format Error.\n";
        std::cout << " [" << arg << "]\n";
        return false;
    }
    n = (bool)num;
    return true;
}

/**
 * resulttypeパラメータ取得(int)
 *
 * sが有効なresulttype値として解釈できればnに格納し、trueを返す。
 *  - sがパラメータとして無効な場合、falseを返す。このときnは不定。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   arg     1パラメータの全体(エラー出力用)
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
template<typename T>
bool validate(std::string s, T& type, const std::string& arg) {
    try {
        type = s;
    } catch (...) {
        std::cout << "enum value Error.\n";
        std::cout << " [" << arg << "]\n";
        return false;
    }
    
    return true;
}

/**
 * ディレクトリ確認
 *
 * sに指定されたバス(ディレクトリ)の準備をする
 *  - createフラグがtrueであれば、sに示すパスが存在しない場合にディレクトリの生成を試みる。
 *    falseであれば生成せずにfalseを返す。
 *
 * @param[in]   psth    入力パラメータ値
 * @param[in]   create  ディレクトリ生成フラグ
 *
 * @return パラメータ値が有効かどうか
 * @retval true     指定パスは有効(生成した場合を含む)
 * @retval false    指定パスは無効(アクセスできない場合を含む)
 */
bool makeSureDir(std::string& path, bool create) {
    size_t len = path.length();
    if (len == 0) {
        // 空文字列の場合はエラー
        std::cout << "Invalid Argument Error.\n";
        std::cout << " PATH is empty string.\n";
        return false;
    }
    if (path.substr(len - 1, 1) != "/") {
        // 末尾に"/"を追加
        path += "/";
    }
    // 情報の取得
    struct stat st;
    if (stat(path.c_str(), &st) == 0) {
        // 情報の取得に成功
        if ((st.st_mode & S_IFMT) == S_IFDIR) {
            // 出力先パスがディレクトリ
            return true;
        }
        // 出力先パスがディレクトリではない
        std::cout << "Invalid Argument Error.\n";
        std::cout << " PATH[" << path << "] is NOT a directory.\n";
        return false;
    }
    if (!create) {
        // 情報の取得に失敗 (権限がない、または存在しない?)
        std::cout << "Error, PATH[" << path << "] does NOT exist.\n";
        return false;
    }
    // 情報の取得に失敗 (権限がない、または存在しない?)
    std::cout << "Info, PATH[" << path << "] does NOT exist.\n";
    // ディレクトリの作成
    if (mkdir(path.c_str(), 0777) == 0) {
        // ディレクトリの作成に成功
        std::cout << "Info, mkdir(" << path << ", 0777) success.\n";
        return true;
    }
    // ディレクトリの作成に失敗 (権限がない、または同名のファイルが存在する?)
    std::cout << "Error, mkdir(" << path << ", 0777) failed.\n";
    return false;
}

/**
 * ガイダンスデータファイルリスト取得
 * @param[in] inputPath ファイルリスト取得パス
 * @return 該当ファイル名のvector
 */
std::vector<std::string> getFilenames(std::string& inputPath) {
    std::vector<std::string> filenames;
    
    if (inputPath.empty()) {
        return filenames;
    }

    if (inputPath.back() != '/' && inputPath.back() != '\\' ) {
        // 単一ファイルか?
        if (inputPath.length() < 12 ||
            inputPath.substr(0, 12) != "GuidanceData" ||
            inputPath.substr(inputPath.length() - 4, 4) != ".csv") {
            // GuidanceData*.CSVファイルのみ対象
            filenames.push_back(inputPath);
            return filenames;
        }
    }
    
#if defined(_WIN32)
    WIN32_FIND_DATAA ffd;
    DWORD dwError = 0;

    std::string path = inputPath + "\\GuidanceData*.csv";
    const char *fieldDir = path.c_str();

    HANDLE hFind = FindFirstFileA(fieldDir, &ffd);
    if (hFind == INVALID_HANDLE_VALUE) {
        return -1;
    }

    // List all the files in the directory with some info about them.

    do {
        if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            printf("  %s   <DIR>\n", ffd.cFileName);
        } else {
            const std::string filename = ffd.cFileName;
            filenames.push_back(filename);
        }
    } while (FindNextFileA(hFind, &ffd) != 0);

    dwError = GetLastError();
    FindClose(hFind);
    return dwError;
#else
    // パス指定のとき
    const char *fieldDir = inputPath.c_str();
    DIR *dp;
    dirent *entry;
    dp = opendir(fieldDir);
    if (dp == NULL) {
        std::cout << "[Error] failed to open dir[" << fieldDir << "].\n";
        return filenames;
    }
    while ((entry = readdir(dp)) != NULL) {
        std::ostringstream oss;
        oss << entry->d_name;
        const std::string filename = oss.str();
        // CSVファイルのみ対象
        if (filename.length() < 5 ||
            filename.substr(0, 12) != "GuidanceData" ||
            filename.substr(filename.length() - 4, 4) != ".csv") {
            // 上記以外のパスはスキップ
//            std::cout << "[Info] skipped filename[" << filename << "].\n";
            continue;
        }
        const std::string filepath = inputPath + filename;
        filenames.push_back(filepath);
    }
    if (filenames.size() == 0) {
        std::cout << "Error, NO data.\n";
    }

    return filenames;
#endif // _MSC_VER
}


/// タイムスタンプ文字列を返す
std::string getCurrentDateTimeString(const std::string& format = "%Y-%m-%d %H:%M:%S") {
    std::array<char, 64> buffer{0};
    time_t rawtime;
    time(&rawtime);
    const auto timeinfo = localtime(&rawtime);
    strftime(buffer.data(), sizeof(buffer), format.c_str(), timeinfo);
    
    return std::string{buffer.data()};
}

int main(int argc, const char * argv[]) {
    
    Options::InputPath inputPath;
    GuidanceDataChecker ppt;
    
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg.length() < 4) {
            // 無効なオプションが指定された
            std::cout << "Invalid Option Error.\n";
            std::cout << " [" << arg << "]\n";
            printUsage();
            return 0;
        }
        std::vector<std::string> vs;
        boost::algorithm::split(vs, arg, boost::is_any_of("="));
        if (2 < vs.size()) {
            // 無効なオプションが指定された
            std::cout << "Invalid Option Error.\n";
            std::cout << " [" << arg << "]\n";
            printUsage();
            return 0;
        }
        
        std::string option = vs[0]; // arg.substr(0, 3);
        std::string parameter = vs[1]; // arg.substr(3);
        bool optionValid = true;
        if (option == inputPath.signature) {
            // ガイダンスデータファイルの入力元
            optionValid = validate(parameter, inputPath, arg);
        } else if (option == "-help") {
            optionValid = false;
        } else {
            // 無効なオプションが指定された
            std::cout << "Invalid Option Error.\n";
            std::cout << " [" << arg << "]\n";
            optionValid = false;
        }
        
        if (!optionValid) {
            printUsage();
            return 0;
        }
    }
    
    // 入力元のチェック
    if (inputPath.value.empty()) {
        inputPath.value = inputPath_default;
        if (!inputPath.value.empty() && !makeSureDir(inputPath.value, false)) {
            return 0;
        }
    }
    
    // 対象ファイルのリストを取得
    std::vector<std::string> filenames = getFilenames(inputPath.value);
    
    // テストの実行
    std::cout << "[GuidanceDataChecker] Build " << __DATE__ " " __TIME__ << "\n"
    << "Start date :" << ::getCurrentDateTimeString() << "\n";
    
    ppt.setParameter(filenames);
    ppt.start();
    
    std::cout << "Finished :"<< ::getCurrentDateTimeString() << "\n";
    return 0;
}

// Yanmar Confidential 20200918
/** @file Option.cpp
 */

#include "Option.hpp"

#include <cstdio>
#include <string>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdexcept>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

using namespace yanmar::PathPlan;

namespace {
#pragma mark - local scope free functions

    std::string to_string(const GeoPoint& point, const char* caption = "") {
        std::stringstream ss;
        ss << std::setprecision(15) << std::showpoint
        << caption << "(" << point.lat << ", " << point.lon << ")";
        return ss.str();
    }
    

} // anonymous namespace


namespace yanmar { namespace PathPlan { namespace Options {
#pragma mark - other functions

    template<>
    GeoPoint parse(const std::string& instr) {
        GeoPoint p;
        std::vector<std::string> strs;
        boost::split(strs, instr, boost::is_any_of(","));
        std::for_each(strs.begin(), strs.end(), [](std::string& str) { boost::trim(str); });
        p.lat = boost::lexical_cast<double>(strs[0]);
        p.lon = boost::lexical_cast<double>(strs[1]);
        
        return GeoPoint{};
    }


#pragma mark - Option value name tables
    // テーブル定義マクロ
#define DEF_VALUE_NAME_TABLE(v) v::table_t v::vnTable
    // オプションテーブルの実体化
    DEF_VALUE_NAME_TABLE(GeneratePathType_t);
    DEF_VALUE_NAME_TABLE(ResultType_t);
    DEF_VALUE_NAME_TABLE(FollowPos_t);
    DEF_VALUE_NAME_TABLE(ImplementPos_t);
    DEF_VALUE_NAME_TABLE(HsMarginType_t);
    DEF_VALUE_NAME_TABLE(WorkPattern_t);
    DEF_VALUE_NAME_TABLE(WorkRotation_t);
    DEF_VALUE_NAME_TABLE(ProgressType_t);
    DEF_VALUE_NAME_TABLE(WorkPathLegType_t);
    DEF_VALUE_NAME_TABLE(PathTypeAB_t);
    DEF_VALUE_NAME_TABLE(HeadlandProcess_t);
    DEF_VALUE_NAME_TABLE(HeadlandPattern_t);
    DEF_VALUE_NAME_TABLE(HeadlandRotation_t);
    DEF_VALUE_NAME_TABLE(HeadlandCornerTurn_t);
    DEF_VALUE_NAME_TABLE(CsvCheckType_t);

#pragma mark - DirPoints

    DirPoints::DirPoints() = default;
    DirPoints::DirPoints(const DirPoints&) = default;
    
    DirPoints DirPoints::parse(const std::string& instr) {
        DirPoints retval;
        std::vector<std::string> strs;
        boost::split(strs, instr, boost::is_any_of(","));
        std::for_each(strs.begin(), strs.end(), [](std::string& str) { boost::trim(str); });
        
        if (strs.size() == 4) {
            retval[0].lat = boost::lexical_cast<double>(strs[0]);
            retval[0].lon = boost::lexical_cast<double>(strs[1]);
            retval[1].lat = boost::lexical_cast<double>(strs[2]);
            retval[1].lon = boost::lexical_cast<double>(strs[3]);
        } else {
            throw std::out_of_range(instr);
        }
        
        return retval;
    }
    
    /**
     * PathPlanTest::DirPoints 代入演算子
     */
    DirPoints DirPoints::operator=(const std::string& instr) {
        *this = DirPoints::parse(instr);
        
        return *this;
    }


#pragma mark - TractorPos

    TractorPos& TractorPos::operator=(const std::string& instr) {
        static_cast<GeoPoint>(*this) = parse<GeoPoint>(instr);
        
        return *this;
    }
    
}}} // namespace yanmar::PathPlan::Option

// Yanmar Confidential 20200918
/**
 @file Option.hpp
 
 handling command-line options.
 */
#pragma once

#include "ValueKey.hpp"

#include <map>
#include <array>
#include <fstream>
#include <stdexcept>

#include "PathPlanIF.hpp"

namespace yanmar { namespace PathPlan { namespace Options {
    // 作業方向指定座標ペア
    class DirPoints : public std::array<GeoPoint, 2> {
    public:
        static DirPoints parse(const std::string& str);
        
        DirPoints();
        DirPoints(const DirPoints&);
        
        DirPoints operator=(const std::string& instr);
    };
    
    
    // パラメータ変換用テンプレート
    template<typename T, typename U>
    static T getValue(U str);
    
    //
    // オプション値-値名称
    //

    // 作業方向モード
    struct DirMode {
        enum Mode : int {
            ANGLE_INTERVAL,
            ANGLE,
            EDGE_AROUND,
            EDGE,
            POINTS
        };
        
        Mode mode = ANGLE_INTERVAL;
        DirPoints points;
        int edge = 0;
        double angle = 0.0;
        double interval = 5.0;
        struct DirRange {
            double start = 0.0;
            double end = 180.0;
        } range;
        
        static constexpr auto signature = "-direction";
        static constexpr auto usage =
                " -direction=FLOAT\n"
                "    Angle of path direction for run once each field.(degree)\n";
    };
    
    /**
     結果ファイル形式
     
     @note  文字で与えるオプションはこのように、オプションの値value_type、value-nameテーブルvnTable[]を定義して
            後はvalue_name_t<>テンプレートクラスに任せるだけでvalidate()で文字列から値を取得できるようになる。
     */
    struct ResultType_t {
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            UNDEFINED = 0,
            EXTERNAL = 1,
            INTERNAL = 2,
            BOTH = 3,
            INIT_DEFAULT = EXTERNAL // 必須
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[4] {
            VALUE_NAME(UNDEFINED),
            VALUE_NAME(EXTERNAL),
            VALUE_NAME(INTERNAL),
            VALUE_NAME(BOTH)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-resultsvg";
        static constexpr auto usage =
                " -resultsvg={external | internal | both} [external]\n"
                "    external: Use external orient svg file for result, except failed.\n"
                "    internal: Use always internal orient svg file for result even if succeed.\n"
                "    both: save both svg files.\n";
    };
    ///  結果ファイル形式保持クラス
    using ResultType = value_name_t<ResultType_t>;
    
    /**
     生成パス種別値
     */
    class GeneratePathType_t {
    public:
        enum value_type : int {
            STANDARD    = 0,    ///< 0:シフトなし
            AB          = 2,    ///< 1:ABパス
            FITTING     = 4,     ///< 4:ならいパス
            INIT_DEFAULT = STANDARD
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[3] {
            VALUE_NAME(STANDARD),
            VALUE_NAME(AB),
            VALUE_NAME(FITTING)
        };
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-generatePathType";
        static constexpr auto usage =
                " -pathTypeAB={STANDARD | AB | SHIFTAB | FITTING} [STANDARD]\n"
                "   Path type to generate.\n";
    };
    /// 生成パス種別保持クラス
    using GeneratePathType = value_name_t<GeneratePathType_t>;
    
    /// 追走位置値
    struct FollowPos_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            UNDEFINED   = Param::Tractor::FollowPos::UNDEFINED,	///< 未定義(たぶん先頭と同値になるだろう)
            FOLLOW      = Param::Tractor::FollowPos::FOLLOW,	///< 追走(後方)
            PARALLEL    = Param::Tractor::FollowPos::PARALLEL,	///< 並走(左右は自動決定)
            RIGHT       = Param::Tractor::FollowPos::RIGHT,		///< 右追走
            CENTER      = Param::Tractor::FollowPos::CENTER,	///< 後方追走
            LEFT        = Param::Tractor::FollowPos::LEFT,		///< 左追走
            INIT_DEFAULT = UNDEFINED
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[6] {
            VALUE_NAME(UNDEFINED),
            VALUE_NAME(FOLLOW),
            VALUE_NAME(PARALLEL),
            VALUE_NAME(RIGHT),
            VALUE_NAME(CENTER),
            VALUE_NAME(LEFT)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-tr2_FollowPos";
        static constexpr auto usage =
                " -tr2_FollowPos={center | parallel} [undifined]\n"
                "    Tractor2(manned) presence and set its follow position to Tractor1.\n";
    };
    /// 追走位置値保持クラス
    using FollowPos = value_name_t<FollowPos_t>;
    
    /// 作業機位置値
    struct ImplementPos_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            UNDEFINED   = Param::Implement::Pos::UNDEFINED, ///< 未定義
            REAR        = Param::Implement::Pos::REAR,      ///< 後方
            FRONT       = Param::Implement::Pos::FRONT,     ///< 前方
            INIT_DEFAULT = UNDEFINED
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[3] {
            VALUE_NAME(UNDEFINED),
            VALUE_NAME(REAR),
            VALUE_NAME(FRONT)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-IPOS";
        static constexpr auto usage =
        " -IPOS={REAR | FRONT} [undifined]\n"
        "    Implement mount position.\n";
    };
    /// 追走位置値保持クラス
    using ImplementPos = value_name_t<ImplementPos_t>;
    
    /// 枕地・サイドマージンタイプ
    class HsMarginType_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            MINIMUM      = Param::Work::HeadlandSideMarginType::MINIMUM,      ///< 最小値
            FACTOR_EACH  = Param::Work::HeadlandSideMarginType::FACTOR_EACH,  ///< パス間隔整数倍(個別)
            FACTOR_UNITY = Param::Work::HeadlandSideMarginType::FACTOR_UNITY, ///< パス間隔整数倍(統一)
            RICE_21      = Param::Work::HeadlandSideMarginType::RICE_21,      ///< 田植機用の設定(枕地2工程/サイドマージン1工程)
            RICE_22      = Param::Work::HeadlandSideMarginType::RICE_22,      ///< 田植機用の設定(枕地2工程/サイドマージン2工程)
            INIT_DEFAULT = MINIMUM
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[5] {
            VALUE_NAME(MINIMUM),
            VALUE_NAME(FACTOR_EACH),
            VALUE_NAME(FACTOR_UNITY),
            VALUE_NAME(RICE_21),
            VALUE_NAME(RICE_22)
        };
        
        static constexpr auto signature = "-headlandSideMarginType";
        static constexpr auto usage =
                " -headlandSideMarginType={MINIMUM | FACTOR_EACH | FACTOR_UNITY | RICE_21 | RICE_22} [MINIMUM]\n"
                "    Compute type for width of Headland and Sidemargin.\n"
                "    MINIMUM     : Use minimum width for each other.\n"
                "    FACTOR_EACH : Use the different factors by caltibation width for each value.\n"
                "    FACTOR_UNITY: Use the same factor by caltibation width for both value.\n"
                "    RICE_21     : For rice planter factor, Headland: 2, Sidemargin: 1.\n"
                "    RICE_22     : For rice planter factor, Headland: 2, Sidemargin: 2.\n";

        using table_t = decltype(vnTable);
    };
    /// 枕地・サイドマージンタイプ保持クラス
    using HsMarginType = value_name_t<HsMarginType_t>;
    
    /// 作業パターン
    class WorkPattern_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            UNIDIRECTION    = Param::Work::Pattern::UNIDIRECTION,      ///< 一方向
            BIDIRECTION     = Param::Work::Pattern::BIDIRECTION,       ///< 両方向
            CYCLONE         = Param::Work::Pattern::CYCLONE,           ///< 内向き渦巻き生成(外周から中心への単一作業パス)
            SEMICYCLONE     = Param::Work::Pattern::SEMICYCLONE,       ///< 内向き準渦巻きパターン(複数作業パスを外側から処理)
            ANTICYCLONE     = Param::Work::Pattern::ANTICYCLONE,       ///< 外向き渦巻き生成(中心から外周への単一作業パス)
            SEMIANTICYCLONE = Param::Work::Pattern::SEMIANTICYCLONE,   ///< 外向き準渦巻きパターン(複数作業パスを中心から処理)
            INIT_DEFAULT = BIDIRECTION
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[6] {
            VALUE_NAME(UNIDIRECTION),
            VALUE_NAME(BIDIRECTION),
            VALUE_NAME(CYCLONE),
            VALUE_NAME(SEMICYCLONE),
            VALUE_NAME(ANTICYCLONE),
            VALUE_NAME(SEMIANTICYCLONE)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-workPattern";
        static constexpr auto usage =
                " -workPattern={BIDIRECTION | UNIDIRECTION | CYCLONE | SEMICYCLONE}\n"
                "    Working pattern of sweep in working area.\n"
                "    BIDIRECTION : Sweep by raster, each raster lines use bi-directionally.\n"
                "    UNIDIRECTION: Sweep by raster, all raster lines use same direction\n"
                "    CYCLONE     : Sweep by orbital along working area polygon edge order from edge to center.\n"
                "    SEMICYCLONE : Sweep by raster, progress from outside to inside like as CYCLONE.\n"
                "    ANTICYCLONE : Similar CYCLONE but order from center to edge. [only RESERVED]\n";
    };
    /// 作業パターン保持クラス
    using WorkPattern = value_name_t<WorkPattern_t>;

    /// 作業の周回方向
    class WorkRotation_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            CLOCKWISE       = Param::Work::Headland::Pattern::Rotation::CLOCKWISE,           ///< 時計回り
            ANTICLOCKWISE   = Param::Work::Headland::Pattern::Rotation::ANTICLOCKWISE,       ///< 反時計回り
            INIT_DEFAULT = ANTICLOCKWISE
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[2] {
            VALUE_NAME(CLOCKWISE),
            VALUE_NAME(ANTICLOCKWISE)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-rotation";
        static constexpr auto usage =
        " -rotation={CLOCKWISE | ANTICLOCKWISE}\n"
        "	Rotate direction for work pattern, will be effective for CYCLONE or ANTICYCLONE.\n";
    };
    /// 作業周回方向保持クラス
    using WorkRotation = value_name_t<WorkRotation_t>;
    
    /// 作業パス接続方式
    class ProgressType_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            NORMAL    = Param::Work::ProgressType::NORMAL,      ///< 通常(ブロック単位の処理なし)
            BLOCK     = Param::Work::ProgressType::BLOCK,       ///< ブロック単位で処理する
            INIT_DEFAULT = NORMAL
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[2] {
            VALUE_NAME(NORMAL),
            VALUE_NAME(BLOCK)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-progressType";
        static constexpr auto usage =
        " -progressType={NORMAL | BLOCK}\n"
        "    Progress pattern in working area in field.\n";
    };
    /// 作業パターン保持クラス
    using ProgressType = value_name_t<ProgressType_t>;

    /// 作業領域拡大(ドン突き)
    class WorkPathLegType_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            DEFAULT = Param::Work::WorkPath::Leg::Type::DEFAULT,    ///< デフォルト
            STRAIGHT = Param::Work::WorkPath::Leg::Type::STRAIGHT,  ///< 直線
            FOLD = Param::Work::WorkPath::Leg::Type::FOLD,          ///< ドン付きあり
            INIT_DEFAULT = DEFAULT
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[2] {
            VALUE_NAME(STRAIGHT),
            VALUE_NAME(FOLD),
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-workPath_LegType";
        static constexpr auto usage =
        " -workPath_LegType={STRAIGHT | FOLD}\n"
        "    STRAIGHT : straight leg. (default)\n"
        "    FOLD     : add overrun and back for expanding working segment length.\n";
    };
    
    /// 作業領域拡大設定保持クラス
    using WorkPath_legtype = value_name_t<WorkPathLegType_t>;
    
    /// 枕地作業順
    class HeadlandProcess_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            NOP         = Param::Work::Headland::Process::NOP,  ///< 処理なし
            PRE         = Param::Work::Headland::Process::PRE,  ///< 先に作業(草刈りなどで先に旋回スペースを作る)
            POST        = Param::Work::Headland::Process::POST, ///< 後に作業(ロータリーなどで枕地を後で仕上げる)
            INIT_DEFAULT = NOP
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[3] {
            VALUE_NAME(NOP),
            VALUE_NAME(PRE),
            VALUE_NAME(POST)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-headland_process";
        static constexpr auto usage =
        " -headland_process={NOP | PRE | POST}\n"
        "    Process of oder of headland area.\n"
        "    NOP     : no operation in headland.\n"
        "    PRE     : PRE WORK, work headland first for making up turn margin.\n"
        "    POST    : POST WORK, work headland after raster sweep.\n";
    };
    /// 枕地作業順保持クラス
    using Headland_process = value_name_t<HeadlandProcess_t>;
    
    /// 枕地作業パターン
    class HeadlandPattern_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            CYCLONE         = Param::Work::Pattern::CYCLONE,           ///< 内向き渦巻き生成(外周から中心への単一作業パス)
            ANTICYCLONE     = Param::Work::Pattern::ANTICYCLONE,       ///< 外向き渦巻き生成(中心から外周への単一作業パス)
            INIT_DEFAULT = ANTICYCLONE
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[2] {
            VALUE_NAME(CYCLONE),
            VALUE_NAME(ANTICYCLONE)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-headland_pattern";
        static constexpr auto usage =
        " -headland_pattern={CYCLONE | ANTICYCLONE}\n"
        "    Working pattern of headland area.\n"
        "    CYCLONE     : an orbital path from outside to inside.\n"
        "    ANTICYCLONE : an orbital path from inside to ourside.\n";
    };
    /// 作業パターン保持クラス
    using Headland_pattern = value_name_t<HeadlandPattern_t>;
    
    /// 枕地作業の周回方向
    class HeadlandRotation_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            CLOCKWISE       = Param::Work::Headland::Pattern::Rotation::CLOCKWISE,           ///< 時計回り
            ANTICLOCKWISE   = Param::Work::Headland::Pattern::Rotation::ANTICLOCKWISE,       ///< 反時計回り
            INIT_DEFAULT = ANTICLOCKWISE
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[2] {
            VALUE_NAME(CLOCKWISE),
            VALUE_NAME(ANTICLOCKWISE)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-headland_rotation";
        static constexpr auto usage =
        " -headland_rotation={CLOCKWISE | ANTICLOCKWISE}\n"
        "    Rotetre direction of the orbital path.\n";
    };
    /// 作業パターン保持クラス
    using Headland_rotation = value_name_t<HeadlandRotation_t>;
    
    /// 作業制約
    class HeadlandCornerTurn_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            ALTERNATIVE = Param::Work::Headland::CornerTurn::ALTERNATIVE,     ///< αターン以外の代替ターンを使用しても最後まで作業する。デフォルト。
            BREAK_IF_ALT = Param::Work::Headland::CornerTurn::BREAK_IF_ALT,   ///< αターンを代替する場合は正常終了。
            ABORT_IF_ALT = Param::Work::Headland::CornerTurn::ABORT_IF_ALT,   ///< αターンを代替する場合はエラー終了。
            INIT_DEFAULT = ALTERNATIVE
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[3] {
            VALUE_NAME(ALTERNATIVE),
            VALUE_NAME(BREAK_IF_ALT),
            VALUE_NAME(ABORT_IF_ALT)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-headland_restriction";
        static constexpr auto usage =
        " -headland_cornerturn={ALTERNATIVE | BREAK_IF_ALT | ABORT_IF_ALT}\n"
        "    ALTERNATIVE : permit alterante corner turn (fallback from alpha tuyrn.)).\n"
        "    BREAK_IF_ALT: break if alternate turn.\n"
        "    ABORT_IF_ALT: abort pathgeneration with error, when alternate corner turn path.\n";
    };
    /// 作業制約保持クラス
    using Headland_cornerTurn = value_name_t<HeadlandCornerTurn_t>;

    /// ABパス種別値
    class PathTypeAB_t {
    public:
        enum value_type : int {
            NO_SHIFT    = Param::Work::PathTypeAB::NO_SHIFT,     ///< 0:シフトなし
            TRACTOR_POS = Param::Work::PathTypeAB::TRACTOR_POS,   ///< 1:シフトあり/トラクターの現在地基準
            SHIFT_VALUE = Param::Work::PathTypeAB::SHIFT_VALUE,     ///< 2:シフトあり/シフト値設定
            INIT_DEFAULT = NO_SHIFT
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[3] {
            VALUE_NAME(NO_SHIFT),
            VALUE_NAME(TRACTOR_POS),
            VALUE_NAME(SHIFT_VALUE)
        };

        using table_t = decltype(vnTable);
        static constexpr auto signature = "-pathTypeAB";
        static constexpr auto usage =
                " -pathTypeAB={NO_SHIFT | TRACTOR_POS | SHIFT_VALUE} [NO_SHIFT]\n"
                "   AB path shift mode.\n"
                "   NO_SHIFT:      Nothing to shift.\n"
                "   TRACTOR_POS:   Set origin to tractor position and shift paths by value.\n"
                "   SHIFT_VALUEAB: Shift by value that specified by -shiftValueAB.\n";
    };
    /// ABパス種別保持クラス
    using PathTypeAB = value_name_t<PathTypeAB_t>;

    /// トラクター位置
    class TractorPos : public GeoPoint {
    public:
        static constexpr auto signature = "-TractorPos";
        static constexpr auto usage =   " -TractorPos=LAT,LON\n"
                "   The coordinates of tractor position in field for AB path shift.\n";
        
        TractorPos() = default;
        TractorPos(const TractorPos&) = default;
        TractorPos(const GeoPoint& p) :
            GeoPoint (p)
        {}
        TractorPos(std::string str);
        
        operator std::string() const;
        TractorPos& operator=(const std::string& str);
    };

    /// 作業領域拡大設定保持クラス
    using WorkPathLegType = value_name_t<WorkPathLegType_t>;

    /// CSVデータテストオプション
    class CsvCheckType_t {
    public:
        // オプション値
        // - INIT_DEFAULTを変数の初期値とする
        enum value_type : int {
            NONE,       ///< 処理なし
            GUIDANCE,   ///< ガイダンスデータチェック
            DISPLAY,    ///< ディスプレイデータチェック
            BOTH,       ///< 両方
            INIT_DEFAULT = BOTH
        };
        
        using NamedValue = NamedValue_t<value_type>;
        // PathPlanTest.cpp内にvnTableの実体化をすること
        constexpr static NamedValue::data_type vnTable[4] {
            VALUE_NAME(NONE),
            VALUE_NAME(GUIDANCE),
            VALUE_NAME(DISPLAY),
            VALUE_NAME(BOTH)
        };
        
        using table_t = decltype(vnTable);
        static constexpr auto signature = "-checkcsv";
        static constexpr auto usage =
        " -checkcsv={NONE | GUIDANCE | DISPLAY | BOTH} [BOTH]\n"
        "    Test CSV output data.\n"
        "    NONE     : not test.\n"
        "    GUIDANCE : test guidance csv data.\n"
        "    DISPLAY  : test display csv data.\n"
        "    BOTH     : test both csv data.(as default)\n";
    };

    /// CSVデータテストオプション保持クラス
    using CsvCheckType = value_name_t<CsvCheckType_t>;

}}} // namespace yanmar::PathPlan::Options

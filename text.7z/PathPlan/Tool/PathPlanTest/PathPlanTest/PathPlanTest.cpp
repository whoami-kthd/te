// Yanmar Confidential 20200918
//
//  PathPlanTest.cpp
//  PathPlanTest
//

#include "PathPlanTest.hpp"

#include <dirent.h>
#include <cstdio>
#include <string>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdexcept>
#include <sys/stat.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include "PathGeneratorError.hpp"
#include "Geometry/Geometry.hpp"
#include "Geometry/Coordinates.hpp"

#include "GuidanceDataChecker.hpp"

using namespace yanmar::PathPlan;

namespace {
    std::string to_string(const GeoPoint& point, const char* caption = "") {
        std::stringstream ss;
        ss << std::setprecision(15) << std::showpoint
        << caption << "(" << point.lat << ", " << point.lon << ")";
        return ss.str();
    }
} // anonymous namespace

namespace yanmar { namespace PathPlan {

/**
 * テストパラメータログ出力
 */
void PathPlanTest::printParameter(const InputData& inData, size_t numFields) const {
	const Tractor& tractor0 = _inData.tractors[0];
    const auto& work = _inData.work;

	std::cout << "\n[Testing Parameters]\n";
        if (_inputFilename.empty()) {
            std::cout << "InputPath   :\t" << _inputPath << "\n";
        } else {
            std::cout << "InputFile   :\t" << _inputFilename << "\n";
        }
    std::cout <<
		"OutputPath  :\t" << _outputPath << "\n"
        "OutputSuffix:\t" << _outputSuffix << "\n"
        "Result SVG type   :\t" << (std::string)_resultSvgType << "\n";
    if (_workPathDir.mode == Options::DirMode::ANGLE_INTERVAL) {
        std::cout << "Direction Interval:\t" << _workPathDir.angle << "\tdegree(s)\n";
    } else if (_workPathDir.mode == Options::DirMode::ANGLE) {
        std::cout << "Direction angle   :\t" << _workPathDir.angle << "\n";
    } else if (_workPathDir.mode == Options::DirMode::EDGE_AROUND) {
        std::cout << "Directions        :\tall filed edges.\n";
    } else if (_workPathDir.mode == Options::DirMode::EDGE) {
        std::cout << "Direction edge    :\t" << _workPathDir.edge << "\n";
    } else if (_workPathDir.mode == Options::DirMode::POINTS) {
        std::cout << "Direction points  :\t" << to_string(_workPathDir.points[0], "[0]:") << to_string(_workPathDir.points[1], ", [1]:") << "\n";
    }
    std::cout <<
		"\nTractor metrics\n"
		"TW :\t" << tractor0.width	<< "\tTractor width. (mm)\n"
		"TR :\t" << tractor0.turnRadius	<< "\tTurn radius. (mm)\n"
		"\nTractor metrics from GNSS position\n"
		"TLF:\t" << tractor0.gnss.lengthToFrontEnd << "\tLength to front end of tractor(includes front weight). (mm)\n"
		"TLR:\t" << tractor0.gnss.lengthToRearEnd << "\tLength to rear end of tractor(as lower link). (mm)\n"
		"\nImplement metrics\n"
		"IL :\t" << tractor0.implement.length	<< "\tImplement length. (mm)\n"
		"ILW:\t" << tractor0.implement.cultivationPos << "\tImplement length to working position. (mm)\n"
		"IW :\t" << tractor0.implement.width	<< "\tImplement width of extent. (mm)\n"
		"IWW:\t" << tractor0.implement.cultivationWidth	<< "\tImplement width of working. (mm)\n"
        "IO:\t" << tractor0.implement.widthOffset               << "\tImplement offset. (mm)\n"
        "IOW:\t" << tractor0.implement.cultivationWidthOffset   << "\tImplement working width offset. (mm)\n"
        "canBackward:\t" << tractor0.implement.canBackward   << "\tImplement backward avalability.\n";
    if (2 <= inData.tractors.size()) {
        const Tractor& tractor1 = _inData.tractors[0];
        std::cout << "\nTractor2 settings\n"
        "IWW       :\t" << tractor1.implement.cultivationWidth	<< "\tImplement width of working. (mm)\n"
        "Follow pos:\t" << tractor1.followPos << "\t2:CENTER, 5:PARALLEL\n"
        "Use IWW   :\t" << work.usePathInterval2forN << "\t0:NO, 1:YES; Use Tractor2 IWW to calc headland and side margin width.\n";
    } else {
        std::cout << "\nTractor2\tnot present\n"
        "IWW       :\t-\n" <<
        "Follow pos:\t-\n" <<
        "Use IWW   :\t-\n";
    }
    std::cout << "\nWork settings\n"
        "WorkPattern :\t" << work.workPattern << "\t1:BIDIRECTION, 2:UNIDIRECTION, 3:CYCLONE, 4:SEMICYCLONE\n"
        "CanBackward :\t" << work.canBackward << "\t0:inhibit, 1:permit\n"
        "OverlapWidth:\t" << work.overlapWidth << "\tOverlap width for IWW. (Interval if negative) (mm)\n"
        "HlSmType    :\t" << work.headlandSideMarginType << "\t0:MINIMUM, 1:FACTOR_EACH, 2:FACTOR_UNITY, 21:RICE_21, 22:RICE_22\n"
        "[WorkPath]\n"
        " leg type   :\t" << work.workPath.leg.type << "\t0:STRAIGHT, 1:FOLD(add back)\n"
        "[Headland]\n"
        " process    :\t"   << _headland_process << "\t= " << (string)_headland_process << EOL <<
        " pattern    :\t"   << _headland_pattern << "\t= " << (string)_headland_pattern << EOL <<
        " rotation   :\t"   << _headland_rotation << "\t= " << (string)_headland_rotation << EOL <<
        " restriction:\t"   << _headland_restriction << "\t= " << (string)_headland_restriction << EOL <<
        "[AB path]\n"
        " shift mode :\t" << work.pathTypeAB << "\t0:NO_SHIFT, 1:TRACTOR_POS, 2:SHIDT_VALUE\n"
        " shift value:\t" << work.shiftValueAB << "\t(mm)\n"
    << std::endl;

	std::cout << "[TEST PATTERN]\n"
		<<  "Num of fields       :\t" << numFields << "\n";
    int patterns = 1;
    switch (_workPathDir.mode) {
    case Options::DirMode::ANGLE_INTERVAL:
        patterns = (int)((_workPathDir.range.end - _workPathDir.range.start + _workPathDir.interval - 1)  / _workPathDir.interval);
        std::cout <<
            "Patterns for a field:\t" << patterns << "\n" <<
            "Total test cases    :\t" << numFields * patterns << "\n";
        break;
    case Options::DirMode::EDGE_AROUND:
        std::cout <<
            "Patterns for a field:\tNum of edges of each filed.\n";
        break;
    case Options::DirMode::ANGLE:
    case Options::DirMode::EDGE:
    case Options::DirMode::POINTS:
    default:
        std::cout <<
            "Patterns for a field:\t" << patterns << "\n" <<
            "Total test cases    :\t" << numFields << "\n";
        break;
    }

    if (_stposIndex == -2) {
        std::cout << "stpos     :\t" << to_string(_stpos) << "\n";
    } else if (_stposIndex == -1) {
        std::cout << "stpos     :\t" << "ROTATION\n";
    } else {
        std::cout << "stposIndex:\t" << _stposIndex << "\n";
    }

    if (_edposIndex == -1) {
        std::cout << "edposIndex:\t" << "ROTATION\n";
    } else if (_edposIndex == -2) {
        std::cout << "edpos     :\t" << to_string(_edpos) << "\n";
    } else if (_edposIndex == -3) {
        std::cout << "edpos     :\t" << "N/A\n";
    } else {
        std::cout << "edposIndex:\t" << _edposIndex << "\n";
    }

	std::cout << std::endl;
}

PathPlanTest::PathPlanTest() = default;
PathPlanTest::~PathPlanTest() = default;

/**
 * パラメータを設定します。
 * @param[in] inputPath 圃場ファイルの入力元
 * @param[in] outputPath パス生成結果の出力先
 * @param[in] dirInterval 作業方向の間隔
 */
void PathPlanTest::setParameter(const std::string& inputPath, const std::string& outputPath, const std::string& indexFilename, const std::string& areaFilename) {
	_inputPath = inputPath;
	_outputPath = outputPath;
    _indexFilename = indexFilename;
	_areaFilename = areaFilename;
}

/**
 * パスプランの自動テストを開始します。
 * @return 0:正常終了
 */
int PathPlanTest::start() {
	if (_inDataPath.length() > 0) return start2();

	// 圃場ファイルのパスリストを取得
	std::vector<std::string> filenames;
	if (getFilenames(filenames) < 0) return -1;
    
	printParameter(_inData, filenames.size());

	writeIndexHtml_begin();
	writeAreaCsv_begin();

	// 圃場ファイルのパスリストの数だけループ
	for (int i = 0; i < (int)filenames.size(); ++i) {
		const std::string &filename = filenames[i];
        const std::string pathfile = _inputPath + filename;
		std::vector<GeoPoint> field;
		std::vector<std::vector<GeoPoint>> obstacles;
		// 圃場ファイルの読み込み
		if (readField(pathfile, field, obstacles) < 0) {
			continue;
		}
		// パス生成条件の可変部分を表す文字列
		const std::string conditions = "";
		// パス生成条件
		InputData inData = _inData;
		inData.field.outline.assign(field.begin(), field.end());
		inData.field.obstacles.assign(obstacles.begin(), obstacles.end());
		inData.field.start = field[0];
		inData.field.end = field[0];
		inData.field.directionPoints[0] = field[0];
		inData.field.directionPoints[1] = field[1];
		inData.field.refPos = field[0];
		loopWorkDirection(pathfile, conditions, inData);
	}

	writeIndexHtml_end();
	writeAreaCsv_end();

	std::cout << "Info, error counts.\n";
	if (_errs.empty()) {
		std::cout << "[NO ERROR]\n";
	} else {
		for (const auto& error : _errs) {
			std::cout << " error code[" << error.first << "], count[" << error.second << "].\n";
		}
	}
	return 0;
}

/**
 * パスプランの自動テストを開始します。
 * ファイルからInputData(パス生成条件)を生成します。
 * @return 0:正常終了
 */
int PathPlanTest::start2() {
	// InputDataファイルのパスリストを取得
	std::vector<std::string> inDataFilenames;
	if (getInDataFilenames(inDataFilenames) < 0) return -1;

	writeIndexHtml_begin();
	writeAreaCsv_begin();

	// InputDataファイルのパスリストの数だけループ
	// TODO:圃場ファイルのループは未対応
	for (int i = 0; i < (int) inDataFilenames.size(); ++i) {
		const std::string &inDataFilename = inDataFilenames[i];
		const std::string pathInDataFile = _inDataPath + inDataFilename;
		// InputDataファイルの読み込み
		// "<!--"から空行までをパス生成条件(csv文字列)として抜き出す
		std::string csvString;
		std::ifstream inFile;
		inFile.open(pathInDataFile);
		if (inFile.fail()) {
			std::cout << "Warning, failed to open filename[" << inDataFilename << "].\n";
			continue;
		}
		try {
			// 空行またはコメント行フラグ
			bool flag = true;
			// 1行ごとに読み込み
			std::string line;
			while (std::getline(inFile, line)) {
				if (flag) {
					if (line == "<!--") flag = false;
				} else {
					if (line.length() == 0) break;
					csvString += line + "\n";
				}
			}
		} catch (const std::exception &err) {
			inFile.close();
			std::cout << "Warning, failed to read filename[" << inDataFilename << "].\n";
			continue;
		}
		inFile.close();
		// InputDataの生成
		_inData = InputData::fromCsvString(csvString);
		if (_inputPath.empty()) {
			// 圃場ファイルの入力元が設定されていない場合
			const std::string conditions = "";
			executePathPlan(inDataFilename, conditions, _inData);
		} else {
			// 圃場ファイルのパスリストを取得
			std::vector<std::string> fieldFilenames;
			if (getFilenames(fieldFilenames) < 0) return -1;
			// 圃場ファイルのパスリストの数だけループ
			for (int i = 0; i < (int) fieldFilenames.size(); ++i) {
				const std::string &fieldFilename = fieldFilenames[i];
				const std::string pathFieldFile = _inputPath + fieldFilename;
				std::vector<GeoPoint> field;
				std::vector<std::vector<GeoPoint>> obstacles;
				// 圃場ファイルの読み込み
				if (readField(pathFieldFile, field, obstacles) < 0) {
					continue;
				}
				// パス生成条件の可変部分を表す文字列
				const std::string conditions = "_" + inDataFilename.substr(0, inDataFilename.length() - 4);
				// パス生成条件
				InputData inData = _inData;
				inData.field.outline.assign(field.begin(), field.end());
				inData.field.obstacles.assign(obstacles.begin(), obstacles.end());
				inData.field.start = field[0];
				inData.field.end = field[0];
				inData.field.directionPoints[0] = field[0];
				inData.field.directionPoints[1] = field[1];
				inData.field.refPos = field[0];
				loopWorkDirection(pathFieldFile, conditions, inData);
			}
		}
	}

	writeIndexHtml_end();
	writeAreaCsv_end();

	return 0;
}

/**
 * InputDataファイルのパスリストを取得します。
 * @param[out] inDataFiles InputDataファイルのパスリストの格納先
 * @return 0:正常終了
 */
int PathPlanTest::getInDataFilenames(std::vector<std::string> &inDataFilenames) {
	const char *inDataDir = _inDataPath.c_str();
	DIR *dp;
	dirent *entry;
	dp = opendir(inDataDir);
	if (dp == NULL) {
		std::cout << "Error, failed to open dir[" << inDataDir << "].\n";
		return -1;
	}
	while ((entry = readdir(dp)) != NULL) {
		std::ostringstream oss;
		oss << entry->d_name;
		const std::string filename = oss.str();
		// InputDataのファイル名は"*.svg"
		// TODO:ファイル名と拡張子のルールについては要検討
		if (filename.length() < 5 || filename.substr(filename.length() - 4, 4) != ".svg") {
			// 上記以外のパスはスキップ
			std::cout << "Info, skipped filename[" << filename << "].\n";
			continue;
		}
		inDataFilenames.push_back(filename);
	}
	if (inDataFilenames.size() == 0) {
		std::cout << "Error, NO data.\n";
		return -1;
	}
	std::sort(inDataFilenames.begin(), inDataFilenames.end());
	return 0;
}

/**
 * 圃場ファイルのパスリストを取得します。
 * @param[out] filenames 圃場ファイルのパスリストの格納先
 * @return 0:正常終了
 */
int PathPlanTest::getFilenames(std::vector<std::string> &filenames) {
	filenames.clear();

    // ファイル指定のとき
    if (!_inputFilename.empty()) {
        filenames.push_back(_inputFilename);
        return 0;
    }
    
    // パス指定のとき
    const char *fieldDir = _inputPath.c_str();
	DIR *dp;
	dirent *entry;
	dp = opendir(fieldDir);
	if (dp == NULL) {
		std::cout << "Error, failed to open dir[" << fieldDir << "].\n";
		return -1;
	}
	while ((entry = readdir(dp)) != NULL) {
		std::ostringstream oss;
		oss << entry->d_name;
		const std::string filename = oss.str();
		// 圃場のファイル名は"Field_" + conditionField + ".txt"
		if (filename.length() < 10 || filename.substr(0, 6) != "Field_") {
			// 上記以外のパスはスキップ
			std::cout << "Info, skipped filename[" << filename << "].\n";
			continue;
		}
		filenames.push_back(filename);
	}
	if (filenames.size() == 0) {
		std::cout << "Error, NO data.\n";
		return -1;
	}
    // make sure files were sorted even if read from the FS that has unsort dir entry.
    std::sort(filenames.begin(), filenames.end());

    return 0;
}

/**
 * 圃場ファイルを読み込みます。
 * @param[in] filename ファイルパス
 * @param[out] field 圃場データの格納先
 * @return 0:正常終了
 */
int PathPlanTest::readField(const std::string &filename, std::vector<GeoPoint> &field, std::vector<std::vector<GeoPoint>> &obstacles) {
	field.clear();
	obstacles.clear();

	std::ifstream inFile;
	inFile.open(filename);
	if (inFile.fail()) {
		std::cout << "Warning, failed to open filename[" << filename << "].\n";
		return -1;
	}
	try {
		// 空行またはコメント行フラグ
		bool empty = true;
		// 処理番号(0:圃場, 1-:障害物)
		int n = -1;
		// 1行ごとに読み込み
		std::string line;
		std::vector<GeoPoint> obstacle;
		while (std::getline(inFile, line)) {
			if (line.length() == 0 || line.front() == '#') {
				// 空行またはコメント行
				if (empty) {
					// 空行またはコメント行が連続している(処理なし)
				} else {
					// データ行の切れ目
					empty = true;
					if (n > 0) {
						obstacles.push_back(obstacle);
						obstacle.clear();
					}
				}
				// スキップ
				continue;
			} else {
				// データ行
				if (empty) {
					// データ行の1行目
					empty = false;
					++n;
				} else {
					// データ行の2行目以降(処理なし)
				}
			}
			// データ行の読み込み処理
			std::stringstream ss(line);
			std::string buf;
			// カンマで区切る
			std::getline(ss, buf, ',');
			double lat = boost::lexical_cast<double>(buf);
			std::getline(ss, buf, ',');
			double lon = boost::lexical_cast<double>(buf);
			if (n == 0) {
				// 圃場
				field.push_back(GeoPoint(lat, lon));
			} else {
				// 障害物
				obstacle.push_back(GeoPoint(lat, lon));
			}
		}
		if (n > 0 && empty == false) {
			obstacles.push_back(obstacle);
		}
	} catch (const std::exception &err) {
		inFile.close();
		std::cout << "Warning, failed to read filename[" << filename << "].\n";
		return -1;
	}
	inFile.close();
	return 0;
}

/**
 * 作業方向ループ実行
 * 
 * 作業方向のループさせてパスプランを実行します。
 *
 * @param[in] inFilename 圃場ファイルのパス
 * @param[in] conditions パス生成条件の可変部分を表す文字列
 * @param[in] inData パス生成条件
 * @return 0:正常終了
 */
int PathPlanTest::loopWorkDirection(const std::string &inFilename, const std::string &conditions, const InputData &inData) {
    if (_workPathDir.mode == Options::DirMode::EDGE) {
        // ほ場の指定辺の角度に合わせる
        const int edgeIndex = _workPathDir.edge;
        InputData tmpInData = InputData(inData);
        auto& field = tmpInData.field;
        const int size = (int)field.outline.size();

		// 暫定対応
		if (edgeIndex == 99) {
			// 最長辺を作業方向に設定する
			// TODO:ただし、座標系が不明/緯度経度のまま計算してるかも
			double dm = 0;
			GeoPoint p0 = field.outline[size - 1];
			for (int i = 0; i < size; ++i) {
				GeoPoint p1 = field.outline[i];
				double dx = p1.x - p0.x;
				double dy = p1.y - p0.y;
				double d = std::sqrt(dx * dx + dy * dy);
				if (d > dm) {
					dm = d;
					_workPathDir.points[0] = p0;
					_workPathDir.points[1] = p1;
					field.directionPoints = _workPathDir.points;
				}
				p0 = p1;
			}
		} else if (edgeIndex == 98) {
			// 2番目に長い辺を作業方向に設定する
			// TODO:ただし、座標系が不明/緯度経度のまま計算してるかも
			double dm1 = 0;
			double dm2 = 0;
			GeoPoint dm1_p0;
			GeoPoint dm1_p1;
			GeoPoint dm2_p0;
			GeoPoint dm2_p1;
			GeoPoint p0 = field.outline[size - 1];
			for (int i = 0; i < size; ++i) {
				GeoPoint p1 = field.outline[i];
				double dx = p1.x - p0.x;
				double dy = p1.y - p0.y;
				double d = std::sqrt(dx * dx + dy * dy);
				if (d > dm1) {
					dm2 = dm1;
					dm1 = d;
					dm2_p0 = dm1_p0;
					dm2_p1 = dm1_p1;
					dm1_p0 = p0;
					dm1_p1 = p1;
				} else if (d > dm2) {
					dm2 = d;
					dm2_p0 = p0;
					dm2_p1 = p1;
				}
				p0 = p1;
			}
			_workPathDir.points[0] = dm2_p0;
			_workPathDir.points[1] = dm2_p1;
			field.directionPoints = _workPathDir.points;
		} else {
			_workPathDir.points[0] = field.outline[_workPathDir.edge % size];
			_workPathDir.points[1] = field.outline[(_workPathDir.edge + 1) % size];
			field.directionPoints = _workPathDir.points;
		}

        // パス生成条件の可変部分を表す文字列に辺のインデックスを追加
        std::ostringstream oss;
        oss << conditions << "_p" << std::setw(2) << std::setfill('0') << edgeIndex;
        runStEdPosRotation(inFilename, oss.str(), tmpInData);
    } else if (_workPathDir.mode == Options::DirMode::EDGE_AROUND) {
        // ほ場の各辺に合わせて回転
        InputData tmpInData = InputData(inData);
        auto& field = inData.field;
        for (auto stIt = field.outline.cbegin(); stIt != field.outline.cend(); ++stIt) {
            // パス生成条件の作業方向を書き換える
            auto edIt = next(stIt);
            if (edIt == field.outline.cend()) {
                edIt = field.outline.cbegin();
            }
            tmpInData.field.directionPoints[0] = *stIt;
            tmpInData.field.directionPoints[1] = *edIt;
            
            // パス生成条件の可変部分を表す文字列に辺のインデックスを追加
            std::ostringstream oss;
            const auto edgeIndex = distance(field.outline.cbegin(), stIt);
            oss << conditions << "_p" << std::setw(2) << std::setfill('0') << edgeIndex;
            runStEdPosRotation(inFilename, oss.str(), tmpInData);
        }
    } else if (_workPathDir.mode == Options::DirMode::ANGLE_INTERVAL) {
        // 指定間隔で回転
        const GeoPoint refPos{AngleUnit::toRadian(inData.field.directionPoints[0].lat), AngleUnit::toRadian(inData.field.directionPoints[0].lon)};
        Geodesic converter;
        converter.setRefPos(refPos);
        const int endDir = _workPathDir.range.end;
        const int interval = std::max(_workPathDir.interval, 1.0);
        for (int orient = _workPathDir.range.start; orient < endDir; orient += interval) {
            // パス生成条件の作業方向を書き換える
            const double workDirection = AngleUnit::toRadian(orient);
            GeoPoint directionPoint = GeoPoint(cos(workDirection), sin(workDirection));
            converter.convert(directionPoint);
            InputData tmpInData = InputData(inData);
            tmpInData.field.directionPoints[1] = directionPoint;
            
            // パス生成条件の可変部分を表す文字列に作業方向の角度を追加
            std::ostringstream oss;
            oss << conditions << "_" << std::setw(3) << std::setfill('0') << orient;
            runStEdPosRotation(inFilename, oss.str(), tmpInData);
        }
    } else if (_workPathDir.mode == Options::DirMode::ANGLE) {
        // 角度指定
        // パス生成条件の作業方向を書き換える
        const GeoPoint refPos{AngleUnit::toRadian(inData.field.directionPoints[0].lat), AngleUnit::toRadian(inData.field.directionPoints[0].lon)};
        Geodesic converter;
        converter.setRefPos(refPos);
        const double workDirection = AngleUnit::toRadian(_workPathDir.angle);
        GeoPoint directionPoint = GeoPoint(cos(workDirection), sin(workDirection));
        converter.convert(directionPoint);
        InputData tmpInData = InputData(inData);
        tmpInData.field.directionPoints[1] = directionPoint;
        
        // パス生成条件の可変部分を表す文字列に作業方向の角度を追加
        std::ostringstream oss;
        oss << conditions << "_" << std::setw(3) << std::setfill('0') << (int)_workPathDir.angle;
        runStEdPosRotation(inFilename, oss.str(), tmpInData);
    } else if (_workPathDir.mode == Options::DirMode::POINTS) {
        // 2点指定
        // パス生成条件の作業方向を書き換える
        InputData tmpInData = InputData(inData);
        tmpInData.field.directionPoints = _workPathDir.points;
        
        // パス生成条件の可変部分を表す文字列に作業方向の角度を追加
        std::ostringstream oss;
        oss << conditions << "_points";
        runStEdPosRotation(inFilename, oss.str(), tmpInData);
    } else {
        assert(false);
    }
    
	return 0;
}

/**
 * 開始・終了点の巡回ディスパッチ
 *
 * 開始・終了点のパスプラン巡回実行をディスパッチします。
 *
 * @param[in] inFilename 圃場ファイルのパス
 * @param[in] conditions パス生成条件の可変部分を表す文字列
 * @param[in] inData パス生成条件
 * @return 0:正常終了
 */
int PathPlanTest::runStEdPosRotation(const std::string &inFilename, const std::string &conditions, InputData &inData) {
    int result = 0;
    const int size = (int)inData.field.outline.size();

    // 開始位置設定
    if (0 <= _stposIndex) {
        inData.field.start = inData.field.outline[_stposIndex % size];
    } else if (_stposIndex == -2) {
        inData.field.start = _stpos;
    }

    // 終了位置設定
    if (0 <= _edposIndex) {
        inData.field.end = inData.field.outline[std::max(0, _edposIndex) % size];
    } else if (_edposIndex == -2) {
        inData.field.end = _edpos;
        inData.field.endPointAvailable = true;
    } else if (_edposIndex == -3) {
        inData.field.endPointAvailable = false;
    }

    // ディスパッチ
    if (_stposIndex == -1) {
        // 開始位置巡回
        result = execute_stposRotation(inFilename, conditions, inData);
    } else if (_edposIndex == -1) {
        // 終了位置巡回
        result = execute_edposRotation(inFilename, conditions, inData);
    } else {
        // 巡回なし
        result = executePathPlan(inFilename, conditions, inData);
    }
    
    return 0;
}

/**
 * 開始点巡回実行
 *
 * パスプランを開始点を巡回しながら実行します。
 *
 * @param[in] inFilename 圃場ファイルのパス
 * @param[in] conditions パス生成条件の可変部分を表す文字列
 * @param[in] inData パス生成条件
 * @return 0:正常終了
 */
int PathPlanTest::execute_stposRotation(const std::string &inFilename, const std::string &conditions, InputData inData) {
    if (_stposIndex == -1) {
        for (int stIndex = 0; stIndex < (int)inData.field.outline.size(); stIndex++) {
            inData.field.start = inData.field.outline[stIndex];	// 開始点指定
            // パスプランの実行
            std::ostringstream ss;
            ss << "_st" << std::setw(2) << std::setfill('0') << stIndex;
            const std::string tmpConditions = conditions + ss.str();
            execute_edposRotation(inFilename, tmpConditions, inData);
        }
    } else {
        executePathPlan(inFilename, conditions, inData);
    }
    
    return 0;
}

/**
 * 終了点巡回実行
 *
 * パスプランを終了点巡回しながら実行します。
 *
 * @param[in] inFilename 圃場ファイルのパス
 * @param[in] conditions パス生成条件の可変部分を表す文字列
 * @param[in] inData パス生成条件
 * @return 0:正常終了
 */
int PathPlanTest::execute_edposRotation(const std::string &inFilename, const std::string &conditions, InputData inData) {
    if (_edposIndex == -1) {
        for (int edIndex = 0; edIndex < (int)inData.field.outline.size(); edIndex++) {
            inData.field.end = inData.field.outline[edIndex];	// 終了点指定
            // パスプランの実行
            std::stringstream ss;
            ss << "_ep" << std::setw(2) << std::setfill('0') << edIndex;
            const std::string tmpConditions = conditions + ss.str();
            executePathPlan(inFilename, tmpConditions, inData);
        }
    } else {
        executePathPlan(inFilename, conditions, inData);
    }
    return 0;
}

/**
 ディレクトリ作成
 
 @param[in] dir 生成するディレクトリパス
 
 @return 処理後の指定ディレクトリの状態
 @retval true   存在する
 @retval false  不明
 */
bool makeSureDir(const std::string& dir) {
    int result = mkdir(dir.c_str(), 0777);
    return (result == 0 || result == EEXIST);
}
    
int movefile(const std::string &src, const std::string &dst) {
    const int result = rename(src.c_str(), dst.c_str());
    if (result != 0) {
        std::cout << "Warning, failed to move from filename[" << src << "]\n";
        std::cout << "                          to filename[" << dst << "].\n";
    }
    return result;
}

int copyfile(const std::string &src, const std::string &dst) {
    std::ifstream inFile;
    inFile.open(src);
    if (inFile.fail()) {
        std::cout << "Warning, failed to copy from filename[" << src << "]\n";
        std::cout << "                          to filename[" << dst << "].\n";
        std::cout << "         failed to open src file.\n";
        return -1;
    }
    std::ofstream outFile;
    outFile.open(dst);
    if (outFile.fail()) {
        std::cout << "Warning, failed to copy from filename[" << src << "]\n";
        std::cout << "                          to filename[" << dst << "].\n";
        std::cout << "         failed to open dst file.\n";
        return -1;
    }
    outFile << inFile.rdbuf() << std::flush;
    outFile.close();
    inFile.close();
    return 0;
}

// パス生成結果出力
void saveResultSvg(const std::string& resultFilename, const std::string& outFilename, const std::string& _additionalInfo) {
    
    // 結果ファイル取得
    const int resultFileMoved = movefile(resultFilename, outFilename);
    if (resultFileMoved == 0) {
        std::fstream outFile;
        outFile.open(outFilename, std::ios_base::app);
        if (outFile) {
            outFile << "<!--\n"
            << _additionalInfo
            << "\n-->\n";
            outFile.close();
        }
    }
}

namespace {
   
    /**
     出力ファイル名管理クラス
     */
    struct OutFilename {
        std::string fieldFilename;
        std::string base = "PathData";
        std::string fieldName;
        std::string conditions;
        std::string suffix;
        std::string error;
        std::string ext = ".svg";
        
    private:
        std::string internal;   ///< 内部用ファイル名
        std::string external;   ///< 外部用ファイル名
        std::string display;   ///< ディプレイデータファイル名
        std::string guidance;   ///< ガイダンスデータファイル名

    public:
        /**
         圃場ファイル名を指定して初期化する。
         パスが付いていても良い。
         */
        OutFilename (const std::string& inFilename) {
            // 圃場ファイル名の取り出し
            {
                auto posStart = inFilename.find_last_of("/\\");
                if (posStart == std::string::npos) {
                    posStart = 0;
                } else {
                    posStart += 1;
                }
                
                fieldFilename = inFilename.substr(posStart);
            }
            
            // 圃場名取り出し
            {
                auto posStart = fieldFilename.find_first_of("_");
                if (posStart == std::string::npos) {
                    posStart = 0;
                    fieldName = "_";
                }
                
                auto posEnd = fieldFilename.find_last_of(".");
                auto size = std::string::npos;
                if (posEnd != std::string::npos) {
                    size = posEnd - posStart;
                }
                fieldName = fieldFilename.substr(posStart, size);
            }
        }
        
        // 使用済みファイル名のうち優先度の高い方を返す
        const std::string& get() {
            assert(!internal.empty() || !external.empty());
            // 両方使用した場合internal優先
            return (!external.empty()) ? external : internal;
        }
        
        // 内部形式用パスファイル名取得
        const std::string& getInternal(const std::string& path) {
            if (internal.empty()) {
                internal = path + base + fieldName + conditions + suffix + error + "_i.svg";
            }
            return internal;
        }
        
        // 外部形式用パスファイル名取得
        const std::string& getExternal(const std::string& path) {
            if (external.empty()) {
                external = path + base + fieldName + conditions + suffix + error + ".svg";
            }
            return external;
        }

        const std::string& getDisplay(const std::string& path) {
            if (display.empty()) {
                display = path + "DisplayData" + fieldName + conditions + suffix + error + ".csv";
            }
            return display;
        }
        
        const std::string& getGuidance(const std::string& path) {
            if (guidance.empty()) {
                guidance = path + "GuidanceData" + fieldName + conditions + suffix + error + ".csv";
            }
            return guidance;
        }
    };
}

    
/**
 * パスプラン実行
 *
 * 指定生成条件でパスプラン実行し、結果ファイルを保存します。
 *
 * @param[in] inFilename 圃場ファイルのパス
 * @param[in] conditions パス生成条件の可変部分を表す文字列
 * @param[in] inData パス生成条件
 * @return 0:正常終了
 */
int PathPlanTest::executePathPlan(const std::string &inFilename, const std::string &conditions, const InputData &inData) {
	int result = 0;
    
    struct ResultFiles {
        std::string internal = "PathData_internal.svg";
        std::string external = "PathData.svg";
        std::string display = "DisplayData.csv";
        std::string guidance = "GuidanceData.csv";
    } resultFiles;
   
    OutFilename outFilename(inFilename);
    outFilename.conditions = conditions;
    outFilename.suffix = _outputSuffix;
    
    // 前回のファイルを削除します
	remove(resultFiles.external.c_str());
	remove(resultFiles.internal.c_str());
    remove(resultFiles.display.c_str());
    remove(resultFiles.guidance.c_str());

	PathPlanning pp;
	// パス生成条件の設定
	pp.setInputData(inData);
	// 圃場面積
	double fieldArea = 0.0;
	// 実作業面積
	double effectiveArea = 0.0;
    // エラーコード
    std::string errCode;
    std::string errDesc;
    std::string guidanceData;
	try {
        switch ((Options::GeneratePathType::value_type)_generatePathType) {
        case Options::GeneratePathType::STANDARD:
            {
            // パスプランの実行
            pp.createPathData();
            // 圃場面積の取得
            fieldArea = pp.getFieldArea();
            // 実作業面積の取得
            effectiveArea = pp.getEffectiveArea();
            // ガイダンスデータのチェック
            guidanceData = pp.getGuidanceData();
            checkGuidanceData(guidanceData);
            }
            break;
        case Options::GeneratePathType::AB:
            pp.createPathDataAB();
            break;
        case Options::GeneratePathType::FITTING:
            break;
        default:
            assert(false);
        }
    } catch (const yanmar::PathPlan::Error& err) {
        errCode = err.what();
        errDesc = err.description;
        result = -1;
	} catch (const std::exception& err) {
        errCode = err.what();
        result = -1;
    }

	// エラーの場合
    if (result != 0) {
		std::cout << "Warning, createPathData failed.\n";
		std::cout << " filename  [" << (_inputPath + outFilename.fieldFilename) << "].\n";
		std::cout << " conditions[" << conditions << "].\n";
		std::cout << " error code[" << errCode << "].\n";
        std::cout << " error desc[" << errDesc << "].\n";

		const std::string errFieldDir = _outputPath + "ErrField_" + errCode + "/";
		auto itr = _errs.find(errCode);
		if (itr != _errs.end()) {
			++(itr->second);
			struct stat st;
			if (stat(errFieldDir.c_str(), &st) == 0 && (st.st_mode & S_IFMT) == S_IFDIR) {
				copyfile(inFilename, errFieldDir + outFilename.fieldFilename);
			}
		} else {
			_errs[errCode] = 1;
			if (makeSureDir(errFieldDir)) {
				copyfile(inFilename, errFieldDir + outFilename.fieldFilename);
			}
		}
		// エラーの場合、出力先ファイル名にエラーコードを追加
		outFilename.error = std::string("_") + errCode;
    }

    // 結果ファイル名
    std::string infoStr = _additionalInfo + "\n" + errCode + "\n" + errDesc;
    if (_resultSvgType == Options::ResultType::EXTERNAL) {
        // 出力先のファイルパス
        // パス生成結果出力
        if (result != 0) {
            saveResultSvg(resultFiles.internal, outFilename.getExternal(_outputPath), infoStr);
        } else {
            saveResultSvg(resultFiles.external, outFilename.getExternal(_outputPath), infoStr);
        }
    } else if (_resultSvgType == Options::ResultType::INTERNAL) {
        // 出力先のファイルパス
        saveResultSvg(resultFiles.internal, outFilename.getInternal(_outputPath), infoStr);
    } else if (_resultSvgType == Options::ResultType::BOTH) {
        // 出力先のファイルパス
        // パス生成結果出力
        saveResultSvg(resultFiles.internal, outFilename.getInternal(_outputPath), infoStr);
        saveResultSvg(resultFiles.external, outFilename.getExternal(_outputPath), infoStr);
    }
    
    movefile(resultFiles.display, outFilename.getDisplay(_outputPath));
    movefile(resultFiles.guidance, outFilename.getGuidance(_outputPath));
    
	if (result == 0) {
		writeIndexHtml_loop(outFilename.get());
		writeAreaCsv_loop(outFilename.get(), fieldArea, effectiveArea, true);
		std::cout << "Info, success filename[" << outFilename.get() << "].\n";
    } else {
		writeAreaCsv_loop(outFilename.get(), fieldArea, effectiveArea, false);
    }

	return result;
}

/**
 * ガイダンスデータCSVをチェックします
 */
int PathPlanTest::checkGuidanceData(const std::string &guidanceData) {
    if (_checkCsvOutput == Options::CsvCheckType_t::GUIDANCE ||
        _checkCsvOutput == Options::CsvCheckType_t::BOTH) {
        Csv::CsvData csvData{};
        csvData.parse(guidanceData);

        GuidanceDataChecker gc;
        auto errors = gc.check(csvData);
        
        if (!errors.empty()) {
            PathPlan::Error err{"E-PP-802"};
            err.setDescription(errors.front());
            throw err;
        }
    }

    if (_checkCsvOutput == Options::CsvCheckType_t::DISPLAY ||
        _checkCsvOutput == Options::CsvCheckType_t::BOTH) {
        // TODO: ディスプレイデータチェック
    }

    return 0;
}

/**
 * テスト結果のindex.htmlを出力します。
 */
int PathPlanTest::writeIndexHtml_begin() {
	_osIndexFile.open(_indexFilename, std::ios::trunc);
	if (_osIndexFile.fail()) {
		std::cout << "Warning, failed to open filename[" << _indexFilename << "].\n";
		return -1;
	}
	_osIndexFile << R"(<!doctype html>)" << EOL;
	_osIndexFile << R"(<html>)" << EOL;
	_osIndexFile << R"(<head>)" << EOL;
	_osIndexFile << R"(<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />)" << EOL;
	_osIndexFile << R"(<title>パスプラン 自動テスト 結果表示</title>)" << EOL;
	_osIndexFile << R"(<style type="text/css">)" << EOL;
	_osIndexFile << R"(#menu {)" << EOL;
	_osIndexFile << R"(    position: fixed;)" << EOL;
	_osIndexFile << R"(    z-index: 1;)" << EOL;
	_osIndexFile << R"(    top: 0px;)" << EOL;
	_osIndexFile << R"(    left: 0px;)" << EOL;
	_osIndexFile << R"(    width: 100%;)" << EOL;
	_osIndexFile << R"(    height: 100%;)" << EOL;
	_osIndexFile << R"(})" << EOL;
	_osIndexFile << R"(#view {)" << EOL;
	_osIndexFile << R"(    position: absolute;)" << EOL;
	_osIndexFile << R"(    z-index: 0;)" << EOL;
	_osIndexFile << R"(    top: 0px;)" << EOL;
	_osIndexFile << R"(    left: 0px;)" << EOL;
	_osIndexFile << R"(    width: 100%;)" << EOL;
	_osIndexFile << R"(    height: 100%;)" << EOL;
	_osIndexFile << R"(})" << EOL;
	_osIndexFile << R"(</style>)" << EOL;
	_osIndexFile << R"(<script type="text/javascript">)" << EOL;
	_osIndexFile << R"(var results = [)" << EOL;
	_index1stLine = true;
	return 0;
}
int PathPlanTest::writeIndexHtml_loop(const std::string &outFilename) {
	if (_osIndexFile.fail()) {
		return -1;
	}
	if (_index1stLine) {
		_index1stLine = false;
	} else {
		_osIndexFile << ",";
	}
	_osIndexFile << "'" << outFilename << "'";
	_osIndexFile << std::endl;
	return 0;
}
int PathPlanTest::writeIndexHtml_end() {
	if (_osIndexFile.fail()) {
		return -1;
	}
	_osIndexFile << R"(];)" << EOL;
	_osIndexFile << R"(var index;)" << EOL;
	_osIndexFile << R"(var scale;)" << EOL;
	_osIndexFile << R"(function init() {)" << EOL;
	_osIndexFile << R"(    index = 0;)" << EOL;
	_osIndexFile << R"(    scale = 1.0;)" << EOL;
	_osIndexFile << R"(    var obj = document.getElementById("view");)" << EOL;
	_osIndexFile << R"(    obj.data = results[index];)" << EOL;
	_osIndexFile << R"(    var clone = obj.cloneNode(true);)" << EOL;
	_osIndexFile << R"(    obj.parentNode.replaceChild(clone, obj);)" << EOL;
    _osIndexFile << R"(    document.getElementById("filename").textContent=results[index];)" << EOL;
	_osIndexFile << R"(})" << EOL;
	_osIndexFile << R"(function onClickPrev() {)" << EOL;
	_osIndexFile << R"(    --index;)" << EOL;
	_osIndexFile << R"(    if (index < 0) {)" << EOL;
	_osIndexFile << R"(        index = results.length - 1;)" << EOL;
	_osIndexFile << R"(    })" << EOL;
	_osIndexFile << R"(    var obj = document.getElementById("view");)" << EOL;
	_osIndexFile << R"(    obj.data = results[index];)" << EOL;
	_osIndexFile << R"(    var clone = obj.cloneNode(true);)" << EOL;
	_osIndexFile << R"(    obj.parentNode.replaceChild(clone, obj);)" << EOL;
    _osIndexFile << R"(    document.getElementById("filename").textContent=results[index];)" << EOL;
	_osIndexFile << R"(})" << EOL;
	_osIndexFile << R"(function onClickNext() {)" << EOL;
	_osIndexFile << R"(    ++index;)" << EOL;
	_osIndexFile << R"(    if (index >= results.length) {)" << EOL;
	_osIndexFile << R"(        index = 0;)" << EOL;
	_osIndexFile << R"(    })" << EOL;
	_osIndexFile << R"(    var obj = document.getElementById("view");)" << EOL;
	_osIndexFile << R"(    obj.data = results[index];)" << EOL;
	_osIndexFile << R"(    var clone = obj.cloneNode(true);)" << EOL;
	_osIndexFile << R"(    obj.parentNode.replaceChild(clone, obj);)" << EOL;
    _osIndexFile << R"(    document.getElementById("filename").textContent=results[index];)" << EOL;
	_osIndexFile << R"(})" << EOL;
	_osIndexFile << R"(function onClickScaleD() {)" << EOL;
	_osIndexFile << R"(    scale -= 0.1;)" << EOL;
	_osIndexFile << R"(    if (scale < 0.1) {)" << EOL;
	_osIndexFile << R"(        scale = 0.1;)" << EOL;
	_osIndexFile << R"(    })" << EOL;
	_osIndexFile << R"(    document.getElementById("view").style = "-webkit-transform:scale(" + scale + ");-moz-transform:scale(" + scale + ");-ms-transform:scale(" + scale + ");-o-transform:scale(" + scale + ");transform:scale(" + scale + ");-webkit-transform-origin:0 0;-moz-transform-origin:0 0;-ms-transform-origin:0 0;-o-transform-origin:0 0;transform-origin:0 0;";)" << EOL;
	_osIndexFile << R"(})" << EOL;
	_osIndexFile << R"(function onClickScaleR() {)" << EOL;
	_osIndexFile << R"(    scale = 1.0;)" << EOL;
	_osIndexFile << R"(    document.getElementById("view").style = "-webkit-transform:scale(" + scale + ");-moz-transform:scale(" + scale + ");-ms-transform:scale(" + scale + ");-o-transform:scale(" + scale + ");transform:scale(" + scale + ");-webkit-transform-origin:0 0;-moz-transform-origin:0 0;-ms-transform-origin:0 0;-o-transform-origin:0 0;transform-origin:0 0;";)" << EOL;
	_osIndexFile << R"(})" << EOL;
	_osIndexFile << R"(function onClickScaleU() {)" << EOL;
	_osIndexFile << R"(    scale += 0.1;)" << EOL;
	_osIndexFile << R"(    document.getElementById("view").style = "-webkit-transform:scale(" + scale + ");-moz-transform:scale(" + scale + ");-ms-transform:scale(" + scale + ");-o-transform:scale(" + scale + ");transform:scale(" + scale + ");-webkit-transform-origin:0 0;-moz-transform-origin:0 0;-ms-transform-origin:0 0;-o-transform-origin:0 0;transform-origin:0 0;";)" << EOL;
	_osIndexFile << R"(})" << EOL;
	_osIndexFile << R"(</script>)" << EOL;
	_osIndexFile << R"(</head>)" << EOL;
	_osIndexFile << R"(<body onload="init();">)" << EOL;
	_osIndexFile << R"(    <div id="menu">)" << EOL;
    _osIndexFile << R"(        <div style="text-align:left;"><button type="button" accesskey="p" onclick="onClickPrev();">prev</button><button type="button" accesskey="n" onclick="onClickNext();">next</button> <span id="filename" style="font-size:8pt"></span></div>)" << EOL;
	_osIndexFile << R"(        <div style="text-align:left;"><button type="button" accesskey="-" onclick="onClickScaleD();">－</button><button type="button" accesskey="." onclick="onClickScaleR();">・</button><button type="button" accesskey="+" onclick="onClickScaleU();">＋</button></div>)" << EOL;
	_osIndexFile << R"(    </div>)" << EOL;
	_osIndexFile << R"(    <object id="view"></object>)" << EOL;
	_osIndexFile << R"(</body>)" << EOL;
	_osIndexFile << R"(</html>)" << EOL;
	_osIndexFile << std::flush;
	_osIndexFile.close();
	return 0;
}

int PathPlanTest::writeAreaCsv_begin() {
	_osAreaFile.open(_areaFilename, std::ios::trunc);
	if (_osAreaFile.fail()) {
		std::cout << "Warning, failed to open filename[" << _areaFilename << "].\n";
		return -1;
	}
	return 0;
}
int PathPlanTest::writeAreaCsv_loop(const std::string &outFilename, double fieldArea, double effectiveArea, bool success) {
	if (_osAreaFile.fail()) {
		return -1;
	}
	if (success) {
		_osAreaFile << outFilename << "," << fieldArea << "," << effectiveArea << std::endl;
	} else {
		_osAreaFile << outFilename << ",," << std::endl;
	}
	return 0;
}
int PathPlanTest::writeAreaCsv_end() {
	if (_osAreaFile.fail()) {
		return -1;
	}
	_osAreaFile << std::flush;
	_osAreaFile.close();
	return 0;
}

}} // yanmar::PathPlan

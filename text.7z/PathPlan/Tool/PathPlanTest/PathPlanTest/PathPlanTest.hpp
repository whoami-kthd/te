// Yanmar Confidential 20200918
//
//  PathPlanTest.hpp
//  PathPlanTest
//
#pragma once

#include "Option.hpp"

#include <map>
#include <array>
#include <fstream>
#include <stdexcept>

#include "PathPlanIF.hpp"

namespace yanmar { namespace PathPlan {

    class PathPlanTest
	{
	public:
		PathPlanTest();
		~PathPlanTest();
		void setParameter(const std::string& inputPath, const std::string& outputPath, const std::string& indexFilename, const std::string& areaFilename);
		void printParameter(const InputData& inData, size_t numFields) const;
		int start();
		// ファイルからInputData(パス生成条件)を生成する版
		int start2();

        // パラメータ変換用テンプレート
        template<typename T, typename U>
        static T getValue(U str);

	private:
		int getInDataFilenames(std::vector<std::string> &inDataFilenames);
		int getFilenames(std::vector<std::string> &filenames);
		int readField(const std::string &filename, std::vector<GeoPoint> &field, std::vector<std::vector<GeoPoint>> &obstacles);
		int loopWorkDirection(const std::string &inFilename, const std::string &conditions, const InputData &inData);
        int runStEdPosRotation(const std::string &inFilename, const std::string &conditions, InputData &inData);
		int executePathPlan(const std::string &inFilename, const std::string &conditions, const InputData &inData);
        int checkGuidanceData(const std::string &guidanceData);
		int writeIndexHtml_begin();
		int writeIndexHtml_loop(const std::string &outFilename);
		int writeIndexHtml_end();
		int writeAreaCsv_begin();
		int writeAreaCsv_loop(const std::string &outFilename, double fieldArea, double effectiveArea, bool success);
		int writeAreaCsv_end();
		int execute_stposRotation(const std::string &inFilename, const std::string &conditions, InputData inData);
		int execute_edposRotation(const std::string &inFilename, const std::string &conditions, InputData inData);
	
	public:
		int _stposIndex = 0;
		int _edposIndex = 0;
        GeoPoint _stpos;
        GeoPoint _edpos;
        std::string _inputFilename;
		InputData _inData;
        std::string _additionalInfo;
        
        //
        // オプション
        //

        // 作業方向モード
        Options::DirMode _workPathDir;
        // 結果ファイル形式
        Options::ResultType _resultSvgType;
        // 生成パス種別
        Options::GeneratePathType _generatePathType;
        // CSV出力チェック
        Options::CsvCheckType _checkCsvOutput;
        // 追走位置
        Options::FollowPos _followPos;
        // 作業機位置
        Options::ImplementPos _implementPos;
        // 枕地・サイドマージンタイプ
        Options::HsMarginType _headlandSideMarginType;
        // 作業パターン
        Options::WorkPattern _workPattern;
        // 作業周回方向
        Options::WorkRotation _workRotation;
        // 作業進捗パターン
        Options::ProgressType _progressType;
        // 作業領域拡大
        Options::WorkPath_legtype _WorkPath_legtype;
        // 枕地作業順
        Options::Headland_process _headland_process;
        // 枕地作業パターン
        Options::Headland_pattern _headland_pattern;
        // 枕地作業の周回方向
        Options::Headland_rotation _headland_rotation;
        // 作業制約
        Options::Headland_cornerTurn _headland_restriction;
        // ABパスタイプ
        Options::PathTypeAB _pathTypeAB;
        // トラクター位置
        Options::TractorPos _tractorPos;

    public:
		std::string _inDataPath;
		std::string _inputPath;
		std::string _outputPath = "./result/";
        std::string _outputSuffix;
        std::string _indexFilename = "./index.html";
		std::string _areaFilename = "./area.csv";
		std::map<std::string, int> _errs;
		std::ofstream _osIndexFile;
        std::ofstream _osAreaFile;
		bool _index1stLine = true;
	};

}} // namespace yanmar::PathPlan

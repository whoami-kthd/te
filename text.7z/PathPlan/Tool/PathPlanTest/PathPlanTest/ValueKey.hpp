// Yanmar Confidential 20200918
/**
 @file ValueKey.hpp
 
 Value - key handling class for command-line options.
 */
#pragma once

#include "string_view.hpp"

#include <array>
#include <algorithm>
#include <fstream>
#include <stdexcept>

#include "PathPlanIF.hpp"

// {値, "値"} 初期化リスト生成マクロ
#define VALUE_NAME(v) {v, #v}

namespace yanmar { namespace PathPlan { namespace Options {
    
    // オプション文字列のパース
    template<typename T, typename U>
    T parse(const U& in);
    
    /**
     name-value table element
     */
    template<typename Value_t>
    class NamedValue_t {
    public:
        using data_type = std::pair<Value_t, cstr_adaptor>;
        static_assert(std::is_literal_type<data_type>::value, "");
        //        using table_t = const data_type[];
        //            using table_t = std::vector<const data_type>;
    };
    
    /**
     名前付き値保持クラス
     
     value_type型の値valueを保持し、その名称stringとの相互変換を実現するクラス。
     - value_typeおよび名称stringとも相互変換可能。
     - staticに参照する値-名称テーブルvnTableを元にして変換を行う。
     - 変換関数自体も公開する。
     - テンプレートパラメータに与えるTは以下のものを備えること
        - 型value_type
        - 型NamedValue = NamedValue_t<value_type>
        - 値value_type INIT_DEFAULT
        - NamedValue::data_typeのstaticな配列 vnTable[]
     */
    template<typename T>
    class value_name_t : public T {
    public:
        using value_type = typename T::value_type;
        using NamedValue = typename T::NamedValue;
        using data_type = typename NamedValue::data_type;
        using table_t = typename T::table_t;
    
    public:
        /// 値
        value_type value = T::INIT_DEFAULT;

    public:
        // コンストラクタ
        value_name_t() = default;
        value_name_t(const value_name_t&) = default;
        /// value_typeからのコンストラクタ
        value_name_t(value_type v) :
            value(v)
        {}
        /// 名称からのコンストラクタ
        value_name_t(const std::string& str)
        {
            value = find(T::vnTable, str);
        }
        
        /**
         value対nameリストから指定の値の名前を得る
         */
        static std::string find(const table_t& va, value_type v) {
            array_view<data_type> table(va);
            const auto it = find_if(table.cbegin(), table.cend(),
                                    [&v](const data_type& vn) {
                                        return (v == vn.first);
                                    } );
            
            if (it == table.cend()) {
                throw std::out_of_range(std::to_string(v));
            }
            
            return it->second;
        }
        
        /**
         value対nameリストから指定名前の値を得る
         */
        static value_type find(const table_t& va, const std::string& str) {
            auto v = toUpper(str);
            array_view<data_type> table(va);
            const auto it = find_if(table.cbegin(), table.cend(),
                                    [&v](const data_type& vn) {
                                        return (v == vn.second);
                                    } );
            
            if (it == table.cend()) {
                throw std::out_of_range(str);
            }
            
            return it->first;
        }
        
        operator value_type() const { return static_cast<value_type>(value); }
        operator std::string() const { return find(T::vnTable, value); }
        value_type operator=(const std::string& str) { value = find(T::vnTable, str); return value; }
    };

}}} // namespace yanmar::PathPlan::Options

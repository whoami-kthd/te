// Yanmar Confidential 20200918
//
//  main.cpp
//  PathPlanTest
//

#include <cmath>
#include <iostream>
#include <iomanip>
#include <ratio>
#include <sys/stat.h>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include "PathPlanTest.hpp"
#include "Geometry/Geometry.hpp"
#include "Common.h"

using namespace yanmar::PathPlan;

namespace {
    const std::string inputPath_default = "./field/";
    const std::string outputPath_default = "./result/";
    const std::string indexFilename_default = "./index.html";
	const std::string areaFilename_default = "./area.csv";

    std::string inputPath; // 圃場ファイルの入力元
    std::string inputFile; // 単一圃場ファイル
	std::string outputPath; // パス生成結果の出力先
    std::string outputSuffix;       // パス生成結果ファイル名に追加するサフィックス
    std::string indexFilename;      // パス生成結果のブラウズ用htmlファイル名
	std::string areaFilename;       // 圃場面積と実作業面積のcsvファイル名
    Options::DirMode dirRange; // 作業方向の範囲と間隔
}
// constexpr static auto EOL = "\n";;

void printUsage() {
	PathPlanTest ppt;
	InputData inData = InputData::getSampleData();
	const Tractor& tractor0 = inData.tractors[0];
	const WorkSetting& work = inData.work;

	std::cout << "Usage\n" <<
	" PathPlanTest [OPTION]...\n"
	<< std::endl;

	std::cout <<
	"[Options]\n"
    "     -OPTIONNAME={option values 1 | 2 | 3 ...} [the value in default]\n"
	" note:All OPTIONNAMEs are case sensitive, value strings are case insensitive.\n"
    "      Additionally, there are general alias for boolean value as: {0|1} = {off | on} = {false | true}.\n"
	"Path:\n"
	" -i=PATH\n"
	"	InputPath [" << inputPath << "]\n"
    " -infile=FILENAME\n"
    "	Just one input field file to test.\n"
	" -o=PATH\n"
	"	OutputPath [" << outputPath_default << "]\n"
    "	And use for result .html file name. [" << indexFilename_default << "]\n"
	"	                   .csv file name. [" << areaFilename_default << "]\n"
    " -osuffix=SUFFIX\n"
    "	Suffix to add to base name of each result file.\n"
    << Options::ResultType::usage
    << Options::GeneratePathType::usage <<
    "Patterns:\n"
	" -d=FLOAT [" << ppt._workPathDir.interval << "]\n"
	"	This is the pattern in default when any pattern option wasn't specified.\n"
    "	Increase angle of path direction interval between 1 to 180 degrees for each field.\n"
    "	Or angles of all edges in each field if set 0.\n"
    << Options::DirMode::usage <<
    " -directionEdge=INTEGER\n"
    "	Index number of field edge for path direction for run once each field.\n"
    "	Or angles of all edges in each field if set -1.\n"
    " -directionPoints=LAT1,LON1,LAT2,LON2\n"
    "	Two coordinates to determine direction of working path. (Same way of application.)\n"
	"Tractor metrics:\n"
	" -TW=FLOAT [" << std::fixed << tractor0.width	<< "]\n"
	"	Tractor width. (mm)\n"
	" -TR=INTEGER [" << tractor0.turnRadius	<< "]\n"
	"	Turn radius. (mm)\n"
	"Tractor metrics from GNSS position:\n"
	" -TLF=INTEGER [" << tractor0.gnss.lengthToFrontEnd << "]\n"
	"	Length to front end of tractor includes front weight. (mm)\n"
	" -TLR=INTEGER [" << tractor0.gnss.lengthToRearEnd << "]\n"
	"	Length to rear end of tractor as point of lower link. (mm)\n"
	"Implement metrics:\n"
    << Options::ImplementPos::usage <<
	" -IL=INTEGER [" << tractor0.implement.length << "]\n"
	"	Implement length. (mm)\n"
	" -ILW=INTEGER [" << tractor0.implement.cultivationPos << "]\n"
	"	Implement length to working position. (mm)\n"
	" -IW=INTEGER [" << tractor0.implement.width	<< "]\n"
	"	Implement width of extent. (mm)\n"
    " -ILTC=INTEGER [" << tractor0.implement.widthOffset << "]\n"
    "	Offset of implement width of extent. (mm, rightward is positive.)\n"
    " -IWW=INTEGER [" << tractor0.implement.cultivationWidth    << "]\n"
    "	Implement width of working. (mm)\n"
    " -IWO=INTEGER [" << tractor0.implement.cultivationWidthOffset << "]\n"
    "	Offset of implement width of working. (mm, rightward is positive.)\n"
    "	Options -IW, -IWW and -ILTC must be specified before this.\n"
    " -IO=INTEGER [" << tractor0.implement.overhang << "]\n"
    "	Inside distance the working width edge from implement edge. (mm)\n"
    "	This option will be output to GuidanceData and there is no effect for path planning.\n"
    " -implementCanBackward={0|1} [" << tractor0.implement.canBackward << "]\n"
    "    Permission for backward moveing. [0:inhibit, 1:permit].\n"
    "Work settings:\n"
    << Options::WorkPattern::usage
    << Options::ProgressType::usage
    << Options::WorkPath_legtype::usage
    << Options::Headland_process::usage
    << Options::Headland_pattern::usage
    << Options::Headland_rotation::usage
    << Options::Headland_cornerTurn::usage <<
    " -canBackward={0|1} [" << work.canBackward << "]\n"
    "	Permission for backward moveing. [0:inhibit, 1:permit].\n"
    " -overlapWidth=INTEGER [" << work.overlapWidth << "]\n"
    "	Overlap width in IWW. And interval width if negative. (mm)\n"
    << Options::HsMarginType::usage <<
    " -stposIndex=INTEGER [" << ppt._stposIndex << "]\n"
    " -edposIndex=INTEGER [" << ppt._edposIndex << "]\n"
    "	Start point and end point with 0-origin index number in field virtices.\n"
    "	Rotation all virtices if -1. Otherwize it will used number for mod virtices.\n"
    " -stpos=LAT,LON [1st point of a field]\n"
    "	Coordinates of start point. Recomended use for single field.\n"
    " -edpos={LAT,LON | NONE} [1st point of a field]\n"
    "	Coordinates of start point and end point. Recomended use for single field.\n"
    "	Or make field.endPointAvilable flag false if set NONE.\n"
    " -tr2_IWW=INTEGER [refer to IWW value]\n"
    "	Tractor2(manned) implement width of working. (mm)\n"
    "	Use IWW value in default.\n"
    << Options::FollowPos::usage <<
    " -tr2_usePathInterval2forN={true | false} [false]\n"
    "	Use tractor2(manned) IWW for calc headland and side margin width. It depends on headlandSideMarginType.\n"
    << Options::TractorPos::usage <<
    " -shiftValueAB=INTEGER\n"
    "   AB path shift value will be used for pathTypeAB was SHIFT_VALUE.\n"
    << Options::TractorPos::usage
    << Options::CsvCheckType::usage <<
    "[Example1]\n"
    " PathPlanTest -i=./field_20161031/ -o=./result_20161031/ -d=37\n" <<
    "[Example2]\n"
    " PathPlanTest -TW=1758 -TR=4500 -TLF=2240 -TLR=2160 -IL=1500 -ILW=600 -IW=3000 -IWW=2500 -overlapWidth=-100\n"
    "[Example2] set start point 4th virtex.\n"
    " PathPlanTest -stposIndex=3\n"
    << std::endl;
}

/**
 * 範囲クラス
 *
 * @tparam T 数値型
 */
template<typename T>
class Range
{
public:
    Range() = default;
    Range(T aLower, T aUpper) :
        lower(aLower), upper(aUpper)
    {}

    /// 範囲内検査
    bool within(T value) const
    {
        return (lower <= value) && (value <= upper);
    }
    
    T lower = 0;
    T upper = 0;
};

/**
 * パラメータ取得(有効範囲付き)
 *
 *  sが数値として解釈でき、rangeの範囲内であればその値をnに格納しtrueを返す。
 *  - もしsがパラメータとして無効な場合、falseを返す。このときnは不定。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   range   パラメータ値の有効範囲
 * @param[in]   arg     1パラメータの全体
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
template<typename T>
bool validate(const std::string& s, T& n, Range<T>&& range, const std::string& arg) {
	T num = 0;
	try {
		num = boost::lexical_cast<T>(s);
	} catch (const std::exception &err) {
		std::cout << "Number Format Error.\n";
		std::cout << " [" << arg << "]\n";
		return false;
	}
	if (!range.within(num)) {
		std::cout << "Invalid Argument Error.\n";
		std::cout << " [" << arg << "] out of range: [" << range.lower << ", " << range.upper << "]\n";
		return false;
	}
	n = num;
	return true;
}

/**
 * パラメータ取得(最小値付き)
 *
 * sが数値として解釈でき、min以上であればその値をnに格納しtrueを返す。
 *  - sがパラメータとして無効な場合、falseを返す。このときnは不定。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   min     パラメータ値の最小値
 * @param[in]   arg     1パラメータの全体
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
template<typename T>
bool validate(const std::string& s, T& n, T min, const std::string& arg) {
    T num = 0;
    try {
        num = boost::lexical_cast<T>(s);
    } catch (const std::exception &err) {
        std::cout << "Number Format Error.\n";
        std::cout << " [" << arg << "]\n";
        return false;
    }
    if (num < min) {
        std::cout << "Invalid Argument Error.\n";
        std::cout << " [" << arg << "] less than " << min << "\n";
        return false;
    }
    n = num;
    return true;
}


/**
 * パラメータ取得(bool)
 *
 * sがbool値として解釈できればnに格納し、trueを返す。
 *  - sがパラメータとして無効な場合、falseを返す。このときnは不定。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   arg     1パラメータの全体(エラー出力用)
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
bool validate(std::string s, bool& n, const std::string& arg) {
    for_each(s.begin(), s.end(), [](char& it) { it = tolower(it); } );
    
    int num = 0;
    try {
        if (s == "true" || s == "on") {
            num = 1;
        } else if (s == "false" || s == "off") {
            num = 0;
        } else {
            num = boost::lexical_cast<int>(s);
        }
    } catch (const std::exception &err) {
        std::cout << "Boolean Format Error.\n";
        std::cout << " [" << arg << "]\n";
        return false;
    }
    n = (bool)num;
    return true;
}

/**
 * resulttypeパラメータ取得(int)
 *
 * sが有効なresulttype値として解釈できればnに格納し、trueを返す。
 *  - sがパラメータとして無効な場合、falseを返す。このときnは不定。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   arg     1パラメータの全体(エラー出力用)
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
template<typename T>
bool validate(std::string s, T& type, const std::string& arg) {
    try {
        type = s;
    } catch (...) {
        std::cout << "enum value Error.\n";
        std::cout << " [" << arg << "]\n";
        return false;
    }

    return true;
}


/**
 * GeoPointパラメータ取得
 *
 * sが有効なGeoPoint値 "LAT,LON" として解釈できればnに格納し、trueを返す。
 *  - sがパラメータとして無効な書式である場合、falseを返す。このときnは不定。
 *  - 座標として有効かどうかは検査しない。
 *
 * @param[in]   s       入力パラメータ値
 * @param[out]  n       出力先
 * @param[in]   arg     1パラメータの全体(エラー出力用)
 *
 * @return パラメータ値が有効かどうか
 * @retval true     有効
 * @retval false    無効
 */
bool validate(std::string s, GeoPoint& p, const std::string& arg) {
    try {
        std::vector<std::string> strs;
        boost::split(strs, s, boost::is_any_of(","));
        std::for_each(strs.begin(), strs.end(), [](std::string& str) { boost::trim(str); });
        p.lat = boost::lexical_cast<double>(strs[0]);
        p.lon = boost::lexical_cast<double>(strs[1]);
    } catch (...) {
        std::cout << "Coordinates(LAT,LON) value Error.\n";
        std::cout << " [" << arg << "]\n";
        return false;
    }
    
    return true;
}

/**
 * ディレクトリ確認
 *
 * sに指定されたバス(ディレクトリ)の準備をする
 *  - createフラグがtrueであれば、sに示すパスが存在しない場合にディレクトリの生成を試みる。
 *    falseであれば生成せずにfalseを返す。
 *
 * @param[in]   psth    入力パラメータ値
 * @param[in]   create  ディレクトリ生成フラグ
 *
 * @return パラメータ値が有効かどうか
 * @retval true     指定パスは有効(生成した場合を含む)
 * @retval false    指定パスは無効(アクセスできない場合を含む)
 */
bool makeSureDir(std::string& path, bool create) {
	size_t len = path.length();
	if (len == 0) {
		// 空文字列の場合はエラー
		std::cout << "Invalid Argument Error.\n";
		std::cout << " PATH is empty string.\n";
		return false;
	}
	if (path.substr(len - 1, 1) != "/") {
		// 末尾に"/"を追加
		path += "/";
	}
	// 情報の取得
	struct stat st;
	if (stat(path.c_str(), &st) == 0) {
		// 情報の取得に成功
		if ((st.st_mode & S_IFMT) == S_IFDIR) {
			// 出力先パスがディレクトリ
			return true;
		}
		// 出力先パスがディレクトリではない
		std::cout << "Invalid Argument Error.\n";
		std::cout << " PATH[" << path << "] is NOT a directory.\n";
		return false;
	}
	if (!create) {
		// 情報の取得に失敗 (権限がない、または存在しない?)
		std::cout << "Error, PATH[" << path << "] does NOT exist.\n";
		return false;
	}
	// 情報の取得に失敗 (権限がない、または存在しない?)
	std::cout << "Info, PATH[" << path << "] does NOT exist.\n";
	// ディレクトリの作成
	if (mkdir(path.c_str(), 0777) == 0) {
		// ディレクトリの作成に成功
		std::cout << "Info, mkdir(" << path << ", 0777) success.\n";
		return true;
	}
	// ディレクトリの作成に失敗 (権限がない、または同名のファイルが存在する?)
	std::cout << "Error, mkdir(" << path << ", 0777) failed.\n";
	return false;
}

/// タイムスタンプ文字列を返す
std::string getCurrentDateTimeString(const std::string& format = "%Y-%m-%d %H:%M:%S") {
    std::array<char, 64> buffer{0};
    time_t rawtime;
    time(&rawtime);
    const auto timeinfo = localtime(&rawtime);
    strftime(buffer.data(), sizeof(buffer), format.c_str(), timeinfo);
    
    return std::string{buffer.data()};
}

int main(int argc, const char * argv[]) {

	// デフォルトのパラメータ
	InputData inData = InputData::getSampleData();
    Tractor& tractor0 = inData.tractors[0];
    Tractor tractor1;
    tractor1.implement.cultivationWidth = tractor0.implement.cultivationWidth;    // デフォルトはロボトラと同じ
    WorkSetting& work = inData.work;
	PathPlanTest ppt;

	for (int i = 1; i < argc; ++i) {
		std::string arg = argv[i];
        ppt._additionalInfo += " " + arg;
		if (arg.length() < 4) {
			// 無効なオプションが指定された
			std::cout << "Invalid Option Error.\n";
			std::cout << " [" << arg << "]\n";
			printUsage();
			return 0;
		}
		std::vector<std::string> vs;
		boost::algorithm::split(vs, arg, boost::is_any_of("="));
		if (2 < vs.size()) {
			// 無効なオプションが指定された
			std::cout << "Invalid Option Error.\n";
			std::cout << " [" << arg << "]\n";
			printUsage();
			return 0;
		}

		std::string option = vs[0]; // arg.substr(0, 3);
		std::string parameter = vs[1]; // arg.substr(3);
        bool optionValid = true;
		if (option == "-inDataPath") {
			// InputDataファイルの入力元
			ppt._inDataPath = parameter;
		} else if (option == "-i") {
			// 圃場ファイルの入力元
			inputPath = parameter;
        } else if (option == "-infile") {
            // 圃場ファイルの入力元
            inputFile = parameter;
		} else if (option == "-o") {
			// パス生成結果の出力先
			outputPath = parameter;
        } else if (option == "-osuffix") {
            // 結果ファイルサフィックス
            outputSuffix = parameter;
        } else if (option == Options::ResultType::signature) {
            // 内部方向結果ファイル使用
            optionValid = validate(parameter, ppt._resultSvgType, arg);
        } else if (option == Options::GeneratePathType::signature) {
            // 生成パスモード
            optionValid = validate(parameter, ppt._generatePathType, arg);
        } else if (option == Options::CsvCheckType::signature) {
            // CSV出力チェック
            optionValid = validate(parameter, ppt._checkCsvOutput, arg);
		} else if (option == "-d") {
			// 作業方向の間隔(度)
            ppt._workPathDir.mode = Options::DirMode::ANGLE_INTERVAL;
            optionValid = validate(parameter, ppt._workPathDir.interval, Range<double>{0.0, 180.0}, arg);
            if (optionValid) {
                ppt._workPathDir.range.start = 0.0;
                ppt._workPathDir.range.end = 180.0;
            }
        } else if (option == Options::DirMode::signature) {
            // 作業方向(1回のみ)
            ppt._workPathDir.mode = Options::DirMode::ANGLE;
            optionValid = validate(parameter, ppt._workPathDir.angle, 0.0, arg);
        } else if (option == "-directionEdge") {
            // 作業方向(エッジ指定)
            optionValid = validate(parameter, ppt._workPathDir.edge, -1, arg);
            if (optionValid) {
                if (ppt._workPathDir.edge == -1) {
                    // エッジ巡回
                    ppt._workPathDir.mode = Options::DirMode::EDGE_AROUND;
                } else {
                    // 1回のみ
                    ppt._workPathDir.mode = Options::DirMode::EDGE;
                }
            }
        } else if (option == "-directionPoints") {
            // 作業方向(2点指定)
            ppt._workPathDir.mode = Options::DirMode::POINTS;
            optionValid = validate(parameter, ppt._workPathDir.points, arg);
        } else if (option == "-stposIndex") {
            // 開始点巡回
            optionValid = validate(parameter, ppt._stposIndex, -1, arg);
        } else if (option == "-edposIndex") {
            // 終了点巡回
            optionValid = validate(parameter, ppt._edposIndex, -1, arg);
        } else if (option == "-stpos") {
            // 開始点座標
            optionValid = validate(parameter, ppt._stpos, arg);
            if (optionValid) {
                ppt._stposIndex = -2;
            }
        } else if (option == "-edpos") {
            // 終了点座標
            if (parameter == "NONE") {
                ppt._edposIndex = -3;
            } else {
                optionValid = validate(parameter, ppt._edpos, arg);
                if (optionValid) {
                    ppt._edposIndex = -2;
                }
            }
        } else if (option == Options::WorkPattern::signature) {
            // 作業パターン
            optionValid = validate(parameter, ppt._workPattern, arg);
            if (optionValid) {
                inData.work.workPattern = ppt._workPattern;
            }
        } else if (option == Options::WorkRotation::signature) {
            // 周回方向
            optionValid = validate(parameter, ppt._workRotation, arg);
            if (optionValid) {
                inData.work.rotation = ppt._workRotation;
            }
        } else if (option == Options::ProgressType::signature) {
            // 作業パターン
            optionValid = validate(parameter, ppt._progressType, arg);
            if (optionValid) {
                inData.work.progressType = ppt._progressType;
            }
        } else if (option == Options::WorkPath_legtype::signature) {
            // 作業領域拡大
            optionValid = validate(parameter, ppt._WorkPath_legtype, arg);
            if (optionValid) {
                inData.work.workPath.leg.type = ppt._WorkPath_legtype;
            }
        } else if (option == Options::Headland_process::signature) {
            // 枕地作業順
            optionValid = validate(parameter, ppt._headland_process, arg);
            if (optionValid) {
                inData.work.headland.process = ppt._headland_process;
            }
        } else if (option == Options::Headland_pattern::signature) {
            // 枕地作業パターン
            optionValid = validate(parameter, ppt._headland_pattern, arg);
            if (optionValid) {
                inData.work.headland.pattern = ppt._headland_pattern;
            }
        } else if (option == Options::Headland_rotation::signature) {
            // 枕地作業の周回方向
            optionValid = validate(parameter, ppt._headland_rotation, arg);
            if (optionValid) {
                inData.work.headland.rotation = ppt._headland_rotation;
            }
        } else if (option == Options::Headland_cornerTurn::signature) {
            // 作業制約
            optionValid = validate(parameter, ppt._headland_restriction, arg);
            if (optionValid) {
                inData.work.headland.restriction = ppt._headland_restriction;
            }
		} else if (option == "-canBackward") {
			// 作業設定のバック許可
            // - ターン時にバックするかどうかであって、機械的に不可能かどうかではない。
            optionValid = validate(parameter, work.canBackward, arg);
		} else if (option == "-TW") {
			// トラクター幅
			optionValid = validate(parameter, tractor0.width, 1.0, arg);
		} else if (option == "-TR") {
			// 旋回半径
            optionValid = validate(parameter, tractor0.turnRadius, 1.0, arg);
		} else if (option == "-TLF") {
			// GNSSアンテナからフロントウェイトまでの長さ
			optionValid = validate(parameter, tractor0.gnss.lengthToFrontEnd, 1.0, arg);
		} else if (option == "-TLR") {
			// GNSSからロアリンクまでの長さ
			optionValid = validate(parameter, tractor0.gnss.lengthToRearEnd, 1.0, arg);
        } else if (option == "-IPOS") {
            // 作業機位置
            optionValid = validate(parameter, ppt._implementPos, arg);
            if (optionValid) {
                tractor0.implement.pos = ppt._implementPos;
            }
		} else if (option == "-IL") {
			// ロアリンクから作業機後端までの長さ
			optionValid = validate(parameter, tractor0.implement.length, 1.0, arg);
		} else if (option == "-ILW") {
			// ロアリンクから作業(耕耘)中心までの長さ
			optionValid = validate(parameter, tractor0.implement.cultivationPos, 1.0, arg);
		} else if (option == "-IW") {
			// 作業機幅
			optionValid = validate(parameter, tractor0.implement.width, 1.0, arg);
        } else if (option == "-ILTC") {
            // 作業機オフセット
            optionValid = validate(parameter, tractor0.implement.widthOffset, 0.0, arg);
		} else if (option == "-IWW") {
			// 作業(耕耘)幅
			optionValid = validate(parameter, tractor0.implement.cultivationWidth, 1.0, arg);
        } else if (option == "-IWO") {
            // 作業(耕耘)幅オフセット
            optionValid = validate(parameter, tractor0.implement.cultivationWidthOffset, -50000.0, arg);
            if (optionValid) {
                const double overhang = (tractor0.implement.width - tractor0.implement.cultivationWidth) / 2.0;
                const double offsetdiff = tractor0.implement.cultivationWidthOffset - tractor0.implement.widthOffset;
                tractor0.implement.overhang = abs(overhang + offsetdiff);
            }
        } else if (option == "-IO") {
            // 作業機オーバーハング
            optionValid = validate(parameter, tractor0.implement.overhang, 0.0, arg);
            if (optionValid) {
//                const double centerOverhang = (tractor0.implement.width - tractor0.implement.cultivationWidth) / 2.0;
//                const double offsetadj = tractor0.implement.overhang - ((tractor0.implement.width - tractor0.implement.cultivationWidth) / 2.0);
//                tractor0.implement.cultivationWidthOffset = tractor0.implement.widthOffset + copysign(offsetadj, tractor0.implement.widthOffset);
            }
        } else if (option == "-implementCanBackward") {
            // 作業機のバック許可
            optionValid = validate(parameter, tractor0.implement.canBackward, arg);
        } else if (option == "-overlapWidth") {
            // オーバーラップ幅
            optionValid = validate(parameter, work.overlapWidth, -50000.0, arg);
        } else if (option == "-headlandSideMarginType") {
            // 枕地幅/サイドマージンの計算方法
            optionValid = validate(parameter, ppt._headlandSideMarginType, arg);
            if (optionValid) {
                inData.work.headlandSideMarginType = ppt._headlandSideMarginType;
            }
        } else if (option == "-tr2_IWW") {
            // 有人機作業幅
            optionValid = validate(parameter, tractor1.implement.width, 0.0, arg);
        } else if (option == "-tr2_FollowPos") {
            // 有人機位置
            optionValid = validate(parameter, ppt._followPos, arg);
            if (optionValid) {
                tractor1.followPos = ppt._followPos;
            }
        } else if (option == "-tr2_usePathInterval2forN") {
            // 有人機あり、かつ枕地幅/サイドマージンの計算方法が1または2の場合に、整数倍の基準として有人機の作業間隔を使用するフラグ
            optionValid = validate(parameter, inData.work.usePathInterval2forN, arg);
        } else if (option == "-pathTypeAB") {
            // ABパスモード
            optionValid = validate(parameter, ppt._pathTypeAB, arg);
            if (optionValid) {
                inData.work.pathTypeAB = ppt._pathTypeAB;
            }
        } else if (option == "-shiftValueAB") {
            // ABパスシフト量
            optionValid = validate(parameter, inData.work.shiftValueAB, 0.0, arg);
        } else if (option == Options::TractorPos::signature) {
            // トラクター位置
            optionValid = validate(parameter, ppt._tractorPos, arg);
            if (optionValid) {
                inData.field.tractorPos = ppt._tractorPos;
            }
        } else if (option == "-help") {
            optionValid = false;
        } else {
			// 無効なオプションが指定された
			std::cout << "Invalid Option Error.\n";
			std::cout << " [" << arg << "]\n";
            optionValid = false;
		}
        
        if (!optionValid) {
			printUsage();
            return 0;
        }
	}

    // 有人トラクターあり
    if (ppt._followPos != Options::FollowPos::UNDEFINED) {
        inData.tractors.push_back(tractor1);
    } else if (inData.work.usePathInterval2forN) {
        printUsage();
        return 0;
    }
    
    // インデックスファイル名の決定
    if (indexFilename.empty()) {
        std::string tmp;
        if (!outputPath.empty()) {
            tmp += '_';
            auto beginIt = outputPath.cbegin();
            auto endIt = outputPath.cend();
            auto begin = outputPath.find_first_not_of("./\\ ");
            auto end = outputPath.find_last_not_of("./\\ ");
            if (begin != std::string::npos && end != std::string::npos) {
                advance(beginIt, begin);
                endIt = next(outputPath.cbegin(), end + 1);
            }
            std::replace_copy_if(beginIt, endIt, std::back_inserter(tmp),
                                 [](std::string::value_type ch) {
                                     std::string invalidChars{"\\/:*?\"<>|] "};
                                     return (invalidChars.find(ch) != std::string::npos);
                                 },
                                 '_');
        }
        indexFilename = "index" + tmp + ".html";
    }
    
	// 面積csvファイル名の決定
	if (areaFilename.empty()) {
		std::string tmp;
		if (!outputPath.empty()) {
			tmp += '_';
			auto beginIt = outputPath.cbegin();
			auto endIt = outputPath.cend();
			auto begin = outputPath.find_first_not_of("./\\ ");
			auto end = outputPath.find_last_not_of("./\\ ");
			if (begin != std::string::npos && end != std::string::npos) {
				advance(beginIt, begin);
				endIt = next(outputPath.cbegin(), end + 1);
			}
			std::replace_copy_if(beginIt, endIt, std::back_inserter(tmp),
								 [](std::string::value_type ch) {
									 std::string invalidChars{"\\/:*?\"<>|] "};
									 return (invalidChars.find(ch) != std::string::npos);
								 },
								 '_');
		}
		areaFilename = "area" + tmp + ".csv";
	}

    // outputPathはindexファイル名に影響するのでoutputFilenaemの決定後に行うこと
    if (outputPath.empty()){
        outputPath = outputPath_default;
    }
    
	// 入力元のチェック
    if (inputFile.empty()) {
        if (ppt._inDataPath.empty() && inputPath.empty()) {
            inputPath = inputPath_default;
        }
        if (!inputPath.empty() && !makeSureDir(inputPath, false)) {
            return 0;
        }
    }
	// 出力先のチェック
	if (!makeSureDir(outputPath, true)) return 0;

	// テストの実行
    std::cout << "[PathPlanTest] Build " << __DATE__ " " __TIME__ << "\n"
              << "Start date :" << yanmar::PathPlan::getCurrentDateTimeString() << "\n";

    ppt._inputFilename = inputFile;
    ppt._outputSuffix = outputSuffix;
	ppt.setParameter(inputPath, outputPath, indexFilename, areaFilename);
	ppt._inData = inData;
	ppt.start();
    
    std::cout << "Finished :"<< yanmar::PathPlan::getCurrentDateTimeString() << "\n";
	return 0;
}

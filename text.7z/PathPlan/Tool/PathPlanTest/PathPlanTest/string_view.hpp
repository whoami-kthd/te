// Yanmar Confidential 20200918
/**
 @file array_view.hpp
 
 Value - key handling class for command-line options.
 */
#pragma once

#include <array>
#include <string>
#include <stdexcept>

namespace yanmar { namespace PathPlan {
    
    // 大文字変換
    inline
    std::string toUpper(std::string str) {
        for_each(str.begin(), str.end(), [](char& ch) { ch = toupper(ch); });
        return str;
    }

    //    // 配列のサイズを得る
    //    template <class T, std::size_t N>
    //    inline static
    //    std::size_t arraysize(const T (&table)[N]) { return N; }
    
    /**
     array_view
     
     配列をコンテナのように扱うラッパー。string_viewのベース
     */
    template<typename T>
    class array_view {
    public:
        using value_type = T;
        const value_type*const data;
        using reference = value_type&;
        using const_referece = const value_type&;
        using size_type = std::size_t;
        using iterator = value_type*;
        using const_iterator = const value_type*;
        
        size_type count;
        size_type size() const noexcept { return (count - 1); }
        size_type length() const noexcept { return size(); }
        
        const_referece operator[](size_type n) const noexcept { return data[n]; }
        const_referece at(size_type n) const {
            if (count <= n ) {
                throw std::out_of_range("");
            }
            
            return data[n];
        }
        
        const_iterator begin() const noexcept { return data; }
        const_iterator cbegin() const noexcept { return data; }
        const_iterator end() const noexcept { return &data[count]; }
        const_iterator cend() const noexcept { return &data[count]; }
        
        template<std::size_t N>
        constexpr array_view(const T (&v)[N]) :
            data(v),
            count(N)
        {}
        
        operator std::string() const {
            return std::string(data);
        }
        
        operator const value_type*const() {
            return data;
        }
    };
    
    // string_viewの代用品(C++17にはある)
    using cstr_adaptor = array_view<std::string::value_type>;
    
    // cstr_adaptor比較演算子
    static inline
    bool operator==(const cstr_adaptor& sa, const cstr_adaptor::value_type* s) {
        return (strcmp(sa.data, s) == 0);
    }
    
    static inline
    bool operator==(const cstr_adaptor& sa, const cstr_adaptor& s) {
        return (sa == s.data);
    }
    
    static inline
    bool operator==(const cstr_adaptor& sa, const std::string& s) {
        return (s == (std::string)sa);
    }
    
    template<typename T>
    static inline
    bool operator==(const T s, const cstr_adaptor& sa) {
        return (sa == s);
    }

}} // namespace yanmar::PathPlan::Options

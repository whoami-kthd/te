// CMVDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMVDlg.h"
#include "CMV_Util.h"
#include "CMV_DEF.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define CMV_DLG_SIZEX						653
#define CMV_DLG_SIZEY						500
#define MAGIN_RIGHT							230
#define MAGIN_TOP_BOTTOM					160

// #DDT171006-01 Check condition of load map (S)
CString NGAnswerAutoRun		=	_T("Equipment PC is running in autorun mode. Stop it before loading map.");
							
CString NGAnswerStepRun		=	_T("Equipment PC is running in step mode. Stop it before loading map.");
						
CString NGAnswerScreen		=	_T("Equipment PC is not in AutoRun screen, StepMode screen or Manual screen!");
						
CString NGAnswerStgVacuum	=	_T("Carrier stage vacuum is OFF.\nTurn ON vacuum on Manual.");

CString NGAnswerNoUseMap	=	_T("Carrier mapping mode is OFF.\nTurn ON mapping mode then loading map again.");

CString CannotLoadMap		=	_T("Cannot load map.");

CString TimeOutTFC			=	_T("Time out!\nDo you want to wait response from TFC?");
							
CString LoadDataFromTFC		=	_T("Cannot load data from TFC.");

CString ConvertExcute		=	_T("Map convert error execute. Cannot convert map data.");

CString ConvertError		=	_T("Map convert error happend. Cannot convert map data.");
						
CString ConvertTimeout		=	_T("Map convert error timeout. Cannot convert map data.");

CString DesFileNotFound		=	_T("Destination map folder is invalid.");

CString MapIsWrongFormat	=	_T("Map file is wrong format.");							

CString MapToConvertIsNotFound = _T("Map file to convert is not found.");


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMVDlg dialog

IMPLEMENT_DYNAMIC(CCMVDlg, CDialog);

CCMVDlg::CCMVDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCMVDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCMVDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon			= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pDoc			= NULL;
	m_bInit			= false;
	m_MapLayout		= NULL;
	m_pMapInfo		= NULL;
	m_LoadMapBtn    = NULL;
	m_Edit			= NULL;
	pCbb			= NULL;
// #DDT171006-01 Check condition of load map (S)
	m_pLoadMapThread = NULL;
	m_LoadMapHandle[0] = NULL;
	m_LoadMapHandle[1] = NULL;
// #DDT171006-01 Check condition of load map (E)
	indexMove = -1;
}

CCMVDlg::~CCMVDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
	DeleteObject(m_hBackClr);
	DeleteObject(m_hPosClr);
	DeleteObject(m_hRefClr);
	DeleteObject(m_hPickClr);
// #DDT171006-01 Check condition of load map (S)
	if (m_pLoadMapThread) {
		delete m_pLoadMapThread;
	}
	::CloseHandle(m_LoadMapHandle[0]);
	::CloseHandle(m_LoadMapHandle[1]);
// #DDT171006-01 Check condition of load map (E)
}

void CCMVDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCMVDlg)
	DDX_Control(pDX, IDC_CHIP_LIST, m_ChipListCtrl);
	DDX_Control(pDX, IDC_LIST_INDEX_PICKUP, m_ListIndexCtrl);
	//}}AFX_DATA_MAP
}

static UINT WM_TFC_CTRL  = RegisterWindowMessage(STR_TFC_CTRL);
static UINT CMV_CTRL	 = RegisterWindowMessage(STR_CMV_CTRL);
BEGIN_MESSAGE_MAP(CCMVDlg, CDialog)
	//{{AFX_MSG_MAP(CCMVDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTN_LOAD_MAP, OnBtnLoadMap)
	ON_BN_CLICKED(IDC_BTN_ZOOM_IN, OnBtnZoomIn)
	ON_BN_CLICKED(IDC_BTN_ZOOM_OUT, OnBtnZoomOut)
	ON_NOTIFY(NM_CLICK, IDC_LIST_INDEX_PICKUP, OnClickListIndexPickup)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_CHIP_LIST, OnChipListCustomDraw)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST_INDEX_PICKUP, OnIndexPickupListCustomDraw)
	ON_NOTIFY(NM_CLICK, IDC_CHIP_LIST, OnClickChipList)
	ON_CBN_SELCHANGE(IDC_ZOOM, OnSelchangeZoom)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BTN_PICK, OnBtnPick)
	ON_BN_CLICKED(IDC_BTN_POS, OnBtnPos)
	ON_BN_CLICKED(IDC_BTN_REF, OnBtnRef)
	ON_BN_CLICKED(IDC_BTN_BG, OnBtnBg)
	ON_BN_CLICKED(IDC_BTN_JUMP, OnBtnJump)
	ON_REGISTERED_MESSAGE(CMV_CTRL, OnMapCtrl)
	ON_WM_GETMINMAXINFO()
	ON_WM_SIZE()
	ON_MESSAGE(WM_UPDATE_MAP, OnUpdateMapView)		// #DDT171006-01 Check condition of load map
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMVDlg message handlers

BOOL CCMVDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_IsLoadedMap = false;

	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;

	m_pDoc = new CMV_Doc();
	// Create Map view layout
	CRect rect;
	GetDlgItem(IDC_MAP_DISP_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_MapLayout = new CMV_Map_View();
	m_MapLayout->SetDocument(m_pDoc);
	m_MapLayout->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_MAP_DISP_LAYOUT, pContext);

	// Create Map Jump view layout
	GetDlgItem(IDC_MAP_JUMP)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_pMapInfo = new CMV_MapInfo();
	m_pMapInfo->SetDocument(m_pDoc);
	m_pMapInfo->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_MAP_JUMP, pContext);

	delete pContext;

	/* Init map view */
	char buf[BUFSIZ];
	GetModuleFileName(NULL, buf, BUFSIZ - 1);	
	m_pDoc->m_rootPath = buf;
	CString AppName(AfxGetAppName());
	AppName += ".exe";
	m_pDoc->m_rootPath.Replace(AppName, "");
	m_pDoc->m_datFile = m_pDoc->m_rootPath + STR_MD_LOAD;
	m_pDoc->m_IniFile = m_pDoc->m_rootPath + STR_MV ".ini";
	
	m_pDoc->m_ConvertIniFile = buf;
	m_pDoc->m_ConvertIniFile.Replace(AppName, "");
	m_pDoc->m_ConvertIniFile+= "Convert.ini";

	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "DispMode", TRUE, m_pDoc->m_DispMode, 0);
	m_pDoc->m_nFormat = DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX | DT_CENTER | DT_NOCLIP;

	m_pDoc->mySFont.CreateFont(11, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));

	m_pDoc->myLFont.CreateFont(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));
	
	m_pDoc->m_Setting	= (_T("Setting"));
	m_pDoc->m_LoadFile	= (_T(""));
	m_pDoc->m_DispMode	= (0);
	m_pDoc->m_FNLOC		= (_T(""));
	m_pDoc->m_MID		= (_T(""));

	/* Init colors for each category (S) */
	m_pDoc->s1 = "G_CategoryColor";
	for( int i = 0 ; i < 256 ; i++){
		sprintf(m_pDoc->ch, "%03d", i);
		m_pDoc->s2 = m_pDoc->ch;
		m_pDoc->s3 = m_pDoc->s1 + m_pDoc->s2;
		GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, (LPCTSTR)m_pDoc->s3, TRUE, m_pDoc->colors, 3, 255);
		m_pDoc->m_gCategoryColor[i] = RGB(m_pDoc->colors[0], m_pDoc->colors[1], m_pDoc->colors[2]);
	}
	/* Init colors for each category (E) */

	/* Init variables */
	m_pDoc->m_IsLoadedMap = false;
	
	m_LoadMapBtn = (CButton*)GetDlgItem(IDC_BTN_LOAD_MAP);
	m_LoadMapBtn->EnableWindow(TRUE);
	

	/* Initialize Index pickup list (S) */
	// Initial extended style for the list control on this dialog
	DWORD dwStyle = m_ListIndexCtrl.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP;
	m_ListIndexCtrl.SetExtendedStyle(dwStyle);

	CRect rectIndexList;
	m_ListIndexCtrl.GetClientRect(rectIndexList);
	
	m_ListIndexCtrl.InsertColumn(0, _T("Step"), LVCFMT_LEFT, rectIndexList.Width()/3);
	m_ListIndexCtrl.InsertColumn(1, _T("Index"), LVCFMT_LEFT, rectIndexList.Width()/3*1.5);
	/* Initialize Index pickup list (E) */


	/* Initialize Chip list (S) */
	// Initial extended style for the list control on this dialog
	dwStyle = m_ChipListCtrl.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP;
	m_ChipListCtrl.SetExtendedStyle(dwStyle);

	CRect rectChipList;
	m_ChipListCtrl.GetClientRect(rectChipList);
	
	m_ChipListCtrl.InsertColumn(0, _T("Bin"), LVCFMT_LEFT, rectChipList.Width()/6+5);
	m_ChipListCtrl.InsertColumn(1, _T("Color"), LVCFMT_LEFT, rectChipList.Width()/3-5);
	m_ChipListCtrl.InsertColumn(2, _T("LED number"), LVCFMT_LEFT, rectChipList.Width()/2);
	/* Initialize Chip list (E) */
	
	m_pDoc->m_IndexSelect = -1;
	m_pDoc->m_IsDispIndex = FALSE;
	m_pDoc->m_IsDispJumpInTab = FALSE;			// For display jump index in Jump table of CMV_MapJump class
	m_pDoc->m_IsDispJumpInMapViaClick = FALSE;
	m_pDoc->m_IsDispJumpInMapViaButton = FALSE;
	m_pDoc->m_IsDispCurrentPos = FALSE;
	m_pDoc->m_IsDispRefPos = FALSE;

	m_pDoc->m_JumpXEnter = 0;
	m_pDoc->m_JumpYEnter = 0;

	/* Add content for zoom combobox (E) */

	/* Initialize color setting */
	m_pDoc->m_BackColor = ::GetSysColor(COLOR_BTNFACE);
	m_pDoc->m_RefColor  = ::GetSysColor(COLOR_BTNFACE);
	m_pDoc->m_PosColor  = ::GetSysColor(COLOR_BTNFACE);
	m_pDoc->m_PickColor = ::GetSysColor(COLOR_BTNFACE);
	m_bInit				= true;

	m_pDoc->SettingDataRW(TRUE);

	m_pDoc->DvDataRW(TRUE);

	// Add content for zoom combobox
	pCbb = ((CComboBox*)GetDlgItem(IDC_ZOOM));
	for(int idx = 0; idx < m_pDoc->m_vZoom.size(); idx ++){
		CString str;
		str.Format(_T("x%d"), m_pDoc->m_vZoom[idx]);
		pCbb->AddString(str);
	}
	
	m_pDoc->m_nZoom = 0;
	pCbb->SetCurSel(m_pDoc->m_nZoom);

	m_windowSize[0] =  m_pDoc->m_windowSize[0];		//left
	m_windowSize[1] =  m_pDoc->m_windowSize[1];		//top
	m_windowSize[2] =  m_pDoc->m_windowSize[2];		//right
	m_windowSize[3] =  m_pDoc->m_windowSize[3];     //bottom

	SetWindowPos(&wndTopMost, m_windowSize[0], m_windowSize[1], CMV_DLG_SIZEX, CMV_DLG_SIZEY,  SWP_SHOWWINDOW);

	m_hBackClr = CreateSolidBrush(m_pDoc->m_BackColor);
	m_hPosClr = CreateSolidBrush(m_pDoc->m_PosColor);
	m_hRefClr = CreateSolidBrush(m_pDoc->m_RefColor);
	m_hPickClr = CreateSolidBrush(m_pDoc->m_PickColor);

	// Disable load mapfile button
//	m_LoadMapBtn->EnableWindow(FALSE);

	m_pDoc->MapD.PICKX = 5;
	m_pDoc->MapD.PICKY = 0;
//	m_pDoc->m_CurrentPos = 1;
// #DDT171006-01 Check condition of load map (S)
	m_LoadMapHandle[0] = CreateEvent(NULL, false, false, "OK-Map");
	m_LoadMapHandle[1] = CreateEvent(NULL, false, false, "NG-Map");
// #DDT171006-01 Check condition of load map (E)

	return TRUE;
}

void CCMVDlg::OnClose()
{
	if (m_pDoc) {
		m_pDoc->ClearData();
	}
	CDialog::OnClose();
}

void CCMVDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCMVDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// Center icon in client rectangle
	int cxIcon = GetSystemMetrics(SM_CXICON);
	int cyIcon = GetSystemMetrics(SM_CYICON);
	CRect rect;
	GetClientRect(&rect);
	int x = (rect.Width() - cxIcon + 1) / 2;
	int y = (rect.Height() - cyIcon + 1) / 2;

	if(m_pDoc->m_IndexSelect == -1){
		m_ListIndexCtrl.SetItemState(-1, ~LVIS_SELECTED, LVIS_SELECTED);
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCMVDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CCMVDlg::GetCMV(CCMVApp* pCMVInfo){
	pCMV = pCMVInfo;
}


void CCMVDlg::OnBtnLoadMap() 
{
	// Initialize Input map
	m_pInputMap.SetDocument(m_pDoc);
	m_pInputMap.SetInfoMapDisp(this);

	if(m_pInputMap.DoModal() != IDOK) {
		// do nothing
	} else {
// #DDT171006-01 Check condition of load map (S)
		m_barcode = m_pInputMap.GetBarcode();

		if (m_pLoadMapThread) {
			delete m_pLoadMapThread;
		}
		m_pLoadMapThread = AfxBeginThread(
			OnLoadMapDataThread,				// worker thread
			this,							// param
			THREAD_PRIORITY_NORMAL,			// priority: normal
			0,								// stack size: same as creating thread
			CREATE_SUSPENDED,				// create flag: don't start immediately
			NULL							// security: same as creating thread
			);
		if (m_pLoadMapThread) {
			// Don't auto delete after thread terminated
			m_pLoadMapThread->m_bAutoDelete = FALSE;
			// Start thread
			m_pLoadMapThread->ResumeThread();
		}
// #DDT171006-01 Check condition of load map (E)
	}
}

UINT CCMVDlg::OnLoadMapDataThread(LPVOID pParam)
{
	CCMVDlg *pDlg = (CCMVDlg *)pParam;
	pDlg->LoadMapDataThread();
	return 0;
}

BOOL CCMVDlg::LoadMapDataThread()
{
	BOOL r = TRUE;

	// Find TFC window
	CWnd * tfc = FindWindow(NULL, TFC_FRAMENAME);
	if (tfc != NULL) {
		// Request load map to TFC
		tfc->PostMessage(WM_TFC_CTRL, TFC_LOAD_REQ, 0);
		// Reset event
		ResetEvent(m_LoadMapHandle[0]);
		ResetEvent(m_LoadMapHandle[1]);
		// Wait response from TFC
		DWORD result = WaitForMultipleObjects(2, &m_LoadMapHandle[0], false, 10 * 1000 /*10s*/);
		if (result == WAIT_TIMEOUT) {
			r = FALSE;
		} else if (result == WAIT_OBJECT_0 + 1) {
			r = FALSE;
		} else if (result == WAIT_OBJECT_0) {
			// OK
		}
	}

	if (r) {
		// Convert and load map
		int error = 0;
		r = m_pDoc->LoadMap(m_barcode, error);
		if(!r) {
			switch(error) {
			case CONVER_ERR_RUNCNV:
				AfxMessageBox( ConvertExcute, MB_OK);
				break;
			case CONVER_ERR_CNVERR:
				AfxMessageBox(ConvertError, MB_OK);
				break;
			case CONVER_ERR_TIMEOUT:
				AfxMessageBox(ConvertTimeout, MB_OK);
				break;
			case ERR_DST_DIR:
				AfxMessageBox(DesFileNotFound, MB_OK);
				break;
			case ERR_DataLeght:
				AfxMessageBox(MapIsWrongFormat, MB_OK);
				break;
			case ERR_NoMap:
				AfxMessageBox(MapToConvertIsNotFound, MB_OK);
				break;
			default:
				AfxMessageBox(CannotLoadMap, MB_OK);
				break;
			}
		}
	}

	if (tfc != NULL) {
		if (r) {
			// Create handle for share memory
			m_hMapNameData = CreateFileMapping(
				INVALID_HANDLE_VALUE,    // use paging file
				NULL,                    // default security
				PAGE_READWRITE,          // read/write access
				0,                       // maximum object size (high-order DWORD)
				MAPNAME_SIZE,            // maximum object size (low-order DWORD)
				GLOBAL_NAME_MAPNAME_CARRIER);					  // name of mapping object
			// If cannot create mapping file, show warning message and return
			if (m_hMapNameData == NULL)
			{
				r = FALSE;
			}
			if (r) {
				m_pBufMapNameData = (char*) MapViewOfFile(m_hMapNameData,   // handle to map object
					FILE_MAP_ALL_ACCESS, // read/write permission
					0,
					0,
					MAPNAME_SIZE);
				if (m_pBufMapNameData == NULL)
				{
					r = FALSE;
					CloseHandle(m_hMapNameData);
				}
			}
			
			if (r) {
				int length = m_barcode.GetLength()+1;
				char *tmp = new char[length];
				memset(tmp, 0x00, length);
				memcpy(tmp, m_barcode.GetBuffer(length-1), (length-1) * sizeof(char));
				memcpy(m_pBufMapNameData, tmp, length * sizeof(char));
				delete tmp;
				//memcpy(m_pBufMapNameData, m_barcode.GetBuffer(m_barcode.GetLength()), m_barcode.GetLength() * sizeof(char));
			}
			// Request TFC load map
			if (r) {
				tfc->PostMessage(WM_TFC_CTRL, TFC_LOADMAP, 1);
				
				// Reset event
				ResetEvent(m_LoadMapHandle[0]);
				ResetEvent(m_LoadMapHandle[1]);
				// Wait response from TFC
				DWORD result = WaitForMultipleObjects(2, &m_LoadMapHandle[0], false, 50 * 1000 /*50s*/);
				if (result == WAIT_TIMEOUT) {
					r = FALSE;
					UnmapViewOfFile(m_pBufMapNameData);
					CloseHandle(m_hMapNameData);
				} else if (result == WAIT_OBJECT_0 + 1) {
					r = FALSE;
				} else if (result == WAIT_OBJECT_0) {
				
				}
			}
		}
	}

	if (r) {
		// Update map data to map view
		this->PostMessage(WM_UPDATE_MAP, 0, 0);
	}

	return r;
}


void CCMVDlg::LoadMapFile(CString pathMapFile) {
		// Close Input map file dialog
		m_pInputMap.EndDialog(0);

	if (m_pDoc->MapD.DataRW(TRUE, _T(pathMapFile))) {

		m_pDoc->m_IsLoadedMap = true;
//		m_LoadMapBtn->EnableWindow(FALSE);

		m_pDoc->m_ColumnMax = m_pDoc->MapD.COLCT;
		m_pDoc->m_RowMax  = m_pDoc->MapD.ROWCT;
		
		int idx = m_pDoc->MapD.FNLOC / 90;
		if (0 > idx || 3 < idx || !(m_pDoc->m_DispMode & m_pDoc->DispFNLOC )) {
			idx = 4;
		}
		char *dirs[][5] = {
			{ "�a", "�k", "�s", "�q", "  " },
			{ "��", "��", "��", "�E", "  " },
		};

		if (m_pDoc->m_DispMode & m_pDoc->DispMID) {
			m_pDoc->m_MID.Format(" MID=%s", m_pDoc->MapD.MID);
		} else {
			m_pDoc->m_MID = "";
		}

		/* Put mapfile to str variable (S) */
		for (int y = 0; y < m_pDoc->m_RowMax; y++) {
			m_pDoc->str += m_pDoc->MapD.BINLT.Mid(m_pDoc->m_ColumnMax * y, m_pDoc->m_ColumnMax) + "\n";
		}
		/* Put mapfile to str variable (E) */

		/* Initialize LEDArrayInfo (S) */
		m_pDoc->LEDArrayInfo = new LEDInfo* [m_pDoc->m_ColumnMax];
		for(int i = 0; i < m_pDoc->m_ColumnMax; i++) {
			m_pDoc->LEDArrayInfo[i] = new LEDInfo [m_pDoc->m_RowMax];
		}

		int temp = m_pDoc->m_RowMax * m_pDoc->m_ColumnMax;
		m_pDoc->m_pIndexFirstX = new int[temp];
		m_pDoc->m_pIndexFirstY = new int[temp];

		/* Create axisRects for display axis (S) */
		m_pDoc->xAxisRectArray = new CRect [m_pDoc->m_ColumnMax];
		m_pDoc->yAxisRectArray = new CRect [m_pDoc->m_RowMax];

		SetDlgItemText(IDC_EDIT_MAP_NAME, (m_pDoc->MapD.MID));
		SetDlgItemText(IDC_EDIT_MAP_BCEQU, (m_pDoc->MapD.BCEQU));

		/* Initialize map view */
		m_MapLayout->InitMapView();

		OnUpdateIndexPickupList();
		OnUpdateChipList();
		m_pDoc->m_IsDispJumpInTab = TRUE;

		m_MapLayout->SetBackSolidBrush(m_pDoc->m_BackColor);

		//Write barcode(map name) to INI file
		bool r = TRUE;
		r = WriteFile(_T(m_pDoc->m_IniFile), FCB_PATH_CMV_MAP_SECTION, _T("MapFile"), m_pDoc->m_LoadFile);
	}
}

void CCMVDlg::OnBtnZoomIn() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		if (m_pDoc->m_nZoom < m_pDoc->m_numberOfZoom-1)
		{
			m_pDoc->m_nZoom += 1;
			m_MapLayout->OnUpdateMapView();
		}
		pCbb->SetCurSel(m_pDoc->m_nZoom);
	}
}

void CCMVDlg::OnBtnZoomOut() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		if (m_pDoc->m_nZoom<m_pDoc->m_numberOfZoom && m_pDoc->m_nZoom > 0)
		{
			m_pDoc->m_nZoom -= 1;
			m_MapLayout->OnUpdateMapView();
		}
		pCbb->SetCurSel(m_pDoc->m_nZoom);
	}
}


void CCMVDlg::AddIndexPickup(CListCtrl &ctrl, int row, int col, const char *str)
{
	 LVITEM lv;
    lv.iItem = row;
    lv.iSubItem = col;
    lv.pszText = (LPSTR) str;
    lv.mask = LVIF_TEXT;
    if(col == 0)
        ctrl.InsertItem(&lv);
    else
        ctrl.SetItem(&lv); 
}

void CCMVDlg::OnUpdateIndexPickupList()
{
	int i, j;
	int index = 0;
	
	int maxMoveX = m_pDoc->m_ColumnMax - m_pDoc->m_ratioToolLEDX * (m_pDoc->m_ToolIndexX-1);
	int maxMoveY = m_pDoc->m_RowMax - m_pDoc->m_ratioToolLEDY * (m_pDoc->m_ToolIndexY-1);

	for(j = 0; j < maxMoveY; j++){
		for(i = 0; i<maxMoveX; i++) {
			// Find good bin in map
			if(m_pDoc->LEDArrayInfo[i][j].isGoodBin == true && m_pDoc->LEDArrayInfo[i][j].isInGroup == false) 
			{
				bool isGroup = true;
				int ledY, ledX;
				for(ledY=0; ledY<m_pDoc->m_ToolIndexY; ledY++) {
					for(ledX=0; ledX<m_pDoc->m_ToolIndexX; ledX++) {
						if( (m_pDoc->LEDArrayInfo[i+ledX*m_pDoc->m_ratioToolLEDX][j+ledY*m_pDoc->m_ratioToolLEDY].isGoodBin == false) ||
							(m_pDoc->LEDArrayInfo[i+ledX*m_pDoc->m_ratioToolLEDX][j+ledY*m_pDoc->m_ratioToolLEDY].isInGroup == true)) {
							isGroup = false;
						}
					}
				}
				
				if(isGroup) {
					for(ledY=0; ledY<m_pDoc->m_ToolIndexY; ledY++) {
						for(ledX=0; ledX<m_pDoc->m_ToolIndexX; ledX++) {
							m_pDoc->LEDArrayInfo[i+ledX*m_pDoc->m_ratioToolLEDX][j+ledY*m_pDoc->m_ratioToolLEDY].isInGroup = true;
							m_pDoc->LEDArrayInfo[i+ledX*m_pDoc->m_ratioToolLEDX][j+ledY*m_pDoc->m_ratioToolLEDY].index = index;
						}
					}

					// Update index pickup list (S)
					CString stepStr, indexStr, xCell, yCell;
					stepStr.Format(_T("   %d "), index + 1);
					xCell.Format(_T("   %d"), i+1);
					yCell.Format(_T("%d  "), j+1);

					// Get coordinate of first LED in Index
					m_pDoc->m_pIndexFirstX[index] = i;
					m_pDoc->m_pIndexFirstY[index] = j;

					indexStr = xCell + _T(", ") + yCell;

					AddIndexPickup(m_ListIndexCtrl, index, 0, stepStr );
					AddIndexPickup(m_ListIndexCtrl, index, 1, indexStr);
					// Update index pickup list (E)

					index++;
				}
			}
		}
	}

	indexMove = -1;
}

void CCMVDlg::OnClickListIndexPickup(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	m_pDoc->m_IndexSelect = pNMListView->iItem;
	
//	indexMove = -1;
	m_pDoc->m_IsDispIndex = TRUE;
	m_pDoc->m_IsDispJumpInMapViaClick = FALSE;
	m_pDoc->m_IsDispJumpInMapViaButton = FALSE;
	m_pDoc->m_IsDispCurrentPos = FALSE;
	m_pDoc->m_IsDispJumpInTab = TRUE;
	m_MapLayout->ScrollToDisplayIndex();

	*pResult = 0;
	Invalidate(TRUE);
//	m_MapLayout->UpdateWindow();
//	m_MapLayout->Invalidate();
}


void CCMVDlg::OnUpdateChipList()
{
	int i, j;
	int index = 0;

	/* Initialize ChipNum (S) */
	for(j = 0; j < CHIP_TYPE_MAX ; j++){
		m_pDoc->ChipNum[j] = 0;
	}
	/* Initialize ChipNum (E) */
	
	/* Count number of each LED.ch (S) */
	for(j = 0; j < m_pDoc->m_RowMax; j++){
		for(i = 0; i < m_pDoc->m_ColumnMax; i++){
			if(m_pDoc->LEDArrayInfo[i][j].ch < 256){
				m_pDoc->ChipNum[m_pDoc->LEDArrayInfo[i][j].ch]++;
			}
		}
	}

	for(j = 0; j < CHIP_TYPE_MAX; j++){
		if(m_pDoc->ChipNum[j] > 0) {
			/* Update chip list (S) */				
			CString catStr(j), diesStr;
			diesStr.Format(_T("   %d  "), m_pDoc->ChipNum[j]);
			
			AddIndexPickup(m_ChipListCtrl, index, 0, catStr );
			AddIndexPickup(m_ChipListCtrl, index, 2, diesStr);
			/* Update chip list (E) */
			index++;
		}
	}
}

void CCMVDlg::OnChipListCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
    LPNMLVCUSTOMDRAW lplvcd;

    lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;
    if (lplvcd->nmcd.dwDrawStage == CDDS_PREPAINT){
        *pResult = CDRF_NOTIFYITEMDRAW;
		return;
	}

    if (lplvcd->nmcd.dwDrawStage == CDDS_ITEMPREPAINT){
        *pResult = CDRF_NOTIFYSUBITEMDRAW;
		return;
	}

    if (lplvcd->nmcd.dwDrawStage == (CDDS_ITEMPREPAINT | CDDS_SUBITEM)) {
		int		nCol = 0;
		char	ch[8];

		for (int i = 0; i < m_ChipListCtrl.GetItemCount(); i++) {
			CString szText = m_ChipListCtrl.GetItemText(i, nCol);
			strcpy(ch, (LPCTSTR)(szText));
			COLORREF color = m_pDoc->m_gCategoryColor[(int)ch[0]];

			if(1 == lplvcd->iSubItem) {
				if(lplvcd->nmcd.dwItemSpec == i) {
				   lplvcd->clrTextBk = color;
				}
			}
			else {
				lplvcd->clrTextBk = CMV_DRAW_TEXT_BKG_CLR;
			}
		}

		*pResult = CDRF_NEWFONT;
    }
}


void CCMVDlg::OnIndexPickupListCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
    LPNMLVCUSTOMDRAW lplvcd = reinterpret_cast<NMLVCUSTOMDRAW*>( pNMHDR );
	*pResult = CDRF_DODEFAULT;

    lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;
    if (lplvcd->nmcd.dwDrawStage == CDDS_PREPAINT){
        *pResult = CDRF_NOTIFYITEMDRAW;
		return;
	}

    if (lplvcd->nmcd.dwDrawStage == CDDS_ITEMPREPAINT){
        *pResult = CDRF_NOTIFYSUBITEMDRAW;
		return;
	}

    if (lplvcd->nmcd.dwDrawStage == (CDDS_ITEMPREPAINT | CDDS_SUBITEM)) {	
			if(1 == lplvcd->iSubItem || 0 == lplvcd->iSubItem) {
				if(lplvcd->nmcd.dwItemSpec == indexMove 
					&& indexMove >= 0 
					&& indexMove < m_ListIndexCtrl.GetItemCount())
				{
					// Set color for index pickup follow move position
//					m_pDoc->m_IndexSelect = -1;
					lplvcd->clrTextBk = m_pDoc->m_PickColor;
					m_ListIndexCtrl.EnsureVisible(indexMove+1,FALSE);
				}
				else {
//					lplvcd->clrTextBk = CMV_DRAW_TEXT_BKG_CLR;
				}
			}
			else {
				lplvcd->clrTextBk = CMV_DRAW_TEXT_BKG_CLR;
			}
    }
	
	*pResult = CDRF_NEWFONT;
}


void CCMVDlg::OnClickChipList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CColorDialog myDLG;
	COLORREF	 newColor;
	char		 ch[8];

	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	m_pDoc->m_CatSelect = pNMListView->iItem;

	if (m_pDoc->m_CatSelect >= 0)
	{
		CString szText = m_ChipListCtrl.GetItemText(m_pDoc->m_CatSelect, 0);
		strcpy(ch, (LPCTSTR)(szText));

		if(myDLG.DoModal() == IDOK) {
			newColor = myDLG.GetColor();
			if(newColor != m_pDoc->m_gCategoryColor[(int)ch[0]])
			{
				m_pDoc->m_gCategoryColor[(int)ch[0]] = newColor;

				/* Put colors for each category to INI file(S) */
				m_pDoc->s1 = "G_CategoryColor";
				for( int i = 0 ; i < CHIP_TYPE_MAX ; i++){
					sprintf(m_pDoc->ch, "%03d", i);
					m_pDoc->s2 = m_pDoc->ch;
					m_pDoc->s3 = m_pDoc->s1 + m_pDoc->s2;

					int colorsSetting[3];
					colorsSetting[0] = GetRValue(m_pDoc->m_gCategoryColor[i]);
					colorsSetting[1] = GetGValue(m_pDoc->m_gCategoryColor[i]);
					colorsSetting[2] = GetBValue(m_pDoc->m_gCategoryColor[i]);
					WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, (LPCTSTR)m_pDoc->s3, colorsSetting);
				}
				/* Put colors for each category to INI file (E) */

			}
		}
		Invalidate();
		//m_MapLayout->UpdateWindow();
	}
	
	m_ListIndexCtrl.SetItemState(-1, ~LVIS_SELECTED, LVIS_SELECTED);

	*pResult = 0;
}

void CCMVDlg::OnSelchangeZoom() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		m_pDoc->m_nZoom = pCbb->GetCurSel();
		m_MapLayout->OnUpdateMapView();
	}
}

HBRUSH CCMVDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if(nCtlColor == CTLCOLOR_BTN){
		if(pWnd->m_hWnd == GetDlgItem(IDC_BTN_BG)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(m_pDoc->m_BackColor);
			DeleteObject(m_hBackClr);
			m_hBackClr = CreateSolidBrush(m_pDoc->m_BackColor);
			return m_hBackClr;

		} else if(pWnd->m_hWnd == GetDlgItem(IDC_BTN_POS)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(m_pDoc->m_PosColor);
			DeleteObject(m_hPosClr);
			m_hPosClr = CreateSolidBrush(m_pDoc->m_PosColor);
			return m_hPosClr;

		} else if(pWnd->m_hWnd == GetDlgItem(IDC_BTN_REF)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(m_pDoc->m_RefColor);
			DeleteObject(m_hRefClr);
			m_hRefClr = CreateSolidBrush(m_pDoc->m_RefColor);
			return m_hRefClr;

		} else if(pWnd->m_hWnd == GetDlgItem(IDC_BTN_PICK)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(m_pDoc->m_PickColor);
			DeleteObject(m_hPickClr);
			m_hPickClr = CreateSolidBrush(m_pDoc->m_PickColor);
			return m_hPickClr;

		}
	}
	return hbr;
}

void CCMVDlg::OnBtnPick() 
{
	// TODO: Add your control notification handler code here
	CColorDialog myDLG;
	COLORREF	 newColor;
	char		 ch[8];
	CString szText = '#';
	strcpy(ch, (LPCTSTR)(szText));
	
	if(myDLG.DoModal() == IDOK) {
		newColor = myDLG.GetColor();
		if(newColor != m_pDoc->m_PickColor) {
			m_pDoc->m_PickColor = newColor;

			int colorsSetting[3];
			colorsSetting[0] = GetRValue(m_pDoc->m_PickColor);
			colorsSetting[1] = GetGValue(m_pDoc->m_PickColor);
			colorsSetting[2] = GetBValue(m_pDoc->m_PickColor);
			WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("G_PickColor"), colorsSetting);
		}
	}
	Invalidate();
}

void CCMVDlg::OnBtnPos() 
{
	CColorDialog myDLG;
	COLORREF	 newColor;

	if(myDLG.DoModal() == IDOK) {
		newColor = myDLG.GetColor();
		if(newColor != m_pDoc->m_PosColor) {
			m_pDoc->m_PosColor = newColor;

			int colorsSetting[3];
			colorsSetting[0] = GetRValue(m_pDoc->m_PosColor);
			colorsSetting[1] = GetGValue(m_pDoc->m_PosColor);
			colorsSetting[2] = GetBValue(m_pDoc->m_PosColor);
			WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("G_CurColor"), colorsSetting);
		}
	}

	Invalidate();
}

void CCMVDlg::OnBtnRef() 
{
	CColorDialog myDLG;
	COLORREF	 newColor;

	if(myDLG.DoModal() == IDOK) {
		newColor = myDLG.GetColor();
		if(newColor != m_pDoc->m_RefColor) {
			m_pDoc->m_RefColor = newColor;

			int colorsSetting[3];
			colorsSetting[0] = GetRValue(m_pDoc->m_RefColor);
			colorsSetting[1] = GetGValue(m_pDoc->m_RefColor);
			colorsSetting[2] = GetBValue(m_pDoc->m_RefColor);
			WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("G_RefColor"), colorsSetting);
		}
	}

	Invalidate();
}

void CCMVDlg::OnBtnBg() 
{
	CColorDialog myDLG;
	COLORREF	 newColor;

	if(myDLG.DoModal() == IDOK) {
		newColor = myDLG.GetColor();
		if(newColor != m_pDoc->m_BackColor) {
			m_pDoc->m_BackColor = newColor;
			m_MapLayout->SetBackSolidBrush(m_pDoc->m_BackColor);

			int colorsSetting[3];
			colorsSetting[0] = GetRValue(m_pDoc->m_BackColor);
			colorsSetting[1] = GetGValue(m_pDoc->m_BackColor);
			colorsSetting[2] = GetBValue(m_pDoc->m_BackColor);
			WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("G_BackColor"), colorsSetting);
		}
	}

	Invalidate();
	m_MapLayout->UpdateWindow();
}


void CCMVDlg::OnBtnJump()
{
	CString tmpTextJumpX = m_pMapInfo->m_pGridCtrl->GetCellText(0, 18);
	CString tmpTextJumpY = m_pMapInfo->m_pGridCtrl->GetCellText(1, 18);

	int valueJumpX = atoi(tmpTextJumpX);
	int valueJumpY = atoi(tmpTextJumpY);

	if (m_pDoc->m_IsLoadedMap == TRUE) {
		if (valueJumpX < 1 || valueJumpX > m_pDoc->m_ColumnMax || valueJumpY < 1 || valueJumpY > m_pDoc->m_RowMax) {
			MessageBox(_T("The index value is not a valid !!!\n"), _T("Error"), MB_ICONERROR | MB_OK);
			return;
		}
		else {
			m_pDoc->m_JumpXEnter = valueJumpX;
			m_pDoc->m_JumpYEnter = valueJumpY;
		}

		m_pDoc->m_IsDispCurrentPos = FALSE;
		m_pDoc->m_IsDispRefPos = FALSE;
		m_pDoc->m_IsDispJumpInTab = TRUE;
		m_pDoc->m_IsDispJumpInMapViaClick = FALSE;
		m_pDoc->m_IsDispJumpInMapViaButton = TRUE;
		m_pDoc->m_IndexSelect = -1;
		m_MapLayout->ScrollToDisplayIndex();
		Invalidate();
		//AfxGetApp()->m_pMainWnd->Invalidate(TRUE);
		//UpdateWindow();
	}else{
		MessageBox(_T("Map file is not loaded !!!\n"), _T("Error"), MB_ICONERROR | MB_OK);
		m_pDoc->m_JumpXEnter = -1;
		m_pDoc->m_JumpYEnter = -1;
		m_pMapInfo->m_pGridCtrl->SetCellText(0, 18, _T(""));
		m_pMapInfo->m_pGridCtrl->SetCellText(1, 18, _T(""));
	}
}


BOOL CCMVDlg::PreTranslateMessage(MSG* pMsg) 
{
	if (pMsg->message == WM_KEYDOWN)
	{
		switch(pMsg->wParam)
		{
			case VK_UP:
				pMsg->wParam = VK_RETURN;
				::TranslateMessage(pMsg);
				::DispatchMessage(pMsg);
				break;
			case VK_DOWN:
				pMsg->wParam = VK_RETURN;
				::TranslateMessage(pMsg);
				::DispatchMessage(pMsg);
				break;
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}


void CCMVDlg::WriteFile(LPCTSTR filePath, LPCTSTR lpszSection, LPCTSTR lpszKey, int Data[])
{
	CString	strA,strB;
	int	numElements = 4;

	strA.Format(_T("%d"),numElements);
	
	for(int i=0;i<numElements;i++){
		strB.Format(_T(",%d"), Data[i]);
		strA += strB;
	}
	WritePrivateProfileString (lpszSection, lpszKey, strA, filePath);
}

bool CCMVDlg::WriteFile(LPCTSTR filePath, LPCTSTR lpszSection, LPCTSTR lpszKey, CString data)
{
	bool r = TRUE;
	WritePrivateProfileString (lpszSection, lpszKey, data, filePath);

	return r;
}

LRESULT CCMVDlg::OnMapCtrl(WPARAM wParam, LPARAM lParam)
{
	LRESULT r = 0;
	int ix, iy;
	switch (wParam) {
	case WMV_DISP:	// �\������
		switch (lParam) {
		case 0:	// ����
			SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_HIDEWINDOW);
			break;
		case 1:	// �\��
			SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
			break;
		case 2:
			break;
		}
		break;
	case WMV_PICK:
		{
			if (XYOK(lParam, ix, iy)) {
				// #DDT-TODO Update status of all ICs in group
				m_pDoc->SetPickStatus(ix-1, iy-1);

				indexMove = m_pDoc->LEDArrayInfo[m_pDoc->m_CurrentPosX][m_pDoc->m_CurrentPosY].index;

				TRACE("Pick point move: Index move: ix = %d, iy = %d\n", ix, iy);

				m_pDoc->m_IndexSelect = -1;
				m_pDoc->m_IsDispIndex = FALSE;
				m_pDoc->m_IsDispJumpInMapViaClick = FALSE;
				m_pDoc->m_IsDispJumpInMapViaButton = FALSE;
				m_pDoc->m_IsDispIndex = FALSE;
				//Invalidate(TRUE);
			}
		}
		break;
	case WMV_REFP:
		if (XYOK(lParam, ix, iy)) {
			m_pDoc->m_RefPosX =ix - 1;
			m_pDoc->m_RefPosY =iy - 1;
			
			TRACE("Reference point move: ix = %d, iy = %d\n", ix, iy);

			//Jump to new reference position
			m_MapLayout->JumpToPos(m_pDoc->m_RefPosX, m_pDoc->m_RefPosY, TRUE);

			m_pDoc->m_IndexSelect = -1;
			m_pDoc->m_IsDispRefPos = TRUE;
			m_pDoc->m_IsDispIndex = FALSE;
			m_pDoc->m_IsDispJumpInMapViaClick = FALSE;
			m_pDoc->m_IsDispJumpInMapViaButton = FALSE;
			m_pDoc->m_IsDispIndex = FALSE;
			Invalidate(TRUE);
		}
		break;
	case WMV_REFC:
//		RefC(lParam);
		Invalidate(false);
		break;
	case WMV_MOVE:
		if (XYOK(lParam, ix, iy)) {	
			m_pDoc->m_CurrentPosX =ix - 1;
			m_pDoc->m_CurrentPosY =iy - 1;
			TRACE("Current position move: ix = %d, iy = %d\n", ix, iy);

			if(m_pDoc->m_IndexSelect == -1) {
				m_ListIndexCtrl.EnsureVisible(indexMove+1,FALSE);
			}

			//Jump to new position
			m_MapLayout->JumpToPos(m_pDoc->m_CurrentPosX, m_pDoc->m_CurrentPosY, TRUE);

			m_pDoc->m_IndexSelect = -1;
			m_pDoc->m_IsDispCurrentPos = TRUE;
			m_pDoc->m_IsDispIndex = FALSE;
			m_pDoc->m_IsDispJumpInMapViaClick = FALSE;
			m_pDoc->m_IsDispJumpInMapViaButton = FALSE;
			m_pDoc->m_IsDispIndex = FALSE;
			Invalidate(TRUE);
		}
		break;
	case WMV_CARRIER:
		// Do nothing
		break;
	case WMV_FILE:
		switch (lParam) {
		case 1:
			{
				r = m_pDoc->RestoreMap();
				if (r) {
					OnUpdateMapView(0,0);
				}
			}
			break;
		case 2:
			{
				m_pDoc->DvDataRW(TRUE);
				m_pMapInfo->UpdateGridData();

				if(m_pDoc->m_IsLoadedMap == true) {
					m_ChipListCtrl.DeleteAllItems();
					m_ListIndexCtrl.DeleteAllItems();
					m_MapLayout->InitMapView();
					OnUpdateIndexPickupList();
					OnUpdateChipList();
					m_MapLayout->OnUpdateMapView();
				}
				AfxGetApp()->m_pMainWnd->Invalidate(TRUE);
				UpdateWindow();
			}
			break;
		default:
			break;
		}
// #DDT171006-01 Check condition of load map (S)
	case TFC_LOAD_OK:
		{
			SetEvent(m_LoadMapHandle[0]);	
		}
		break;
	case TFC_LOAD_NG:
		{
			SetEvent(m_LoadMapHandle[1]);
			switch(lParam) {
			case CMV_NG_AUTORUN:
				AfxMessageBox(NGAnswerAutoRun, MB_OK);
				break;
			case CMV_NG_STEPRUN:
				AfxMessageBox(NGAnswerStepRun, MB_OK);
				break;
			case CMV_NG_SCREEN:
				AfxMessageBox(NGAnswerScreen, MB_OK);
				break;
			case CMV_NG_VACUUM:
				AfxMessageBox(NGAnswerStgVacuum, MB_OK);
				break;
			case CMV_NG_CANNOTSET:
				AfxMessageBox(CannotLoadMap, MB_OK);
				break;
			case CMV_NG_NOUSEMAP:
				AfxMessageBox(NGAnswerNoUseMap, MB_OK);
				break;
			default:
				break;
			}
		}
		break;
// #DDT171006-01 Check condition of load map (E)
	default:
		break;
	}
	return r;
}

// #KS110723-01(S) �s�b�N�A�b�v�ς݋L������
// �������ʒu�ł���΁AXY�����ɕ�������
bool CCMVDlg::XYOK(const int idx, int &x, int &y)
{
	bool r = true;
	m_ColumnMax = m_pDoc->MapD.COLCT;
	m_RowMax  = m_pDoc->MapD.ROWCT;
	int iY = (int)((int)idx / (m_ColumnMax + 1));
	int iX = (int)idx - (iY * (m_ColumnMax + 1));
	if (0 < iY && iY <= m_RowMax && 0 < iX && iX <= m_ColumnMax) {
		x = iX;
		y = iY;
	} else {
		TRACE("XYOK: The index is not a valid: ix = %d, iy = %d\n", iX, iY);
		r = false;
	}
	return(r);
}
// Get min and max size of dialog
void CCMVDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	lpMMI->ptMinTrackSize.x = CMV_DLG_SIZEX;
	lpMMI->ptMinTrackSize.y = CMV_DLG_SIZEY;
}

void CCMVDlg::OnSize(UINT nType, int cx, int cy)
{
	if (!m_bInit) {
		return;
	}
	// Initialize a rect
	CRect rect;
	// Expand layout window
	m_MapLayout->GetWindowRect(rect);
	ScreenToClient(&rect);
	int oldWidth = rect.Width(); // store original width of layout window
	int oldHeight = rect.Height();
	CRect layoutRect(rect.TopLeft(), CSize(cx - MAGIN_RIGHT, cy - MAGIN_TOP_BOTTOM));
	m_MapLayout->MoveWindow(layoutRect);
/*	if (GetDlgItem(IDC_BTN_LOAD_MAP) != NULL) {
		GetDlgItem(IDC_BTN_LOAD_MAP)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_LOAD_MAP)->MoveWindow(rect,true);
	}*/
//	IDC_LIST_INDEX_PICKUP
	if (GetDlgItem(IDC_LIST_INDEX_PICKUP) != NULL) {
		GetDlgItem(IDC_LIST_INDEX_PICKUP)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		rect = CRect(rect.TopLeft(), CSize(rect.Width(), rect.Height() + layoutRect.Height() - oldHeight));
		GetDlgItem(IDC_LIST_INDEX_PICKUP)->MoveWindow(rect,true);
	}
//	IDC_STATIC
	if (GetDlgItem(IDC_STATIC) != NULL) {
		GetDlgItem(IDC_STATIC)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		rect = CRect(rect.TopLeft(), CSize(rect.Width(), rect.Height() + layoutRect.Height() - oldHeight));
		GetDlgItem(IDC_STATIC)->MoveWindow(rect,true);
	}
//IDC_CHIP_LIST
	if (GetDlgItem(IDC_CHIP_LIST) != NULL) {
		GetDlgItem(IDC_CHIP_LIST)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_CHIP_LIST)->MoveWindow(rect,true);
	}
//	IDC_BTN_PICK
	if (GetDlgItem(IDC_BTN_PICK) != NULL) {
		GetDlgItem(IDC_BTN_PICK)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_PICK)->MoveWindow(rect,true);
	}
//	IDC_BTN_REF
	if (GetDlgItem(IDC_BTN_REF) != NULL) {
		GetDlgItem(IDC_BTN_REF)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_REF)->MoveWindow(rect,true);
	}
//	IDC_BTN_POS
	if (GetDlgItem(IDC_BTN_POS) != NULL) {
		GetDlgItem(IDC_BTN_POS)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_POS)->MoveWindow(rect,true);
	}
//	IDC_BTN_BG
	if (GetDlgItem(IDC_BTN_BG) != NULL) {
		GetDlgItem(IDC_BTN_BG)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_BG)->MoveWindow(rect,true);
	}
//	IDC_STATIC_PICK
	if (GetDlgItem(IDC_STATIC_PICK) != NULL) {
		GetDlgItem(IDC_STATIC_PICK)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_PICK)->MoveWindow(rect,true);
	}
//	IDC_STATIC_BG
	if (GetDlgItem(IDC_STATIC_BG) != NULL) {
		GetDlgItem(IDC_STATIC_BG)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_BG)->MoveWindow(rect,true);
	}
//	IDC_STATIC_REF
	if (GetDlgItem(IDC_STATIC_REF) != NULL) {
		GetDlgItem(IDC_STATIC_REF)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_REF)->MoveWindow(rect,true);
	}
//	IDC_STATIC_POS
	if (GetDlgItem(IDC_STATIC_POS) != NULL) {
		GetDlgItem(IDC_STATIC_POS)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_POS)->MoveWindow(rect,true);
	}
//	IDC_STATIC_DIE
	if (GetDlgItem(IDC_STATIC_DIE) != NULL) {
		GetDlgItem(IDC_STATIC_DIE)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_DIE)->MoveWindow(rect,true);
	}

	//	IDC_STATIC_SETTING
	if (GetDlgItem(IDC_STATIC_SETTING) != NULL) {
		GetDlgItem(IDC_STATIC_SETTING)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_SETTING)->MoveWindow(rect,true);
	}
	//	IDC_STATIC_MAP_ZOOM
	if (GetDlgItem(IDC_STATIC_MAP_ZOOM) != NULL) {
		GetDlgItem(IDC_STATIC_MAP_ZOOM)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_MAP_ZOOM)->MoveWindow(rect,true);
	}
	//	IDC_ZOOM
	if (GetDlgItem(IDC_ZOOM) != NULL) {
		GetDlgItem(IDC_ZOOM)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_ZOOM)->MoveWindow(rect,true);
	}
	//	IDC_BTN_ZOOM_IN
	if (GetDlgItem(IDC_BTN_ZOOM_IN) != NULL) {
		GetDlgItem(IDC_BTN_ZOOM_IN)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_ZOOM_IN)->MoveWindow(rect,true);
	}
	//	IDC_BTN_ZOOM_OUT
	if (GetDlgItem(IDC_BTN_ZOOM_OUT) != NULL) {
		GetDlgItem(IDC_BTN_ZOOM_OUT)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_ZOOM_OUT)->MoveWindow(rect,true);
	}

//	m_pMapInfo
	if (m_pMapInfo) {
		m_pMapInfo->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(0,layoutRect.Height() - oldHeight);
		m_pMapInfo->MoveWindow(rect,true);
	}
//	IDC_BTN_JUMP
	if (GetDlgItem(IDC_BTN_JUMP) != NULL) {
		GetDlgItem(IDC_BTN_JUMP)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(0,layoutRect.Height() - oldHeight);
		GetDlgItem(IDC_BTN_JUMP)->MoveWindow(rect,true);
	}
	// Redraw
	CRect rc;
	m_MapLayout->GetWindowRect(rc);
	GetClientRect(&rc);	
	if (m_MapLayout->m_mapDispSize.cx <= rc.right) {
		m_MapLayout->m_mapDispSize.cx = rc.right;
	}

	if (m_MapLayout->m_mapDispSize.cy <= rc.bottom) {
		m_MapLayout->m_mapDispSize.cy = rc.bottom;
	}
// (E)

	if (m_ListIndexCtrl.GetSafeHwnd() && (m_pDoc->m_IndexSelect == -1)) {
	   m_ListIndexCtrl.EnsureVisible(indexMove+1,FALSE);
	}

	Invalidate();
	CDialog::OnSize(nType, cx, cy);
	
}
void CCMVDlg::OnCancel()
{
	if ((GetKeyState(0x1B) & 0x8000)) {	
		if(m_pDoc->m_IsLoadedMap == true) {
			for(int i = 0; i < m_pDoc->m_ColumnMax; i++) {
				delete[] m_pDoc->LEDArrayInfo[i];
			}
			delete[] m_pDoc->LEDArrayInfo;
			
			delete[] m_pDoc->xAxisRectArray;
			delete[] m_pDoc->yAxisRectArray;
		}
		//delete m_pDoc;	

		/* Put position window and color setting to INI file (S) */
		int *m_windowSizeTemp = new int[4];
		CRect rect;
		GetWindowRect(&rect);
		m_windowSize[0] = rect.left;
		m_windowSize[1] = rect.top;
		m_windowSize[2] = rect.right;
		m_windowSize[3] = rect.bottom;

		WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("Position_Window"), m_windowSize);

		int colorsSetting[3];
		colorsSetting[0] = GetRValue(m_pDoc->m_BackColor);
		colorsSetting[1] = GetGValue(m_pDoc->m_BackColor);
		colorsSetting[2] = GetBValue(m_pDoc->m_BackColor);
		WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("G_BackColor"), colorsSetting);
		colorsSetting[0] = GetRValue(m_pDoc->m_PosColor);
		colorsSetting[1] = GetGValue(m_pDoc->m_PosColor);
		colorsSetting[2] = GetBValue(m_pDoc->m_PosColor);
		WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("G_CurColor"), colorsSetting);
		colorsSetting[0] = GetRValue(m_pDoc->m_RefColor);
		colorsSetting[1] = GetGValue(m_pDoc->m_RefColor);
		colorsSetting[2] = GetBValue(m_pDoc->m_RefColor);
		WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("G_RefColor"), colorsSetting);
		colorsSetting[0] = GetRValue(m_pDoc->m_PickColor);
		colorsSetting[1] = GetGValue(m_pDoc->m_PickColor);
		colorsSetting[2] = GetBValue(m_pDoc->m_PickColor);
		WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("G_PickColor"), colorsSetting);

		delete m_windowSizeTemp;
		/* Put position window and color setting to INI file (E) */
	}
	CDialog::OnCancel();
}

void CCMVDlg::OnOK()
{
	// Do nothing
	return;
}
// #DDT171006-01 Check condition of load map (S)
LRESULT CCMVDlg::OnUpdateMapView(WPARAM wParam, LPARAM lParam)
{
	// clear all data and reset zoom
	m_pDoc->ClearData();
	m_ChipListCtrl.DeleteAllItems();
	m_ListIndexCtrl.DeleteAllItems();
	// reset zoom
	pCbb->SetCurSel(0);

	m_pDoc->m_IsLoadedMap = true;
	
	m_pDoc->m_ColumnMax = m_pDoc->MapD.COLCT;
	m_pDoc->m_RowMax  = m_pDoc->MapD.ROWCT;
	
	int idx = m_pDoc->MapD.FNLOC / 90;
	if (0 > idx || 3 < idx || !(m_pDoc->m_DispMode & m_pDoc->DispFNLOC )) {
		idx = 4;
	}
	char *dirs[][5] = {
		{ "�a", "�k", "�s", "�q", "  " },
		{ "��", "��", "��", "�E", "  " },
	};
	
	if (m_pDoc->m_DispMode & m_pDoc->DispMID) {
		m_pDoc->m_MID.Format(" MID=%s", m_pDoc->MapD.MID);
	} else {
		m_pDoc->m_MID = "";
	}
	
	/* Put mapfile to str variable (S) */
	for (int y = 0; y < m_pDoc->m_RowMax; y++) {
		m_pDoc->str += m_pDoc->MapD.BINLT.Mid(m_pDoc->m_ColumnMax * y, m_pDoc->m_ColumnMax) + "\n";
	}
	/* Put mapfile to str variable (E) */
	
	/* Initialize LEDArrayInfo (S) */
	m_pDoc->LEDArrayInfo = new LEDInfo* [m_pDoc->m_ColumnMax];
	for(int i = 0; i < m_pDoc->m_ColumnMax; i++) {
		m_pDoc->LEDArrayInfo[i] = new LEDInfo [m_pDoc->m_RowMax];
	}
	
	int temp = m_pDoc->m_RowMax * m_pDoc->m_ColumnMax;
	m_pDoc->m_pIndexFirstX = new int[temp];
	m_pDoc->m_pIndexFirstY = new int[temp];
	
	/* Create axisRects for display axis (S) */
	m_pDoc->xAxisRectArray = new CRect [m_pDoc->m_ColumnMax];
	m_pDoc->yAxisRectArray = new CRect [m_pDoc->m_RowMax];
	
	SetDlgItemText(IDC_EDIT_MAP_NAME, (m_pDoc->MapD.MID));
	SetDlgItemText(IDC_EDIT_MAP_BCEQU, (m_pDoc->MapD.BCEQU));
	
	/* Initialize map view */
	m_MapLayout->InitMapView();
	
	OnUpdateIndexPickupList();
	OnUpdateChipList();
	
	m_MapLayout->SetBackSolidBrush(m_pDoc->m_BackColor);
	return 0;
}
// #DDT171006-01 Check condition of load map (E)

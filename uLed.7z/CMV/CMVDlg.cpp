// CMVDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMVDlg.h"
#include "CMV_Util.h"
#include "CMV_DEF.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMVDlg dialog

IMPLEMENT_DYNAMIC(CCMVDlg, CDialog);

CCMVDlg::CCMVDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCMVDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCMVDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon			= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pDoc			= NULL;
}

CCMVDlg::~CCMVDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
}

void CCMVDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCMVDlg)
	DDX_Control(pDX, IDC_CHIP_LIST, m_ChipListCtrl);
	DDX_Control(pDX, IDC_LIST_INDEX_PICKUP, m_ListIndexCtrl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCMVDlg, CDialog)
	//{{AFX_MSG_MAP(CCMVDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTN_LOAD_MAP, OnBtnLoadMap)
	ON_BN_CLICKED(IDC_BTN_ZOOM_IN, OnBtnZoomIn)
	ON_BN_CLICKED(IDC_BTN_ZOOM_OUT, OnBtnZoomOut)
	ON_NOTIFY(NM_CLICK, IDC_LIST_INDEX_PICKUP, OnClickListIndexPickup)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_CHIP_LIST, OnChipListCustomDraw)
	ON_NOTIFY(NM_CLICK, IDC_CHIP_LIST, OnClickChipList)
	ON_CBN_SELCHANGE(IDC_ZOOM, OnSelchangeZoom)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMVDlg message handlers

BOOL CCMVDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_IsLoadedMap = false;

	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;

	m_pDoc = new CMV_Doc();
	// Create Map view layout
	CRect rect;
	GetDlgItem(IDC_MAP_DISP_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_MapLayout = new CMV_Map_View();
	m_MapLayout->SetDocument(m_pDoc);
	m_MapLayout->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_MAP_DISP_LAYOUT, pContext);


	// Create Tool/LED Info view layout
	GetDlgItem(IDC_TOOL_LED_INFO)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_pToolDisp = new CMV_ToolDispInfo();
	m_pToolDisp->SetDocument(m_pDoc);
	m_pToolDisp->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_TOOL_LED_INFO, pContext);


	// Create Map Jump view layout
	GetDlgItem(IDC_MAP_JUMP)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_pMapJump = new CMV_MapJump();
	m_pMapJump->SetDocument(m_pDoc);
	m_pMapJump->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_MAP_JUMP, pContext);
	

	delete pContext;

	/* Init map view */
	char buf[BUFSIZ];
	GetModuleFileName(NULL, buf, BUFSIZ - 1);	
	m_pDoc->m_IniFile = buf;
	CString AppName(AfxGetAppName());
	AppName += ".exe";
	m_pDoc->m_IniFile.Replace(AppName, "");
	m_pDoc->m_LoadFile = m_pDoc->m_IniFile + STR_MD_LOAD;
	m_pDoc->m_IniFile += STR_MV ".ini";
	
	m_pDoc->m_CurX = 0;		// Current position X
	m_pDoc->m_CurY = 0;		// Current position Y

	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "DispMode", TRUE, m_pDoc->m_DispMode, 0);
	m_pDoc->m_nFormat = DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX | DT_CENTER | DT_NOCLIP;

	m_pDoc->myFont.CreateFont(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));
	
	m_pDoc->m_Setting	= (_T("Setting"));
	m_pDoc->m_LoadFile	= (_T(""));
	m_pDoc->m_DispMode	= (0);
	m_pDoc->m_FNLOC		= (_T(""));
	m_pDoc->m_MID		= (_T(""));


	/* Init colors for each category (S) */
	m_pDoc->s1 = "G_CategoryColor";
	for( int i = 0 ; i < 256 ; i++){
		sprintf(m_pDoc->ch, "%03d", i);
		m_pDoc->s2 = m_pDoc->ch;
		m_pDoc->s3 = m_pDoc->s1 + m_pDoc->s2;
		GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, (LPCTSTR)m_pDoc->s3, TRUE, m_pDoc->colors, 3, 255);
		m_pDoc->m_gCategoryColor[i] = RGB(m_pDoc->colors[0], m_pDoc->colors[1], m_pDoc->colors[2]);
	}
	/* Init colors for each category (E) */

	/* Init variables */
	m_pDoc->m_IsLoadedMap = false;
	
	m_LoadMapBtn = (CButton*)GetDlgItem(IDC_BTN_LOAD_MAP);
	m_LoadMapBtn->EnableWindow(TRUE);
	

	/* Initialize Index pickup list (S) */
	// Initial extended style for the list control on this dialog
	DWORD dwStyle = m_ListIndexCtrl.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP;
	m_ListIndexCtrl.SetExtendedStyle(dwStyle);

	CRect rectIndexList;
	m_ListIndexCtrl.GetClientRect(rectIndexList);
	
	m_ListIndexCtrl.InsertColumn(0, _T("Step"), LVCFMT_LEFT, rectIndexList.Width()/3);
	m_ListIndexCtrl.InsertColumn(1, _T("Index"), LVCFMT_LEFT, rectIndexList.Width()/3*2);
	/* Initialize Index pickup list (E) */


	/* Initialize Chip list (S) */
	// Initial extended style for the list control on this dialog
	dwStyle = m_ChipListCtrl.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP;
	m_ChipListCtrl.SetExtendedStyle(dwStyle);

	CRect rectChipList;
	m_ChipListCtrl.GetClientRect(rectChipList);
	
	m_ChipListCtrl.InsertColumn(0, _T(" Cat "), LVCFMT_LEFT, rectChipList.Width()/3 - 5);
	m_ChipListCtrl.InsertColumn(1, _T(" "), LVCFMT_LEFT, rectChipList.Width()/3);
	m_ChipListCtrl.InsertColumn(2, _T("Dies # "), LVCFMT_LEFT, rectChipList.Width()/3+5);
	/* Initialize Chip list (E) */
	
	m_pDoc->m_IndexSelect = -1;
	m_pDoc->m_IsDipsIndex = FALSE;
	m_pDoc->m_IsDiplayJump = FALSE;

	/* Initialize CComboBox*/
	pZoom = ((CComboBox*)GetDlgItem(IDC_ZOOM));
	
	return TRUE;
}



void CCMVDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCMVDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// Center icon in client rectangle
	int cxIcon = GetSystemMetrics(SM_CXICON);
	int cyIcon = GetSystemMetrics(SM_CYICON);
	CRect rect;
	GetClientRect(&rect);
	int x = (rect.Width() - cxIcon + 1) / 2;
	int y = (rect.Height() - cyIcon + 1) / 2;
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCMVDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Automation servers should not exit when a user closes the UI
//  if a controller still holds on to one of its objects.  These
//  message handlers make sure that if the proxy is still in use,
//  then the UI is hidden but the dialog remains around if it
//  is dismissed.

void CCMVDlg::OnClose() 
{
	if(m_pDoc->m_IsLoadedMap == true) {
		for(int i = 0; i < m_pDoc->m_LineMax; i++) {
			delete[] m_pDoc->LEDArrayInfo[i];
		}
		delete[] m_pDoc->LEDArrayInfo;

		delete[] m_pDoc->xAxisRectArray;
		delete[] m_pDoc->yAxisRectArray;
	}

	delete m_pDoc;
	CDialog::OnClose();
}

void CCMVDlg::GetCMV(CCMVApp* pCMVInfo){
	pCMV = pCMVInfo;
}


void CCMVDlg::OnBtnLoadMap() 
{
	CFileDialog FileDialog(TRUE, "*.*", NULL, OFN_HIDEREADONLY, "");

	if(FileDialog.DoModal() == IDOK)
	{
		CString PathName = FileDialog.GetPathName();

		LoadMapFile(PathName);

		m_MapLayout->Invalidate();
	}
	
	m_pDoc->m_IsLoadedMap = true;
	m_LoadMapBtn->EnableWindow(FALSE);

	/* Add content for zoom combobox (S) */
	for(int idx = 1; idx < 7; idx ++){
		sizeArray[0] = 0;
		sizeArray[idx] = idx;
		CString str;
		str.Format(_T("      x%d"), sizeArray[idx]);
		pZoom->AddString(str);
	}

	// Initial zoom
	pZoom->SetCurSel(0);
	/* Add content for zoom combobox (E) */

	OnUpdateIndexPickupList();
	OnUpdateChipList();

	Invalidate();
	UpdateWindow();
}



void CCMVDlg::LoadMapFile(CString pathMapFile) {

	if (m_pDoc->MapD.DataRW(TRUE, pathMapFile)) {

		m_pDoc->m_CoulmMax = m_pDoc->MapD.COLCT;
		m_pDoc->m_LineMax  = m_pDoc->MapD.ROWCT;
		
		int idx = m_pDoc->MapD.FNLOC / 90;
		if (0 > idx || 3 < idx || !(m_pDoc->m_DispMode & m_pDoc->DispFNLOC )) {
			idx = 4;
		}
		char *dirs[][5] = {
			{ "�a", "�k", "�s", "�q", "  " },
			{ "��", "��", "��", "�E", "  " },
		};

		if (m_pDoc->m_DispMode & m_pDoc->DispMID) {
			m_pDoc->m_MID.Format(" MID=%s", m_pDoc->MapD.MID);
		} else {
			m_pDoc->m_MID = "";
		}

		/* Put mapfile to str variable (S) */
		for (int y = 0; y < m_pDoc->m_LineMax; y++) {
			m_pDoc->str += m_pDoc->MapD.BINLT.Mid(m_pDoc->m_CoulmMax * y, m_pDoc->m_CoulmMax) + "\n";
		}
		/* Put mapfile to str variable (E) */

		/* Initialize LEDArrayInfo (S) */
		m_pDoc->LEDArrayInfo = new LEDInfo* [m_pDoc->m_LineMax * sizeof(LEDInfo *)];
		for(int i = 0; i < m_pDoc->m_LineMax; i++) {
			m_pDoc->LEDArrayInfo[i] = new LEDInfo [m_pDoc->m_CoulmMax * sizeof(LEDInfo)];
		}

		/* Create axisRects for display axis (S) */
		m_pDoc->xAxisRectArray = new CRect [m_pDoc->m_CoulmMax * sizeof(CRect)];
		m_pDoc->yAxisRectArray = new CRect [m_pDoc->m_LineMax * sizeof(CRect)];

		/* Display information about MID, BCEQU */
		CEdit* edit1=(CEdit*)GetDlgItem(IDC_EDIT_MAP_NAME);
		edit1 ->SetWindowText((LPCTSTR)(m_pDoc->MapD.MID));

		edit1=(CEdit*)GetDlgItem(IDC_EDIT_MAP_BCEQU);
		edit1 ->SetWindowText((LPCTSTR)(m_pDoc->MapD.BCEQU));

		/* Initialize map view */
		m_MapLayout->InitMapView();
	}
}

void CCMVDlg::OnBtnZoomIn() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		if (m_pDoc->m_Zoom < 7) {
			m_pDoc->m_Zoom += 1;
			pZoom->SetCurSel(m_pDoc->m_Zoom - 1);
			m_MapLayout->OnUpdateMapView();
		}
	}
}

void CCMVDlg::OnBtnZoomOut() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		if (m_pDoc->m_Zoom > 1 ) {
			m_pDoc->m_Zoom -= 1;
			pZoom->SetCurSel(m_pDoc->m_Zoom - 1);
			m_MapLayout->OnUpdateMapView();
		}
	}
	
}


void CCMVDlg::AddIndexPickup(CListCtrl &ctrl, int row, int col, const char *str)
{
	 LVITEM lv;
    lv.iItem = row;
    lv.iSubItem = col;
    lv.pszText = (LPSTR) str;
    lv.mask = LVIF_TEXT;
    if(col == 0)
        ctrl.InsertItem(&lv);
    else
        ctrl.SetItem(&lv); 
}


void CCMVDlg::OnUpdateIndexPickupList()
{
	int i, j;
	int index = 1;

	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax- m_pDoc->m_ratioToolLEDX ; i++){
	    for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax-m_pDoc->m_ratioToolLEDY ; j++){
	
			// Find good bin in map
			if(m_pDoc->LEDArrayInfo[i][j].isGoodBin == true && m_pDoc->LEDArrayInfo[i][j].isInGroup == false) 
			{
				if( (m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j].isGoodBin == true) &&
					(m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j].isInGroup == false) &&
					(m_pDoc->LEDArrayInfo[i][j+m_pDoc->m_ratioToolLEDY].isGoodBin == true) &&
					(m_pDoc->LEDArrayInfo[i][j+m_pDoc->m_ratioToolLEDY].isInGroup == false) &&
					(m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j+m_pDoc->m_ratioToolLEDY].isGoodBin == true) &&
					(m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j+m_pDoc->m_ratioToolLEDY].isInGroup == false) )
					{
						m_pDoc->LEDArrayInfo[i][j].isInGroup = true;
						m_pDoc->LEDArrayInfo[i][j].index = index;
						
						m_pDoc->LEDArrayInfo[i][j+m_pDoc->m_ratioToolLEDY].isInGroup = true;
						m_pDoc->LEDArrayInfo[i][j+m_pDoc->m_ratioToolLEDY].index = index;
						
						m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j].isInGroup = true;
						m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j].index = index;
						
						m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j+m_pDoc->m_ratioToolLEDY].isInGroup = true;
						m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j+m_pDoc->m_ratioToolLEDY].index = index;
						
						
						/* Update index pickup list (S) */
						CString stepStr, indexStr, xCell, yCell;
						stepStr.Format(_T("   %d "), index);
						xCell.Format(_T("   %d"), j);
						yCell.Format(_T("%d  "), i);

						// Get coordinate of first LED in Index
						m_pDoc->m_indexFirstX[index] = j;
						m_pDoc->m_indexFirstY[index] = i;

						indexStr = xCell + _T(", ") + yCell;

						AddIndexPickup(m_ListIndexCtrl, index-1, 0, stepStr );
						AddIndexPickup(m_ListIndexCtrl, index-1, 1, indexStr);
						/* Update index pickup list (E) */

						index++;
					}
			}
		}
	}
}


void CCMVDlg::OnClickListIndexPickup(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	m_pDoc->m_IndexSelect = pNMListView->iItem + 1;
	m_pDoc->m_IsDipsIndex = true;
	
	*pResult = 0;
	Invalidate(TRUE);
	m_MapLayout->UpdateWindow();
}


void CCMVDlg::OnUpdateChipList()
{
	int i, j, ii, jj;
	int index = 0;

	/* Initialize ChipNum (S) */
	for(i = 0 ; i < m_pDoc->m_LineMax ; i++){
		for(j = 0 ; j < m_pDoc->m_CoulmMax ; j++){
			m_pDoc->ChipNum[i][j] = 0;
		}
	}
	/* Initialize ChipNum (E) */
	
	/* Count number of each LED.ch (S) */
	for(i = 0; i < m_pDoc->m_LineMax; i++){
		for(j = 0; j < m_pDoc->m_CoulmMax; j++){

			for (ii = 0; ii<=i; ii++) {
				for (jj = 0; jj<=j || (ii<i && jj<m_pDoc->m_CoulmMax); jj++) {
					if( (m_pDoc->LEDArrayInfo[i][j].ch == m_pDoc->LEDArrayInfo[ii][jj].ch) || (i == ii && j == jj) )
					{
						m_pDoc->ChipNum[ii][jj]++;
						ii = m_pDoc->m_LineMax;
						jj = m_pDoc->m_CoulmMax;
					}
				}
			}
		}
	}
	/* Count number of each LED.ch (E) */

	for(i = 0; i < m_pDoc->m_LineMax; i++){
	    for(j = 0; j < m_pDoc->m_CoulmMax; j++){
			if(m_pDoc->ChipNum[i][j] > 0) {
				/* Update chip list (S) */				
				CString catStr(m_pDoc->LEDArrayInfo[i][j].ch), diesStr;
				//catStr = _T(" ") + catStr + _T(" ");
				diesStr.Format(_T("   %d  "), m_pDoc->ChipNum[i][j]);
				
				AddIndexPickup(m_ChipListCtrl, index, 0, catStr );
				AddIndexPickup(m_ChipListCtrl, index, 2, diesStr);
				/* Update chip list (E) */
				index++;
			}
		}
	}
}

void CCMVDlg::OnChipListCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
    LPNMLVCUSTOMDRAW lplvcd;

    lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;
    if (lplvcd->nmcd.dwDrawStage == CDDS_PREPAINT){
        *pResult = CDRF_NOTIFYITEMDRAW;
		return;
	}

    if (lplvcd->nmcd.dwDrawStage == CDDS_ITEMPREPAINT){
        *pResult = CDRF_NOTIFYSUBITEMDRAW;
		return;
	}

    if (lplvcd->nmcd.dwDrawStage == (CDDS_ITEMPREPAINT | CDDS_SUBITEM)) {
		int		nCol = 0;
		char	ch[8];

		for (int i = 0; i < m_ChipListCtrl.GetItemCount(); i++) {
			CString szText = m_ChipListCtrl.GetItemText(i, nCol);
			strcpy(ch, (LPCTSTR)(szText));
			COLORREF color = m_pDoc->m_gCategoryColor[(int)ch[0]];

			if(1 == lplvcd->iSubItem) {
				if(lplvcd->nmcd.dwItemSpec == i) {
				   lplvcd->clrTextBk = color;
				}
			}
			else {
				lplvcd->clrTextBk = RGB(255,255,255);
			}
		}

		*pResult = CDRF_NEWFONT;
    }
}


void CCMVDlg::OnClickChipList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CColorDialog myDLG;
	COLORREF	 newColor;
	char		 ch[8];

	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	m_pDoc->m_CatSelect = pNMListView->iItem;

	if (m_pDoc->m_CatSelect >= 0)
	{
		CString szText = m_ChipListCtrl.GetItemText(m_pDoc->m_CatSelect, 0);
		strcpy(ch, (LPCTSTR)(szText));

		if(myDLG.DoModal() == IDOK) {
			newColor = myDLG.GetColor();
			if(newColor != m_pDoc->m_gCategoryColor[(int)ch[0]])
			{
				m_pDoc->m_gCategoryColor[(int)ch[0]] = newColor;
			}
		}
	}

	Invalidate();
	m_MapLayout->UpdateWindow();
	*pResult = 0;
}

void CCMVDlg::OnSelchangeZoom() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		m_pDoc->m_Zoom = pZoom->GetCurSel() + 1;
		m_MapLayout->OnUpdateMapView();
	}
}

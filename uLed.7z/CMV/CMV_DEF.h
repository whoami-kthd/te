#pragma once

#include "stdafx.h"
#include <vector>
#include "Pos.h"

using namespace std;

#define LED_MODE				1
#define INDEX_MODE				2

// Define PI constant
#define PI 3.141592653589793

#define ARRAY_LENGTH(_array)	(sizeof(_array)/sizeof(_array[0]))

#define DEG_TO_RAD(_deg)		(_deg * PI / 180)

#define RAD_TO_DEG(_rad)		(_rad * 180 / PI)

#define NUMBER_ZOOM_MAX			20
#define NUMBER_SHAPE_MAX		20

#define	TextVisibleHight		14
#define	TextVisibleWidth		9

#define CHIP_TYPE_MAX			256

#define TYOUSEI_TOP				28 /*�㑤�����l*/
#define TYOUSEI_LEFT			28 /*���������l*/

#define MARGIN_TO_DISPLAY		33

struct IndexModeStruct
{
	int xCoordirate;
	int yCoordirate;
};

enum {
	eDIR_RIGHT	= 0,
	eDIR_LEFT	= 1,
	eDIR_UP		= 2,
	eDIR_DOWN	= 3,
};

struct LEDInfo
{
	unsigned int	top;
	unsigned int	left;
	unsigned char	ch;
	bool			isGoodBin;
	bool			isInGroup;
	unsigned short  index;
	char		    pickStatus;
};

// #DDT170930
#define GLOBAL_NAME_MAPNAME_CARRIER		"Global\\MyCarrierMapName"
#define	MAPNAME_SIZE					100

#define NUMBER_ZOOM_MAX			20

#define TFC_FRAMENAME		_T("TFC")

#define	MAGNIFICATION_RATIO		40

#define MIN_DISP_SIZE_LESS_THAN_1000		15
#define MIN_DISP_SIZE_GREATER_THAN_1000		12

// #DDT171006-01 Check condition of load map (S)
enum {
	CMV_NG_AUTORUN = 0,
	CMV_NG_STEPRUN,
	CMV_NG_FRAME,
	CMV_NG_SCREEN,
	CMV_NG_VACUUM,
	CMV_NG_CANNOTSET,
	CMV_NG_NOUSEMAP,
};
// #DDT171006-01 Check condition of load map (E)
enum {
	NOT_PICKED	= 0x00,
	PICKED		= 0x01,
	PICKED_OK	= 0x02,
	PICKED_NG	= 0x04,
};

// CMV_Doc.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMV_Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc

IMPLEMENT_DYNCREATE(CMV_Doc, CDocument)

CMV_Doc::CMV_Doc()
{
}

BOOL CMV_Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}

CMV_Doc::~CMV_Doc()
{
}


BEGIN_MESSAGE_MAP(CMV_Doc, CDocument)
	//{{AFX_MSG_MAP(CMV_Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc diagnostics

#ifdef _DEBUG
void CMV_Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMV_Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc serialization

void CMV_Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc commands

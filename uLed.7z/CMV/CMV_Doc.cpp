// CMV_Doc.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMV_Doc.h"
#include "io.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc

IMPLEMENT_DYNCREATE(CMV_Doc, CDocument)

CMV_Doc::CMV_Doc()
{
	m_JumpX = -1;
	m_JumpY = -1;
	m_JumpXEnter = -1;
	m_JumpYEnter = -1;
	m_CatSelect = -1;
	m_pIndexFirstX = NULL;
	m_pIndexFirstY = NULL;
	xAxisRectArray = NULL;
	yAxisRectArray = NULL;
	LEDArrayInfo = NULL;
	m_IsLoadedMap = false;
	groupNo = -1;
}

BOOL CMV_Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}

CMV_Doc::~CMV_Doc()
{
	if (m_pIndexFirstX) {
		delete[] m_pIndexFirstX;
	}
	if (m_pIndexFirstY) {
		delete[] m_pIndexFirstY;
	}

	if (NULL != mySFont.GetSafeHandle()) 
		this->mySFont.DeleteObject();
	if (NULL != myLFont.GetSafeHandle()) 
		this->myLFont.DeleteObject();
}


BEGIN_MESSAGE_MAP(CMV_Doc, CDocument)
	//{{AFX_MSG_MAP(CMV_Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc diagnostics

#ifdef _DEBUG
void CMV_Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMV_Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc serialization

void CMV_Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


BOOL CMV_Doc::SettingDataRW(BOOL Read)
{
	BOOL r = TRUE;
	/* Display color of dies # (S) */
	int colorsSetting[3];
	r = GWPPfileData(this->m_IniFile, this->m_Setting, "G_BackColor", Read, colorsSetting, 3, 64);
	this->m_BackColor = RGB(colorsSetting[0], colorsSetting[1], colorsSetting[2]);
	r = GWPPfileData(this->m_IniFile, this->m_Setting, "G_RefColor", Read, colorsSetting, 3, 255) && r;
	this->m_RefColor = RGB(colorsSetting[0], colorsSetting[1], colorsSetting[2]);
	r = GWPPfileData(this->m_IniFile, this->m_Setting, "G_CurColor", Read, colorsSetting, 3, 255) && r;
	this->m_PosColor = RGB(colorsSetting[0], colorsSetting[1], colorsSetting[2]);
	r = GWPPfileData(this->m_IniFile, this->m_Setting, "G_PickColor", Read, colorsSetting, 3, 255) && r;
	this->m_PickColor = RGB(colorsSetting[0], colorsSetting[1], colorsSetting[2]);
	/* Display color of dies # (E) */

	/* Get position window */
	GWPPfileData(this->m_IniFile, this->m_Setting, "Position_Window", TRUE, m_windowSize, 4, 64);

	/* Initialize CComboBox*/
	m_numberOfZoom = 0;
	for (int i = 0; i < NUMBER_ZOOM_MAX; i++) {
		m_ZoomRatio[i] = 0;
	}
	
	// Array of zoom ratio
	GWPPfileData(m_IniFile, m_Setting, CMV_EDIT_ZOOMRATIO, TRUE, m_numberOfZoom, 1);					// read number of zoom ratio
	// Check number of zoom
	if (m_numberOfZoom <= 0 || m_numberOfZoom > NUMBER_ZOOM_MAX) {
		m_numberOfZoom = 1;
	} 
	GWPPfileData(m_IniFile, m_Setting, CMV_EDIT_ZOOMRATIO, TRUE, m_ZoomRatio, m_numberOfZoom, 1);		// read array of zoom ratio
	
	m_vZoom.clear();
	for(UINT idx = 0; idx < m_numberOfZoom; idx ++){
		m_vZoom.push_back(m_ZoomRatio[idx]);
	}
	// Data read write convert map.ini
	m_MapInfo.ConvertD.DataRW(TRUE, m_ConvertIniFile);

	return r;
}

BOOL CMV_Doc::DvDataRW(BOOL Read)
{
	BOOL r = TRUE;
	r = GWPPfileData(FCB_INIT_FILE_PATH, FCB_INI_SECTION, FCB_INI_DV_KEY, Read, this->m_dvPath, "");
	/* Read tool information (S) */
	R2Pos tmp;
	r = GWPPfileData(this->m_dvPath + "\\" + FCB_DV_FILE100, FCB_DV_TOOL_SECTION, "IC�i��(1) toolIndex", Read, tmp, R2Pos(1,1)) && r;
	this->m_ToolIndexX = tmp.X();
	this->m_ToolIndexY = tmp.Y();
	r = GWPPfileData(this->m_dvPath + "\\" + FCB_DV_FILE100, FCB_DV_TOOL_SECTION, "IC�i��(1) toolPitch", Read, tmp, R2Pos(1,1)) && r;
	this->m_ToolPitchX = tmp.X();
	this->m_ToolPitchY = tmp.Y();
	
	r = GWPPfileData(this->m_dvPath + "\\" + FCB_DV_FILE300, FCB_DV_LED_SECTION, "IC�i��(1) ���IC����", Read, tmp, R2Pos(1,1)) && r;
	this->m_LEDSizeX = tmp.X();
	this->m_LEDSizeY = tmp.Y();
	r = GWPPfileData(this->m_dvPath + "\\" + FCB_DV_FILE300, FCB_DV_LED_PITCH_SECTION, "IC�i��(1) ���IC�߯�", Read, tmp, R2Pos(1,1)) && r;
	this->m_LEDPitchX = tmp.X();
	this->m_LEDPitchY = tmp.Y();
	/* Read tool information (E) */
	return r;
}

void CMV_Doc::ClearData()
{
	if(this->m_IsLoadedMap == true){
		// Reset variable which contains string map
		this->str = "";

		// Reset all flag for draw
		this->m_IndexSelect = -1;
		this->m_IsDispIndex = FALSE;
		this->m_IsDispJumpInTab = FALSE;
		this->m_IsDispJumpInMapViaClick = FALSE;
		this->m_IsDispJumpInMapViaButton = FALSE;
		this->m_IsDispCurrentPos = FALSE;
		this->m_IsDispRefPos = FALSE;

		m_JumpX = -1;
		m_JumpY = -1;
		m_JumpXEnter = -1;
		m_JumpYEnter = -1;

		if (m_pIndexFirstX) {
			delete[] m_pIndexFirstX;
			m_pIndexFirstX = NULL;
		}
		if (m_pIndexFirstY) {
			delete[] m_pIndexFirstY;
			m_pIndexFirstY = NULL;
		}

		for(int i = 0; i < m_ColumnMax; i++) {
			if (LEDArrayInfo[i]) {
				delete[] LEDArrayInfo[i];
				LEDArrayInfo[i] = NULL;
			}
		}

		if (LEDArrayInfo) {
			delete[] LEDArrayInfo;
			LEDArrayInfo = NULL;
		}
		if (xAxisRectArray) {
			delete[] xAxisRectArray;
			xAxisRectArray = NULL;
		}
		if (yAxisRectArray) {
			delete[] yAxisRectArray;
			yAxisRectArray = NULL;
		}
	}

	this->m_IsLoadedMap = false;
}

BOOL CMV_Doc::LoadMap(CString barcode, int &error) 
{
	BOOL r = TRUE;

	DWORD dwExitCode = 0;
	STARTUPINFO si = { sizeof(STARTUPINFO) };
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;
	PROCESS_INFORMATION pi;
	
	CString m_pathFileBeforeConvert = m_MapInfo.ConvertD.InDir;    // _T("D:\\MapData\\WfMap_TSB\\");
	CString m_pathFileAfterConvert	= m_MapInfo.ConvertD.DestPath; //_T("D:\\MapData\\WfMap_SM\\");
	CString m_converterTool			= m_MapInfo.ConvertD.Converter;
	
	m_LoadFile = barcode;
	m_FullPathFileBefore = m_pathFileBeforeConvert + m_LoadFile;
	m_FullPathFileAfter  = m_pathFileAfterConvert + m_LoadFile;
	
	// Check file exist in des before convert
	if (0 != _access(m_FullPathFileAfter, 0)) {
		m_MapInfo.ConvertD.MapFile = m_LoadFile;
		//	m_MapInfo.ConvertD.DataRW(TRUE, m_ConvertIniFile);
//		WritePrivateProfileString(_T(m_ConvertIniFile), _T("Converter"), _T("MapFile"), m_LoadFile);
//		WritePrivateProfileString(_T(m_IniFile), FCB_PATH_CMV_MAP_SECTION, _T("MapFile"), m_LoadFile);
		
		/* Check file name is existed or not*/
		// convert map file
		CString command = m_converterTool + " " + m_pathFileBeforeConvert + " " + m_pathFileAfterConvert + " ";
		command += m_LoadFile + " 1";
		char *cmdLine	= command.GetBuffer(100);
		
		r = CreateProcess(
			NULL,// pointer to name of executable module
			cmdLine,			// pointer to command line string
			NULL,				// pointer to process security attributes
			NULL,				// pointer to thread security attributes
			FALSE,				// handle inheritance flag
			CREATE_NEW_CONSOLE,	// creation flags
			NULL,				// pointer to new environment block
			NULL,				// pointer to current directory name
			&si,				// pointer to STARTUPINFO
			&pi					// pointer to PROCESS_INFORMATION
			);
		
		Sleep(200);
		command.ReleaseBuffer();
		
		if (!r) {
			error = CONVER_ERR_RUNCNV;
		} else if (!GetExitCodeProcess(pi.hProcess, &dwExitCode)) {
			// Cannot get status of process
			error = CONVER_ERR_CNVERR;
			r = FALSE;
		} else if (STILL_ACTIVE == dwExitCode) {
			// Process is executing
			DWORD dwRet = ::WaitForSingleObject(pi.hProcess, m_MapInfo.ConvertD.TimeOut);
			if (WAIT_OBJECT_0 == dwRet) { // Process is finished
				if (!GetExitCodeProcess(pi.hProcess, &dwExitCode)) {
					// Cannot get status of process
					error = CONVER_ERR_CNVERR;
					r = FALSE;
				} else if (dwExitCode >= 1) {
					// Have error when convert
					error = dwExitCode;
					r = FALSE;
				}
			} else if (WAIT_TIMEOUT == dwRet) {
				// Timeout error
				error = CONVER_ERR_TIMEOUT;
				r = FALSE;
			}
		} else if (dwExitCode >= 1) {
			// return error code
			error = dwExitCode;
			r = FALSE;
		}
	}

	if (r) {
		// Do not need convert map
		r = MapD.DataRW(TRUE, _T(m_FullPathFileAfter)) ;
	}
		
	return r;
}

// #DDT171007-01 Update data from TFC (S)
BOOL CMV_Doc::RestoreMap()
{
	BOOL r = MapD.DataRW(TRUE, _T(m_datFile));

	return r;
}

void CMV_Doc::SetPickStatus(int idx, int idy)
{
	if (LEDArrayInfo[idx][idy].isInGroup) {
		groupNo = LEDArrayInfo[idx][idy].index;

		for (int j = 0; j < m_ToolIndexY; j++) {
			for (int i = 0; i < m_ToolIndexX; i++) {
				int x =idx + i * m_ratioToolLEDX;
				int y =idy + j * m_ratioToolLEDY;
				if (( x < m_ColumnMax) && (y < m_RowMax)) {
					if (LEDArrayInfo[x][y].index == groupNo) {
						LEDArrayInfo[x][y].pickStatus = PICKED;
						LEDArrayInfo[x][y].ch = 46; // "."
					}
				} else {
					TRACE("PickStatus(%d,%d) InValid: x=%d,y=%d\n", idx, idy, x, y);
				}
			}
		}
	}
	m_IndexSelect = -1;
	m_IsDispIndex = FALSE;
	m_IsDispJumpInMapViaClick = FALSE;
	m_IsDispJumpInMapViaButton = FALSE;
	m_IsDispIndex = FALSE;

	AfxGetApp()->m_pMainWnd->Invalidate(TRUE);
}
// #DDT171007-01 Update data from TFC (E)
/////////////////////////////////////////////////////////////////////////////
// CMV_Doc commands


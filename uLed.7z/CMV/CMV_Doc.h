#if !defined(AFX_CMV_DOC_H__8BF545BE_FF03_44E7_ABC3_CFBAE725A5F4__INCLUDED_)
#define AFX_CMV_DOC_H__8BF545BE_FF03_44E7_ABC3_CFBAE725A5F4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_Doc.h : header file
//

#include "CMV_DEF.h"
#include "GWPP.h"
#include "CMVif.h"

// Message
#define WM_UPDATE_VIEW				(WM_APP + 4000)
#define WM_UPDATE_ZOOM				(WM_UPDATE_VIEW + 1)
#define WM_UPDATE_SELECTED			(WM_UPDATE_VIEW + 2)
#define WM_UPDATE_KEY				(WM_UPDATE_VIEW + 3)
#define WM_UPDATE_FULLKEY			(WM_UPDATE_VIEW + 4)
#define WM_UPDATE_REGNO				(WM_UPDATE_VIEW + 5)
#define WM_FINISH_CHECK				(WM_UPDATE_VIEW + 6)
#define WM_UPDATE_CELL				(WM_UPDATE_VIEW + 7)
#define WM_STOP_SAVE				(WM_UPDATE_VIEW + 8)
#define WM_UPDATE_REVWND			(WM_UPDATE_VIEW + 9)
#define WM_UPDATE_MAP				(WM_UPDATE_VIEW + 10)
#define WM_INDEX_MAX				2048

enum {
	CONVER_ERR_NOERROR	 = 0,	// No error
	CONVER_ERR_RUNCNV		,	// Cannot execute
	CONVER_ERR_CNVERR		,	// Cannot convert
	CONVER_ERR_TIMEOUT		,	// Timeout
};

// Define error code which get from convert tool (S)
enum {
	ERR_DST_DIR		=	8,
	ERR_NoMap		=	26,
	ERR_DataLeght	=	27,
};
// Define error code which get from convert tool (E)

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc document

class CMV_Doc : public CDocument
{
public:
	CMV_Doc();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMV_Doc)

// Attributes
public:
	int			m_JumpX;
	int			m_JumpY;
	int			m_JumpXEnter;
	int			m_JumpYEnter;

	int*		m_pIndexFirstX;
	int*		m_pIndexFirstY;

// #DDT171007-01 Update data from TFC (S)
	CString m_rootPath;
	CString m_datFile;
// #DDT171007-01 Update data from TFC (E)
	CString m_ConvertIniFile;
	CString m_IniFile;
	CString m_Setting;
	CString m_LoadFile;
	CString m_FullPathFileBefore;
	CString m_FullPathFileAfter;
	CString m_dvPath;
	
	CString m_FNLOC;	// �t���b�g�m�b�`
	CString m_MID;		// �ޗ�ID
	
	int m_DispMode;		// �\���@�E

	
	enum {
		DispFNLOC	= 0x0001,
		DispMID		= 0x0002,
	};


	MapData		MapD;
// #DDT171006-01 Check condition of load map (S)
	MapInfo		m_MapInfo;
// #DDT171006-01 Check condition of load map (E)

	int colors[3]; 
	int m_gCategoryColor[256];	// �J�e�S���w�i�F

	/* Save item rects for call when need */
	LEDInfo **LEDArrayInfo;
	CRect *xAxisRectArray;
	CRect *yAxisRectArray;

	/* Tool information for display map */
	int		m_dispToolIndexX;
	int		m_dispToolIndexY;
	double	m_dispToolPitchX;
	double	m_dispToolPitchY;

	double	m_dispLEDPitchX;
	double	m_dispLEDPitchY;
	double	m_dispLEDSizeX;
	double	m_dispLEDSizeY;

	/* Origin tool information */
	int		m_ToolIndexX;
	int		m_ToolIndexY;
	double	m_ToolPitchX;
	double	m_ToolPitchY;

	double	m_LEDPitchX;
	double	m_LEDPitchY;
	double	m_LEDSizeX;
	double	m_LEDSizeY;

	int m_ratioToolLEDX;
	int m_ratioToolLEDY;

	UINT m_nFormat;

	CFont mySFont;
	CFont myLFont;
	CString str;
	
	int ChipNum[CHIP_TYPE_MAX];

	CString s1,s2,s3;
	char	ch[8];

	// Map size: x1, x2, x3, x4, x5, x6
	double	MapSize;

	vector<int> m_vZoom;
	int m_nZoom;
	int m_numberOfZoom;
	int m_ZoomRatio[NUMBER_ZOOM_MAX];
	
	// Minimum size of LED
	double m_MiniSizeX;
	double m_MiniSizeY;

	// Minimum pitch of LEDs
	double m_MiniPitchLEDX;
	double m_MiniPitchLEDY;

	// Minimum pitch of Tool
	double m_MiniPitchToolX;
	double m_MiniPitchToolY;

	// ���݂̍ő�`�b�v��
	int m_ColumnMax;				// �\���ő啝    X
	int m_RowMax;				// �\���ő卂��  Y

	bool m_IsLoadedMap;
	bool m_IsDispJumpInMapViaClick;
	bool m_IsDispJumpInMapViaButton;
	bool m_IsDispJumpInTab;
	bool m_IsDispIndex;
	int  m_IndexSelect;

	int  m_RefPosX;
	int  m_RefPosY;
	bool m_IsDispRefPos;

	int	 m_CatSelect;
	int  m_CurrentPosX;
	int  m_CurrentPosY;
	bool m_IsDispCurrentPos;

	COLORREF m_BackColor;
	COLORREF m_PosColor;
	COLORREF m_RefColor;
	COLORREF m_PickColor;

	int		 m_windowSize[4];	// Position of window

	// For draw LED status after pickup
	int		m_firstIndexX;
	int		m_firstIndexY;

	int		groupNo;

// Operations
public:
	BOOL	SettingDataRW(BOOL Read);
	BOOL	DvDataRW(BOOL Read);
// Convert and load map
	BOOL	LoadMap(CString barcode, int &error);
// Restore map (from WaferMap.dat)
	BOOL	RestoreMap();
// Set picked status
	void	SetPickStatus(int idx, int idy);
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_Doc)
	public:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
	protected:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMV_Doc();
	void	ClearData();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CMV_Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_DOC_H__8BF545BE_FF03_44E7_ABC3_CFBAE725A5F4__INCLUDED_)

#if !defined(AFX_CMV_DOC_H__8BF545BE_FF03_44E7_ABC3_CFBAE725A5F4__INCLUDED_)
#define AFX_CMV_DOC_H__8BF545BE_FF03_44E7_ABC3_CFBAE725A5F4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_Doc.h : header file
//

#include "CMV_DEF.h"
#include "GWPP.h"
#include "CMVif.h"

/////////////////////////////////////////////////////////////////////////////
// CMV_Doc document

class CMV_Doc : public CDocument
{
public:
	CMV_Doc();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMV_Doc)

// Attributes
public:

	CSize		m_sizebmp;
	int			m_imgCount;
	double		m_Scale;
	int			m_JumpX;
	int			m_JumpY;
	boolean		m_IsDiplayJump;

	int			m_indexFirstX[255];
	int			m_indexFirstY[255];


public:
	CString m_IniFile;
	CString m_Setting;
	CString m_LoadFile;
	CString m_FNLOC;	// �t���b�g�m�b�`
	CString m_MID;		// �ޗ�ID
	
	int m_DispMode;		// �\���@�

	
	enum {
		DispFNLOC	= 0x0001,
		DispMID		= 0x0002,
	};


	MapData MapD;

	int colors[3]; 
	int m_gCategoryColor[256];	// �J�e�S���w�i�F

	/* Save item rects for call when need */
	LEDInfo **LEDArrayInfo;
	CRect *xAxisRectArray;
	CRect *yAxisRectArray;

	int m_toolSizeX;
	int m_toolSizeY;
	double m_toolPitchX;
	double m_toolPitchY;

	int m_ratioToolLEDX;
	int m_ratioToolLEDY;

	UINT m_nFormat;

	CFont myFont;
	CString str;
	
	int ChipNum[256][256];

	CString s1,s2,s3;
	char	ch[8];

	// Map size: x1, x2, x3, x4, x5, x6
	double	MapSize;
	double m_Zoom;
	
	// Minimum size of LED
	double m_MiniSizeX;
	double m_MiniSizeY;

	// Minimum pitch of LEDs
	double m_MiniPitchLEDX;
	double m_MiniPitchLEDY;

	// Minimum pitch of Tool
	double m_MiniPitchToolX;
	double m_MiniPitchToolY;

	// Pitch of LED
	double m_LEDPitchX;
	double m_LEDPitchY;

	// Current LED size
	double m_SizeX;
	double m_SizeY;

	// ���݂̍ő�`�b�v��
	int m_CoulmMax;				// �\���ő啝    X
	int m_LineMax;				// �\���ő卂��  Y

	// ���݈ʒu�f�[�^
	int m_CurX;					// ���݈ʒu(x)
	int m_CurY;					// ���݈ʒu(Y)

	bool m_IsLoadedMap;
	
	bool m_IsDipsIndex;
	int  m_IndexSelect;

	int	 m_CatSelect;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_Doc)
	public:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
	protected:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMV_Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CMV_Doc)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_DOC_H__8BF545BE_FF03_44E7_ABC3_CFBAE725A5F4__INCLUDED_)

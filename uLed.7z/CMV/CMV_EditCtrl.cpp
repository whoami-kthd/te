// CMV_EditCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "cmv.h"
#include "CMV_Doc.h"
#include "CMV_EditCtrl.h"

/////////////////////////////////////////////////////////////////////////////
////Define text  for Japanese and english
CString CutEdit[] =	{
						_T("�J�b�g(&T)"),
						_T("Cut(&T)"),
					};

CString CopyEdit[] ={
						_T("�R�s�[(&C)"),
						_T("Copy(&C)"),
					};
CString PasteEdit[]={
						_T("�\��t����(&P)"),
						_T("Paste(&P)"),
					};
CString DeleteEdit[]={
						_T("�폜����(&D)"),
						_T("Delete(&D)"),
					};

/////////////////////////////////////////////////////////////////////////////
// CMV_EditCtrl dialog


CMV_EditCtrl::CMV_EditCtrl(CWnd* pParent /*=NULL*/)
	: CDialog(CMV_EditCtrl::IDD, pParent)
{
}

CMV_EditCtrl::~CMV_EditCtrl()
{
	DestroyWindow();
}

void CMV_EditCtrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_BOX, m_Edit);
}


BEGIN_MESSAGE_MAP(CMV_EditCtrl, CDialog)
	ON_WM_SIZE()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_EditCtrl message handlers

void CMV_EditCtrl::OnCancel()
{
	// do nothing
	TRACE("CMV_EditCtrl Cancel\n");
}

void CMV_EditCtrl::OnOK()
{
	// do nothing
	if (m_Edit.GetMode() == 0) {
		m_Edit.OnKey(IDC_NKEY_ENT, 0);
	} else {
		m_Edit.OnFullKey(IDC_FKEY_ENTER, 0);
	}
}

void CMV_EditCtrl::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);
	if(IsWindow(m_Edit.m_hWnd)){
		m_Edit.MoveWindow(0, 0, cx, cy);
	}
}

BOOL CMV_EditCtrl::OnInitDialog()
{
	CDialog::OnInitDialog();
	return TRUE;
}

void CMV_EditCtrl::SetText(CString text)
{
	m_Edit.SetWindowText(text);
}

void CMV_EditCtrl::SetEditFont(int fontSize, CString fontName)
{
	m_Edit.SetEditFont(fontSize, fontName);
}

CString CMV_EditCtrl::GetText()
{
	CString text;
	m_Edit.GetWindowText(text);
	return text;
}

CWnd* CMV_EditCtrl::GetEditWnd()
{
	return &m_Edit;
}

void CMV_EditCtrl::SetRevWnd(CWnd* pRevWnd)
{
	m_Edit.SetRevWnd(pRevWnd);
}

void CMV_EditCtrl::SetSel(int start, int end)
{
	m_Edit.SetSel(start, end);
}

// Set integer mode (full key only)
void CMV_EditCtrl::SetIntegerMode(bool isInteger)
{
	m_Edit.SetIntegerMode(isInteger);
}

// Set integer mode (full key only)
void CMV_EditCtrl::SetMode(int mode)
{
	m_Edit.SetMode(mode);
}

// Set language
void CMV_EditCtrl::SetLanguage(int language)
{
	m_Edit.SetLanguage(language);
}

/////////////////////////////////////////////////////////////////////////////
// CMV_EditBox

CMV_EditBox::CMV_EditBox()
{
	m_pRevWnd = NULL;
	m_StartSel = 0;
	m_EndSel = 0;
	m_Mode = 0;
	m_IsInteger = true;
	m_Language = 0;
}

CMV_EditBox::~CMV_EditBox()
{
}


BEGIN_MESSAGE_MAP(CMV_EditBox, CEdit)
	//ON_WM_KEYUP()
	//ON_WM_KEYDOWN()
	ON_WM_CHAR()
	ON_WM_CONTEXTMENU()
	ON_WM_KILLFOCUS()
	ON_MESSAGE(WM_LBUTTONDBLCLK, OnLButtonDblClk)
	ON_MESSAGE(WM_UPDATE_KEY, OnKey)
	ON_MESSAGE(WM_UPDATE_FULLKEY, OnFullKey)
	ON_COMMAND(ID_EDIT_CUT, CEdit::Cut)
	ON_COMMAND(ID_EDIT_COPY, CEdit::Copy)
	ON_COMMAND(ID_EDIT_PASTE, CEdit::Paste)
	ON_COMMAND(ID_EDIT_CLEAR, CEdit::Clear)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_EditBox message handlers

void CMV_EditBox::CreateEditBox(CWnd* pParent, CRect rect, CString text)
{
	CEdit::Create(WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_LEFT | WS_BORDER, rect, pParent, NULL);
	// Set text
	SetWindowText(text);
	SetSel(0, 0);
}

void CMV_EditBox::SetEditFont(int fontSize, CString fontName)
{
	m_font.CreatePointFont(fontSize, fontName);
	SetFont(&m_font, FALSE);
}

void CMV_EditBox::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// Select all text
	SetSel(0, -1);
}

void CMV_EditBox::OnKillFocus(CWnd* pNewWnd)
{
	if(pNewWnd == NULL) return;
	/*POINT lppMouse;
	GetCursorPos(&lppMouse);
	CRect lprEdit;
	GetWindowRect(&lprEdit);

	if(lprEdit.PtInRect(lppMouse)){
		SetFocus();
	}else*/{
		// Store the current select
		GetSel(m_StartSel, m_EndSel);
		// Kill focus
		CEdit::OnKillFocus(pNewWnd);
		GetParent()->ShowWindow(SW_HIDE);
	}
}

/*void CMV_EditBox::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// do nothing
	CEdit::OnKeyUp(nChar, nRepCnt, nFlags);
}

void CMV_EditBox::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// do nothing
}*/

void CMV_EditBox::OnContextMenu(CWnd* pWnd, CPoint point)
{
	SetFocus();
    CMenu menuContext;
//	menuContext.LoadMenu(IDR_EDIT_MENU);

	// Change menu language
	menuContext.ModifyMenu(ID_EDIT_CUT, MF_BYCOMMAND | MF_STRING, ID_EDIT_CUT, CutEdit[m_Language]);
	menuContext.ModifyMenu(ID_EDIT_COPY, MF_BYCOMMAND | MF_STRING, ID_EDIT_COPY, CopyEdit[m_Language]);
	menuContext.ModifyMenu(ID_EDIT_PASTE, MF_BYCOMMAND | MF_STRING, ID_EDIT_PASTE, PasteEdit[m_Language]);
	menuContext.ModifyMenu(ID_EDIT_CLEAR, MF_BYCOMMAND | MF_STRING, ID_EDIT_CLEAR, DeleteEdit[m_Language]);

	// Check disable/enable Copy menu item
	DWORD sel = GetSel();
	DWORD flags = (LOWORD(sel) == HIWORD(sel)) ? MF_GRAYED : MF_ENABLED;
	menuContext.EnableMenuItem(ID_EDIT_COPY, flags);
	// Check disable/enable Cut menu item
	BOOL bReadOnly = GetStyle() & ES_READONLY;
	flags = ((flags == MF_GRAYED) || bReadOnly) ? MF_GRAYED : MF_ENABLED;
	menuContext.EnableMenuItem(ID_EDIT_CUT, flags);
	// Check disable/enable Delete menu item
	menuContext.EnableMenuItem(ID_EDIT_CLEAR, flags);
	// Show popup menu
	CMenu *pPopupMenu = menuContext.GetSubMenu(0);
    pPopupMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON, point.x, point.y, this);
}


void CMV_EditBox::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if (m_IsInteger) {
		if ((nChar >= 'a' && nChar <= 'z') || (nChar >= 'A' && nChar <= 'Z')) {
			return;
		} 
	}
	CEdit::OnChar(nChar, nRepCnt, nFlags);
}


LRESULT CMV_EditBox::OnKey(WPARAM wParam, LPARAM lParam)
{
	if(wParam == IDC_NKEY_ENT){
		// Post message to the parent window
		::PostMessage(m_pRevWnd->m_hWnd, WM_UPDATE_CELL, 0, 0);
		return 0;
	}

	CString text;
	GetWindowText(text);

	CString text1 = (text != _T("")) ? text.Mid(0, m_StartSel) : _T("");
	CString text2 = _T("");
	CString text3 = (text != _T("")) ? text.Mid(m_EndSel, text.GetLength() - 1) : _T("");

	switch(wParam){
	case IDC_NKEY_0:
	case IDC_NKEY_1:
	case IDC_NKEY_2:
	case IDC_NKEY_3:
	case IDC_NKEY_4:
	case IDC_NKEY_5:
	case IDC_NKEY_6:
	case IDC_NKEY_7:
	case IDC_NKEY_8:
	case IDC_NKEY_9:
		text2.Format(_T("%d"), wParam - IDC_NKEY_0);
		m_StartSel ++;
		break;
	case IDC_NKEY_DEL:
		if((m_StartSel == m_EndSel) && (m_StartSel > 0)){
			text1 = (text1 != _T("")) ? text1.Mid(0, text1.GetLength() - 1) : _T("");
			m_StartSel --;
		}
		break;
	case IDC_NKEY_DOT:
		text2 = _T(".");
		m_StartSel ++;
		break;
	case IDC_NKEY_CLR:
		text1 = _T("");
		text2 = _T("");
		text3 = _T("");
		m_StartSel = 0;
		break;
	case IDC_NKEY_MINUS:
		text2 = _T("-");
		m_StartSel ++;
		break;
	default:
		break;
	}

	SetWindowText(text1 + text2 + text3);
	GetParent()->ShowWindow(SW_SHOW);
	//if(m_StartSel < 0){
		//m_StartSel = 0;
	//}
	SetSel(m_StartSel, m_StartSel);

	return 0;
}

LRESULT CMV_EditBox::OnFullKey(WPARAM wParam, LPARAM lParam)
{
	if(wParam == IDC_FKEY_ENTER){
		// Post message to the parent window
		::PostMessage(m_pRevWnd->m_hWnd, WM_UPDATE_CELL, 0, 0);
		return 0;
	}

	CString text;
	GetWindowText(text);

	CString text1 = (text != _T("")) ? text.Mid(0, m_StartSel) : _T("");
	CString text2 = _T("");
	CString text3 = (text != _T("")) ? text.Mid(m_EndSel, text.GetLength()) : _T("");

	switch(wParam) {
		case IDC_FKEY_0:
		case IDC_FKEY_1:
		case IDC_FKEY_2:
		case IDC_FKEY_3:
		case IDC_FKEY_4:
		case IDC_FKEY_5:
		case IDC_FKEY_6:
		case IDC_FKEY_7:
		case IDC_FKEY_8:
		case IDC_FKEY_9:
			text2.Format(_T("%d"), wParam - IDC_FKEY_0);
			m_StartSel++;
			break;
		case IDC_FKEY_A:
		case IDC_FKEY_B:
		case IDC_FKEY_C:
		case IDC_FKEY_D:
		case IDC_FKEY_E:
		case IDC_FKEY_F:
		case IDC_FKEY_G:
		case IDC_FKEY_H:
		case IDC_FKEY_I:
		case IDC_FKEY_J:
		case IDC_FKEY_K:
		case IDC_FKEY_L:
		case IDC_FKEY_M:
		case IDC_FKEY_N:
		case IDC_FKEY_O:
		case IDC_FKEY_P:
		case IDC_FKEY_Q:
		case IDC_FKEY_R:
		case IDC_FKEY_S:
		case IDC_FKEY_T:
		case IDC_FKEY_U:
		case IDC_FKEY_V:
		case IDC_FKEY_W:
		case IDC_FKEY_X:
		case IDC_FKEY_Y:
		case IDC_FKEY_Z:
			if (!m_IsInteger) {
				text2.Format(_T("%c"), wParam - IDC_FKEY_A + 65);
				m_StartSel++;
			}
			break;
		case IDC_FKEY_LEFTBRACKET:
			if (!m_IsInteger) {
				text2 = _T("[");
				m_StartSel++;
			}
			break;
		case IDC_FKEY_RIGHTBRACKET:
			if (!m_IsInteger) {
				text2 = _T("]");
				m_StartSel++;
			}
			break;
		case IDC_FKEY_UNDERLINE:
			if (!m_IsInteger) {
				text2 = _T("_");
				m_StartSel++;
			}
			break;
		case IDC_FKEY_COMMA:
			if (!m_IsInteger) {
				text2 = _T(",");
				m_StartSel++;
			}
			break;
		case IDC_FKEY_MINUS:
			if (!m_IsInteger || (m_StartSel == 0)) {
				text2 = _T("-");
				m_StartSel++;
			}
			break;
		case IDC_FKEY_DOT:
			if (!m_IsInteger) {
				text2 = _T(".");
				m_StartSel++;
			}
			break;
		case IDC_FKEY_DEL:
			if((m_StartSel == m_EndSel) && (m_StartSel > 0)){
				text1 = (text1 != _T("")) ? text1.Mid(0, text1.GetLength() - 1) : _T("");
				m_StartSel--;
			}
			break;
		case IDC_FKEY_CLR:
			text1 = _T("");
			text2 = _T("");
			text3 = _T("");
			m_StartSel = 0;
			break;
		default:
			break;	
	}

	SetWindowText(text1 + text2 + text3);
	GetParent()->ShowWindow(SW_SHOW);
	SetSel(m_StartSel, m_StartSel);

	return 0;
}

void CMV_EditBox::SetRevWnd(CWnd* pRevWnd)
{
	m_pRevWnd = pRevWnd;
}

// Set mode (full key or num key)
void CMV_EditBox::SetMode(int mode)
{
	m_Mode = mode;
}

// Get mode
int CMV_EditBox::GetMode() 
{
	return m_Mode;
}

// Set integer mode (full key only)
void CMV_EditBox::SetIntegerMode(bool isInteger)
{
	m_IsInteger = isInteger;
}

// Get integer mode (full key only)
bool CMV_EditBox::GetIntegerMode()
{
	return m_IsInteger;
}

// Set language
void CMV_EditBox::SetLanguage(int language)
{
	m_Language = language;
}

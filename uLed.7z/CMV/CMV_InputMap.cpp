// CMV_InputMap.cpp : implementation file
//

#include "stdafx.h"
#include "cmv.h"
#include "CMV_InputMap.h"
#include "CMV_Doc.h"
#include "CMVDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_InputMap dialog


CMV_InputMap::CMV_InputMap(CWnd* pParent /*=NULL*/)
	: CDialog(CMV_InputMap::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMV_InputMap)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMV_InputMap::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMV_InputMap)
	DDX_Control(pDX, IDC_EDIT_MAPNAME, m_EditMapName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMV_InputMap, CDialog)
	//{{AFX_MSG_MAP(CMV_InputMap)
	ON_BN_CLICKED(IDC_BTN_OK, OnBtnOk)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_InputMap message handlers

void CMV_InputMap::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}

void CMV_InputMap::SetInfoMapDisp(CCMVDlg* pMapDlg)
{
	m_pCMVDlg = pMapDlg;
}


BOOL CMV_InputMap::OnInitDialog() 
{
	CDialog::OnInitDialog();

	return TRUE;
}

void CMV_InputMap::OnBtnOk()						// OK button
{
// #DDT171006-01 Check condition of load map (S)
	m_EditMapName.GetWindowText(m_barcode);
	OnOK();
// #DDT171006-01 Check condition of load map (E)
}

BOOL CMV_InputMap::PreTranslateMessage(MSG* pMsg) 
{
	if ((GetKeyState(0x0D) & 0x8000) ) {			// Enter key
// #DDT171006-01 Check condition of load map (S)
		m_EditMapName.GetWindowText(m_barcode);
		OnOK();
// #DDT171006-01 Check condition of load map (E)
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}


void CMV_InputMap::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	m_EditMapName.SetFocus();
	m_EditMapName.SetSel(0,-1);
}

bool CMV_InputMap::WriteFile(LPCTSTR filePath, LPCTSTR lpszSection, LPCTSTR lpszKey, CString data)
{
	bool r = TRUE;
	WritePrivateProfileString (lpszSection, lpszKey, data, filePath);

	return r;
}

// #DDT171006-01 Check condition of load map (S)
CString CMV_InputMap::GetBarcode()
{
	return m_barcode;
}
// #DDT171006-01 Check condition of load map (E)
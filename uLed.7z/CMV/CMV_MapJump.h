#if !defined(AFX_CMV_MAPJUMP_H__F9F06106_C9D3_47C7_BDD6_20FD88A63A12__INCLUDED_)
#define AFX_CMV_MAPJUMP_H__F9F06106_C9D3_47C7_BDD6_20FD88A63A12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_MapJump.h : header file
//

#include "CMV_Doc.h"
#include "MemDC.h"

/////////////////////////////////////////////////////////////////////////////
// CMV_MapJump view

class CMV_MapJump : public CView
{
public:
	CMV_MapJump();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMV_MapJump)

// Attributes
public:
	CMV_Doc*		m_pDoc;

// Operations
public:
	void SetDocument(CMV_Doc* pDoc);
	void DrawJumpTable(CDC* pDC);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_MapJump)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMV_MapJump();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	//{{AFX_MSG(CMV_MapJump)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_MAPJUMP_H__F9F06106_C9D3_47C7_BDD6_20FD88A63A12__INCLUDED_)

// CMV_Map_View.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMV_Map_View.h"
#include "CMV_Util.h"
#include "MemDC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View

IMPLEMENT_DYNAMIC(CMV_Map_View, CScrollView)

CMV_Map_View::CMV_Map_View()
{
	xfirstLEDJump = 0;
	yfirstLEDJump = 0;
	SetBackSolidBrush(::GetSysColor(COLOR_BTNFACE));
}

CMV_Map_View::~CMV_Map_View()
{
	if(NULL != m_brushBack.GetSafeHandle())
	  m_brushBack.DeleteObject();
// #DDT171004-01 draw on memDC
	if(m_MemDC.m_hDC != NULL){
		m_MemDC.DeleteDC();
		m_MemBmp.DeleteObject();
	}
}


BEGIN_MESSAGE_MAP(CMV_Map_View, CScrollView)
	//{{AFX_MSG_MAP(CMV_Map_View)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONUP()
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View drawing
BOOL CMV_Map_View::SetBackSolidBrush(COLORREF crColor)
{
	if(NULL != m_brushBack.GetSafeHandle())
	  m_brushBack.DeleteObject();

	BOOL bRet = m_brushBack.CreateSolidBrush(crColor);

	if(NULL != m_hWnd)
	  Invalidate();

	return bRet;
}

void CMV_Map_View::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();
	m_pDoc->m_nZoom = 0;
	
	_SetScrollSizes();
}

void CMV_Map_View::DrawToMemDC()
{
	// Get total size
	CSize size = GetTotalSize();
	// Get region
	CRect rect(CPoint(0, 0), GetTotalSize());
	// Draw background to virtual DC
	m_MemDC.FillSolidRect(rect, m_pDoc->m_BackColor);
	// Set drawing rect
	// CRect drawRect = GetSubstrateRect();
	CRect drawRect = CRect(CPoint(0, 0), GetTotalSize());
	// Set view port for memory DC
	CPoint viewPnt = drawRect.TopLeft();
	viewPnt.Offset(-GetScrollPosition());
	m_MemDC.SetViewportOrg(viewPnt);
	// Start drawing here
	if (m_pDoc->m_IsLoadedMap == true)
	{
		DrawLEDs(&m_MemDC);
		DrawYAxis(/*&m_MemDC*/);
		DrawXAxis();
	}
	// End drawing here
	// Set the default view port for memory DC
	m_MemDC.SetViewportOrg(0, 0);
}

bool CMV_Map_View::HasToDraw(int idx, int idy)
{
	bool r = true;
	LEDInfo info = m_pDoc->LEDArrayInfo[idx-1][idy-1];
	CPoint offset = GetScrollPosition();
	CRect drawRect;
	GetClientRect(&drawRect);
	if ((info.top + m_pDoc->m_dispLEDSizeY < drawRect.top + offset.y)
		|| (info.top > drawRect.bottom + offset.y)
		|| (info.left > drawRect.right + offset.x)
		|| (info.left + m_pDoc->m_dispLEDSizeX < drawRect.left + offset.x)
		) {
		r = false;
	}
	return r;
}

void CMV_Map_View::ScrollToDisplayIndex() 
{
	CRect rcClient;
	GetClientRect(&rcClient);
	/* Set scroll for view pickup index alway in center(S) */
	if ( (GetStyle() & WS_HSCROLL) || (GetStyle() & WS_VSCROLL) ) {
		int xlimit = GetScrollLimit(SB_HORZ);
		int ylimit = GetScrollLimit(SB_VERT);
		
		if ((m_pDoc->m_IsDispIndex == TRUE) && (m_pDoc->m_IndexSelect >= 0) ) {	
			xfirstLEDJump = m_pDoc->LEDArrayInfo[m_pDoc->m_pIndexFirstX[m_pDoc->m_IndexSelect]][m_pDoc->m_pIndexFirstY[m_pDoc->m_IndexSelect]].left - MARGIN_TO_DISPLAY;
			yfirstLEDJump = m_pDoc->LEDArrayInfo[m_pDoc->m_pIndexFirstX[m_pDoc->m_IndexSelect]][m_pDoc->m_pIndexFirstY[m_pDoc->m_IndexSelect]].top - MARGIN_TO_DISPLAY;
			 
			SetScrollPos(SB_HORZ, (xfirstLEDJump < xlimit) ? xfirstLEDJump : xlimit);
			SetScrollPos(SB_VERT, (yfirstLEDJump < ylimit) ? yfirstLEDJump : ylimit);
			
			m_pDoc->m_IsDispIndex = FALSE;
		}
		
		if (m_pDoc->m_IsDispJumpInMapViaButton == TRUE ) {
			if ((m_pDoc->m_JumpXEnter > 0) && (m_pDoc->m_JumpXEnter <= m_pDoc->m_ColumnMax) && 
				(m_pDoc->m_JumpYEnter > 0) && (m_pDoc->m_JumpYEnter <= m_pDoc->m_RowMax) ){
			
				xfirstLEDJump = m_pDoc->LEDArrayInfo[m_pDoc->m_JumpXEnter-1][m_pDoc->m_JumpYEnter-1].left - MARGIN_TO_DISPLAY;
				yfirstLEDJump = m_pDoc->LEDArrayInfo[m_pDoc->m_JumpXEnter-1][m_pDoc->m_JumpYEnter-1].top - MARGIN_TO_DISPLAY;
				
				SetScrollPos(SB_HORZ, (xfirstLEDJump < xlimit) ? xfirstLEDJump : xlimit);
				SetScrollPos(SB_VERT, (yfirstLEDJump < ylimit) ? yfirstLEDJump : ylimit);
			}
		}
	}
	/* Set scroll for view pickup index alway in center(E) */
}

void CMV_Map_View::OnDraw(CDC* pDC)
{
//	ASSERT(MM_TEXT == pDC->GetMapMode());
//	ASSERT(CPoint(0, 0) == pDC->GetViewportOrg());
// #DDT171004-01 draw on memDC (S)
	// Draw to virtual DC
	DrawToMemDC();
	// Draw to real DC
	CRect rect;
	GetWindowRect(rect);
	pDC->BitBlt(GetScrollPosition().x, GetScrollPosition().y, rect.Width(), rect.Height(),
		&m_MemDC, 0, 0, SRCCOPY);
// #DDT171004-01 draw on memDC (E)
}

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View diagnostics

#ifdef _DEBUG
void CMV_Map_View::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMV_Map_View::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_Map_View message handlers

void CMV_Map_View::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}


void CMV_Map_View::InitMapView()
{
	int i, j;
	double rate = 1, rate1, rate2;
	CRect rect;
	GetClientRect(&rect);

	if(m_pDoc->m_RowMax > 1000){
		rate1 = MIN_DISP_SIZE_GREATER_THAN_1000/m_pDoc->m_LEDSizeX;
	}else{
		rate1 = (rect.Width() - 2 * TYOUSEI_LEFT) / ((m_pDoc->m_RowMax-1) * m_pDoc->m_LEDPitchX + m_pDoc->m_LEDPitchX);
		if(rate1* m_pDoc->m_LEDSizeX < MIN_DISP_SIZE_LESS_THAN_1000) {
			rate1 =  MIN_DISP_SIZE_LESS_THAN_1000/m_pDoc->m_LEDSizeX;
		}
	}

	if(m_pDoc->m_ColumnMax > 1000){
		rate2 = MIN_DISP_SIZE_GREATER_THAN_1000/m_pDoc->m_LEDSizeY;
	}else{
		rate2 = (rect.Height() - 2 * TYOUSEI_TOP) / ((m_pDoc->m_ColumnMax-1) * m_pDoc->m_LEDPitchY + m_pDoc->m_LEDPitchY);
		if(rate2* m_pDoc->m_LEDSizeY < MIN_DISP_SIZE_LESS_THAN_1000) {
			rate2 =  MIN_DISP_SIZE_LESS_THAN_1000/m_pDoc->m_LEDSizeY;
		}
	}
	
	rate = rate1 > rate2 ? rate2 : rate1;

	m_pDoc->m_dispLEDSizeX	= rate * m_pDoc->m_LEDSizeX;
	m_pDoc->m_dispLEDSizeY	= rate * m_pDoc->m_LEDSizeY;
	m_pDoc->m_dispLEDPitchX = rate * m_pDoc->m_LEDPitchX;
	m_pDoc->m_dispLEDPitchY = rate * m_pDoc->m_LEDPitchY;

	m_pDoc->m_dispToolIndexX = rate * m_pDoc->m_ToolIndexX;
	m_pDoc->m_dispToolIndexY = rate * m_pDoc->m_ToolIndexY;
	m_pDoc->m_dispToolPitchX = rate * m_pDoc->m_ToolPitchX;
	m_pDoc->m_dispToolPitchY = rate * m_pDoc->m_ToolPitchY;

	m_pDoc->m_ratioToolLEDX = (int)(m_pDoc->m_dispToolPitchX/m_pDoc->m_dispLEDPitchX + 0.5);
	m_pDoc->m_ratioToolLEDY = (int)(m_pDoc->m_dispToolPitchY/m_pDoc->m_dispLEDPitchY + 0.5);

//	if(m_pDoc->m_ratioToolLEDX == 0) m_pDoc->m_ratioToolLEDX =1;
//	if(m_pDoc->m_ratioToolLEDY == 0) m_pDoc->m_ratioToolLEDY =1;

	if(m_pDoc->m_ToolIndexX == 1)  m_pDoc->m_ratioToolLEDX = 0;
	if(m_pDoc->m_ToolIndexY == 1)  m_pDoc->m_ratioToolLEDY = 0;

	/* Get rect of LEDArrayInfo (S) */
	CRect Rect, Rect2;

	CSize size = GetTotalSize();
	// Get region
	CRect rc(CPoint(0, 0), GetTotalSize());

	Rect2.top    = rc.top + TYOUSEI_TOP;
	Rect2.left   = rc.left + TYOUSEI_LEFT;
	Rect2.bottom = rc.top + m_pDoc->m_dispLEDSizeY;
	Rect2.right  = rc.left + m_pDoc->m_dispLEDSizeX;

	for(j = 0 ; j < m_pDoc->m_RowMax ; j++){
		Rect.top    = Rect2.top + (j * m_pDoc->m_dispLEDPitchY);

		for(i = 0 ; i < m_pDoc->m_ColumnMax ; i++){
			Rect.left   = Rect2.left + (i * m_pDoc->m_dispLEDPitchX);

			Rect.bottom = Rect.top  + m_pDoc->m_dispLEDSizeY;
			Rect.right  = Rect.left + m_pDoc->m_dispLEDSizeX;

			m_pDoc->LEDArrayInfo[i][j].top    = Rect.top;
			m_pDoc->LEDArrayInfo[i][j].left   = Rect.left;

			m_pDoc->s2 = m_pDoc->str.Mid( ((m_pDoc->m_ColumnMax + 1) * j) + i, 1 );
			strcpy(m_pDoc->ch, (LPCTSTR)(m_pDoc->s2));
			m_pDoc->LEDArrayInfo[i][j].ch = m_pDoc->ch[0];

			if(m_pDoc->MapD.BCEQU.Find(CString(m_pDoc->ch[0])) != -1) {
				m_pDoc->LEDArrayInfo[i][j].isGoodBin = true;
			}else {
				m_pDoc->LEDArrayInfo[i][j].isGoodBin = false;
			}

			m_pDoc->LEDArrayInfo[i][j].isInGroup = false;
			m_pDoc->LEDArrayInfo[i][j].index	 = -1;
			m_pDoc->LEDArrayInfo[i][j].pickStatus = NOT_PICKED;
		}
	}
	/* Get rect of LEDArrayInfo (E) */

	for(i = 0; i < m_pDoc->m_ColumnMax; i++) {
		m_pDoc->xAxisRectArray[i].left		= m_pDoc->LEDArrayInfo[i][0].left;
		m_pDoc->xAxisRectArray[i].right		= m_pDoc->LEDArrayInfo[i][0].left + m_pDoc->m_dispLEDSizeX;
		m_pDoc->xAxisRectArray[i].bottom	= m_pDoc->LEDArrayInfo[i][0].top;
		m_pDoc->xAxisRectArray[i].top		= m_pDoc->LEDArrayInfo[i][0].top - TYOUSEI_TOP;
	}

	for(j = 0; j < m_pDoc->m_RowMax; j++) {		
		m_pDoc->yAxisRectArray[j].right		= m_pDoc->LEDArrayInfo[0][j].left;
		m_pDoc->yAxisRectArray[j].left		= m_pDoc->LEDArrayInfo[0][j].left - TYOUSEI_LEFT;
		m_pDoc->yAxisRectArray[j].top		= m_pDoc->LEDArrayInfo[0][j].top;
		m_pDoc->yAxisRectArray[j].bottom	= m_pDoc->LEDArrayInfo[0][j].top + m_pDoc->m_dispLEDSizeY;
	}	
	/* Create axisRects for display axis (E) */

	m_mapDispSize.cx = m_pDoc->xAxisRectArray[m_pDoc->m_ColumnMax-1].right + TYOUSEI_LEFT;
	m_mapDispSize.cy = m_pDoc->yAxisRectArray[m_pDoc->m_RowMax-1].bottom + TYOUSEI_TOP;

	_SetScrollSizes();
	SetScrollPos(SB_HORZ, 0);
	SetScrollPos(SB_VERT, 0);
}


void CMV_Map_View::OnPrepareDC(CDC* pDC, CPrintInfo* pInfo) 
{
	CScrollView::OnPrepareDC(pDC, pInfo);

	//pDC->SetMapMode(MM_TEXT);          // force map mode to MM_TEXT
	//pDC->SetViewportOrg(CPoint(0, 0)); // force viewport origin to zero
}


BOOL CMV_Map_View::OnScrollBy(CSize sizeScroll, BOOL bDoScroll) 
{
	int xOrig, x;
	int yOrig, y;

	// don't scroll if there is no valid scroll range (ie. no scroll bar)
	CScrollBar* pBar;
	DWORD dwStyle = GetStyle();
	pBar = GetScrollBarCtrl(SB_VERT);
	if ((pBar != NULL && !pBar->IsWindowEnabled()) ||
		(pBar == NULL && !(dwStyle & WS_VSCROLL)))
	{
		// vertical scroll bar not enabled
		sizeScroll.cy = 0;
	}
	pBar = GetScrollBarCtrl(SB_HORZ);
	if ((pBar != NULL && !pBar->IsWindowEnabled()) ||
		(pBar == NULL && !(dwStyle & WS_HSCROLL)))
	{
		// horizontal scroll bar not enabled
		sizeScroll.cx = 0;
	}

	// adjust current x position
	xOrig = x = GetScrollPos(SB_HORZ);
	int xMax = GetScrollLimit(SB_HORZ);
	x += sizeScroll.cx;
	if (x < 0)
		x = 0;
	else if (x > xMax)
		x = xMax;

	// adjust current y position
	yOrig = y = GetScrollPos(SB_VERT);
	int yMax = GetScrollLimit(SB_VERT);
	y += sizeScroll.cy;
	if (y < 0)
		y = 0;
	else if (y > yMax)
		y = yMax;

	// did anything change?
	if (x == xOrig && y == yOrig)
		return FALSE;

	if (bDoScroll)
	{
	    Invalidate();
		if (x != xOrig)
			SetScrollPos(SB_HORZ, x);
		if (y != yOrig)
			SetScrollPos(SB_VERT, y);
	}
	return TRUE;
}


void CMV_Map_View::_SetScrollSizes()
{
	CRect rect;
	GetClientRect(&rect);
	CSize sizeView(rect.Width(), rect.Height());
	if(m_pDoc->m_IsLoadedMap == true)
	{
		CSize size = GetMapDispSize();
		if (size.cx > sizeView.cx) {
			sizeView.cx = (int)(size.cx);
		}
		if (size.cy > sizeView.cy) {
			sizeView.cy = (int)(size.cy);
		}
	}
	
	SetScrollSizes(MM_TEXT, sizeView);
}


CSize CMV_Map_View::GetMapDispSize(void)
{
	return m_mapDispSize;
}


int CMV_Map_View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CScrollView::OnCreate(lpCreateStruct) == -1)
		return -1;
	_SetScrollSizes();
// #DDT171004-01 draw on memDC (S)
	CRect rect;
	GetDesktopWindow()->GetWindowRect(rect);
	// Create the virtual DC
	CDC* pDC = GetDC();
	m_MemDC.CreateCompatibleDC(pDC);
	m_MemBmp.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
	m_MemDC.SelectObject(&m_MemBmp);
// #DDT171004-01 draw on memDC (E)
	return 0;
}


void CMV_Map_View::DrawLEDs(/*CMemDC* pDCDraw, */CDC *pDC)
{
	// Store the view port
	CPoint viewPnt = pDC->GetViewportOrg();

	CRect subRect(CPoint(0,0), GetTotalSize());
	//GetClientRect(&subRect);
	pDC->FillSolidRect(subRect, m_pDoc->m_BackColor/*DBLE_SUBS_BKG_CLRRGB(236, 236, 236)*/);
	/* Draw edge of LED items color */
	CPen pen(PS_SOLID, 0.5, CMV_EDGE_LINE_CLR);
	CPen* pOldPen = pDC->SelectObject(&pen);

	CBrush *pOldBrush = pDC->SelectObject(&m_brushBack);

	CFont *pFont = NULL;
	if ((m_pDoc->m_dispLEDSizeX >= LED_SIZE_TO_DRAW_LTEXT && m_pDoc->m_dispLEDSizeY >= LED_SIZE_TO_DRAW_LTEXT)
		|| (m_pDoc->m_dispLEDPitchX >= LED_PITCH_TO_DRAW_TEXT) && (m_pDoc->m_dispLEDPitchY >= LED_PITCH_TO_DRAW_TEXT)) {
		pFont = pDC->SelectObject(&m_pDoc->myLFont);
	} else {
		pFont = pDC->SelectObject(&m_pDoc->mySFont);
	}

	pDC->SetBkMode(TRANSPARENT);

	CRect WorkRect;
	int i, j;
	for(j = 0; j < m_pDoc->m_RowMax; j++){
		for(i = 0; i < m_pDoc->m_ColumnMax; i++){
			if (!HasToDraw(i+1, j+1)) continue;
			WorkRect.left	= m_pDoc->LEDArrayInfo[i][j].left;
			WorkRect.top	= m_pDoc->LEDArrayInfo[i][j].top;
			WorkRect.bottom = m_pDoc->LEDArrayInfo[i][j].top + m_pDoc->m_dispLEDSizeY;
			WorkRect.right  = m_pDoc->LEDArrayInfo[i][j].left + m_pDoc->m_dispLEDSizeX;

			COLORREF color;
			if (m_pDoc->LEDArrayInfo[i][j].pickStatus == PICKED) {
				color = m_pDoc->m_PickColor;
			}
			else if (m_pDoc->LEDArrayInfo[i][j].pickStatus == PICKED_OK) {
				color = CMV_PICKED_OK_CLR;
			}
			else if (m_pDoc->LEDArrayInfo[i][j].pickStatus == PICKED_NG) {
				color = CMV_PICKED_NG_CLR;
			} else {
				color = m_pDoc->m_gCategoryColor[(int)(m_pDoc->LEDArrayInfo[i][j].ch)];
			}
			CBrush brush(color);
			pDC->FillRect( WorkRect, &brush );

			pDC->MoveTo(WorkRect.left, WorkRect.top);
			pDC->LineTo(WorkRect.right, WorkRect.top);
			pDC->LineTo(WorkRect.right, WorkRect.bottom);
			pDC->LineTo(WorkRect.left, WorkRect.bottom);
			pDC->LineTo(WorkRect.left, WorkRect.top);

			// Draw text bin
			if ( m_pDoc->m_dispLEDSizeX >= LED_SIZE_TO_DRAW_STEXT && m_pDoc->m_dispLEDSizeY >= LED_SIZE_TO_DRAW_STEXT) {
				pDC->DrawText(m_pDoc->LEDArrayInfo[i][j].ch, &WorkRect, m_pDoc->m_nFormat);
			}
		}
	}

	if( m_pDoc->m_IndexSelect >= 0){
		DrawIndexPickup(&m_MemDC, m_pDoc->m_IndexSelect);
	}

	// Draw reference point which sent from TFC
	if(m_pDoc->m_IsDispRefPos == TRUE) {
		DrawReferencePoint(&m_MemDC, m_pDoc->m_RefPosX, m_pDoc->m_RefPosY, FALSE);
		m_pDoc->m_IsDispIndex = FALSE;
	}

	// Draw pick point which sent from TFC 
//	if(m_pDoc->m_IsDispPickPos == TRUE) {
//		DrawPickPoint(&m_MemDC, m_pDoc->m_PickPosX, m_pDoc->m_PickPosY);
//		m_pDoc->m_IsDispIndex = FALSE;
//	}
	
	// Draw current position
	if(m_pDoc->m_IsDispCurrentPos == TRUE) {
		DrawCurrentPosition(&m_MemDC, m_pDoc->m_CurrentPosX, m_pDoc->m_CurrentPosY, TRUE);
	}

	if(m_pDoc->m_IsDispJumpInMapViaClick == TRUE) {
		if (m_pDoc->m_JumpX < 1 || m_pDoc->m_JumpY < 1 || m_pDoc->m_JumpX>m_pDoc->m_ColumnMax || m_pDoc->m_JumpY>m_pDoc->m_RowMax) {
			// Do nothing
		} else {
			DrawIndexJump(&m_MemDC, m_pDoc->m_JumpX-1, m_pDoc->m_JumpY-1);
		}
	}

	if(m_pDoc->m_IsDispJumpInMapViaButton == TRUE && m_pDoc->m_IsLoadedMap == TRUE){
		if (m_pDoc->m_JumpXEnter < 1 || m_pDoc->m_JumpYEnter < 1 || m_pDoc->m_JumpXEnter>m_pDoc->m_ColumnMax || m_pDoc->m_JumpYEnter>m_pDoc->m_RowMax) {
//			MessageBox(_T(" Index is invalid. Please enter the number greater than 1."), _T("Error"), MB_ICONERROR | MB_OK);
			TRACE("DrawIndexJump function has invalid item: m_pDoc->m_JumpXEnter < 1 || m_pDoc->m_JumpYEnter < 1\n");
		} else {
			DrawIndexJump(pDC, m_pDoc->m_JumpXEnter-1, m_pDoc->m_JumpYEnter-1);
		}
		m_pDoc->m_IsDispJumpInMapViaClick = FALSE;
	}
		
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pFont);
	pDC->SelectObject(pOldPen);
	DeleteObject(&m_brushBack);
	DeleteObject(&pen);
}

void CMV_Map_View::DrawYAxis(/*CDC *pDC*/void)
{
	CString text;
	// Get region
	CRect rectY;
	rectY.left		= GetScrollPos(SB_HORZ);
	rectY.right		= GetScrollPos(SB_HORZ) + TYOUSEI_LEFT;
	rectY.top		= GetScrollPos(SB_VERT) + TYOUSEI_TOP;
	rectY.bottom	= m_pDoc->yAxisRectArray[m_pDoc->m_RowMax-1].bottom + TYOUSEI_TOP;
	m_MemDC.FillSolidRect(rectY, m_pDoc->m_BackColor);


	CFont *pFont = NULL;
	if ((m_pDoc->m_dispLEDSizeX >= LED_SIZE_TO_DRAW_LTEXT && m_pDoc->m_dispLEDSizeY >= LED_SIZE_TO_DRAW_LTEXT)
		|| (m_pDoc->m_dispLEDPitchX >= LED_PITCH_TO_DRAW_TEXT) && (m_pDoc->m_dispLEDPitchY >= LED_PITCH_TO_DRAW_TEXT)) {
		pFont = m_MemDC.SelectObject(&m_pDoc->myLFont);
	} else {
		pFont = m_MemDC.SelectObject(&m_pDoc->mySFont);
	}

	if ( (m_pDoc->m_dispLEDSizeX >= LED_SIZE_TO_DRAW_STEXT && m_pDoc->m_dispLEDSizeY >= LED_SIZE_TO_DRAW_STEXT)
		|| (m_pDoc->m_dispLEDPitchX >= LED_PITCH_TO_DRAW_TEXT) && (m_pDoc->m_dispLEDPitchY >= LED_PITCH_TO_DRAW_TEXT)) {
		
		for(int j = 0; j < m_pDoc->m_RowMax; j++) {
			text.Format(_T("%d"), j+1);
//			pDC->DrawText( text, m_pDoc->yAxisRectArray[j], m_pDoc->m_nFormat);
			m_pDoc->yAxisRectArray[j].left = rectY.left;
			m_pDoc->yAxisRectArray[j].right = rectY.right;
			m_MemDC.DrawText( text, m_pDoc->yAxisRectArray[j], m_pDoc->m_nFormat);
		}
	}else {
		text.Format(_T("1"));
		m_MemDC.DrawText( text, m_pDoc->yAxisRectArray[0], m_pDoc->m_nFormat);
		for(int j = 4; j < m_pDoc->m_RowMax; j+=5) {
			text.Format(_T("%d"), j+1);
			m_pDoc->yAxisRectArray[j].left = rectY.left;
			m_pDoc->yAxisRectArray[j].right = rectY.right;
			m_MemDC.DrawText( text, m_pDoc->yAxisRectArray[j], m_pDoc->m_nFormat);
		}
	}
}


void CMV_Map_View::DrawXAxis(/*CDC *pDC*/void)
{
	CString text;

	// Get region
	CRect rectX;
	rectX.left		= GetScrollPos(SB_HORZ) + TYOUSEI_LEFT;
	rectX.right		= m_pDoc->xAxisRectArray[m_pDoc->m_ColumnMax-1].right + TYOUSEI_LEFT;
	rectX.top		= GetScrollPos(SB_VERT);
	rectX.bottom	= GetScrollPos(SB_VERT) + TYOUSEI_TOP;
	m_MemDC.FillSolidRect(rectX, m_pDoc->m_BackColor);

	CFont *pFont = NULL;
	if ((m_pDoc->m_dispLEDSizeX >= LED_SIZE_TO_DRAW_LTEXT && m_pDoc->m_dispLEDSizeY >= LED_SIZE_TO_DRAW_LTEXT)
		|| (m_pDoc->m_dispLEDPitchX >= LED_PITCH_TO_DRAW_TEXT) && (m_pDoc->m_dispLEDPitchY >= LED_PITCH_TO_DRAW_TEXT)) {
		pFont = m_MemDC.SelectObject(&m_pDoc->myLFont);
	} else {
		pFont = m_MemDC.SelectObject(&m_pDoc->mySFont);
	}

	if ( (m_pDoc->m_dispLEDSizeX >= LED_SIZE_TO_DRAW_STEXT && m_pDoc->m_dispLEDSizeY >= LED_SIZE_TO_DRAW_STEXT)
		|| (m_pDoc->m_dispLEDPitchX >= LED_PITCH_TO_DRAW_TEXT) && (m_pDoc->m_dispLEDPitchY >= LED_PITCH_TO_DRAW_TEXT)) {
		
		for(int i = 0; i < m_pDoc->m_ColumnMax; i++) {
			text.Format(_T("%d"), i+1);
//			pDC->DrawText( text, m_pDoc->xAxisRectArray[i], m_pDoc->m_nFormat);
			m_pDoc->xAxisRectArray[i].top = rectX.top;
			m_pDoc->xAxisRectArray[i].bottom = rectX.bottom;
			m_MemDC.DrawText( text, m_pDoc->xAxisRectArray[i], m_pDoc->m_nFormat);
		}
	}else {
		text.Format(_T("1"));
		m_MemDC.DrawText( text, m_pDoc->xAxisRectArray[0], m_pDoc->m_nFormat);
		for(int i = 4; i < m_pDoc->m_ColumnMax; i+=5) {
			text.Format(_T("%d"), i+1);
			m_pDoc->xAxisRectArray[i].top = rectX.top;
			m_pDoc->xAxisRectArray[i].bottom = rectX.bottom;
			m_MemDC.DrawText( text, m_pDoc->xAxisRectArray[i], m_pDoc->m_nFormat);
		}
	}


	// Draw top-left of map view
	CRect rect;
	rect.top		= 0;
	rect.left		= 0;
	rect.bottom		= GetScrollPos(SB_VERT) + TYOUSEI_TOP;
	rect.right		= GetScrollPos(SB_HORZ) + TYOUSEI_LEFT;

	m_MemDC.FillSolidRect(rect, m_pDoc->m_BackColor);
}


void CMV_Map_View::OnUpdateMapView(void)
{
	double rate = 1, rate1, rate2;
	CRect rect;
	GetClientRect(&rect);

	if(m_pDoc->m_RowMax > 1000){
		rate1 = MIN_DISP_SIZE_GREATER_THAN_1000/m_pDoc->m_LEDSizeX;
	}else{
		rate1 = (rect.Width() - 2 * TYOUSEI_LEFT) / ((m_pDoc->m_RowMax-1) * m_pDoc->m_LEDPitchX + m_pDoc->m_LEDPitchX);
		if(rate1* m_pDoc->m_LEDSizeX < MIN_DISP_SIZE_LESS_THAN_1000) {
			rate1 =  MIN_DISP_SIZE_LESS_THAN_1000/m_pDoc->m_LEDSizeX;
		}
	}

	if(m_pDoc->m_ColumnMax > 1000){
		rate2 = MIN_DISP_SIZE_GREATER_THAN_1000/m_pDoc->m_LEDSizeY;
	}else{
		rate2 = (rect.Height() - 2 * TYOUSEI_TOP) / ((m_pDoc->m_ColumnMax-1) * m_pDoc->m_LEDPitchY + m_pDoc->m_LEDPitchY);
		if(rate2* m_pDoc->m_LEDSizeY < MIN_DISP_SIZE_LESS_THAN_1000) {
			rate2 =  MIN_DISP_SIZE_LESS_THAN_1000/m_pDoc->m_LEDSizeY;
		}
	}

	rate = rate1 > rate2 ? rate2 : rate1;

	m_pDoc->m_dispLEDSizeX	= rate * m_pDoc->m_LEDSizeX;
	m_pDoc->m_dispLEDSizeY	= rate * m_pDoc->m_LEDSizeY;
	m_pDoc->m_dispLEDPitchX = rate * m_pDoc->m_LEDPitchX;
	m_pDoc->m_dispLEDPitchY = rate * m_pDoc->m_LEDPitchY;

	m_pDoc->m_dispToolIndexX = rate * m_pDoc->m_ToolIndexX;
	m_pDoc->m_dispToolIndexY = rate * m_pDoc->m_ToolIndexY;
	m_pDoc->m_dispToolPitchX = rate * m_pDoc->m_ToolPitchX;
	m_pDoc->m_dispToolPitchY = rate * m_pDoc->m_ToolPitchY;

	m_pDoc->m_dispLEDSizeX *= m_pDoc->m_ZoomRatio[m_pDoc->m_nZoom];
	m_pDoc->m_dispLEDSizeY *= m_pDoc->m_ZoomRatio[m_pDoc->m_nZoom];

	m_pDoc->m_dispLEDPitchX *= m_pDoc->m_ZoomRatio[m_pDoc->m_nZoom];
	m_pDoc->m_dispLEDPitchY *= m_pDoc->m_ZoomRatio[m_pDoc->m_nZoom];

	/* Get rect of LEDArrayInfo (S) */
	CRect Rect, Rect2;
	int i, j;

	CSize size = GetTotalSize();
	// Get region
	CRect rc(CPoint(0, 0), GetTotalSize());

	Rect2.top    = rc.top  + TYOUSEI_TOP;
	Rect2.left   = rc.left + TYOUSEI_LEFT;
	Rect2.bottom = rc.top  + m_pDoc->m_dispLEDSizeY;
	Rect2.right  = rc.left + m_pDoc->m_dispLEDSizeX;

	// j is counter follow y axis, i is counter follow x axis
	for(j = 0; j < m_pDoc->m_RowMax ; j++){
		Rect.top    = Rect2.top + (j * m_pDoc->m_dispLEDPitchY);

		for(i = 0; i < m_pDoc->m_ColumnMax ; i++){
			Rect.left   = Rect2.left + (i * m_pDoc->m_dispLEDPitchX);

			Rect.bottom = Rect.top  + m_pDoc->m_dispLEDSizeY;
			Rect.right  = Rect.left + m_pDoc->m_dispLEDSizeX;

			m_pDoc->LEDArrayInfo[i][j].top    = Rect.top;
			m_pDoc->LEDArrayInfo[i][j].left   = Rect.left;
		}
	}
	/* Get rect of LEDArrayInfo (E) */

	for(i = 0; i < m_pDoc->m_ColumnMax; i++) {
		m_pDoc->xAxisRectArray[i].left   = m_pDoc->LEDArrayInfo[i][0].left;
		m_pDoc->xAxisRectArray[i].right  = m_pDoc->LEDArrayInfo[i][0].left + m_pDoc->m_dispLEDSizeX;
		m_pDoc->xAxisRectArray[i].bottom = m_pDoc->LEDArrayInfo[i][0].top;
		m_pDoc->xAxisRectArray[i].top	 = m_pDoc->LEDArrayInfo[i][0].top - TYOUSEI_TOP;
	}

	for(j = 0; j < m_pDoc->m_RowMax; j++) {		
		m_pDoc->yAxisRectArray[j].right		= m_pDoc->LEDArrayInfo[0][j].left;
		m_pDoc->yAxisRectArray[j].left		= m_pDoc->LEDArrayInfo[0][j].left - TYOUSEI_LEFT;
		m_pDoc->yAxisRectArray[j].top		= m_pDoc->LEDArrayInfo[0][j].top;
		m_pDoc->yAxisRectArray[j].bottom	= m_pDoc->LEDArrayInfo[0][j].top + m_pDoc->m_dispLEDSizeY;
	}
	/* Create axisRects for display axis (E) */

	m_mapDispSize.cx = m_pDoc->xAxisRectArray[m_pDoc->m_ColumnMax-1].right  + TYOUSEI_LEFT;
	m_mapDispSize.cy = m_pDoc->yAxisRectArray[m_pDoc->m_RowMax-1].bottom  + TYOUSEI_TOP;

	_SetScrollSizes();
	Invalidate();
//	UpdateWindow();	
}


BOOL CMV_Map_View::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}


void CMV_Map_View::DrawIndexPickup(CDC *pDCDraw, int index)
{
	CRect WorkRect;

	CPen pen(PS_SOLID, 2, CMV_INDEX_PICKUP_CLR);
	CPen* pOldPen = pDCDraw->SelectObject(&pen);

	int i, j;
	for(j = 0; j <m_pDoc->m_RowMax ; j++){
		for(i = 0; i < m_pDoc->m_ColumnMax ; i++){

			if (m_pDoc->LEDArrayInfo[i][j].index == index) {
				int margin = (int)(m_pDoc->m_dispLEDPitchX - m_pDoc->m_dispLEDSizeX);
				if (margin >= MARGIN_TO_DRAW_POS) {
					margin = MARGIN_TO_DRAW_POS;
				}
				WorkRect.top	= m_pDoc->LEDArrayInfo[i][j].top - margin;
				WorkRect.left	= m_pDoc->LEDArrayInfo[i][j].left - margin;
				WorkRect.bottom = m_pDoc->LEDArrayInfo[i][j].top + m_pDoc->m_dispLEDSizeY + margin;
				WorkRect.right  = m_pDoc->LEDArrayInfo[i][j].left + m_pDoc->m_dispLEDSizeX + margin;
							
				/* Draw rectange (S) */
				pDCDraw->MoveTo(WorkRect.left, WorkRect.top);
				pDCDraw->LineTo(WorkRect.right, WorkRect.top);

				pDCDraw->MoveTo(WorkRect.left, WorkRect.top);
				pDCDraw->LineTo(WorkRect.left, WorkRect.bottom);

				pDCDraw->MoveTo(WorkRect.left, WorkRect.bottom);
				pDCDraw->LineTo(WorkRect.right, WorkRect.bottom);

				pDCDraw->MoveTo(WorkRect.right, WorkRect.top);
				pDCDraw->LineTo(WorkRect.right, WorkRect.bottom);
				/* Draw rectange (E) */
			}
		}
	}
	pDCDraw->SelectObject(pOldPen);
	DeleteObject(&pen);
}

void CMV_Map_View::DrawReferencePoint(CDC *pDCDraw, int ix, int iy, bool Mode)
{
	CRect RefPosRec;
	CPen pen(PS_SOLID, 2, m_pDoc->m_RefColor );
	CPen* pOldPen = pDCDraw->SelectObject(&pen);

	if (!Mode) {
		// Display one reference point only
		RefPosRec.top    = m_pDoc->LEDArrayInfo[ix][iy].top;
		RefPosRec.left   = m_pDoc->LEDArrayInfo[ix][iy].left;
		RefPosRec.right  = m_pDoc->LEDArrayInfo[ix][iy].top + m_pDoc->m_dispLEDSizeY;
		RefPosRec.bottom = m_pDoc->LEDArrayInfo[ix][iy].left + m_pDoc->m_dispLEDSizeX;
		
		/* Draw X line (S) */
		pDCDraw->MoveTo(RefPosRec.left, RefPosRec.top);
		pDCDraw->LineTo(RefPosRec.right, RefPosRec.bottom);

		pDCDraw->MoveTo(RefPosRec.right, RefPosRec.top);
		pDCDraw->LineTo(RefPosRec.left, RefPosRec.bottom);
		/* Draw X line (E) */

	} else {	// Display all reference point which same index
		int index = m_pDoc->LEDArrayInfo[ix][iy].index;
		if(index >= 0){ 
			int i, j;
			for(j = 0; j < m_pDoc->m_RowMax; j++){
				for(i = 0; i < m_pDoc->m_ColumnMax; i++){

					if (m_pDoc->LEDArrayInfo[i][j].index == index) {
						RefPosRec.top    = m_pDoc->LEDArrayInfo[i][j].top;
						RefPosRec.left   = m_pDoc->LEDArrayInfo[i][j].left;
						RefPosRec.right  = m_pDoc->LEDArrayInfo[i][j].top + m_pDoc->m_dispLEDSizeY;
						RefPosRec.bottom = m_pDoc->LEDArrayInfo[i][j].left + m_pDoc->m_dispLEDSizeX;
						
						/* Draw X line (S) */
						pDCDraw->MoveTo(RefPosRec.left, RefPosRec.top);
						pDCDraw->LineTo(RefPosRec.right, RefPosRec.bottom);

						pDCDraw->MoveTo(RefPosRec.right, RefPosRec.top);
						pDCDraw->LineTo(RefPosRec.left, RefPosRec.bottom);
						/* Draw X line (E) */
					}
				}
			}
		}
	}

	pDCDraw->SelectObject(&pOldPen);
	DeleteObject(&pen);
}

void CMV_Map_View::DrawPickPoint(CDC *pDCDraw, int ix, int iy)
{
	CBrush brush(m_pDoc->m_PickColor);
	int index = m_pDoc->LEDArrayInfo[ix][iy].index;
	CRect PickRec;

	if(index >= 0){
		int i, j;
		for(j = 0; j < m_pDoc->m_RowMax ; j++){
			for(i = 0; i < m_pDoc->m_ColumnMax ; i++){
				if (m_pDoc->LEDArrayInfo[i][j].index == index || m_pDoc->LEDArrayInfo[i][j].pickStatus == PICKED) {	
					PickRec.top		= m_pDoc->LEDArrayInfo[i][j].top;
					PickRec.left	= m_pDoc->LEDArrayInfo[i][j].left;
					PickRec.bottom	= m_pDoc->LEDArrayInfo[i][j].top + m_pDoc->m_dispLEDSizeY;
					PickRec.right	= m_pDoc->LEDArrayInfo[i][j].left + m_pDoc->m_dispLEDSizeX;
				
					pDCDraw->FillRect( PickRec, &brush );
					pDCDraw->SetBkMode(TRANSPARENT);
					pDCDraw->DrawText(m_pDoc->LEDArrayInfo[i][j].ch, &PickRec, m_pDoc->m_nFormat);
				}
			}
		}
	}
}


void CMV_Map_View::DrawIndexJump(CDC *pDCDraw, int indexX, int indexY)
{
	CRect WorkRect;

	CPen pen(PS_SOLID, 2, CMV_INDEX_JUMP_CLR);
	CPen* pOldPen = pDCDraw->SelectObject(&pen);
	
	int margin = (int)(m_pDoc->m_dispLEDPitchX - m_pDoc->m_dispLEDSizeX);
	if (margin >= MARGIN_TO_DRAW_POS) {
		margin = MARGIN_TO_DRAW_POS;
	}
				
	WorkRect.top	= m_pDoc->LEDArrayInfo[indexX][indexY].top - margin;
	WorkRect.left	= m_pDoc->LEDArrayInfo[indexX][indexY].left - margin;
	WorkRect.bottom = m_pDoc->LEDArrayInfo[indexX][indexY].top + m_pDoc->m_dispLEDSizeY + margin;
	WorkRect.right  = m_pDoc->LEDArrayInfo[indexX][indexY].left + m_pDoc->m_dispLEDSizeX + margin;


	/* Draw rectange (S) */
	pDCDraw->MoveTo(WorkRect.left, WorkRect.top);
	pDCDraw->LineTo(WorkRect.right, WorkRect.top);

	pDCDraw->MoveTo(WorkRect.left, WorkRect.top);
	pDCDraw->LineTo(WorkRect.left, WorkRect.bottom);

	pDCDraw->MoveTo(WorkRect.left, WorkRect.bottom);
	pDCDraw->LineTo(WorkRect.right, WorkRect.bottom);

	pDCDraw->MoveTo(WorkRect.right, WorkRect.top);
	pDCDraw->LineTo(WorkRect.right, WorkRect.bottom);
	/* Draw rectange (E) */
	pDCDraw->SelectObject(&pOldPen);
	DeleteObject(&pen);
}


void CMV_Map_View::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CScrollView::OnLButtonUp(nFlags, point);
	
	// Get scroll position
	point.x += GetScrollPos(SB_HORZ);
	point.y += GetScrollPos(SB_VERT);

	int i, j;
	if (m_pDoc->m_IsLoadedMap == true) {
		for(j = 0; j < m_pDoc->m_RowMax; j++) {	
			for(i = 0; i < m_pDoc->m_ColumnMax; i++) {			
				if ((point.x >= m_pDoc->LEDArrayInfo[i][j].left && point.x <= m_pDoc->LEDArrayInfo[i][j].left + m_pDoc->m_dispLEDSizeX) &&
					(point.y <= m_pDoc->LEDArrayInfo[i][j].top + m_pDoc->m_dispLEDSizeX && point.y >= m_pDoc->LEDArrayInfo[i][j].top) ) {
					m_pDoc->m_JumpX = i+1;
					m_pDoc->m_JumpY = j+1;
				}
			}
		}
	}

	m_pDoc->m_IndexSelect = -1;
	m_pDoc->m_IsDispCurrentPos = FALSE;
	m_pDoc->m_IsDispRefPos = FALSE;
	m_pDoc->m_IsDispJumpInTab = TRUE;
	m_pDoc->m_IsDispJumpInMapViaButton = FALSE;
	m_pDoc->m_IsDispJumpInMapViaClick = TRUE;
	AfxGetApp()->m_pMainWnd->Invalidate(TRUE);
	UpdateWindow();
}


void CMV_Map_View::DrawCurrentPosition(CDC *pDCDraw, int ix, int iy, bool Mode)
{
	// Draw current move position
	CRect CurrentPos;
	int iLen, i1, i2;
	CPen pen(PS_SOLID, 2, m_pDoc->m_PosColor );
	CPen* pCurrentPosPen = pDCDraw->SelectObject(&pen);

	int margin = (int)(m_pDoc->m_dispLEDPitchX - m_pDoc->m_dispLEDSizeX);
	if (margin >= MARGIN_TO_DRAW_POS) {
		margin = MARGIN_TO_DRAW_POS;
	}

	if (!Mode) {
		
		CurrentPos.top    = m_pDoc->LEDArrayInfo[ix][iy].top - margin;
		CurrentPos.left   = m_pDoc->LEDArrayInfo[ix][iy].left - margin;
		CurrentPos.right  = m_pDoc->LEDArrayInfo[ix][iy].left + m_pDoc->m_dispLEDSizeX + margin;
		CurrentPos.bottom = m_pDoc->LEDArrayInfo[ix][iy].top + m_pDoc->m_dispLEDSizeY + margin;
		

		POINT PolyPoint[5];
		PolyPoint[0].x = CurrentPos.left;
		PolyPoint[0].y = CurrentPos.top;
		PolyPoint[1].x = CurrentPos.right;
		PolyPoint[1].y = CurrentPos.top;
		PolyPoint[2].x = CurrentPos.right;
		PolyPoint[2].y = CurrentPos.bottom;
		PolyPoint[3].x = CurrentPos.left;
		PolyPoint[3].y = CurrentPos.bottom;
		PolyPoint[4].x = CurrentPos.left;
		PolyPoint[4].y = CurrentPos.top;
		pDCDraw->Polyline( PolyPoint, 5);

		iLen = 6;
		i1 = CurrentPos.left - iLen;
		i2 = CurrentPos.top + (CurrentPos.bottom - CurrentPos.top) / 2;
		PolyPoint[0].x = i1;
		PolyPoint[0].y = i2;
		PolyPoint[1].x = CurrentPos.left;
		PolyPoint[1].y = i2;
		pDCDraw->Polyline( PolyPoint, 2);

		i1 = CurrentPos.right + iLen;
		PolyPoint[0].x = i1;
		PolyPoint[1].x = CurrentPos.right;
		pDCDraw->Polyline( PolyPoint, 2);

		i1 = CurrentPos.top - iLen;
		i2 = CurrentPos.left + (CurrentPos.right - CurrentPos.left) / 2;
		PolyPoint[0].x = i2;
		PolyPoint[0].y = i1;
		PolyPoint[1].x = i2;
		PolyPoint[1].y = CurrentPos.top;
		pDCDraw->Polyline( PolyPoint, 2);

		i1 = CurrentPos.bottom + iLen;
		PolyPoint[0].y = i1;
		PolyPoint[1].y = CurrentPos.bottom;
		pDCDraw->Polyline( PolyPoint, 2);
	}
	else {
		int index = m_pDoc->LEDArrayInfo[ix][iy].index;
		if(index >= 0){
			int i, j;
			for(j = 0; j < m_pDoc->m_RowMax ; j++){
				for(i = 0; i < m_pDoc->m_ColumnMax ; i++){
					if (m_pDoc->LEDArrayInfo[i][j].index == index) {
						CurrentPos.top    = m_pDoc->LEDArrayInfo[i][j].top - margin;
						CurrentPos.left   = m_pDoc->LEDArrayInfo[i][j].left - margin;
						CurrentPos.right  = m_pDoc->LEDArrayInfo[i][j].left + m_pDoc->m_dispLEDSizeY + margin;
						CurrentPos.bottom = m_pDoc->LEDArrayInfo[i][j].top + m_pDoc->m_dispLEDSizeX + margin;

						POINT PolyPoint[5];
						PolyPoint[0].x = CurrentPos.left;
						PolyPoint[0].y = CurrentPos.top;
						PolyPoint[1].x = CurrentPos.right;
						PolyPoint[1].y = CurrentPos.top;
						PolyPoint[2].x = CurrentPos.right;
						PolyPoint[2].y = CurrentPos.bottom;
						PolyPoint[3].x = CurrentPos.left;
						PolyPoint[3].y = CurrentPos.bottom;
						PolyPoint[4].x = CurrentPos.left;
						PolyPoint[4].y = CurrentPos.top;
						pDCDraw->Polyline( PolyPoint, 5);

						iLen = 6;
						i1 = CurrentPos.left - iLen;
						i2 = CurrentPos.top + (CurrentPos.bottom - CurrentPos.top) / 2;
						PolyPoint[0].x = i1;
						PolyPoint[0].y = i2;
						PolyPoint[1].x = CurrentPos.left;
						PolyPoint[1].y = i2;
						pDCDraw->Polyline( PolyPoint, 2);

						i1 = CurrentPos.right + iLen;
						PolyPoint[0].x = i1;
						PolyPoint[1].x = CurrentPos.right;
						pDCDraw->Polyline( PolyPoint, 2);

						i1 = CurrentPos.top - iLen;
						i2 = CurrentPos.left + (CurrentPos.right - CurrentPos.left) / 2;
						PolyPoint[0].x = i2;
						PolyPoint[0].y = i1;
						PolyPoint[1].x = i2;
						PolyPoint[1].y = CurrentPos.top;
						pDCDraw->Polyline( PolyPoint, 2);

						i1 = CurrentPos.bottom + iLen;
						PolyPoint[0].y = i1;
						PolyPoint[1].y = CurrentPos.bottom;
						pDCDraw->Polyline( PolyPoint, 2);
					}
				}
			}
		}
	}
}

void CMV_Map_View::JumpToPos(int ix, int iy, bool Mode)
{
	if (!Mode) {		
		// Set scroll
		CRect rcClient(0, 0, 0, 0);
		GetClientRect(rcClient);

		/* Set scroll for view pickup index alway in center(S) */
		if ( (GetStyle() & WS_HSCROLL) || (GetStyle() & WS_VSCROLL) ) {
			int xlimit = GetScrollLimit(SB_HORZ);
			int ylimit = GetScrollLimit(SB_VERT);

			xfirstLEDJump = m_pDoc->LEDArrayInfo[ix][iy].left - MARGIN_TO_DISPLAY;
			yfirstLEDJump = m_pDoc->LEDArrayInfo[ix][iy].top - MARGIN_TO_DISPLAY;

			SetScrollPos(SB_HORZ, (xfirstLEDJump < xlimit) ? xfirstLEDJump : xlimit);
			SetScrollPos(SB_VERT, (yfirstLEDJump < ylimit) ? yfirstLEDJump : ylimit);
//			Invalidate();
		}
	}
	else {
		// Set scroll
		CRect rcClient(0, 0, 0, 0);
		GetClientRect(rcClient);

		
		if ( (GetStyle() & WS_HSCROLL) || (GetStyle() & WS_VSCROLL) ) {
			int xlimit = GetScrollLimit(SB_HORZ);
			int ylimit = GetScrollLimit(SB_VERT);

			xfirstLEDJump = m_pDoc->LEDArrayInfo[ix][iy].left- MARGIN_TO_DISPLAY;
			yfirstLEDJump = m_pDoc->LEDArrayInfo[ix][iy].top - MARGIN_TO_DISPLAY;

			SetScrollPos(SB_HORZ, (xfirstLEDJump < xlimit) ? xfirstLEDJump : xlimit);
			SetScrollPos(SB_VERT, (yfirstLEDJump < ylimit) ? yfirstLEDJump : ylimit);
//			Invalidate();
		}
	}
}

/**
* Override function to get current position of vertival scroll in 64bit.
* With large data, position in 16bit is not enough.
*/
void CMV_Map_View::OnVScroll( UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int pos = 0;
	switch(nSBCode) {
		// In case of thumb track, we need to update track position
		case SB_THUMBTRACK:
			SCROLLINFO si;
			si.cbSize = sizeof(SCROLLINFO);
			// Get scroll info
			GetScrollInfo(SB_VERT,&si,SIF_ALL);
			// Update track position
			pos = si.nTrackPos;
			break;
		default:
			pos = nPos;
			break;
	}

	DrawYAxis();
	CScrollView::OnVScroll(nSBCode, pos, pScrollBar);
}

/**
* Override function to get current position of vertival scroll in 64bit.
* With large data, position in 16bit is not enough.
*/
void CMV_Map_View::OnHScroll( UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int pos = 0;
	switch(nSBCode) {
		// In case of thumb track, we need to update track position
		case SB_THUMBTRACK:
			SCROLLINFO si;
			si.cbSize = sizeof(SCROLLINFO);
			// Get scroll info
			GetScrollInfo(SB_HORZ,&si,SIF_ALL);
			// Update track position
			pos = si.nTrackPos;
			break;
		default:
			pos = nPos;
			break;
	}

	DrawXAxis();
	CScrollView::OnHScroll(nSBCode, pos, pScrollBar);
}


void CMV_Map_View::OnSize(UINT nType, int cx, int cy)
{
	_SetScrollSizes();

	CScrollView::OnSize(nType, cx, cy);
}
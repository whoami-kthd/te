///////////////////////////////////////////////////////////
//  CMV_NumKeyWnd.cpp
//  Implementation of the Class CMV_NumKeyWnd
//  Created on:      16-Thg7-2013 11:51:16 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CMV.h"
#include "CMV_NumKeyWnd.h"
#include "CMV_Doc.h"


/////////////////////////////////////////////////////////////////////////////
// CMV_NumKeyWnd dialog


CMV_NumKeyWnd::CMV_NumKeyWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CMV_NumKeyWnd::IDD, pParent)
{
	m_pRevWnd = NULL;
}

CMV_NumKeyWnd::~CMV_NumKeyWnd()
{

}


void CMV_NumKeyWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CMV_NumKeyWnd, CDialog)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_NumKeyWnd message handlers

void CMV_NumKeyWnd::OnKey(UINT nID)
{
	if(m_pRevWnd == NULL) return;
	// Post message to the parent window
	::PostMessage(m_pRevWnd->m_hWnd, WM_UPDATE_KEY, (WPARAM)nID, 0);
}

BOOL CMV_NumKeyWnd::Create(CWnd* pRevWnd, UINT nIDTemplate, CWnd* pParentWnd)
{
	m_pRevWnd = pRevWnd;
	return CDialog::Create(nIDTemplate, pParentWnd);
}

void CMV_NumKeyWnd::OnCancel()
{
	// do nothing
	TRACE("CMV_NumKeyWnd Cancel\n");
}

void CMV_NumKeyWnd::OnOK()
{
	// do nothing
}

// Set receive key window
void CMV_NumKeyWnd::SetReceiveKeyWindow(CWnd* pRevWnd)
{
	m_pRevWnd = pRevWnd;
}

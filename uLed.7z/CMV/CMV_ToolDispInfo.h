#if !defined(AFX_CMV_TOOLDISPINFO_H__D367E906_F672_4E1F_B42E_B3600458F166__INCLUDED_)
#define AFX_CMV_TOOLDISPINFO_H__D367E906_F672_4E1F_B42E_B3600458F166__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_ToolDispInfo.h : header file
//

#include "CMV_Doc.h"
#include "MemDC.h"

/////////////////////////////////////////////////////////////////////////////
// CMV_ToolDispInfo view

class CMV_ToolDispInfo : public CView
{
public:
	CMV_ToolDispInfo();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMV_ToolDispInfo)

// Attributes
public:
	CMV_Doc*	m_pDoc;

// Operations
public:
	void SetDocument(CMV_Doc* pDoc);
	void DrawToolLEDInfoTable(CDC* pDC, CRect rc, int xSizeUnit, int ySizeUnit);
	void WriteToolInfo(CDC* pDC, CRect rc, int xSizeUnit, int ySizeUnit);
	void WriteLEDInfo(CDC* pDC, CRect rc, int xSizeUnit, int ySizeUnit);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_ToolDispInfo)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMV_ToolDispInfo();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CMV_ToolDispInfo)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_TOOLDISPINFO_H__D367E906_F672_4E1F_B42E_B3600458F166__INCLUDED_)

/*---------------------------------------------------------------------
	���̧�ُ��̕ۑ��A�擾
	   Get/WritePrivateProfileString () ���g�p�B
								1997 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------
 #0001 97-10-06 R2PosS���폜���AR2Pos2��ǉ��B
---------------------------------------------------------------------*/
#include	<afxwin.h>
#include	<stdafx.h>
#include	<stdio.h>
#include	"Gwpp.h"

//------- ���̧�ق��ׯ��
BOOL GWPPfileEnd(LPCTSTR	lpFileName)
{
	int r = WritePrivateProfileString (NULL,NULL,NULL,lpFileName); 
	if(r)	r = FALSE;
	else	r = TRUE;
	return	r;
}

//--------- ����� or ���폜
BOOL GWPPfileDataDelete(			// ����� or ���폜
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey)		// address of key name
{
	return WritePrivateProfileString (lpszSection,lpszKey,NULL,lpFileName); 
}
//------- ���̧�ُ��̕ۑ��A�擾
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			CString&	Data,		// �ް��i�[
			CString		DataD)		// ��̫���ް�
{
	int r=TRUE;
	if(Get){
		LPTSTR p = Data.GetBuffer( 2048 );
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,p,2048,lpFileName); 
		if(r){
			p[2047]=0;
			Data.ReleaseBuffer();  // �]���ȃ�������������܂��Bp �͖����ɂȂ�܂��B
		}
		else{
			p[0]=0;
			Data.ReleaseBuffer();	// �]���ȃ�������������܂��Bp �͖����ɂȂ�܂��B
			Data = DataD;			// �f�t�H���g�f�[�^���R�s�[����
		}
	}
	else{
		r = WritePrivateProfileString (lpszSection,lpszKey,Data,lpFileName); 
	}

	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(					// BGH_XMP_Move_Data �^,,BGH_XMP_Move_Data(4/13 YM)
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			XMP_Move_Data&	Data,	// �ް��i�[,BGH_XMP_Move_Data(4/13 YM)
			XMP_Move_Data	DataD)		// ��̫���ް�,BGH_XMP_Move_Data(4/13 YM)
{
	int	r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                        NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			double	v,a,d,j;
			if(sscanf(inBuf,"%lf ,%lf ,%lf ,%lf",&v,&a,&d,&j) != 4){
				r = FALSE;
			}
			else{
				Data.Veloc = v;
				Data.Accel = a;
				Data.Decel = d;
				Data.Jerk = j;
			}
		}
		if(!r){
			Data = DataD; 
		}
	}
	else{
		CString	str;
		str.Format("%10.10lf,%10.10lf,%10.10lf,%10.10lf",Data.Veloc,Data.Accel,Data.Decel,Data.Jerk);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			LightLevelData&	Data,			// �ް��i�[
			LightLevelData	DataD)		// ��̫���ް�
{
	int	r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                        NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			int	a,b,c,d;
			if(sscanf(inBuf,"%d ,%d ,%d ,%d",&a,&b,&c,&d) != 4){
				r = FALSE;
			}
			else{
				Data.A = a;
				Data.B = b;
				Data.C = c;
				Data.D = d;
			}
		}
		if(!r){
			Data = DataD; 
		}
	}
	else{
		CString	str;
		str.Format("%d,%d,%d,%d",Data.A,Data.B,Data.C,Data.D);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			int&	Data,			// �ް��i�[
			int		DataD)		// ��̫���ް�
{
	int r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%d",&Data) != 1){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD; 
	}
	else{
		CString	str;
		str.Format("%d",Data);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}

	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			int		Data[],			// �ް��i�[
			int		Numb,			// �z��v�f���@
			int		DataD)		// ��̫���ް� �ǂݏo���v�f����Numb�ɖ����Ȃ��ꍇ��DataD��ݒ�
{
	int r=TRUE;
	if(Get){
		char	inBuf[20];
		int		i=0,n;
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,inBuf,20,lpFileName); 
		if(r){
			if(sscanf(inBuf,"%d",&n) == 1){
				int	leng = (n+1)*20+1;
				char	*buff = new char[leng];
				r = GetPrivateProfileString (lpszSection,lpszKey,
				                    NULL,buff,leng,lpFileName); 
				if(r){
					char	*bp=buff;
					bp = strchr(bp,',');		// �v�f�������
					if(bp){
						bp ++;
						for(;i<n && i<Numb;i++){
							if(sscanf(bp,"%d",&Data[i]) != 1){
								break;
							}
							bp = strchr(bp,',');		// ���v�f
							if(bp)	bp ++;
							else{
								i++;
								break;
							}
						}
					}
				}
				delete[] buff;
			}
		}
		if(i != Numb)	r = FALSE;
		else			r = TRUE;
		for(;i<Numb;i++){
			Data[i] = DataD; 
		}
	}
	else{
		CString	strA,strB;
		strA.Format("%d",Numb);		// �v�f��
		for(int i=0;i<Numb;i++){
			strB.Format(",%d",Data[i]);	// �v�f1,�v�f�Q,.....
			strA += strB;
		}
			// �v�f��,�v�f1,�v�f�Q,..... 
		r = WritePrivateProfileString (lpszSection,lpszKey,strA,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			double&	Data,			// �ް��i�[
			double	DataD)		// ��̫���ް�
{
	int	r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                          NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%lf",&Data) != 1){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD; 
	}
	else{
		CString	str;
		str.Format("%10.10lf",Data);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------//000713 YM�ǉ� long�ް��ǂݍ��ݗp 
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			long&	Data,			// �ް��i�[
			long	DataD)		// ��̫���ް�
{
	int	r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                          NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%ld",&Data) != 1){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD; 
	}
	else{
		CString	str;
		str.Format("%ld",Data);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			double	Data[],			// �ް��i�[
			int		Numb,			// �z��v�f���@
			double	DataD)			// ��̫���ް� �ǂݏo���v�f����Numb�ɖ����Ȃ��ꍇ��DataD��ݒ�
{
	int r=TRUE;
	if(Get){
		char	inBuf[20];
		int		i=0,n;
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,inBuf,20,lpFileName); 
		if(r){
			if(sscanf(inBuf,"%d",&n) == 1){
				int	leng = (n+1)*25+1;
				char	*buff = new char[leng];
				r = GetPrivateProfileString (lpszSection,lpszKey,
				                    NULL,buff,leng,lpFileName); 
				if(r){
					char	*bp=buff;
					bp = strchr(bp,',');		// �v�f�������
					if(bp){
						bp ++;
						for(;i<n && i<Numb;i++){
							if(sscanf(bp,"%lf",&Data[i]) != 1){
								break;
							}
							bp = strchr(bp,',');		// ���v�f
							if(bp)	bp ++;
							else{
								i++;
								break;
							}
						}
					}
				}
				delete[] buff;
			}
		}
		if(i != Numb)	r = FALSE;
		else			r = TRUE;
		for(;i<Numb;i++){
			Data[i] = DataD; 
		}
	}
	else{
		CString	strA,strB;
		strA.Format("%d",Numb);		// �v�f��
		for(int i=0;i<Numb;i++){
			strB.Format(",%10.10lf",Data[i]);	// �v�f1,�v�f�Q,.....
			strA += strB;
		}
			// �v�f��,�v�f1,�v�f�Q,..... 
		r = WritePrivateProfileString (lpszSection,lpszKey,strA,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			R2Pos&	Data,			// �ް��i�[
			R2Pos	DataD)		// ��̫���ް�
{
	int	r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                        NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			double	x,y;
			if(sscanf(inBuf,"%lf ,%lf",&x,&y) != 2){
				r = FALSE;
			}
			else{
				Data.X() = x;
				Data.Y() = y;
			}
		}
		if(!r){
			Data = DataD; 
		}
	}
	else{
		CString	str;
		str.Format("%10.10lf,%10.10lf",Data.X(),Data.Y());
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			R2Pos	Data[],			// �ް��i�[
			int		Numb,			// �z��v�f���@
			R2Pos	DataD)			// ��̫���ް� �ǂݏo���v�f����Numb�ɖ����Ȃ��ꍇ��DataD��ݒ�
{
	int r=TRUE;
	if(Get){
		char	inBuf[20];
		int		i=0,n;
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,inBuf,20,lpFileName); 
		if(r){
			if(sscanf(inBuf,"%d",&n) == 1){
				int	leng = (n+1)*25*2+1;
				char	*buff = new char[leng];
				r = GetPrivateProfileString (lpszSection,lpszKey,
				                    NULL,buff,leng,lpFileName); 
				if(r){
					char	*bp=buff;
					bp = strchr(bp,',');		// �v�f�������
					if(bp){
						bp ++;
						for(;i<n && i<Numb;i++){
							double	x,y;
							if(sscanf(bp,"%lf ,%lf",&x,&y) != 2){
								break;
							}
							else{
								Data[i].X() = x;
								Data[i].Y() = y;
							}
							bp = strchr(bp,',');		// ���v�f
							if(bp){
								bp ++;
								bp = strchr(bp,',');		// ���v�f
								if(bp)	bp ++;
							}
							if(bp == NULL){
								i++;
								break;
							}
						}
					}
				}
				delete[] buff;
			}
		}
		if(i != Numb)	r = FALSE;
		else			r = TRUE;
		for(;i<Numb;i++){
			Data[i] = DataD; 
		}
	}
	else{
		CString	strA,strB;
		strA.Format("%d",Numb);		// �v�f��
		for(int i=0;i<Numb;i++){
			strB.Format(",%10.10lf,%10.10lf",Data[i].X(),Data[i].Y());// �v�f1,�v�f�Q,.....
			strA += strB;
		}
			// �v�f��,�v�f1,�v�f�Q,..... 
		r = WritePrivateProfileString (lpszSection,lpszKey,strA,lpFileName); 
	}
	return	r;
}

//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			MtrSpeed&	Data,			// �ް��i�[
			MtrSpeed	DataD)		// ��̫���ް�
{
	int	r=TRUE;
	if(Get){
		char	inBuf[128];
		int	r = GetPrivateProfileString (lpszSection,lpszKey,
	                        NULL,inBuf,128,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%d ,%d ,%d ,%d ,%d",
				&Data.l,&Data.h,&Data.u,&Data.d,&Data.c) != 5){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD;	
	}
	else{
		CString	str;
		str.Format("%d,%d,%d,%d,%d",Data.l,Data.h,Data.u,Data.d,Data.c);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			AFUFocusPara&	Data,			// �ް��i�[
			AFUFocusPara	DataD)		// ��̫���ް�
{
	int	r=TRUE;
	if(Get){
		char	inBuf[128];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,inBuf,128,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%d ,%d ,%d ,%d ,%d ,%d ,%d",
				&Data.th_focus,
				&Data.th_high,
				&Data.add_jf,
				&Data.home,
				&Data.inpls,
				&Data.d_offset,
				&Data.ldpower) != 7){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD; 
	}
	else{
		CString	str;
		str.Format("%d,%d,%d,%d,%d,%d,%d",
			Data.th_focus,
			Data.th_high,
			Data.add_jf,
			Data.home,
			Data.inpls,
			Data.d_offset,
			Data.ldpower);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}

	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			AFUMotorPara&	Data,			// �ް��i�[
			AFUMotorPara	DataD)		// ��̫���ް�
{
	int	r = TRUE;
	if(Get){
		char	inBuf[128];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,inBuf,128,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%d ,%d ,%d ,%d ,%d ,%d",
				&Data.drvmode,
				&Data.maxsd,
				&Data.minsd,
				&Data.cnstsd,
				&Data.accel1,
				&Data.accel2) != 6){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD; 
	}
	else{
		CString	str;
		str.Format("%d,%d,%d,%d,%d,%d",
			Data.drvmode,
			Data.maxsd,
			Data.minsd,
			Data.cnstsd,
			Data.accel1,
			Data.accel2);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			CogSearchPara&	Data,			// �ް��i�[
			CogSearchPara	DataD)		// ��̫���ް�
{
	int	r = TRUE;
	if(Get){
		char	inBuf[128];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,inBuf,128,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%d ,%d ,%d ,%d ,%d ,%d ,%d ,%d ,%d ,%d ,%d ,%d ,%d",
				&Data.MSizeX,&Data.MSizeY,
				&Data.MCentX,&Data.MCentY,
				&Data.SSizeX,&Data.SSizeY,
				&Data.SCentX,&Data.SCentY,
				&Data.Accept,&Data.Confusion,
				&Data.Results,
				&Data.Score1,&Data.Score2
				) != 13){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD; 
	}
	else{
		CString	str;
		str.Format("%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d",
				Data.MSizeX,Data.MSizeY,
				Data.MCentX,Data.MCentY,
				Data.SSizeX,Data.SSizeY,
				Data.SCentX,Data.SCentY,
				Data.Accept,Data.Confusion,
				Data.Results,
				Data.Score1,Data.Score2);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			CogSearchPara2&	Data,			// �ް��i�[
			CogSearchPara2	DataD)		// ��̫���ް�
{
	int	r = TRUE;
	if(Get){
		char	inBuf[128];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                           NULL,inBuf,128,lpFileName); 
		if(r){
			r = TRUE;
			if(sscanf(inBuf,"%d ,%d ,%d",
				&Data.Angle_l,&Data.Angle_inc,&Data.Angle) != 3){
				r = FALSE;
			}
		}
		if(!r)	Data = DataD; 
	}
	else{
		CString	str;
		str.Format("%d,%d,%d",
				Data.Angle_l,
				Data.Angle_inc,
				Data.Angle);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
/////////////////////////////////////////////////////////////////////
//------- �F���������Ұ�
void CogSearchParaCheck(CogSearchPara& P,int ww,int hh,int ResultsMax)	// �F���������Ұ��̐���������
	// ���Ұ����͈͊O�̏ꍇ�́A�͈͓��ɒ�������
{
	int	cwmin,cwmax,chmin,chmax,sz1,sz2;
	cwmin = -(ww-1)/2;	cwmax = ww/2;
	chmin = -(hh-1)/2;	chmax = hh/2;
	if(P.MCentX < (cwmin+2))	P.MCentX = cwmin+2;
	if(P.MCentX > (cwmax-2))	P.MCentX = cwmax-2;
	if(P.MCentY < (chmin+2))	P.MCentY = chmin+2;
	if(P.MCentY > (chmax-2))	P.MCentY = chmax-2;

	sz1 = P.MCentX - cwmin;
	sz2 = cwmax - P.MCentX;
	if(sz1 > sz2)	sz1 = sz2;
	sz1 = sz1 * 2;
	if(P.MSizeX > sz1)	P.MSizeX = sz1;

	sz1 = P.MCentY - cwmin;
	sz2 = cwmax - P.MCentY;
	if(sz1 > sz2)	sz1 = sz2;
	sz1 = sz1 * 2;
	if(P.MSizeY > sz1)	P.MSizeY = sz1;

	if(P.SCentX < (cwmin+2))	P.SCentX = cwmin+2;
	if(P.SCentX > (cwmax-2))	P.SCentX = cwmax-2;
	if(P.SCentY < (chmin+2))	P.SCentY = chmin+2;
	if(P.SCentY > (chmax-2))	P.SCentY = chmax-2;

	sz1 = P.SCentX - cwmin;
	sz2 = cwmax - P.SCentX;
	if(sz1 > sz2)	sz1 = sz2;
	sz1 = sz1 * 2;
	if(P.SSizeX > sz1)	P.SSizeX = sz1;

	sz1 = P.SCentY - cwmin;
	sz2 = cwmax - P.SCentY;
	if(sz1 > sz2)	sz1 = sz2;
	sz1 = sz1 * 2;
	if(P.SSizeY > sz1)	P.SSizeY = sz1;

	if(P.Accept < 0)		P.Accept = 0;
	if(P.Accept > 1000)		P.Accept = 1000;
	if(P.Confusion < 0)		P.Confusion = 0;
	if(P.Confusion > 1000)	P.Confusion	= 1000;
	if(P.Results < 1)		P.Results	= 1;
	if(P.Results > ResultsMax)		P.Results	= ResultsMax;
}
//--------------------------------------------------------------------
// #K1034 00-07-17 ������ܰ�̓_�����݂�ϼ����Ұ��Őݒ�\�Ȃ悤�ɂ���
BOOL GWPPfileData(
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			SignalTowerData&	Data,			// �ް��i�[
			SignalTowerData	DataD)		// ��̫���ް�
{
	int	r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                        NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			int	R,Y,G,B,BzA,BzB;
			if(sscanf(inBuf,"%d ,%d ,%d ,%d ,%d, %d",&R,&Y,&G,&B,&BzA,&BzB) != 6){
				r = FALSE;
			}
			else{
				Data.SigR = R;
				Data.SigY = Y;
				Data.SigG = G;
				Data.SigB = B;
				Data.BzzA = BzA;
				Data.BzzB = BzB;
			}
		}
		if(!r){
			Data = DataD; 
		}
	}
	else{
		CString	str;
		str.Format("%d,%d,%d,%d,%d,%d",Data.SigR,Data.SigY,Data.SigG,Data.SigB,Data.BzzA,Data.BzzB);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
// #K1135 00-11-15 �ŏ��E�ő�l�ް��ǉ�
BOOL GWPPfileData(					// LightLevelData �^
			LPCTSTR	lpFileName, 	// points to initialization filename 
			LPCTSTR	lpszSection,	// address of section name
			LPCTSTR	lpszKey,		// address of key name
			BOOL	Get,			// TRUE:���o���w��@FALSE:�������ݎw��
			MaxMinData&	Data,		// �ް��i�[
			MaxMinData	DataD)		// ��̫���ް�
{
	int	r=TRUE;
	if(Get){
		char	inBuf[80];
		r = GetPrivateProfileString (lpszSection,lpszKey,
	                        NULL,inBuf,80,lpFileName); 
		if(r){
			r = TRUE;
			double	min, max;
			if(sscanf(inBuf,"%lf ,%lf",&min,&max) != 2){
				r = FALSE;
			}
			else{
				Data.Min = min;
				Data.Max = max;
			}
		}
		if(!r){
			Data = DataD; 
		}
	}
	else{
		CString	str;
		str.Format("%10.10lf,%10.10lf",Data.Min,Data.Max);
		r = WritePrivateProfileString (lpszSection,lpszKey,str,lpFileName); 
	}
	return	r;
}
//--------------------------------------------------------------------
// MemDC.h: interface for the CMemDC class.
//
// Author: Ovidiu Cucu
// Homepage: http://www.codexpert.ro/
// Weblog: http://codexpert.ro/blog/

#pragma once


class CMemDC : public CDC  
{
	DECLARE_DYNAMIC(CMemDC)

	int m_nSavedDC;
	CBitmap m_bitmap;
	unsigned char* m_pBits;
	HBITMAP m_hBitmap;
	CBitmap* oldBitMap;
public:
	CMemDC(CDC* pDC, int nWidth, int nHeight);
	CMemDC(CDC* pDC, CBitmap* pBitmap);
	~CMemDC();
};

inline CMemDC::CMemDC(CDC* pDC, int nWidth, int nHeight)
{
	ASSERT_VALID(pDC);
	VERIFY(CreateCompatibleDC(pDC));

	m_nSavedDC = SaveDC();
	BITMAPINFO bmi;
	memset(&bmi, 0, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biWidth = nWidth;
	bmi.bmiHeader.biHeight = -nHeight; // top-down
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biCompression = BI_RGB;
	m_hBitmap = CreateDIBSection(pDC->m_hDC, &bmi, DIB_RGB_COLORS, (void**)&m_pBits, NULL, NULL);
	m_bitmap.Attach(m_hBitmap);
	oldBitMap = SelectObject(&m_bitmap);
}

inline CMemDC::CMemDC(CDC* pDC, CBitmap* pBitmap)
{
	ASSERT_VALID(pDC);
	ASSERT_VALID(pBitmap);

	VERIFY(CreateCompatibleDC(pDC));
	SelectObject(pBitmap);
}

inline CMemDC::~CMemDC()
{
	RestoreDC(m_nSavedDC);
	SelectObject(oldBitMap);
	m_bitmap.Detach();
	DeleteObject(m_hBitmap);
	if(NULL != m_bitmap.GetSafeHandle())
	{
	  m_bitmap.DeleteObject();
	}
	DeleteDC();
}


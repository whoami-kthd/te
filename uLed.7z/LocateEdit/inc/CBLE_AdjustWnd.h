///////////////////////////////////////////////////////////
//  CBLE_AdjustWnd.h
//  Implementation of the Class CBLE_AdjustWnd
//  Created on:      16-Thg7-2013 10:25:31 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_93359C09_7195_4ff3_AD48_7E0312926812__INCLUDED_)
#define EA_93359C09_7195_4ff3_AD48_7E0312926812__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_LayoutWnd.h"
#include "CBLE_CommonWnd.h"
#include "CBLE_InfoWnd.h"
#include "CBLE_NumKeyWnd.h"


// CBLE_AdjustWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_AdjustWnd dialog

class CBLE_AdjustWnd : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CBLE_LayoutWnd* m_LayoutWnd;
	CBLE_CommonWnd m_CommWnd;
	CBLE_InfoWnd m_InfoWnd;
	CBLE_NumKeyWnd m_KeyWnd;

	int m_nZoom;
	int m_nRegNo;
	bool m_bInit;

// Construction
public:
	//CBLE_CommonWnd m_CommWnd;
	CBLE_AdjustWnd(CWnd* pParent = NULL);   // standard constructor
	enum { IDD = IDD_ADJUST_DLG };
	

// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	
	// For Undo function
	virtual BOOL PreTranslateMessage(MSG* pMsg);

// Implementation
public:
	void CloseWnd(); //THAIHV 20151124 (C)
	void InitView();
	void SetDocument(CBLE_Doc* pDoc);
	void AllowSelectDeletedIC();
	virtual ~CBLE_AdjustWnd();
	CBLE_CommonWnd* GetCommdWnd();
	CBLE_LayoutWnd* GetLayoutWnd();
	CBLE_InfoWnd* GetInfoWnd();
	void ChangeLanguage();
	afx_msg void OnUpdateRegNo();
	afx_msg void OnZoom(); // Zoom by combobox

	void SetRegNo(int regNo);

// Implementation
protected:
	// Message
	afx_msg LRESULT OnUpdateView(WPARAM wParam, LPARAM lParam); // Update view when a child window is changed
	afx_msg LRESULT OnUpdateZoom(WPARAM wParam, LPARAM lParam); // Zoom by mouse wheel
	afx_msg LRESULT OnChangeSelectIC(WPARAM wParam, LPARAM lParam); // Update the selected ICs
	afx_msg LRESULT OnDisplayFocusIC(WPARAM wParam,LPARAM lParam); // Display focus IC in real-time display mode
	afx_msg void OnChangeZoom(UINT nID); // Zoom by ZoomIn/ZoomOut button
	afx_msg void OnChangeRegNo(); // Change RegNo by combobox
	afx_msg void OnStartExpandWnd();
	afx_msg void OnStartOffsetWnd();
	afx_msg void OnRegNoButton(UINT nID); //Response to Up/Down regno button
	afx_msg void OnIndexDisplay(); // Response to index display button
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnClearAllOffset();
	afx_msg void OnDestroy();
	afx_msg LRESULT OnChangeRevKeyWnd(WPARAM wParam,LPARAM lParam); // Update the selected ICs
	DECLARE_MESSAGE_MAP()

private:
	void CheckBtnState();
	BOOL CheckExpandCondition();
};


#endif // !defined(EA_93359C09_7195_4ff3_AD48_7E0312926812__INCLUDED_)

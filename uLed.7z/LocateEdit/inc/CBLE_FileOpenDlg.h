#if !defined(AFX_ABAIMPORTDIALOG_H__69A447FB_CE76_4BB6_86E8_428DEF9A99B0__INCLUDED_)
#define AFX_ABAIMPORTDIALOG_H__69A447FB_CE76_4BB6_86E8_428DEF9A99B0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CBLE_FileOpendDlg.h : header file
//

class CBLE_FileOpenDlg : public CFileDialog
{
	DECLARE_DYNAMIC(CBLE_FileOpenDlg)

public: 
	int m_Language;

public:
	CBLE_FileOpenDlg(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

	virtual ~CBLE_FileOpenDlg();

protected:
	virtual BOOL OnInitDialog();

};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ABAIMPORTDIALOG_H__69A447FB_CE76_4BB6_86E8_428DEF9A99B0__INCLUDED_)

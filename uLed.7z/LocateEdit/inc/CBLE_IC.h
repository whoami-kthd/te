///////////////////////////////////////////////////////////
//  CBLE_IC.h
//  Implementation of the Class CBLE_IC
//  Created on:      12-Thg7-2013 1:52:09 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_5C0EB08D_5467_46ef_B1A4_233BCE11A102__INCLUDED_)
#define EA_5C0EB08D_5467_46ef_B1A4_233BCE11A102__INCLUDED_

#pragma once
#include "CBLE_DEF.h"
#include "pos.h"

class CBLE_IC : public CObject
{

public:
// Attributes
	TBLE_RegIC* m_pRegIC;
	int m_indexX;
	int m_indexY;
	double m_OffsetX;
	double m_OffsetY;
	double m_BgPosX;
	double m_BgPosY;
	double m_TargetBgPosX; // For expand function
	double m_TargetBgPosY; // For expand function
	double m_TargetTheta;
	/**
	 * the current Angle of IC
	 */
	double m_OffsetT;
	
	// Substrate info statuses

	DBLE_DetectState m_DetectL;
	DBLE_DetectState m_DetectR;
	DBLE_BondState m_BondingL;
	DBLE_BondState m_BondingR;

	// Stack count
	int m_StackCountL;
	int m_StackCountR;

	// Editing statuses
	bool m_Deleted;
	bool m_Selected;
	bool m_Overlapped;
	bool m_Clickable;
	bool m_OutsideSubStrate;
	bool m_BeingFocus;

	// Status for moved IC
	bool m_IsMovedL;
	bool m_IsMovedR;

	bool m_SelectedL;
	bool m_SelectedR;


public:
	DECLARE_SERIAL(CBLE_IC)

	// Operator
	CBLE_IC(TBLE_RegIC* pRegIC = NULL, int idxX = -1, int idxY = -1);
	CBLE_IC(const CBLE_IC &ic);
	inline CBLE_IC operator=(const CBLE_IC& element) {
		CopyData(element);
		return *this;		
	}
	virtual ~CBLE_IC();
	void SetIcProperties(TBLE_RegIC* pRegIC, int idxX, int idxY);		// Set properties of IC if properties of regNo is changed
	void Draw(CDC* pDC, double scale, DBLE_MODE mode, TBLE_StatusColor* stColor = NULL, bool drawRegNo = true, bool selectable = true, int dir = 0);
	void DrawIndex(CDC* pDC, double scale, bool xAxis);
	BOOL Click(R2Pos point, DBLE_MODE mode, bool selectDeleted = false);
	//BOOL IntersectRect(CRect rect, DBLE_MODE mode);
	BOOL IntersectRect(R2Pos p1, R2Pos p2, DBLE_MODE mode, bool selectDeleted = false);
	void Delete();
	void Restore();
	bool CheckOverlap(CBLE_IC* pIC);
	void GetICPoint(vector<R2Pos> &vPoint, double scale = 0, bool checkSize = false);

	double GetPosX();
	double GetPosY();

	// Set Moved status
	void SetMoved(bool isMoved, int dir);

	// Serialize
	void Serialize(CArchive& archive);

	// Copy data
	void CopyData(CBLE_IC ic);
	bool CompareIC(CBLE_IC ic);
	double GetDistanceToICBorder(R2Pos point);
private:
	bool CheckColor(COLORREF color);

};
#endif // !defined(EA_5C0EB08D_5467_46ef_B1A4_233BCE11A102__INCLUDED_)

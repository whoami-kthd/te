#if !defined(AFX_CBLE_INFOWND_H__CE980C4A_00C9_4CD2_A53C_203204FE86FD__INCLUDED_)
#define AFX_CBLE_INFOWND_H__CE980C4A_00C9_4CD2_A53C_203204FE86FD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_GridCtrl.h"

// CBLE_InfoWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_InfoWnd dialog

class CBLE_InfoWnd : public CDialog
{

private:
	CBLE_Doc* m_pDoc;
	CBLE_GridCtrl* m_pGridCtrl;
	DBLE_MODE m_DisplayMode; //store display mode
// #DDT(20140624): Add mode for InfoDlg
	int m_SubInfoDir;			// subinfo L or R

// Construction
public:
	CBLE_InfoWnd(CWnd* pParent = NULL);   // standard constructor
	enum { IDD = IDD_INFORMATION_DLG };
	void ChangeLanguage();

// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();

	// Implementation
public:
	void SetDocument(CBLE_Doc* pDoc);
	void SetDisplayMode(DBLE_MODE mode);
	void UpdateGridData();
	void DisplayFocusIC();
	virtual ~CBLE_InfoWnd();
	CWnd* GetEditWnd();
	// #DDT(20140624): Add for InfoDlg mode
	void SetSubInfoDir(int dir);

	afx_msg void OnIndexJump();
	afx_msg void OnIndexSend();
	afx_msg LRESULT OnDisplayRealTime();
	afx_msg LRESULT OnUpdateGrid(WPARAM wParam, LPARAM lParam); // Response when press a key in keyboard
	afx_msg virtual void OnLButtonDown(UINT nFlags, CPoint point); // using mouse click event to determine if info or common window is active
	DECLARE_MESSAGE_MAP()

private:
	void InitGridCtrl();
	
};


#endif // !defined(AFX_CBLE_INFOWND_H__CE980C4A_00C9_4CD2_A53C_203204FE86FD__INCLUDED_)

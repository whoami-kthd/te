///////////////////////////////////////////////////////////
//  CBLE_LocateEditWnd.h
//  Implementation of the Class CBLE_LocateEditWnd
//  Created on:      16-Thg7-2013 10:25:24 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_A83821BC_6A10_4fa1_A5C8_99013C834711__INCLUDED_)
#define EA_A83821BC_6A10_4fa1_A5C8_99013C834711__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_LayoutWnd.h"
#include "CBLE_CommonWnd.h"
#include "CBLE_InfoWnd.h"
#include "CBLE_NumKeyWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CBLE_LocateEditWnd dialog

class CBLE_LocateEditWnd : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CBLE_LayoutWnd* m_LayoutWnd;
	CBLE_CommonWnd m_CommWnd;
	CBLE_InfoWnd m_InfoWnd;
	CBLE_NumKeyWnd m_KeyWnd;

	int m_nZoom;
	int m_nRegNo;
	int m_bInit;

// Construction
public:
	//CBLE_CommonWnd m_CommWnd;
	//CBLE_Doc* m_pDoc;
	CBLE_LocateEditWnd(CWnd* pParent = NULL);   // standard constructor
	enum { IDD = IDD_LOCATE_EDIT_DLG };
	void ChangeLanguage();
	
// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();

	// For Undo function
	virtual BOOL PreTranslateMessage(MSG* pMsg);

// Implementation
public:
	void CloseWnd();    //THAIHV 20151124 (C)
	void InitView();
	void SetDocument(CBLE_Doc* pDoc);
	void AllowSelectDeletedIC();
	virtual ~CBLE_LocateEditWnd();
	CBLE_CommonWnd* GetCommdWnd();
	CBLE_LayoutWnd* GetLayoutWnd();
	CBLE_Doc* GetDocument();
	int GetZoomScale();
	void SetRegNo(int regNo);
	CBLE_NumKeyWnd* GetNumKeyWnd();
	void UpdateComboBox();
	CBLE_InfoWnd* GetInfoWnd();
	void DeleteSelectedIC();

	// Message
	afx_msg LRESULT OnUpdateView(WPARAM wParam, LPARAM lParam); // Update view when a child window is changed
	afx_msg LRESULT OnUpdateZoom(WPARAM wParam, LPARAM lParam); // Zoom by mouse wheel
	afx_msg LRESULT OnUpdateRegNo(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnChangeSelectIC(WPARAM wParam,LPARAM lParam); // Update the selected ICs
	afx_msg LRESULT OnDisplayFocusIC(WPARAM wParam,LPARAM lParam); // Display focus IC in real-time display mode
	afx_msg void OnZoom(); // Zoom by combobox
	afx_msg void OnChangeZoom(UINT nID); // Zoom by ZoomIn/ZoomOut button
	afx_msg void OnChangeRegNo(); // Change RegNo by combobox
	afx_msg void OnDelete(); // Response Delete button
	afx_msg void OnRestore(); // Response Restore button
	afx_msg void OnChangeDisplayMode(); // Response Invalid Display button
	afx_msg void OnCheckReflect(); // Response Check&Reflect button
	afx_msg void OnIndexDisplay(); // Response Index Display button
	afx_msg void OnAllRestore(); // Response All Restore button
	afx_msg void OnRegNoButton(UINT nID); //Response Up/Down regno button
	afx_msg void OnSize(UINT nType, int cx, int cy); 
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnAnsTimer(WPARAM wParam, LPARAM lParam);
	afx_msg void OnDestroy( );
	afx_msg LRESULT OnChangeRevKeyWnd(WPARAM wParam,LPARAM lParam); // Update the selected ICs
	DECLARE_MESSAGE_MAP()
		
private:
	void CheckBtnState();

};
#endif // !defined(EA_A83821BC_6A10_4fa1_A5C8_99013C834711__INCLUDED_)


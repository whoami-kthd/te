///////////////////////////////////////////////////////////
//  CBLE_Model.h
//  Implementation of the Class CBLE_Model
//  Created on:      12-Thg7-2013 2:56:05 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_774CF48C_DC37_4824_A11E_0676C7A2B672__INCLUDED_)
#define EA_774CF48C_DC37_4824_A11E_0676C7A2B672__INCLUDED_

#pragma once
#include "CBLE_Substrate.h"
#include "CBLE_DEF.h"
#include "..\\BLE.h"
#include "CBLE_Memento.h"
// Define string for data fine name
#define DBLE_MODEL_DV190_NAME				"dv_.190"
#define DBLE_MODEL_DV290_NAME				"dv_.290"
#define DBLE_MODEL_DV390_NAME				"dv_.390"
#define DBLE_MODEL_DV100_NAME				"dv_.100"
#define DBLE_MODEL_DV200_NAME				"dv_.200"
#define DBLE_MODEL_DV300_NAME				"dv_.300"
#define DBLE_MODEL_MC000_NAME				"mc_.000"
#define DBLE_BINARY_FILE					"dv_.191"

#define	DBLE_SUBINFO_FRMDIR_LEFT					2
#define	DBLE_SUBINFO_FRMDIR_RIGHT					3
#define DBLE_SUBINFOWND_SIZEX						550
#define DBLE_SUBINFOWND_SIZEY						520//475

class CBLE_Model : public CObject
{
private:
	CBLE_Substrate					m_Substrate;
	CString							m_strLocateEditIniFilePath;							// file path of LocateEdit.ini
	CString							m_strSubInfoIniFilePath;							// file path of SubInfo.ini
	CString							m_strDataFilePath;									// file path of data file (like: "*\\dv_.")
	CString							m_strMachineFilePath;								// file path of machine data file (like: "*\\mc_.")
	int								m_isSubComplex;
	int								m_frameDir[2];
public:
	vector<TBLE_RegIC>				m_vRegIC;
	TBLE_Init						m_Init;
	vector<TBLE_Subs_Shape>			m_vShape;
	TBLE_StatusColor				m_StatusColor;
	TBLE_Mapping					m_MapData;
	int								m_ProcessIndex;
	bool							m_bStartProgress;
	HANDLE							m_StopThread;

public:
	CBLE_Model();
	virtual ~CBLE_Model();

	DECLARE_SERIAL(CBLE_Model)

	CBLE_Substrate* GetSubstrate();

	void SetLocateEditIniFilePath(CString filePath);					// set file path of LocateEdit.ini
	CString GetLocateEditIniFilePath();									// get file path of LocateEdit.ini
	void SetSubInfoIniFilePath(CString filePath);						// set file path of SubInfo.ini
	void SetDataFilePath(CString filePath);								// set file path of data files
	void SetDataFilePath();												// read FCB.INI and set data file path
	CString GetDataFilePath();											// Get file path
	void SetMachineFilePath();											// set machine data file path
	void SetMachineFilePath(CString filePath);							// read FCB.INI and set machine data file path
	int GetSubComplexMode();											// read subcomplex mode from dv_.100 file
	CString GetMachineFilePath();
	bool GetDataFromFolder(CString folderPath);							// read data of a folder
	void GetDataFromFile(CString filePath1, CString filePath2, CString filePath3);			// filePath1: path+name of dv_.190, filePath3: path+name of dv_.390
	bool SaveDataToFile();
	void ReleaseData();
	void CreateAllIC(vector<TBLE_RegIC> vOldRegIC);
	void UpdateRegNo(vector<TBLE_RegIC> vRegIC, bool isChangeShape);
	void InitEditModeSetting();
	void InitSubInfoModeSetting();
	void InitShapeName();
	int	GetAutoToolChange();
	int GetColletteNumber();
	int GetEjectorNumber();
	int GetMappMethod();
	void SavePassword(CString newPass, int level);
	void DisplayModeRW(bool read, int subMode, int &displayMode);
	bool StatusRW(bool read, LPCTSTR lpFileName, DBLE_SUBINFO_TYPE lrMode, int bdMode);
	void SaveColor();
	void ConvertRGBColor(COLORREF color, int &r, int &g, int &b);
	long GetSectionIndex(const char *section, const char *sourceBuff);
	bool IsMatchedString(const char *desStr, const char *srcStr);
	bool FileNotFound(CString filePath);
	int	 GetFrmDir(int side);
	void SetFrmDir(int side, int dir);

	// Read/Write ICs information from dv_.*90 file
	bool RegNoDataRW(bool read, LPCTSTR lpFileName, char* buff = NULL);
	bool SubstrateShapeDataRW(bool read, LPCTSTR lpFileName, char* buff = NULL);
	bool IcsDataRW(bool read, LPCTSTR lpFileName);
	bool MappingDataRW(bool read, LPCTSTR lpFileName);
	bool OffsetXYDataRW(bool read, LPCTSTR lpFileName, char* buff = NULL);
	bool OffsetTDataRW(bool read, LPCTSTR lpFileName, char* buff = NULL);
	bool LocateValidDataRW(bool read, LPCTSTR lpFileName, char* buff = NULL);

	// Read/Write file function
	bool GWPPfileDataDelete(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey = NULL);
	int	 GetPrivateProfileStringFromBuff(const char *entry, const char *def, char *buffer, int buffer_len, long startIdx, char* sourceBuff);
	bool GWPPfileData(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey, bool read, double data[], int numb, double dataD, int kmode, bool hasToAdd = false, char* srcBuff = NULL, long startSecIdx = 0);
	bool GWPPfileData(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey, bool read, R2Pos data[], int numb, R2Pos dataD, int kmode, bool hasToAdd = false, char* srcBuff = NULL, long startSecIdx = 0);
	bool GWPPfileData(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey, bool read, int data[], int numb, int dataD, bool hasToAdd = false, char* srcBuff = NULL, long startSecIdx = 0);
	bool GWPPfileData(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey, bool read, int &data, int dataD, char* srcBuff = NULL, long startSecIdx = 0);
	bool GWPPfileData(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey, bool read, double &data, double dataD, int kmode, char* srcBuff = NULL, long startSecIdx = 0);
	bool GWPPfileData(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey, bool read, R2Pos &data, R2Pos dataD, int kmode, char* srcBuff = NULL, long startSecIdx = 0);
	bool GWPPfileData(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey, bool read, CString &data, CString dataD, char* srcBuff = NULL, long startSecIdx = 0);
	bool GWPPfileData(LPCTSTR lpFileName, LPCTSTR lpszSection, LPCTSTR lpszKey, bool read, CString data[], int numb, CString dataD, char* srcBuff = NULL, long startSecIdx = 0);

// #DDT140116: For setting color
	void SaveSettingColor();

	// Serialize
	void Serialize(CArchive& archive);

// For undo function
	// Create memento
	CBLE_Memento CreateMemento(int kind, bool all = false, int regNo = 0);
	// Restore state
	void RestoreState();
	int CalIndex(CBLE_IC ic);

	CString GetBarcode(int lr);
	BOOL LoadMapData(CString barcode, int lr, vector<CBLE_IC> &vIC);
private :
	void GetNumberOfElement(int arr[], int &numb, int max);
	
};
#endif // !defined(EA_774CF48C_DC37_4824_A11E_0676C7A2B672__INCLUDED_)

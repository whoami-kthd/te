///////////////////////////////////////////////////////////
//  CBLE_NumKeyWnd.h
//  Implementation of the Class CBLE_NumKeyWnd
//  Created on:      16-Thg7-2013 11:51:16 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_96EDC1E7_C7F5_437f_A3FA_E55536CF3BAC__INCLUDED_)
#define EA_96EDC1E7_C7F5_437f_A3FA_E55536CF3BAC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CBLE_NumKeyWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_NumKeyWnd dialog

class CBLE_NumKeyWnd : public CDialog
{
private:
	// The window to receive key
	CWnd* m_pRevWnd;

// Construction
public:
	CBLE_NumKeyWnd(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_NumKeyWnd();
	enum { IDD = IDD_NKEY_DLG };
	

	BOOL Create(CWnd* pRevWnd, UINT nIDTemplate, CWnd* pParentWnd = NULL);
	void SetReceiveKeyWindow(CWnd* pRevWnd); // set receive key window

// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnCancel();
	virtual void OnOK();


// Implementation
public:
	afx_msg void OnKey(UINT nID);
	DECLARE_MESSAGE_MAP()
};


#endif // !defined(EA_96EDC1E7_C7F5_437f_A3FA_E55536CF3BAC__INCLUDED_)

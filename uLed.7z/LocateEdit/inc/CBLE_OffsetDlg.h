///////////////////////////////////////////////////////////
//  CBLE_OffsetDlg.h
//  Implementation of the Class CBLE_OffsetDlg
//  Created on:      16-Thg7-2013 1:30:47 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_9DB82DF1_A88B_4ebc_8FF7_672F350F252B__INCLUDED_)
#define EA_9DB82DF1_A88B_4ebc_8FF7_672F350F252B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CBLE_Doc.h"
#include "CBLE_GridCtrl.h"
#include "CBLE_NumKeyWnd.h"


enum DBLE_OFFSET_DLG_MODE
{
	DBLE_OFFSET_DLG_MODE_OFFSET = 0,
	DBLE_OFFSET_DLG_MODE_EXPAND
};

// CBLE_OffsetDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_OffsetDlg dialog

class CBLE_OffsetDlg : public CDialog
{

private:
	DBLE_OFFSET_DLG_MODE m_Mode;
	CBLE_Doc* m_pDoc;
	CBLE_GridCtrl* m_pGridCtrl;
	CBLE_NumKeyWnd m_KeyWnd;

// Construction
public:
	CBLE_OffsetDlg(DBLE_OFFSET_DLG_MODE mode = DBLE_OFFSET_DLG_MODE_OFFSET,
		CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_OffsetDlg();
	enum { IDD = IDD_OFFSET_DLG };
	void SetDocument(CBLE_Doc* pDoc);
	void ChangeLanguage();

	// For undo function
	void OnRestoreState();

// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnClose();
	virtual void OnCancel();
	virtual void OnOK();
	virtual BOOL OnInitDialog();

	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	afx_msg void OnCheckReflect();
	afx_msg void OnAllOffset();
	afx_msg void OnForceOk();
	afx_msg LRESULT OnUpdateGrid(WPARAM wParam, LPARAM lParam); // Response when press a key

	DECLARE_MESSAGE_MAP()

private:
	void InitGridCtrl();
	void AddGridData();
};
#endif // !defined(EA_9DB82DF1_A88B_4ebc_8FF7_672F350F252B__INCLUDED_)
	

	
	
	
	


#if !defined(AFX_CBLE_PROGRESSBAR_H__536115A9_E516_452B_A05D_3DCA5BA232D9__INCLUDED_)
#define AFX_CBLE_PROGRESSBAR_H__536115A9_E516_452B_A05D_3DCA5BA232D9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CBLE_ProgressBar.h : header file
//
#include "..\\BLE.h"
#include "CBLE_Doc.h"

/////////////////////////////////////////////////////////////////////////////
// CBLE_ProgressBar dialog

class CBLE_ProgressBar : public CDialog
{
// Construction
public:
	CBLE_ProgressBar(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_ProgressBar();

	virtual BOOL OnInitDialog();
	void SetDocument(CBLE_Doc* pDoc);

public:
	CBLE_Doc*						m_pDoc;
	CWinThread*						m_pProgThread;
	HANDLE							m_StopThread;
	HANDLE							m_StopUpdate;
	DBLE_ProgressBarType			m_Type; // determine what kind of processing will be used: check reflect or create all region
	bool							m_bDisplay;
	bool							m_bResult; // result of thread
	CString							m_FolderPath; // use to store path to data folder
	UINT_PTR						m_OpenTimerID;
// Dialog Data
	//{{AFX_DATA(CBLE_ProgressBar)
	enum { IDD = IDD_PROGRESSBAR_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	static UINT CheckReflectProc(LPVOID pParam);
	static UINT CheckReflectSelectOnly(LPVOID pParam);
	static UINT SaveDataThread(LPVOID pParam);
	static UINT OpenDataThread(LPVOID pParam);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBLE_ProgressBar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	afx_msg virtual void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) ;
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBLE_ProgressBar)
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	LRESULT OnAutoClose(WPARAM wParam,LPARAM lParam);
	afx_msg void OnTimer(UINT nIDEvent); // function to auto update progress bar

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CBLE_PROGRESSBAR_H__536115A9_E516_452B_A05D_3DCA5BA232D9__INCLUDED_)

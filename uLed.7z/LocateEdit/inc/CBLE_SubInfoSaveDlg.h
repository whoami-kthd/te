///////////////////////////////////////////////////////////
//  CBLE_SubInfoSaveDlg.h
//  Implementation of the Class CBLE_SubInfoSaveDlg
//  Created on:      2013-09-19
//  Original author: DucDT
///////////////////////////////////////////////////////////
#pragma once

#include "CBLE_Doc.h"
#include "CBLE_FullKeyWnd.h"
#include "CBLE_EditCtrl.h"

// CBLE_SubInfoSaveDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBLE_SubInfoSaveDlg dialog

class CBLE_SubInfoSaveDlg : public CDialog
{
private:
	CBLE_Doc* m_pDoc;
	CBLE_FullKeyWnd m_KeyWnd;
	CString m_FileName;
	// Edit box
	CBLE_EditCtrl m_Edit;

	DBLE_SUBINFO_TYPE m_SubInfoMode;
	int m_BondDetectMode;
// Construction
public:
	CBLE_SubInfoSaveDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CBLE_SubInfoSaveDlg();
	enum { IDD = IDD_SUBINFO_SAVE_DLG };

	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	virtual void OnOK();
	virtual void OnClose();

	void SetDocument(CBLE_Doc* pDoc);
	void SetModeLR(DBLE_SUBINFO_TYPE lr);
	void SetStatusMode(int mode);
	void InitView();
	void UpdateView();
	CString GetFileName();


// Overrides
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	afx_msg void OnSaveCancel();
	afx_msg void OnSaveOK();
	afx_msg virtual void OnLButtonDown(UINT nFlags, CPoint point);
	LRESULT OnUpdateValue(WPARAM wParam, LPARAM lParam);

// Implementation
protected:

	DECLARE_MESSAGE_MAP()
};


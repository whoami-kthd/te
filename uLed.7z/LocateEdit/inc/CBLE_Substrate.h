///////////////////////////////////////////////////////////
//  CBLE_Substrate.h
//  Implementation of the Class CBLE_Substrate
//  Created on:      12-Thg7-2013 2:12:09 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if !defined(EA_870D9E87_87BB_4ee7_9A4C_069C9F9CE302__INCLUDED_)
#define EA_870D9E87_87BB_4ee7_9A4C_069C9F9CE302__INCLUDED_

#pragma once
#include "CBLE_IC.h"


struct TBLE_IC_Region
{
	R2Pos m_Pos1;
	R2Pos m_Pos2;
	vector<CBLE_IC*> m_vIC;
public:
	TBLE_IC_Region();
	void PushIC(CBLE_IC* pIC);
	void PopIC(CBLE_IC* pIC);
};


class CBLE_Substrate : public CObject
{

public:	
	DBLE_SUBSTRATE_SHAPE m_Shape;
	int m_SizeX;
	int m_SizeY;
	int m_ShapeID;

	// Used to display index of IC
	CPoint m_DisplayCenter;
	CRect m_DisplayRect;
	CPoint m_RealTopLeft;

	// Allow select deleted 
	bool m_bSelectDeleted;
	/**
	 * The vector of all IC in this substrate
	 */
	vector<CBLE_IC*> m_vIC;
	/**
	 * The vector of all selected IC in this substrate
	 */
	vector<CBLE_IC*> m_vSelIC;
	// #DDT(20140624): Add vector selected ICs for left&right
	vector<CBLE_IC*> m_vSelICL;
	vector<CBLE_IC*> m_vSelICR;

	// Focused IC
	CBLE_IC* m_pFocusIC;

	bool m_bDisplayRealTime;

	vector<TBLE_IC_Region> m_vRegion;

	int m_NeighborLimit;

public:
	CBLE_Substrate();
	virtual ~CBLE_Substrate();

	DECLARE_SERIAL(CBLE_Substrate)

	bool ICInSubstrate(CBLE_IC* pIC);
	void MouseDown(UINT nFlags, R2Pos point, DBLE_MODE mode, int RegNo, int lr = 0);
	//void MouseUp(CRect rect, DBLE_MODE mode, int RegNo);
	void MouseUp(R2Pos p1, R2Pos p2, DBLE_MODE mode, int RegNo, int lr = 0);
	void SetScale(double scale);

	void Draw(CDC* pDC, CRect rect, DBLE_MODE mode, int RegNo, TBLE_StatusColor* stColor = NULL, int dir = 0, int indexDisplay = 0);
	void ResetData(bool hasToClearICs = true);
	void AddRegNo(TBLE_RegIC* pRegNo, TBLE_RegIC* pOldRegNo);
	void EraseNotNeedOldIC();
	// Set shape for substrate
	void SetShape(int shapeName, DBLE_SUBSTRATE_SHAPE shape, int sizeX, int sizeY);

	void SetNeighborLimit(int limit);

	void SelectIC(CBLE_IC* pIC, int lr = 0);
	void DeselectIC(CBLE_IC* pIC, int lr = 0);
	void DeselectAll(int lr = 0);
	void RestoreAll(int regNo);
	void ClearAllOffset(int regNo);
	void ClearSelICOffset();
	bool CheckSelIC(); // Check if any selected IC got overlapped
	int FindMaxXIndex(int regNo, double scale, DBLE_MODE mode);
	int FindMaxYIndex(int regNo, double scale, DBLE_MODE mode);
	bool ICInRegion(vector<R2Pos> vICPnt, TBLE_IC_Region region);
	bool PerformanceChecking(bool isSaving = false); // Checking performance of PC: true: display progress bar, false: do not display progress bar
	void FocusOnIC(R2Pos point, DBLE_MODE mode, int RegNo, int lr = 0);

	// Get the size of border
	CSize GetBorderSize();
	int	GetICNumbers() {
		return m_vIC.size();
	}

	void CheckRegionSelectedICs();
	void SetRegionAllICs();

	// Serialize
	void Serialize(CArchive& archive, vector<TBLE_RegIC>* vRegIC);

private:
	void CreateRegions();
	bool PointInRegion(R2Pos point, TBLE_IC_Region region);
	bool HasToDraw(CBLE_IC *ic, double scale);
	
};
#endif // !defined(EA_870D9E87_87BB_4ee7_9A4C_069C9F9CE302__INCLUDED_)

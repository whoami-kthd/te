///////////////////////////////////////////////////////////
//  CBLE_AdjustWnd.cpp
//  Implementation of the Class CBLE_AdjustWnd
//  Created on:      16-Thg7-2013 10:25:31 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_AdjustWnd.h"
#include "CBLE_OffsetDlg.h"
#include "CBLE_ExpandDlg.h"
#include "CBLE_Util.h"
#include "CBLE_CareTaker.h"
#include "CBLE_FrameWnd.h"

#define DBLE_ADJWND_SIZEX				600
#define DBLE_ADJWND_SIZEY				500
#define DBLE_ADJWND_MINSCALE			1.0

#define DBLE_ADJWN_OPERATION_SIZEX		300
#define DBLE_ADJWN_OPERATION_SIZEY		200
#define DBLE_ADJWN_MARGIN_SIZEX			140

#define DBLE_ADJWN_10KEY_WIDTH			170		// 10KEY��Width,Height
#define DBLE_ADJWN_10KEY_HEIGHT			140

#define DBLE_ADJWN_INFO_WIDTH			400		// Information��Width,Height
#define DBLE_ADJWN_INFO_HEIGHT			60

//#define WARNING_MESSAGE_CLEAROFFSET		_T("Are you sure want to clear all offset?")

/////////////////////////////////////////////////////////////////////////////
// Define message text for Japanese and English
//
CString ClearAllOffset[] = {							
								_T("�I�t�Z�b�g�����ׂč폜���܂����H"),
								_T("Are you sure want to clear all offset?"),
							};

/////////////////////////////////////////////////////////////////////////////
// CBLE_AdjustWnd dialog


CBLE_AdjustWnd::CBLE_AdjustWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_AdjustWnd::IDD, pParent)
{
	m_pDoc = NULL;
	m_nZoom = 0;
	m_nRegNo = 0;
	m_LayoutWnd = NULL;
	m_bInit = false;
}

CBLE_AdjustWnd::~CBLE_AdjustWnd()
{

}


void CBLE_AdjustWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_CBIndex(pDX, IDC_ADJ_ZOOM_CBB, m_nZoom);
	DDX_CBIndex(pDX, IDC_ADJ_REGNO_CBB, m_nRegNo);
}


BEGIN_MESSAGE_MAP(CBLE_AdjustWnd, CDialog)
	// Messages
	ON_MESSAGE(WM_UPDATE_VIEW, OnUpdateView)
	ON_MESSAGE(WM_UPDATE_ZOOM, OnUpdateZoom)
	ON_MESSAGE(WM_UPDATE_SELECTED, OnChangeSelectIC)
	ON_MESSAGE(WM_DISPLAY_FOCUSIC, OnDisplayFocusIC)
	ON_MESSAGE(WM_UPDATE_REGNO, OnUpdateRegNo)
	ON_MESSAGE(WM_UPDATE_REVWND, OnChangeRevKeyWnd)
	// Combobox event
	ON_CBN_SELCHANGE(IDC_ADJ_ZOOM_CBB, OnZoom)
	ON_CBN_SELCHANGE(IDC_ADJ_REGNO_CBB, OnChangeRegNo)
	// Button event
	ON_COMMAND_RANGE(IDC_ADJ_ZOOM_IN, IDC_ADJ_ZOOM_OUT, OnChangeZoom)
	ON_COMMAND_RANGE(IDC_ADJ_REGNO_UP, IDC_ADJ_REGNO_DOWN, OnRegNoButton)
	ON_BN_CLICKED(IDC_ADJ_MOVE_BTN, OnStartOffsetWnd)
	ON_BN_CLICKED(IDC_ADJ_EXPAND_BTN, OnStartExpandWnd)
	ON_BN_CLICKED(IDC_ADJ_CLEAR_OFFSET, OnClearAllOffset)
	ON_BN_CLICKED(IDC_ADJ_INDEX_DISPLAY_BTN, OnIndexDisplay)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_WM_DESTROY()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_AdjustWnd message handlers

//void CBLE_AdjustWnd::OnCancel()
//{
	// do nothing
//}

void CBLE_AdjustWnd::OnOK()
{
	// do nothing
}
//THAIHV 20151124 (C)
//Close Windows
void CBLE_AdjustWnd::CloseWnd()
{
	OnCancel();
}
void CBLE_AdjustWnd::OnCancel()
{
	CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_ADJDLG);
	CDialog::OnCancel();

	// Reset restore buffer
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore();

}

void CBLE_AdjustWnd::OnDestroy()
{
	CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_ADJDLG);
	CDialog::OnDestroy();
}

BOOL CBLE_AdjustWnd::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;

	CRect rect;
	// Creat common window
	GetDlgItem(IDC_ADJ_COMMON)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_CommWnd.SetDocument(m_pDoc);
	m_CommWnd.Create(IDD_COM_SETTING_DLG, this);
	m_CommWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	// Change language
	m_CommWnd.ChangeLanguage();
	m_CommWnd.ShowWindow(SW_SHOW);
	// Create layout window
	GetDlgItem(IDC_ADJ_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_LayoutWnd = new CBLE_LayoutWnd();
	m_LayoutWnd->SetDocument(m_pDoc);
	m_LayoutWnd->Create(NULL, NULL,
		WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_ADJ_LAYOUT, pContext);
	//m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],true);
	// Create information window
	GetDlgItem(IDC_ADJ_INFO)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_InfoWnd.SetDocument(m_pDoc);
	m_InfoWnd.Create(IDD_INFORMATION_DLG, this);
	m_InfoWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	//Change language
	m_InfoWnd.ChangeLanguage();
	m_InfoWnd.ShowWindow(SW_SHOW);

	// Create numkey window
	GetDlgItem(IDC_ADJ_NUM_KEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(m_CommWnd.GetEditWnd(), IDD_NKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);
	//#THAIHV170815 Hide button for RegNo
	GetDlgItem(IDC_ADJ_REGNO_CBB)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_ADJ_REGNO_DOWN)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_ADJ_REGNO_UP)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_ADJ_STATICREGNO)->ShowWindow(SW_HIDE);

	// Add content for zoom combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_ADJ_ZOOM_CBB));
	for(UINT idx = 0; idx < m_pDoc->m_vZoom.size(); idx ++){
		CString str;
		str.Format(_T("x%d"), m_pDoc->m_vZoom[idx]);
		pCbb->AddString(str);
	}
	// Init view
	InitView();
//#THAIHV170818 Move Items in Adjust mode (S)
	//	IDC_ADJ_MOVE_BTN
	GetDlgItem(IDC_ADJ_MOVE_BTN)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -30);
	GetDlgItem(IDC_ADJ_MOVE_BTN)->MoveWindow(rect,true);

	//IDC_ADJ_EXPAND_BTN
	GetDlgItem(IDC_ADJ_EXPAND_BTN)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -20);
	GetDlgItem(IDC_ADJ_EXPAND_BTN)->MoveWindow(rect,true);

	//IDC_ADJ_CLEAR_OFFSET
	GetDlgItem(IDC_ADJ_CLEAR_OFFSET)->GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.OffsetRect(0, -10);
	GetDlgItem(IDC_ADJ_CLEAR_OFFSET)->MoveWindow(rect,true);
//#THAIHV170818 Move Items in Adjust mode (S)
	// Delete pointer
	delete pContext;

	m_bInit = true;
	// Resize windown
	CBLE_Util::GetWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_ADJDLG);
	
	return TRUE;
}

void CBLE_AdjustWnd::InitView()
{
	OnUpdateRegNo();
	// Update information window
	m_InfoWnd.UpdateGridData();
	m_CommWnd.UpdateView();
	// Show this window
	ShowWindow(SW_SHOW);
}

void CBLE_AdjustWnd::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

void CBLE_AdjustWnd::SetRegNo(int regNo)
{
	if (regNo > m_pDoc->GetData()->m_vRegIC.size() || regNo < 0) {
		return;
	}
	m_nRegNo = regNo;

	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_ADJ_REGNO_CBB));
	pCbb->SetCurSel(m_nRegNo);

	// Change regno event
	OnChangeRegNo();
}


void CBLE_AdjustWnd::CheckBtnState()
{
	// Zoom out button
	GetDlgItem(IDC_ADJ_ZOOM_OUT)->EnableWindow(m_nZoom != 0);

	// Zoom in button
	GetDlgItem(IDC_ADJ_ZOOM_IN)->EnableWindow(m_nZoom != (m_pDoc->m_vZoom.size() - 1));

	// Pitch Expand button
	GetDlgItem(IDC_ADJ_EXPAND_BTN)->EnableWindow(CheckExpandCondition());

	// Locate Move button
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC; // contains both deleted and not deleted ICs
	vector<CBLE_IC*> vSelIC; // contains only not deleted ICs
	int size = vIC.size();
	for (int idx = 0; idx < size; idx ++) {
		if (!vIC[idx]->m_Deleted) {
			vSelIC.push_back(vIC[idx]); // add not deleted IC
		}
	}
	GetDlgItem(IDC_ADJ_MOVE_BTN)->EnableWindow(!vSelIC.empty());

	// RegNo Up button
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_ADJ_REGNO_CBB));
	GetDlgItem(IDC_ADJ_REGNO_UP)->EnableWindow(m_nRegNo != pCbb->GetCount() - 1);

	// RegNo Down button
	CString strRegNo;
	GetDlgItem(IDC_ADJ_REGNO_CBB)->GetWindowText(strRegNo);
	GetDlgItem(IDC_ADJ_REGNO_DOWN)->EnableWindow(atoi(strRegNo) != 0);

	// Display index button
	GetDlgItem(IDC_ADJ_INDEX_DISPLAY_BTN)->EnableWindow(m_nRegNo != 0);
}


void CBLE_AdjustWnd::OnZoom()
{
	UpdateData();
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom], true);
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	CheckBtnState();
}

void CBLE_AdjustWnd::OnChangeZoom(UINT nID)
{
	switch(nID){
	case IDC_ADJ_ZOOM_IN:
		m_nZoom ++;
		break;
	case IDC_ADJ_ZOOM_OUT:
		m_nZoom --;
		break;
	default:
		return;
	}
	// Set Scale
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],true);
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	UpdateData(FALSE);
	CheckBtnState();
}


void CBLE_AdjustWnd::OnChangeRegNo()
{
	UpdateData();
	// Set RegNo to Layout
	CString strRegNo;
	GetDlgItem(IDC_ADJ_REGNO_CBB)->GetWindowText(strRegNo);
	m_LayoutWnd->SetRegNo(atoi(strRegNo));

	// Display index
	CButton* checkBox = (CButton*) GetDlgItem(IDC_ADJ_INDEX_DISPLAY_BTN);
	m_LayoutWnd->SetIndexDisplay(checkBox->GetCheck());

	// Redraw Layout
	m_LayoutWnd->Invalidate();
}


LRESULT CBLE_AdjustWnd::OnUpdateZoom(WPARAM wParam, LPARAM lParam)
{
	if((wParam == DBLE_ZOOM_IN) && (m_nZoom != (m_pDoc->m_vZoom.size() - 1))){
		OnChangeZoom(IDC_ADJ_ZOOM_IN);
	}else if((wParam == DBLE_ZOOM_OUT) && (m_nZoom != 0)){
		OnChangeZoom(IDC_ADJ_ZOOM_OUT);
	}
	return 0;
}


LRESULT CBLE_AdjustWnd::OnUpdateView(WPARAM wParam, LPARAM lParam)
{
	m_LayoutWnd->SetScale(m_pDoc->m_vZoom[m_nZoom],true);
	m_LayoutWnd->Invalidate();
	CheckBtnState();
	return 0;
}


LRESULT CBLE_AdjustWnd::OnChangeSelectIC(WPARAM wParam, LPARAM lParam)
{
	// Update information window
	m_InfoWnd.UpdateGridData();
	// Update button state
	CheckBtnState();

	return 0;
}


void CBLE_AdjustWnd::OnStartExpandWnd()
{
	TRACE("[Adjust][Expand]CBLE_ AdjustWnd::On StartExpandWnd()\n");
	CBLE_ExpandDlg expandDlg;
	expandDlg.SetDocument(m_pDoc);
	if(expandDlg.DoModal() != IDOK) return;
	// Redraw Layout
	m_LayoutWnd->Invalidate();
	// Check state of all buttons
	CheckBtnState();
}


void CBLE_AdjustWnd::OnStartOffsetWnd()
{
	TRACE("[Adjust][Move]CBLE_ AdjustWnd::On StartOffsetWnd()\n");
	CBLE_OffsetDlg offsetDlg(DBLE_OFFSET_DLG_MODE_OFFSET);
	offsetDlg.SetDocument(m_pDoc);
	if(offsetDlg.DoModal() != IDOK) return;
	m_pDoc->GetData()->GetSubstrate()->CheckRegionSelectedICs();
	// Redraw Layout
	m_LayoutWnd->Invalidate();

	// Update information window
	m_InfoWnd.UpdateGridData();

	// Check state of all buttons
	CheckBtnState();

}


void CBLE_AdjustWnd::OnUpdateRegNo()
{
	// Get the pointer of RegNo combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_ADJ_REGNO_CBB));
	// Get current RegNo
	CString strReg;
	pCbb->GetWindowText(strReg);
	int RegNo = atoi(strReg);
	// Update RegNo
	m_nRegNo = 0;
	// Update content for RegNo combobox
	pCbb->ResetContent();
	pCbb->AddString(_T("0"));
	vector<TBLE_RegIC> vReg = m_pDoc->GetData()->m_vRegIC;
	CString strTmp;
	int regSize = vReg.size();
	for(UINT idx = 0; idx < regSize; idx ++){
		strTmp.Format(_T("%d"), vReg[idx].m_RegNo);
		pCbb->AddString(strTmp);
		if(RegNo != vReg[idx].m_RegNo) continue;
		m_nRegNo = idx + 1;
	}

	// Update view
	UpdateData(FALSE);
	OnChangeRegNo();
	// Check state of all buttons
	CheckBtnState();
	// Redraw the layout window
	m_LayoutWnd->Invalidate();
}

// Display index
void CBLE_AdjustWnd::OnIndexDisplay()
{
	// Display index
	CButton* checkBox = (CButton*) GetDlgItem(IDC_ADJ_INDEX_DISPLAY_BTN);
	m_LayoutWnd->SetIndexDisplay(checkBox->GetCheck());

	m_LayoutWnd->Invalidate();
	return;
}

BOOL CBLE_AdjustWnd::CheckExpandCondition()
{
	vector<CBLE_IC*> vSelIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	// Vector contains all main ICs
	vector<CBLE_IC*> vIC;

	if(vSelIC.empty()) return FALSE;

	int size = vSelIC.size();
	int regno = 0;

	// Get regno of main IC
	for(UINT idx = 0; idx < size; idx ++){
		if (!vSelIC[idx]->m_Deleted) {
			regno = vSelIC[idx]->m_pRegIC->m_RegNo;
			break;
		}
	}

	//If all selected ICs are deleted then return
	if (regno == 0) {
		m_pDoc->GetData()->GetSubstrate()->DeselectAll();
		return FALSE;
	}

	for(idx = 0; idx < size; idx ++){
		//if(vIC[idx]->m_OffsetX != vIC[0]->m_OffsetX) return FALSE;
		//if(vIC[idx]->m_OffsetY != vIC[0]->m_OffsetY) return FALSE;
		if (vSelIC[idx]->m_pRegIC->m_RegNo == regno) {
			vIC.push_back(vSelIC[idx]);
		} else {
			if (!vSelIC[idx]->m_Deleted) {
				return FALSE;
			}
		}
	}

	// Assign vector of selected IC
	m_pDoc->GetData()->GetSubstrate()->m_vSelIC = vIC;
	size = vIC.size();

	// Check index of all selected ICs
	int minX = vIC[0]->m_indexX;
	int minY = vIC[0]->m_indexY;
	int maxX = vIC[0]->m_indexX;
	int maxY = vIC[0]->m_indexY;
	for(idx = 0; idx < size; idx ++){
		if(minX > vIC[idx]->m_indexX) minX = vIC[idx]->m_indexX;
		if(minY > vIC[idx]->m_indexY) minY = vIC[idx]->m_indexY;
		if(maxX < vIC[idx]->m_indexX) maxX = vIC[idx]->m_indexX;
		if(maxY < vIC[idx]->m_indexY) maxY = vIC[idx]->m_indexY;
	}

	if((maxX - minX) < 2) return FALSE;
	if((maxY - minY) < 2) return FALSE;

	for(int idxX = minX; idxX <= maxX; idxX ++){
		for(int idxY = minY; idxY <= maxY; idxY ++){
			BOOL Enable = FALSE;
			for(idx = 0; idx < vIC.size(); idx ++){
				if(vIC[idx]->m_indexX != idxX) continue;
				if(vIC[idx]->m_indexY != idxY) continue;
				Enable = TRUE;
				break;
			}
			if(!Enable) return FALSE;
		}
	}
	return TRUE;
}

void CBLE_AdjustWnd::OnRegNoButton(UINT nID)
{
	UpdateData();
	CString strRegNo;
	GetDlgItem(IDC_ADJ_REGNO_CBB)->GetWindowText(strRegNo);
	int regNo = atoi(strRegNo);

	switch(nID){
	case IDC_ADJ_REGNO_UP:
		regNo ++;
		break;
	case IDC_ADJ_REGNO_DOWN:
		regNo --;
		break;
	default:
		return;
	}
	m_LayoutWnd->SetRegNo(regNo);
	// Add content for regno combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_ADJ_REGNO_CBB));
	pCbb->SetCurSel(regNo);

	// Change regno event
	OnChangeRegNo();

	// Redraw Layout
	m_LayoutWnd->Invalidate();
}

CBLE_CommonWnd* CBLE_AdjustWnd::GetCommdWnd()
{
	return &m_CommWnd;
}

CBLE_InfoWnd* CBLE_AdjustWnd::GetInfoWnd()
{
	return &m_InfoWnd;
}

CBLE_LayoutWnd* CBLE_AdjustWnd::GetLayoutWnd()
{
	return m_LayoutWnd;
}


void CBLE_AdjustWnd::OnSize(UINT nType, int cx, int cy)
{
	if (!m_bInit) return;

	// Initialize a rect
	CRect rect;

	// Expand layout window
	m_LayoutWnd->GetWindowRect(rect);
	ScreenToClient(&rect);
	int oldWidth = rect.Width(); //store original width of layout window
	// int oldHeight = rect.Height(); // store original height of layout window
	CRect layourRect(rect.TopLeft(), CSize(cx - DBLE_ADJWN_OPERATION_SIZEX, cy - DBLE_ADJWN_OPERATION_SIZEY));
	m_LayoutWnd->MoveWindow(layourRect);

	// Expand locate edit frame
	GetDlgItem(IDC_ADJ_LOCATEDIT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	CRect leditRect(rect.TopLeft(), CSize(cx - DBLE_ADJWN_MARGIN_SIZEX, cy - DBLE_ADJWN_OPERATION_SIZEY));
	GetDlgItem(IDC_ADJ_LOCATEDIT)->MoveWindow(leditRect,true);

	// Expand layout frame
	GetDlgItem(IDC_ADJ_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	GetDlgItem(IDC_ADJ_LAYOUT)->MoveWindow(layourRect,true);

	// Expand infor window
	m_InfoWnd.GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.SetRect(0, cy - DBLE_ADJWN_INFO_HEIGHT, 0 + DBLE_ADJWN_INFO_WIDTH, cy);
	m_InfoWnd.MoveWindow(rect, true);

	// Expand 10-key window
	m_KeyWnd.GetWindowRect(rect);
	ScreenToClient(&rect);
	rect.SetRect( cx - DBLE_ADJWN_10KEY_WIDTH, cy - DBLE_ADJWN_10KEY_HEIGHT /*- DBLE_ADJWN_INFO_HEIGHT*/, cx, cy /*- DBLE_ADJWN_INFO_HEIGHT*/);
	m_KeyWnd.MoveWindow(rect, true);

	// Expand buttons and text
	for (UINT idx = IDC_ADJ_ZOOM_CBB; idx <= IDC_ADJ_INDEX_DISPLAY_BTN; idx++) {
		GetDlgItem(idx)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layourRect.Width() - oldWidth, 0);
		GetDlgItem(idx)->MoveWindow(rect,true);
	}
	// Redraw
	Invalidate();
	CDialog::OnSize(nType, cx, cy);
}

void CBLE_AdjustWnd::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	lpMMI->ptMinTrackSize.x = DBLE_ADJWND_SIZEX;
	lpMMI->ptMinTrackSize.y = DBLE_ADJWND_SIZEY;
}

void CBLE_AdjustWnd::OnClearAllOffset()
{
	int language = m_pDoc->GetData()->m_Init.m_Language; // find display language
	// Display warning message
	//int nType = AfxMessageBox(WARNING_MESSAGE_CLEAROFFSET, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
	int nType = theApp.CBTMessageBox(this->m_hWnd, ClearAllOffset[language], MB_YESNO, language);
	if (nType == IDYES) {								// Re-input
		
		// For undo function: Store state
		CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
		CBLE_Memento mem = m_pDoc->GetData()->CreateMemento(IDD_ADJUST_DLG, true, m_nRegNo);
		pCareTaker->SetMemento(mem);

		TRACE("[Adjust][Clear]CBLE_ AdjustWnd::On ClearAllOffset()\n");
		m_pDoc->GetData()->GetSubstrate()->ClearAllOffset(m_nRegNo);

		//Redraw layout
		m_LayoutWnd->Invalidate();
	} else {
		return;
	}
}

/*
* Change language
*/
void CBLE_AdjustWnd::ChangeLanguage()
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	for (UINT id = IDC_ADJ_LAYOUT; id <= IDC_ADJ_LBL_LOCATEEDIT; id ++) {
		for (int idx = 0; idx < DBLE_LANGUAGE_ITEMS; idx ++) {
			if ((id == m_pDoc->m_DialogItems[idx].m_ID) && (m_pDoc->m_DialogItems[idx].m_Name.Compare("") != 0)) {
				GetDlgItem(id)->SetWindowText(m_pDoc->m_DialogItems[idx].m_Name);
				break;
			}
		}
	}
}

// #DUCDT131125: Add receive window for numkey
/**
* Set receive window for numkey
*/
LRESULT CBLE_AdjustWnd::OnChangeRevKeyWnd(WPARAM wParam,LPARAM lParam)
{
	if(wParam == (WPARAM)m_InfoWnd.m_hWnd) {
		m_KeyWnd.SetReceiveKeyWindow(m_InfoWnd.GetEditWnd());
	} else if (wParam == (WPARAM)m_CommWnd.m_hWnd) {
		m_KeyWnd.SetReceiveKeyWindow(m_CommWnd.GetEditWnd());
	}
	return 0;
}

// Allow select deleted ICs
void CBLE_AdjustWnd::AllowSelectDeletedIC()
{
	m_pDoc->GetData()->GetSubstrate()->m_bSelectDeleted = true;
}

// Display focus IC
LRESULT CBLE_AdjustWnd::OnDisplayFocusIC(WPARAM wParam, LPARAM lParam)
{
	m_InfoWnd.DisplayFocusIC();
	return 0;
}

/**
* Catch Ctrl + Z to restore
*/
BOOL CBLE_AdjustWnd::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN /*&& pMsg->wParam == VK_CONTROL*/){
		if ((GetKeyState(0x5A) & 0x8000) && (GetKeyState(VK_CONTROL) & 0x8000)) {
			CBLE_FrameWnd *frame = (CBLE_FrameWnd*)GetParentFrame();
			frame->OnRestoreState();
		}
    }	
    return CDialog::PreTranslateMessage(pMsg);
}

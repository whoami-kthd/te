// CBLE_CommonWnd.cpp : implementation file
//

#include "stdafx.h"
#include "swatch.h"
#include "..\\BLE.h"
#include "CBLE_CommonWnd.h"
#include "CBLE_Util.h"
#include "CBLE_ProgressBar.h"
#include "CBLE_LocateEditWnd.h"
#include "CBLE_CareTaker.h"
#include "CBLE_FrameWnd.h"

/*#define WARNING_MESSAGE_OUTOFRANGE			_T("Your input is out of limit range! \n Do you want to re-input?")
#define WARNING_MESSAGE_ICPITCHMISSING		_T("Please full fill IC pitch!")
#define WARNING_MESSAGE_ICSIZEMISSING		_T("Please full fill IC size!")
#define WARNING_MESSAGE_NUMBERMISSING		_T("Please full fill IC number!")
*/
#define DBLE_EDITWND_MINSCALE				1.0
#define MINUS_COLUM_IN_SURROUND				4    //#THAIHV170613
// Hash table for all shapes of substrate

// Defined for column width of grid control
static long m_arrComColWidth[] = {
//	RegNo	IcType	IcSize	IcPitch	StartPos	Array	Angle	Tool	Eject	Collette
//	/*25*/1,		1/*30*/,		45, 45,	50, 50,	60, 60,		30, 30,	50,		30,		30,		30	/*20, 20,	20, 20,	20, 20*/	//#DMV170622 Disable Tool Change
	/*25*/1,		1/*30*/,		55, 55,	60, 60,	70, 70,		40, 40,	60,		40,		40,		40	/*20, 20,	20, 20,	20, 20*/
};

// Defined for column number type of grid control
static DBLE_CellType m_arrComColType[] = {
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_DOUBLE,
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_INT,
	DBLE_CELL_INT
};

/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString CommonSettingLang[] = {							
								"���ʐݒ�",
								"Common Setting",
							};

CString DeviceNameLang[] =	{
								"�i�햼",
								"DeviceName",
							};

CString OutOfRangeCom[] =	{
								_T("���͂������͈͊O�ł��B�ē��͂��܂����H"),
								_T("Your input is out of limit range! \n Do you want to re-input?"),
							};

CString ICPitchMissing[] =	{
								_T("IC�s�b�`����͂��Ă��������I"),
								_T("Please full fill IC pitch!"),
							};

CString ICSizeMissing[] =	{
								_T("IC�T�C�Y����͂��Ă��������I"),
								_T("Please full fill IC size!"),
							};

CString ICNumMissing[] =	{
								_T("IC�̐�����͂��Ă��������I"),
								_T("Please full fill IC number!"),
							};

CString CheckInvalid[] =	{
								_T("COMMON�̒l���ԈႢ�܂��B�ē��͂����������I"),
								_T("Values are invalid \n Please input again!"),
							};

/////////////////////////////////////////////////////////////////////////////
// CBLE_CommonWnd dialog


CBLE_CommonWnd::CBLE_CommonWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_CommonWnd::IDD, pParent)
{
	m_pDoc = NULL;
	m_nShape = 0;
	m_lastShape = 0;
	m_GridCtrl = NULL;
	m_autoToolChange = 0;
	m_colletteNo = 0;
	m_ejectorNo = 0;
}

CBLE_CommonWnd::~CBLE_CommonWnd()
{

}


void CBLE_CommonWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	// Substrate shape
	DDX_CBIndex(pDX, IDC_COMM_CBB_SHAPE, m_nShape);
}


BEGIN_MESSAGE_MAP(CBLE_CommonWnd, CDialog)
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateGrid)
	// Change shape
	ON_CBN_SELCHANGE(IDC_COMM_CBB_SHAPE, OnChangeShape)
	// Click check&reflect button
	ON_BN_CLICKED(IDC_COMM_BTN_CHECK, OnCheckBtn)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_CommonWnd message handlers

/////////////////////////////////////////////////////////////////////////////
// CBLE_LocateEditWnd message handlers

void CBLE_CommonWnd::OnCancel()
{
	// do nothing
}

void CBLE_CommonWnd::OnOK()
{
	// do nothing
}

BOOL CBLE_CommonWnd::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	int lang = m_pDoc->GetData()->m_Init.m_Language;
	//GetDlgItem(IDC_COMM_LBL_TITLE)->SetWindowText(_T(CommonSettingLang[lang]));

	// Create grid control
	CRect rect;
	GetDlgItem(IDC_COMM_GRID)->GetWindowRect(rect);
	ScreenToClient(&rect);
	int numberOfCol = 11;
	numberOfCol = (m_autoToolChange != 4) ? numberOfCol : numberOfCol + 2;
	if ((m_colletteNo != 0) && (m_ejectorNo != 1)) {
		numberOfCol = numberOfCol + 4;
	}
	//numberOfCol = (m_colletteNo == 0) ? numberOfCol : numberOfCol + 2;
	//numberOfCol = (m_ejectorNo == 1) ? numberOfCol : numberOfCol + 2;
//	m_GridCtrl = new CBLE_GridCtrl(7, numberOfCol);
	m_GridCtrl = new CBLE_GridCtrl( 7-MINUS_COLUM_IN_SURROUND, numberOfCol);  //#THAIHV170613

	//m_GridCtrl->SetDocument(m_pDoc);
	m_GridCtrl->Create(rect, this, m_pDoc);

	// Set DeviceName
	CString label;
	//GetDlgItem(IDC_COMM_DEVNAME)->GetWindowText(_T(label));
	label = DeviceNameLang[lang] + ": " + m_pDoc->GetDeviceName();
	GetDlgItem(IDC_COMM_DEVNAME)->SetWindowText(_T(label));
	// Init grid control
	InitGridCtrl();
	AddGridData();

	// Add content for substrate shape combobox
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_COMM_CBB_SHAPE));
	int shapeSize = m_pDoc->GetData()->m_vShape.size();
	for(UINT idx = 0; idx < shapeSize; idx ++){
		pCbb->AddString(m_pDoc->GetData()->m_Init.m_ShapeName[idx]);
	}
	// Update view
	UpdateData(FALSE);

	return TRUE;
}


void CBLE_CommonWnd::InitGridCtrl()
{
	// Get auto tool change
	//int autoToolChange = m_pDoc->GetData()->GetAutoToolChange();
	//int colletteNo = m_pDoc->GetData()->GetColletteNumber();
	//int ejectorNo = m_pDoc->GetData()->GetEjectorNumber();
	
	// Set language
	m_GridCtrl->SetLanguage(m_pDoc->GetData()->m_Init.m_Language);

	// Set type for all cols
	for(UINT idx = 0; idx < ARRAY_LENGTH(m_arrComColType); idx ++){
		m_GridCtrl->SetColType(idx, m_arrComColType[idx]);
	}

	// Set width for all cols
	for(idx = 0; idx < 11; idx ++){
		m_GridCtrl->SetColWidth(idx, m_arrComColWidth[idx]);	// �����w��
	}
	//#THAIHV170815 Set invisible for RegNo, ICType, Angle, Tool
	m_GridCtrl->SetColInvisible(0);
	m_GridCtrl->SetColInvisible(1);
	m_GridCtrl->SetColInvisible(10);
	m_GridCtrl->SetColInvisible(11);
	m_GridCtrl->SetColInvisible(12);
	// Set merge for some rows and cols
	m_GridCtrl->MergeCell(0, 0, 1, 0);
	m_GridCtrl->MergeCell(0, 1, 1, 1);
	m_GridCtrl->MergeCell(0, 2, 0, 3);
	m_GridCtrl->MergeCell(0, 4, 0, 5);
	m_GridCtrl->MergeCell(0, 6, 0, 7);
	m_GridCtrl->MergeCell(0, 8, 0, 9);
	m_GridCtrl->MergeCell(0, 10, 1, 10);
	// Set header
	m_GridCtrl->SetRowHeader(0);
	m_GridCtrl->SetRowHeader(1);
	m_GridCtrl->SetColHeader(0);

	// Set header text
	m_GridCtrl->SetCellText(0, 0, _T("Reg No"));
	m_GridCtrl->SetCellText(0, 1, _T("IC Type"));

	m_GridCtrl->SetCellText(0, 2, _T("IC Size [mm]"));
	m_GridCtrl->SetCellText(1, 2, _T("X"));
	m_GridCtrl->SetCellText(1, 3, _T("Y"));

	m_GridCtrl->SetCellText(0, 4, _T("IC Pitch [mm]"));
	m_GridCtrl->SetCellText(1, 4, _T("X"));
	m_GridCtrl->SetCellText(1, 5, _T("Y"));

	m_GridCtrl->SetCellText(0, 6, _T("Start Pos. [mm]"));
	m_GridCtrl->SetCellText(1, 6, _T("X"));
	m_GridCtrl->SetCellText(1, 7, _T("Y"));

	m_GridCtrl->SetCellText(0, 8, _T("Array"));
	m_GridCtrl->SetCellText(1, 8, _T("X"));
	m_GridCtrl->SetCellText(1, 9, _T("Y"));

	m_GridCtrl->SetCellText(0, 10, _T("Angle [deg]"));
	
	if (m_autoToolChange == 4) {
		m_GridCtrl->SetColWidth(idx, m_arrComColWidth[idx]);
		idx++;
		//#DMV170622 Disable Tool Change (S)
		m_GridCtrl->SetCellText(0, idx - 1, _T("Tool"));
		m_GridCtrl->MergeCell(0, idx - 1, 1, idx-1);
//		m_GridCtrl->SetColWidth(idx, m_arrComColWidth[idx]);
//		m_GridCtrl->MergeCell(0, idx - 1, 0, idx);
//		m_GridCtrl->SetCellText(0, idx - 1, _T("Tool"));
//		m_GridCtrl->SetCellText(1, idx - 1, _T("L"));
//		m_GridCtrl->SetCellText(1, idx, _T("R"));
//		idx++;
		//#DMV170622 Disable Tool Change (E)
	}
	if ((m_colletteNo != 0) && ((m_ejectorNo != 1))) {
		m_GridCtrl->SetColWidth(idx, m_arrComColWidth[idx]);
		idx++;
		//#DMV170622 Disable Tool Change (S)		
		m_GridCtrl->SetCellText(0, idx - 1, _T("Collette"));
		m_GridCtrl->MergeCell(0, idx - 1, 1, idx-1);
//		m_GridCtrl->SetColWidth(idx, m_arrComColWidth[idx]);
//		m_GridCtrl->MergeCell(0, idx - 1, 0, idx);
//		m_GridCtrl->SetCellText(0, idx - 1, _T("Collette"));
//		m_GridCtrl->SetCellText(1, idx - 1, _T("L"));
//		m_GridCtrl->SetCellText(1, idx, _T("R"));
//		idx++;
		//#DMV170622 Disable Tool Change (E)
	//}
	//if (m_ejectorNo != 1) {
		m_GridCtrl->SetColWidth(idx, m_arrComColWidth[idx]);
		idx++;
		//#DMV170622 Disable Tool Change (S)
		m_GridCtrl->SetCellText(0, idx - 1, _T("Eject"));
		m_GridCtrl->MergeCell(0, idx - 1, 1, idx-1);
//		m_GridCtrl->SetColWidth(idx, m_arrComColWidth[idx]);
//		m_GridCtrl->MergeCell(0, idx - 1, 0, idx);
//		m_GridCtrl->SetCellText(0, idx - 1, _T("Eject"));
//		m_GridCtrl->SetCellText(1, idx - 1, _T("L"));
//		m_GridCtrl->SetCellText(1, idx, _T("R"));
//		idx++;
		//#DMV170622 Disable Tool Change (E)
	}
// #DDT(20140421) Disable all rows follow RegNoMax
	int numberOfRow = (m_pDoc->GetData()->m_Init.m_RegNoMax <= 5) ? m_pDoc->GetData()->m_Init.m_RegNoMax + 2 : 7;
	for (int i = numberOfRow; i < 7; i++) {
		m_GridCtrl->SetRowHeader(i);
		m_GridCtrl->SetRowText(i, "");
	}
}

void CBLE_CommonWnd::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
	m_nShape = pDoc->GetData()->GetSubstrate()->m_ShapeID - 1;
	m_lastShape = m_nShape;
	m_autoToolChange = m_pDoc->GetData()->GetAutoToolChange();
	m_colletteNo = m_pDoc->GetData()->GetColletteNumber();
	m_ejectorNo = m_pDoc->GetData()->GetEjectorNumber();
}


void CBLE_CommonWnd::ResetGridCtrl(bool hasToResetHeaderStatus)
{
	long startRow = 2;
	int rowNum = m_GridCtrl->GetRows();
	int colNum = m_GridCtrl->GetCols();
// #DDT(20140421) Update LocateEdit
	int maxRow = (m_pDoc->GetData()->m_Init.m_RegNoMax <= 5) ? m_pDoc->GetData()->m_Init.m_RegNoMax + 2 : 7;
	for(long row = startRow; row < rowNum; row ++){
		for(long col = 0; col < colNum; col ++){
			m_GridCtrl->SetCellText(row, col, _T(""));
			// If m_pDoc load data again, gridCtrl has to reset header status
			if (hasToResetHeaderStatus) {
				if (row >= maxRow) {
					continue;
				}
				if (col!= 0) {
					m_GridCtrl->GetCell(row, col)->SetHeader(false);
				}
			}
		}
	}
}

void CBLE_CommonWnd::AddGridData()
{
	vector<TBLE_RegIC> vReg = m_pDoc->GetData()->m_vRegIC;
	long startRow = 2;
	CString strTmp;
	int regSize = vReg.size();
	for(UINT idx = 0; idx < regSize; idx ++){
		// RegNo
		strTmp.Format(_T("%d"), vReg[idx].m_RegNo);
		m_GridCtrl->SetCellText(idx + startRow, 0, strTmp);
		// IC type
		strTmp.Format(_T("%d"), vReg[idx].m_Type);
		m_GridCtrl->SetCellText(idx + startRow, 1, strTmp);
		// IC size X
		strTmp.Format(_T("%.4f"), vReg[idx].m_SizeX);
		m_GridCtrl->SetCellText(idx + startRow, 2, strTmp);
		// IC size Y
		strTmp.Format(_T("%.4f"), vReg[idx].m_SizeY);
		m_GridCtrl->SetCellText(idx + startRow, 3, strTmp);
		// IC pitch X
		strTmp.Format(_T("%.4f"), vReg[idx].m_PitchX);
		m_GridCtrl->SetCellText(idx + startRow, 4, strTmp);
		// IC pitch Y
		strTmp.Format(_T("%.4f"), vReg[idx].m_PitchY);
		m_GridCtrl->SetCellText(idx + startRow, 5, strTmp);
		// IC startpos X
		strTmp.Format(_T("%.4f"), vReg[idx].m_StartPosX);
		m_GridCtrl->SetCellText(idx + startRow, 6, strTmp);
		// IC startpos Y
		strTmp.Format(_T("%.4f"), vReg[idx].m_StartPosY);
		m_GridCtrl->SetCellText(idx + startRow, 7, strTmp);
		// IC number X
		strTmp.Format(_T("%d"), vReg[idx].m_NumberX);
		m_GridCtrl->SetCellText(idx + startRow, 8, strTmp);
		// IC number Y
		strTmp.Format(_T("%d"), vReg[idx].m_NumberY);
		m_GridCtrl->SetCellText(idx + startRow, 9, strTmp);
		// IC Angle
		strTmp.Format(_T("%.4f"), vReg[idx].m_Angle);
		m_GridCtrl->SetCellText(idx + startRow, 10, strTmp);
		int index = 10;
		if (m_autoToolChange == 4) {
			// IC tool L
			strTmp.Format(_T("%d"), vReg[idx].m_ToolL);
			m_GridCtrl->SetCellText(idx + startRow, ++index, strTmp);
//#DMV170622 Disable Tool Change (S)
			// IC tool R
//			strTmp.Format(_T("%d"), vReg[idx].m_ToolR);
//			m_GridCtrl->SetCellText(idx + startRow, ++index, strTmp);
//#DMV170622 Disable Tool Change (E)
		}
		if ((m_colletteNo != 0) && (m_ejectorNo != 1)) {
			// IC collette L
			strTmp.Format(_T("%d"), vReg[idx].m_ColletteL);
			m_GridCtrl->SetCellText(idx + startRow, ++index, strTmp);
//#DMV170622 Disable Tool Change (S)
			// IC collette R
//			strTmp.Format(_T("%d"), vReg[idx].m_ColletteR);
//			m_GridCtrl->SetCellText(idx + startRow, ++index, strTmp);
//#DMV170622 Disable Tool Change (E)
		//}
		//if (m_ejectorNo != 1) {
			// IC eject L
			strTmp.Format(_T("%d"), vReg[idx].m_EjectL);
			m_GridCtrl->SetCellText(idx + startRow, ++index, strTmp);
//#DMV170622 Disable Tool Change (S)
			// IC eject R
//			strTmp.Format(_T("%d"), vReg[idx].m_EjectR);
//			m_GridCtrl->SetCellText(idx + startRow, ++index, strTmp);
//#DMV170622 Disable Tool Change (E)
		}
	}
}


void CBLE_CommonWnd::OnChangeShape()
{
	// Reset restore buffer
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore();

	// Update modified flag
	m_pDoc->SetModifiedFlag(1);
	UpdateData();
	CBLE_Substrate* pSubs = m_pDoc->GetData()->GetSubstrate();
	CBLE_Model *pModel = m_pDoc->GetData();
	pSubs->SetShape(m_nShape + 1, pModel->m_vShape[m_nShape].shape, pModel->m_vShape[m_nShape].sizeX, pModel->m_vShape[m_nShape].sizeY);
	// Set regioin for all ICs
	m_pDoc->GetData()->GetSubstrate()->SetRegionAllICs();
	
	CString lastShape, newShape;
	CString sizeX, sizeY;
	sizeX.Format(_T("%d"), pModel->m_vShape[m_lastShape].sizeX);
	sizeY.Format(_T("%d"), pModel->m_vShape[m_lastShape].sizeY);
	if (pModel->m_vShape[m_lastShape].shape == DBLE_SHAPE_SQUARE) {
		lastShape = lastShape + "Square" + " " + sizeX + "x" + sizeY + "mm";
	} else {
		lastShape = lastShape + "Round" + " " + sizeX + "mm";
	}

	sizeX.Format(_T("%d"), pModel->m_vShape[m_nShape].sizeX);
	sizeY.Format(_T("%d"), pModel->m_vShape[m_nShape].sizeY);
	if (pModel->m_vShape[m_nShape].shape == DBLE_SHAPE_SQUARE) {
		newShape = newShape + "Square" + " " + sizeX + "x" + sizeY + "mm";
	} else {
		newShape = newShape + "Round" + " " + sizeX + "mm";
	}

	// Write log: Change shape
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_SHAPE, lastShape + " -> " + newShape);

	// Post message to redraw the parent window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_VIEW, 0, 0);
}


LRESULT CBLE_CommonWnd::OnUpdateGrid(WPARAM wParam, LPARAM lParam)
{
	long row = m_GridCtrl->GetRowSel();
	long col = m_GridCtrl->GetColSel();
	if((row == -1) || (col == -1)) return 0;

	CString tmpText = m_GridCtrl->GetCellText(row, col);
	
	// Get old text to write log file
	CString oldText = m_GridCtrl->GetCell(row, col)->GetOldText();

	// Check old value same as new value or not?
	if (tmpText.Compare(oldText) != 0) {
			
		if (!CheckInputValue(row, col)) {

			int language = m_pDoc->GetData()->m_Init.m_Language;
			// Write log file: Input error
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, OutOfRangeCom[language], "", "");
				
			//int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
			int nType = theApp.CBTMessageBox(this->m_hWnd, OutOfRangeCom[language], MB_YESNO, language);		// Message: input is not correct
			if (nType == IDYES) {								// Re-input
				m_GridCtrl->SetCellText(row, col, oldText);
				m_GridCtrl->ShowEditBox();
				return 0;
			} else {
				m_GridCtrl->RestoreText(row, col);	// Back to the previous value
			}
		} else {
			// For undo function
			// Store state
			CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
			CBLE_GridStore grid(row, col, oldText, IDD_COM_SETTING_DLG, GRID_TYPE);
			pCareTaker->SetMemento(grid);
			// Update grid: auto fill, write log
			UpdateGrid(row, col, tmpText, oldText);
		
		}
	}
	// Focus on CommondWindow
	SetFocus();
	// Move to next collumn
	if (col + 1 < m_GridCtrl->GetCols()) {
		m_GridCtrl->SetCellSel(row, col + 1);
	} else if (row + 1 < m_GridCtrl->GetRows()){ // if collumn is maximum then return;
		m_GridCtrl->SetCellSel(row + 1, IC_TYPE);
	} else {

		m_GridCtrl->Deselect();
	}
	Invalidate();
	return 0;
}

//////////////////////////////////////////////
// Check input value
//
bool CBLE_CommonWnd::CheckInputValue(int row, int col)
{
	double	min, max;										// range of value
	bool	isValid = true;									// input is valid or invalid
	TBLE_Init initData = m_pDoc->GetData()->m_Init;
	TRACE("[Edit][Common]CBLE_ CommonWnd::Check InputValue(row=%d,col=%d)Value=%f\n",row,col,atof (m_GridCtrl->GetCellText(row, col)));

	switch (col) {
		// Check IcType Value
	case IC_TYPE :
		{
			int value = atof (m_GridCtrl->GetCellText(row, col));
			if (value < 0 || value > initData.m_IcTypeMax) {
				isValid = false;
			}
		}
		break;

		// Check IcSize value
	case IC_SIZE_X :
		{
			double value = atof (m_GridCtrl->GetCellText(row, col));
			min = initData.m_IcSizeMin.x;
			max = initData.m_IcSizeMax.x;
			if (value > max || value < min) {
				isValid = false;
			}

			// IC size value has to <= IC pitch
			CString pitchStr = m_GridCtrl->GetCellText(row, /*col+2*/IC_PITCH_X);		// Get inputed IC pitch X
			if ((pitchStr != "") &&  (value > atof(pitchStr))){
				isValid = false;
			}
		}
		break;
	case IC_SIZE_Y :
		{
			double value = atof (m_GridCtrl->GetCellText(row, col));
			min = initData.m_IcSizeMin.y;
			max = initData.m_IcSizeMax.y;
			if (value > max || value < min) {
				isValid = false;
			}

			// IC size value has to <= IC pitch
			CString pitchStr = m_GridCtrl->GetCellText(row, /*col+2*/IC_PITCH_Y);		// Get inputed IC pitch Y
			if ((pitchStr != "") &&  (value > atof(pitchStr))) {						// If IC pitch already been entered
				isValid = false;
			}
		}
		break;

		// IC pitch value has to >= IC size value
	case IC_PITCH_X :
		{
			CString sizeStr = m_GridCtrl->GetCellText(row, /*col+2*/IC_SIZE_X);		// Get inputed IC size value (string)
			if (sizeStr != "") {
				double value = atof (m_GridCtrl->GetCellText(row, col));
				min = atof(sizeStr);
				if (value < min) {
					isValid = false;
				}

			}
		}
		break;
	case IC_PITCH_Y :
		{
			CString sizeStr = m_GridCtrl->GetCellText(row, /*col+2*/IC_SIZE_Y);		// Get inputed IC size value (string)
			if (sizeStr != "") {
				double value = atof (m_GridCtrl->GetCellText(row, col));
				min = atof(sizeStr);
				if (value < min) {
					isValid = false;
				}
			}
		}
		break;
	//case START_POS_X :
	//case START_POS_Y :
	case NUMBER_X :
	case NUMBER_Y :
		{
			int value = atof (m_GridCtrl->GetCellText(row, col));
			if (value <= 0 || value > initData.m_ArrayNumberMaxX) {
				isValid = false;
			}
		}
		break;
	case ANGLE :
		{
			double value = atof (m_GridCtrl->GetCellText(row, col));
			if (value < -360 || value > 360) {
				isValid = false;
			}
		}
		break;
	case TOOL_L :
//	case TOOL_R :			//#DMV170622 Disable Tool Change
		{
			int value = atoi(m_GridCtrl->GetCellText(row, col));
			int max = initData.m_BgHeadToolMax;
			if (m_autoToolChange == 4) {
				if (value < 1 || value > max ) {
					isValid = false;
				}
			} else if ((m_colletteNo != 0) && (m_ejectorNo != 1)) {
				max = initData.m_PickupColletteMax;
				if (value < 1 || value > max ) { // Min input value of collete is 1
					isValid = false;
				}
			} else {
				/*int max = initData.m_WaferEjectMax;
				if (value < 0 || value > max ) {
					isValid = false;
				}*/
			}
		}
		break;
	case COLLETTE_L :
//	case COLLETTE_R :			//#DMV170622 Disable Tool Change
		{
			int value = atoi(m_GridCtrl->GetCellText(row, col));
			// Assign max value depend on collette or ejector
			int max = (m_autoToolChange == 4) ? initData.m_PickupColletteMax : initData.m_WaferEjectMax;
			if (value < 1 || value > max ) { // Min input value of collete is 1
				isValid = false;
			}
			/* else {
				int max = initData.m_WaferEjectMax;
				if (value < 0 || value > max ) {
					isValid = false;
				}
			}*/
		}
		break;
	case EJECTER_L :
//	case EJECTER_R :			//#DMV170622 Disable Tool Change
		{
			int value = atoi(m_GridCtrl->GetCellText(row, col));
			int max = initData.m_WaferEjectMax;
			if (value < 1 || value > max ) {	// Min input of ejector is 1
				isValid = false;
			}
		}
		break;
	default:
		break;
	}

	return isValid;
}

void CBLE_CommonWnd::OnCheckBtn()
{

// Check value of all cells before Check&Reflect
	int language = m_pDoc->GetData()->m_Init.m_Language;
	long startRow = 2;
	int rowNum = m_pDoc->GetData()->m_vRegIC.size() + startRow;
	int colNum = m_GridCtrl->GetCols();
	for (int rowIdx = startRow; rowIdx < rowNum; rowIdx++) {
// #DUCDT131121: Don't check if cell is disable
		CBLE_GridCell *pCell = m_GridCtrl->GetCell(rowIdx, IC_TYPE);
		if (pCell->IsEnable()) {
			break;
		}
		for (int colIdx = IC_TYPE; colIdx < colNum; colIdx++) {
			bool r = CheckInputValue(rowIdx, colIdx);
			if (!r) {
				m_GridCtrl->SetMarkCell(rowIdx, colIdx);
				Invalidate();
				theApp.CBTMessageBox(this->m_hWnd, CheckInvalid[language], MB_OK, language);

				// Write log file: missing value
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, CheckInvalid[language], "", "");
				return;
			}
		}
	}

	// Reset restore buffer
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore();

	TRACE("[Edit][C&R]CBLE_ CommonWnd::On CheckBtn()Check,Refrect-Start\n");
	// Update modified flag
	m_pDoc->SetModifiedFlag(1);
	vector<TBLE_RegIC> vRegNo;

	rowNum = m_GridCtrl->GetRows();
	for(long row = startRow; row < rowNum; row++){
		TBLE_RegIC RegNo;
		// IC type
		RegNo.m_Type = atoi(m_GridCtrl->GetCellText(row, IC_TYPE));
		if(RegNo.m_Type == 0) break;
		// RegNo
		RegNo.m_RegNo = row - startRow + 1;
		// IC size X
		RegNo.m_SizeX = atof(m_GridCtrl->GetCellText(row, IC_SIZE_X));
		// IC size Y
		RegNo.m_SizeY = atof(m_GridCtrl->GetCellText(row, IC_SIZE_Y));
		// Check if user left IC size blank
		if (RegNo.m_SizeX == 0 || RegNo.m_SizeY == 0) {
			//AfxMessageBox(WARNING_MESSAGE_ICSIZEMISSING);
			theApp.CBTMessageBox(this->m_hWnd, ICSizeMissing[language], MB_OK, language);

			// Write log file: missing value
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ICSizeMissing[language], "", "");
			return;
		}
		// IC pitch X
		RegNo.m_PitchX = atof(m_GridCtrl->GetCellText(row, IC_PITCH_X));
		// IC pitch Y
		RegNo.m_PitchY = atof(m_GridCtrl->GetCellText(row, IC_PITCH_Y));
		if (RegNo.m_PitchY == 0 || RegNo.m_PitchX == 0) {
			//AfxMessageBox(WARNING_MESSAGE_ICPITCHMISSING);
			theApp.CBTMessageBox(this->m_hWnd, ICPitchMissing[language], MB_OK, language);

			// Write log file: missing value
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ICPitchMissing[language], "", "");

			return;
		}
		// IC startpos X
		RegNo.m_StartPosX = atof(m_GridCtrl->GetCellText(row, START_POS_X));
		// IC startpos Y
		RegNo.m_StartPosY = atof(m_GridCtrl->GetCellText(row, START_POS_Y));
		// IC number X
		RegNo.m_NumberX = atoi(m_GridCtrl->GetCellText(row, NUMBER_X));
		// IC number Y
		RegNo.m_NumberY = atoi(m_GridCtrl->GetCellText(row, NUMBER_Y));
		if (RegNo.m_NumberX == 0 || RegNo.m_NumberY == 0) {
			//AfxMessageBox(WARNING_MESSAGE_NUMBERMISSING);
			theApp.CBTMessageBox(this->m_hWnd, ICNumMissing[language], MB_OK, language);

			// Write log file: missing value
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ICNumMissing[language], "", "");

			return;
		}
		// IC Angle
		RegNo.m_Angle = atof(m_GridCtrl->GetCellText(row, ANGLE));
		
		if (m_autoToolChange == 4) {
			// IC tool L
			RegNo.m_ToolL = atoi(m_GridCtrl->GetCellText(row, TOOL_L));
			if (RegNo.m_ToolL == 0) {
				RegNo.m_ToolL = 1;
			}
//#DMV170622 Disable Tool Change (S)
			// IC tool R
//			RegNo.m_ToolR = atoi(m_GridCtrl->GetCellText(row, TOOL_R));
//			if (RegNo.m_ToolR == 0) {
//				RegNo.m_ToolR = 1;
//			}
//#DMV170622 Disable Tool Change(E)
			if ((m_colletteNo != 0) && (m_ejectorNo != 1)) { // has tool collumn and collette collumn
				// IC collette L
				RegNo.m_ColletteL = atoi(m_GridCtrl->GetCellText(row, COLLETTE_L));
//#DMV170622 Disable Tool Change (S)
				// IC collette R
//				RegNo.m_ColletteR = atoi(m_GridCtrl->GetCellText(row, COLLETTE_R));
//#DMV170622 Disable Tool Change (E)
				// IC eject L
				RegNo.m_EjectL = atoi(m_GridCtrl->GetCellText(row, EJECTER_L));
//#DMV170622 Disable Tool Change (S)
				// IC eject R
//				RegNo.m_EjectR = atoi(m_GridCtrl->GetCellText(row, EJECTER_R));
//#DMV170622 Disable Tool Change (E)
			}
		} else { // in case tool collumn is missing
			if ((m_colletteNo != 0) && (m_ejectorNo != 1)) { // missing tool collumn but has collette collumn
				// IC collette L
				RegNo.m_ColletteL = atoi(m_GridCtrl->GetCellText(row, TOOL_L));
//#DMV170622 Disable Tool Change (S)				
				// IC collette R
//				RegNo.m_ColletteR = atoi(m_GridCtrl->GetCellText(row, TOOL_R));
//#DMV170622 Disable Tool Change (E)
				// IC eject L
				RegNo.m_EjectL = atoi(m_GridCtrl->GetCellText(row, COLLETTE_L));
//#DMV170622 Disable Tool Change (S)
				// IC eject R
//				RegNo.m_EjectR = atoi(m_GridCtrl->GetCellText(row, COLLETTE_R));			
//#DMV170622 Disable Tool Change (E)
			}
		}
		

		// Add new RegNo
		vRegNo.push_back(RegNo);
	}

	// --------------------
	// Update data to model
// #MH130926-01: Not need change status if change shape
	//bool shapeChanged = (m_nShape == m_lastShape) ? false : true;

	// Write log
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_CHECKREFELCT, DBLE_LOGFILE_COMMON, "");

	bool shapeChanged = false;
	m_pDoc->GetData()->UpdateRegNo(vRegNo, shapeChanged);		// Ic����������,���̊֐��̎��Ԃ��|����.
	m_lastShape = m_nShape;

	StopWatch	swSetRegion;swSetRegion.Start(TRUE);		// ���v���ԑ���
	// Set region for all ICs
	m_pDoc->GetData()->GetSubstrate()->SetRegionAllICs();

	StopWatch	swCheck;swCheck.Start(TRUE);
	// Check and reflect only setting in option is check and reflect
	if (m_pDoc->GetSetting() == 1) { // if setting in option is reflect only then skip
		CBLE_ProgressBar progressDlg;
		progressDlg.SetDocument(m_pDoc);
		progressDlg.m_Type = DBLE_PROGRESSBAR_CHCK;
		progressDlg.m_bDisplay = m_pDoc->GetData()->GetSubstrate()->PerformanceChecking();
		
		if (progressDlg.DoModal() != IDOK) {
			return;
		}
	}
	TRACE("[Edit]  CBLE_ CommonWnd::On CheckBtn()check time=%dm:%ds(%d)\n",swCheck.readMin(),swCheck.readSec(),swCheck.Read()/1000);

	// Move center to overlapped ICs
	CBLE_LocateEditWnd* p_Edit = (CBLE_LocateEditWnd* )GetParent();
	int zoomScale = p_Edit->GetZoomScale();
	if (m_pDoc->m_vZoom[zoomScale] >= DBLE_EDITWND_MINSCALE) {
		p_Edit->GetLayoutWnd()->SetScale(m_pDoc->m_vZoom[zoomScale],false);
	}

	// Update view
	ResetGridCtrl(false);
	AddGridData();
	// Post message to redraw the parent window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_REGNO, 0, 0);
	TRACE("[Edit]CBLE_ CommonWnd::On CheckBtn()Check,Refrect-Finish\n");
}

void CBLE_CommonWnd::AutoFillICSize(int row, int col)
{
	if ((col == IC_TYPE) || (col == IC_SIZE_X) || (col == IC_SIZE_Y)) {
		int icType = atof (m_GridCtrl->GetCellText(row, IC_TYPE));
		int rowMax = m_GridCtrl->GetRows();
		for (int idx = 0; idx < rowMax; idx++) {
			int value = atof (m_GridCtrl->GetCellText(idx, IC_TYPE));
			if ((idx != row) && (value == icType) && (value != 0)) {
				if (col == IC_TYPE) {
					m_GridCtrl->SetCellText(row, IC_SIZE_X, m_GridCtrl->GetCellText(idx, IC_SIZE_X));
					m_GridCtrl->SetCellText(row, IC_SIZE_Y, m_GridCtrl->GetCellText(idx, IC_SIZE_Y));
				} else {
					// Update new value of ic size to other row
					m_GridCtrl->SetCellText(idx, IC_SIZE_X, m_GridCtrl->GetCellText(row, IC_SIZE_X));
					m_GridCtrl->SetCellText(idx, IC_SIZE_Y, m_GridCtrl->GetCellText(row, IC_SIZE_Y));
				}
			}
		}
	}
}


void CBLE_CommonWnd::UpdateView()
{
	// Reset DeviceName
	int lang = m_pDoc->GetData()->m_Init.m_Language;
	CString label;
	//GetDlgItem(IDC_COMM_DEVNAME)->GetWindowText(_T(label));
	label = DeviceNameLang[lang] + ": " + m_pDoc->GetDeviceName();
	GetDlgItem(IDC_COMM_DEVNAME)->SetWindowText(_T(label));
	// Reset shape name
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_COMM_CBB_SHAPE));
	int shapeSize = m_pDoc->GetData()->m_vShape.size();

	//Update shape of substrate
	CString shape;
	CString sizeX, sizeY;
	sizeX.Format(_T("%d"), m_pDoc->GetData()->GetSubstrate()->m_SizeX);
	sizeY.Format(_T("%d"), m_pDoc->GetData()->GetSubstrate()->m_SizeY);

	// Get current shape of substrate
	if (m_pDoc->GetData()->GetSubstrate()->m_Shape == DBLE_SHAPE_SQUARE) {
		shape = shape + "Square" + " " + sizeX + "x" + sizeY + "mm";
	} else {
		shape = shape + "Round" + " " + sizeX + "mm";
	}

	for(UINT idx = 0; idx < shapeSize; idx ++){
		// Check if current shape is display on combo box
		if (shape.CompareNoCase(m_pDoc->GetData()->m_Init.m_ShapeName[idx]) == 0) {
			m_nShape = idx;
		}
	}
	pCbb->SetCurSel(m_nShape);// Add content for substrate shape combobox

	ResetGridCtrl(true);
	AddGridData();
}

CWnd* CBLE_CommonWnd::GetEditWnd()
{
	return m_GridCtrl->GetEditWnd();
}

/* 
* Change focus when select a cell on info window or common window
*/
void CBLE_CommonWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	// Ask parent to update receive key window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_REVWND, (WPARAM)m_hWnd, 0);
}

/*
*	Change language for common window
*/
void CBLE_CommonWnd::ChangeLanguage()
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	for (UINT id = IDC_COMM_DEVNAME; id <= IDC_COMM_LBL_TITLE; id ++) {
		for (int idx = 0; idx < DBLE_LANGUAGE_ITEMS; idx ++) {
			if ((id == m_pDoc->m_DialogItems[idx].m_ID) && (m_pDoc->m_DialogItems[idx].m_Name.Compare("") != 0)) {
				GetDlgItem(id)->SetWindowText(m_pDoc->m_DialogItems[idx].m_Name);
				break;
			}
		}
	}
}

/**
* Update grid
*/
void CBLE_CommonWnd::UpdateGrid(int row, int col, CString val, CString oldVal)
{
	// Auto fill IC size
	if ((col == IC_TYPE) || (col == IC_SIZE_X) || (col == IC_SIZE_Y)) {
		AutoFillICSize(row, col);
	}
	m_GridCtrl->SetCellText(row, col, val);
	// Check if IcType = 0, then disable all cells after that
	if ((col == IC_TYPE) && (atof(val) == 0)) {
		int rowMax = m_GridCtrl->GetRows();
		for (int i = row; i < rowMax; i++) {
			m_GridCtrl->SetRowHeader(i, true);
			m_GridCtrl->SetRowText(i,"");
		}
		m_GridCtrl->GetCell(row, col)->SetHeader(false);
	} else if ((col == IC_TYPE) && (atof(val) != 0) && (atof(/*m_GridCtrl->GetCell(row, col)->GetOldText()*/oldVal) == 0)) {
		// If change IcType form 0 to other, then enable all cells after that
		int rowMax = m_GridCtrl->GetRows();
		for (int i = row; i < rowMax; i++) {

// #DUCDT131121: If have row with IC_TYPE is 0, do not allow enable it
			CString tmp = (m_GridCtrl->GetCell(i, IC_TYPE))->GetOldText();
			if (atof(tmp) == 0) {
				m_GridCtrl->GetCell(i, IC_TYPE)->SetHeader(false);
				break;
			}
			m_GridCtrl->SetRowHeader(i, false);

// #DUCDT131121: Auto fill IC size after enable row to sure all RegNo with same IC type have same IC size
			// Auto fill IC size
			AutoFillICSize(i, IC_TYPE);
		}
		m_GridCtrl->SetColHeader(0, true);
	}
	// Write log file: change value
	switch (col) {
	case IC_TYPE :
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_ICTYPE, oldVal + " -> " + val);
		break;
	case IC_SIZE_X :
	case IC_SIZE_Y :
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_ICSIZE, oldVal + " -> " + val);
		break;
	case IC_PITCH_X :
	case IC_PITCH_Y :
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_ICPITCH, oldVal + " -> " + val);
		break;
	case START_POS_X :
	case START_POS_Y :
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_STARTPOS, oldVal + " -> " + val);
		break;
	case NUMBER_X :
	case NUMBER_Y :
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_ICNUMBER, oldVal + " -> " + val);
		break;
	case ANGLE :
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_ANGLE, oldVal + " -> " + val);
		break;
	case TOOL_L :
//	case TOOL_R :				//#DMV170622 Disable Tool Change
		if (m_autoToolChange == 4) {
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_TOOL, oldVal + " -> " + val);
		} else if ((m_colletteNo != 0) && ((m_ejectorNo != 1))) {
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_COLLETTE, oldVal + " -> " + val);
		} else {
			//theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_EJECTER, oldVal + " -> " + val);
		}
		break;
	case COLLETTE_L :
//	case COLLETTE_R :			//#DMV170622 Disable Tool Change
		if ((m_colletteNo != 0) && (m_autoToolChange == 4) && (m_ejectorNo != 1)) {
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_COLLETTE, oldVal + " -> " + val);
		} else if ((m_colletteNo != 0) && (m_autoToolChange != 4) && (m_ejectorNo != 1)) {
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_EJECTER, oldVal + " -> " + val);
		} else {
			// do nothing
		}
		break;
	case EJECTER_L :
//	case EJECTER_R :			//#DMV170622 Disable Tool Change
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_CHANGEVALUE, DBLE_LOGFILE_COMMON, DBLE_LOGFILE_COMM_EJECTER, oldVal + " -> " + val);
		break;
	default:
		break;
	}
}

/**
* Restore state
*/
void CBLE_CommonWnd::RestoreState()
{
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	if (!pCareTaker->Restoreable() || (pCareTaker->GetLastKind() != IDD_COM_SETTING_DLG)) {
		return;
	}
	// Get data
	CBLE_Memento mem = pCareTaker->GetMemento();
	void* tmp = mem.GetState();
	vector<TBLE_GridData> *v_Grid = static_cast<vector<TBLE_GridData> *>(tmp);
	TBLE_GridData grid = v_Grid->at(0);

	CString oldVal = m_GridCtrl->GetCell(grid.row, grid.col)->GetText();
	m_GridCtrl->SetCellText(grid.row, grid.col, grid.val);

	// Update grid
	UpdateGrid(grid.row, grid.col, grid.val, oldVal);

	// Reset all marked cells before
	m_GridCtrl->ResetMarkCells();

	// Mark cell
	m_GridCtrl->SetMarkCell(grid.row, grid.col);

	Invalidate();

	delete v_Grid;
	
}

/**
* Catch Ctrl + Z to restore
*/
BOOL CBLE_CommonWnd::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN /*&& pMsg->wParam == VK_CONTROL*/){
		if ((GetKeyState(0x5A) & 0x8000) && (GetKeyState(VK_CONTROL) & 0x8000)) {
			CBLE_FrameWnd *frame = (CBLE_FrameWnd*)GetParentFrame();
			frame->OnRestoreState();
		}
    }	
    return CDialog::PreTranslateMessage(pMsg);
}


/**
* Update Grid control
*/
void CBLE_CommonWnd::UpdateCommonSetting()
{
	// Reset DeviceName
	int lang = m_pDoc->GetData()->m_Init.m_Language;
	CString label;
	//GetDlgItem(IDC_COMM_DEVNAME)->GetWindowText(_T(label));
	label = DeviceNameLang[lang] + ": " + m_pDoc->GetDeviceName();
	GetDlgItem(IDC_COMM_DEVNAME)->SetWindowText(_T(label));
	// Reset shape name
	CComboBox* pCbb = ((CComboBox*)GetDlgItem(IDC_COMM_CBB_SHAPE));
	pCbb->ResetContent();
	int shapeSize = m_pDoc->GetData()->m_vShape.size();
	for(UINT idx = 0; idx < shapeSize; idx ++){
		pCbb->AddString(m_pDoc->GetData()->m_Init.m_ShapeName[idx]);
	}
	//Update shape of substrate
	CString shape;
	CString sizeX, sizeY;
	sizeX.Format(_T("%d"), m_pDoc->GetData()->GetSubstrate()->m_SizeX);
	sizeY.Format(_T("%d"), m_pDoc->GetData()->GetSubstrate()->m_SizeY);

	// Get current shape of substrate
	if (m_pDoc->GetData()->GetSubstrate()->m_Shape == DBLE_SHAPE_SQUARE) {
		shape = shape + "Square" + " " + sizeX + "x" + sizeY + "mm";
	} else {
		shape = shape + "Round" + " " + sizeX + "mm";
	}

	for(idx = 0; idx < shapeSize; idx ++){
		// Check if current shape is display on combo box
		if (shape.CompareNoCase(m_pDoc->GetData()->m_Init.m_ShapeName[idx]) == 0) {
			m_nShape = idx;
		}
	}
	pCbb->SetCurSel(m_nShape);// Add content for substrate shape combobox

	// Delete old grid
	m_GridCtrl->OnOK();
	//delete m_GridCtrl;


	// Create grid control
	CRect rect;
	GetDlgItem(IDC_COMM_GRID)->GetWindowRect(rect);
	ScreenToClient(&rect);
	int numberOfCol = 11;
	numberOfCol = (m_autoToolChange != 4) ? numberOfCol : numberOfCol + /*2*/1;	//#DMV170622 Disable Tool Change
	if ((m_colletteNo != 0) && (m_ejectorNo != 1)) {
		numberOfCol = numberOfCol + /*4*/2;										//#DMV170622 Disable Tool Change
	}
//	m_GridCtrl = new CBLE_GridCtrl(7, numberOfCol);
	m_GridCtrl = new CBLE_GridCtrl( 7-MINUS_COLUM_IN_SURROUND, numberOfCol);  //#THAIHV170613
	//m_GridCtrl->SetDocument(m_pDoc);
	m_GridCtrl->Create(rect, this, m_pDoc);
	// Init grid control
	InitGridCtrl();
	ResetGridCtrl(true);
	AddGridData();

	
}
///////////////////////////////////////////////////////////
//  CBLE_ExpandView.cpp
//  Implementation of the Class CBLE_ExpandView
//  Created on:      16-Thg7-2013 1:51:31 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_ExpandView.h"

#define DBLE_EXPAND_VIEW_BKG_CLR				RGB(240, 240, 240)
#define DBLE_EXPAND_VIEW_VIR_DC_SIZE_MORE		10
#define DBLE_EXPAND_VIEW_LIMIT_N				10
#define DBLE_EXPAND_VIEW_FONT_NAME				_T("Arial")
#define DBLE_EXPAND_VIEW_FONT_SIZE				70
#define DBLE_EXPAND_VIEW_FONT_CLR1				RGB(250, 0, 0)
#define DBLE_EXPAND_VIEW_FONT_CLR2				RGB(0, 0, 250)
#define DBLE_EXPAND_VIEW_FRAME_CLR				RGB(255, 0, 250)
#define DBLE_EXPAND_VIEW_FRAME_BDR				6
#define DBLE_EXPAND_VIEW_BORDER					10


/////////////////////////////////////////////////////////////////////////////
// CBLE_ExpandView

IMPLEMENT_DYNCREATE(CBLE_ExpandView, CScrollView)

CBLE_ExpandView::CBLE_ExpandView()
{
	m_pReg = NULL;
	m_pDoc = NULL;
	m_vIC.clear();
	m_vN.clear();

	m_MinX = -1;
	m_MaxX = -1;
	m_MinY = -1;
	m_MaxY = -1;

	m_SizeX = 0.0;
	m_SizeY = 0.0;

	m_MaxN = 0;

	m_CenX = 0.0;
	m_CenY = 0.0;
}


CBLE_ExpandView::~CBLE_ExpandView()
{
}


BEGIN_MESSAGE_MAP(CBLE_ExpandView, CScrollView)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_MOUSEACTIVATE()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_ExpandView drawing

void CBLE_ExpandView::OnDraw(CDC* pDC)
{
	// Draw to virtual DC
	DrawToMemDC();
	// Draw to real DC
	CRect rect;
	GetWindowRect(rect);
	pDC->BitBlt(GetScrollPosition().x, GetScrollPosition().y, rect.Width(), rect.Height(),
		&m_MemDC, 0, 0, SRCCOPY);
}

void CBLE_ExpandView::DrawToMemDC()
{
	// Get total size
	CSize size = GetTotalSize();
	// Get region
	CRect rect(CPoint(0, 0), GetTotalSize());
	// Draw background to virtual DC
	m_MemDC.FillSolidRect(rect, DBLE_EXPAND_VIEW_BKG_CLR);

	// Set the draw size
	rect.DeflateRect(DBLE_EXPAND_VIEW_BORDER, DBLE_EXPAND_VIEW_BORDER);
	CBLE_IC* pStartIC = FindIC(m_MinX, m_MinY);
	double sizeX = FindIC(m_MaxX, m_MinY)->m_BgPosX - pStartIC->m_BgPosX;
	// Change the coordinate
	double sizeY = pStartIC->m_BgPosY - FindIC(m_MinX, m_MaxY)->m_BgPosY;
	double scale = min(rect.Width()/(sizeX + m_pReg->m_SizeX), rect.Height()/(sizeY + m_pReg->m_SizeY));

	double centerX = pStartIC->m_BgPosX + sizeX/2;
	double centerY = pStartIC->m_BgPosY - sizeY/2;

	// Set viewport
	CPoint viewPnt = rect.CenterPoint();
	viewPnt.Offset(- GetScrollPosition());
	CPoint oldViewPnt = m_MemDC.SetViewportOrg(viewPnt);
	// Set color
	m_MemDC.SetBkMode(TRANSPARENT);
	COLORREF oldClr = m_MemDC.GetTextColor();
	// Set font
	CFont font;
	font.CreatePointFont(DBLE_EXPAND_VIEW_FONT_SIZE, DBLE_EXPAND_VIEW_FONT_NAME);
	CFont* pOldFont = m_MemDC.SelectObject(&font);

	// Draw all selected ICs
	CBLE_IC* pIC = NULL;
	int icSize = m_vIC.size();
	for(UINT idx = 0; idx < icSize; idx ++){
		pIC = m_vIC[idx];
		// Store offset value
		double offsetX = pIC->m_OffsetX;
		double offsetY = pIC->m_OffsetY;
		// Set the new offset value
		pIC->m_OffsetX -= centerX;
		pIC->m_OffsetY -= centerY;
		// Draw IC
		pIC->Draw(&m_MemDC, scale, DBLE_MODE_LOCATE_EDIT_HIDE_INVALID, &(m_pDoc->GetData()->m_StatusColor), false);
		DrawICText(&m_MemDC, pIC, scale);
		// Restore offset value
		pIC->m_OffsetX = offsetX;
		pIC->m_OffsetY = offsetY;
	}
	// Draw N frames
	int nSize = m_vN.size();
	for(idx = 0; idx < nSize; idx ++){
		DrawNFrame(&m_MemDC, m_vN[idx], -centerX, -centerY, scale);
	}
	
	// Restore
	m_MemDC.SetViewportOrg(oldViewPnt);
	m_MemDC.SelectObject(pOldFont);
	m_MemDC.SetTextColor(oldClr);
}

BOOL CBLE_ExpandView::OnEraseBkgnd(CDC* pDC)
{
	// do nothing
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_ExpandView diagnostics

#ifdef _DEBUG
void CBLE_ExpandView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CBLE_ExpandView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBLE_ExpandView message handlers

// This method needs to be overridden to prevent an assertion
int CBLE_ExpandView::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message)
{
	if(message != WM_MOUSEMOVE){
		SetFocus();
	}
	return MA_ACTIVATE;
}

void CBLE_ExpandView::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

void CBLE_ExpandView::SetScale()
{
	// Get region
	CRect rect;
	GetClientRect(&rect);
	// Set scroll size
	long wndStyle = GetWindowLong(GetSafeHwnd(), GWL_STYLE);
	int HSize = ((wndStyle & WS_HSCROLL) == 0) ? 0 : GetSystemMetrics(SM_CXHSCROLL);
	int VSize = ((wndStyle & WS_VSCROLL) == 0) ? 0 : GetSystemMetrics(SM_CXVSCROLL);
	CSize size = rect.Size() + CSize(HSize, VSize);
	SetScrollSizes(MM_TEXT, size);
}

int CBLE_ExpandView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if(CScrollView::OnCreate(lpCreateStruct) == -1) return -1;
	// Set scale
	SetScale();
	// Get the window region
	CRect rect;
	GetWindowRect(rect);
	// Create the virtual DC
	CDC* pDC = GetDC();
	m_MemDC.CreateCompatibleDC(pDC);
	m_MemBmp.CreateCompatibleBitmap(pDC,
		rect.Width() + DBLE_EXPAND_VIEW_VIR_DC_SIZE_MORE, rect.Height() + DBLE_EXPAND_VIEW_VIR_DC_SIZE_MORE);
	m_MemDC.SelectObject(&m_MemBmp);
	// Initialize data
	InitData();

	return 0;
}

void CBLE_ExpandView::InitData()
{
	// Set all selected IC
	m_vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	m_pReg = m_vIC[0]->m_pRegIC;
	// Find maximum & minimum index
	m_MinX = m_vIC[0]->m_indexX;
	m_MinY = m_vIC[0]->m_indexY;
	m_MaxX = m_vIC[0]->m_indexX;
	m_MaxY = m_vIC[0]->m_indexY;
	int icSize = m_vIC.size();
	for(UINT idx = 0; idx < icSize; idx ++){
		if(m_MinX > m_vIC[idx]->m_indexX) m_MinX = m_vIC[idx]->m_indexX;
		if(m_MinY > m_vIC[idx]->m_indexY) m_MinY = m_vIC[idx]->m_indexY;
		if(m_MaxX < m_vIC[idx]->m_indexX) m_MaxX = m_vIC[idx]->m_indexX;
		if(m_MaxY < m_vIC[idx]->m_indexY) m_MaxY = m_vIC[idx]->m_indexY;
	}
	// Find the N number
	//m_MaxN = min(m_MaxX - m_MinX, m_MaxY - m_MinY)/2; // old algorithm
	m_MaxN = max(m_MaxX - m_MinX, m_MaxY - m_MinY)/2;	// new algorithm
}

CBLE_IC* CBLE_ExpandView::FindIC(int idxX, int idxY)
{
	int icSize = m_vIC.size();
	for(UINT idx = 0; idx < icSize; idx ++){
		if(m_vIC[idx]->m_indexX != idxX) continue;
		if(m_vIC[idx]->m_indexY != idxY) continue;
		return m_vIC[idx];
	}
	return NULL;
}

void CBLE_ExpandView::DrawICText(CDC* pDC, CBLE_IC* pIC, double scale)
{
	if(pIC == NULL) return;
	// Calculate the N number
	int N = FindNValue(pIC);
	// Set the text
	CString text = _T("N");
	if(N != 0){
		text.Format(_T("N%d"), N);
	}
	// Set text color
	pDC->SetTextColor((N%2 == 0) ? DBLE_EXPAND_VIEW_FONT_CLR1 : DBLE_EXPAND_VIEW_FONT_CLR2);
	// Draw text
	CSize textSize = pDC->GetTextExtent(text);
	pDC->TextOut(int(pIC->GetPosX()*scale) - textSize.cx/2, -int(pIC->GetPosY()*scale) - textSize.cy/2, text);
}

int CBLE_ExpandView::FindNValue(CBLE_IC* pIC)
{
	if(pIC == NULL) return -1;
	// old algorithm
	//int idxX = min(abs(pIC->m_indexX - m_MinX), abs(pIC->m_indexX - m_MaxX));
	//int idxY = min(abs(pIC->m_indexY - m_MinY), abs(pIC->m_indexY - m_MaxY));
	//return (m_MaxN - min(idxX, idxY));

	// new algorithm (follow comment from custommer)
	int midXmin = m_MinX + (m_MaxX - m_MinX)/2;
	int midXmax = ((m_MaxX - m_MinX)%2 == 0) ? midXmin : (midXmin + 1);
	int midYmin = m_MinY + (m_MaxY - m_MinY)/2;
	int midYmax = ((m_MaxY - m_MinY)%2 == 0) ? midYmin : (midYmin + 1);

	int NX = min(abs(pIC->m_indexX - midXmin), abs(pIC->m_indexX - midXmax));
	int NY = min(abs(pIC->m_indexY - midYmin), abs(pIC->m_indexY - midYmax));
	return max(NX, NY);
}

/**
* ????
*/
void CBLE_ExpandView::FindNICs(int N, vector<CBLE_IC*>& vIC)
{
	vIC.clear();
	if(N < 0) return;

	int icSize = m_vIC.size();
	for(UINT idx = 0; idx < icSize; idx ++){
		if(FindNValue(m_vIC[idx]) != N) continue;
		vIC.push_back(m_vIC[idx]);
	}
}

/**
* Find index of center IC
*/
void CBLE_ExpandView::FindCenterIC()
{
	vector<CBLE_IC*> vICcenter;
	FindNICs(0, vICcenter);

	m_CenX = 0.0;
	m_CenY = 0.0;
	int centerSize = vICcenter.size();
	for (int i = 0; i < centerSize; i++) {
		m_CenX += vICcenter[i]->m_indexX;
		m_CenY += vICcenter[i]->m_indexY;
	}

	m_CenX /= centerSize;
	m_CenY /= centerSize;
}

/**
* Calculate Offset of ICs after expanding
*/
void CBLE_ExpandView::ExpandICs(int Nstart, int Nend, double dX, double dY)
{
	// Vector of alls IC on N-cycle
	vector<CBLE_IC*> vIC;
	CBLE_IC* pIC;			// pointer to IC will expand

	// Expand all ICs from N-start to N-end
	for (int i = Nstart + 1; i <= Nend; i++) {
		// Clear vector IC and create new data for new i-cycle
		vIC.clear();
		FindNICs(i, vIC);

		// Let i-cycle has size sizeX * sizeY
		// min, max index of ICs on i-cycle
		int minX = floor(m_CenX) - i;
		int maxX = floor(m_CenX) + i;
		// If sizeX is even
		if (m_CenX > floor(m_CenX)) {
			maxX++;
		}
		int minY = floor(m_CenY) - i;
		int maxY = floor(m_CenY) + i;
		// If sizeY is even
		if (m_CenY > floor(m_CenY)) {
			maxY++;
		}

		int vectorSize = vIC.size();
		// Expand each IC on N-cycle
		for (int j = 0; j < vectorSize; j++) {
			pIC = vIC[j];
			// Calculate offset of ICs on upper row and lower row of cycle
			if (pIC->m_indexX != maxX && pIC->m_indexX != minX) {
				pIC->m_OffsetX += dX * (pIC->m_indexX - m_CenX);		// Offset X direction = Index X direction
				int dirY = (pIC->m_indexY == minY) ? 1 : -1;			// direction to expand offsetY
				pIC->m_OffsetY += dirY * dY * (i - Nstart);				// Offset Y direction = (-1) * Index Y direction
			}else if (pIC->m_indexY != maxY && pIC->m_indexY != minY) {
			// Calculate offset of ICs on left column and right column of cycle
				pIC->m_OffsetY += dY * (m_CenY - pIC->m_indexY);		// Offset Y direction = (-1) * Index Y direction
				int dirX = (pIC->m_indexX == minX) ? -1 : 1;			// direction to expand offsetY
				pIC->m_OffsetX += dirX * dX * (i - Nstart);				// Offset Y direction = (-1) * Index Y direction
			} else {
				// If IC is at corner of cycle
				pIC->m_OffsetX += dX * (pIC->m_indexX - m_CenX);		// Offset X direction = Index X direction
				pIC->m_OffsetY += dY * (m_CenY - pIC->m_indexY);		// Offset Y direction = (-1) * Index Y direction
			}
		}
	}

	// Expand ICs from N-end + 1 to N-max
	// I dont want to merge this for-loop with for-loop above
	for(i = Nend + 1; i <= m_MaxN; i++) {
		// Clear vector IC and create new data for new N-cycle
		vIC.clear();
		FindNICs(i, vIC);
		int vectorSize = vIC.size();

		// With cycles that out side of Nend, just change offset for ICs to keep the Pitch
		// Expand each IC if need, there are 4 ICs not change offset (at 4 corners of N-cycle)
		for (int j = 0; j < vectorSize; j++) {
			pIC = vIC[j];
			int dirX = (pIC->m_indexX > m_CenX) ? 1 : -1;		// offset X direction
			int dirY = (pIC->m_indexY > m_CenY) ? -1 : 1;		// offset Y direction
			CBLE_IC* pBaseIC;									// IC of (j-1)-cycle that has same IdxX or IdxY. Offset of this IC has already calculated
																// offset of pIC will be calculated base on offset of pBaseIC

			if (pIC->m_indexX != m_MaxX && pIC->m_indexX != m_MinX) {
				pBaseIC = FindIC(pIC->m_indexX, pIC->m_indexY + dirY);
				pIC->m_OffsetY += pBaseIC->m_OffsetY - (pBaseIC->m_TargetBgPosY - pBaseIC->m_BgPosY); // new offset - old offset
			} else {
				if (pIC->m_indexY != m_MaxY && pIC->m_indexY != m_MinY) {
					pBaseIC = FindIC(pIC->m_indexX - dirX, pIC->m_indexY);
					pIC->m_OffsetX += pBaseIC->m_OffsetX - (pBaseIC->m_TargetBgPosX - pBaseIC->m_BgPosX);	// new offset - old offset
				}
			}
		}
	}
}

int CBLE_ExpandView::GetMaxN()
{
	return m_MaxN;
}

void CBLE_ExpandView::SetNVector(vector<int> vN)
{
	m_vN = vN;
}

void CBLE_ExpandView::DrawNFrame(CDC* pDC, int N, double offsetX, double offsetY, double scale)
{
	// Find all ICs
	vector<CBLE_IC*> vIC;
	FindNICs(N, vIC);
	if(vIC.empty()) return;
	// Find the min, max position
	double minX = 0.0, minY = 0.0, maxX = 0.0, maxY = 0.0;

	// Store offset value
	double resOffX = vIC[0]->m_OffsetX;
	double resOffY = vIC[0]->m_OffsetY;

	// Set the new offset value
	vIC[0]->m_OffsetX += offsetX;
	vIC[0]->m_OffsetY += offsetY;
	minX = maxX = vIC[0]->GetPosX()*scale;
	minY = maxY = vIC[0]->GetPosY()*scale;

	// Restore offset value
	vIC[0]->m_OffsetX = resOffX;
	vIC[0]->m_OffsetY = resOffY;

	// Offset all ICs
	int icSize = vIC.size();
	for(UINT idx = 1; idx < icSize; idx ++){
		// Store offset value
		resOffX = vIC[idx]->m_OffsetX;
		resOffY = vIC[idx]->m_OffsetY;
		// Set the new offset value
		vIC[idx]->m_OffsetX += offsetX;
		vIC[idx]->m_OffsetY += offsetY;
		// Get pos
		double posX = vIC[idx]->GetPosX()*scale;
		double posY = vIC[idx]->GetPosY()*scale;
		// Set max, min
		if(minX > posX) minX = posX;
		if(minY > posY) minY = posY;
		if(maxX < posX) maxX = posX;
		if(maxY < posY) maxY = posY;
		// Restore offset value
		vIC[idx]->m_OffsetX = resOffX;
		vIC[idx]->m_OffsetY = resOffY;
	}

	// Draw frame
	CRect rect(CPoint(int(minX), int(minY)), CPoint(int(maxX), int(maxY)));
	rect.InflateRect(int((m_pReg->m_SizeX + DBLE_EXPAND_VIEW_FRAME_BDR)*scale/2),
		int((m_pReg->m_SizeY + DBLE_EXPAND_VIEW_FRAME_BDR)*scale/2));

	// Create pen
	CPen pen(PS_DASH, 1, DBLE_EXPAND_VIEW_FRAME_CLR);
	CPen* pOldPen = pDC->SelectObject(&pen);
	// Create null brush
	CBrush* pOldBrush = pDC->GetCurrentBrush();
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	// Draw the rectangle
	pDC->Rectangle(rect);
	// Restore brush and pen
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);
}

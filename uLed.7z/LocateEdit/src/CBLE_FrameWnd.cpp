///////////////////////////////////////////////////////////
//  CBLE_FrameWnd.cpp
//  Implementation of the Class CBLE_FrameWnd
//  Created on:      16-Thg7-2013 10:25:07 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"

#include "CBLE_FrameWnd.h"
#include "CBLE_Doc.h"
#include "CBLE_Util.h"
#include "CBLE_ProgressBar.h"
#include "CBLE_CareTaker.h"
// Position of SubInfo in command lines
#define SUBINFO_POS							2
#define RIGHTSIDE_POS						11

// Define message
//#define BLE_FRAME_MAPPING_METHOD_MESS		"Mapping method is not grade!"

/////////////////////////////////////////////////////////////////////////////
// Define message text for Japanese and English
//
CString MappingMethod[] =	{							
								_T("�}�b�s���O���\�b�h��GRADE���Ⴀ��܂���ł����B"),
								_T("Mapping method is not grade!"),
							};

CString MainMenuLanguage[] ={
								_T("�t�@�C��"),
								_T("��ҏW"),
								_T("����"),
								_T("�p�X���[�h"),
								_T("�E�B���h�E"),
								_T("�փ��[�v"),
							};

CString FileMenuLanguage[]=	{
								_T("�J�����g�J��"),
								_T("&�J��...\tCtrl+O"),
								_T("&����\tCtrl+S"),
								_T(""),
								_T("�I��"),
							};

CString EditMenuLanguage[]=	{
								_T("�ʒu�ҏW"),
								_T("�I�t�Z�b�g/�g��"),
								_T(""),
								_T("�}�b�s���O"),
							};

CString InfoMenuLanguage[]=	{
								_T("�����̏��"),
								_T("�E���̏��"),
							};

CString PassMenuLanguage[]=	{
								_T("�p�X���[�h"),
							};

CString WindowMenuLanguage[]=	{
								_T("���ׂĕ\��"),
							};

CString HelpMenuLanguage[]=	{
								_T("�o�[�W����"),
								_T("�I�v�V����"),
							};
/////////////////////////////////////////////////////////////////////////////
// CBLE_FrameWnd


IMPLEMENT_DYNCREATE(CBLE_FrameWnd, CFrameWnd)

BEGIN_MESSAGE_MAP(CBLE_FrameWnd, CFrameWnd)

	ON_WM_CREATE()
	// Call sub-tool
	ON_COMMAND_RANGE(ID_MENU_LOCATEEDIT, ID_MENU_CHECKREFLECT, OnStartSubWnd)
	ON_COMMAND(ID_MENU_ARRANGE, OnArrangeWnd)    //THAIHV 20151123 (E)
	ON_UPDATE_COMMAND_UI_RANGE(ID_MENU_LOCATEEDIT, ID_MENU_ARRANGE, OnUpdateSubWndCmd)
	// File command
	ON_UPDATE_COMMAND_UI_RANGE(ID_FILE_OPEN, ID_FILE_SAVE, OnUpdateFileCmd)

	ON_MESSAGE(WM_START_INSTANCE, OnStartInstance)

	ON_REGISTERED_MESSAGE(BLE_CTRL, OnSubInfoCtrl)

	ON_MESSAGE(WM_COLOR_CHANGE, OnColorChange)

	ON_MESSAGE(WM_INIT_COMPLETE, OnInitComplete)
	
	ON_MESSAGE(WM_CURROPEN_COMPLETE, OnCurrentOpenComplete)
	
	ON_MESSAGE(WM_UPDATE_OPTION, OnUpdateOption)

	ON_COMMAND(ID_EDIT_UNDO, OnRestoreState)
	// Close window
	ON_WM_CLOSE()
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CBLE_FrameWnd construction/destruction

CBLE_FrameWnd::CBLE_FrameWnd()
{
	// TODO: add member initialization code here
}

CBLE_FrameWnd::~CBLE_FrameWnd()
{
}

int CBLE_FrameWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{

	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// Set title
	SetTitle(DBLE_DIALOGNAME_EDIT);

#if 0
	// �L���������W�Ŕz�u
	CBLE_Util::GetWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_EDIT);
	// �����w����W�Ŕz�u
	SetWindowPos(&CWnd::wndTop,
		0, 0, DBLE_MAINWND_SIZEX, DBLE_MAINWND_SIZEY, SWP_SHOWWINDOW);
#endif
	/*if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);*/

	return 0;
}
void CBLE_FrameWnd::OnClose()
{
	CFrameWnd::OnClose();
}
BOOL CBLE_FrameWnd::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_FrameWnd diagnostics

#ifdef _DEBUG
void CBLE_FrameWnd::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CBLE_FrameWnd::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

//////////////////////////////////////////////////
// CBLE_FrameWnd message handlers

/**
 * Range info windows 
 */
//THAIHV 20151123 (E)
void CBLE_FrameWnd::OnArrangeWnd(){
	CRect rect;
	GetClientRect(&rect);
	if((IsWindow(m_SubInfoLWnd.m_hWnd) && m_SubInfoLWnd.IsWindowVisible())
		&& (IsWindow(m_SubInfoRWnd.m_hWnd) && m_SubInfoRWnd.IsWindowVisible())
		&& (rect.Width() >= 2 * DBLE_SUBINFOWND_SIZEX)
		&& (rect.Height() >= DBLE_SUBINFOWND_SIZEY)){
		m_SubInfoLWnd.MoveWindow(rect.left, rect.top, rect.Width()/2,rect.Height(), TRUE);
		m_SubInfoRWnd.MoveWindow(rect.right/2, rect.top, rect.Width()/2, rect.Height(), TRUE);
	}
}
//////////////////////////////////////////////////
// CBLE_FrameWnd Close Windows 

/**
 * Close Windows in Edit Mode
 */
//THAIHV 20151123 (C)
void CBLE_FrameWnd::CloseWnd(){
	if((IsWindow(m_LocateEditWnd.m_hWnd))&&(m_LocateEditWnd.IsWindowVisible())){
		m_LocateEditWnd.CloseWnd();
	}
	if((IsWindow(m_AdjustWnd.m_hWnd) != NULL)&&(m_AdjustWnd.IsWindowVisible())){
		m_AdjustWnd.CloseWnd();
	}
	if((IsWindow(m_MappingWnd.m_hWnd) != NULL)&&(m_MappingWnd.IsWindowVisible())){
		m_MappingWnd.CloseWnd();
	}

}

/////////////////////////////////////////////////////////////////////////////
// CBLE_FrameWnd message handlers

/**
 * Start a sub window 
 */
void CBLE_FrameWnd::OnStartSubWnd(int nID)
{
	POSITION pos = GetActiveDocument()->GetFirstViewPosition();
	CView* pView = GetActiveDocument()->GetNextView(pos);
	int mapMethod = 0;
	//char buf[BUFSIZ];
	CString filePath;
	switch(nID){
	case ID_MENU_LOCATEEDIT:
		// Set title for window
		SetTitle(DBLE_DIALOGNAME_EDIT);
		
		// Set title for window in case doc is initializing 
		SetWindowText(DBLE_FRAMENAME_EDITMODE);

		TRACE("[MENU][SubstEdit][LocateEdit]\n");
		CloseWnd();  //THAIHV 20151123 (C)
		if(!IsWindow(m_LocateEditWnd.m_hWnd)){
			// Check to see if SubstLocateEdit is start already but it's initializing doc
			if (m_LocateEditWnd.GetDocument() != NULL) {
				break;
			}
			m_LocateEditWnd.SetDocument((CBLE_Doc*)GetActiveDocument());
			m_LocateEditWnd.GetDocument()->SetMode(DBLE_EDIT_MODE);
			m_LocateEditWnd.GetDocument()->InitDoc();
			m_LocateEditWnd.Create(IDD_LOCATE_EDIT_DLG, pView);
			// Change language
			m_LocateEditWnd.ChangeLanguage();
		}else{
			m_LocateEditWnd.InitView();
		}
		// Do not allow select deleted IC
		m_LocateEditWnd.AllowSelectDeletedIC();

		//SetWindowText(DBLE_FRAMENAME_EDITMODE);
		break;
	case ID_MENU_ADJUST:
		TRACE("[MENU][SubstEdit][Offset,Expand]\n");
		// Set title
		SetTitle(DBLE_DIALOGNAME_EDIT);

		// Set title for window in case doc is initializing
		SetWindowText(DBLE_FRAMENAME_EDITMODE);
		CloseWnd(); // THAIHV 20151123 (C)
		if(!IsWindow(m_AdjustWnd.m_hWnd)){
			m_AdjustWnd.SetDocument((CBLE_Doc*)GetActiveDocument());
			m_AdjustWnd.Create(IDD_ADJUST_DLG, pView);
			// Change language
			m_AdjustWnd.ChangeLanguage();
		}else{
			m_AdjustWnd.InitView();
		}
		// Allow select deleted IC
		m_AdjustWnd.AllowSelectDeletedIC();

		SetWindowText(DBLE_FRAMENAME_EDITMODE);
		break;
	case ID_MENU_MAPPING:
		TRACE("[MENU][SubstEdit][Mapping]\n");

		// Check mapping method
		mapMethod = ((CBLE_Doc*)GetActiveDocument())->GetData()->GetMappMethod();
		if (mapMethod != 2) {												// if mapping method is not grade, return.
			//AfxMessageBox(BLE_FRAME_MAPPING_METHOD_MESS, MB_OK);
			theApp.CBTMessageBox(this->m_hWnd, MappingMethod[((CBLE_Doc*)GetActiveDocument())->GetData()->m_Init.m_Language], MB_OK, ((CBLE_Doc*)GetActiveDocument())->GetData()->m_Init.m_Language);
		} else {
			// Set title for window
			SetTitle(DBLE_DIALOGNAME_EDIT);
			
			// Set title for window in case doc is initializing
			SetWindowText(DBLE_FRAMENAME_EDITMODE);
			CloseWnd(); //THAIHV 20151123 (C)
			if (!IsWindow(m_MappingWnd.m_hWnd)) {
				// Set document
				m_MappingWnd.SetDocument((CBLE_Doc*)GetActiveDocument());

				// Create window
				m_MappingWnd.Create(IDD_MAPPING_DLG, pView);

				// Change language
				m_MappingWnd.ChangeLanguage();
			} else {
				// Initialize view
				m_MappingWnd.InitView();
			}
			//SetWindowText(DBLE_FRAMENAME_EDITMODE);
		}
		break;
	case ID_MENU_SUBINFO_L:
		theApp.p_Logger->m_Mode = "SubInfo"; // log for subinfo

		TRACE("[MENU][SubstEdit][SubstInfoL]\n");
		// Set title for window
		SetTitle(DBLE_DIALOGNAME_SUBINFO);

		// Set title for window in case doc is initializing
		SetWindowText(DBLE_FRAMENAME_SUBINFOMODE);

		// Check to see if subinfo is created but it's initializing doc
		if (!IsWindow(m_SubInfoLWnd.m_hWnd)) {
			if (m_SubInfoLWnd.GetDocument() != NULL) {
				break;
			}
			m_SubInfoLWnd.SetDocument((CBLE_Doc*)GetActiveDocument());
			// Check to see if SubstLocateEdit is start already but it's initializing doc
			if (!IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoLWnd.GetDocument()->SetMode(DBLE_SUBINFO_MODE);
				m_SubInfoLWnd.GetDocument()->InitDoc();
				//int width = GetSystemMetrics(SM_CXFULLSCREEN);
				//int height = GetSystemMetrics(SM_CYFULLSCREEN);
				//SetWindowPos(&CWnd::wndTop, 0, height - DBLE_MAINWND_SIZEY_SUBINFO, DBLE_MAINWND_SIZEX_SUBINFO * 2 , DBLE_MAINWND_SIZEY_SUBINFO, SWP_SHOWWINDOW);	// MainWindow��size�w��
			}
			m_SubInfoLWnd.SetMode(DBLE_SUBINFO_TYPE_L);
			m_SubInfoLWnd.Create(IDD_SUBINFO_DLG, pView);
		} else {
			m_SubInfoLWnd.InitView();
		}
		//SetWindowText(DBLE_FRAMENAME_SUBINFOMODE);
		break;
	case ID_MENU_SUBINFO_R:
		theApp.p_Logger->m_Mode = "SubInfo";

		TRACE("[MENU][SubstEdit][SubstInfoR]\n");
		// Set title for window
		SetTitle(DBLE_DIALOGNAME_SUBINFO);

		// Set title for window in case doc is initializing
		SetWindowText(DBLE_FRAMENAME_SUBINFOMODE);

		// Check to see if subinfo is created but it's initializing doc
		if (!IsWindow(m_SubInfoRWnd.m_hWnd)) {
			if (m_SubInfoRWnd.GetDocument() != NULL) {
				break;
			}
			m_SubInfoRWnd.SetDocument((CBLE_Doc*)GetActiveDocument());
			if (!IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoRWnd.GetDocument()->SetMode(DBLE_SUBINFO_MODE);
				m_SubInfoRWnd.GetDocument()->InitDoc();
				//int width = GetSystemMetrics(SM_CXFULLSCREEN);
				//int height = GetSystemMetrics(SM_CYFULLSCREEN);			// #MH130910 - Fix error of compiling. Please confirm
				//SetWindowPos(&CWnd::wndTop, 0, height - DBLE_MAINWND_SIZEY_SUBINFO, DBLE_MAINWND_SIZEX_SUBINFO * 2 , DBLE_MAINWND_SIZEY_SUBINFO, SWP_SHOWWINDOW);	// MainWindow��size�w��
			}
			m_SubInfoRWnd.SetMode(DBLE_SUBINFO_TYPE_R);
			m_SubInfoRWnd.Create(IDD_SUBINFO_DLG, pView);
			
		} else {
			m_SubInfoRWnd.InitView();
		}
		//SetWindowText(DBLE_FRAMENAME_SUBINFOMODE);
		//GetModuleFileName (NULL, buf, BUFSIZ - 1);	
		//filePath = buf;
		//ShellExecute(GetSafeHwnd(), "open", filePath, NULL, NULL, 1);
		break;
	case ID_MENU_PASSWORD:
		TRACE("[MENU][SubstEdit][Password]\n");
		if(!IsWindow(m_PassWordWnd.m_hWnd)){
			m_PassWordWnd.SetDocument((CBLE_Doc*)GetActiveDocument());
			m_PassWordWnd.Create(IDD_PASSWORD_DLG, pView);

			// Change language
			m_PassWordWnd.ChangeLanguage();
		}else{
			m_PassWordWnd.InitView();
		}
		break;
	case ID_MENU_CHECKREFLECT:
		if(!IsWindow(m_OptCheckReflect.m_hWnd)){
			m_OptCheckReflect.SetDocument((CBLE_Doc*)GetActiveDocument());
			m_OptCheckReflect.Create(IDD_OPTION_CHECKREFLECT, pView);
		}else{
			m_OptCheckReflect.InitView();
		}
		break;
	default:
		break;
	}
	// Change menu language
	ChangeMenuLanguage();
}

void CBLE_FrameWnd::UpdateDataFromFile()
{
	bool update = false;
	if (IsWindow(m_LocateEditWnd.m_hWnd)) {
		m_LocateEditWnd.GetCommdWnd()->SetDocument((CBLE_Doc*)GetActiveDocument());
		m_LocateEditWnd.GetCommdWnd()->UpdateView();
		m_LocateEditWnd.GetLayoutWnd()->Invalidate();
		m_LocateEditWnd.OnUpdateRegNo(0,0);
		update |= m_LocateEditWnd.IsWindowVisible() ? true : false;
	} 
	if (IsWindow(m_AdjustWnd.m_hWnd)) {
		m_AdjustWnd.GetCommdWnd()->SetDocument((CBLE_Doc*)GetActiveDocument());
		m_AdjustWnd.GetCommdWnd()->UpdateView();
		m_AdjustWnd.GetLayoutWnd()->Invalidate();
		m_AdjustWnd.OnUpdateRegNo();
		update |= m_AdjustWnd.IsWindowVisible() ? true : false;
	}
	if (IsWindow(m_MappingWnd.m_hWnd)) {
		// Check mapping window is visible or not
		if (m_MappingWnd.IsWindowVisible()) {
			// Check mapping method
			int mapMethod = ((CBLE_Doc*)GetActiveDocument())->GetData()->GetMappMethod();
			if (mapMethod != 2) {												// if mapping method is not grade, return.
				//AfxMessageBox(BLE_FRAME_MAPPING_METHOD_MESS, MB_OK);
				theApp.CBTMessageBox(this->m_hWnd, MappingMethod[((CBLE_Doc*)GetActiveDocument())->GetData()->m_Init.m_Language], MB_OK, ((CBLE_Doc*)GetActiveDocument())->GetData()->m_Init.m_Language);
				m_MappingWnd.OnCancel();
				update |= false;
			} else {
				m_MappingWnd.UpdateView();
			}
		}
		update |= (m_MappingWnd.IsWindowVisible()) ? true : false;
	}
	if (!update) {
		if (IsWindow(m_LocateEditWnd.m_hWnd)) {
			m_LocateEditWnd.ShowWindow(SW_SHOW);
		}
	}
}

void CBLE_FrameWnd::OnUpdateSubWndCmd(CCmdUI *pCmdUI)
{
	TRACE("[MENU]\n");
	BOOL Enable = ((CBLE_Doc*)GetActiveDocument())->m_User != DBLE_USER_LEVEL1;
	switch(pCmdUI->m_nID){
	case ID_MENU_PASSWORD:
		Enable = TRUE;
	case ID_MENU_MAPPING:
	case ID_MENU_LOCATEEDIT:
	case ID_MENU_ADJUST:
		if((IsWindow(m_LocateEditWnd.m_hWnd) && m_LocateEditWnd.IsWindowVisible() && (pCmdUI->m_nID == ID_MENU_LOCATEEDIT))
				|| (IsWindow(m_AdjustWnd.m_hWnd) && m_AdjustWnd.IsWindowVisible() && (pCmdUI->m_nID == ID_MENU_ADJUST))
				|| (IsWindow(m_MappingWnd.m_hWnd) && m_MappingWnd.IsWindowVisible() && (pCmdUI->m_nID == ID_MENU_MAPPING))
				|| (IsWindow(m_PassWordWnd.m_hWnd) && m_PassWordWnd.IsWindowVisible() && (pCmdUI->m_nID == ID_MENU_PASSWORD))
				|| (IsWindow(m_SubInfoLWnd.m_hWnd) /*&& m_SubInfoLWnd.IsWindowVisible()*/)
				|| (IsWindow(m_SubInfoRWnd.m_hWnd) /*&& m_SubInfoRWnd.IsWindowVisible()*/)){
			Enable = FALSE;  
		}
		pCmdUI->Enable(Enable);
		break;
	case ID_MENU_SUBINFO_L:
		if((IsWindow(m_SubInfoLWnd.m_hWnd) && m_SubInfoLWnd.IsWindowVisible())
				|| (IsWindow(m_LocateEditWnd.m_hWnd))
				|| (IsWindow(m_AdjustWnd.m_hWnd))
				|| (IsWindow(m_MappingWnd.m_hWnd))
				|| (IsWindow(m_PassWordWnd.m_hWnd))){
			Enable = FALSE;
		}
		pCmdUI->Enable(Enable);
		break;
	case ID_MENU_SUBINFO_R:
		if((IsWindow(m_SubInfoRWnd.m_hWnd) && m_SubInfoRWnd.IsWindowVisible())
				|| (IsWindow(m_LocateEditWnd.m_hWnd))
				|| (IsWindow(m_AdjustWnd.m_hWnd))
				|| (IsWindow(m_MappingWnd.m_hWnd))
				|| (IsWindow(m_PassWordWnd.m_hWnd))){
			Enable = FALSE;
		}
		pCmdUI->Enable(Enable);
		break;
	case ID_MENU_CHECKREFLECT:
		Enable = ((CBLE_Doc*)GetActiveDocument())->m_User == DBLE_USER_LEVEL3;
	case ID_FILE_CURRENTOPEN:
		//Enable = true; // Fix bugs: password level 2 can open option for check and reflect
		if((IsWindow(m_SubInfoRWnd.m_hWnd)/* && m_SubInfoRWnd.IsWindowVisible()*/)
				|| (IsWindow(m_SubInfoLWnd.m_hWnd)/* && m_SubInfoLWnd.IsWindowVisible()*/)){
// #DUCDT131114: Enable current open in SubInfo mode if initialize fail
			if (!((CBLE_Doc*)GetActiveDocument())->IsSavingData()) {
				Enable = FALSE;
			}
		}
		pCmdUI->Enable(Enable);
		break;
	case ID_MENU_ARRANGE:
		if ((IsWindow(m_SubInfoLWnd.m_hWnd) && m_SubInfoLWnd.IsWindowVisible())
			&& (IsWindow(m_SubInfoRWnd.m_hWnd) && m_SubInfoRWnd.IsWindowVisible())) {
			Enable = TRUE;
		} else {
			Enable = FALSE;
		}
		pCmdUI->Enable(Enable);
		break;
	default:
		break;
	}
}

void CBLE_FrameWnd::OnUpdateFileCmd(CCmdUI *pCmdUI)
{
	BOOL Enable = ((CBLE_Doc*)GetActiveDocument())->m_User != DBLE_USER_LEVEL1;
	switch(pCmdUI->m_nID) {	
	case ID_FILE_OPEN:
		Enable = true;
	case ID_FILE_SAVE:
		if((IsWindow(m_SubInfoRWnd.m_hWnd)/* && m_SubInfoRWnd.IsWindowVisible()*/)
				|| (IsWindow(m_SubInfoLWnd.m_hWnd)/* && m_SubInfoLWnd.IsWindowVisible()*/)
				|| (((CBLE_Doc*)GetActiveDocument())->IsSavingData())){
			Enable = FALSE;
		}
		pCmdUI->Enable(Enable);
		break;
	default:
		break;
	}
}

void CBLE_FrameWnd::OnStartInstance(WPARAM wParam, LPARAM lParam)
{
	if(IsWindow(m_LocateEditWnd.m_hWnd)){
		m_LocateEditWnd.InitView();
		return;
	}
	if (wParam == ID_MENU_SUBINFO) { //start both L and R
		OnStartSubWnd(ID_MENU_SUBINFO_R);
		OnStartSubWnd(ID_MENU_SUBINFO_L);
		return;
	}
	OnStartSubWnd(wParam);
}


BOOL CBLE_FrameWnd::DestroyWindow()
{
	if (IsWindow(m_LocateEditWnd) || IsWindow(m_AdjustWnd) || IsWindow(m_MappingWnd)) {
		CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_EDIT);
	} else {
		CBLE_Util::SaveWindowPlace(this, DBLE_DIALOGNAME_APPNAME, DBLE_DIALOGNAME_SUBINFO);
	}

	// Destroy restore buffer
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->~CBLE_CareTaker();
	delete pCareTaker;

	//::SetEvent(m_StopThread);
	return CFrameWnd::DestroyWindow();
}

//##DuyND 
///////////////////////////////////////////////////
// Function to handle message send from TFC
//
LRESULT CBLE_FrameWnd::OnSubInfoCtrl(WPARAM wParam, LPARAM lParam)
{
	CBLE_Doc *doc = (CBLE_Doc*)GetActiveDocument();
	switch(wParam) {
		case BOND_NDONE_L:
			// Check Left side subinfo window
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(DBLE_BOND_NOTDONE, lParam);
			}
			break;
		case BOND_NDONE_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(DBLE_BOND_NOTDONE, lParam);
			}
			break;
		case BOND_FAIL_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(DBLE_BOND_FAIL, lParam);
			}
			break;
		case BOND_FAIL_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(DBLE_BOND_FAIL, lParam);
			}
			break;
		case BOND_DONE_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(DBLE_BOND_DONE, lParam);
			}
			break;
		case BOND_DONE_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(DBLE_BOND_DONE, lParam);
			}
			break;
		case BOND_STACK_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(DBLE_BOND_STACK, lParam);
			}
			break;
		case BOND_STACK_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(DBLE_BOND_STACK, lParam);
			}
			break;
		case BOND_SKIP_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(DBLE_BOND_NONEED, lParam);
			}
			break;
		case BOND_SKIP_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(DBLE_BOND_NONEED, lParam);
			}
			break;
		case DET_UNKN_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(DBLE_DETECT_UNKNOWN, lParam);
			}
			break;
		case DET_UNKN_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(DBLE_DETECT_UNKNOWN, lParam);
			}
			break;
		case DET_BAD_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(DBLE_DETECT_BAD, lParam);
			}
			break;
		case DET_BAD_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(DBLE_DETECT_BAD, lParam);
			}
			break;
		case DET_GOOD_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(DBLE_DETECT_GOOD, lParam);
			}
			break;
		case DET_GOOD_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(DBLE_DETECT_GOOD, lParam);
			}
			break;

		case BLE_OK_L:
		case BLE_NG_L:
		case NG_LOAD_L:
		case OK_LOAD_L:
		case NG_LOADMAP_L:
		case OK_LOADMAP_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(wParam, lParam);
			}
			break;
		case BLE_OK_R:
		case BLE_NG_R:
		case NG_LOAD_R:
		case OK_LOAD_R:
		case NG_LOADMAP_R:
		case OK_LOADMAP_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(wParam, lParam);
			} 
			break;
		case BLE_SAVE_FILE_OK:
		case BLE_SAVE_FILE_NG:
		case BLE_SUBINFO_INIT:
		case BLE_SUBINFO_CUROPEN:
		case BLE_INIT_SUBINFO_OK:
		case BLE_INIT_SUBINFO_NG:
		case BLE_CUROPEN_SUBINFO_OK:
		case BLE_CUROPEN_SUBINFO_NG:
			doc->OnProcessAns(wParam, lParam);
			break;
		// Reset status in SubInfo left
		case BLE_RESET_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(wParam, lParam);
			}
			break;
		// Reset status in SubInfo right
		case BLE_RESET_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(wParam, lParam);
			}
			break;

		// Move position in SubInfo left
		case BLE_MOVED_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetStatus(wParam, lParam);
			}
			break;
		case BLE_MOVED_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetStatus(wParam, lParam);
			}
			break;
		// Frame direction
		case BLE_DIR_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.SetFrameDirection(lParam);
			}
			Invalidate();
			break;
		case BLE_DIR_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.SetFrameDirection(lParam);
			}
			Invalidate();
			break;
		// Load status when startup
		case STARTUP_LOAD_L:
			if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.LoadStatus(wParam, lParam);
			}
			break;
		case STARTUP_LOAD_R:
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.LoadStatus(wParam, lParam);
			}
			break;
		// Reload data
		case BLE_FILE:
			doc->InitDoc();
			/*if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
				m_SubInfoLWnd.OnUpdateView(0, 0);
			}
			if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
				m_SubInfoRWnd.OnUpdateView(0, 0);
			}*/
			if (lParam == eLeftMode) {
				OnStartSubWnd(ID_MENU_SUBINFO_L);
			} else if (lParam == eRightMode) {
				OnStartSubWnd(ID_MENU_SUBINFO_R);
			} else if (lParam == eLRMode) {
				OnStartSubWnd(ID_MENU_SUBINFO_L);
				OnStartSubWnd(ID_MENU_SUBINFO_R);
			} else {
				// Nothing
			}
			break;
		default: 
			break;
		
	}
	if (wParam >= STACK_COUNT_L && wParam < STACK_COUNT_R) {
		if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
			m_SubInfoLWnd.SetStatus(wParam, lParam);
		}
	}
	if (wParam >= STACK_COUNT_R && wParam < STACK_COUNT_R + 30) {
		if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
			m_SubInfoRWnd.SetStatus(wParam - STACK_COUNT_R, lParam);
		}
	}
	return 0;
}

/**
* Color change, re-draw layout
*/
void CBLE_FrameWnd::OnColorChange(WPARAM wParam, LPARAM lParam)
{
	if (IsWindow(m_SubInfoLWnd)) {
		m_SubInfoLWnd.OnUpdateView(wParam, lParam);
	}
	if (IsWindow(m_SubInfoRWnd)) {
		m_SubInfoRWnd.OnUpdateView(wParam, lParam);
	}
}

bool CBLE_FrameWnd::SaveDataProgressBar()
{
	CBLE_ProgressBar progressDlg;
	progressDlg.SetDocument((CBLE_Doc*)GetActiveDocument());
	progressDlg.m_Type = DBLE_PROGRESSBAR_SAVE_DATA; 
	progressDlg.m_bDisplay = ((CBLE_Doc*)GetActiveDocument())->GetData()->GetSubstrate()->PerformanceChecking(true);
	progressDlg.DoModal();
	return progressDlg.m_bResult;
}

bool CBLE_FrameWnd::OpenFileProgressBar(CString folderPath)
{
	CBLE_ProgressBar progressDlg;
	progressDlg.m_FolderPath = folderPath;
	progressDlg.SetDocument((CBLE_Doc*)GetActiveDocument());
	progressDlg.m_Type = DBLE_PROGRESSBAR_OPEN_DATA;
	//progressDlg.m_bDisplay = ((CBLE_Doc*)GetActiveDocument())->GetData()->GetSubstrate()->PerformanceChecking();
	progressDlg.DoModal();

	return progressDlg.m_bResult;
}

/*
* Change language of menu
*/
void CBLE_FrameWnd::ChangeMenuLanguage()
{
	CBLE_Doc *doc = (CBLE_Doc*)GetActiveDocument();
	if (doc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	CWnd* pMain = AfxGetMainWnd();
	CMenu* pMenu = pMain->GetMenu();
	//int id = pMenu->GetMenuItemID(0);
	for (int i = 0; i < DBLE_LANGUAGE_MENU; i++) {
		UINT menuID = pMenu->GetMenuItemID(i); // Set ID for menu items
		pMenu->ModifyMenu(i, MF_BYPOSITION | MF_STRING, menuID, MainMenuLanguage[i]);
		CMenu* pSubMenu = pMenu->GetSubMenu(i);
		int subMenuSize = 0;
		if (i == 0) {
			subMenuSize = ARRAY_LENGTH(FileMenuLanguage);
			for (int id = 0; id < subMenuSize; id ++) {
				if (id == 3) {
					continue; // skip separator item
				}
				UINT subMenuID = pSubMenu->GetMenuItemID(id); // Set ID for menu items
				// Change menu text
				pSubMenu->ModifyMenu(id, MF_BYPOSITION | MF_STRING, subMenuID, FileMenuLanguage[id]); 
			}
		}
		if (i == 1) {
			subMenuSize = ARRAY_LENGTH(EditMenuLanguage);
			for (int id = 0; id < subMenuSize; id ++) {
				if (id == 2) {
					continue; // skip separator item
				}
				UINT subMenuID = pSubMenu->GetMenuItemID(id); // Set ID for menu items
				// Change menu text
				pSubMenu->ModifyMenu(id, MF_BYPOSITION | MF_STRING, subMenuID, EditMenuLanguage[id]); 
			}
		}
		if (i == 2) {
			subMenuSize = ARRAY_LENGTH(InfoMenuLanguage);
			for (int id = 0; id < subMenuSize; id ++) {
				UINT subMenuID = pSubMenu->GetMenuItemID(id); // Set ID for menu items
				// Change menu text
				pSubMenu->ModifyMenu(id, MF_BYPOSITION | MF_STRING, subMenuID, InfoMenuLanguage[id]); 
			}
		}
		if (i == 3) {
			subMenuSize = ARRAY_LENGTH(PassMenuLanguage);
			for (int id = 0; id < subMenuSize; id ++) {
				UINT subMenuID = pSubMenu->GetMenuItemID(id); // Set ID for menu items
				// Change menu text
				pSubMenu->ModifyMenu(id, MF_BYPOSITION | MF_STRING, subMenuID, PassMenuLanguage[id]); 
			}
		}
		if (i == 4) {
			subMenuSize = ARRAY_LENGTH(WindowMenuLanguage);
			for (int id = 0; id < subMenuSize; id ++) {
				UINT subMenuID = pSubMenu->GetMenuItemID(id); // Set ID for menu items
				// Change menu text
				pSubMenu->ModifyMenu(id, MF_BYPOSITION | MF_STRING, subMenuID, WindowMenuLanguage[id]); 
			}
		}

		if (i == 5) {
			subMenuSize = ARRAY_LENGTH(HelpMenuLanguage);
			for (int id = 0; id < subMenuSize; id ++) {
				UINT subMenuID = pSubMenu->GetMenuItemID(id); // Set ID for menu items
				// Change menu text
				pSubMenu->ModifyMenu(id, MF_BYPOSITION | MF_STRING, subMenuID, HelpMenuLanguage[id]); 
			}
		}
	}
	// Update menu after change language
	CFrameWnd::OnUpdateFrameMenu(pMenu->m_hMenu);
}

void CBLE_FrameWnd::UpdateSetting()
{
	if (IsWindow(m_SubInfoLWnd)) {
		m_SubInfoLWnd.InitView();
	}
	if (IsWindow(m_SubInfoRWnd)) {
		m_SubInfoRWnd.InitView();
	}
}


void CBLE_FrameWnd::OnRestoreState()
{
	CBLE_Doc *pDoc = (CBLE_Doc*)GetActiveDocument();
	// Create instance of CareTaker
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	// Check buffer empty or not
	if (!pCareTaker->Restoreable()) {
//		delete pCareTaker;
		return;
	}
	int kind = pCareTaker->GetLastKind();
	// Refresh layout
	
	if (IsWindow(m_LocateEditWnd.m_hWnd) && m_LocateEditWnd.IsWindowVisible()) {
		// Restore on Common setting
		if (kind == IDD_COM_SETTING_DLG) {
			m_LocateEditWnd.GetCommdWnd()->RestoreState();
		} else if (kind == IDD_LOCATE_EDIT_DLG){
			if (pDoc != NULL) {

				// Reset choosen RegNo to 0
				m_LocateEditWnd.SetRegNo(0);

				// Restore
				pDoc->GetData()->RestoreState();

				// Update layout position
				m_LocateEditWnd.OnZoom();
				
				// Update info window
				m_LocateEditWnd.GetInfoWnd()->UpdateGridData();
			}
		} else {
			// Nothing
		}
		
	} else if (IsWindow(m_AdjustWnd.m_hWnd) && m_AdjustWnd.IsWindowVisible()) {
		// Restore on Common setting
		if (kind == IDD_COM_SETTING_DLG) {
			m_AdjustWnd.GetCommdWnd()->RestoreState();
		} else if (kind == IDD_ADJUST_DLG) {
			if (pDoc != NULL) {
				// Reset choosen RegNo to 0
				m_AdjustWnd.SetRegNo(0);

				// Restore
				pDoc->GetData()->RestoreState();

				// Update layout position
				m_AdjustWnd.OnZoom();

				// Update info window
				m_AdjustWnd.GetInfoWnd()->UpdateGridData();
			}
		} else {
			// Nothing
		}
	} else if (IsWindow(m_MappingWnd.m_hWnd) && m_MappingWnd.IsWindowVisible()) {
		m_MappingWnd.RestoreState();
		//m_MappingWnd.UpdateView();
	}
}

void CBLE_FrameWnd::OnInitComplete(WPARAM wParam, LPARAM lParam)
{
	CBLE_Doc *doc = (CBLE_Doc*)GetActiveDocument();
	doc->InitDocData();
	ChangeMenuLanguage();
	if (IsWindow(m_LocateEditWnd.m_hWnd)) {
		m_LocateEditWnd.GetCommdWnd()->SetDocument((CBLE_Doc*)GetActiveDocument());
		// Update GridCtrl
		m_LocateEditWnd.GetCommdWnd()->UpdateCommonSetting();
		m_LocateEditWnd.GetLayoutWnd()->Invalidate();
		m_LocateEditWnd.OnUpdateRegNo(0,0);
		m_LocateEditWnd.UpdateComboBox();
		m_LocateEditWnd.ChangeLanguage();
	} 
	if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
		// Check mapping window is visible or not
		if (m_SubInfoLWnd.IsWindowVisible()) {
			m_SubInfoLWnd.Invalidate();
			m_SubInfoLWnd.UpdateSubInfo();
		}
	}
	if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
		// Check mapping window is visible or not
		if (m_SubInfoRWnd.IsWindowVisible()) {
			m_SubInfoRWnd.Invalidate();
			m_SubInfoRWnd.UpdateSubInfo();
		}
	}
}

void CBLE_FrameWnd::OnCurrentOpenComplete(WPARAM wParam, LPARAM lParam)
{
	CBLE_Doc *doc = (CBLE_Doc*)GetActiveDocument();
	doc->CurrentOpenData();
	if (IsWindow(m_SubInfoLWnd.m_hWnd)) {
		// Check mapping window is visible or not
		if (m_SubInfoLWnd.IsWindowVisible()) {
			m_SubInfoLWnd.Invalidate();
			m_SubInfoLWnd.UpdateSubInfo();
		}
	}
	if (IsWindow(m_SubInfoRWnd.m_hWnd)) {
		// Check mapping window is visible or not
		if (m_SubInfoRWnd.IsWindowVisible()) {
			m_SubInfoRWnd.Invalidate();
			m_SubInfoRWnd.UpdateSubInfo();
		}
	}
}

LRESULT CBLE_FrameWnd::OnUpdateOption(WPARAM wParam, LPARAM lParam)
{
	if (IsWindow(m_LocateEditWnd.m_hWnd) && m_LocateEditWnd.IsWindowVisible()) {
		m_LocateEditWnd.Invalidate();
	}
	if (IsWindow(m_AdjustWnd.m_hWnd) && m_AdjustWnd.IsWindowVisible()) {
		m_AdjustWnd.Invalidate();
	}
	return 0;
}

/**
* Catch Ctrl + Z to restore
*/
BOOL CBLE_FrameWnd::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN /*&& pMsg->wParam == VK_CONTROL*/){
		if ((GetKeyState(VK_DELETE) & 0x8000) ) {
			if (IsWindow(m_LocateEditWnd) && m_LocateEditWnd.IsWindowVisible()) {
				m_LocateEditWnd.DeleteSelectedIC();
			}
		}
    }	
    return CFrameWnd::PreTranslateMessage(pMsg);
}
///////////////////////////////////////////////////////////
//  CBLE_FullKeyWnd.cpp
//  Implementation of the Class CBLE_FullKeyWnd
//  Created on:      16-Thg7-2013 1:57:46 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_FullKeyWnd.h"
#include "CBLE_Doc.h"

/////////////////////////////////////////////////////////////////////////////
// CBLE_FullKeyWnd dialog


CBLE_FullKeyWnd::CBLE_FullKeyWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_FullKeyWnd::IDD, pParent)
{
	m_pRevWnd = NULL;
}

CBLE_FullKeyWnd::~CBLE_FullKeyWnd()
{

}


void CBLE_FullKeyWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBLE_FullKeyWnd, CDialog)
	ON_COMMAND_RANGE(IDC_NKEY_0, IDC_FKEY_CLR, OnKey)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_FullKeyWnd message handlers

void CBLE_FullKeyWnd::OnKey(UINT nID)
{
	if(m_pRevWnd == NULL) return;
	// Post message to the parent window
	::PostMessage(m_pRevWnd->m_hWnd, WM_UPDATE_FULLKEY, (WPARAM)nID, 0);
}

BOOL CBLE_FullKeyWnd::Create(CWnd* pRevWnd, UINT nIDTemplate, CWnd* pParentWnd)
{
	m_pRevWnd = pRevWnd;
	return CDialog::Create(nIDTemplate, pParentWnd);
}

void CBLE_FullKeyWnd::OnCancel()
{
	// do nothing
}

void CBLE_FullKeyWnd::OnOK()
{
	// do nothing
}
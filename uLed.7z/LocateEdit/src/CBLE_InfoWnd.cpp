// CBLE_InfoWnd.cpp : implementation file
//

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_InfoWnd.h"
#include "CBLE_LocateEditWnd.h"
#include "CBLE_FrameWnd.h"

// Defined for column width of grid control
static long m_arrInfoColWidth[] = {
//	RegNo		Index			Offset			Pos
//	45, 15, 5,	30, 15, 20, 5,	35, 15, 45, 5,	40, 15, 55
	1, 1, 5,	30, 15, 40, 5,	35, 15, 65, 5,	40, 15, 65
};

#define DBLE_INFO_CELL_HEIGTH				17
#define DBLE_EDITWND_MINSCALE				1.0

//Define warning message
/*#define WARNING_MESSAGE_OUTOFRANGE			_T("Your input is out of limit range! \n Do you want to re-input?")
#define WARNING_MESSAGE_CANTSELECT			_T("Cannot find IC! Check your input RegNo and Index")
#define WARNING_MESSAGE_INDEXXMISSING		_T("Please input index X value!")
#define WARNING_MESSAGE_INDEXYMISSING		_T("Please input index Y value!")
#define WARNING_MESSAGE_REGNOMISSING		_T("Please input RegNo value!")
#define WARNING_MESSAGE_IC_DELETED			_T("Can't select deleted IC in hide invalid IC mode!\nPlease change to show invalid IC mode")
*/
/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString OutOfRangeInfo[] =	{
								_T("���͒l�������͈͊O�ł��B\n �ē��͂��܂����H"),
								_T("Your input is out of limit range! \n Do you want to re-input?"),
							};

CString ICCantSelect[] =	{
								_T("����IC��������܂���ł����BRegNo��IC�C���f�b�N�X���`�F�b�N���Ă��������I"),
								_T("Cannot find IC! Check your input RegNo and Index"),
							};

CString IndexXMissing[] =	{
								_T("�C���f�b�N�XX����͂��Ă��������I"),
								_T("Please input index X value!"),
							};

CString IndexYMissing[] =	{
								_T("�C���f�b�N�XY����͂��Ă��������I"),
								_T("Please input index Y value!"),
							};

CString RegNoMissing[] =	{
								_T("RegNo����͂��Ă��������I"),
								_T("Please input RegNo value!"),
							};

CString ICDeleted[] =		{
								_T("�L���\�����[�h�ō폜����IC��I���ł��܂���B�����\�����[�h�ɕύX���Ă��������I"),
								_T("Can't select deleted IC in hide invalid IC mode!\nPlease change to show invalid IC mode"),
							};
CString TFCNotRun[] =			{							
								_T("TFC�����s���Ă��܂���B"),
								_T("TFC is not running now"),
							};
/////////////////////////////////////////////////////////////////////////////
// CBLE_InfoWnd dialog


CBLE_InfoWnd::CBLE_InfoWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_InfoWnd::IDD, pParent)
{
	m_pDoc = NULL;
	m_pGridCtrl = NULL;
	m_DisplayMode = DBLE_MODE_LOCATE_EDIT_HIDE_INVALID;
	m_SubInfoDir = 0;
}

CBLE_InfoWnd::~CBLE_InfoWnd()
{

}


void CBLE_InfoWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CBLE_InfoWnd, CDialog)
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateGrid)
	ON_BN_CLICKED(IDC_INFO_INDEX_JUMP, OnIndexJump)
	ON_BN_CLICKED(IDC_INFO_INDEX_SENDTFC, OnIndexSend)
	ON_BN_CLICKED(IDC_INFO_REALTIME_DISP, OnDisplayRealTime)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_InfoWnd message handlers

void CBLE_InfoWnd::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

BOOL CBLE_InfoWnd::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Create grid control
	CRect rect;
	GetDlgItem(IDC_INFO_GRID)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_pGridCtrl = new CBLE_GridCtrl(2, 14);
	//m_pGridCtrl->SetDocument(m_pDoc);
	m_pGridCtrl->Create(rect, this, m_pDoc);
	if ( m_SubInfoDir == 0) {
		GetDlgItem(IDC_INFO_INDEX_SENDTFC)->ShowWindow(SW_HIDE);
	}
	// Get data
	InitGridCtrl();
	UpdateGridData();
	return TRUE;
}


void CBLE_InfoWnd::InitGridCtrl()
{
	// Set language
	m_pGridCtrl->SetLanguage(m_pDoc->GetData()->m_Init.m_Language);

	// Set width for all cols
	for(UINT idx = 0; idx < ARRAY_LENGTH(m_arrInfoColWidth); idx ++){
		m_pGridCtrl->SetColWidth(idx, m_arrInfoColWidth[idx]);
	}

	// Set height for all row
	for(int row = 0; row < m_pGridCtrl->GetRows(); row ++){
		m_pGridCtrl->SetRowHeight(row, DBLE_INFO_CELL_HEIGTH);
	}

	// Set merge for some rows and cols
	m_pGridCtrl->MergeCell(0, 3, 1, 3);
	m_pGridCtrl->MergeCell(0, 7, 1, 7);
	m_pGridCtrl->MergeCell(0, 11, 1, 11);
	

	//#THAIHV170815 Set invisible for IC Type, RegNo
	m_pGridCtrl->SetColInvisible(0);
	m_pGridCtrl->SetColInvisible(1);
	// Set invisible for some cols
	m_pGridCtrl->SetColInvisible(2);
	m_pGridCtrl->SetColInvisible(6);
	m_pGridCtrl->SetColInvisible(10);
	
	// Set type for some cols
	m_pGridCtrl->SetColType(1, DBLE_CELL_INT);			// RegNo
	m_pGridCtrl->SetColType(5, DBLE_CELL_INT);			// Index X
	m_pGridCtrl->SetColType(6, DBLE_CELL_INT);			// Index Y

	// Set header for all collumn except two cells of IC index and RegNo, IC type
	m_pGridCtrl->SetRowHeader(0);
	m_pGridCtrl->SetRowHeader(1);
	m_pGridCtrl->GetCell(0, 5)->SetHeader(false);
	m_pGridCtrl->GetCell(0, 1)->SetHeader(false);
	m_pGridCtrl->GetCell(1, 5)->SetHeader(false);
	/*m_pGridCtrl->SetColHeader(0);
	m_pGridCtrl->SetColHeader(3);
	m_pGridCtrl->SetColHeader(4);
	m_pGridCtrl->SetColHeader(7);
	m_pGridCtrl->SetColHeader(8);
	m_pGridCtrl->SetColHeader(11);
	m_pGridCtrl->SetColHeader(12);*/

	// Set text
	m_pGridCtrl->SetCellText(0, 0, _T("Reg No"));
	m_pGridCtrl->SetCellText(1, 0, _T("Ic Type"));

	m_pGridCtrl->SetCellText(0, 3, _T("Index"));
	m_pGridCtrl->SetCellText(0, 4, _T("X"));
	m_pGridCtrl->SetCellText(1, 4, _T("Y"));

	m_pGridCtrl->SetCellText(0, 7, _T("Offset [mm]"));
	m_pGridCtrl->SetCellText(0, 8, _T("X"));
	m_pGridCtrl->SetCellText(1, 8, _T("Y"));

	m_pGridCtrl->SetCellText(0, 11, _T("Position [mm]"));
	m_pGridCtrl->SetCellText(0, 12, _T("X"));
	m_pGridCtrl->SetCellText(1, 12, _T("Y"));
}

void CBLE_InfoWnd::UpdateGridData()
{
	// Update check box status
	CButton* checkBox = (CButton*) GetDlgItem(IDC_INFO_REALTIME_DISP);
	m_pDoc->GetData()->GetSubstrate()->m_bDisplayRealTime == true ? checkBox->SetCheck(BST_CHECKED) : checkBox->SetCheck(BST_UNCHECKED);

	// Get the selected IC
	vector<CBLE_IC*> vIC;
	if (m_SubInfoDir == 0) {
		vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
	} else if (m_SubInfoDir == DBLE_SUBINFO_TYPE_L) {
		vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICL;
	} else if (m_SubInfoDir == DBLE_SUBINFO_TYPE_R) {
		vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICR;
	}
	
	if(vIC.size() != 1){
		// RegNo information
		m_pGridCtrl->SetCellText(0, 1, _T(""));
		// IC type information
		m_pGridCtrl->SetCellText(1, 1, _T(""));
		// Index X information
		m_pGridCtrl->SetCellText(0, 5, _T(""));
		// Index Y information
		m_pGridCtrl->SetCellText(1, 5, _T(""));
		// Offset X information
		m_pGridCtrl->SetCellText(0, 9, _T(""));
		// Offset Y information
		m_pGridCtrl->SetCellText(1, 9, _T(""));
		// Position X information
		m_pGridCtrl->SetCellText(0, 13, _T(""));
		// Position Y information
		m_pGridCtrl->SetCellText(1, 13, _T(""));
	}else{
		CBLE_IC* pIC = vIC[0];
		CString strTmp;
		// RegNo information
		strTmp.Format(_T("%d"), pIC->m_pRegIC->m_RegNo);
		m_pGridCtrl->SetCellText(0, 1, strTmp);
		// IC type information
		strTmp.Format(_T("%d"), pIC->m_pRegIC->m_Type);
		m_pGridCtrl->SetCellText(1, 1, strTmp);
		// Index X information
		strTmp.Format(_T("%d"), pIC->m_indexX + 1);
		m_pGridCtrl->SetCellText(0, 5, strTmp);
		// Index Y information
		strTmp.Format(_T("%d"), pIC->m_indexY + 1);
		m_pGridCtrl->SetCellText(1, 5, strTmp);
		// Offset X information
		strTmp.Format(_T("%.4f"), pIC->m_OffsetX);
		m_pGridCtrl->SetCellText(0, 9, strTmp);
		// Offset Y information
		strTmp.Format(_T("%.4f"), pIC->m_OffsetY);
		m_pGridCtrl->SetCellText(1, 9, strTmp);
		// Position X information
		strTmp.Format(_T("%.4f"), pIC->GetPosX());
		m_pGridCtrl->SetCellText(0, 13, strTmp);
		// Position Y information
		strTmp.Format(_T("%.4f"), pIC->GetPosY());
		m_pGridCtrl->SetCellText(1, 13, strTmp);

		TRACE("[Edit]CBLE_ InfoWnd::Update GridData()Reg%d,X%d,Y%d\n",pIC->m_pRegIC->m_RegNo,pIC->m_indexX + 1,pIC->m_indexY + 1);
	}
}

// Display information of focus IC
void CBLE_InfoWnd::DisplayFocusIC()
{
	CBLE_IC* pIC = m_pDoc->GetData()->GetSubstrate()->m_pFocusIC;
	if (pIC == NULL) {
		// Get the selected IC
		vector<CBLE_IC*> vIC;
		if (m_SubInfoDir == 0) {
			vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelIC;
		} else if (m_SubInfoDir == DBLE_SUBINFO_TYPE_L) {
			vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICL;
		} else if (m_SubInfoDir == DBLE_SUBINFO_TYPE_R) {
			vIC = m_pDoc->GetData()->GetSubstrate()->m_vSelICR;
		}
		if(vIC.size() != 1){ 
			pIC = NULL;
		} else {
			pIC = vIC[0];
		}
	}
	CString strTmp;
	if (pIC == NULL) {
		// RegNo information
		m_pGridCtrl->SetCellText(0, 1, _T(""));
		// IC type information
		m_pGridCtrl->SetCellText(1, 1, _T(""));
		// Index X information
		m_pGridCtrl->SetCellText(0, 5, _T(""));
		// Index Y information
		m_pGridCtrl->SetCellText(1, 5, _T(""));
		// Offset X information
		m_pGridCtrl->SetCellText(0, 9, _T(""));
		// Offset Y information
		m_pGridCtrl->SetCellText(1, 9, _T(""));
		// Position X information
		m_pGridCtrl->SetCellText(0, 13, _T(""));
		// Position Y information
		m_pGridCtrl->SetCellText(1, 13, _T(""));

		return;
	}
	// RegNo information
	strTmp.Format(_T("%d"), pIC->m_pRegIC->m_RegNo);
	m_pGridCtrl->SetCellText(0, 1, strTmp);
	// IC type information
	strTmp.Format(_T("%d"), pIC->m_pRegIC->m_Type);
	m_pGridCtrl->SetCellText(1, 1, strTmp);
	// Index X information
	strTmp.Format(_T("%d"), pIC->m_indexX + 1);
	m_pGridCtrl->SetCellText(0, 5, strTmp);
	// Index Y information
	strTmp.Format(_T("%d"), pIC->m_indexY + 1);
	m_pGridCtrl->SetCellText(1, 5, strTmp);
	// Offset X information
	strTmp.Format(_T("%.4f"), pIC->m_OffsetX);
	m_pGridCtrl->SetCellText(0, 9, strTmp);
	// Offset Y information
	strTmp.Format(_T("%.4f"), pIC->m_OffsetY);
	m_pGridCtrl->SetCellText(1, 9, strTmp);
	// Position X information
	strTmp.Format(_T("%.4f"), pIC->GetPosX());
	m_pGridCtrl->SetCellText(0, 13, strTmp);
	// Position Y information
	strTmp.Format(_T("%.4f"), pIC->GetPosY());
	m_pGridCtrl->SetCellText(1, 13, strTmp);
}


void CBLE_InfoWnd::OnCancel()
{
	// do nothing
}

void CBLE_InfoWnd::OnOK()
{
	// do nothing
}

// Check display real-time
LRESULT CBLE_InfoWnd::OnDisplayRealTime()
{
	CButton *checkBox = (CButton*) GetDlgItem(IDC_INFO_REALTIME_DISP);
	if (checkBox->GetCheck() == BST_CHECKED) {
		m_pDoc->GetData()->GetSubstrate()->m_bDisplayRealTime = true;
	} else {
		m_pDoc->GetData()->GetSubstrate()->m_bDisplayRealTime = false;
	}

	//Update setting
	CBLE_FrameWnd* pFrame = (CBLE_FrameWnd*) (AfxGetApp()->m_pMainWnd);
	pFrame->UpdateSetting();
	
	return 0;
	
}

// Check input value
LRESULT CBLE_InfoWnd::OnUpdateGrid(WPARAM wParam, LPARAM lParam)
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	long row = m_pGridCtrl->GetRowSel();
	long col = m_pGridCtrl->GetColSel();
	if((row == -1) || (col == -1)) return 0;
	CString tmpText = m_pGridCtrl->GetCellText(row, col);
	int value = atoi(tmpText);
	if (col == 5) {
		if (value < 1 || value > 300) {
			//int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
			int nType = theApp.CBTMessageBox(this->m_hWnd, OutOfRangeInfo[language], MB_YESNO, language);
			// Write log file: missing value
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, OutOfRangeInfo[language], "", "");

			if (nType == IDYES) {								// Re-input
				m_pGridCtrl->GetCell(row, col)->SetText(_T(""), false);
				m_pGridCtrl->ShowEditBox();
				return 0;
			} else {
				m_pGridCtrl->SetCellText(row, col, _T(""));
			}
		}
	} else if (col == 1) {
		if (value < 1 || value > 5) {
			//int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
			int nType = theApp.CBTMessageBox(this->m_hWnd, OutOfRangeInfo[language], MB_YESNO, language);
			// Write log file: missing value
			theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, OutOfRangeInfo[language], "", "");

			if (nType == IDYES) {								// Re-input
				m_pGridCtrl->GetCell(row, col)->SetText(_T(""), false);
				m_pGridCtrl->ShowEditBox();
				return 0;
			} else {
				m_pGridCtrl->SetCellText(row, col, _T(""));
			}
		}
	}
	m_pGridCtrl->Deselect();
	Invalidate();
	return 0;
}

void CBLE_InfoWnd::OnIndexJump()
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	// Get vector ICs
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vIC;
	m_pDoc->GetData()->GetSubstrate()->DeselectAll(m_SubInfoDir);

	// Get regno, indexX and indexY
	int indexX = atoi(m_pGridCtrl->GetCellText(0, 5)) - 1;
	int indexY = atoi(m_pGridCtrl->GetCellText(1, 5)) - 1;
	int regNo = atoi(m_pGridCtrl->GetCellText(0, 1));
	regNo = 1;
	if (indexX < 0) { //check indexX value
		//AfxMessageBox(WARNING_MESSAGE_INDEXXMISSING, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, IndexXMissing[language], MB_OK, language);
		// Write log file: missing value
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, IndexXMissing[language], "", "");
		return;
	} 
	if (indexY < 0) { //check indexY value
		//AfxMessageBox(WARNING_MESSAGE_INDEXYMISSING, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, IndexYMissing[language], MB_OK, language);
		// Write log file: missing value
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, IndexYMissing[language], "", "");
		return;
	}
	if (regNo <= 0) { //check regno value
		//AfxMessageBox(WARNING_MESSAGE_REGNOMISSING, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, RegNoMissing[language], MB_OK, language);
		// Write log file: missing value
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, RegNoMissing[language], "", "");
		return;
	}

	// Find IC
	int size = vIC.size();
	for (UINT idx = 0; idx < size; idx ++) {
		if (!vIC[idx]->m_Clickable) { // Do not select if display regno differ from IC regno
			continue;
		}
		if (vIC[idx]->m_pRegIC->m_RegNo == regNo) {
			if (vIC[idx]->m_indexX == indexX && vIC[idx]->m_indexY == indexY && !vIC[idx]->m_OutsideSubStrate) {
				// In case IC was deleted
				if ((vIC[idx]->m_Deleted) && (m_DisplayMode == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID)) {
					//AfxMessageBox(WARNING_MESSAGE_IC_DELETED, MB_OK);
					theApp.CBTMessageBox(this->m_hWnd, ICDeleted[language], MB_OK, language);
					// Write log file: Select deleted IC in hide invalide mode
					theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ICDeleted[language], "", "");
					return;
				}
				m_pDoc->GetData()->GetSubstrate()->SelectIC(vIC[idx], m_SubInfoDir);
				UpdateGridData();
				::PostMessage(GetParent()->m_hWnd, WM_UPDATE_VIEW, 0, 0);
				return;
			}
		}
	}
	// Post a message if can't find regno
	//AfxMessageBox(WARNING_MESSAGE_CANTSELECT, MB_OK);
	theApp.CBTMessageBox(this->m_hWnd, ICCantSelect[language], MB_OK, language);

	// Write log file: IC not found
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ICCantSelect[language], "", "");
	return;
}


void CBLE_InfoWnd::OnIndexSend()
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	// Find TFC window
	CWnd * tfc = FindWindow(NULL, TFC_FRAMENAME);
	if (tfc == NULL) {
		//AfxMessageBox(DBLE_SUBINFOWND_NOTRUN_MESS, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, TFCNotRun[language], MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, TFCNotRun[language], "", "");
		return;
	}
	// Get vector ICs
	vector<CBLE_IC*> vIC = m_pDoc->GetData()->GetSubstrate()->m_vIC;
	m_pDoc->GetData()->GetSubstrate()->DeselectAll(m_SubInfoDir);

	// Get regno, indexX and indexY
	int indexX = atoi(m_pGridCtrl->GetCellText(0, 5)) - 1;
	int indexY = atoi(m_pGridCtrl->GetCellText(1, 5)) - 1;
	int regNo = atoi(m_pGridCtrl->GetCellText(0, 1));

	if (indexX < 0) { //check indexX value
		//AfxMessageBox(WARNING_MESSAGE_INDEXXMISSING, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, IndexXMissing[language], MB_OK, language);
		// Write log file: missing value
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, IndexXMissing[language], "", "");
		return;
	} 
	if (indexY < 0) { //check indexY value
		//AfxMessageBox(WARNING_MESSAGE_INDEXYMISSING, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, IndexYMissing[language], MB_OK, language);
		// Write log file: missing value
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, IndexYMissing[language], "", "");
		return;
	}
	if (regNo <= 0) { //check regno value
		//AfxMessageBox(WARNING_MESSAGE_REGNOMISSING, MB_OK);
		theApp.CBTMessageBox(this->m_hWnd, RegNoMissing[language], MB_OK, language);
		// Write log file: missing value
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, RegNoMissing[language], "", "");
		return;
	}

	// Find IC
	int size = vIC.size();
	for (UINT idx = 0; idx < size; idx ++) {
		if (!vIC[idx]->m_Clickable) { // Do not select if display regno differ from IC regno
			continue;
		}
		if (vIC[idx]->m_pRegIC->m_RegNo == regNo) {
			if (vIC[idx]->m_indexX == indexX && vIC[idx]->m_indexY == indexY && !vIC[idx]->m_OutsideSubStrate) {
				// In case IC was deleted
				if (vIC[idx]->m_Deleted) {
					//AfxMessageBox(WARNING_MESSAGE_IC_DELETED, MB_OK);
					theApp.CBTMessageBox(this->m_hWnd, ICDeleted[language], MB_OK, language);
					// Write log file: Select deleted IC in hide invalide mode
					theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ICDeleted[language], "", "");
					return;
				}
				// Don't update selected IC
				//m_pDoc->GetData()->GetSubstrate()->SelectIC(vIC[idx], m_SubInfoDir);
				//UpdateGridData();
				//::PostMessage(GetParent()->m_hWnd, WM_UPDATE_VIEW, 0, 0);

				tfc->PostMessage(WM_TFC_CTRL, (m_SubInfoDir == DBLE_SUBINFO_TYPE_L) ? BLE_INDEX_L : BLE_INDEX_R, m_pDoc->GetData()->CalIndex(*vIC[idx]));
				return;
			}
		}
	}
	// Post a message if can't find regno
	//AfxMessageBox(WARNING_MESSAGE_CANTSELECT, MB_OK);
	theApp.CBTMessageBox(this->m_hWnd, ICCantSelect[language], MB_OK, language);

	// Write log file: IC not found
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, ICCantSelect[language], "", "");
	return;
}

CWnd* CBLE_InfoWnd::GetEditWnd()
{
	return m_pGridCtrl->GetEditWnd();
}

/* 
* Change focus when select a cell on info window or common window
*/
void CBLE_InfoWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	// Ask parent to update receive key window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_REVWND, (WPARAM)m_hWnd, 0);
}

/*
*
*/
void CBLE_InfoWnd::SetDisplayMode(DBLE_MODE mode)
{
	m_DisplayMode = mode;
}

/*
* Change language
*/
void CBLE_InfoWnd::ChangeLanguage()
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	for (UINT id = IDC_INFO_GRID; id <= IDC_INFO_INDEX_SENDTFC; id ++) {
		for (int idx = 0; idx < DBLE_LANGUAGE_ITEMS; idx ++) {
			if ((id == m_pDoc->m_DialogItems[idx].m_ID) && (m_pDoc->m_DialogItems[idx].m_Name.Compare("") != 0)) {
				GetDlgItem(id)->SetWindowText(m_pDoc->m_DialogItems[idx].m_Name);
				break;
			}
		}
	}
}

// #DDT(20140624): Add for InfoDlg mode
void CBLE_InfoWnd::SetSubInfoDir(int dir)
{
	m_SubInfoDir = dir;
}
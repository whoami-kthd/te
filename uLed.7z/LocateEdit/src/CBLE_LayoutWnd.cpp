///////////////////////////////////////////////////////////
//  CBLE_LayoutWnd.cpp
//  Implementation of the Class CBLE_LayoutWnd
//  Created on:      16-Thg7-2013 1:03:28 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////
//

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_LayoutWnd.h"
#include "CBLE_Util.h"
#include "swatch.h"
#include "CBLE_FrameWnd.h"

#define DBLE_LAYOUT_BKG_CLR				RGB(250, 250, 250)
#define DBLE_LAYOUT_SELECT_RECT_CLR		RGB(0, 250, 0)
#define DBLE_LAYOUT_BORDER_SIZE			2
#define DBLE_IC_LINE_CLR				RGB(10, 10, 10)
#define DBLE_IC_GRAY_CLR				RGB(192, 190, 190)
#define DBLE_IC_OVERLAP_CLR				RGB(255, 0, 10)

//#define DBLE_LAYOUT_TEXT_X				2
//#define DBLE_LAYOUT_TEXT_Y				2

/////////////////////////////////////////////////////////////////////////////
// CBLE_LayoutWnd

IMPLEMENT_DYNCREATE(CBLE_LayoutWnd, CScrollView)

CBLE_LayoutWnd::CBLE_LayoutWnd()
{
	m_pDoc = NULL;
	m_RegNo = 0;
	m_Mode = DBLE_MODE_LOCATE_EDIT_HIDE_INVALID;
	m_SelectRect.SetRectEmpty();
	m_Dragging = false;
	m_ClickPnt = CPoint(0, 0);
	m_ScrollPnt = CPoint(0, 0);
	m_Scale = 1.0;
	m_SubInfoDir = 0;
	m_IndexDisplay = 0;
}

CBLE_LayoutWnd::~CBLE_LayoutWnd()
{
	if(m_MemDC.m_hDC != NULL){
		m_MemDC.DeleteDC();
		m_MemBmp.DeleteObject();
	}
}


BEGIN_MESSAGE_MAP(CBLE_LayoutWnd, CScrollView)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	// Mouse events
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_CAPTURECHANGED()
	ON_WM_SIZE()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_LayoutWnd drawing

void CBLE_LayoutWnd::OnDraw(CDC* pDC)
{
	// Draw to virtual DC
	DrawToMemDC();
	// Draw to real DC
	CRect rect;
	GetWindowRect(rect);
	pDC->BitBlt(GetScrollPosition().x, GetScrollPosition().y, rect.Width(), rect.Height(),
		&m_MemDC, 0, 0, SRCCOPY);
}

void CBLE_LayoutWnd::DrawToMemDC()
{
	// Get total size
	CSize size = GetTotalSize();
	// Get region
	CRect rect(CPoint(0, 0), GetTotalSize());
	// Draw background to virtual DC
	m_MemDC.FillSolidRect(rect, DBLE_LAYOUT_BKG_CLR);
	// Set drawing rect
	CRect drawRect = GetSubstrateRect();
	// Set view port for memory DC
	CPoint viewPnt = GetSubstrateRect().TopLeft();
	m_pDoc->GetData()->GetSubstrate()->m_RealTopLeft = viewPnt;
	viewPnt.Offset(- GetScrollPosition());


	//Get root point for displaying index
	CRect displayRect;
	GetClientRect(&displayRect);
	m_pDoc->GetData()->GetSubstrate()->m_DisplayRect = displayRect; 
	m_pDoc->GetData()->GetSubstrate()->m_DisplayCenter = viewPnt + GetRootPoint();
	

	m_MemDC.SetViewportOrg(viewPnt);
	// Draw substrate to virtual DC
	m_pDoc->GetData()->GetSubstrate()->Draw(&m_MemDC, drawRect, m_Mode, m_RegNo, &(m_pDoc->GetData()->m_StatusColor), m_SubInfoDir, m_IndexDisplay);

	// Draw the selected rectangle
	if(!m_SelectRect.IsRectEmpty()){
		CRect selRect = m_SelectRect;
		selRect.OffsetRect(- GetScrollPosition());
		CRectTracker tracker = CRectTracker(selRect, CRectTracker::hatchInside);
		tracker.Draw(&m_MemDC);
	}
	// Set the default view port for memory DC
	m_MemDC.SetViewportOrg(0, 0);
}

BOOL CBLE_LayoutWnd::OnEraseBkgnd(CDC* pDC)
{
	// do nothing
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_LayoutWnd diagnostics

#ifdef _DEBUG
void CBLE_LayoutWnd::AssertValid() const
{
	CScrollView::AssertValid();
}

void CBLE_LayoutWnd::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBLE_LayoutWnd message handlers

void CBLE_LayoutWnd::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

int CBLE_LayoutWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if(CScrollView::OnCreate(lpCreateStruct) == -1) return -1;
	SetScale(m_Scale,true);

	// Get the window region
	CRect rect;
	GetDesktopWindow()->GetWindowRect(rect);
	// Create the virtual DC
	CDC* pDC = GetDC();
	m_MemDC.CreateCompatibleDC(pDC);
	m_MemBmp.CreateCompatibleBitmap(pDC, rect.Width(), rect.Height());
	m_MemDC.SelectObject(&m_MemBmp);

	return 0;
}

void CBLE_LayoutWnd::OnMButtonDown(UINT nFlags, CPoint point)
{
	// Update scroll point
	m_ScrollPnt = point;
}

void CBLE_LayoutWnd::SetScale(double scale, bool isZoom)
{
	bool flag = true; // used to handle exception case
// #DUCDT131122: If current scale is 1, zoom in with center is display center
	if (/*m_Scale > scale*/CBLE_Util::DoubleComparison(m_Scale, 1.0)) { // if zoom in for first time then zooming center is center of display
		flag = false;
	}
	m_Scale = scale;
	// Get region
	CRect rect;
	GetClientRect(&rect);

	// Store previous scroll bar
	double Vpercent = 0.0;
	if(GetScrollLimit(SB_VERT) != 0){
		Vpercent = (double)GetScrollPos(SB_VERT)/(double)GetScrollLimit(SB_VERT);
	}
	double Hpercent = 0.0;
	if(GetScrollLimit(SB_HORZ) != 0){
		Hpercent = (double)GetScrollPos(SB_HORZ)/(double)GetScrollLimit(SB_HORZ);
	}

	// Set scroll size
	long wndStyle = GetWindowLong(GetSafeHwnd(), GWL_STYLE);
	int HSize = ((wndStyle & WS_HSCROLL) == 0) ? 0 : GetSystemMetrics(SM_CXHSCROLL);
	int VSize = ((wndStyle & WS_VSCROLL) == 0) ? 0 : GetSystemMetrics(SM_CXVSCROLL);
	CSize size = rect.Size() + CSize(HSize, VSize);
	SetScrollSizes(MM_TEXT, CBLE_Util::ScaleSize(size, scale));

	// Calculate the scroll position
	GetClientRect(&rect);
	bool hasSel = true;
	CPoint center = GetZoomPoint(hasSel, isZoom);

	int HPos = 0, VPos = 0;
	if(hasSel){
		// Hozirontal
		HPos = (scale == 1.0) ? 0 : (center.x - rect.Width()/2);

		if(HPos < 0){
			HPos = 0;
		}else if(HPos > GetScrollLimit(SB_HORZ)){
			HPos = GetScrollLimit(SB_HORZ);
		}
		// Vertical
		VPos = (scale == 1.0) ? 0 : (center.y - rect.Height()/2);

		if(VPos < 0){
			VPos = 0;
		}else if(VPos > GetScrollLimit(SB_VERT)){
			VPos = GetScrollLimit(SB_VERT);
		}
	} else {
		// Zooming center is current scroll bar position
		VPos = CBLE_Util::Round(Vpercent * GetScrollLimit(SB_VERT));
		HPos = CBLE_Util::Round(Hpercent * GetScrollLimit(SB_HORZ));

		// Handle exception case: restore scroll bar whel scale is 1.0
		if (scale == 1.0) {
			VPos = 0;
			HPos = 0;
		}

		// Handle exception case: zooming center is center of display when zoom for the first time
// #DUCDT131122: Zoom in with center is display center
/*
		if (scale == 2.0) {
			if (Vpercent == 0 && flag) VPos = 0.5 * GetScrollLimit(SB_VERT);
			if (Hpercent == 0 && flag) HPos = 0.5 * GetScrollLimit(SB_HORZ);
		}
*/
		if (scale > 1.0) {
			if (Vpercent == 0 && !flag) VPos = 0.5 * GetScrollLimit(SB_VERT);
			if (Hpercent == 0 && !flag) HPos = 0.5 * GetScrollLimit(SB_HORZ);
		}
	}

	// Set scroll position
	SetScrollPos(SB_HORZ, HPos);
	SetScrollPos(SB_VERT, VPos);
}

void CBLE_LayoutWnd::SetMode(DBLE_MODE mode)
{
	m_Mode = mode;
	m_pDoc->GetData()->GetSubstrate()->DeselectAll(m_SubInfoDir);
	// Post message to update the selected IC in the parent window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_SELECTED, 0, 0);
}

void CBLE_LayoutWnd::SetRegNo(int RegNo)
{
	m_RegNo = RegNo;
	// If regno = 0 and in edit mode, change mode into hide invalid
	if (m_RegNo == 0 && m_pDoc->GetMode() == DBLE_EDIT_MODE) {
		SetMode(DBLE_MODE_LOCATE_EDIT_HIDE_INVALID);
	}
	m_pDoc->GetData()->GetSubstrate()->DeselectAll(m_SubInfoDir);
	// Post message to update the selected IC in the parent window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_SELECTED, 0, 0);
}

DBLE_MODE CBLE_LayoutWnd::GetMode()
{
	return m_Mode;
}


void CBLE_LayoutWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	// Set the selected rectangle
	m_ClickPnt = point + GetScrollPosition();
	m_Dragging = true;
	SetCapture();
	// Get the refferent point
	//CPoint refPnt = CBLE_Util::ScalePoint(point - GetRootPoint() + GetScrollPosition(), 1/GetDrawScale());
	R2Pos refPnt = CBLE_Util::ScaleR2Point(point - GetRootPoint() + GetScrollPosition(), 1/GetDrawScale());
	// Get the substrate
	CBLE_Substrate* pSubs = m_pDoc->GetData()->GetSubstrate();

	//pSubs->MouseDown(nFlags, R2Pos(refPnt.x, refPnt.y), m_Mode, m_RegNo);
	pSubs->MouseDown(nFlags, refPnt, m_Mode, m_RegNo, m_SubInfoDir);

	// Redraw
	Invalidate();

	// Post message to update the selected IC in the parent window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_SELECTED, 0, 0);
}

void CBLE_LayoutWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	if(!m_SelectRect.IsRectEmpty()){
		// Refferent rect
		m_SelectRect.OffsetRect(- GetRootPoint());
		double scale = 1/GetDrawScale();
		R2Pos p1 = CBLE_Util::ScaleR2Point(m_SelectRect.TopLeft(), scale);
		R2Pos p2 = CBLE_Util::ScaleR2Point(m_SelectRect.BottomRight(), scale);
		// Get the substrate
		CBLE_Substrate* pSubs = m_pDoc->GetData()->GetSubstrate();
		pSubs->MouseUp(p1, p2, m_Mode, m_RegNo, m_SubInfoDir);
		// Release the selected rectangle
		m_SelectRect.SetRectEmpty();
	}
	// Release capture mouse
	ReleaseCapture();
	// Post message to update the selected IC in the parent window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_SELECTED, 0, 0);
}


void CBLE_LayoutWnd::OnMouseMove(UINT nFlags, CPoint point)
{
	if (nFlags & MK_MBUTTON) { // allow click on middle mouse button and move
		//Fix bugs: Hold middle mouse and move after zoom in then zoom out
		if (m_Scale != 1.0) {
			int hPos = GetScrollPos(SB_HORZ) + CBLE_Util::ScalePoint(point, 1/GetDrawScale()).x - CBLE_Util::ScalePoint(m_ScrollPnt, 1/GetDrawScale()).x;
			int vPos = GetScrollPos(SB_VERT) + CBLE_Util::ScalePoint(point, 1/GetDrawScale()).y - CBLE_Util::ScalePoint(m_ScrollPnt, 1/GetDrawScale()).y;

			if (hPos > GetScrollLimit(SB_HORZ)) {
				hPos = GetScrollLimit(SB_HORZ);
			}

			if (vPos > GetScrollLimit(SB_VERT)) {
				vPos = GetScrollLimit(SB_VERT);
			}

			// Set scroll position
			SetScrollPos(SB_HORZ, hPos);
			SetScrollPos(SB_VERT, vPos);
			Invalidate();
		}
	}
	// Get the substrate
	CBLE_Substrate* pSubs = m_pDoc->GetData()->GetSubstrate();
	if (pSubs->m_bDisplayRealTime) {
		R2Pos refPnt = CBLE_Util::ScaleR2Point(point - GetRootPoint() + GetScrollPosition(), 1/GetDrawScale());

		//pSubs->MouseDown(nFlags, R2Pos(refPnt.x, refPnt.y), m_Mode, m_RegNo);
		pSubs->FocusOnIC(refPnt, m_Mode, m_RegNo, m_SubInfoDir);
		// Redraw
		Invalidate();

		// Post message to update the selected IC in the parent window
		::PostMessage(GetParent()->m_hWnd, WM_DISPLAY_FOCUSIC, 0, 0);
	}

	if(!m_Dragging) return;
	m_SelectRect.SetRect(m_ClickPnt, point + GetScrollPosition());
	m_SelectRect.NormalizeRect();

	// Redraw
	Invalidate();
}


void CBLE_LayoutWnd::OnCaptureChanged(CWnd *pWnd)
{
	if(m_Dragging){
		// Stop the dragging
		m_Dragging = false;
	}
	// Redraw
	Invalidate();
}

BOOL CBLE_LayoutWnd::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// Active zoom
	if(nFlags & MK_CONTROL){
		WPARAM wParam = (zDelta > 0) ? (WPARAM)DBLE_ZOOM_IN : (WPARAM)DBLE_ZOOM_OUT;
		// Post message to redraw the parent window
		::PostMessage(GetParent()->m_hWnd, WM_UPDATE_ZOOM, wParam, 0);
	}
	if (m_IndexDisplay != 0) {
		Invalidate();
	}
	return CScrollView::OnMouseWheel(nFlags, zDelta, pt);
}

CPoint CBLE_LayoutWnd::GetRootPoint()
{
	return CPoint(GetTotalSize().cx/2, GetTotalSize().cy/2);
}

CRect CBLE_LayoutWnd::GetSubstrateRect()
{
	// Get total size
	CSize size = GetTotalSize();
	// Get region
	CRect rect(CPoint(0, 0), GetTotalSize());
	// Set drawing rect
	CRect subsRect = rect;
	/*if(size.cx > size.cy){
		subsRect.left = rect.CenterPoint().x - size.cy/2;
		subsRect.right = subsRect.left + size.cy;
	}else{
		subsRect.top = rect.CenterPoint().y - size.cx/2;
		subsRect.bottom = subsRect.top + size.cx;
	}*/
	subsRect.DeflateRect(DBLE_LAYOUT_BORDER_SIZE, DBLE_LAYOUT_BORDER_SIZE);
	return subsRect;
}

double CBLE_LayoutWnd::GetDrawScale()
{
	// Get the substrate
	CBLE_Substrate* pSubs = m_pDoc->GetData()->GetSubstrate();
	// Get the border size of substrate
	CSize bdrSize = pSubs->GetBorderSize();
	// Get the substrate region
	CRect subRect = GetSubstrateRect();
	subRect.DeflateRect(bdrSize.cx, bdrSize.cy);

	double minSize = min((double)subRect.Width(), (double)subRect.Height());
	return minSize/max(pSubs->m_SizeX, pSubs->m_SizeY);
}


CPoint CBLE_LayoutWnd::GetZoomPoint(bool& hasSel, bool isZoom)
{
	// Get all seleted ICs
	CBLE_Substrate* pSubs = m_pDoc->GetData()->GetSubstrate();
	vector<CBLE_IC*> vIC;
	if (isZoom) {
		// #DDT(20140624): Update vIC following mode
		if (m_SubInfoDir == 0) {
			vIC = pSubs->m_vSelIC;
		} else if (m_SubInfoDir == DBLE_SUBINFO_TYPE_L) {
			vIC = pSubs->m_vSelICL;
		} else if (m_SubInfoDir == DBLE_SUBINFO_TYPE_R) {
			vIC = pSubs->m_vSelICR;
		}
	} else {
		int icSize = pSubs->m_vIC.size();
		for (int idx = 0; idx < icSize; idx++ ) {
			if ((pSubs->m_vIC[idx]->m_Overlapped) && (!pSubs->m_vIC[idx]->m_Deleted)) {
				vIC.push_back(pSubs->m_vIC[idx]);
				break;
			} 
		}
	}

	// Get the center points of all selected ICs
	double centerX, centerY;
	centerX = centerY = 0.0;
	int selNum = (int)vIC.size();
	
	for(int idx = 0; idx < selNum; idx ++){
		centerX += vIC[idx]->GetPosX()/(double)selNum;
		centerY += vIC[idx]->GetPosY()/(double)selNum;
	}
	CPoint center = CPoint(CPoint(CBLE_Util::Round(centerX), CBLE_Util::Round(-centerY)));
	center = CBLE_Util::ScalePoint(center, GetDrawScale());

	hasSel = (selNum != 0);
	return (center + GetRootPoint());
}

void CBLE_LayoutWnd::OnSize(UINT nType, int cx, int cy)
{
	CScrollView::OnSize(nType, cx, cy);
	SetScale(m_Scale,true);
}

void CBLE_LayoutWnd::SetSubInfoDir(int dir)
{
	m_SubInfoDir = dir;
}

int CBLE_LayoutWnd::GetIndexDisplay()
{
	return m_IndexDisplay;
}

void CBLE_LayoutWnd::SetIndexDisplay(int indexDisplay)
{
	m_IndexDisplay = indexDisplay;
}

void CBLE_LayoutWnd::SetScroll(CBLE_IC *ic)
{
	// Get region
	CRect rect;
	GetClientRect(&rect);
	// Calculate the scroll position
	CPoint center = CPoint(CPoint(CBLE_Util::Round(ic->GetPosX()), CBLE_Util::Round(-(ic->GetPosY()))));
	center = CBLE_Util::ScalePoint(center, GetDrawScale());
	center += GetRootPoint();

	const double SCROLL_AREA_RATE = 0.1;
	// Get current scroll position
	int HPos = GetScrollPos(SB_HORZ);
	int VPos = GetScrollPos(SB_VERT);

	int diff = center.x - HPos;
	if ((diff < rect.Width() * SCROLL_AREA_RATE) || (diff > rect.Width() * (1-SCROLL_AREA_RATE))) {
		// Hozirontal
		HPos = (m_Scale == 1.0) ? 0 : (center.x - rect.Width()/2);
		if(HPos < 0){
			HPos = 0;
		}else if(HPos > GetScrollLimit(SB_HORZ)){
			HPos = GetScrollLimit(SB_HORZ);
		}
	}
	diff = center.y - VPos;
	if ((diff < rect.Height() * SCROLL_AREA_RATE) || (diff > rect.Height() * (1 - SCROLL_AREA_RATE))) {
		// Vertical
		VPos = (m_Scale == 1.0) ? 0 : (center.y - rect.Height()/2);
		if(VPos < 0){
			VPos = 0;
		}else if(VPos > GetScrollLimit(SB_VERT)){
			VPos = GetScrollLimit(SB_VERT);
		}
	}

	// Set scroll position
	SetScrollPos(SB_HORZ, HPos);
	SetScrollPos(SB_VERT, VPos);
}

/**
* Catch Ctrl + Z to restore
*/
/*
BOOL CBLE_LayoutWnd::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN){
		if ((GetKeyState(0x5A) & 0x8000) && (GetKeyState(VK_CONTROL) & 0x8000)) {
			CBLE_FrameWnd *frame = (CBLE_FrameWnd*)GetParentFrame();
			frame->OnRestoreState();
		}
    }	
    return CScrollView::PreTranslateMessage(pMsg);
}
*/
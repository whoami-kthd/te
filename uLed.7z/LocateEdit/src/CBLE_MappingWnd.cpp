///////////////////////////////////////////////////////////
//  CBLE_MappingWnd.cpp
//  Implementation of the Class CBLE_MappingWnd
//  Created on:      16-Thg7-2013 10:25:37 SA
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_MappingWnd.h"
#include "CBLE_CareTaker.h"
#include "CBLE_FrameWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CBLE_MappingWnd dialog

CBLE_MappingWnd::CBLE_MappingWnd(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_MappingWnd::IDD, pParent)
{
	m_pDoc = NULL;

	m_BarCodeRead = 0;
	m_Orientation = 0;
	m_RefDie = 0;
	m_Focus = IDC_MAPP_X_EDIT;

	m_Mark = 0;
}

CBLE_MappingWnd::~CBLE_MappingWnd()
{

}


void CBLE_MappingWnd::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_MAPP_BARCODE_ON, m_BarCodeRead);
	DDX_Radio(pDX, IDC_MAPP_DIRECTION_0, m_Orientation);
	DDX_Radio(pDX, IDC_MAPP_REF_NONE, m_RefDie);
}


BEGIN_MESSAGE_MAP(CBLE_MappingWnd, CDialog)
	ON_WM_LBUTTONDOWN()
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateValue)
	ON_BN_CLICKED(IDC_MAPPING_CANCEL_BTN, OnMappingCancel)
	ON_BN_CLICKED(IDC_MAPPING_CHECK_BTN, OnCheckReflect)
	ON_WM_CLOSE()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_MappingWnd message handlers

BOOL CBLE_MappingWnd::OnInitDialog()
{
	CDialog::OnInitDialog();
	// Create key window
	CRect rect;
	GetDlgItem(IDC_MAPP_FULL_KEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(m_Edit.GetEditWnd(), IDD_FKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);

	// Create the edit box
	m_Edit.Create(IDD_EDIT_BOX_DLG, this);
	m_Edit.SetWindowPos(&CWnd::wndBottom, 0, 0, 0, 0, SWP_DRAWFRAME);
	m_Edit.SetEditFont(DBLE_MAPPING_FONT_SIZE, DBLE_MAPPING_FONT_NAME);
	m_Edit.SetRevWnd(this);

	// Initialize view and update data
	InitView();
	UpdateData(FALSE);

	return TRUE;
}

void CBLE_MappingWnd::OnCancel()
{
	CDialog::OnCancel();

	// Refresh buffer store
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	pCareTaker->ResetStore();
}

void CBLE_MappingWnd::OnOK()
{
	// Do nothing
}

void CBLE_MappingWnd::OnClose()
{
	OnCancel();
}



void CBLE_MappingWnd::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

void CBLE_MappingWnd::InitView()
{
	UpdateView();
	ShowWindow(SW_SHOW);
}

void CBLE_MappingWnd::UpdateView()
{
	TBLE_Mapping map;
	map = m_pDoc->GetData()->m_MapData;
	m_BarCodeRead = 1 - map.m_BCRead;
	m_Orientation = map.m_OriFlat/90;
	m_RefDie = map.m_RefDie;
	CString tmp;
	tmp.Format("%d", map.m_RefDieX);
	GetDlgItem(IDC_MAPP_X_EDIT)->SetWindowText(tmp);
	tmp.Format("%d", map.m_RefDieY);
	GetDlgItem(IDC_MAPP_Y_EDIT)->SetWindowText(tmp);
	GetDlgItem(IDC_MAPP_PATTERN_EDIT)->SetWindowText(map.m_GoodBin);
	GetDlgItem(IDC_MAPP_NULL_EDIT)->SetWindowText(map.m_NullBin);
	GetDlgItem(IDC_MAPP_PASS_EDIT)->SetWindowText(map.m_PassBin);
	GetDlgItem(IDC_MAPP_BONDED_EDIT)->SetWindowText(map.m_BondedBin);
	UpdateData(FALSE);
}

void CBLE_MappingWnd::OnMappingCancel()
{
	OnCancel();

}

void CBLE_MappingWnd::CloseWnd()
{
	int Answer = MessageBox("Do you want to save current setting?", NULL, MB_OKCANCEL|MB_ICONWARNING);
	if(Answer == IDOK){
		OnCheckReflect();
	} else {
		OnCancel();
	}
	
}

void CBLE_MappingWnd::OnCheckReflect()
{
	// Update modified flag
	m_pDoc->SetModifiedFlag(1);

	CBLE_Model *model = m_pDoc->GetData();
	CString fileName = model->GetDataFilePath() + DBLE_MODEL_DV290_NAME;
	UpdateData();
	int deg = 0;
	switch (m_Orientation) {
		case 0:
			deg = 0;
			break;
		case 1:
			deg = 90;
			break;
		case 2:
			deg = 180;
			break;
		case 3:
			deg = 270;
			break;
		default:
			break;
	}
	model->m_MapData.m_OriFlat = deg;
	CString tmp;
	GetDlgItem(IDC_MAPP_X_EDIT)->GetWindowText(tmp);
	model->m_MapData.m_RefDieX = atoi(tmp);
	GetDlgItem(IDC_MAPP_Y_EDIT)->GetWindowText(tmp);
	model->m_MapData.m_RefDieY = atoi(tmp);
	GetDlgItem(IDC_MAPP_PATTERN_EDIT)->GetWindowText(model->m_MapData.m_GoodBin);
	GetDlgItem(IDC_MAPP_NULL_EDIT)->GetWindowText(model->m_MapData.m_NullBin);
	GetDlgItem(IDC_MAPP_PASS_EDIT)->GetWindowText(model->m_MapData.m_PassBin);
	GetDlgItem(IDC_MAPP_BONDED_EDIT)->GetWindowText(model->m_MapData.m_BondedBin);
	// Get bar code read
	switch (m_BarCodeRead) {
		case 0:
			model->m_MapData.m_BCRead = 1;
			break;
		case 1:
			model->m_MapData.m_BCRead = 0;
			break;
		default: 
			break;
	}
	switch (m_RefDie) {
		case 0:
			model->m_MapData.m_RefND = 0;
			break;
		case 1:
			model->m_MapData.m_RefND = 1;
			break;
		default:
			break;
	}
	// Write mapping data
	// model->MappingDataRW(false);

	// Write log
	theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_OPERATION, DBLE_LOGFILE_CHECKREFELCT, DBLE_LOGFILE_MAPPING, "");

	// Close window
	OnCancel();
}

// Handle when left mouse down
void CBLE_MappingWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	CString text;
	// For Undo function
	if (m_Mark != 0) {
		GetDlgItem(m_Mark)->GetWindowText(text);
		// Overlap mark cell
		GetDlgItem(m_Mark)->SetWindowText(text);
		// Reset mark cell
		m_Mark = 0;
	}
	
	CRect rect;
	bool in = false;
	for (int i = 0; i < DBLE_MAPPING_EDIT_NO; i++) {
		GetDlgItem(IDC_MAPP_X_EDIT + i)->GetWindowRect(rect);
		ScreenToClient(&rect);
		if (rect.PtInRect(point)) {
			m_Focus = i + IDC_MAPP_X_EDIT;
			GetDlgItem(m_Focus)->GetWindowText(text);
			in = true;
			break;
		}
	}
	//m_Edit.GetEditWnd()->SetFocus();
	if (in) {
		// Set edit window & text
		ClientToScreen(&rect);
		m_Edit.MoveWindow(rect);
		m_Edit.SetText(text);
		m_Edit.GetEditWnd()->SetFocus();
		m_Edit.SetMode(1);
		switch (m_Focus) {
			case IDC_MAPP_X_EDIT:
			case IDC_MAPP_Y_EDIT:
				m_Edit.SetIntegerMode(true);
				break;
			case IDC_MAPP_PATTERN_EDIT:
			case IDC_MAPP_NULL_EDIT:
			case IDC_MAPP_PASS_EDIT:
			case IDC_MAPP_BONDED_EDIT:
				m_Edit.SetIntegerMode(false);
				break;
			default:
				break;

		}
		m_Edit.ShowWindow(SW_SHOW);
	} else {
		// Reset focus and edit window
		m_Focus = 0;
		m_Edit.MoveWindow(CRect(0, 0, 0, 0));
		m_Edit.ShowWindow(SW_HIDE);
	}
	return;
}

LRESULT CBLE_MappingWnd::OnUpdateValue(WPARAM wParam, LPARAM lParam)
{
	CString text = m_Edit.GetText();

	CString tmp;
	GetDlgItem(m_Focus)->GetWindowText(tmp);
	if (tmp.Compare(text) != 0) {
		// For undo function
		// Store state
		CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
		TBLE_Mapping *mapping = new TBLE_Mapping();
		GetDlgItem(IDC_MAPP_X_EDIT)->GetWindowText(tmp);
		mapping->m_RefDieX = atoi(tmp);
		GetDlgItem(IDC_MAPP_Y_EDIT)->GetWindowText(tmp);
		mapping->m_RefDieY = atoi(tmp);
		GetDlgItem(IDC_MAPP_PATTERN_EDIT)->GetWindowText(mapping->m_GoodBin);
		GetDlgItem(IDC_MAPP_NULL_EDIT)->GetWindowText(mapping->m_NullBin);
		GetDlgItem(IDC_MAPP_PASS_EDIT)->GetWindowText(mapping->m_PassBin);
		GetDlgItem(IDC_MAPP_BONDED_EDIT)->GetWindowText(mapping->m_BondedBin);
		CBLE_MapStore mem(mapping, IDD_MAPPING_DLG, MAPP_TYPE);
		pCareTaker->SetMemento(mem);
	}

	// Delete store if old value is same as new value
	int i = 0;
	switch (m_Focus) {
		case IDC_MAPP_X_EDIT:
		case IDC_MAPP_Y_EDIT:
			// Convert to integer
			i = atoi(text);
			text.Format("%d", i);
			break;
		default:
			break;
	}
	GetDlgItem(m_Focus)->SetWindowText(text);
	// Focus on Mapping Window
	SetFocus();
	// Reset focus and edit window
	m_Focus = 0;
	m_Edit.MoveWindow(CRect(0, 0, 0, 0));
	m_Edit.ShowWindow(SW_HIDE);
	return 0;
}

/**
* Change language
*/
void CBLE_MappingWnd::ChangeLanguage()
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	for (UINT id = IDC_MAPP_BARCODE_ON; id <= IDC_MAPP_BONDED_EDIT; id ++) {
		for (int idx = 0; idx < DBLE_LANGUAGE_ITEMS; idx ++) {
			if ((id == m_pDoc->m_DialogItems[idx].m_ID) && (m_pDoc->m_DialogItems[idx].m_Name.Compare("") != 0)) {
				GetDlgItem(id)->SetWindowText(m_pDoc->m_DialogItems[idx].m_Name);
				break;
			}
		}
	}
}


/**
* Restore state
*/
void CBLE_MappingWnd::RestoreState()
{
	CBLE_CareTaker *pCareTaker = CBLE_CareTaker::CreateInstance();
	//CBLE_CareTaker::m_DialogID = IDD_MAPPING_DLG;
	if (!pCareTaker->Restoreable() || (pCareTaker->GetLastKind() != IDD_MAPPING_DLG)) {
		return;
	}
	CBLE_Memento mem = pCareTaker->GetMemento();
	void *tmpMem = mem.GetState();
	TBLE_Mapping *mapping = static_cast<TBLE_Mapping *> (tmpMem);

	CString oldText;
	// Restore
	CString tmp;
	tmp.Format("%d", mapping->m_RefDieX);
	GetDlgItem(IDC_MAPP_X_EDIT)->GetWindowText(oldText);
	if (oldText.Compare(tmp) != 0) {
		m_Mark = IDC_MAPP_X_EDIT;
	}
	GetDlgItem(IDC_MAPP_X_EDIT)->SetWindowText(tmp);

	tmp.Format("%d", mapping->m_RefDieY);
	GetDlgItem(IDC_MAPP_Y_EDIT)->GetWindowText(oldText);
	if (oldText.Compare(tmp) != 0) {
		m_Mark = IDC_MAPP_Y_EDIT;
	}
	GetDlgItem(IDC_MAPP_Y_EDIT)->SetWindowText(tmp);

	GetDlgItem(IDC_MAPP_PATTERN_EDIT)->GetWindowText(oldText);
	if (oldText.Compare(mapping->m_GoodBin) != 0) {
		m_Mark = IDC_MAPP_PATTERN_EDIT;
	}
	GetDlgItem(IDC_MAPP_PATTERN_EDIT)->SetWindowText(mapping->m_GoodBin);

	GetDlgItem(IDC_MAPP_NULL_EDIT)->GetWindowText(oldText);
	if (oldText.Compare(mapping->m_NullBin) != 0) {
		m_Mark = IDC_MAPP_NULL_EDIT;
	}
	GetDlgItem(IDC_MAPP_NULL_EDIT)->SetWindowText(mapping->m_NullBin);

	GetDlgItem(IDC_MAPP_PASS_EDIT)->GetWindowText(oldText);
	if (oldText.Compare(mapping->m_PassBin) != 0) {
		m_Mark = IDC_MAPP_PASS_EDIT;
	}
	GetDlgItem(IDC_MAPP_PASS_EDIT)->SetWindowText(mapping->m_PassBin);

	GetDlgItem(IDC_MAPP_BONDED_EDIT)->GetWindowText(oldText);
	if (oldText.Compare(mapping->m_BondedBin) != 0) {
		m_Mark = IDC_MAPP_BONDED_EDIT;
	}
	GetDlgItem(IDC_MAPP_BONDED_EDIT)->SetWindowText(mapping->m_BondedBin);
	OnPaint();
	delete mapping;
}

void CBLE_MappingWnd::OnPaint()
{
	CDialog::OnPaint();
	CRect rect;
	CClientDC dc(this);
	if (m_Mark != 0) {
		CPen pen;
		pen.CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
		CBrush brush;

		// Store brush
		CBrush* pOlBrush = dc.GetCurrentBrush();
		// Store pen
		CPen* pOldPen = dc.SelectObject(&pen);
		CWnd* pWnd = GetDlgItem(m_Mark);
		if(pWnd != NULL) {
			pWnd->GetWindowRect(rect);
			ScreenToClient(&rect);
			rect.DeflateRect(3, 3);
			dc.SelectObject(GetStockObject(NULL_BRUSH));
			vector<CPoint> vPoint;
			vPoint.push_back(CPoint(rect.left, rect.bottom));
			vPoint.push_back(CPoint(rect.right, rect.bottom));
			vPoint.push_back(CPoint(rect.right, rect.top));
			vPoint.push_back(CPoint(rect.left, rect.top));
			dc.Polygon(&vPoint[0], 4);
		}
		// Restore old brush
		dc.SelectObject(pOlBrush);
		// Restore old pen
		dc.SelectObject(pOldPen);
	}
}

/**
* Catch Ctrl + Z to restore
*/
BOOL CBLE_MappingWnd::PreTranslateMessage(MSG* pMsg)
{
	if(pMsg->message == WM_KEYDOWN /*&& pMsg->wParam == VK_CONTROL*/){
		if ((GetKeyState(0x5A) & 0x8000) && (GetKeyState(VK_CONTROL) & 0x8000)) {
			CBLE_FrameWnd *frame = (CBLE_FrameWnd*)GetParentFrame();
			frame->OnRestoreState();
		}
    }	
    return CDialog::PreTranslateMessage(pMsg);
}

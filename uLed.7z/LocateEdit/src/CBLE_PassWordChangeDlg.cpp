// CBLE_PassWordChangeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "..\\BLE.h"
#include "CBLE_PassWordChangeDlg.h"

//#define WARNING_MESSAGE_PASSNOTTHESAME		_T("Your password is not correct!")
//#define WARNING_MESSAGE_PASSINUSE			_T("Your password currently in use!")

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Define window text for Japanese and English
//
CString PassNotTheSame[] =	{							
								_T("�p�X���[�h�͊ԈႢ�܂��B"),
								_T("Your password is not correct!"),
							};

CString PassInUse[] =		{
								_T("���̃p�X���[�h�͎g���Ă��܂��B"),
								_T("Your password currently in use!"),
							};

/////////////////////////////////////////////////////////////////////////////
// CBLE_PassWordChangeDlg dialog


CBLE_PassWordChangeDlg::CBLE_PassWordChangeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBLE_PassWordChangeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBLE_PassWordChangeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pDoc = NULL;
	m_ID = IDC_CHANGEPASSWORD_ENTERPASS;
}


void CBLE_PassWordChangeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBLE_PassWordChangeDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


void CBLE_PassWordChangeDlg::SetDocument(CBLE_Doc* pDoc)
{
	m_pDoc = pDoc;
}

BOOL CBLE_PassWordChangeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Create key window
	CRect rect;
	GetDlgItem(IDC_CHANGEPASSWORD_NUM_KEY)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_KeyWnd.Create(this, IDD_NKEY_DLG, this);
	m_KeyWnd.SetWindowPos(&CWnd::wndBottom,
		rect.left, rect.top, rect.Width(), rect.Height(), SWP_DRAWFRAME);
	m_KeyWnd.ShowWindow(SW_SHOW);

	DisplayPasswordLevel();
	UpdateData(FALSE);

	// Change language
	ChangeLanguage();

	return TRUE;
}

BEGIN_MESSAGE_MAP(CBLE_PassWordChangeDlg, CDialog)
	//{{AFX_MSG_MAP(CBLE_PassWordChangeDlg)
	ON_BN_CLICKED(IDC_CHANGEPASSWORD_EXECUTE, OnChangepasswordExecute)
	ON_BN_CLICKED(IDC_CHANGEPASSWORD_CANCEL, OnChangepasswordCancel)
	ON_MESSAGE(WM_UPDATE_KEY, OnPressKey)
	ON_EN_SETFOCUS(IDC_CHANGEPASSWORD_ENTERPASS, OnSetfocusChangepasswordEnterpass)
	ON_EN_SETFOCUS(IDC_CHANGEPASSWORD_REENTRYPASS, OnSetfocusChangepasswordReentrypass)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_PassWordChangeDlg message handlers

void CBLE_PassWordChangeDlg::OnChangepasswordExecute() 
{
	int language = m_pDoc->GetData()->m_Init.m_Language;
	// TODO: Add your control notification handler code here
		// TODO: Add your control notification handler code here
	bool close = true;
	CString enterPass;
	GetDlgItem(IDC_CHANGEPASSWORD_ENTERPASS)->GetWindowText(enterPass);
	CString reentryPass;
	GetDlgItem(IDC_CHANGEPASSWORD_REENTRYPASS)->GetWindowText(reentryPass);
	if (!(strcmp(enterPass, reentryPass))) {
		if (m_pDoc->m_User == DBLE_USER_LEVEL1) {
			if ((enterPass != m_pDoc->GetData()->m_Init.m_PassLevel2) && (enterPass != m_pDoc->GetData()->m_Init.m_PassLevel3)) {
				m_pDoc->GetData()->m_Init.m_PassLevel1 = enterPass;
			} else {
				close = false;
				//AfxMessageBox(WARNING_MESSAGE_PASSINUSE);
				theApp.CBTMessageBox(this->m_hWnd, PassInUse[language], MB_OK, language);
				// Write log file: pass in use
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, PassInUse[language], "", "");
			}
		} else if (m_pDoc->m_User == DBLE_USER_LEVEL2) {
			if ((enterPass != m_pDoc->GetData()->m_Init.m_PassLevel1) && (enterPass != m_pDoc->GetData()->m_Init.m_PassLevel3)) {
				m_pDoc->GetData()->m_Init.m_PassLevel2 = enterPass;
			} else {
				close = false;
				//AfxMessageBox(WARNING_MESSAGE_PASSINUSE);
				theApp.CBTMessageBox(this->m_hWnd, PassInUse[language], MB_OK, language);
				// Write log file: pass in use
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, PassInUse[language], "", "");
			}
		} else {
			if ((enterPass != m_pDoc->GetData()->m_Init.m_PassLevel1) && (enterPass != m_pDoc->GetData()->m_Init.m_PassLevel2)) {
				m_pDoc->GetData()->m_Init.m_PassLevel3 = enterPass;
			} else {
				close = false;
				//AfxMessageBox(WARNING_MESSAGE_PASSINUSE);
				theApp.CBTMessageBox(this->m_hWnd, PassInUse[language], MB_OK, language);
				// Write log file: pass in use
				theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, PassInUse[language], "", "");
			}
		}
	} else {
		close = false;
		//AfxMessageBox(WARNING_MESSAGE_PASSNOTTHESAME);
		theApp.CBTMessageBox(this->m_hWnd, PassNotTheSame[language], MB_OK, language);
		// Write log file: pass in use
		theApp.p_Logger->SetLogFormat(DBLE_LOGFILE_ERROR, PassNotTheSame[language], "", "");
	}
	if (close) {
		m_pDoc->GetData()->SavePassword(enterPass, m_pDoc->m_User);
		CDialog::OnOK();
	}
}

void CBLE_PassWordChangeDlg::OnChangepasswordCancel() 
{
	// TODO: Add your control notification handler code here
	CDialog::OnCancel();
}

LRESULT CBLE_PassWordChangeDlg::OnPressKey(WPARAM wParam, LPARAM lParam)
{
	if ((m_ID == IDC_CHANGEPASSWORD_ENTERPASS)||(m_ID == IDC_CHANGEPASSWORD_REENTRYPASS)) {
		CString temp;
		GetDlgItem(m_ID)->GetWindowText(temp);
		if (UINT(wParam) != IDC_NKEY_ENT) {
			PressNumKey(temp, UINT(wParam), true);
		}
		GetDlgItem(m_ID)->SetWindowText(temp);
	} else {
		return 0;
	}

	return 0;
}

void CBLE_PassWordChangeDlg::OnSetfocusChangepasswordEnterpass() 
{
	// TODO: Add your control notification handler code here
	m_ID = IDC_CHANGEPASSWORD_ENTERPASS;
}

void CBLE_PassWordChangeDlg::OnSetfocusChangepasswordReentrypass() 
{
	// TODO: Add your control notification handler code here
	m_ID = IDC_CHANGEPASSWORD_REENTRYPASS;
}

void CBLE_PassWordChangeDlg::DisplayPasswordLevel()
{
	GetDlgItem(IDC_CHANGEPASSWORD_LEVEL1)->EnableWindow(m_pDoc->m_User == DBLE_USER_LEVEL1);
	GetDlgItem(IDC_CHANGEPASSWORD_LEVEL2)->EnableWindow(m_pDoc->m_User == DBLE_USER_LEVEL2);
	GetDlgItem(IDC_CHANGEPASSWORD_LEVEL3)->EnableWindow(m_pDoc->m_User == DBLE_USER_LEVEL3);
}

// Change a text when press a numkey
void CBLE_PassWordChangeDlg::PressNumKey(CString& text, UINT key, bool isInteger)
{
	switch(key){
	case IDC_NKEY_0:
	case IDC_NKEY_1:
	case IDC_NKEY_2:
	case IDC_NKEY_3:
	case IDC_NKEY_4:
	case IDC_NKEY_5:
	case IDC_NKEY_6:
	case IDC_NKEY_7:
	case IDC_NKEY_8:
	case IDC_NKEY_9:
		{
			CString strNum;
			strNum.Format(_T("%d"), key - IDC_NKEY_0);
			text += strNum;
		}
		break;
	case IDC_NKEY_DEL:
		text = text.Mid(0, text.GetLength() - 1);
		break;
	case IDC_NKEY_DOT:
		text += _T(".");
		break;
	case IDC_NKEY_CLR:
		text = _T("");
		break;
	case IDC_NKEY_MINUS:
		text += _T("-");
		break;
	case IDC_NKEY_ENT:
		if(isInteger){
			text.Format(_T("%d"), atoi(text));
		}else{
			text.Format(_T("%.4f"), atof(text));
		}
		break;
	default:
		break;
	}
}

/*
* Change language
*/
void CBLE_PassWordChangeDlg::ChangeLanguage()
{
	if (m_pDoc->GetData()->m_Init.m_Language == DBLE_LANGUAGE_ENGLISH) {
		return;
	}
	for (UINT id = IDC_CHANGEPASSWORD_NUM_KEY; id <= IDC_CHANGEPASSWORD_CANCEL; id ++) {
		for (int idx = 0; idx < DBLE_LANGUAGE_ITEMS; idx ++) {
			if ((id == m_pDoc->m_DialogItems[idx].m_ID) && (m_pDoc->m_DialogItems[idx].m_Name.Compare("") != 0)) {
				GetDlgItem(id)->SetWindowText(m_pDoc->m_DialogItems[idx].m_Name);
				break;
			}
		}
	}
}

///////////////////////////////////////////////////////////
//  CBLE_Substrate.cpp
//  Implementation of the Class CBLE_Substrate
//  Created on:      12-Thg7-2013 2:12:09 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////
#include "swatch.h"

#include "CBLE_Substrate.h"
#include "CBLE_Util.h"
#include "CBLE_Doc.h"


#define DBLE_SUBS_BKG_CLR					RGB(236, 236, 236)
#define DBLE_SUBS_LINE_CLR					RGB(180, 10, 10)
#define DBLE_SUBS_CENTER_LINE				RGB(192, 190, 190)

#define DBLE_SUBS_START_DRAW_X				4
#define DBLE_SUBS_START_DRAW_Y				4

#define DBLE_SUBS_GRID_X					1
#define DBLE_SUBS_GRID_Y					1
#define DBLE_SUBS_SCALE_REGION				2.0

// Implement serialize
IMPLEMENT_SERIAL(CBLE_Substrate, CObject, 1)

static int IcIdxCreating = 0;

CRITICAL_SECTION syncObj;

TBLE_IC_Region::TBLE_IC_Region()
{
	m_Pos1 = R2Pos(0, 0);
	m_Pos2 = R2Pos(0, 0);
	m_vIC.clear();
}

void TBLE_IC_Region::PushIC(CBLE_IC* pIC)
{
	int maxIC = m_vIC.size();
	for (UINT idx = 0; idx < maxIC; idx ++) {
		// If this IC already in vector
		if (pIC == m_vIC[idx]) {
			return;
		}
	}
	m_vIC.push_back(pIC);
}

void TBLE_IC_Region::PopIC(CBLE_IC* pIC)
{
	int maxIC = m_vIC.size();
	for (UINT idx = 0; idx < maxIC; idx ++) {
		if (pIC != m_vIC[idx]) {
			continue;
		}
		m_vIC.erase(m_vIC.begin() + idx);
		return;
	}
}

/**
* Default constructor
*/
CBLE_Substrate::CBLE_Substrate()
{
	m_Shape = DBLE_SHAPE_SQUARE;
	m_SizeX = 0;
	m_SizeY = 0;
	m_vIC.clear();
	m_vSelIC.clear();
	m_vSelICL.clear();
	m_vSelICR.clear();
	m_vRegion.clear();
	m_ShapeID = 0;

	m_DisplayCenter = CPoint(0,0);
	m_RealTopLeft = CPoint(0, 0);
	m_DisplayRect = CRect();
	
	m_bSelectDeleted = false;
	//Initilize the critical section
	InitializeCriticalSection(&syncObj);

	m_pFocusIC = NULL;
	m_bDisplayRealTime = false;
}


/**
* Default destructor
*/
CBLE_Substrate::~CBLE_Substrate()
{
	ResetData();
	DeleteCriticalSection(&syncObj);
}

/*
 * Check a IC is in region of this substrate or not
 */
bool CBLE_Substrate::ICInSubstrate(CBLE_IC* pIC)
{
	// Get 4 points of IC
	vector<R2Pos> vR2Pnt;
	pIC->GetICPoint(vR2Pnt);

	int ICPointSize = vR2Pnt.size();
	if(m_Shape == DBLE_SHAPE_SQUARE) {
		// Check if any point of IC got outside of substrate
		for(UINT id = 0; id < ICPointSize; id ++){
			if(vR2Pnt[id].x < (-m_SizeX/2.0)) return false;
			if(vR2Pnt[id].x > m_SizeX/2.0) return false;
			if(vR2Pnt[id].y < (-m_SizeY/2.0)) return false;
			if(vR2Pnt[id].y > m_SizeY/2.0) return false;
		}
	} else { // Circle
		double radius = m_SizeX/2.0;
		R2Pos center = R2Pos(0.0, 0.0);
		for(UINT id = 0; id < ICPointSize; id ++) {	
			// Check if distance from four point of IC is greater than radius of the circle
			if( CBLE_Util::SegmentLength(center, vR2Pnt[id]) > radius) return false;
		}
	}
	
	return true;
}


/**
* This function will be used to change selected status of IC
*/
void CBLE_Substrate::SelectIC(CBLE_IC* pIC, int lr)
{
	if (lr == 0) {
		if(pIC->m_Selected) return;
		pIC->m_Selected = true; // change selected status of IC to true
		m_vSelIC.push_back(pIC); //add selected IC to selected IC vector
	} else if (lr == DBLE_SUBINFO_TYPE_L) {
		if(pIC->m_SelectedL) return;
		pIC->m_SelectedL = true; // change selected status of IC to true
		m_vSelICL.push_back(pIC); //add selected IC to selected IC vector
	} else if (lr == DBLE_SUBINFO_TYPE_R) {
		if(pIC->m_SelectedR) return;
		pIC->m_SelectedR = true; // change selected status of IC to true
		m_vSelICR.push_back(pIC); //add selected IC to selected IC vector
	}
}

/**
* This function will be used to de-selected selected IC
*/
void CBLE_Substrate::DeselectIC(CBLE_IC* pIC, int lr)
{
	int selSize;
	if (lr == 0) { 
		pIC->m_Selected = false; // set selected status of IC to false
		//Remove de-selected IC from selected IC vector
		selSize = m_vSelIC.size();
		for(UINT idx = 0; idx < selSize; idx ++){
			if(m_vSelIC[idx] != pIC) continue;
			m_vSelIC.erase(m_vSelIC.begin() + idx);
			break;
		}
	} else if (lr == DBLE_SUBINFO_TYPE_L) {
		pIC->m_SelectedL = false;

		//Remove de-selected IC from selected IC vector
		selSize = m_vSelICL.size();
		for(UINT idx = 0; idx < selSize; idx ++){
			if(m_vSelICL[idx] != pIC) continue;
			m_vSelICL.erase(m_vSelICL.begin() + idx);
			break;
		}
	} else if (lr == DBLE_SUBINFO_TYPE_R) {
		pIC->m_SelectedR = false;

		//Remove de-selected IC from selected IC vector
		selSize = m_vSelICR.size();
		for(UINT idx = 0; idx < selSize; idx ++){
			if(m_vSelICR[idx] != pIC) continue;
			m_vSelICR.erase(m_vSelICR.begin() + idx);
			break;
		}
	}
}

/**
* This function will de-select all selected ICs
*/
void CBLE_Substrate::DeselectAll(int lr)
{
	//change selected status of ICs to false
	int selSize;
	/*for(UINT idx = 0; idx < selSize; idx ++){
		m_vSelIC[idx]->m_Selected = false;
		m_vSelIC[idx]->m_SelectedL = false;
		m_vSelIC[idx]->m_SelectedR = false;
	}*/
	if (lr == 0) {
		selSize = m_vSelIC.size();
		for(UINT idx = 0; idx < selSize; idx ++){
			m_vSelIC[idx]->m_Selected = false;
		}
		//clear selected ICs vector
		m_vSelIC.clear();
	} else if (lr == DBLE_SUBINFO_TYPE_L) {
		selSize = m_vSelICL.size();
		for(UINT idx = 0; idx < selSize; idx ++){
			m_vSelICL[idx]->m_SelectedL = false;
		}
		//clear selected ICs vector
		m_vSelICL.clear();
	} else if (lr == DBLE_SUBINFO_TYPE_R) {
		selSize = m_vSelICR.size();
		for(UINT idx = 0; idx < selSize; idx ++){
			m_vSelICR[idx]->m_SelectedR = false;
		}
		//clear selected ICs vector
		m_vSelICR.clear();
	}
}

/**
* Handle mouse down event from user
*/
void CBLE_Substrate::MouseDown(UINT nFlags, R2Pos point, DBLE_MODE mode, int RegNo, int lr)
{
	//allow select multi ICs when holding shift
	if(!(nFlags & MK_SHIFT)){
		DeselectAll(lr);
	}
	vector<CBLE_IC*> vIC;
	vIC.clear();

	// Get region vector
	UINT RgnSize = m_vRegion.size();
	for(UINT idx = 0; idx < RgnSize; idx ++){
		if(!PointInRegion(point, m_vRegion[idx])) continue; // Check if clicked point is in region
		vIC = m_vRegion[idx].m_vIC; // Get vector ic in region
		break;
	}
	
	int ICsize = (int)vIC.size();
	bool isSelected = false;
	double nearestDistance = 10000.0;
	CBLE_IC *pNearestIC = NULL;
	for(int ICidx = ICsize - 1; ICidx >= 0; ICidx --){
		if((RegNo != 0) && (vIC[ICidx]->m_pRegIC->m_RegNo != RegNo)) continue; //allow select if only regno == 0 or IC's regno == selected regno.
		if(!vIC[ICidx]->Click(point, mode, false)) {
			double tmp = vIC[ICidx]->GetDistanceToICBorder(point);
			if ((tmp < vIC[ICidx]->m_pRegIC->m_SizeX * m_NeighborLimit) && (tmp < vIC[ICidx]->m_pRegIC->m_SizeY * m_NeighborLimit) && (tmp < nearestDistance)) {
				nearestDistance = tmp;
				pNearestIC = vIC[ICidx];
			}
			continue; //allow select if only user click on IC's region.
		}
		SelectIC(vIC[ICidx], lr); //select IC
		isSelected = true;
		break;
	}
	if (!isSelected && pNearestIC != NULL) {
		// #DDT-TODO Check nearest IC
		if(!pNearestIC->m_Deleted || (mode == DBLE_MODE_LOCATE_EDIT_SHOW_INVALID)) {
			this->SelectIC(pNearestIC , lr);
		}
	}
}

void CBLE_Substrate::FocusOnIC(R2Pos point, DBLE_MODE mode, int RegNo, int lr)
{
	vector<CBLE_IC*> vIC;
	vIC.clear();

	// Restore focus status of IC
	if (m_pFocusIC != NULL) {
		m_pFocusIC->m_BeingFocus = false;
		m_pFocusIC = NULL;
	}

	// Disable if some ICs got selected
	if ((lr == 0 &&m_vSelIC.size() != 0)
		|| (lr == DBLE_SUBINFO_TYPE_L && m_vSelICL.size() != 0)
		|| (lr == DBLE_SUBINFO_TYPE_R && m_vSelICR.size() != 0)){
		return;
	}

	// Get region vector
	UINT RgnSize = m_vRegion.size();
	for(UINT idx = 0; idx < RgnSize; idx ++){
		if(!PointInRegion(point, m_vRegion[idx])) continue; // Check if clicked point is in region
		vIC = m_vRegion[idx].m_vIC; // Get vector ic in region
		break;
	}
	
	int ICsize = (int)vIC.size();
	for(int ICidx = ICsize - 1; ICidx >= 0; ICidx --){
		if((RegNo != 0) && (vIC[ICidx]->m_pRegIC->m_RegNo != RegNo)) continue; //allow select if only regno == 0 or IC's regno == selected regno.

		if(!vIC[ICidx]->Click(point, mode, false)) continue; //allow select if only user click on IC's region.

		if ((lr == 0 && vIC[ICidx]->m_Selected)
			|| (lr == DBLE_SUBINFO_TYPE_L && vIC[ICidx]->m_SelectedL)
			|| (lr == DBLE_SUBINFO_TYPE_R && vIC[ICidx]->m_SelectedR)) {
			continue;
		}
		// Set focus IC
		m_pFocusIC = vIC[ICidx];
		m_pFocusIC->m_BeingFocus = true;
		return;
	}
	return;
}

/**
* This function will be used to select IC after release left-mouse.
* Only IC which has region intersect with select rect will be selected.
*/
void CBLE_Substrate::MouseUp(R2Pos p1, R2Pos p2, DBLE_MODE mode, int RegNo, int lr)
{
	int size = (int)m_vIC.size();
	for(int idx = size - 1; idx >= 0; idx --){
		if((RegNo != 0) && (m_vIC[idx]->m_pRegIC->m_RegNo != RegNo)) continue; //allow select if only regno == 0 or IC's regno == selected regno.
		if(!m_vIC[idx]->IntersectRect(p1, p2, mode, m_bSelectDeleted) || !m_vIC[idx]->m_Clickable /*|| m_vIC[idx]->m_OutsideSubStrate*/) continue; //allow select only if IC's region intersect with select rect
		SelectIC(m_vIC[idx], lr); //select IC
	}
}

/**
* This function will be used to draw substrate with IC on it.
*/
void CBLE_Substrate::Draw(CDC* pDC, CRect rect, DBLE_MODE mode, int RegNo, TBLE_StatusColor* stColor, int dir, int indexDisplay)
{
	// Lock until draw finish
	EnterCriticalSection(&syncObj);

	TRACE("[Edit]CBLE_ Substrate::Draw\n");
	// Store the view port
	CPoint viewPnt = pDC->GetViewportOrg();

	// Set the drawing rect
	CRect drwRect(CPoint(0, 0), rect.Size());
	drwRect.DeflateRect(DBLE_SUBS_START_DRAW_X, DBLE_SUBS_START_DRAW_Y);
	// Get the scale to convert from mm to pixel
	double minSize = min((double)drwRect.Width(), (double)drwRect.Height());
	double drawScale;
	int sizeX, sizeY;
	if(m_SizeX > m_SizeY){
		drawScale = minSize/m_SizeX;
		sizeX = minSize;
		sizeY = CBLE_Util::Round(double(sizeX)*m_SizeY/m_SizeX);
	}else{
		drawScale = minSize/m_SizeY;
		sizeY = minSize;
		sizeX = CBLE_Util::Round(double(sizeY)*m_SizeX/m_SizeY);
	}

	// Create pen
	CPen pen(PS_SOLID, 2, stColor->m_Shape/*DBLE_SUBS_LINE_CLR*/);
	CPen* pOldPen = pDC->SelectObject(&pen);
	// Create null brush
	CBrush* pOldBrush = pDC->GetCurrentBrush();
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	// Calculate the region of substrate
	CPoint center = drwRect.CenterPoint();
	CRect subRect(center, center);
	subRect.InflateRect(
		CBLE_Util::Round((double)sizeX/2.0),
		CBLE_Util::Round((double)sizeY/2.0));

	// Set new view port for device context
	pDC->SetViewportOrg(viewPnt + subRect.TopLeft());
	subRect.OffsetRect(- subRect.TopLeft());

	// Draw substrate background
	pDC->FillSolidRect(subRect, DBLE_SUBS_BKG_CLR);
	// Draw substrate
	if(m_Shape == DBLE_SHAPE_SQUARE){
		pDC->Rectangle(subRect);
	}else{ // Circle
		pDC->Ellipse(subRect);
	}
	// Restore brush and pen
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);

	// Create pen to draw center lines
	CPen pen1;
	// Draw center lines
	pen1.CreatePen(PS_DOT, 1, stColor->m_CenterLine/*DBLE_SUBS_CENTER_LINE*/);
	CPen* pOldPen1 = pDC->SelectObject(&pen1);

	pDC->MoveTo(subRect.CenterPoint());
	pDC->LineTo(CPoint(CPoint(subRect.CenterPoint().x, subRect.TopLeft().y)));

	pDC->MoveTo(subRect.CenterPoint());
	pDC->LineTo(CPoint(CPoint(subRect.CenterPoint().x, subRect.BottomRight().y)));

	pDC->MoveTo(subRect.CenterPoint());
	pDC->LineTo(CPoint(CPoint(subRect.TopLeft().x, subRect.CenterPoint().y )));

	pDC->MoveTo(subRect.CenterPoint());
	pDC->LineTo(CPoint(CPoint(subRect.BottomRight().x, subRect.CenterPoint().y)));

	// Restore pen & brush
	pDC->SelectObject(pOldPen1);

	// Draw all ICs
	pDC->SetViewportOrg(viewPnt + center);
	pDC->SetBkMode(TRANSPARENT);
	/*for(UINT idx = 0; idx < m_vIC.size(); idx ++){
		if((RegNo != 0) && (m_vIC[idx]->m_pRegIC->m_RegNo != RegNo)) continue; //only draw IC in case of RegNo is 0 or IC regno equal to selected regno
		m_vIC[idx]->Draw(pDC, drawScale, mode, stColor); //call draw function of IC
	}*/

	vector<CBLE_IC*> vIC;
	int maxX = 0;
	int maxY = 0;

	// Only find max IC in case of index display to not affect other function
	if ((indexDisplay != 0) && (RegNo != 0)) {
		maxX = FindMaxXIndex(RegNo, drawScale, mode);
		maxY = FindMaxYIndex(RegNo, drawScale, mode);
	}

	UINT RgnSize = m_vRegion.size();
	for(UINT RgnIdx = 0; RgnIdx < RgnSize; RgnIdx ++){
		vIC = m_vRegion[RgnIdx].m_vIC;
		int icSize = vIC.size();

		for(UINT idx = 0; idx < icSize; idx ++){
			int selected = vIC[idx]->m_Selected;
			if (dir == DBLE_SUBINFO_TYPE_L) {
				selected = vIC[idx]->m_SelectedL;
			} else if (dir == DBLE_SUBINFO_TYPE_R) {
				selected = vIC[idx]->m_SelectedR;
			}
			if (!m_bDisplayRealTime) {
				vIC[idx]->m_BeingFocus = false;
			}
			// Don't draw selected IC
			if (selected && indexDisplay == 0) {
				continue;
			}
			// Don't draw IC out side of client display
			if (!HasToDraw(vIC[idx], drawScale)) {
				continue;
			}
			// Draw all ICs
			if((RegNo != 0) && (vIC[idx]->m_pRegIC->m_RegNo != RegNo)) {
				vIC[idx]->m_Clickable = false;
				if (mode == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID) {
					vIC[idx]->Draw(pDC, drawScale, mode, stColor, true, vIC[idx]->m_Clickable, dir);
				}
			} else {
				if((vIC[idx]->m_pRegIC->m_RegNo == RegNo) && (indexDisplay != 0)) { // allow only if regno differ from 0
					// Find IC in the edges
					
					if(vIC[idx]->m_indexX == maxX) {
						vIC[idx]->DrawIndex(pDC, drawScale, true);
					}
					if (vIC[idx]->m_indexY == maxY) {
						vIC[idx]->DrawIndex(pDC, drawScale, false);
					}

				}
				vIC[idx]->m_Clickable = true;
				vIC[idx]->Draw(pDC, drawScale, mode, stColor, true, vIC[idx]->m_Clickable, dir);
			}
		}
		// Draw selected ICs
		vector<CBLE_IC*> vIC;
		if (dir == 0) {
			vIC = m_vSelIC;
		} else if (dir == DBLE_SUBINFO_TYPE_L) {
			vIC = m_vSelICL;
		} else if (dir == DBLE_SUBINFO_TYPE_R) {
			vIC = m_vSelICR;
		}
		for (idx = 0; idx < vIC.size(); idx++) {
			// Don't draw IC out side of client display
			if (!HasToDraw(vIC[idx], drawScale)) {
				continue;
			}
			vIC[idx]->Draw(pDC, drawScale, mode, stColor, true, true, dir);
		}
		
	}

	// Restore the view port
	pDC->SetViewportOrg(viewPnt);

	// Unlock when finish draw
	LeaveCriticalSection(&syncObj);
}

/**
* Clear all ICs on substrate
*/
void CBLE_Substrate::ResetData(bool hasToClearICs)
{
	// Lock until delete all ICs and finish create regions
	EnterCriticalSection(&syncObj);

	StopWatch	swResetData;swResetData.Start(TRUE);
	TRACE("[Edit]CBLE_ Substrate::Reset Data()Begin reset data\n");
	int icSize = m_vIC.size();
	if (hasToClearICs) {
		for(UINT idx = 0; idx < icSize; idx ++){
			delete m_vIC[idx];
		}
		m_vIC.clear();
		m_vSelIC.clear(); 
		// #DDT(20140624): Clear left&right selected data
		m_vSelICL.clear(); 
		m_vSelICR.clear(); 
	}
	
	// Reset region
	CreateRegions();
	TRACE("[Edit]CBLE_ Substrate::Reset Data()Finish: eslapsed time: %dm:%ds(%d)\n", swResetData.readMin(), swResetData.readSec(), swResetData.Read()/1000);
	// Unlock vector ICs
	LeaveCriticalSection(&syncObj);
	
}


/**
* Initialize array of ICs with RegNo on substrate.
* If IC got outside of substrate then delete it.
*/
void CBLE_Substrate::AddRegNo(TBLE_RegIC* pRegNo, TBLE_RegIC* pOldRegNo)
{
	// If array number of this regNo is same to the previous setting and substrate shape not be changed
	if (!pRegNo->m_Changed) {
		for(int idxY = 0; idxY < pRegNo->m_NumberY; idxY++){
			for(int idxX = 0; idxX < pRegNo->m_NumberX; idxX++){
				// Keep these ICs and set properties again
				m_vIC[IcIdxCreating]->SetIcProperties(pRegNo, idxX, idxY);

				// Check if IC is out of substrate
				if(!ICInSubstrate(m_vIC[IcIdxCreating])){
					m_vIC[IcIdxCreating]->Delete();
					m_vIC[IcIdxCreating]->m_OutsideSubStrate = true;
				} else {
					m_vIC[IcIdxCreating]->m_OutsideSubStrate = false;
				}	

				IcIdxCreating++;
			}
		}
	} else {
		// If substrate shape or array number of this regNo is changed, it has to delete old IC and create newone
		// #DDT(150805)
		int oldIdxX = 0;
		int oldIdxY = 0;
		if (m_vIC.size() > IcIdxCreating && pOldRegNo != NULL) {
			oldIdxX = pOldRegNo->m_NumberX;
			oldIdxY = pOldRegNo->m_NumberY;
		}
				
		for(int idxY = 0; idxY < pRegNo->m_NumberY || idxY < oldIdxY; idxY++){
			for(int idxX = 0; idxX < pRegNo->m_NumberX || idxX < oldIdxX; idxX++){
				if (idxX >= pRegNo->m_NumberX || idxY >= pRegNo->m_NumberY) {
					if ((idxX >= pRegNo->m_NumberX && idxY < oldIdxY)
						|| (idxY >= pRegNo->m_NumberY && idxX < oldIdxX)
						|| (idxX >= pRegNo->m_NumberX && idxY >= pRegNo->m_NumberY)) {
						// Delete redundant IC
						delete m_vIC[IcIdxCreating];
						m_vIC.erase(m_vIC.begin() + IcIdxCreating);
						//IcIdxCreating--;
					} else {
						// Do nothing
					}
				} else 
				// In case of old index is in range of new index
				if (idxX < oldIdxX && idxY < oldIdxY) {
					
						CBLE_IC* pIC = m_vIC[IcIdxCreating];
						// Keep these ICs and set properties again
						m_vIC[IcIdxCreating]->SetIcProperties(pRegNo, idxX, idxY);
						// Check if IC is out of substrate
						if(!ICInSubstrate(pIC)){
							pIC->Delete();
							pIC->m_OutsideSubStrate = true;
						} else {
							pIC->m_OutsideSubStrate = false;
						}
						IcIdxCreating++;
					
				} else {
					CBLE_IC* pIC = new CBLE_IC(pRegNo, idxX, idxY);
					if (IcIdxCreating < m_vIC.size()) {
						// In case: new array number > old array number and this regNo is not the last regNo
						// has to insert newone into middle of vector
						m_vIC.insert(m_vIC.begin() + IcIdxCreating, pIC);
					} else {
						// In case: new array number > old array number and this regNo is the last regNo
						// has to add new IC at the end of vector
						m_vIC.push_back(pIC);
					}
					// Check if IC is out of substrate
					if(!ICInSubstrate(pIC)){
						pIC->Delete();
						pIC->m_OutsideSubStrate = true;
					} else {
						pIC->m_OutsideSubStrate = false;
					}
					IcIdxCreating++;
				}
				
				
			}
		}
	}
}

/**
* After creating all new ICs, erase remain old ICs that not need
* This method erase all ICs in vector, from Idx to end if exist
*/
void CBLE_Substrate::EraseNotNeedOldIC() {
	int idx = IcIdxCreating;
	int vIcSize = m_vIC.size();
	while (vIcSize > idx) {
		delete m_vIC[idx];
		idx++;

	}
	if (idx == IcIdxCreating) {
		// Do nothing
	} else {
		idx--;
		if (idx < vIcSize && idx >= IcIdxCreating) {
			m_vIC.erase(m_vIC.begin() + IcIdxCreating, m_vIC.begin() + idx);
			m_vIC.erase(m_vIC.begin() + IcIdxCreating);
		}
	}
	IcIdxCreating = 0;
}

/**
* Set shape for substrate, check if IC is in substrate or
* not whenever user change shape of substrate
*/
void CBLE_Substrate::SetShape(int shapeID, DBLE_SUBSTRATE_SHAPE shape, int sizeX, int sizeY)
{
	m_ShapeID = shapeID;
	m_Shape = shape;
	m_SizeX = sizeX;
	m_SizeY = sizeY;
	// Create region
	CreateRegions();
	// Delete ICs out of substrate
	UINT size = m_vIC.size();
	for(UINT idx = 0; idx < size; idx ++){
// #MH130926-01: Not need to change status of IC if change shape
	//	m_vIC[idx]->m_Deleted = false;
		m_vIC[idx]->m_OutsideSubStrate = false;
		if(ICInSubstrate(m_vIC[idx])) {
			continue;
		}
		m_vIC[idx]->Delete();
		m_vIC[idx]->m_OutsideSubStrate = true;
	}
}


CSize CBLE_Substrate::GetBorderSize()
{
	return CSize(DBLE_SUBS_START_DRAW_X, DBLE_SUBS_START_DRAW_Y);
}


void CBLE_Substrate::CreateRegions()
{
	StopWatch	swCreateRegions;swCreateRegions.Start(TRUE);
	TRACE("[Edit]CBLE_ Substrate::Create Regions()Begin create regions\n");
	m_vRegion.clear();
	double startX = - DBLE_SUBS_SCALE_REGION*m_SizeX/2.0;
	double startY = - DBLE_SUBS_SCALE_REGION*m_SizeY/2.0;
	double sizeX = (DBLE_SUBS_SCALE_REGION*m_SizeX)/double(DBLE_SUBS_GRID_X);
	double sizeY = (DBLE_SUBS_SCALE_REGION*m_SizeY)/double(DBLE_SUBS_GRID_Y);

	for(int idxX = 0; idxX < DBLE_SUBS_GRID_X; idxX ++){
		startY = - m_SizeY/2.0;
		for(int idxY = 0; idxY < DBLE_SUBS_GRID_Y; idxY ++){
			TBLE_IC_Region region;
			region.m_Pos1.x = startX;
			region.m_Pos1.y = startY;
			region.m_Pos2.x = startX + sizeX;
			region.m_Pos2.y = startY + sizeY;
			region.m_vIC.clear();
			m_vRegion.push_back(region);
			startY += sizeY;
		}	
		startX +=  sizeX;
	}
	TRACE("[Edit]CBLE_ Substrate::Create Regions()Finish: eslapsed time: %dm:%ds(%d)\n", swCreateRegions.readMin(), swCreateRegions.readSec(), swCreateRegions.Read()/1000);
}

bool CBLE_Substrate::ICInRegion(vector<R2Pos> vICPnt, TBLE_IC_Region region)
{
	// Check if any point of IC got inside of region
	int size = vICPnt.size();
	for(UINT idx = 0; idx < size; idx ++){
		if(PointInRegion(vICPnt[idx], region)) return true;
	}
	return false;
}

bool CBLE_Substrate::PerformanceChecking(bool isSaving)
{
	int validIC = 0;
	int size = m_vIC.size();
	if (!isSaving) {
		for (int id = 0; id < size; id ++) {
			if (!m_vIC[id]->m_Deleted) {
				validIC++;
			}
		}
	} else {
		validIC = size;
	}
	if (validIC == 0) {
		return false;
	}

	if (theApp.m_Speed / validIC < DBLE_SPEED_IC_RATIO) {
		return true;
	}

	return false;
}

bool CBLE_Substrate::PointInRegion(R2Pos point, TBLE_IC_Region region)
{
	if(point.x < region.m_Pos1.x) return false;
	if(point.x > region.m_Pos2.x) return false;
	if(point.y < region.m_Pos1.y) return false;
	if(point.y > region.m_Pos2.y) return false;
	return true;
}


void CBLE_Substrate::CheckRegionSelectedICs()
{
	// Vector to store 4 points of IC
	vector<R2Pos> vR2Pnt;

	UINT ICsize = m_vSelIC.size();		// #DDT(20140624): Don't need to check left&right selected data here
	UINT RgnSize = m_vRegion.size();

	CBLE_IC* pIC = NULL;
	for(UINT ICidx = 0; ICidx < ICsize; ICidx ++){
		pIC = m_vSelIC[ICidx];
		pIC->GetICPoint(vR2Pnt);
		for(UINT idx = 0; idx < RgnSize; idx ++){
			ICInRegion(vR2Pnt, m_vRegion[idx]) ? m_vRegion[idx].PushIC(pIC) : m_vRegion[idx].PopIC(pIC);
		}
	}
}


void CBLE_Substrate::SetRegionAllICs()
{
	m_vRegion[0].m_vIC = m_vIC;
#if 0 //Currently, this function take a lot of time. So we disable to reduce processing time.
	StopWatch	swSetRegion;swSetRegion.Start(TRUE);		// ���v���ԑ���
	// Vector to store 4 points of IC
	vector<R2Pos> vR2Pnt;

	UINT ICsize = m_vIC.size();
	UINT RgnSize = m_vRegion.size();
	CBLE_IC* pIC = NULL;
	//for(UINT idx = 0; idx < RgnSize; idx ++){
	//		m_vRegion[idx].m_vIC.clear();
	//		//m_vRegion[idx]
	//}
	TRACE("[Edit]CBLE_ Substrate::Set RegionAllICs()IcCount=%dpcs\n",ICsize);
	for(UINT ICidx = 0; ICidx < ICsize; ICidx ++){
		pIC = m_vIC[ICidx];
		pIC->GetICPoint(vR2Pnt);
		for(UINT idx = 0; idx < RgnSize; idx ++){
			if(!ICInRegion(vR2Pnt, m_vRegion[idx])) continue;
			m_vRegion[idx].PushIC(pIC);
		}
	}
	TRACE("[Edit]CBLE_ Substrate::Set RegionAllICs()time=%dm:%ds(%d)\n",swSetRegion.readMin(),swSetRegion.readSec(),swSetRegion.Read()/1000);
#endif
}

void CBLE_Substrate::RestoreAll(int regNo)
{
	int size = m_vIC.size();
	for(UINT idx = 0; idx < size; idx ++) {
		if (m_vIC[idx]->m_pRegIC->m_RegNo == regNo || regNo == 0) {
			if (m_vIC[idx]->m_Deleted && !m_vIC[idx]->m_OutsideSubStrate) {
				m_vIC[idx]->Restore();
			}
		}
	}
}

// Clear offset for all ICs
void CBLE_Substrate::ClearAllOffset(int regNo)
{
	int size = m_vIC.size();
	for (UINT idx = 0; idx < size; idx ++) {
		if (regNo == 0 || m_vIC[idx]->m_pRegIC->m_RegNo == regNo) {
			m_vIC[idx]->m_OffsetX = 0;
			m_vIC[idx]->m_OffsetY = 0;
			m_vIC[idx]->m_OffsetT = 0;

			// Update target position
			m_vIC[idx]->m_TargetBgPosX = m_vIC[idx]->m_BgPosX + m_vIC[idx]->m_OffsetX;
			m_vIC[idx]->m_TargetBgPosY = m_vIC[idx]->m_BgPosY + m_vIC[idx]->m_OffsetY;
			m_vIC[idx]->m_TargetTheta = m_vIC[idx]->m_pRegIC->m_Angle + m_vIC[idx]->m_OffsetT;
		}
	}
}

// Clear offset for all selected ICs
void CBLE_Substrate::ClearSelICOffset()
{
	int selSize = m_vSelIC.size(); // #DDT(20140624): Don't need to check left&right selected data here
	for (UINT idx = 0; idx < selSize; idx ++) {
		m_vSelIC[idx]->m_OffsetX = m_vSelIC[idx]->m_TargetBgPosX - m_vSelIC[idx]->m_BgPosX;
		m_vSelIC[idx]->m_OffsetY = m_vSelIC[idx]->m_TargetBgPosY - m_vSelIC[idx]->m_BgPosY;
		m_vSelIC[idx]->m_OffsetT = m_vSelIC[idx]->m_TargetTheta - m_vSelIC[idx]->m_pRegIC->m_Angle;
	}
}

// Find maximum index X of IC in substrate
int CBLE_Substrate::FindMaxXIndex(int regNo, double scale, DBLE_MODE mode)
{
	int maxX = 0;
	int size = m_vIC.size();
	for (UINT idx = 0; idx < size; idx ++) {
		if ((mode == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID) && (m_vIC[idx]->m_Deleted)) {
			continue;
		}

		if ((ICInSubstrate(m_vIC[idx])) && (m_vIC[idx]->m_pRegIC->m_RegNo == regNo)) {
			if (m_vIC[idx]->GetPosX() * scale < -m_DisplayCenter.x + m_DisplayRect.Width() - m_vIC[idx]->m_pRegIC->m_SizeX * scale) {
				if (m_vIC[idx]->m_indexX >= maxX) { 
					maxX = m_vIC[idx]->m_indexX;
				}
			}
		}
	}
	return maxX;
}

// Find maximum index Y of IC in substrate
int CBLE_Substrate::FindMaxYIndex(int regNo, double scale, DBLE_MODE mode)
{
	int maxY = 0;
	int size = m_vIC.size();
	for (UINT idx = 0; idx < size; idx ++) {
		if ((mode == DBLE_MODE_LOCATE_EDIT_HIDE_INVALID) && (m_vIC[idx]->m_Deleted)) {
			continue;
		}

		if ((ICInSubstrate(m_vIC[idx])) && (m_vIC[idx]->m_pRegIC->m_RegNo == regNo)) {
			if (-m_vIC[idx]->GetPosY() * scale < -m_DisplayCenter.y + m_DisplayRect.Height() - m_vIC[idx]->m_pRegIC->m_SizeY * scale) {
				if (m_vIC[idx]->m_indexY >= maxY) { 
					maxY = m_vIC[idx]->m_indexY;
				}
			}
		}
	}
	return maxY;
}

// Check to see if any select ICs got overlapped
bool CBLE_Substrate::CheckSelIC()
{
	bool flag = false;
	int selSize = m_vSelIC.size();	// #DDT(20140624): Don't need to check left&right selected data here
	//Check if no ICs got selected
	if ( selSize <= 0) {
		return true;
	}

	for (UINT idx = 0; idx < selSize; idx ++) {
		if (m_vSelIC[idx]->m_Overlapped) {
			flag = true;
			break; //stop immediately if found overlapIC
		}
	}
	return flag;
}

// Serialize function
void CBLE_Substrate::Serialize(CArchive &archive, vector<TBLE_RegIC>* vRegIC)
{
	CObject::Serialize(archive);

	int size = m_vIC.size();
	int regICSize = vRegIC->size();
	int shape = m_Shape;
	if (archive.IsStoring()) {
		archive << size << shape << m_SizeX << m_SizeY << m_ShapeID;
		for (int idxReg = 0; idxReg < regICSize; idxReg ++) {
			for (int idx = 0; idx < size; idx ++) {
				if (m_vIC[idx]->m_pRegIC->m_RegNo == vRegIC->at(idxReg).m_RegNo) {
					m_vIC[idx]->Serialize(archive);
				}
			}
		}
	} else {
		archive >> size >> shape >> m_SizeX >> m_SizeY >> m_ShapeID;
		if (shape == 0) {
			m_Shape = DBLE_SHAPE_SQUARE;
		} else {
			m_Shape = DBLE_SHAPE_ROUND;
		}
		CreateRegions();
		for (int idxReg = 0; idxReg < regICSize; idxReg ++) {
			TBLE_RegIC* pRegNo = &(*vRegIC)[idxReg];
			for(int idxY = 0; idxY < pRegNo->m_NumberY; idxY++){
				for(int idxX = 0; idxX < pRegNo->m_NumberX; idxX++){
					CBLE_IC* pIC = new CBLE_IC(pRegNo, idxX, idxY);
					pIC->Serialize(archive);
					m_vIC.push_back(pIC);
				}
			}
		}
	}
	SetRegionAllICs();
}

bool CBLE_Substrate::HasToDraw(CBLE_IC *ic, double scale)
{

	// Offset
	CPoint offset = m_DisplayCenter - m_RealTopLeft;
	double posX = ic->GetPosX() * scale + offset.x;
	double posY = -ic->GetPosY() * scale + offset.y;
	double sizeX = ic->m_pRegIC->m_SizeX * scale;
	double sizeY = ic->m_pRegIC->m_SizeY * scale;
	if ((posX >= m_RealTopLeft.x - sizeX)
		&& (posX <= m_RealTopLeft.x + m_DisplayRect.Width() + sizeX)
		&& (posY >= m_RealTopLeft.y - sizeY)
		&& (posY <= m_RealTopLeft.y + m_DisplayRect.Height() + sizeY)
	) {

		return true;
	}
	return false;

}

void CBLE_Substrate::SetNeighborLimit(int limit)
{
	m_NeighborLimit = limit;
}

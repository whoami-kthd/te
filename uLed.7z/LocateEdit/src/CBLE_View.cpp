// CBLE_View.cpp : implementation of the CBLE_View class
//

#include "stdafx.h"
#include "..\\BLE.h"

#include "CBLE_Doc.h"
#include "CBLE_View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBLE_View

IMPLEMENT_DYNCREATE(CBLE_View, CView)

BEGIN_MESSAGE_MAP(CBLE_View, CView)
	//{{AFX_MSG_MAP(CBLE_View)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBLE_View construction/destruction

CBLE_View::CBLE_View()
{
	// TODO: add construction code here

}

CBLE_View::~CBLE_View()
{
}

BOOL CBLE_View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_View drawing

void CBLE_View::OnDraw(CDC* pDC)
{
	CBLE_Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_View printing

BOOL CBLE_View::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CBLE_View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CBLE_View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CBLE_View diagnostics

#ifdef _DEBUG
void CBLE_View::AssertValid() const
{
	CView::AssertValid();
}

void CBLE_View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CBLE_Doc* CBLE_View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBLE_Doc)));
	return (CBLE_Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBLE_View message handlers

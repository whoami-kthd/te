// CMVDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMVDlg.h"
#include "CMV_Util.h"
#include "CMV_DEF.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define CMV_DLG_SIZEX						765
#define CMV_DLG_SIZEY						740
#define MAGIN_RIGHT							185
#define MAGIN_TOP_BOTTOM					160


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMVDlg dialog

IMPLEMENT_DYNAMIC(CCMVDlg, CDialog);

CCMVDlg::CCMVDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCMVDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCMVDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon			= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pDoc			= NULL;
	m_bInit			= false;
}

CCMVDlg::~CCMVDlg()
{
	// If there is an automation proxy for this dialog, set
	//  its back pointer to this dialog to NULL, so it knows
	//  the dialog has been deleted.
}

void CCMVDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCMVDlg)
	DDX_Control(pDX, IDC_CHIP_LIST, m_ChipListCtrl);
	DDX_Control(pDX, IDC_LIST_INDEX_PICKUP, m_ListIndexCtrl);
	//}}AFX_DATA_MAP
}
static UINT WMV_CTRL = RegisterWindowMessage(STR_WMV_CTRL);
BEGIN_MESSAGE_MAP(CCMVDlg, CDialog)
	//{{AFX_MSG_MAP(CCMVDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BTN_LOAD_MAP, OnBtnLoadMap)
	ON_BN_CLICKED(IDC_BTN_ZOOM_IN, OnBtnZoomIn)
	ON_BN_CLICKED(IDC_BTN_ZOOM_OUT, OnBtnZoomOut)
	ON_NOTIFY(NM_CLICK, IDC_LIST_INDEX_PICKUP, OnClickListIndexPickup)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_CHIP_LIST, OnChipListCustomDraw)
	ON_NOTIFY(NM_CLICK, IDC_CHIP_LIST, OnClickChipList)
	ON_CBN_SELCHANGE(IDC_ZOOM, OnSelchangeZoom)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BTN_PICK, OnBtnPick)
	ON_BN_CLICKED(IDC_BTN_POS, OnBtnPos)
	ON_BN_CLICKED(IDC_BTN_REF, OnBtnRef)
	ON_BN_CLICKED(IDC_BTN_BG, OnBtnBg)
	ON_BN_CLICKED(IDC_BTN_JUMP, OnBtnJump)
	ON_REGISTERED_MESSAGE(WMV_CTRL, OnMapCtrl)
	ON_WM_GETMINMAXINFO()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMVDlg message handlers

BOOL CCMVDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_IsLoadedMap = false;

	// Make Context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = m_pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;

	m_pDoc = new CMV_Doc();
	// Create Map view layout
	CRect rect;
	GetDlgItem(IDC_MAP_DISP_LAYOUT)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_MapLayout = new CMV_Map_View();
	m_MapLayout->SetDocument(m_pDoc);
	m_MapLayout->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_MAP_DISP_LAYOUT, pContext);


/*	// Create Tool/LED Info view layout
	GetDlgItem(IDC_TOOL_LED_INFO)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_pToolDisp = new CMV_ToolDispInfo();
	m_pToolDisp->SetDocument(m_pDoc);
	m_pToolDisp->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_TOOL_LED_INFO, pContext);
*/

	// Create Map Jump view layout
	GetDlgItem(IDC_MAP_JUMP)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_pMapInfo = new CMV_MapInfo();
	m_pMapInfo->SetDocument(m_pDoc);
	m_pMapInfo->Create(NULL, NULL, 
			WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, this, IDC_MAP_JUMP, pContext);

	delete pContext;

	/* Init map view */
	char buf[BUFSIZ];
	GetModuleFileName(NULL, buf, BUFSIZ - 1);	
	m_pDoc->m_IniFile = buf;
	CString AppName(AfxGetAppName());
	AppName += ".exe";
	m_pDoc->m_IniFile.Replace(AppName, "");
	m_pDoc->m_LoadFile = m_pDoc->m_IniFile + STR_MD_LOAD;
	m_pDoc->m_IniFile += STR_MV ".ini";
	
	m_pDoc->m_CurX = 0;		// Current position X
	m_pDoc->m_CurY = 0;		// Current position Y

	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "DispMode", TRUE, m_pDoc->m_DispMode, 0);
	m_pDoc->m_nFormat = DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX | DT_CENTER | DT_NOCLIP;

	m_pDoc->myFont.CreateFont(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));
	
	m_pDoc->m_Setting	= (_T("Setting"));
	m_pDoc->m_LoadFile	= (_T(""));
	m_pDoc->m_DispMode	= (0);
	m_pDoc->m_FNLOC		= (_T(""));
	m_pDoc->m_MID		= (_T(""));


	/* Init colors for each category (S) */
	m_pDoc->s1 = "G_CategoryColor";
	for( int i = 0 ; i < 256 ; i++){
		sprintf(m_pDoc->ch, "%03d", i);
		m_pDoc->s2 = m_pDoc->ch;
		m_pDoc->s3 = m_pDoc->s1 + m_pDoc->s2;
		GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, (LPCTSTR)m_pDoc->s3, TRUE, m_pDoc->colors, 3, 255);
		m_pDoc->m_gCategoryColor[i] = RGB(m_pDoc->colors[0], m_pDoc->colors[1], m_pDoc->colors[2]);
	}
	/* Init colors for each category (E) */

	/* Init variables */
	m_pDoc->m_IsLoadedMap = false;
	
	m_LoadMapBtn = (CButton*)GetDlgItem(IDC_BTN_LOAD_MAP);
	m_LoadMapBtn->EnableWindow(TRUE);
	

	/* Initialize Index pickup list (S) */
	// Initial extended style for the list control on this dialog
	DWORD dwStyle = m_ListIndexCtrl.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP;
	m_ListIndexCtrl.SetExtendedStyle(dwStyle);

	CRect rectIndexList;
	m_ListIndexCtrl.GetClientRect(rectIndexList);
	
	m_ListIndexCtrl.InsertColumn(0, _T("Step"), LVCFMT_LEFT, rectIndexList.Width()/3);
	m_ListIndexCtrl.InsertColumn(1, _T("Index"), LVCFMT_LEFT, rectIndexList.Width()/3*2);
	/* Initialize Index pickup list (E) */


	/* Initialize Chip list (S) */
	// Initial extended style for the list control on this dialog
	dwStyle = m_ChipListCtrl.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP;
	m_ChipListCtrl.SetExtendedStyle(dwStyle);

	CRect rectChipList;
	m_ChipListCtrl.GetClientRect(rectChipList);
	
	m_ChipListCtrl.InsertColumn(0, _T(" Cat "), LVCFMT_LEFT, rectChipList.Width()/3 - 5);
	m_ChipListCtrl.InsertColumn(1, _T(" "), LVCFMT_LEFT, rectChipList.Width()/3);
	m_ChipListCtrl.InsertColumn(2, _T("Dies # "), LVCFMT_LEFT, rectChipList.Width()/3+5);
	/* Initialize Chip list (E) */
	
	m_pDoc->m_IndexSelect = -1;
	m_pDoc->m_IsDispIndex = FALSE;
	m_pDoc->m_IsDispJumpInTab = FALSE;			// For display jump index in Jump table of CMV_MapJump class
	m_pDoc->m_IsDispJumpInMap = FALSE;			// For display bound of jump index in map file of CMV_Map_View class


	/* Initialize CComboBox*/
	pZoom = ((CComboBox*)GetDlgItem(IDC_ZOOM));

	/* Add content for zoom combobox (S) */
	for(int idx = 1; idx < 7; idx ++){
		sizeArray[0] = 0;
		sizeArray[idx] = idx;
		CString str;
		str.Format(_T("      x%d"), sizeArray[idx]);
		pZoom->AddString(str);
	}

	// Initial zoom
	pZoom->SetCurSel(0);
	/* Add content for zoom combobox (E) */

	/* Initialize color setting */
	m_pDoc->m_BackColor = ::GetSysColor(COLOR_BTNFACE);
	m_pDoc->m_RefColor  = ::GetSysColor(COLOR_BTNFACE);
	m_pDoc->m_PosColor  = ::GetSysColor(COLOR_BTNFACE);
	m_pDoc->m_PickColor = ::GetSysColor(COLOR_BTNFACE);
	m_bInit				= true;

	/* Read tool information (S) */
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "ToolSizeX", TRUE, m_pDoc->m_dispToolIndexX, 0);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "ToolSizeY", TRUE, m_pDoc->m_dispToolIndexY, 0);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "ToolPitchX", TRUE, m_pDoc->m_dispToolPitchX, 0);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "ToolPitchY", TRUE, m_pDoc->m_dispToolPitchY, 0);
	
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "LEDSizeX", TRUE, m_pDoc->m_dispLEDPitchX, 0);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "LEDSizeY", TRUE, m_pDoc->m_dispLEDPitchY, 0);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "LEDPitchX", TRUE, m_pDoc->m_dispLEDSizeX, 0);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "LEDPitchY", TRUE, m_pDoc->m_dispLEDSizeY, 0);
	/* Read tool information (E) */

	/* Display color of dies # (S) */
	int colorsSetting[3];
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "G_BackColor", TRUE, colorsSetting, 3, 64);
	m_pDoc->m_BackColor = RGB(colorsSetting[0], colorsSetting[1], colorsSetting[2]);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "G_RefColor", TRUE, colorsSetting, 3, 255);
	m_pDoc->m_RefColor = RGB(colorsSetting[0], colorsSetting[1], colorsSetting[2]);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "G_CurColor", TRUE, colorsSetting, 3, 255);
	m_pDoc->m_PosColor = RGB(colorsSetting[0], colorsSetting[1], colorsSetting[2]);
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "G_PickColor", TRUE, colorsSetting, 3, 255);
	m_pDoc->m_PickColor = RGB(colorsSetting[0], colorsSetting[1], colorsSetting[2]);
	/* Display color of dies # (E) */

	/* Get position window */
	int *m_windowSizeTemp = new int[4];
	GWPPfileData(m_pDoc->m_IniFile, m_pDoc->m_Setting, "Position_Window", TRUE, m_windowSizeTemp, 4, 64);
	m_windowSize[0] =  *m_windowSizeTemp;			//left
	m_windowSize[1] =  *(m_windowSizeTemp + 1);		//top
	m_windowSize[2] =  *(m_windowSizeTemp + 2);		//right
	m_windowSize[3] =  *(m_windowSizeTemp + 3);     //bottom

	SetWindowPos(&wndTopMost, m_windowSize[0], m_windowSize[1], CMV_DLG_SIZEX, CMV_DLG_SIZEY,  SWP_SHOWWINDOW);

	delete m_windowSizeTemp;
	return TRUE;
}


void CCMVDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCMVDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	// Center icon in client rectangle
	int cxIcon = GetSystemMetrics(SM_CXICON);
	int cyIcon = GetSystemMetrics(SM_CYICON);
	CRect rect;
	GetClientRect(&rect);
	int x = (rect.Width() - cxIcon + 1) / 2;
	int y = (rect.Height() - cyIcon + 1) / 2;
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCMVDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CCMVDlg::GetCMV(CCMVApp* pCMVInfo){
	pCMV = pCMVInfo;
}


void CCMVDlg::OnBtnLoadMap() 
{
	// Initialize Input map
	m_pInputMap.SetDocument(m_pDoc);
	m_pInputMap.SetInfoMapDisp(this);
	m_pInputMap.DoModal();
}


void CCMVDlg::LoadMapFile(CString pathMapFile) {
	
	m_pInputMap.EndDialog(0);		// Close Input map file dialog
	if (m_pDoc->MapD.DataRW(TRUE, pathMapFile)) {

		m_pDoc->m_IsLoadedMap = true;
		m_LoadMapBtn->EnableWindow(FALSE);

		m_pDoc->m_CoulmMax = m_pDoc->MapD.COLCT;
		m_pDoc->m_LineMax  = m_pDoc->MapD.ROWCT;
		
		int idx = m_pDoc->MapD.FNLOC / 90;
		if (0 > idx || 3 < idx || !(m_pDoc->m_DispMode & m_pDoc->DispFNLOC )) {
			idx = 4;
		}
		char *dirs[][5] = {
			{ "�a", "�k", "�s", "�q", "  " },
			{ "��", "��", "��", "�E", "  " },
		};

		if (m_pDoc->m_DispMode & m_pDoc->DispMID) {
			m_pDoc->m_MID.Format(" MID=%s", m_pDoc->MapD.MID);
		} else {
			m_pDoc->m_MID = "";
		}

		/* Put mapfile to str variable (S) */
		for (int y = 0; y < m_pDoc->m_LineMax; y++) {
			m_pDoc->str += m_pDoc->MapD.BINLT.Mid(m_pDoc->m_CoulmMax * y, m_pDoc->m_CoulmMax) + "\n";
		}
		/* Put mapfile to str variable (E) */

		/* Initialize LEDArrayInfo (S) */
		m_pDoc->LEDArrayInfo = new LEDInfo* [m_pDoc->m_LineMax * sizeof(LEDInfo *)];
		for(int i = 0; i < m_pDoc->m_LineMax; i++) {
			m_pDoc->LEDArrayInfo[i] = new LEDInfo [m_pDoc->m_CoulmMax * sizeof(LEDInfo)];
		}

		/* Create axisRects for display axis (S) */
		m_pDoc->xAxisRectArray = new CRect [m_pDoc->m_CoulmMax * sizeof(CRect)];
		m_pDoc->yAxisRectArray = new CRect [m_pDoc->m_LineMax * sizeof(CRect)];

		SetDlgItemText(IDC_EDIT_MAP_NAME, (m_pDoc->MapD.MID));
		SetDlgItemText(IDC_EDIT_MAP_BCEQU, (m_pDoc->MapD.BCEQU));

		/* Initialize map view */
		m_MapLayout->InitMapView();

		OnUpdateIndexPickupList();
		OnUpdateChipList();

		m_MapLayout->SetBackSolidBrush(m_pDoc->m_BackColor);

	}
}

void CCMVDlg::OnBtnZoomIn() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		if (m_pDoc->m_Zoom < 7) {
			m_pDoc->m_Zoom += 1;
			pZoom->SetCurSel(m_pDoc->m_Zoom - 1);
			m_MapLayout->OnUpdateMapView();
		}
	}
}

void CCMVDlg::OnBtnZoomOut() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		if (m_pDoc->m_Zoom > 1 ) {
			m_pDoc->m_Zoom -= 1;
			pZoom->SetCurSel(m_pDoc->m_Zoom - 1);
			m_MapLayout->OnUpdateMapView();
		}
	}
	
}


void CCMVDlg::AddIndexPickup(CListCtrl &ctrl, int row, int col, const char *str)
{
	 LVITEM lv;
    lv.iItem = row;
    lv.iSubItem = col;
    lv.pszText = (LPSTR) str;
    lv.mask = LVIF_TEXT;
    if(col == 0)
        ctrl.InsertItem(&lv);
    else
        ctrl.SetItem(&lv); 
}


void CCMVDlg::OnUpdateIndexPickupList()
{
	int i, j;
	int index = 1;

	for(i = m_pDoc->m_CurY ; i < m_pDoc->m_LineMax- m_pDoc->m_ratioToolLEDX ; i++){
	    for(j = m_pDoc->m_CurX ; j < m_pDoc->m_CoulmMax-m_pDoc->m_ratioToolLEDY ; j++){
	
			// Find good bin in map
			if(m_pDoc->LEDArrayInfo[i][j].isGoodBin == true && m_pDoc->LEDArrayInfo[i][j].isInGroup == false) 
			{
				if( (m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j].isGoodBin == true) &&
					(m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j].isInGroup == false) &&
					(m_pDoc->LEDArrayInfo[i][j+m_pDoc->m_ratioToolLEDY].isGoodBin == true) &&
					(m_pDoc->LEDArrayInfo[i][j+m_pDoc->m_ratioToolLEDY].isInGroup == false) &&
					(m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j+m_pDoc->m_ratioToolLEDY].isGoodBin == true) &&
					(m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j+m_pDoc->m_ratioToolLEDY].isInGroup == false) )
					{
						m_pDoc->LEDArrayInfo[i][j].isInGroup = true;
						m_pDoc->LEDArrayInfo[i][j].index = index;
						
						m_pDoc->LEDArrayInfo[i][j+m_pDoc->m_ratioToolLEDY].isInGroup = true;
						m_pDoc->LEDArrayInfo[i][j+m_pDoc->m_ratioToolLEDY].index = index;
						
						m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j].isInGroup = true;
						m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j].index = index;
						
						m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j+m_pDoc->m_ratioToolLEDY].isInGroup = true;
						m_pDoc->LEDArrayInfo[i+m_pDoc->m_ratioToolLEDX][j+m_pDoc->m_ratioToolLEDY].index = index;
						
						
						/* Update index pickup list (S) */
						CString stepStr, indexStr, xCell, yCell;
						stepStr.Format(_T("   %d "), index);
						xCell.Format(_T("   %d"), j);
						yCell.Format(_T("%d  "), i);

						// Get coordinate of first LED in Index
						m_pDoc->m_indexFirstX[index] = j;
						m_pDoc->m_indexFirstY[index] = i;

						indexStr = xCell + _T(", ") + yCell;

						AddIndexPickup(m_ListIndexCtrl, index-1, 0, stepStr );
						AddIndexPickup(m_ListIndexCtrl, index-1, 1, indexStr);
						/* Update index pickup list (E) */

						index++;
					}
			}
		}
	}
}


void CCMVDlg::OnClickListIndexPickup(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	m_pDoc->m_IndexSelect = pNMListView->iItem + 1;
	
	m_pDoc->m_IsDispIndex = TRUE;
	m_pDoc->m_IsDispJumpInMap = FALSE;
	
	*pResult = 0;
	Invalidate(TRUE);
	m_MapLayout->UpdateWindow();
}


void CCMVDlg::OnUpdateChipList()
{
	int i, j, ii, jj;
	int index = 0;

	/* Initialize ChipNum (S) */
	for(i = 0 ; i < m_pDoc->m_LineMax ; i++){
		for(j = 0 ; j < m_pDoc->m_CoulmMax ; j++){
			m_pDoc->ChipNum[i][j] = 0;
		}
	}
	/* Initialize ChipNum (E) */
	
	/* Count number of each LED.ch (S) */
	for(i = 0; i < m_pDoc->m_LineMax; i++){
		for(j = 0; j < m_pDoc->m_CoulmMax; j++){

			for (ii = 0; ii<=i; ii++) {
				for (jj = 0; jj<=j || (ii<i && jj<m_pDoc->m_CoulmMax); jj++) {
					if( (m_pDoc->LEDArrayInfo[i][j].ch == m_pDoc->LEDArrayInfo[ii][jj].ch) || (i == ii && j == jj) )
					{
						m_pDoc->ChipNum[ii][jj]++;
						ii = m_pDoc->m_LineMax;
						jj = m_pDoc->m_CoulmMax;
					}
				}
			}
		}
	}
	/* Count number of each LED.ch (E) */

	for(i = 0; i < m_pDoc->m_LineMax; i++){
	    for(j = 0; j < m_pDoc->m_CoulmMax; j++){
			if(m_pDoc->ChipNum[i][j] > 0) {
				/* Update chip list (S) */				
				CString catStr(m_pDoc->LEDArrayInfo[i][j].ch), diesStr;
				//catStr = _T(" ") + catStr + _T(" ");
				diesStr.Format(_T("   %d  "), m_pDoc->ChipNum[i][j]);
				
				AddIndexPickup(m_ChipListCtrl, index, 0, catStr );
				AddIndexPickup(m_ChipListCtrl, index, 2, diesStr);
				/* Update chip list (E) */
				index++;
			}
		}
	}
}

void CCMVDlg::OnChipListCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
    LPNMLVCUSTOMDRAW lplvcd;

    lplvcd = (LPNMLVCUSTOMDRAW)pNMHDR;
    if (lplvcd->nmcd.dwDrawStage == CDDS_PREPAINT){
        *pResult = CDRF_NOTIFYITEMDRAW;
		return;
	}

    if (lplvcd->nmcd.dwDrawStage == CDDS_ITEMPREPAINT){
        *pResult = CDRF_NOTIFYSUBITEMDRAW;
		return;
	}

    if (lplvcd->nmcd.dwDrawStage == (CDDS_ITEMPREPAINT | CDDS_SUBITEM)) {
		int		nCol = 0;
		char	ch[8];

		for (int i = 0; i < m_ChipListCtrl.GetItemCount(); i++) {
			CString szText = m_ChipListCtrl.GetItemText(i, nCol);
			strcpy(ch, (LPCTSTR)(szText));
			COLORREF color = m_pDoc->m_gCategoryColor[(int)ch[0]];

			if(1 == lplvcd->iSubItem) {
				if(lplvcd->nmcd.dwItemSpec == i) {
				   lplvcd->clrTextBk = color;
				}
			}
			else {
				lplvcd->clrTextBk = RGB(255,255,255);
			}
		}

		*pResult = CDRF_NEWFONT;
    }
}


void CCMVDlg::OnClickChipList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CColorDialog myDLG;
	COLORREF	 newColor;
	char		 ch[8];

	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	m_pDoc->m_CatSelect = pNMListView->iItem;

	if (m_pDoc->m_CatSelect >= 0)
	{
		CString szText = m_ChipListCtrl.GetItemText(m_pDoc->m_CatSelect, 0);
		strcpy(ch, (LPCTSTR)(szText));

		if(myDLG.DoModal() == IDOK) {
			newColor = myDLG.GetColor();
			if(newColor != m_pDoc->m_gCategoryColor[(int)ch[0]])
			{
				m_pDoc->m_gCategoryColor[(int)ch[0]] = newColor;
			}
		}
	}

	Invalidate();
	m_MapLayout->UpdateWindow();
	*pResult = 0;
}

void CCMVDlg::OnSelchangeZoom() 
{
	if (m_pDoc->m_IsLoadedMap == true)
	{
		m_pDoc->m_Zoom = pZoom->GetCurSel() + 1;
		m_MapLayout->OnUpdateMapView();
	}
}

HBRUSH CCMVDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if(nCtlColor == CTLCOLOR_BTN){
		if(pWnd->m_hWnd == GetDlgItem(IDC_BTN_BG)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(m_pDoc->m_BackColor);
			return ::CreateSolidBrush(m_pDoc->m_BackColor);

		} else if(pWnd->m_hWnd == GetDlgItem(IDC_BTN_POS)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(m_pDoc->m_PosColor);
			return ::CreateSolidBrush(m_pDoc->m_PosColor);

		} else if(pWnd->m_hWnd == GetDlgItem(IDC_BTN_REF)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(m_pDoc->m_RefColor);
			return ::CreateSolidBrush(m_pDoc->m_RefColor);

		} else if(pWnd->m_hWnd == GetDlgItem(IDC_BTN_PICK)->m_hWnd ){
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetTextColor(m_pDoc->m_PickColor);
			return ::CreateSolidBrush(m_pDoc->m_PickColor);

		}
	}
	return hbr;
}

void CCMVDlg::OnBtnPick() 
{
	// TODO: Add your control notification handler code here
	CColorDialog myDLG;
	COLORREF	 newColor;
	char		 ch[8];
	CString szText = '#';
		strcpy(ch, (LPCTSTR)(szText));

		if(myDLG.DoModal() == IDOK) {
			newColor = myDLG.GetColor();
			if(newColor != m_pDoc->m_gCategoryColor[(int)ch[0]])
			{
				m_pDoc->m_gCategoryColor[(int)ch[0]] = newColor;
				m_pDoc->m_PickColor = newColor;
			}
		}
		Invalidate();
}

void CCMVDlg::OnBtnPos() 
{
	CColorDialog myDLG;
	COLORREF	 newColor;

	if(myDLG.DoModal() == IDOK) {
		newColor = myDLG.GetColor();
		if(newColor != m_pDoc->m_PosColor) {
			m_pDoc->m_PosColor = newColor;
		}
	}

	Invalidate();
}

void CCMVDlg::OnBtnRef() 
{
	CColorDialog myDLG;
	COLORREF	 newColor;

	if(myDLG.DoModal() == IDOK) {
		newColor = myDLG.GetColor();
		if(newColor != m_pDoc->m_RefColor) {
			m_pDoc->m_RefColor = newColor;
		}
	}

	Invalidate();
}

void CCMVDlg::OnBtnBg() 
{
	CColorDialog myDLG;
	COLORREF	 newColor;

	if(myDLG.DoModal() == IDOK) {
		newColor = myDLG.GetColor();
		if(newColor != m_pDoc->m_BackColor) {
			m_pDoc->m_BackColor = newColor;
			m_MapLayout->SetBackSolidBrush(m_pDoc->m_BackColor);
		}
	}

	Invalidate();
	m_MapLayout->UpdateWindow();
}


void CCMVDlg::OnBtnJump()
{
	if((m_pDoc->m_JumpX >= m_pDoc->m_CoulmMax) || (m_pDoc->m_JumpY >= m_pDoc->m_LineMax))
	{
		MessageBox(_T("The index value is not a valid"), _T("Error"), MB_ICONERROR | MB_OK);
	}
	else {
		m_pDoc->m_IsDispJumpInMap = TRUE;
//		m_pDoc->m_IsDispJumpInTab = FALSE;
		m_pDoc->m_IndexSelect = -1;
	}
	
	Invalidate(TRUE);
//	AfxGetApp()->m_pMainWnd->Invalidate();
	UpdateWindow();
}


BOOL CCMVDlg::PreTranslateMessage(MSG* pMsg) 
{
	if ((GetKeyState(0x1B) & 0x8000)) {	
		if(m_pDoc->m_IsLoadedMap == true) {
			for(int i = 0; i < m_pDoc->m_LineMax; i++) {
				delete[] m_pDoc->LEDArrayInfo[i];
			}
			delete[] m_pDoc->LEDArrayInfo;
			
			delete[] m_pDoc->xAxisRectArray;
			delete[] m_pDoc->yAxisRectArray;
		}
		//delete m_pDoc;	

		/* Put position window to INI file (S) */
		int *m_windowSizeTemp = new int[4];
		CRect rect;
		GetWindowRect(&rect);
		m_windowSize[0] = rect.left;
		m_windowSize[1] = rect.top;
		m_windowSize[2] = rect.right;
		m_windowSize[3] = rect.bottom;

		WriteFile(_T(m_pDoc->m_IniFile), m_pDoc->m_Setting, _T("Position_Window"), m_windowSize);
		delete m_windowSizeTemp;
		/* Put position window to INI file (E) */
	}

	return CDialog::PreTranslateMessage(pMsg);
}


void CCMVDlg::WriteFile(LPCTSTR filePath, LPCTSTR lpszSection, LPCTSTR lpszKey, int Data[])
{
	CString	strA,strB;
	int	numElements = 4;

	strA.Format(_T("%d"),numElements);
	
	for(int i=0;i<numElements;i++){
		strB.Format(_T(",%d"), Data[i]);
		strA += strB;
	}
	WritePrivateProfileString (lpszSection, lpszKey, strA, filePath);
}


LRESULT CCMVDlg::OnMapCtrl(WPARAM wParam, LPARAM lParam)
{
	LRESULT r = 0;
	switch (wParam) {
	case WMV_DISP:	// �\������
		switch (lParam) {
		case 0:	// ����
			SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_HIDEWINDOW);
			break;
		case 1:	// �\��
			SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
		
			break;
// #KS090703-01(S) ���e����
		case 2:	// ���e����
			break;
// #KS090703-01(E)
		}
		break;
		case WMV_PICK:	// �s�b�N�A�b�v����
// #KS090826-01 �}�b�s���O�̃s�b�N�A�b�v�ς݃f�[�^��ʋL������
		Picked(lParam);
		Invalidate();
		break;
// #KS041020-01(S) �}�b�v�t�@�C���R���o�[�^�Ή�
// #KS090829-03 ���t�@�����X�ʒu�̃r���[�A�ւ̑��M
	case WMV_REFP:
		RefP(lParam);
		// �s�b�N�A�b�v�`��
		Invalidate(false);
		break;
	case WMV_REFC:
		RefC(lParam);
		// �s�b�N�A�b�v�`��
		Invalidate(false);
		break;
		case WMV_MOVE:	// �ړ�����
		if (XYOK(lParam, m_AutoCurX, m_AutoCurY)) {	// �e�L�X�g�͈͓�
// #KS110723-01(E)
			m_SelIdx = lParam;
			m_SelLock = false;
//			m_Map.SetSel(m_SelIdx, m_SelIdx + 1);
			m_SelLock = true;
//			m_Map.HideSelection(FALSE, TRUE);
//			DispCurrentPosition();
// #KN090820-01 (S) �O���t�B�b�N��
			if(m_PickMode==3){		// �O���t�B�b�N
// #KS110723-01(E)

				Invalidate(false);
			}
		}
		break;
	}
	return r;
}

void CCMVDlg::Picked(int idx)
{
	CHARFORMAT2 cf;
	int ix, iy;
	if (XYOK(idx, ix, iy)) {	// �e�L�X�g�͈͓�
//		m_SelLock = false;
//		m_Map.SetSel(idx, idx + 1);
		int idx2;
		idx2 = (iy * m_pDoc->MapD.COLCT) + ix;
		idx2 = 2;
//		m_pDoc->MapD.PICLT.SetAt(idx2, '#');
		m_pDoc->LEDArrayInfo[ix][iy].ch = '#';
		int colMax = m_pDoc->MapD.COLCT-2;
		int rowMax = m_pDoc->MapD.ROWCT-2;
		int i = m_pDoc->LEDArrayInfo[ix][iy].index;
		for(int col = 0; col< colMax; col++){
			for(int row =0; row < rowMax; row++){
				if(m_pDoc->LEDArrayInfo[row][col].index == i){
					m_pDoc->LEDArrayInfo[row][col].ch = '#';
				}else{
					//Do nothing
				}
			
			}
		}
		switch (m_PickMode) {
		default:
		case 0:
			if (m_pDoc->MapD.NULBC.GetLength()) {
//				m_Map.ReplaceSel(MapD.NULBC);
			}
			break;
		case 1:
//			m_Map.ReplaceSel(" ");
			break;
		case 2:
			cf.cbSize = sizeof(cf);
			cf.dwMask = CFM_COLOR | CFM_BACKCOLOR;
//			m_Map.GetSelectionCharFormat(cf);		// crTextColor�擾
			cf.cbSize = sizeof(cf);
			cf.dwMask = CFM_COLOR | CFM_BACKCOLOR;
			cf.dwEffects = 0;
			cf.crBackColor = m_PickColor;			// �w�i�F��ύX
//			::SendMessage( m_Map.GetSafeHwnd(), EM_SETCHARFORMAT, (WPARAM) SCF_SELECTION, (LPARAM) &cf );
//			m_Map.SetSel(0, 0);
			break;
		case 3:
			// �ʒu�f�[�^�ϊ�
			m_AutoPickUpX = ix;										// �߯����߈ʒu(X)
			m_AutoPickUpY = iy;										// �߯����߈ʒu(Y)
			int iPickUp = m_PickUp[m_AutoPickUpY][m_AutoPickUpX];
// #KS110723-01(E)
			if((m_AutoPickUpX > -1) && (m_AutoPickUpY > -1)){
			/*	if(PickUpCategory.Find(CategoryKind[m_AutoPickUpY][m_AutoPickUpX]) != -1){			//�Ǖi�J�e�S���ɊY�����邩�`�F�b�N
					m_PickUp[m_AutoPickUpY][m_AutoPickUpX] = 2;										//�Ǖi
				}else if(BadMarkCategory.Find(CategoryKind[m_AutoPickUpY][m_AutoPickUpX]) != -1){	//�s�Ǖi�J�e�S���ɊY�����邩�`�F�b�N
					m_PickUp[m_AutoPickUpY][m_AutoPickUpX] = 3;										//�s�Ǖi
				}*/
			}
			// �s�b�N�A�b�v�`��
			Invalidate(false);

			// �J�A�E���g�_�E��
//			if (iPickUp != m_PickUp[iy][ix] && m_PickupCnt[(int)(CategoryKind[iy][ix])] > 0) {
//				m_PickupCnt[(int)(CategoryKind[iy][ix])] -= 1;		// �J�e�S�����ɃJ�E���g�_�E��
// #KS110723-01(E)
//			}
//			SetChipCountDataToDisp(1);							// �s�b�N�A�b�v�c���\���f�[�^�̐ݒ�

			break;
// #KN090820-01 (E) �O���t�B�b�N��
		}
		if (-1 != m_SelIdx) {
//			m_Map.SetSel(m_SelIdx, m_SelIdx + 1);
		}
//		m_SelLock = true;
	}
	return;
}

// #KS090829-03 ���t�@�����X�ʒu�̃r���[�A�ւ̑��M
void CCMVDlg::RefP(int idx)
{
	if(m_pDoc->MapD.RPSEL < 10){		// �o�^�\

		// �ʒu�f�[�^�ϊ�
// #KS110723-01(S) �s�b�N�A�b�v�ς݋L������
//		int iY = (int)((int)idx / (m_CoulmMax + 1) );
//		int iX = (int)idx - (iY * (m_CoulmMax + 1));
		int iX, iY;
		if (!XYOK(idx, iX, iY)) {
			return;
		}
// #KS110723-01(E)
		// �o�^�ς݃`�F�b�N
		for( int i = 0 ; i < 10 ; i++ ){
			if((m_pDoc->MapD.REFPY[i] == iY) && (m_pDoc->MapD.REFPX[i] == iX)){
				return;
			}
		}

		// �o�^
		m_pDoc->MapD.REFPY[m_pDoc->MapD.RPSEL] = iY;
		m_pDoc->MapD.REFPX[m_pDoc->MapD.RPSEL] = iX;
		m_pDoc->MapD.RPSEL += 1;
	}
	
	return;
}

// #KS090829-03 ���t�@�����X�ʒu�̃r���[�A�ւ̍폜
void CCMVDlg::RefC(int idx)
{
/*	if(idx == -1){
		// ���t�@�����X�ʒu�f�[�^�S�f�[�^���폜
		m_pDoc->MapD.RPSEL = 0;
		for (int i = 0 ; i < 10 ; i++) {
			m_pDoc->MapD.REFPY[i] = 0;
			m_pDoc->MapD.REFPX[i] = 0;
		}
	}
	return;*/
}

// #KS110723-01(S) �s�b�N�A�b�v�ς݋L������
// �������ʒu�ł���΁AXY�����ɕ�������
bool CCMVDlg::XYOK(const int idx, int &x, int &y)
{
	bool r = true;
	m_CoulmMax = m_pDoc->MapD.COLCT-1;
	m_LineMax  = m_pDoc->MapD.ROWCT-1;
	int iY = (int)((int)idx / (m_CoulmMax + 1));
	int iX = (int)idx - (iY * (m_CoulmMax + 1));
	if (0 <= iY && iY < m_LineMax && 0 <= iX && iX < m_CoulmMax) {
		x = iX;
		y = iY;
	} else {
		r = false;
	}
	return(r);
}
// Get min and max size of dialog
void CCMVDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	lpMMI->ptMinTrackSize.x = CMV_DLG_SIZEX;
	lpMMI->ptMinTrackSize.y = CMV_DLG_SIZEY;
}

void CCMVDlg::OnSize(UINT nType, int cx, int cy)
{
	if (!m_bInit) {
		return;
	}
	// Initialize a rect
	CRect rect;
	// Expand layout window
	m_MapLayout->GetWindowRect(rect);
	ScreenToClient(&rect);
	int oldWidth = rect.Width(); // store original width of layout window
	int oldHeight = rect.Height();
	CRect layoutRect(rect.TopLeft(), CSize(cx - MAGIN_RIGHT, cy - MAGIN_TOP_BOTTOM));
	m_MapLayout->MoveWindow(layoutRect);
/*	if (GetDlgItem(IDC_BTN_LOAD_MAP) != NULL) {
		GetDlgItem(IDC_BTN_LOAD_MAP)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_LOAD_MAP)->MoveWindow(rect,true);
	}*/
//	IDC_LIST_INDEX_PICKUP
	if (GetDlgItem(IDC_LIST_INDEX_PICKUP) != NULL) {
		GetDlgItem(IDC_LIST_INDEX_PICKUP)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_LIST_INDEX_PICKUP)->MoveWindow(rect,true);
	}
//	IDC_STATIC
	if (GetDlgItem(IDC_STATIC) != NULL) {
		GetDlgItem(IDC_STATIC)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC)->MoveWindow(rect,true);
	}
//IDC_CHIP_LIST
	if (GetDlgItem(IDC_CHIP_LIST) != NULL) {
		GetDlgItem(IDC_CHIP_LIST)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_CHIP_LIST)->MoveWindow(rect,true);
	}
//	IDC_BTN_PICK
	if (GetDlgItem(IDC_BTN_PICK) != NULL) {
		GetDlgItem(IDC_BTN_PICK)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_PICK)->MoveWindow(rect,true);
	}
//	IDC_BTN_REF
	if (GetDlgItem(IDC_BTN_REF) != NULL) {
		GetDlgItem(IDC_BTN_REF)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_REF)->MoveWindow(rect,true);
	}
//	IDC_BTN_POS
	if (GetDlgItem(IDC_BTN_POS) != NULL) {
		GetDlgItem(IDC_BTN_POS)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_POS)->MoveWindow(rect,true);
	}
//	IDC_BTN_BG
	if (GetDlgItem(IDC_BTN_BG) != NULL) {
		GetDlgItem(IDC_BTN_BG)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_BTN_BG)->MoveWindow(rect,true);
	}
//	IDC_STATIC_PICK
	if (GetDlgItem(IDC_STATIC_PICK) != NULL) {
		GetDlgItem(IDC_STATIC_PICK)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_PICK)->MoveWindow(rect,true);
	}
//	IDC_STATIC_BG
	if (GetDlgItem(IDC_STATIC_BG) != NULL) {
		GetDlgItem(IDC_STATIC_BG)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_BG)->MoveWindow(rect,true);
	}
//	IDC_STATIC_REF
	if (GetDlgItem(IDC_STATIC_REF) != NULL) {
		GetDlgItem(IDC_STATIC_REF)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_REF)->MoveWindow(rect,true);
	}
//	IDC_STATIC_POS
	if (GetDlgItem(IDC_STATIC_POS) != NULL) {
		GetDlgItem(IDC_STATIC_POS)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_POS)->MoveWindow(rect,true);
	}
//	IDC_STATIC_DIE
	if (GetDlgItem(IDC_STATIC_DIE) != NULL) {
		GetDlgItem(IDC_STATIC_DIE)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(layoutRect.Width() - oldWidth, 0);
		GetDlgItem(IDC_STATIC_DIE)->MoveWindow(rect,true);
	}
//	m_pMapInfo
	if (m_pMapInfo) {
		m_pMapInfo->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(0,layoutRect.Height() - oldHeight);
		m_pMapInfo->MoveWindow(rect,true);
	}
//	IDC_BTN_JUMP
	if (GetDlgItem(IDC_BTN_JUMP) != NULL) {
		GetDlgItem(IDC_BTN_JUMP)->GetWindowRect(rect);
		ScreenToClient(&rect);
		rect.OffsetRect(0,layoutRect.Height() - oldHeight);
		GetDlgItem(IDC_BTN_JUMP)->MoveWindow(rect,true);
	}
	// Redraw
	CRect rc;
	m_MapLayout->GetWindowRect(rc);
	GetClientRect(&rc);	
	if (m_MapLayout->m_mapDispSize.cx <= rc.right) {
		m_MapLayout->m_mapDispSize.cx = rc.right;
	}

	if (m_MapLayout->m_mapDispSize.cy <= rc.bottom) {
		m_MapLayout->m_mapDispSize.cy = rc.bottom;
	}
// (E)
	Invalidate();
	CDialog::OnSize(nType, cx, cy);
	
}

#if !defined(AFX_CMV_EDITCTRL_H__50807FAB_3422_4BEF_BA34_6592B209EC96__INCLUDED_)
#define AFX_CMV_EDITCTRL_H__50807FAB_3422_4BEF_BA34_6592B209EC96__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// CMV_EditCtrl.h : header file
//
#include "CMV.h"


/////////////////////////////////////////////////////////////////////////////
// CMV_EditBox window

class CMV_EditBox : public CEdit
{
private:
	CFont m_font;
	CWnd* m_pRevWnd;
	int m_StartSel;
	int m_EndSel;
	bool m_IsInteger;
	int m_Mode;
	int m_Language;

// Construction
public:
	CMV_EditBox();
	void CreateEditBox(CWnd* pParent, CRect rect, CString text);
	void SetEditFont(int fontSize, CString fontName);
	void SetRevWnd(CWnd* pRevWnd);
	void SetMode(int mode);									// 0: numkey mode, 1: fullkey mode
	int GetMode();
	void SetIntegerMode(bool isInteger);
	void SetLanguage(int language);
	bool GetIntegerMode();
	afx_msg LRESULT OnKey(WPARAM wParam, LPARAM lParam); // Response when press a key
	afx_msg LRESULT OnFullKey(WPARAM wParam, LPARAM lParam); // Response when press a key (full key board)
// Implementation
	virtual ~CMV_EditBox();

	// Generated message map functions
protected:
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	//afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	//afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg virtual void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
// CMV_EditCtrl dialog

class CMV_EditCtrl : public CDialog
{
private:
	CMV_EditBox m_Edit;

// Construction
public:
	CMV_EditCtrl(CWnd* pParent = NULL);   // standard constructor
	virtual ~CMV_EditCtrl();
	enum { IDD = IDD_EDIT_BOX_DLG };

	void SetText(CString text);
	CString GetText();
	void SetEditFont(int fontSize, CString fontName);
	CWnd* GetEditWnd();
	void SetRevWnd(CWnd* pRevWnd);
	void SetSel(int start, int end);

	void SetMode(int mode);									// 0: numkey mode, 1: fullkey mode
	void SetIntegerMode(bool isInteger);
	void SetLanguage(int language);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();


// Implementation
protected:
	afx_msg void OnSize(UINT nType, int cx, int cy);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_EDITCTRL_H__50807FAB_3422_4BEF_BA34_6592B209EC96__INCLUDED_)

///////////////////////////////////////////////////////////
//  CMV_GridCell.cpp
//  Implementation of the Class CMV_IC
//  Created on:      12-Thg7-2013 1:52:09 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CMV_GridCell.h"

#define DCMV_CELL_BK_CLR			RGB(255, 255, 255)
#define DCMV_CELL_HEADER_BK_CLR		(::GetSysColor(COLOR_BTNFACE))
#define DCMV_CELL_TEXT_CLR			RGB(0, 0, 0)
#define DCMV_CELL_LINE_CLR			RGB(80, 80, 80)
#define DCMV_CELL_MARK_CLR			RGB(0, 0, 0)
#define DCMV_CELL_TEXT_BORDER		2
#define TEXT_LENGTH_MAX				8								// "xxx.xxxx"


CMV_GridCell::CMV_GridCell(int row, int col)
{
	m_Type = DCMV_CELL_STRING;
	m_Text = _T("");
	m_OldText = _T("");
	m_Row = row;
	m_Col = col;
	m_Header = false;
	m_Merged = false;
	m_Visible = true;
	//m_BkClr = DCMV_CELL_BK_CLR;
	m_TextClr = DCMV_CELL_TEXT_CLR;
	m_Region.SetRectEmpty();
	m_IsMark = false;
}


CMV_GridCell::~CMV_GridCell()
{

}


void CMV_GridCell::Draw(CDC* pDC)
{
	if(m_Merged || !m_Visible) return;
	// Background color
	CBrush brush(m_Header ? DCMV_CELL_HEADER_BK_CLR : (/*!m_IsMark ? */DCMV_CELL_BK_CLR /*: DCMV_CELL_MARK_CLR*/));
	CBrush* pOldBrush = pDC->SelectObject(&brush);
	// Set pen
	CPen pen(PS_SOLID, !m_IsMark ? 1 : 2, !m_IsMark ? DCMV_CELL_LINE_CLR : DCMV_CELL_MARK_CLR);
	CPen* pOldPen = pDC->SelectObject(&pen);
	// Set text color
	//SetColor(m_TextClr);
	COLORREF textClr = pDC->SetTextColor(m_TextClr);

	// Draw
	pDC->Rectangle(m_Region);
	CRect textRect = m_Region;
	textRect.DeflateRect(DCMV_CELL_TEXT_BORDER, DCMV_CELL_TEXT_BORDER);

	if (!m_Header && (m_Text.GetLength() > TEXT_LENGTH_MAX)) {	
		// If this cell is for inputting value, need to left align (high priority for the most meaning digit)
		pDC->DrawText(m_Text, textRect, DT_WORDBREAK | DT_LEFT);
	} else {
		// If this cell is for display a label or a short-length number, should align the text to center
		pDC->DrawText(m_Text, textRect, DT_WORDBREAK | DT_CENTER);
	}
	
	// Restore brush and pen
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);
	pDC->SetTextColor(textClr);
}


bool CMV_GridCell::Merge(CMV_GridCell* pCell)
{
	if(pCell == NULL) return false;
	if((pCell->m_Row != m_Row) && (pCell->m_Col != m_Col)) return false;
	pCell->m_Merged = true;
	m_Region.BottomRight() = pCell->m_Region.BottomRight();
	return true;
}

void CMV_GridCell::SetRegion(CRect rect)
{
	m_Region = rect;
}


CRect CMV_GridCell::GetRegion()
{
	return m_Region;
}

void CMV_GridCell::SetHeader(bool header)
{
	m_Header = header;
}


void CMV_GridCell::SetText(CString text, bool restore)
{
	CString tmp = text;
	if((m_Type == DCMV_CELL_INT) && !m_Header && (text != _T(""))){
		tmp.Format(_T("%d"), atoi(text));
	}else if((m_Type == DCMV_CELL_DOUBLE) && !m_Header && (text != _T(""))){
		tmp.Format(_T("%.4f"), atof(text));
	} else {
		// do nothing
	}
	
	m_Text = tmp;
	if(restore) m_OldText = tmp;
}


void CMV_GridCell::RestoreText()
{
	m_Text = m_OldText;
}

void CMV_GridCell::SetColor(COLORREF color)
{
	m_TextClr = color;
}

CString CMV_GridCell::GetText()
{
	return m_Text;
}

CString CMV_GridCell::GetOldText()
{
	return m_OldText;
}

int CMV_GridCell::GetRow()

{
	return m_Row;
}

int CMV_GridCell::GetCol()
{
	return m_Col;
}

void CMV_GridCell::SetVisible(bool visible)
{
	m_Visible = visible;
}


bool CMV_GridCell::IsEnable()
{
	return (m_Visible && !m_Header && !m_Merged);
}

void CMV_GridCell::SetType(DCMV_CellType type)
{
	m_Type = type;
}

void CMV_GridCell::SetMarkCell(bool mark)
{
	m_IsMark = mark;
}

bool CMV_GridCell::GetMarkCell()
{
	return m_IsMark;
}

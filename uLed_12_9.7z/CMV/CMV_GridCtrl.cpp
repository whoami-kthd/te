///////////////////////////////////////////////////////////
//  CMV_GridCtrl.cpp
//  Implementation of the Class CMV_LayoutWnd
//  Created on:      16-Thg7-2013 1:03:28 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////
//
#include "stdafx.h"
//#include "swatch.h"
#include "CMV_GridCtrl.h"
#include "CMV_Doc.h"
#include "CMV_Util.h"


#define DCMV_GRIDCTRL_VIR_DC_SIZE_MORE	10
#define DCMV_GRIDCTRL_DEFAULT_HEIGHT	16
#define DCMV_GRIDCTRL_DEFAULT_WIDTH		45
#define DCMV_GRIDCTRL_BK_COLOR			(::GetSysColor(COLOR_BTNFACE))
#define DCMV_GRIDCTRL_SEL_COLOR			RGB(255, 255, 255)
#define DCMV_GRIDCTRL_TEXT_CLR			RGB(0, 0, 0)
#define DCMV_GRIDCTRL_TEXT_OVERLAP		RGB(255, 0, 0)
#define DCMV_GRIDCTRL_FONT_SIZE			/*72*/80
#define DCMV_GRIDCTRL_FONT_NAME			_T("MS Sans Serif")
#define DCMV_GRIDCTRL_SEL_BORDER		2


/////////////////////////////////////////////////////////////////////////////
// CMV_GridCtrl

IMPLEMENT_DYNCREATE(CMV_GridCtrl, CScrollView)

CMV_GridCtrl::CMV_GridCtrl(int row, int col)
{
	m_pSelCell = NULL;
	m_Row = row;
	m_Col = col;
	// Row heigth
	m_vHeightRow.clear();
	for(int idx = 0; idx < row; idx ++){
		m_vHeightRow.push_back(DCMV_GRIDCTRL_DEFAULT_HEIGHT);
	}
	// Col width
	m_vWidthCol.clear();
	for(idx = 0; idx < col; idx ++){
		m_vWidthCol.push_back(DCMV_GRIDCTRL_DEFAULT_WIDTH);
	}

	m_vCells.clear();
	// Create all cells
	CRect regionX(CPoint(0, 0), CSize(DCMV_GRIDCTRL_DEFAULT_WIDTH, DCMV_GRIDCTRL_DEFAULT_HEIGHT));
	for(int iRow = 0; iRow < row; iRow ++){
		CRect regionY = regionX;
		for(int iCol = 0; iCol < col; iCol ++){
			CMV_GridCell* pCell = new CMV_GridCell(iRow, iCol);
			pCell->SetRegion(regionY);
			m_vCells.push_back(pCell);
			// Offset region
			regionY.OffsetRect(DCMV_GRIDCTRL_DEFAULT_WIDTH - 1, 0);
		}
		regionX.OffsetRect(0, DCMV_GRIDCTRL_DEFAULT_HEIGHT - 1);
	}
}

CMV_GridCtrl::~CMV_GridCtrl()
{
	if(m_MemDC.m_hDC != NULL){
		m_MemDC.DeleteDC();
		m_MemBmp.DeleteObject();
	}
	// Clear all cell
	for(UINT idx = 0; idx < m_vCells.size(); idx ++){
		delete m_vCells[idx];
	}
	m_vCells.clear();
}


BEGIN_MESSAGE_MAP(CMV_GridCtrl, CScrollView)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_SIZE()
	ON_WM_MOUSEACTIVATE()
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateCell)
	ON_WM_VSCROLL()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_LayoutWnd drawing

void CMV_GridCtrl::OnDraw(CDC* pDC)
{
	// Draw to virtual DC
	DrawToMemDC();
	// Draw to real DC
	CRect rect;
	GetWindowRect(rect);
	pDC->BitBlt(GetScrollPosition().x, GetScrollPosition().y, rect.Width(), rect.Height(),
		&m_MemDC, 0, 0, SRCCOPY);
}


void CMV_GridCtrl::DrawToMemDC()
{
	// Get total size
	CSize size = GetTotalSize();
	// Get region
	CRect rect(CPoint(0, 0), GetTotalSize());
	// Draw background to virtual DC
	m_MemDC.FillSolidRect(rect, DCMV_GRIDCTRL_BK_COLOR);
	// Set view port for memory DC
	m_MemDC.SetViewportOrg(- GetScrollPosition());

	// Set font
	CFont font;
	font.CreatePointFont(DCMV_GRIDCTRL_FONT_SIZE, DCMV_GRIDCTRL_FONT_NAME);
	CFont* pOldFont = m_MemDC.SelectObject(&font);
	m_MemDC.SetBkMode(TRANSPARENT);
	
	// Draw all cells except marked cells
	int cellSize = m_vCells.size();
	CRect clientRect;
	GetClientRect(&clientRect);
	//TRACE("CLIENT RECT: left=%d right=%d top=%d bottom=%d\n", clientRect.left, clientRect.right, clientRect.top, clientRect.bottom);
	for(UINT idx = 0; idx < cellSize; idx ++){
		// Don't draw mark cell
		if (m_vCells[idx]->GetMarkCell()) {
			continue;
		}
// #DUCDT131112: Don't draw cell not in display size
		if (GetStyle() & WS_HSCROLL) { // Check if scroll bar is visible
			CRect rect = m_vCells[idx]->GetRegion();
			if ((rect.right < (GetScrollPos(SB_HORZ) + clientRect.left)) 
				|| (rect.left > (GetScrollPos(SB_HORZ) + clientRect.right))
				|| (rect.top > (GetScrollPos(SB_VERT) + clientRect.bottom))
				|| (rect.bottom < (GetScrollPos(SB_VERT) + clientRect.top))) {
				//TRACE("SCROLL POS: HORZ=%d VERT=%d \n", GetScrollPos(SB_HORZ), GetScrollPos(SB_VERT));
				//TRACE("CELL RECT: left=%d right=%d top=%d bottom=%d\n", rect.left, rect.right, rect.top, rect.bottom);
				continue;
			}
		}
		m_vCells[idx]->Draw(&m_MemDC);
	}

	// Draw marked cells
	for(idx = 0; idx < cellSize; idx ++){
		if (m_vCells[idx]->GetMarkCell()) {

// #DUCDT131112: Don't draw cell not in display size
			if (GetStyle() & WS_HSCROLL) { // Check if scroll bar is visible
				CRect rect = m_vCells[idx]->GetRegion();
				if ((rect.right < (GetScrollPos(SB_HORZ) + clientRect.left))
					|| (rect.left > (GetScrollPos(SB_HORZ) + clientRect.right))
					|| (rect.top > (GetScrollPos(SB_VERT) + clientRect.bottom))
					|| (rect.bottom < (GetScrollPos(SB_VERT) + clientRect.top))) {
					continue;
				}
			}
			m_vCells[idx]->Draw(&m_MemDC);
		}
	}

	/*// Draw select cell
	if(m_pSelCell != NULL){
		CRect selRect = m_pSelCell->GetRegion();
		selRect.DeflateRect(DCMV_GRIDCTRL_SEL_BORDER, DCMV_GRIDCTRL_SEL_BORDER);
		m_MemDC.FillSolidRect(selRect, DCMV_GRIDCTRL_SEL_COLOR);
	}*/

	// Set the default view port for memory DC
	m_MemDC.SetViewportOrg(0, 0);
	m_MemDC.SelectObject(pOldFont);
}

BOOL CMV_GridCtrl::OnEraseBkgnd(CDC* pDC)
{
	// do nothing
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMV_LayoutWnd diagnostics

#ifdef _DEBUG
void CMV_GridCtrl::AssertValid() const
{
	CScrollView::AssertValid();
}

void CMV_GridCtrl::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_GridCtrl message handlers

// This method needs to be overridden to prevent an assertion
int CMV_GridCtrl::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message)
{
	if(message != WM_MOUSEMOVE){
		SetFocus();
	}
	return MA_ACTIVATE;
}

void CMV_GridCtrl::OnOK()
{
	//do nothing
	DestroyWindow();
}

int CMV_GridCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if(CScrollView::OnCreate(lpCreateStruct) == -1) return -1;
	SetScroll();

	// Create the edit box
	m_Edit.Create(IDD_EDIT_BOX_DLG, this);
	m_Edit.SetWindowPos(&CWnd::wndTop, 0, 0, 0, 0, SWP_DRAWFRAME);
	m_Edit.SetEditFont(DCMV_GRIDCTRL_FONT_SIZE, DCMV_GRIDCTRL_FONT_NAME);
	m_Edit.SetRevWnd(this);

	return 0;
}


void CMV_GridCtrl::OnSize(UINT nType, int cx, int cy)
{
	CScrollView::OnSize(nType, cx, cy);
	// Set scroll
	SetScroll();

	// Detach the virtual DC
	if(m_MemDC.m_hDC != NULL){
		m_MemDC.DeleteDC();
		m_MemBmp.DeleteObject();
	}
	// Create the virtual DC
	CDC* pDC = GetDC();
	m_MemDC.CreateCompatibleDC(pDC);
	m_MemBmp.CreateCompatibleBitmap(pDC,
		cx + DCMV_GRIDCTRL_VIR_DC_SIZE_MORE, cy + DCMV_GRIDCTRL_VIR_DC_SIZE_MORE);
	m_MemDC.SelectObject(&m_MemBmp);
}


void CMV_GridCtrl::SetScroll()
{
	// Get region
	CRect rect;
	GetClientRect(&rect);
	// Set scroll size
	long wndStyle = GetWindowLong(GetSafeHwnd(), GWL_STYLE);
	int HSize = ((wndStyle & WS_HSCROLL) == 0) ? 0 : GetSystemMetrics(SM_CXHSCROLL);
	int VSize = ((wndStyle & WS_VSCROLL) == 0) ? 0 : GetSystemMetrics(SM_CXVSCROLL);
	CSize regSize = rect.Size() + CSize(HSize, VSize);
	// Scroll size
	CSize size(0, 0);
	for(int idx = 0; idx < m_Row; idx ++){
		size.cy += m_vHeightRow[idx] - 1;
	}
	for(idx = 0; idx < m_Col; idx ++){
		size.cx += m_vWidthCol[idx] - 1;
	}
	size.cx = max(size.cx, regSize.cx);
	size.cy = max(size.cy, regSize.cy);
	SetScrollSizes(MM_TEXT, size);
}


CString CMV_GridCtrl::GetCellText(int row, int col)
{
	CMV_GridCell* pCell = GetCell(row, col);
	if(pCell == NULL) return _T("");
	return pCell->GetText();
}


void CMV_GridCtrl::SetCellText(int row, int col, CString text)
{
	CMV_GridCell* pCell = GetCell(row, col);
	if(pCell == NULL) return;
	pCell->SetText(text);
	// Redraw
	Invalidate();
}


void CMV_GridCtrl::ShowEditBox()
{
	if(m_pSelCell == NULL) {
		return;
	}
	CString text = m_pSelCell->GetText();
	m_Edit.SetText(text);
	m_Edit.SetSel(0, -1); //Select all
	//m_Edit.SetFocus();
	m_Edit.GetEditWnd()->SetFocus();
	m_Edit.ShowWindow(SW_SHOW);
}

CMV_GridCell* CMV_GridCtrl::GetCell(int row, int col)
{
	// Check row, col value
	if (row > m_Row || col > m_Col || row < 0 || col < 0) {
		return NULL;
	}
	int cellSize = m_vCells.size();
	
	/*for(UINT idx = 0; idx < cellSize; idx ++){
		if(m_vCells[idx]->GetCol() != col) continue;
		if(m_vCells[idx]->GetRow() != row) continue;
		return m_vCells[idx];
	}*/

// #DUCDT131112: Calculate index of cell by row and col
	int index = 0;
	index = m_Col * row + col;
	if ((index < cellSize) && (m_vCells[index]->GetCol() == col) && (m_vCells[index]->GetRow() == row)) {
		return m_vCells[index];
	}
	TRACE("[Edit]CMV_ GridCtrl::GetCell() Error at col=%d row=%d\n", col, row);
	return NULL;
}

void CMV_GridCtrl::SetRowHeight(int row, int height)
{
	if(row < 0) return;
	if(row >= (int)m_vHeightRow.size()) return;

	int offset = height - m_vHeightRow[row];
	m_vHeightRow[row] = height;

	// Set new size
	CMV_GridCell* pCell = NULL;
	int cellSize = m_vCells.size();
	for(UINT idx = 0; idx < cellSize; idx ++){
		pCell = m_vCells[idx];
		if(pCell->GetRow() < row) continue;
		CRect region = pCell->GetRegion();
		if(pCell->GetRow() == row){
			region.bottom += offset;
		}else{
			region.OffsetRect(0, offset);
		}

		pCell->SetRegion(region);
	}
	// Set the scroll size
	SetScroll();
}


void CMV_GridCtrl::SetColWidth(int col, int width)
{
	if(col < 0) return;
	if(col >= (int)m_vWidthCol.size()) return;

	int offset = width - m_vWidthCol[col];
	m_vWidthCol[col] = width;

	// Set new size
	CMV_GridCell* pCell = NULL;
	int cellSize = m_vCells.size();
	for(UINT idx = 0; idx < cellSize; idx ++){
		pCell = m_vCells[idx];
		if(pCell->GetCol() < col) continue;
		CRect region = pCell->GetRegion();
		if(pCell->GetCol() == col){
			region.right += offset;
		}else{
			region.OffsetRect(offset, 0);
		}
		pCell->SetRegion(region);
	}
	// Set the scroll size
	SetScroll();
}


void CMV_GridCtrl::SetColHeader(int col, bool isHeader)
{
	int cellSize = m_vCells.size();
	for(UINT idx = 0; idx < cellSize; idx ++){
		if(m_vCells[idx]->GetCol() != col) continue;
		m_vCells[idx]->SetHeader(isHeader);
	}
}


void CMV_GridCtrl::SetRowHeader(int row, bool isHeader)
{
	int cellSize = m_vCells.size();
	for(UINT idx = 0; idx < cellSize; idx ++){
		if(m_vCells[idx]->GetRow() != row) continue;
		m_vCells[idx]->SetHeader(isHeader);
		m_vCells[idx]->RestoreText();
	}
}

void CMV_GridCtrl::SetRowText(int row, CString str)
{
	int cellSize = m_vCells.size();
	for(UINT idx = 0; idx < cellSize; idx ++){
		if(m_vCells[idx]->GetRow() != row) continue;
		m_vCells[idx]->SetText(str, false);
	}
}

void CMV_GridCtrl::MergeCell(int row1, int col1, int row2, int col2)
{
	CMV_GridCell* pCell1 = GetCell(row1, col1);
	if(pCell1 == NULL) return;
	pCell1->Merge(GetCell(row2, col2));
}

int CMV_GridCtrl::GetRows()
{
	return m_Row;
}

int CMV_GridCtrl::GetCols()
{
	return m_Col;
}


int CMV_GridCtrl::GetColSel()
{
	if(m_pSelCell == NULL) return -1;
	return m_pSelCell->GetCol();
}


int CMV_GridCtrl::GetRowSel()
{
	if(m_pSelCell == NULL) return -1;
	return m_pSelCell->GetRow();
}


void CMV_GridCtrl::OnLButtonDown(UINT nFlags, CPoint point)
{
	// Send message to parent to announce event mouse left click
	::PostMessage(GetParent()->m_hWnd, WM_LBUTTONDOWN, 0, 0);
	// Restore the current selected cell
	// CMV_GridCell* pOldSelCell = m_pSelCell;

	// Set the selected rectangle
	CPoint refPnt = point + GetScrollPosition();

	// Select cell
	int row = -1, col = -1;
	// Find row
	int height = 0 ;
	for(int idx = 0; idx < m_Row; idx ++){
		height += m_vHeightRow[idx] - 1;
		if(height < refPnt.y) continue;
		row = idx;
		break;
	}
	// Find col
	int width = 0 ;
	for(idx = 0; idx < m_Col; idx ++){
		width += m_vWidthCol[idx] - 1;
		if(width < refPnt.x) continue;
		col = idx;
		break;
	}

	// Set the new select cell
	m_pSelCell = GetCell(row, col);
	if((m_pSelCell != NULL) && !m_pSelCell->IsEnable()){
		m_pSelCell = NULL;
	}

	// Edit box
	CRect rect(0, 0, 0, 0);
	CString text = _T("");
	if(m_pSelCell != NULL){
		// Move scroll
		MoveScrollCell(m_pSelCell->GetRow(), m_pSelCell->GetCol());

		rect = m_pSelCell->GetRegion();
		rect.InflateRect(3, 3);
		text = m_pSelCell->GetText();
	}
	ClientToScreen(rect);
	rect.OffsetRect(- GetScrollPosition());
	m_Edit.MoveWindow(rect);
	m_Edit.ShowWindow((m_pSelCell != NULL) ? SW_SHOW : SW_HIDE);
	// Set text
	m_Edit.SetText(text);
// #DUCDT131108: if no selected cell, not focus on EditBox
	if (m_pSelCell != NULL) {
		m_Edit.GetEditWnd()->SetFocus();
	}
	//m_Edit.SetSel(text.GetLength(), text.GetLength());
	m_Edit.SetSel(0, -1); // Select all the text
	
	// For undo function: Clear all cells are marked.
	ResetMarkCells();
	// Redraw
	Invalidate();
}

void CMV_GridCtrl::SetRowInvisible(int row)
{
	for(UINT idx = 0; idx < m_vCells.size(); idx ++){
		if(m_vCells[idx]->GetRow() != row) continue;
		m_vCells[idx]->SetVisible(false);
	}
}

void CMV_GridCtrl::SetColInvisible(int col)
{
	int cellSize = m_vCells.size();
	for(UINT idx = 0; idx < cellSize; idx ++){
		if(m_vCells[idx]->GetCol() != col) continue;
		m_vCells[idx]->SetVisible(false);
	}
}


void CMV_GridCtrl::Create(CRect rect, CWnd* pParentWnd, CDocument* pDoc)
{
	// Make the context
	CCreateContext* pContext = new CCreateContext();
	pContext->m_pCurrentDoc = pDoc;
	pContext->m_pCurrentFrame = NULL;
	pContext->m_pLastView = NULL;
	pContext->m_pNewDocTemplate = NULL;
	pContext->m_pNewViewClass = NULL;
	// Create
	CScrollView::Create(NULL, NULL,
		WS_VISIBLE | WS_CHILD | WS_DLGFRAME, rect, pParentWnd, NULL, pContext);
	// Delete pointer
	delete pContext;
}

CWnd* CMV_GridCtrl::GetEditWnd()
{
	return m_Edit.GetEditWnd();
}

void CMV_GridCtrl::RestoreText(int row, int col)
{
	CMV_GridCell* pCell = GetCell(row, col);
	if(pCell == NULL) return;
	pCell->RestoreText();
}

LRESULT CMV_GridCtrl::OnUpdateCell(WPARAM wParam, LPARAM lParam)
{
	if(m_pSelCell == NULL) return 0;
	m_pSelCell->SetText(m_Edit.GetText(), false);
	// Redraw
	Invalidate();
	// Post message to the parent window
	::PostMessage(GetParent()->m_hWnd, WM_UPDATE_CELL, 0, 0);
	return 0;
}

void CMV_GridCtrl::Deselect()
{ 
	m_pSelCell = NULL;
	m_Edit.MoveWindow(CRect(0, 0, 0, 0));
	m_Edit.ShowWindow(SW_HIDE);
}

void CMV_GridCtrl::SetColType(int col, DCMV_CellType type)
{
	int cellSize = m_vCells.size();
	for(UINT idx = 0; idx < cellSize; idx ++){
		if(m_vCells[idx]->GetCol() != col) continue;
		m_vCells[idx]->SetType(type);
	}
}

void CMV_GridCtrl::SetCellColor(int row, bool isOverlapped)
{
	
	int cellSize = m_vCells.size();
	/*
	for(UINT idx = 0; idx < cellSize; idx ++){
		if(m_vCells[idx]->GetRow() != row) continue;
		if (isOverlapped) {
			m_vCells[idx]->SetColor(DCMV_GRIDCTRL_TEXT_OVERLAP);	
		} else {
			m_vCells[idx]->SetColor(DCMV_GRIDCTRL_TEXT_CLR);	
		}
	}*/

// #DUCDT131112: Update set cell color by calculate index of cell
	for (int idx = 0; idx < m_Col; idx++) {
		int index = m_Col * row + idx;
		if (index < 0 || index > cellSize) {
			continue;
		}
		if (isOverlapped) {
			m_vCells[index]->SetColor(DCMV_GRIDCTRL_TEXT_OVERLAP);	
		} else {
			m_vCells[index]->SetColor(DCMV_GRIDCTRL_TEXT_CLR);	
		}
	}
	//m_Color = DCMV_GRIDCTRL_TEXT_OVERLAP;
}

/*
* Set selected cell
*/
void CMV_GridCtrl::SetCellSel(int row, int col)
{
	// Set the new select cell
	m_pSelCell = GetCell(row, col);
	if((m_pSelCell != NULL) && !m_pSelCell->IsEnable()){
		m_pSelCell = NULL;
	}

// #DUCDT131108: Correct move scroll bar
	// Move scroll bar
	MoveScrollCell(row, col);

	// Edit box
	CRect rect(0, 0, 0, 0);
	CString text = _T("");
	if(m_pSelCell != NULL){
		rect = m_pSelCell->GetRegion();
		rect.InflateRect(3, 3);
		text = m_pSelCell->GetText();
	}
	ClientToScreen(rect);
	rect.OffsetRect(- GetScrollPosition());
	m_Edit.MoveWindow(rect);
	m_Edit.ShowWindow((m_pSelCell != NULL) ? SW_SHOW : SW_HIDE);
	// Set text
	m_Edit.SetText(text);
	m_Edit.GetEditWnd()->SetFocus();
	//m_Edit.SetSel(text.GetLength(), text.GetLength());
	m_Edit.SetSel(0, -1); // Select all the text

	// Redraw
	Invalidate();
}

void CMV_GridCtrl::SetLanguage(int language)
{
	m_Edit.SetLanguage(language);
}

// For undo function
void CMV_GridCtrl::SetMarkCell(int row, int col)
{
	CMV_GridCell *pCell = GetCell(row, col);
	if (pCell != NULL) {
		pCell->SetMarkCell(true);
	}
}

// For undo function: Clear marked cells
void CMV_GridCtrl::ResetMarkCells()
{
	int cellSize = m_vCells.size();
	for(UINT idx = 0; idx < cellSize; idx ++){
		m_vCells[idx]->SetMarkCell(false);
	}	
}

/**
* Move scroll
*/
void CMV_GridCtrl::MoveScrollCell(int row, int col)
{
	CMV_GridCell *pCell = GetCell(row, col);
	if (pCell != NULL) {
		CRect clientRect;
		GetClientRect(&clientRect);
		CRect tmp = pCell->GetRegion();
		if (GetStyle() & WS_HSCROLL) { // Check if scroll bar is visible
			int HPos = GetScrollPos(SB_HORZ);
			if ((tmp.right - (clientRect.right + HPos)) > 0) {
				HPos = tmp.right - clientRect.right;
			} else if ((tmp.left - (clientRect.left + HPos)) < 0) {
				HPos = tmp.left - clientRect.left;
			}
			HPos = (HPos >= GetScrollLimit(SB_HORZ)) ? GetScrollLimit(SB_HORZ) : HPos;
			SetScrollPos(SB_HORZ, HPos);
		} 

		if (GetStyle() & WS_VSCROLL) { // Check if scroll bar is visible
			int VPos = GetScrollPos(SB_VERT);
			if ((tmp.bottom - (clientRect.bottom + VPos)) > 0) {
				VPos = tmp.bottom - clientRect.bottom;
			} else if ((tmp.top - (clientRect.top + VPos)) < 0) {
				VPos = tmp.top - clientRect.top;
			}
			VPos = (VPos >= GetScrollLimit(SB_VERT)) ? GetScrollLimit(SB_VERT) : VPos;
			SetScrollPos(SB_VERT, VPos);
		}
	}
	return;
}

/**
* Override function to get current position of vertival scroll in 64bit.
* With large data, position in 16bit is not enough.
*/
void CMV_GridCtrl::OnVScroll( UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	int pos = 0;
	switch(nSBCode) {
		// In case of thumb track, we need to update track position
		case SB_THUMBTRACK:
			SCROLLINFO si;
			si.cbSize = sizeof(SCROLLINFO);
			// Get scroll info
			GetScrollInfo(SB_VERT,&si,SIF_ALL);
			// Update track position
			pos = si.nTrackPos;
			break;
		default:
			pos = nPos;
			break;
	}

	CScrollView::OnVScroll(nSBCode, pos, pScrollBar);
}
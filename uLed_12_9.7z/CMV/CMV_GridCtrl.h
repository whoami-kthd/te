///////////////////////////////////////////////////////////
//  CMV_GridCtrl.h
//  Implementation of the Class CMV_LayoutWnd
//  Created on:      16-Thg7-2013 1:03:28 CH
//  Original author: tiennv
///////////////////////////////////////////////////////////

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_GridCtrl.h : header file
//
#include "CMV_GridCell.h"
#include "CMV_EditCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CMV_LayoutWnd view

class CMV_GridCtrl : public CScrollView
{
public:
	CMV_GridCtrl(int row = 0, int col = 0);           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMV_GridCtrl)
	virtual ~CMV_GridCtrl();
// Attributes
private:
	int m_Row;
	int m_Col;
	vector<CMV_GridCell*> m_vCells;
	CMV_GridCell* m_pSelCell;
	vector<int> m_vHeightRow;
	vector<int> m_vWidthCol;

	// Try to use temporary memoryDC
	CDC m_MemDC;
	CBitmap m_MemBmp;
	
	// The edit box
	CMV_EditCtrl m_Edit;

// Operations
protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	// Draw to memory DC
	void DrawToMemDC();
	void SetScroll();


// Implementation
protected:
	

	// For undo function
	//virtual BOOL PreTranslateMessage(MSG* pMsg);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Create event
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	// Draw event
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	// Mouse down
	afx_msg virtual void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg virtual int OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg LRESULT OnUpdateCell(WPARAM wParam, LPARAM lParam);
	afx_msg void OnVScroll( UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

	DECLARE_MESSAGE_MAP()

public:
	void Create(CRect rect, CWnd* pParentWnd, CDocument* pDoc);
	int GetRows();
	int GetCols();
	CString GetCellText(int row, int col);
	void SetCellText(int row, int col, CString text);
	void SetRowHeight(int row, int height);
	void SetColWidth(int col, int width);
	void SetColHeader(int col, bool isHeader = true);
	void SetRowHeader(int row, bool isHeader = true);
	void SetRowText(int row, CString str);
	void SetCellSel(int row, int col);
	void MergeCell(int row1, int col1, int row2, int col2);
	int GetColSel();
	int GetRowSel();
	void SetRowInvisible(int row);
	void SetColInvisible(int col);
	CWnd* GetEditWnd();
	void RestoreText(int row, int col);
	void Deselect();
	void ShowEditBox();
	CMV_GridCell* GetCell(int row, int col);
	void SetColType(int col, DCMV_CellType type);
	void SetCellColor(int row, bool isOverlapped);
	virtual void OnOK();
	void SetLanguage(int language);

	// Move scroll cell
	void MoveScrollCell(int row, int col);

	// For undo function
	void SetMarkCell(int row, int col);
	void ResetMarkCells();

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

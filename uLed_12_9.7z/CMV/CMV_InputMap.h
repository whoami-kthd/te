#if !defined(AFX_CMV_INPUTMAP_H__FD7AF90F_957B_4634_8055_D91E9E04BCB8__INCLUDED_)
#define AFX_CMV_INPUTMAP_H__FD7AF90F_957B_4634_8055_D91E9E04BCB8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_InputMap.h : header file
//

#include "CMV_Doc.h"

/////////////////////////////////////////////////////////////////////////////
// CMV_InputMap dialog

class CCMVDlg;
class CMV_InputMap : public CDialog
{
// Construction
public:
	CMV_InputMap(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMV_InputMap)
	enum { IDD = IDD_INPUT_MAP_DLG };
	CEdit	m_EditMapName;
	//}}AFX_DATA
public:
	CMV_Doc*	m_pDoc;
	CCMVDlg*	m_pCMVDlg;

public:
	void SetDocument(CMV_Doc* pDoc);
	void SetInfoMapDisp(CCMVDlg* pMapDispDlg);
	void LoadMapEvent(void);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_InputMap)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMV_InputMap)
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnOk();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_INPUTMAP_H__FD7AF90F_957B_4634_8055_D91E9E04BCB8__INCLUDED_)

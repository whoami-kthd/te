// CMV_MapInfo.cpp : implementation file
//

#include "stdafx.h"
#include "cmv.h"
#include "CMV_MapInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// Defined for column width of grid control
static long m_arrInfoColWidth[] = {
  //Tool Pitch		Tool Index		LED Pitch	     LED Size	      Index	
	40, 20, 40, 10,	40, 20, 35, 10,	40, 20, 35, 10,  40, 20, 35, 10,  40, 20, 35,
	40, 20, 40, 10,	40, 20, 35, 10,	40, 20, 35, 10,  40, 20, 35, 10,  40, 20, 35
};


#define DBLE_INFO_CELL_HEIGTH				23
#define DBLE_EDITWND_MINSCALE				1.0

// Define warning message
#define WARNING_MESSAGE_OUTOFRANGE			_T("Your input is out of limit range! \n Do you want to re-input?")

/////////////////////////////////////////////////////////////////////////////
// CMV_MapInfo


IMPLEMENT_DYNCREATE(CMV_MapInfo, CEditView)

CMV_MapInfo::CMV_MapInfo()
{
}

CMV_MapInfo::~CMV_MapInfo()
{
}


BEGIN_MESSAGE_MAP(CMV_MapInfo, CView)
	ON_WM_CREATE()
	ON_WM_LBUTTONDOWN()
	ON_MESSAGE(WM_UPDATE_CELL, OnUpdateGrid)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_MapInfo drawing

void CMV_MapInfo::OnDraw(CDC* pDC)
{
	UpdateGridData();
}

/////////////////////////////////////////////////////////////////////////////
// CMV_MapInfo diagnostics

#ifdef _DEBUG
void CMV_MapInfo::AssertValid() const
{
	CView::AssertValid();
}

void CMV_MapInfo::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_MapInfo message handlers
void CMV_MapInfo::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}

int CMV_MapInfo::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if(CView::OnCreate(lpCreateStruct) == -1) return -1;
	
	CRect rc;
	this->GetWindowRect(rc);
	ScreenToClient(&rc);

	m_pGridCtrl = new CMV_GridCtrl(2, 19);
	m_pGridCtrl->Create(rc, this, m_pDoc);

	// Get data
	InitGridCtrl();
	UpdateGridData();

	m_UpdateIndex = FALSE;
	m_UpdateIndex1 = FALSE;
	return 0;
}


void CMV_MapInfo::InitGridCtrl()
{
	// Set width for all cols
	for(UINT idx = 0; idx < ARRAY_LENGTH(m_arrInfoColWidth); idx ++){
		m_pGridCtrl->SetColWidth(idx, m_arrInfoColWidth[idx]);
	}

	// Set height for all row
	for(int row = 0; row < m_pGridCtrl->GetRows(); row ++){
		m_pGridCtrl->SetRowHeight(row, DBLE_INFO_CELL_HEIGTH);
	}

	// Set merge for some rows and cols
	m_pGridCtrl->MergeCell(0, 0, 1, 0);
	m_pGridCtrl->MergeCell(0, 4, 1, 4);
	m_pGridCtrl->MergeCell(0, 8, 1, 8);
	m_pGridCtrl->MergeCell(0, 12, 1, 12);
	m_pGridCtrl->MergeCell(0, 16, 1, 16);
	
	// Set invisible for some cols
	m_pGridCtrl->SetColInvisible(3);
	m_pGridCtrl->SetColInvisible(7);
	m_pGridCtrl->SetColInvisible(11);
	m_pGridCtrl->SetColInvisible(15);
	
	// Set type for some cols
	m_pGridCtrl->SetColType(3, DCMV_CELL_DOUBLE);		// Tool Pitch X
	m_pGridCtrl->SetColType(3, DCMV_CELL_DOUBLE);		// Tool Pitch Y

	m_pGridCtrl->SetColType(7, DCMV_CELL_INT);			// Tool Index X
	m_pGridCtrl->SetColType(7, DCMV_CELL_INT);			// Tool Index Y

	m_pGridCtrl->SetColType(11, DCMV_CELL_DOUBLE);		// LED Pitch X
	m_pGridCtrl->SetColType(11, DCMV_CELL_DOUBLE);		// LED Pitch Y

	m_pGridCtrl->SetColType(15, DCMV_CELL_DOUBLE);		// LED Size X
	m_pGridCtrl->SetColType(15, DCMV_CELL_DOUBLE);		// LED Size Y

	m_pGridCtrl->SetColType(19, DCMV_CELL_DOUBLE);		// Index X
	m_pGridCtrl->SetColType(19, DCMV_CELL_DOUBLE);		// Index Y

	// Set header for all collumn except two cells of IC index
	m_pGridCtrl->SetRowHeader(0);
	m_pGridCtrl->SetRowHeader(1);
	m_pGridCtrl->GetCell(0, 18)->SetHeader(false);
	m_pGridCtrl->GetCell(1, 18)->SetHeader(false);

	// Set text
	m_pGridCtrl->SetCellText(0, 0, _T("Tool Pitch [mm]"));
	m_pGridCtrl->SetCellText(0, 1, _T("X"));
	m_pGridCtrl->SetCellText(1, 1, _T("Y"));

	m_pGridCtrl->SetCellText(0, 4, _T("Tool Index")); 
	m_pGridCtrl->SetCellText(0, 5, _T("X")); 
	m_pGridCtrl->SetCellText(1, 5, _T("Y")); 

	m_pGridCtrl->SetCellText(0, 8, _T("LED Pitch [mm]"));
	m_pGridCtrl->SetCellText(0, 9, _T("X"));
	m_pGridCtrl->SetCellText(1, 9, _T("Y"));

	m_pGridCtrl->SetCellText(0, 12, _T("LED Size [mm]"));
	m_pGridCtrl->SetCellText(0, 13, _T("X"));
	m_pGridCtrl->SetCellText(1, 13, _T("Y"));

	m_pGridCtrl->SetCellText(0, 16, _T("Index"));
	m_pGridCtrl->SetCellText(0, 17, _T("X"));
	m_pGridCtrl->SetCellText(1, 17, _T("Y"));

}


void CMV_MapInfo::UpdateGridData()
{
	CString strTmp;

	if(m_pDoc->m_IsDispJumpInTab == TRUE)
	{
		if((m_pDoc->m_JumpX >= 0) && (m_pDoc->m_JumpY >= 0)) {
			strTmp.Format(_T("%d"), m_pDoc->m_JumpX);
			m_pGridCtrl->SetCellText(0, 18, strTmp);

			strTmp.Format(_T("%d"), m_pDoc->m_JumpY);
			m_pGridCtrl->SetCellText(1, 18, strTmp);
		}

		m_pDoc->m_IsDispJumpInTab = FALSE;
	}
	else{
		if(!m_UpdateIndex){		// Index X information
			m_pGridCtrl->SetCellText(0, 18, _T(""));
		}else{
			if(m_pDoc->m_JumpX >= 0) {
				strTmp.Format(_T("%d"), m_pDoc->m_JumpX);
				m_pGridCtrl->SetCellText(0, 18, strTmp);
			}
		}

		if(!m_UpdateIndex1){	// Index Y information
			m_pGridCtrl->SetCellText(1, 18, _T(""));
		}else{
			if(m_pDoc->m_JumpY >= 0) {
				strTmp.Format(_T("%d"), m_pDoc->m_JumpY);
				m_pGridCtrl->SetCellText(1, 18, strTmp);
			}
		}
	}

	// Tool Pitch X
	strTmp.Format(_T("%.2f"), m_pDoc->m_dispToolPitchX);
	m_pGridCtrl->SetCellText(0, 2, strTmp);
	// Tool Pitch Y
	strTmp.Format(_T("%.2f"), m_pDoc->m_dispToolPitchY);
	m_pGridCtrl->SetCellText(1, 2, strTmp);

	// Tool Index X
	strTmp.Format(_T("%d"), m_pDoc->m_dispToolIndexX);
	m_pGridCtrl->SetCellText(0, 6, strTmp);
	// Tool Index Y
	strTmp.Format(_T("%d"), m_pDoc->m_dispToolIndexY);
	m_pGridCtrl->SetCellText(1, 6, strTmp);

	// LED Pitch X
	strTmp.Format(_T("%.2f"), m_pDoc->m_dispLEDPitchX);
	m_pGridCtrl->SetCellText(0, 10, strTmp);
	// LED Pitch Y
	strTmp.Format(_T("%.2f"), m_pDoc->m_dispLEDPitchY);
	m_pGridCtrl->SetCellText(1, 10, strTmp);

	// LED Size X
	strTmp.Format(_T("%.2f"), m_pDoc->m_dispLEDSizeX);
	m_pGridCtrl->SetCellText(0, 14, strTmp);
	// LED Size Y
	strTmp.Format(_T("%.2f"), m_pDoc->m_dispLEDSizeY);
	m_pGridCtrl->SetCellText(1, 14, strTmp);
}


/* 
* Change focus when select a cell on info window
*/
void CMV_MapInfo::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_KeyWnd.SetReceiveKeyWindow(GetEditWnd());
}


CWnd* CMV_MapInfo::GetEditWnd()
{
	return m_pGridCtrl->GetEditWnd();
}


// Check input value
LRESULT CMV_MapInfo::OnUpdateGrid(WPARAM wParam, LPARAM lParam)
{
	long row = m_pGridCtrl->GetRowSel();
	long col = m_pGridCtrl->GetColSel();
	if((row == -1) || (col == -1)) return 0;
	CString tmpText = m_pGridCtrl->GetCellText(row, col);
	int value = atoi(tmpText);
	if (col == 18) {
		if (value < 0 || value > 300) {
			int nType = AfxMessageBox(WARNING_MESSAGE_OUTOFRANGE, MB_YESNO/* | MB_ICONQUESTION */);		// Message: input is not correct
			if (nType == IDYES) {								// Re-input
				m_pGridCtrl->GetCell(row, col)->SetText(_T(""), false);
				m_pGridCtrl->ShowEditBox();
				return 0;
			} else {
				m_pGridCtrl->SetCellText(row, col, _T(""));
			}
		}

		if(row == 0){
			m_pDoc->m_JumpX = value;
			m_UpdateIndex = TRUE;
		}
		else{
			m_pDoc->m_JumpY = value;
			m_UpdateIndex1 = TRUE;
		}
	}

	m_pGridCtrl->Deselect();
	AfxGetApp()->m_pMainWnd->Invalidate(TRUE);
	UpdateWindow();

	return 0;
}
#if !defined(AFX_CMV_MAPINFO_H__F9F06106_C9D3_47C7_BDD6_20FD88A63A12__INCLUDED_)
#define AFX_CMV_MAPINFO_H__F9F06106_C9D3_47C7_BDD6_20FD88A63A12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CMV_MapInfo.h : header file
//

#include "CMV_Doc.h"
#include "MemDC.h"
#include "CMV_EditJump.h"
#include "CMV_GridCtrl.h"
#include "CMV_NumKeyWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CMV_MapInfo view

class CMV_MapInfo : public CView
{
public:
	CMV_MapInfo();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMV_MapInfo)

// Attributes
public:
	CMV_Doc*		m_pDoc;
	CMV_GridCtrl*	m_pGridCtrl;
	CMV_NumKeyWnd	m_KeyWnd;
	// Edit box
	CMV_EditCtrl	m_Edit;

	BOOL			m_UpdateIndex;
	BOOL			m_UpdateIndex1;

// Operations
public:
	void SetDocument(CMV_Doc* pDoc);
	void UpdateGridData();
	void InitGridCtrl();
	CWnd* GetEditWnd();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMV_MapInfo)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMV_MapInfo();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	//{{AFX_MSG(CMV_MapInfo)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg LRESULT OnUpdateGrid(WPARAM wParam, LPARAM lParam); // Response when press a key in keyboard
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMV_MapInfo_H__F9F06106_C9D3_47C7_BDD6_20FD88A63A12__INCLUDED_)

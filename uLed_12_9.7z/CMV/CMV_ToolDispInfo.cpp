// CMV_ToolDispInfo.cpp : implementation file
//

#include "stdafx.h"
#include "CMV.h"
#include "CMV_ToolDispInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMV_ToolDispInfo

IMPLEMENT_DYNCREATE(CMV_ToolDispInfo, CView)

CMV_ToolDispInfo::CMV_ToolDispInfo()
{
}

CMV_ToolDispInfo::~CMV_ToolDispInfo()
{
}


BEGIN_MESSAGE_MAP(CMV_ToolDispInfo, CView)
	//{{AFX_MSG_MAP(CMV_ToolDispInfo)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMV_ToolDispInfo drawing

void CMV_ToolDispInfo::OnDraw(CDC* pDC)
{
	CRect rc;
	GetClientRect(&rc);
	CPen pen(PS_SOLID, 1, RGB(80, 80, 80) );
	pDC->SelectObject(&pen);

	CFont myFontTool;
	myFontTool.CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));
	pDC->SelectObject(&myFontTool);

	pDC->FillSolidRect(rc, (::GetSysColor(COLOR_BTNFACE)));

	// size unit
	int xSizeUnit = (rc.right - rc.left)/10;
	int ySizeUnit = (rc.bottom - rc.top)/3;

	DrawToolLEDInfoTable(pDC, rc, xSizeUnit, ySizeUnit);

	WriteToolInfo(pDC, rc,xSizeUnit, ySizeUnit);
	WriteLEDInfo(pDC, rc, xSizeUnit, ySizeUnit);
}

/////////////////////////////////////////////////////////////////////////////
// CMV_ToolDispInfo diagnostics

#ifdef _DEBUG
void CMV_ToolDispInfo::AssertValid() const
{
	CView::AssertValid();
}

void CMV_ToolDispInfo::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMV_ToolDispInfo message handlers

void CMV_ToolDispInfo::SetDocument(CMV_Doc* pDoc)
{
	m_pDoc = pDoc;
}


void CMV_ToolDispInfo::DrawToolLEDInfoTable(CDC* pDC, CRect rc, int xSizeUnit, int ySizeUnit)
{
	GetClientRect(&rc);
	CPen pen(PS_SOLID, 1, RGB(80, 80, 80) );
	pDC->SelectObject(&pen);

	CFont myFontTool;
	myFontTool.CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));
	pDC->SelectObject(&myFontTool);

	/* Draw table of Tool/LED info (S) */
	// Draw edge of table
	pDC->MoveTo(rc.left, rc.bottom);
	pDC->LineTo(rc.right, rc.bottom);
	pDC->MoveTo(rc.left, rc.top);
	pDC->LineTo(rc.right, rc.top);
	pDC->MoveTo(rc.left, rc.top);
	pDC->LineTo(rc.left, rc.bottom);
	pDC->MoveTo(rc.right, rc.top);
	pDC->LineTo(rc.right, rc.bottom);

	/* Draw vertical lines */
	pDC->MoveTo(rc.left+xSizeUnit, rc.top);
	pDC->LineTo(rc.left+xSizeUnit, rc.bottom);

	//XY
	pDC->MoveTo(rc.left+2*xSizeUnit-4, rc.top+ySizeUnit);
	pDC->LineTo(rc.left+2*xSizeUnit-4, rc.bottom);

	pDC->MoveTo(rc.left+3*xSizeUnit, rc.top);
	pDC->LineTo(rc.left+3*xSizeUnit, rc.bottom);

	pDC->MoveTo(rc.left+4*xSizeUnit-4, rc.top+ySizeUnit);
	pDC->LineTo(rc.left+4*xSizeUnit-4, rc.bottom);

	//LED
	pDC->MoveTo(rc.left+5*xSizeUnit, rc.top);
	pDC->LineTo(rc.left+5*xSizeUnit, rc.bottom);

	pDC->MoveTo(rc.left+6*xSizeUnit, rc.top);
	pDC->LineTo(rc.left+6*xSizeUnit, rc.bottom);

	//XY
	pDC->MoveTo(rc.left+7*xSizeUnit-4, rc.top+ySizeUnit);
	pDC->LineTo(rc.left+7*xSizeUnit-4, rc.bottom);

	pDC->MoveTo(rc.left+8*xSizeUnit, rc.top);
	pDC->LineTo(rc.left+8*xSizeUnit, rc.bottom);

	pDC->MoveTo(rc.left+9*xSizeUnit-4, rc.top+ySizeUnit);
	pDC->LineTo(rc.left+9*xSizeUnit-4, rc.bottom);

	/* Draw horizonal lines */

	pDC->MoveTo(rc.left+xSizeUnit, rc.top+ySizeUnit);
	pDC->LineTo(rc.left+5*xSizeUnit, rc.top+ySizeUnit);

	pDC->MoveTo(rc.left+6*xSizeUnit, rc.top+ySizeUnit);
	pDC->LineTo(rc.right, rc.top+ySizeUnit);

	pDC->MoveTo(rc.left+xSizeUnit, rc.top+2*ySizeUnit);
	pDC->LineTo(rc.left+5*xSizeUnit, rc.top+2*ySizeUnit);

	pDC->MoveTo(rc.left+6*xSizeUnit, rc.top+2*ySizeUnit);
	pDC->LineTo(rc.right, rc.top+2*ySizeUnit);

	/* Draw table of Tool/LED info (E) */

	CRect WriteRect;
	/* Draw text in each cell (S) */
	WriteRect.top = rc.top;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left;
	WriteRect.right = rc.left+ xSizeUnit;
	pDC->DrawText(_T("Tool"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top;
	WriteRect.bottom = rc.top + ySizeUnit;
	WriteRect.left = rc.left + xSizeUnit;
	WriteRect.right = rc.left+ 3*xSizeUnit;
	pDC->DrawText(_T("Pitch"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top;
	WriteRect.bottom = rc.top + ySizeUnit;
	WriteRect.left = rc.left + 3*xSizeUnit;
	WriteRect.right = rc.left+ 5*xSizeUnit;
	pDC->DrawText(_T("Index"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + ySizeUnit;
	WriteRect.bottom = rc.top + 2*ySizeUnit;
	WriteRect.left = rc.left + xSizeUnit;
	WriteRect.right = rc.left+ 2*xSizeUnit;
	pDC->DrawText(_T("X"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + 2*ySizeUnit;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + xSizeUnit;
	WriteRect.right = rc.left+ 2*xSizeUnit;
	pDC->DrawText(_T("Y"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + ySizeUnit;
	WriteRect.bottom = rc.top + 2*ySizeUnit;
	WriteRect.left = rc.left + 3*xSizeUnit;
	WriteRect.right = rc.left+ 4*xSizeUnit;
	pDC->DrawText(_T("X"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + 2*ySizeUnit;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + 3*xSizeUnit;
	WriteRect.right = rc.left+ 4*xSizeUnit;
	pDC->DrawText(_T("Y"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + 5*xSizeUnit;
	WriteRect.right = rc.left+ 6*xSizeUnit;
	pDC->DrawText(_T("LED"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top;
	WriteRect.bottom = rc.top + ySizeUnit;
	WriteRect.left = rc.left + 6*xSizeUnit;
	WriteRect.right = rc.left+ 8*xSizeUnit;
	pDC->DrawText(_T("Pitch"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top;
	WriteRect.bottom = rc.top + ySizeUnit;
	WriteRect.left = rc.left + 8*xSizeUnit;
	WriteRect.right = rc.right;
	pDC->DrawText(_T("Size"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + ySizeUnit;
	WriteRect.bottom = rc.top + 2*ySizeUnit;
	WriteRect.left = rc.left + 6*xSizeUnit;
	WriteRect.right = rc.left+ 7*xSizeUnit;
	pDC->DrawText(_T("X"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + 2*ySizeUnit;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + 6*xSizeUnit;
	WriteRect.right = rc.left+ 7*xSizeUnit;
	pDC->DrawText(_T("Y"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + ySizeUnit;
	WriteRect.bottom = rc.top + 2*ySizeUnit;
	WriteRect.left = rc.left + 8*xSizeUnit;
	WriteRect.right = rc.left+ 9*xSizeUnit;
	pDC->DrawText(_T("X"), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + 2*ySizeUnit;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + 8*xSizeUnit;
	WriteRect.right = rc.left+ 9*xSizeUnit;
	pDC->DrawText(_T("Y"), &WriteRect, m_pDoc->m_nFormat);
	/* Draw text in each cell (E) */
}

void CMV_ToolDispInfo::WriteToolInfo(CDC* pDC, CRect rc, int xSizeUnit, int ySizeUnit)
{
	GetClientRect(&rc);
	CRect WriteRect;
	CString text;
	CPen pen(PS_SOLID, 1, RGB(80, 80, 80) );
	pDC->SelectObject(&pen);

	CFont myFontTool;
	myFontTool.CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));
	pDC->SelectObject(&myFontTool);
	
	WriteRect.top = rc.top + ySizeUnit;
	WriteRect.bottom = rc.top + 2*ySizeUnit;
	WriteRect.left = rc.left + 2*xSizeUnit;
	WriteRect.right = rc.left+ 3*xSizeUnit;
	text.Format(_T("%.2f"), m_pDoc->m_dispToolPitchX);
	pDC->DrawText(_T(text), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + 2*ySizeUnit;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + 2*xSizeUnit;
	WriteRect.right = rc.left+ 3*xSizeUnit;
	text.Format(_T("%.2f"), m_pDoc->m_dispToolPitchY);
	pDC->DrawText(_T(text), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + ySizeUnit;
	WriteRect.bottom = rc.top + 2*ySizeUnit;
	WriteRect.left = rc.left + 4*xSizeUnit;
	WriteRect.right = rc.left+ 5*xSizeUnit;
	text.Format(_T("%d"), m_pDoc->m_dispToolIndexX);
	pDC->DrawText(_T(text), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + 2*ySizeUnit;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + 4*xSizeUnit;
	WriteRect.right = rc.left+ 5*xSizeUnit;
	text.Format(_T("%d"), m_pDoc->m_dispToolIndexY);
	pDC->DrawText(_T(text), &WriteRect, m_pDoc->m_nFormat);
}


void CMV_ToolDispInfo::WriteLEDInfo(CDC* pDC, CRect rc, int xSizeUnit, int ySizeUnit)
{
	GetClientRect(&rc);
	CRect WriteRect;
	CString text;

	CFont myFontTool;
	myFontTool.CreateFont(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, 0,
	SHIFTJIS_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
	DEFAULT_QUALITY, FIXED_PITCH | FF_MODERN,_T("�l�r �S�V�b�N"));
	pDC->SelectObject(&myFontTool);

	WriteRect.top = rc.top + ySizeUnit;
	WriteRect.bottom = rc.top + 2*ySizeUnit;
	WriteRect.left = rc.left + 7*xSizeUnit;
	WriteRect.right = rc.left+ 8*xSizeUnit;
	text.Format(_T("%.2f"), m_pDoc->m_dispLEDPitchX);
	pDC->DrawText(_T(text), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + 2*ySizeUnit;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + 7*xSizeUnit;
	WriteRect.right = rc.left+ 8*xSizeUnit;
	text.Format(_T("%.2f"), m_pDoc->m_dispLEDPitchY);
	pDC->DrawText(_T(text), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + ySizeUnit;
	WriteRect.bottom = rc.top + 2*ySizeUnit;
	WriteRect.left = rc.left + 9*xSizeUnit;
	WriteRect.right = rc.right;
	text.Format(_T("%.2f"), m_pDoc->m_dispLEDSizeX);
	pDC->DrawText(_T(text), &WriteRect, m_pDoc->m_nFormat);

	WriteRect.top = rc.top + 2*ySizeUnit;
	WriteRect.bottom = rc.bottom;
	WriteRect.left = rc.left + 9*xSizeUnit;
	WriteRect.right = rc.right;
	text.Format(_T("%.2f"), m_pDoc->m_dispLEDSizeY);
	pDC->DrawText(_T(text), &WriteRect, m_pDoc->m_nFormat);
}
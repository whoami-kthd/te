///////////////////////////////////////////////////////////
//  pos.h
//  Created on:      2013-07-29
//  Original author: ducdt
///////////////////////////////////////////////////////////
#ifndef	pos_h
#define	pos_h
#include	<math.h>
#define	PI  3.141592653589793
#define	DEG_RAD	(PI/180.0)
#define	RAD_DEG	(180.0/PI)
struct	P2PosS;
class	P2Pos;

struct R2PosS
{
	double	x;		// X���ް�
	double	y;		// Y���ް�
};

class R2Pos	: public  R2PosS
{	
public:
	R2Pos(){					
		R2Pos::x = 0;
		R2Pos::y = 0;
	}
	R2Pos(int x,int y){	
		R2Pos::x = x;
		R2Pos::y = y;
	}
	R2Pos(double x,double y){	
		R2Pos::x = x;
		R2Pos::y = y;
	}
	R2Pos(const R2Pos& RP){			
		R2Pos::x = RP.x;		
		R2Pos::y = RP.y;
	}
	R2Pos(const R2PosS& RP){		
		R2Pos::x = RP.x;		
		R2Pos::y = RP.y;
	}
	R2Pos(const P2Pos& PP);
	
	
	inline R2Pos 	operator-() const				{	return	R2Pos(-x,-y);		}			
	inline R2Pos 	operator+(const R2Pos& p) const	{	return	R2Pos(x+p.x,y+p.y);	}	
	inline R2Pos 	operator-(const R2Pos& p) const	{	return	R2Pos(x-p.x,y-p.y);	}	
	inline R2Pos 	operator*(double k) const		{	return	R2Pos(x*k,y*k);		}		
	inline R2Pos 	operator/(double k) const		{	return	R2Pos(x/k,y/k);		}		
	inline R2Pos& 	operator+=(const R2Pos& p)	{
		x += p.x;
		y += p.y;
		return	*this;	
	}
	inline R2Pos& 	operator-=(const R2Pos& p){
		x -= p.x;
		y -= p.y;
		return	*this;	
	}
	inline R2Pos 	operator*=(double k)	
	{
		x *= k;
		y *= k;
		return	*this;	
	}		
	inline R2Pos 	operator/=(double k)	
	{
		x /= k;
		y /= k;
		return	*this;	
	}		
	inline R2Pos& 	operator=(const R2PosS& p){
		x=p.x;
		y=p.y;
		return	*this;
	}	
	inline R2Pos 	operator+(const R2PosS& p) const	{	return	R2Pos(x+p.x,y+p.y);	}	
	inline R2Pos 	operator-(const R2PosS& p) const	{	return	R2Pos(x-p.x,y-p.y);	}	
	inline R2Pos& 	operator+=(const R2PosS& p){
		x += p.x;
		y += p.y;
		return	*this;	
	}
	inline R2Pos& 	operator-=(const R2PosS& p){
		x -= p.x;
		y -= p.y;
		return	*this;	
	}
	
	inline R2Pos& 	operator=(const P2Pos& PP);
	inline R2Pos 	operator+(const P2Pos& PP) const;
	inline int 	operator==(const R2Pos& p) const{	return	((x == p.x)&&(y == p.y));}
	inline int 	operator==(const R2PosS& p) const{	return	((x == p.x)&&(y == p.y));}
	inline int 	operator!=(const R2Pos& p) const{	return	((x != p.x)||(y != p.y));}
	inline int 	operator!=(const R2PosS& p) const{	return	((x != p.x)||(y != p.y));}
	inline int 	operator<(const R2Pos& p) const{	return	((x <  p.x)&&(y <  p.y));}
	inline int 	operator<<(const R2Pos& p) const{	return	((x <  p.x)||(y <  p.y));}
	inline int 	operator<=(const R2Pos& p) const{	return	((x <= p.x)&&(y <= p.y));}
	inline int 	operator<<=(const R2Pos& p) const{	return	((x <= p.x)||(y <= p.y));}
	inline int 	operator>(const R2Pos& p) const{	return	((x >  p.x)&&(y >  p.y));}
	inline int 	operator>>(const R2Pos& p) const{	return	((x >  p.x)||(y >  p.y));}
	inline int 	operator>=(const R2Pos& p) const{	return	((x >= p.x)&&(y >= p.y));}
	inline int 	operator>>=(const R2Pos& p) const{	return	((x >= p.x)||(y >= p.y));}
	
	double	T() const;
	inline double	L() const{return	::sqrt(x * x + y * y);}
	inline double	L(const R2Pos& o) const{		return	::sqrt((x-o.x)*(x-o.x)+(y-o.y)*(y-o.y));}
	inline double	L(double ox,double oy) const{	return	::sqrt((x-ox)*(x-ox)+(y-oy)*(y-oy));}
	inline double	L(const R2PosS& o) const{		return	::sqrt((x-o.x)*(x-o.x)+(y-o.y)*(y-o.y));}
	inline double&	X() {return	x;}						// X
	inline double&	Y() {return	y;}						// Y
	void	Conv(const R2Pos& Po,double S,double C,const R2Pos& Ps);
	void	Conv(const R2Pos& Po,double T,const R2Pos& Ps);
	void	Conv(double f11,double f12,double f21,double f22,int n=1);
};
#endif
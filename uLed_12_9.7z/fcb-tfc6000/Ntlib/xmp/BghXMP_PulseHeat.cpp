#if !ZMP_BOARD

#include	<afxmt.h>
#include	<stdio.h>
#include	<semaxx.h>                        
#include	<XMPCtrl.h>                     
#include	<swatchd.h>
#include	<pos.h>

#include	<stdlib.h>

#include	"stdmpi.h"
#include	"stdmei.h"
#include	"apputil.h"

#include	<bghXMP_define.h>

// ���x�o�͒l�̎擾
double	BGH_XMP::GetTemp(bool outByDegree){
	double	n_Pos = 0.0;
	{
#if GPDEBUG
	return true;
#endif
		long	msg;
		unsigned long position;
		long	lPos;
		//
		msg = mpiAdcInput(H_TempAdc, &position);
		lPos = position;
		//----------------------------
		// �f�W�^���l�ŕԂ�
		if(!outByDegree){
			n_Pos = (double)lPos;
		//----------------------------
		// �ݒ艷�x�ŕԂ�
		}else{
			n_Pos = (double)lPos * this->BGHPara.Heater_a + this->BGHPara.Heater_b;
		}
		//----------------------------
	}
	return n_Pos;
}

#endif


#include <afxwin.h>
#include "DebugWnd.h"

#include "Mc/DEFS/Bnd.h"
#include "Mc/COM/DisplaceSensor.h"
#include "LaserOMRONComm.h"

#define BUTTONW 200
#define BUTTONH 40

#define IDC_DEBUG_LIST  4000
#define IDC_DEBUG_EDIT  4001
#define ID_DEBUG_BUTTON 4010

/////////////////////////////////////////////////////////////////////////

BEGIN_MESSAGE_MAP (CDebugWnd, CWnd)
    ON_WM_PAINT ()
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_DEBUG_LIST, OnCustomDraw)
	ON_NOTIFY(LVN_GETDISPINFO,IDC_DEBUG_LIST, OnGetDispInfo)
	ON_COMMAND_RANGE (ID_DEBUG_BUTTON, ID_DEBUG_BUTTON+BUTTONS, OnButtonClick)
END_MESSAGE_MAP ()

struct MT{
	int		uid;		// �Ư�ID
	int		mid;		// Ӱ��ID
	int		exist;		// ���[�^
	char	*mnames[2];	//	Ӱ������ 
	int		unit;		// �P�ʁ@0:mm 1:�x
	double	*pOffset;	// ���_�I�t�Z�b�g
	double	*pMSLimit;	// -�\�t�g���~�b�g
	double	*pPSLimit;	// +�\�t�g���~�b�g
};

CDebugWnd::CDebugWnd (MCCtrl* p,bool show)
:m_pMCC(p),m_activeView(NULL)
{
  	::ZeroMemory(m_MTTBL_EXISTS,sizeof(m_MTTBL_EXISTS));
  	
    CString strWndClass = AfxRegisterWndClass (
        CS_DBLCLKS,										
        AfxGetApp ()->LoadStandardCursor (IDC_ARROW),   
        (HBRUSH) (COLOR_3DFACE + 1),					
        AfxGetApp ()->LoadStandardIcon (IDI_WINLOGO)	
    );

    CreateEx (0, strWndClass, _T ("DebugWnd"),
        WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_THICKFRAME,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        NULL, NULL);

    CRect rect (0, 0, 800, 610);
	CalcWindowRect (&rect);

    SetWindowPos (NULL, 0, 0, rect.Width (), rect.Height (),
        SWP_NOZORDER | SWP_NOMOVE | SWP_NOREDRAW);

	if(show)
	{
		ShowWindow (SW_SHOW);
		UpdateWindow ();
	}
}

int CDebugWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	CRect rectList(0,0,800,600);
	
	rectList.bottom -=40;
	m_list.CreateEx(
		LVS_EX_GRIDLINES|LVS_EX_HEADERDRAGDROP|LVS_EX_FULLROWSELECT,
		"SysListView32","",
		WS_CHILDWINDOW|WS_VISIBLE|WS_TABSTOP|LVS_REPORT|LVS_OWNERDATA,
		rectList,this,IDC_DEBUG_LIST,NULL);
	m_list.SetItemCount(64);
	
	m_edit.CreateEx(
		0,
		"EDIT","",
		WS_CHILDWINDOW|WS_VSCROLL|ES_MULTILINE,
		rectList,this,IDC_DEBUG_EDIT,NULL);

	CreateStatusBar();
	CreateButtons();

	ListInit();
	
	m_activeView = &m_list;
	
	if(m_pMCC == NULL) return 0;
	bool StgTlt	= (m_pMCC->SD.Component.stageTilt) ? 1 : 0;					// �ð��Tilt�Ư�
	bool BDSBad	= (m_pMCC->SD.Component.hasBadMarkCamStage) ? 1 : 0;			// BDS�s�Ǌ���o�J�����X�e�[�W
	bool FEEDCNV= 0;
	if (eFeedUnit_Conveyor == m_pMCC->SD.Component.feedUnit) {
		FEEDCNV =  1;	// �������j�b�g���:�R���x�A+�t�B�[�_�v�b�V��
	}
	bool WFUNIT	= 0;
	if(m_pMCC->SD.Component.icSupplyUnit){
		WFUNIT = 1;
	}
	bool RAIL_L(m_pMCC->SD.Component.railLR[0]==1);
	bool RAIL_R(m_pMCC->SD.Component.railLR[1]==1);

	bool EJECT1(m_pMCC->SD.Component.ejectAxises[0]==1);
	bool EJECT2(m_pMCC->SD.Component.ejectAxises[1]==1);
	bool EJECT3(m_pMCC->SD.Component.ejectAxises[2]==1);
	bool EJECT4(m_pMCC->SD.Component.ejectAxises[3]==1);
	bool EJECTY(m_pMCC->SD.Component.ejectAxises[4]==1);
///	bool LIFTPIN=(eFeedUnit_RobotArm == m_pMCC->SD.Component.feedUnit) ? true : false;
	bool LIFTPIN=(m_pMCC->BDS.HasALiftPin()) ? true : false;
	if(LIFTPIN){
		// ���̉�ʂɂ���Ԃ̓��t�g�s������������
		m_pMCC->BDS.SyncLiftPinAxis(false);
	}
// #YS130624-01(S) [�ǉ�]���[�_�A�����[�_�Ή�
	bool LDUNIT	= 0;
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
	bool SMLDUNIT = 0;
	if( m_pMCC->GetLDUnit() == 1 ){
		LDUNIT = 1;
	}
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
	if( m_pMCC->GetLDUnit() == 2 ){
		SMLDUNIT = 1;
	}
	bool UDUNIT	= 0;
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
	bool SMUDUNIT = 0;
	if( m_pMCC->GetUDUnit() == 1 ){
		UDUNIT = 1;
	}
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
	if( m_pMCC->GetUDUnit() == 2 ){
		SMUDUNIT = 1;
	}

	s_limitPara					*pBGHLim = m_pMCC->BND.bond.pLmtPara;
	s_OriginPara				*pOrg	 = m_pMCC->BND.bond.pOrgPara;
	BNDCtrl::MC_Data::MtrData	*pBNDMtr = &m_pMCC->BND.MD.MtrD;
	BDSCtrl::MC_Data::MtrData	*pBDSMtr = &m_pMCC->BDS.MD.MtrD;
	ICSCtrl::MC_Data::MtrData	*pICSMtr = &m_pMCC->ICS.MD.MtrD;

	static MT MTTBL[]={
/* 0*/		{BND_ID, BNDCtrl::HXI,	  1,		{"ͯ��  X��",		"Head X-axis"},			0, &pBNDMtr->OrgOffset[BNDCtrl::HXI],	&pBNDMtr->Limit[BNDCtrl::HXI][0],	&pBNDMtr->Limit[BNDCtrl::HXI][1]},		// B'gͯ��X��
/* 1*/		{BND_ID, BNDCtrl::HYI,	  1,		{"ͯ��  Y��",		"Head Y-axis"},			0, &pBNDMtr->OrgOffset[BNDCtrl::HYI],	&pBNDMtr->Limit[BNDCtrl::HYI][0],	&pBNDMtr->Limit[BNDCtrl::HYI][1]},		// B'gͯ��Y��
/* 2*/		{BND_ID, BNDCtrl::HZI,	  1,		{"ͯ��  Z��",		"Head Z-axis"},			0, &pOrg->ZOriginOffset,				&pBGHLim->PML,						&pBGHLim->PPL					},		// B'gͯ��Z��
/* 3*/		{BND_ID, BNDCtrl::HTI,	  1,		{"ͯ�� �Ǝ�",		"Head ��-axis"},		1, &pBNDMtr->OrgOffset[BNDCtrl::HTI],	&pBNDMtr->Limit[BNDCtrl::HTI][0],	&pBNDMtr->Limit[BNDCtrl::HTI][1]},		// B'gͯ�ރƎ�
/* 4*/
/* 5*/
/* 6*/		{BND_ID, BNDCtrl::SXI,	  1, 		{"Bg�ð�� X��",		"Bg Stage X-axis"},		0, &pBNDMtr->OrgOffset[BNDCtrl::SXI],	&pBNDMtr->Limit[BNDCtrl::SXI][0],	&pBNDMtr->Limit[BNDCtrl::SXI][1]},		// B'g�ð�� X��
/* 7*/		{BND_ID, BNDCtrl::SYI,	  1,		{"Bg�ð�� Y��",		"Bg Stage Y-axis"},		0, &pBNDMtr->OrgOffset[BNDCtrl::SYI],	&pBNDMtr->Limit[BNDCtrl::SYI][0],	&pBNDMtr->Limit[BNDCtrl::SYI][1]},		// B'g�ð�� Y��
/* 8*/
/* 9*/		{BND_ID, BNDCtrl::CXI,	  1,		{"���   X��",		"Cam  X-axis"},			0, &pBNDMtr->OrgOffset[BNDCtrl::CXI],	&pBNDMtr->Limit[BNDCtrl::CXI][0],	&pBNDMtr->Limit[BNDCtrl::CXI][1]},		// ���   X��
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*10*/		{BND_ID, BNDCtrl::CYI,	  1,		{"���   Y��",		"Cam  Y-axis"},			0, &pBNDMtr->OrgOffset[BNDCtrl::CYI],	&pBNDMtr->Limit[BNDCtrl::CYI][0],	&pBNDMtr->Limit[BNDCtrl::CYI][1]},		// ���   Y��
/*11*/		{BND_ID, BNDCtrl::CZI,	  1,		{"���   Z��",		"Cam  Z-axis"},			0, &pBNDMtr->OrgOffset[BNDCtrl::CZI],	&pBNDMtr->Limit[BNDCtrl::CZI][0],	&pBNDMtr->Limit[BNDCtrl::CZI][1]},		// ���   Z��
/*12*/
/*13*/
/*14*/
/*15*/
/*16*/
/*17*/		{BND_ID, BNDCtrl::RAL1,	  FEEDCNV,	{"�ð�ޕ��֎�(L)",	"StgRail(L)-axis"},		0, &pBNDMtr->OrgOffset[BNDCtrl::RAL1],	&pBNDMtr->Limit[BNDCtrl::RAL1][0],	&pBNDMtr->Limit[BNDCtrl::RAL1][1]},		// �ð�ޕ��ւ����iL)
/*18*/		{BND_ID, BNDCtrl::RAL2,	  FEEDCNV,	{"�ð�ޕ��֎�(R)",	"StgRail(R)-axis"},		0, &pBNDMtr->OrgOffset[BNDCtrl::RAL1],	&pBNDMtr->Limit[BNDCtrl::RAL1][0],	&pBNDMtr->Limit[BNDCtrl::RAL1][1]},		// �ð�ޕ��ւ����iR)
/*19*/
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*20*/
/*21*/
/*22*/		{BND_ID, BNDCtrl::TZ1I,	  StgTlt,	{"�ð��TiltZ1��",	"StgTilt Z1 axis"},		0, &pBNDMtr->OrgOffset[BNDCtrl::TZ1I],	&pBNDMtr->Limit[BNDCtrl::TZ1I][0],	&pBNDMtr->Limit[BNDCtrl::TZ1I][1]},		// �ð��Tilt Z1��
/*23*/		{BND_ID, BNDCtrl::TZ2I,	  StgTlt,	{"�ð��TiltZ2��",	"StgTilt Z2 axis"},		0, &pBNDMtr->OrgOffset[BNDCtrl::TZ2I],	&pBNDMtr->Limit[BNDCtrl::TZ2I][0],	&pBNDMtr->Limit[BNDCtrl::TZ2I][1]},		// �ð��Tilt Z2��
/*24*/		{BND_ID, BNDCtrl::TZ3I,	  StgTlt,	{"�ð��TiltZ3��",	"StgTilt Z3 axis"},		0, &pBNDMtr->OrgOffset[BNDCtrl::TZ3I],	&pBNDMtr->Limit[BNDCtrl::TZ3I][0],	&pBNDMtr->Limit[BNDCtrl::TZ3I][1]},		// �ð��Tilt Z3��
/*25*/		{BND_ID, BNDCtrl::TZ4I,	  StgTlt,	{"�ð��TiltZ4��",	"StgTilt Z4 axis"},		0, &pBNDMtr->OrgOffset[BNDCtrl::TZ4I],	&pBNDMtr->Limit[BNDCtrl::TZ4I][0],	&pBNDMtr->Limit[BNDCtrl::TZ4I][1]},		// �ð��Tilt Z4��
/*26*/		{BDS_ID, BDSCtrl::FDR_L,  FEEDCNV,	{"̨����߯��������","BringIn Feeder axis"},	0, &pBDSMtr->OrgOffset[BDSCtrl::FDR_L],	&pBDSMtr->Limit[BDSCtrl::FDR_L][0],	&pBDSMtr->Limit[BDSCtrl::FDR_L][1]},	// �{��̨����߯��������
/*27*/		{BDS_ID, BDSCtrl::FDR_R,  FEEDCNV,	{"̨����߯�����o��","CarryOut Feeder axis"},0, &pBDSMtr->OrgOffset[BDSCtrl::FDR_R],	&pBDSMtr->Limit[BDSCtrl::FDR_R][0],	&pBDSMtr->Limit[BDSCtrl::FDR_R][1]},	// �{��̨����߯���r�o��
/*28*/		{BDS_ID, BDSCtrl::CRAL1,  FEEDCNV,	{"���ޱ����(L)��",	"Conveyor-Rail(L)"},	0, &pBDSMtr->OrgOffset[BDSCtrl::CRAL1],	&pBDSMtr->Limit[BDSCtrl::CRAL1][0],	&pBDSMtr->Limit[BDSCtrl::CRAL1][1]},	// ���ޱ���ւ�(L)
/*29*/		{BDS_ID, BDSCtrl::CRAL2,  FEEDCNV,	{"���ޱ����(R)��",	"Conveyor-Rail(R)"},	0, &pBDSMtr->OrgOffset[BDSCtrl::CRAL1],	&pBDSMtr->Limit[BDSCtrl::CRAL1][0],	&pBDSMtr->Limit[BDSCtrl::CRAL1][1]},	// ���ޱ���ւ�(R)
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*30*/		{BDS_ID, BDSCtrl::RAL_L,  RAIL_L,	{"̲��ޕ���(���˰�)","Rail(pre-heat)"},		0, &pBDSMtr->OrgOffset[BDSCtrl::RAL_L],	&pBDSMtr->Limit[BDSCtrl::RAL_L][0],	&pBDSMtr->Limit[BDSCtrl::RAL_L][1]},	// ���ޱ���ւ�(L)
/*31*/		{BDS_ID, BDSCtrl::RAL_R,  RAIL_R,	{"̨��ޕ���(����˰�)","Rail(after-heat)"},	0, &pBDSMtr->OrgOffset[BDSCtrl::RAL_R],	&pBDSMtr->Limit[BDSCtrl::RAL_R][0],	&pBDSMtr->Limit[BDSCtrl::RAL_R][1]},	// ���ޱ���ւ�(R)
/*32*/		{BDS_ID, BDSCtrl::PIN_1,  LIFTPIN,	{"�����ݏ㉺1��","Lift Pin1 Up"},			0, &pBDSMtr->OrgOffset[BDSCtrl::PIN_1],	&pBDSMtr->Limit[BDSCtrl::PIN_1][0],	&pBDSMtr->Limit[BDSCtrl::PIN_1][1]},	// �����ݏ㉺1
/*33*/		{BDS_ID, BDSCtrl::PIN_2,  LIFTPIN,	{"�����ݏ㉺2��","Lift Pin2 Up"},			0, &pBDSMtr->OrgOffset[BDSCtrl::PIN_2],	&pBDSMtr->Limit[BDSCtrl::PIN_2][0],	&pBDSMtr->Limit[BDSCtrl::PIN_2][1]},	// �����ݏ㉺2
/*34*/		{BDS_ID, BDSCtrl::LDELVZ,  LDUNIT,	{"۰�޴��ް�Z��","LD Elevator Z"},			0, &pBDSMtr->OrgOffset[BDSCtrl::LDELVZ],&pBDSMtr->Limit[BDSCtrl::LDELVZ][0],&pBDSMtr->Limit[BDSCtrl::LDELVZ][1]},	// ۰�޴��ް���
/*35*/		{BDS_ID, BDSCtrl::LDELVX,  LDUNIT,	{"۰�޴��ް�X��","LD Elevator X"},			0, &pBDSMtr->OrgOffset[BDSCtrl::LDELVX],&pBDSMtr->Limit[BDSCtrl::LDELVX][0],&pBDSMtr->Limit[BDSCtrl::LDELVX][1]},	// ۰��϶޼�ݕ��o����
/*36*/		{BDS_ID, BDSCtrl::LDSUP,   LDUNIT,	{"۰��϶޼�݋�����","LD M'g Supply axis"},	0, &pBDSMtr->OrgOffset[BDSCtrl::LDSUP],	&pBDSMtr->Limit[BDSCtrl::LDSUP][0],	&pBDSMtr->Limit[BDSCtrl::LDSUP][1]},	// ۰��϶޼�݋�����
/*37*/		{BDS_ID, BDSCtrl::UDELVZ,  UDUNIT,	{"��۰�޴��ް�Z��","UD Elevator Z"},		0, &pBDSMtr->OrgOffset[BDSCtrl::UDELVZ],&pBDSMtr->Limit[BDSCtrl::UDELVZ][0],&pBDSMtr->Limit[BDSCtrl::UDELVZ][1]},	// ��۰�޴��ް���
/*38*/		{BDS_ID, BDSCtrl::UDELVX,  UDUNIT,	{"��۰�޴��ް�X��","UD Elevator X"},		0, &pBDSMtr->OrgOffset[BDSCtrl::UDELVX],&pBDSMtr->Limit[BDSCtrl::UDELVX][0],&pBDSMtr->Limit[BDSCtrl::UDELVX][1]},	// ��۰��϶޼�ݕ��o����
/*39*/		{BDS_ID, BDSCtrl::UDSUP,   UDUNIT,	{"��۰��϶޼�݋�����","UD M'g Supply axis"},0, &pBDSMtr->OrgOffset[BDSCtrl::UDSUP],	&pBDSMtr->Limit[BDSCtrl::UDSUP][0],	&pBDSMtr->Limit[BDSCtrl::UDSUP][1]},	// ��۰��϶޼�݋�����
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*40*/		{BDS_ID, BDSCtrl::CAMY,   BDSBad,	{"�s�Ǌ�����Y","BadMarkCameraY"},		0, &pBDSMtr->OrgOffset[BDSCtrl::CAMY],	&pBDSMtr->Limit[BDSCtrl::CAMY][0],	&pBDSMtr->Limit[BDSCtrl::CAMY][1]},		// �s�Ǌ���o��׽ð��Y��
/*41*/		{ICS_ID, ICSCtrl::SXI,	  WFUNIT,	{"��ʽð��X��",		"Wf Stage X"},			0, &pICSMtr->OrgOffset[ICSCtrl::SXI],	&pICSMtr->Limit[ICSCtrl::SXI][0],	&pICSMtr->Limit[ICSCtrl::SXI][1]},		// ��ʽð��X��
/*42*/		{ICS_ID, ICSCtrl::SYI,	  WFUNIT,	{"��ʽð��Y��",		"Wf Stage Y"},			0, &pICSMtr->OrgOffset[ICSCtrl::SYI],	&pICSMtr->Limit[ICSCtrl::SYI][0],	&pICSMtr->Limit[ICSCtrl::SYI][1]},		// ��ʽð��Y��
/*43*/		{ICS_ID, ICSCtrl::STI,	  WFUNIT,	{"��ʽð�ރƎ�",	"Wf Stage ��"},			1, &pICSMtr->OrgOffset[ICSCtrl::STI],	&pICSMtr->Limit[ICSCtrl::STI][0],	&pICSMtr->Limit[ICSCtrl::STI][1]},		// ��ʽð�ރƎ�
/*44*/
/*45*/
/*46*/
/*47*/
/*48*/
/*49*/
/*50*/
/*51*/
/*52*/
/*53*/
/*54*/
/*55*/
/*56*/
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ� (S)
/*57*/		{BDS_ID, BDSCtrl::MGZL,  SMLDUNIT,	{"۰�޴��ް�Z��","LD Elevator Z"},			0, &pBDSMtr->OrgOffset[BDSCtrl::MGZL],  &pBDSMtr->Limit[BDSCtrl::MGZL][0],  &pBDSMtr->Limit[BDSCtrl::MGZL][1]},		// ۰�޴��ް���
/*58*/		{BDS_ID, BDSCtrl::MGZU,  SMUDUNIT,	{"��۰�޴��ް�Z��","UD Elevator Z"},		0, &pBDSMtr->OrgOffset[BDSCtrl::MGZU],  &pBDSMtr->Limit[BDSCtrl::MGZU][0],  &pBDSMtr->Limit[BDSCtrl::MGZU][1]},		// ��۰�޴��ް���
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ� (E)
	};

	m_pMTTBL = MTTBL;
	m_motors = sizeof(MTTBL)/sizeof(MTTBL[0]);

	SetTimer(IDC_DEBUG_LIST,500,NULL);
	return 0;
}

void CDebugWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	UpdateLayout();		
}

BOOL CDebugWnd::CreateStatusBar()
{
	BOOL Success;
    static UINT nIndicators[] = {
        ID_SEPARATOR,
        ID_SEPARATOR,
        ID_INDICATOR_CAPS,
        ID_INDICATOR_NUM
    };

    Success = m_statusBar.Create(this);
    ASSERT(Success);

    m_statusBar.SetIndicators (nIndicators, 4);
    return Success;
}

BOOL CDebugWnd::UpdateLayout()
{
	CRect clientRect;
	GetClientRect(clientRect);
    m_list.MoveWindow(0,0,clientRect.Width(), (int)(clientRect.Height()*0.8),FALSE);
    
    int columnWidth = 0;
    for(int c = 0;c < m_list.GetHeaderCtrl()->GetItemCount()-1;c++)
    	columnWidth += m_list.GetColumnWidth(c);
    
	m_list.SetColumnWidth(m_list.GetHeaderCtrl()->GetItemCount()-1,clientRect.Width() - columnWidth -25);
	
	m_edit.MoveWindow(0,0,clientRect.Width(), (int)(clientRect.Height()*0.8),FALSE);
	
	CRect listWindowRect;
	m_list.GetWindowRect(listWindowRect);
	m_list.ScreenToClient(listWindowRect);
//	TRACE("(%3d,%3d)-(%3d,%3d)\n",listWindowRect.left,listWindowRect.top,listWindowRect.right,listWindowRect.bottom);
	
	int x,y,w,h;
	for(int i = 0;i < BUTTONS;i++)
	{
		if(i < 5)
		{
			x = 2*i*clientRect.Width()/BUTTONS;
			y = listWindowRect.bottom+5;
			w = 2*clientRect.Width()/BUTTONS;
			h = BUTTONH;
		}else{
			x = 2*(i-5)*clientRect.Width()/BUTTONS;
			y = listWindowRect.bottom+5 + BUTTONH;
			w = 2*clientRect.Width()/BUTTONS;
			h = BUTTONH;
		}
		m_buttons[i].MoveWindow(x,y,w,h,FALSE);
	}

	
	Invalidate();
	return TRUE;
}


BOOL CDebugWnd::CreateButtons()
{
	BOOL Success=TRUE;
	CRect listWindowRect;
	m_list.GetWindowRect(listWindowRect);
	m_list.ScreenToClient(listWindowRect);

	CString caption;
	const int w = BUTTONW;
	const int h = BUTTONH;

	CRect rect(0,listWindowRect.bottom,w,listWindowRect.bottom+h);
	for(int i = 0;i < sizeof(m_buttons)/sizeof(m_buttons[0]) && Success;i++)
	{
		if(i == 0)
			caption.Format("Motor");
		else if(i == 1)
			caption.Format("LaserSensor");
		else if(i <  5)
			caption.Format("");
		else if(i >= 5)
			caption.Format("Debug%d",i-4);
		else ASSERT(!"N/A");

		rect.left   = w*i;
		rect.top    = listWindowRect.bottom + BUTTONS;
		rect.right  = rect.left+w;
		rect.bottom = rect.top+h;

		Success = m_buttons[i].Create(
			caption,
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			rect,this,ID_DEBUG_BUTTON+i);

		ASSERT(Success);
	}
	return Success;
}

void CDebugWnd::UpdateButtonLabel()
{
	CString caption;
	if(m_activeView == &m_list)
	{
		for(int i = 5;i < sizeof(m_buttons)/sizeof(m_buttons[0]);i++)
		{
			caption.Format("Debug%d",i-4);
			m_buttons[i].SetWindowText((LPCTSTR)caption);
		}
	}else
	{
		for(int i = 5;i < sizeof(m_buttons)/sizeof(m_buttons[0]);i++){
			switch(i)
			{
			case 5:
				caption = _T("OPEN");
				break;
			case 6:
				caption = _T("�l�擾");
				break;
			case 7:
				caption = _T("LoggingClear");
				break;
			case 8:
				caption = _T("LoggingStart");
				break;
			case 9:
				caption = _T("LoggingOut");
				break;			
			}
			m_buttons[i].SetWindowText((LPCTSTR)caption);
		}
	}
}

void CDebugWnd::UpdateMTTBL()
{
	bool StgTlt	= (m_pMCC->SD.Component.stageTilt) ? 1 : 0;					// �ð��Tilt�Ư�
	bool BDSBad	= (m_pMCC->SD.Component.hasBadMarkCamStage) ? 1 : 0;			// BDS�s�Ǌ���o�J�����X�e�[�W
	bool FEEDCNV= 0;
	if (eFeedUnit_Conveyor == m_pMCC->SD.Component.feedUnit) {
		FEEDCNV =  1;	// �������j�b�g���:�R���x�A+�t�B�[�_�v�b�V��
	}
	bool WFUNIT	= 0;
	if(m_pMCC->SD.Component.icSupplyUnit){
		WFUNIT = 1;
	}
///	bool LIFTPIN=(eFeedUnit_RobotArm == m_pMCC->SD.Component.feedUnit) ? true : false;
	bool LIFTPIN=(m_pMCC->BDS.HasALiftPin()) ? true : false;
	if(LIFTPIN){
		// ���̉�ʂɂ���Ԃ̓��t�g�s������������
		m_pMCC->BDS.SyncLiftPinAxis(false);
	}
// #YS130624-01(S) [�ǉ�]���[�_�A�����[�_�Ή�
	bool LDUNIT	= 0;
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
	if( m_pMCC->GetLDUnit() == 1 ){
		LDUNIT = 1;
	}
	bool UDUNIT	= 0;
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
	if( m_pMCC->GetUDUnit() == 1 ){
		UDUNIT = 1;
	}
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ� (S)
	bool SMLDUNIT = 0;
	if( m_pMCC->GetLDUnit() == 2 ){
		SMLDUNIT = 1;
	}
	bool SMUDUNIT = 0;
	if( m_pMCC->GetUDUnit() == 2 ){
		SMUDUNIT = 1;
	}
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ� (E)
	bool RAIL_L(m_pMCC->SD.Component.railLR[0]==1);
	bool RAIL_R(m_pMCC->SD.Component.railLR[1]==1);

	bool EJECT1(m_pMCC->SD.Component.ejectAxises[0]==1);
	bool EJECT2(m_pMCC->SD.Component.ejectAxises[1]==1);
	bool EJECT3(m_pMCC->SD.Component.ejectAxises[2]==1);
	bool EJECT4(m_pMCC->SD.Component.ejectAxises[3]==1);
	bool EJECTY(m_pMCC->SD.Component.ejectAxises[4]==1);
	
	int idxexist = 0;
	for(int mindex = 0;mindex < m_motors;++mindex)
	{
		if((0 <= mindex && mindex <= 3)||(6 <= mindex && mindex <= 7)||(9 <= mindex && mindex <= 11)) /* Do nothing */;
		else if( 17 <= mindex && mindex <= 18)                                  m_pMTTBL[mindex].exist = FEEDCNV;
		else if( 22 <= mindex && mindex <= 25)                                  m_pMTTBL[mindex].exist = StgTlt;
		else if( 26 <= mindex && mindex <= 29)                                  m_pMTTBL[mindex].exist = FEEDCNV;
		else if( 30 <= mindex && mindex <= 30)                                  m_pMTTBL[mindex].exist = RAIL_L;
		else if( 31 <= mindex && mindex <= 31)                                  m_pMTTBL[mindex].exist = RAIL_R;
		else if( 32 <= mindex && mindex <= 33)                                  m_pMTTBL[mindex].exist = LIFTPIN;
		else if( 34 <= mindex && mindex <= 36)                                  m_pMTTBL[mindex].exist = LDUNIT;
		else if( 37 <= mindex && mindex <= 39)                                  m_pMTTBL[mindex].exist = UDUNIT;
		else if( 40 == mindex )                                                 m_pMTTBL[mindex].exist = BDSBad;
		else if( 41 <= mindex && mindex <= 47)                                  m_pMTTBL[mindex].exist = WFUNIT;
		else if( 48 <= mindex && mindex <= 48)                                  m_pMTTBL[mindex].exist = EJECT1;
		else if( 49 <= mindex && mindex <= 49)                                  m_pMTTBL[mindex].exist = EJECT2;
		else if( 50 <= mindex && mindex <= 50)                                  m_pMTTBL[mindex].exist = EJECT3;
		else if( 51 <= mindex && mindex <= 51)                                  m_pMTTBL[mindex].exist = EJECT4;
		else if( 52 <= mindex && mindex <= 52)                                  m_pMTTBL[mindex].exist = EJECTY;
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ�
		else if( 53 <= mindex && mindex <= 56)                                  m_pMTTBL[mindex].exist = WFUNIT;
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ� (S)
		else if( 57 <= mindex && mindex <= 57)                                  m_pMTTBL[mindex].exist = SMLDUNIT;
		else if( 58 <= mindex && mindex <= 58)                                  m_pMTTBL[mindex].exist = SMUDUNIT;
// #OZ20150625 �E�F�n��p�������[�_�E�A�����[�_�ǉ� (E)

		else ASSERT(FALSE);
		
		if(m_pMTTBL[mindex].exist)
			m_MTTBL_EXISTS[idxexist++] = &m_pMTTBL[mindex];
	}

}

void CDebugWnd::OnDestroy() 
{
	CWnd::OnDestroy();
	KillTimer(IDC_DEBUG_LIST);
}

void CDebugWnd::PostNcDestroy ()
{
    delete this;
}

void CDebugWnd::OnPaint ()
{
    CPaintDC dc (this);
}

int CDebugWnd::ListInit()
{
	LVCOLUMN    lvc;
    int         i;
    TCHAR       caption[][32] = {_T("MotorName"),_T("CurrentPosition"), _T("OriginOffset"), _T("-Limit"), _T("+Limit"),_T("Origin")};
    const int   clmNum = sizeof caption /sizeof caption[0];
    int         err = 0;
    
    lvc.mask = LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
    for (i = 0; i < clmNum; i++)
    {
        lvc.iSubItem    = i;
        lvc.pszText     = caption[i];
		switch(i)
		{
			case 0:
				lvc.cx = 120;
				break;
			case 1:
				lvc.cx = 100;
				break;
			case 2:
				lvc.cx = 90;
				break;
			case 3:
				lvc.cx = 80;
				break;
			case 4:
				lvc.cx = 80;
				break;
			case 5:
				lvc.cx = 50;
				break;
				
		}
        if (m_list.InsertColumn(i, &lvc) == -1) {err = 1; break;}
    }
   
	m_list.SetExtendedStyle((m_list.GetExtendedStyle()|LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT));
	m_list.SetItemCount(64);

	m_list.GetClientRect(&m_clientRect);
	
    return err;
}

BOOL CDebugWnd::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	// TODO: �����ɓ���ȃR�[�h��ǉ����邩�A�������͊�{�N���X���Ăяo���Ă��������B
	NMHDR* pNMHDR = (NMHDR*)(lParam);
	if(wParam == IDC_DEBUG_LIST)
	{
		NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
		int selectedRow = pNMListView->iItem;
		int selectedCol = pNMListView->iSubItem;
		switch(pNMHDR->code)
		{
		case NM_CLICK:
			break;
		case NM_RCLICK:
			break;
		case NM_CUSTOMDRAW:
			break;
		case NM_DBLCLK:
			break;
		case LVN_COLUMNCLICK:
			break;
		}
	}
	return CWnd::OnNotify(wParam, lParam, pResult);
}

void CDebugWnd::OnGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult)
{
    NMLVDISPINFO* pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
    LVITEM* pItem = &(pDispInfo)->item;

    if (pItem->mask & LVIF_TEXT)
    {
        int iItem = pDispInfo->item.iItem;
        int iSubItem = pDispInfo->item.iSubItem;
		if(iItem < sizeof(m_MTTBL_EXISTS)/sizeof(m_MTTBL_EXISTS[0]) && -1< iSubItem && iSubItem < 6)
		{
			UpdateMTTBL();
			if(m_MTTBL_EXISTS[iItem])
			{
				m_textBuffer="";
				switch(iSubItem)
				{
					case 0:
						m_textBuffer.Format("%s",m_MTTBL_EXISTS[iItem]->mnames[1]);
						break;
					case 1:
						if (m_MTTBL_EXISTS[iItem]->uid == BND_ID) {
							m_status = m_pMCC->BND.MotorStatus(m_MTTBL_EXISTS[iItem]->mid);// Ӱ���ð���̎擾 �w�肳�ꂽӰ���ð���̍����l
							if (1/*2 & SuperMode*/) {
								m_SuperSts = m_pMCC->BND.MotorPosition(m_MTTBL_EXISTS[iItem]->mid, m_value);
							}
						} else if(m_MTTBL_EXISTS[iItem]->uid == BDS_ID){
							m_status = m_pMCC->BDS.MotorStatus(m_MTTBL_EXISTS[iItem]->mid);// Ӱ���ð���̎擾 �w�肳�ꂽӰ���ð���̍����l
							if (1/*2 & SuperMode*/) {
								m_SuperSts = m_pMCC->BDS.MotorPosition(m_MTTBL_EXISTS[iItem]->mid, m_value);
							}
						} else if(m_MTTBL_EXISTS[iItem]->uid == ICS_ID){
							m_status = m_pMCC->ICS.MotorStatus(m_MTTBL_EXISTS[iItem]->mid);// Ӱ���ð���̎擾 �w�肳�ꂽӰ���ð���̍����l
							if (1/*2 & SuperMode*/) {
								m_SuperSts = m_pMCC->ICS.MotorPosition(m_MTTBL_EXISTS[iItem]->mid, m_value);
							}
						}
						if(iItem == 3||iItem == 8||iItem == 43||iItem == 46) m_value = RAD_DEG*m_value;
						m_textBuffer.Format("%9.4lf",m_value);
						break;
					case 2:
						m_value = *m_MTTBL_EXISTS[iItem]->pOffset;
						if(iItem == 3||iItem == 8||iItem == 43||iItem == 46) m_value = RAD_DEG*m_value;
						m_textBuffer.Format("%9.4lf",m_value);
						break;
					case 3:
						m_value = *m_MTTBL_EXISTS[iItem]->pMSLimit;
						if(iItem == 3||iItem == 8||iItem == 43||iItem == 46) m_value = RAD_DEG*m_value;
						m_textBuffer.Format("%9.4lf",m_value);
						break;
					case 4:
						m_value = *m_MTTBL_EXISTS[iItem]->pPSLimit;
						if(iItem == 3||iItem == 8||iItem == 43||iItem == 46) m_value = RAD_DEG*m_value;
						m_textBuffer.Format("%9.4lf",m_value);
						break;
					case 5:
						if (m_MTTBL_EXISTS[iItem]->uid == BND_ID) {
							m_status = m_pMCC->BND.MotorStatus(m_MTTBL_EXISTS[iItem]->mid);// Ӱ���ð���̎擾 �w�肳�ꂽӰ���ð���̍����l
							if (1/*2 & SuperMode*/) {
								m_OrgSts = m_pMCC->BND.MtSel(m_MTTBL_EXISTS[iItem]->mid) & m_pMCC->BND.ResetStatusMotor();
							}
						} else if(m_MTTBL_EXISTS[iItem]->uid == BDS_ID){
							m_status = m_pMCC->BDS.MotorStatus(m_MTTBL_EXISTS[iItem]->mid);// Ӱ���ð���̎擾 �w�肳�ꂽӰ���ð���̍����l
							if (1/*2 & SuperMode*/) {
								m_OrgSts = m_pMCC->BDS.MtSel(m_MTTBL_EXISTS[iItem]->mid) & m_pMCC->BDS.ResetStatusMotor();
							}
						} else if(m_MTTBL_EXISTS[iItem]->uid == ICS_ID){
							m_status = m_pMCC->ICS.MotorStatus(m_MTTBL_EXISTS[iItem]->mid);// Ӱ���ð���̎擾 �w�肳�ꂽӰ���ð���̍����l
							if (1/*2 & SuperMode*/) {
								m_OrgSts = m_pMCC->ICS.MtSel(m_MTTBL_EXISTS[iItem]->mid) & m_pMCC->ICS.ResetStatusMotor();
							}
						}
						m_textBuffer.Format("%s",(m_OrgSts)?"��":"��");
						break;
				}
				pItem->pszText = const_cast<TCHAR*>((LPCTSTR)m_textBuffer);
			}
		}
    }
    *pResult = 0;
}

void CDebugWnd::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult)
{
    LPNMLVCUSTOMDRAW lpLvCustomDraw = reinterpret_cast<LPNMLVCUSTOMDRAW>(pNMHDR);

    if (lpLvCustomDraw->nmcd.dwDrawStage == CDDS_PREPAINT)
    {
        *pResult = CDRF_NOTIFYITEMDRAW;
        return;
    }
    if (lpLvCustomDraw->nmcd.dwDrawStage == CDDS_ITEMPREPAINT)
    {
        if (lpLvCustomDraw->nmcd.dwItemSpec % 2)
        {
            lpLvCustomDraw->clrTextBk =  RGB(230,255,250);
        }
        *pResult = CDRF_NEWFONT;
        return;
    }

    *pResult = 0;
    return;
}

void CDebugWnd::OnButtonClick(UINT nID)
{
	const int DATAS = 2000;
	double pos[DATAS]={0.0};
	double p=0.0;
	int errCode = 0;
	bool isErrOut = false;
	
	CDisplaceSensor* pDisplaceSensor = m_pMCC->BND.m_pDisplaceSensor[1];
	BOOL r;
	switch(nID - ID_DEBUG_BUTTON)
	{
	case 0:
		m_edit.ShowWindow(SW_HIDE);
		m_list.ShowWindow(SW_SHOW);
		m_activeView = &m_list;
		UpdateButtonLabel();
		break;
	case 1:
		m_list.ShowWindow(SW_HIDE);
		m_edit.ShowWindow(SW_SHOW);
		SetFocus();
		m_activeView = &m_edit;
		UpdateButtonLabel();
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	////////////////////////////////////////////////////////////////////////////////////////////////
	case 5:
		if(m_activeView == &m_edit){
			m_edit.SetWindowText("");
			pDisplaceSensor->LaserOMRONCommOpenEnd();
		}
		break;
	case 6:
		if(m_activeView == &m_edit){
			m_edit.SetWindowText("");
			pDisplaceSensor->LaserOMRONCommDataSet(CLaserOMRONComm::eCmd_MS, 1);
			r = pDisplaceSensor->LaserOMRONCommSendRecv(0, p, errCode, isErrOut);	// ����M
			char bufval[15]     = {0};
			if(r){
				sprintf(bufval,"%.8f\r\n",p);
			}else sprintf(bufval,"Error:LaserOMRONCommSendRecv\r\n");
			m_edit.SetWindowText(bufval);
		}
		break;
	case 7:
		if(m_activeView == &m_edit){
			m_edit.SetWindowText("");
			r = pDisplaceSensor->LoggingClear();
			m_edit.SetWindowText((r)?"OK:LoggingClear\r\n":"ERROR:LoggingClear\r\n");
		}
		break;
	case 8:
		if(m_activeView == &m_edit){
			m_edit.SetWindowText("");
			r = pDisplaceSensor->LoggingStart(DATAS,true);
			m_edit.SetWindowText((r)?"OK:LoggingStart\r\n":"ERROR:LoggingStart\r\n");
		}
		break;
	case 9:
		if(m_activeView == &m_edit){
			m_edit.SetWindowText("");
			r = pDisplaceSensor->LoggingOut(pos,DATAS);
			char buffer[20*2000]= {0};
			char bufval[20]     = {0};
			for(int i = 1;r && i < CLaserOMRONComm::eRcvNumMax;i++)
			{
				sprintf(
					bufval,
					"%.8f\r\n",
					pDisplaceSensor->cLaserOMRONComm.GetVal(i));

				lstrcat(buffer,bufval);
				memset(bufval,0,sizeof(bufval));
			}
			m_edit.SetWindowText((r)?buffer:"Error:LoggingOut\r\n");
		}
		break;
	}
}

void CDebugWnd::OnTimer(UINT nIDEvent) 
{
	if(IDC_DEBUG_LIST == nIDEvent)
	{
		CRect rect;
		m_list.GetClientRect(rect);
		rect.top += 22;
		m_list.InvalidateRect(rect,FALSE);
	}
	CWnd::OnTimer(nIDEvent);
}

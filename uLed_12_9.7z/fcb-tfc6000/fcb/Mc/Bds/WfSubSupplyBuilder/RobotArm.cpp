// RobotArm.cpp: RobotArm �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "RobotArm.h"

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

RobotArm::RobotArm()
{

}

RobotArm::~RobotArm()
{

}
RobotArm::RobotArm(
					CString	name,				// ���O
					OrdinarySnsTBL* pDoorOpened,	// DoorOpened
					int	class_id,				// ���̃N���X�h�c
					int pinIdx,					// ���t�g�s���㉺���C���f�b�N�X
					int myMErrStart,			// �����̌y�x�̃G���[�擪
					int myFErrStart)			// �����̒v���I�G���[�擪
					:ManipulatorComm()			// ��M�X���b�h�̋N���Ƃ����Ă���̂ŁA�����I�ɃR���X�g���N�^�N������B
{
	this->name	= name;
	// �G���[�̏�����(PutError()���g����悤�ɂ���)
	this->err.Initinstance(class_id, myMErrStart);
	this->fatalErr.Initinstance(class_id, myFErrStart);
	//
	this->isEnable = false;
	// ���[�^���̏�����
	this->mtLiftPinUp.InitInstance(class_id, pinIdx);
	// DoorOpened���o������
	if(pDoorOpened->sensor_no >= 0){// �A�h���X���_�~�[�łȂ����
		this->snsDoorOpened.Initinstance(class_id, pDoorOpened);
	}
	// �ϐ��̏�����
	this->liftPinDwnPos		= 0.0;
	this->liftPinUpPos		= -1.0;
	this->dirStatus			= eDirUnknown;
	this->nowStatus			= eDirUnknown;
	this->fromIdx			= 0;
	this->toIdx				= 0;
	this->oriFlat			= 0.0;
	this->correctAngle		= 0.0;
	this->isAligned			= false;
	this->pIsAbleToGoUp		= NULL;
}
BOOL RobotArm::Init(){
	int	r = TRUE;
	// �C�x���g��M�X���b�h�N��(�ꎞ��~���[�h�ŋN������ɍĊJ����)
	pEThread = AfxBeginThread( EventProc, this, THREAD_PRIORITY_NORMAL, 0, CREATE_SUSPENDED );
	if( !pEThread ){
	//	AfxMessageBox( "�C�x���g��M�X���b�h�̋N���Ɏ��s���܂����B", MB_OK, 0 );
	//	return FALSE;
	}
	// �گ������ٕۑ�
	m_hEventRThread = pEThread->m_hThread;
	pEThread->ResumeThread();	// �C�x���g��M�X���b�h����J�n
	ManipulatorComm.SetEventEventObject( &evEVENT, &evData );
	return	r;
}
BOOL	RobotArm::SetSpeedAll(int sel){		// ���x�ݒ�
	BOOL ret = TRUE;
	// �t�H�[�N�P
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_A, CManipulatorComm::MPCMD_SMODE_H, sel);
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_A, CManipulatorComm::MPCMD_SMODE_M, sel) && ret;
	// �t�H�[�N�Q
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_B, CManipulatorComm::MPCMD_SMODE_H, sel) && ret;
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_B, CManipulatorComm::MPCMD_SMODE_M, sel) && ret;
	return(ret);
}
BOOL	RobotArm::SetArmSpeedY(int armNo, int sel){		// ���x�ݒ�
	BOOL ret = TRUE;
	if(armNo == eOnFork1){
		// �t�H�[�N�P
		ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_A, CManipulatorComm::MPCMD_SMODE_H, sel);
		ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_A, CManipulatorComm::MPCMD_SMODE_M, sel) && ret;
	}else{
		// �t�H�[�N�Q
		ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_B, CManipulatorComm::MPCMD_SMODE_H, sel) && ret;
		ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_B, CManipulatorComm::MPCMD_SMODE_M, sel) && ret;
	}
	return(ret);
}
BOOL	RobotArm::SetArmSpeedT(int sel){		// ���x�ݒ�
	BOOL ret = TRUE;
	// ����
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_S, CManipulatorComm::MPCMD_SMODE_H, sel);
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_S, CManipulatorComm::MPCMD_SMODE_M, sel) && ret;
	return(ret);
}

BOOL	RobotArm::SetArmSpeedZ(int sel){		// ���x�ݒ�
	BOOL ret = TRUE;
	// Z��
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_Z, CManipulatorComm::MPCMD_SMODE_H, sel);
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_Z, CManipulatorComm::MPCMD_SMODE_M, sel) && ret;
	ret = this->SetMniSpeed(CManipulatorComm::MPCMD_AXIS_Z, CManipulatorComm::MPCMD_SMODE_L, sel) && ret;
	return(ret);
}


BOOL	RobotArm::SetMniSpeed(int axis, int mode, int sel){		// ���x�ݒ�
	BOOL ret = TRUE;
	//6000W����Ȃ��ꍇ
	if(!this->isEnable){
		return TRUE;
	}
	int value = 1000;
	if(sel == 0){
		value = 1000;
	}else if (sel == 1){
		value = 400;
	}else if (sel == 2){
		value = 100;
	}else if (sel == 3){
		value = 50;
	}
	CSingleLock W(&CommSema);
	W.Lock();
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"SetSpeed() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_SSPP( CManipulatorComm::UNIT_MANIPULATOR,				// RobotArm
												axis,			// axis
												mode,			// SMode
												value,			//
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"SetSpeed() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
	}else{
		CString estr;
		estr.Format( "SetSpeed Error Code [%04x]\n", ret );
		this->PutCommonError(eGeneral, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret);
}

BOOL	RobotArm::SetAlnSpeed(int sel){		// ���x�ݒ�
	BOOL ret = TRUE;
	// ��رײݎ�
	ret = this->SetAlnSpeed(CManipulatorComm::MPCMD_SMODE_H, sel);
	ret = this->SetAlnSpeed(CManipulatorComm::MPCMD_SMODE_M, sel) && ret;
	return(ret);
}
BOOL	RobotArm::SetAlnSpeed(int mode, int sel){		// �v���A���C�i���x�ݒ�
	BOOL ret = TRUE;
	//6000W����Ȃ��ꍇ
	if(!this->isEnable){
		return TRUE;
	}
	int value = 1000;
	if(sel == 0){
		value = 1000;
	}else if (sel == 1){
		value = 400;
	}else if (sel == 2){
		value = 100;
	}else if (sel == 3){
		value = 50;
	}
	CSingleLock W(&CommSema);
	W.Lock();
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"SetSpeed() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_SSPP( CManipulatorComm::UNIT_PREALIGNER,		// RobotArm
												CManipulatorComm::MPCMD_AXIS_G,			// �S��
												mode,									// SMode
												value,			//
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"SetSpeed() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
	}else{
		CString estr;
		estr.Format( "SetSpeed Error Code [%04x]\n", ret );
		this->PutCommonError(ePreAligner, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret);
}

//////////////////////////////////////////////////////////////////////
//
// �Z���T�֌W
//
bool RobotArm::DoorOpenedSns(bool &isOn)
{
	return (this->snsDoorOpened.IsDetected(isOn));
}
bool RobotArm::GetArmHoldStatus(bool& detArmA, bool& detArmB){
	BOOL ret = TRUE;
	//6000W����Ȃ��ꍇ
	if(!this->isEnable){
		return TRUE;
	}
	CSingleLock W(&CommSema);
	W.Lock();
	detArmA = true;
	detArmB = true;
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetArmHoldStatus() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_RSTS( CManipulatorComm::UNIT_MANIPULATOR,	// RobotArm
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetArmHoldStatus() End[0x%04x] 0x%4x\n", ret,dt[eNORM].answerData.u_asdata.rsts.Status1);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
		int sts = 0;
		// �A�[���`�̕ێ����
		// �`���b�L���O�w�ߏ�Ԃ͌��Ȃ�
		sts = dt[eNORM].answerData.u_asdata.rsts.Status1 & 0x01;	// �L�������
		if(sts == 0x01){
			detArmA	= false;		// ON�ŕێ����Ă��Ȃ�(���[�N�Ȃ�)
		}
		// �`���b�L���O�w�ߏ�Ԃ͌��Ȃ�
		sts = dt[eNORM].answerData.u_asdata.rsts.Status1 & 0x02;	// �L�������
		if(sts == 0x02){
			detArmB	= false;		// ON�ŕێ����Ă��Ȃ�(���[�N�Ȃ�)
		}
	}else{
		CString estr;
		estr.Format( "GetArmHoldStatus Error Code [%04x]\n", ret );
		this->PutCommonError(eGeneral, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret!=FALSE);
}
// �A�[���z���w�ߏ��
bool RobotArm::GetArmVcCmdStatus(bool& detArmA, bool& detArmB){
	BOOL ret = TRUE;
	//6000W����Ȃ��ꍇ
	if(!this->isEnable){
		return TRUE;
	}
	CSingleLock W(&CommSema);
	W.Lock();
	detArmA = true;
	detArmB = true;
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetArmVcCmdStatus() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_RSTS( CManipulatorComm::UNIT_MANIPULATOR,	// RobotArm
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetArmVcCmdStatus() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
		int sts = 0;
		// �A�[���`�̕ێ����
		// �`���b�L���O�w�ߏ�Ԃ�����
		sts = dt[eNORM].answerData.u_asdata.rsts.Status1 & 0x04;	// �z���w�ߏ��
		if(sts == 0x04){
			detArmA	= false;		// ON�ŕێ����Ă��Ȃ�(���[�N�Ȃ�)
		}
		// �`���b�L���O�w�ߏ�Ԃ͌��Ȃ�
		sts = dt[eNORM].answerData.u_asdata.rsts.Status1 & 0x08;	// �z���w�ߏ��
		if(sts == 0x08){
			detArmB	= false;		// ON�ŕێ����Ă��Ȃ�(���[�N�Ȃ�)
		}
	}else{
		CString estr;
		estr.Format( "GetArmVcCmdStatus Error Code [%04x]\n", ret );
		this->PutCommonError(eGeneral, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret!=FALSE);
}

// �A���C�i��L���擾
bool RobotArm::GetAlignHoldStatus(bool& detAlign){
	BOOL ret = TRUE;
	CSingleLock W(&CommSema);
	W.Lock();
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetAlignHoldStatus() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_RSTS( CManipulatorComm::UNIT_PREALIGNER,	// PreAligner
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetAlignHoldStatus() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
		int sts = 0;
		// �v���A���C�i�̕ێ����
		sts = dt[eNORM].answerData.u_asdata.rsts.Status1 & 0x02;	// �L�������
		if(sts == 0x02){
			detAlign	= false;		// ON�Ń��[�N�Ȃ�
		}
	}else{
		CString estr;
		estr.Format( "GetAlignHoldStatus Error Code [%04x]\n", ret );
		this->PutCommonError(ePreAligner, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret!=FALSE);
}


// �A���C�i�z���w�ߗL���擾
bool RobotArm::GetAlignVcCmdStatus(bool& detAlign){
	BOOL ret = TRUE;
	CSingleLock W(&CommSema);
	W.Lock();
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetAlignVcCmdStatus() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_RSTS( CManipulatorComm::UNIT_PREALIGNER,	// PreAligner
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetAlignVcCmdStatus() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
		int sts = 0;
		// �v���A���C�i�̕ێ����
		sts = dt[eNORM].answerData.u_asdata.rsts.Status1 & 0x04;	// �z���w�ߏ��
		if(sts == 0x04){
			detAlign	= false;		// ON�Ń��[�N�Ȃ�
		}
	}else{
		CString estr;
		estr.Format( "GetAlignVcCmdStatus Error Code [%04x]\n", ret );
		this->PutCommonError(ePreAligner, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret!=FALSE);
}

BOOL	RobotArm::ArmPosition(double& Pa,double& Pb,double& Pz,double& Pt)	// ��ޯ�ABZ�� ���݈ʒu
{
	BOOL ret = TRUE;
	CSingleLock W(&CommSema);
	W.Lock();
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"ArmPosition() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_RPOS( CManipulatorComm::UNIT_MANIPULATOR,	// Manipulator
												CManipulatorComm::MPCMD_TRSST_FE,	// TrsSt
												CManipulatorComm::MPCMD_FORK_A,		// ForkA&PreAlign
												CManipulatorComm::MPCMD_POSTURE_A,
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"ArmPosition() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
		// ���{�b�g�̈ʒu���
		Pa = (double)(dt[eNORM].answerData.u_asdata.rpos.Value2) / 100.0;	// mm
		Pb = (double)(dt[eNORM].answerData.u_asdata.rpos.Value3) / 100.0;	// mm
		Pz = (double)(dt[eNORM].answerData.u_asdata.rpos.Value4) / 100.0;	// mm
		Pt = (double)(dt[eNORM].answerData.u_asdata.rpos.Value1) / 100.0;	// deg
	}else{
		CString estr;
		estr.Format( "ArmPosition Error Code [%04x]\n", ret );
		this->PutCommonError(eGeneral, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret!=FALSE);
}

BOOL	RobotArm::AlignerPosition(R2Pos& P)	// �ײ�XY ���݈ʒu
{
	BOOL ret = TRUE;
	CSingleLock W(&CommSema);
	W.Lock();
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"AlignerPosition() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_RPOS( CManipulatorComm::UNIT_PREALIGNER,	// Aligner
												CManipulatorComm::MPCMD_TRSST_FE,	// TrsSt
												CManipulatorComm::MPCMD_FORK_A,		// ForkA&PreAlign
												CManipulatorComm::MPCMD_POSTURE_A,
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"AlignerPosition() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
		// ���{�b�g�̈ʒu���
		P.x = (double)(dt[eNORM].answerData.u_asdata.rpos.Value2) / 100.0;	// mm
		P.y = (double)(dt[eNORM].answerData.u_asdata.rpos.Value3) / 100.0;	// mm
	}else{
		CString estr;
		estr.Format( "AlignerPosition Error Code [%04x]\n", ret );
		this->PutCommonError(ePreAligner, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret!=FALSE);
}

void	RobotArm::DummySetParam(){
//	double value;
//	this->GetCommonParam(13,value);
//	this->ChangeCommonParam(13,50);
}


// �p�����[�^�擾
BOOL RobotArm::GetCommonParam(int addr, double& value){
	BOOL ret = TRUE;
	//6000W����Ȃ��ꍇ
	if(!this->isEnable){
		return TRUE;
	}
	CSingleLock W(&CommSema);
	W.Lock();
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetCommonParam() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_RPRM( CManipulatorComm::UNIT_MANIPULATOR,	// RobotArm
												CManipulatorComm::MPCMD_TYPE_CIU,
												addr,
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetCommonParam() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
		// �v���A���C�i�̕ێ����
		value = dt[eNORM].answerData.u_asdata.rprm.Value;	// 
	}else{
		CString estr;
		estr.Format( "GetCommonParam Error Code [%04x]\n", ret );
		this->PutCommonError(eGeneral, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret!=FALSE);
}

// �p�����[�^�ύX
BOOL RobotArm::ChangeCommonParam(int addr, int value){
	BOOL ret = TRUE;
	//6000W����Ȃ��ꍇ
	if(!this->isEnable){
		return TRUE;
	}
	CSingleLock W(&CommSema);
	W.Lock();
#if !Release
	CString	Msg;
	CTime theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetCommonParam() Start\n");
#endif
	ret = ManipulatorComm.SendManipulator_SPRM( CManipulatorComm::UNIT_MANIPULATOR,	// RobotArm
												CManipulatorComm::MPCMD_TYPE_CIU,
												addr,
												value,
												&dt[eNORM].answerData);
#if !Release
	theTime = CTime::GetCurrentTime();
	Msg = theTime.Format("%H:%M:%S,");
	TRACE(Msg+"GetCommonParam() End[0x%04x]\n", ret);
#endif
	if(ret == CManipulatorComm::Err0x0000){
		ret = TRUE;
	}else{
		CString estr;
		estr.Format( "GetCommonParam Error Code [%04x]\n", ret );
		this->PutCommonError(eGeneral, ret, estr);
		ret = FALSE;
	}
	W.Unlock();
	return (ret!=FALSE);
}



// �C�x���g��M�X���b�h
UINT	RobotArm::EventProc( LPVOID pParam )
{
	CString			str;
	RobotArm	*pMnP = (RobotArm *)pParam;
	CSingleLock	S( &(pMnP->evEVENT) );
	str.Empty();
	for(;;) {
		S.Lock( INFINITE );
		S.Unlock();
		if( pMnP->evData.evNumb == 100 ){
			str.Format( "Received Event UNIT[%d] EVENT[%d] ErrLevel[%d] ErrCode[%04x]\n", pMnP->evData.unit, pMnP->evData.evNumb, pMnP->evData.u_evdata.error.errLvl, pMnP->evData.u_evdata.error.errCode );
		} else {
			str.Format( "Received Event UNIT[%d] EVENT[%d] Fork[%d] Point[%d]\n", pMnP->evData.unit, pMnP->evData.evNumb, pMnP->evData.u_evdata.arrivePass.fork, pMnP->evData.u_evdata.arrivePass.point );
		}
#if !Release
TRACE(str);
#endif
	}
	return 0;
}


/////////////////////////////////////////
//
// TSR
// ������RS-232C�Ƃ�I/F�ƍŏ��̃R�}���h���L�q
//
//




/*---------------------------------------------------------------------
	������ى�ʊ֐��i�i���ް�:�c�[�����j

	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_ToolInfo(int step,int page)
{
	int OptIdx = 0;
	int Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	int	r=OK_END;
	for(;;){
		if(step == 0){		// �ް��ݒ�
			if(page ==1)		r = DVd_ToolInfo1();
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}

////////////////////////////////////////////////////////////////////////////////-
// �c�[�����i�f�[�^�ݒ�j
int TPCtrl::DVd_ToolInfo1()
{
	enum {
		// ��ʔԍ�
		SNo					= 1100,		// ���No.
		// �\���f�[�^�C���f�b�N�X
		ToolIndexX			= 300,		// �c�[���C���f�b�N�X�w
		ToolIndexY			= 302,		// �c�[���C���f�b�N�X�x
		ToolPitchX			= 304,		// �c�[���s�b�`�w
		ToolPitchY			= 306,		// �c�[���s�b�`�x
		HoleRadius			= 308,		// KTV170906: Add hole radius of vacuumns
		// �{�^���C���f�b�N�X
		KeyToolIndex		= 65,		// �c�[���C���f�b�N�X
		KeyToolPitch		= 66,		// �c�[���s�b�`
		KeyHoleRadius		= 67,		// KTV170906: Add hole radius of vacuumns
		// ��ԕێ��C���f�b�N�X
//		AttWfrSize6			= 200,		// ��ʻ���6���
//		AttWfrSize8			= 201,		// ��ʻ���8���
		// ���ʃ{�^���C���f�b�N�X
		KeyHome				= '0',
		KeyPrev				= '1',
	};
	int	r;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;

	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;

		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		/////////////////////
		// �����l�\��
		//
		DataPut(ToolIndexX,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolIndex.X(),1);
		DataPut(ToolIndexY,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolIndex.Y(),1);
		DataPut(ToolPitchX,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolPitch.X(),1000);
		DataPut(ToolPitchY,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolPitch.Y(),1000);
		DataPut(HoleRadius,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].holeRadius,1000);	// KTV170906: Add hole radius of vacuumns
		//
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			switch(key){
				///////////////
				// �c�[���C���f�b�N�X
				case KeyToolIndex	:
					{
						const char* msgX[] = {
							{ "Tool Index X" },
							{ "Tool Index X" },
						};
						///////////////
						// �f�[�^�ҏW
						if(DataEdit(msgX[Lang],"",pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolIndex.X(),1,999,1)){
							DataPut(ToolIndexX,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolIndex.X(),1);
							DataUpdate = TRUE;
						}
						const char* msgY[] = {
							{ "Tool Index Y" },
							{ "Tool Index Y" },
						};
						///////////////
						// �f�[�^�ҏW
						if(DataEdit(msgY[Lang],"",pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolIndex.Y(),1,999,1)){
							DataPut(ToolIndexY,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolIndex.Y(),1);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// �c�[���s�b�`
				case KeyToolPitch	:
					{
						const char* msgX[] = {
							{ "Tool Pitch X" },
							{ "Tool Pitch X" },
						};
						///////////////
						// �f�[�^�ҏW
						if(DataEdit(msgX[Lang],"",pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolPitch.X(),0.5,10.0,1000)){
							DataPut(ToolIndexX,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolPitch.X(),1000);
							DataUpdate = TRUE;
						}
						const char* msgY[] = {
							{ "Tool Pitch Y" },
							{ "Tool Pitch Y" },
						};
						///////////////
						// �f�[�^�ҏW
						if(DataEdit(msgY[Lang],"",pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolPitch.Y(),0.5,10.0,1000)){
							DataPut(ToolIndexY,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].toolPitch.Y(),1000);
							DataUpdate = TRUE;
						}
					}
					break;
				case KeyHoleRadius	:		// KTV170906: Add hole radius of vacuumns (S)
					{
						const char* msgX[] = {
							{ "Hole Radius" },
							{ "Hole Radius" },
						};
						///////////////
						// �f�[�^�ҏW
						if(DataEdit(msgX[Lang],"",pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].holeRadius,1,999,1)){
							DataPut(HoleRadius,	pMCC->BND.DD.ToolInforD.IC[0/*ictype*/].holeRadius,1);
							DataUpdate = TRUE;
						}
					}
					break;				// KTV170906: Add hole radius of vacuumns (E)
				///////////////
				// 
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.DD.ToolInforD.DataRW(FALSE, pMCC->BND.DD.FName);
	}
	return	r;
}


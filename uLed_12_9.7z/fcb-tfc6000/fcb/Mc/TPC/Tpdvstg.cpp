/*---------------------------------------------------------------------
	������ى�ʊ֐��i�i���ް�:����ިݸ޽ð�ށj
								1997 Nobuharu.Nasu / TELAGO Co.,Ltd.
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

/////////////////////////////////////////////////////////////////////////////
int TPCtrl::DV_BGStg(int step,int page)
{
	int	r=OK_END;
	for (;;) {
		if (step == 0) {
			// �����Ȃ�
		} else {
			// �����Ȃ�
		}
		if (r == Home_END)		break;
		else if (r == Prev_END)	break;
		else if (Data1_END <= r && r <= Data8_END) {
			page = r - Data1_END + 1;
			step = 0;
		} else if (Teach1_END <= r && r <= Teach8_END) {
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}


/*---------------------------------------------------------------------
	�^�b�`�p�l����ʊ֐��i�}�V���f�[�^:���IC�J�����L�����u���[�V�����j
	Edition History
	 #   Date     Changes Made
	-- -------- ------------------------------------------------------

---------------------------------------------------------------------*/
#include	"stdafx.h"
#include	"afxmt.h"
#include 	<stdlib.h>
#include	<tpc.h>
#include	<tpctrl.h>
#include	<mcc.h>

// #MU150828-01
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::MC_BDICCalib(int step,int page)
{
	int	r=OK_END;
	for(;;){
		if (step == 0) {
			if(page == 1)		r = MCd_BDICCalib1();	// �L�����u���[�V�����p�w�b�h�^�[�Q�b�g
			else				r = Data1_END;
		} else {
			if(page == 1)		r = MCt_BDICCalib1();	// �L�����u���[�V�����p�w�b�h�^�[�Q�b�g
			else				r = Teach1_END;
		}
		if(r == Home_END)		break;
		else if(r == Prev_END)	break;
		else if(Data1_END <= r && r <= Data8_END){
			page = r - Data1_END + 1;
			step = 0;
		} else if(Teach1_END <= r && r <= Teach8_END){
			page = r - Teach1_END + 1;
			step = 1;
		}
	}
	return	r;
}
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::MCd_BDICCalib1()
{
	enum{
//		SNo					= 2700,		// ���No.
		SNo					= 2500,		// ���No.
			//
		KeyCalibSel_NoUse	= 65,		// Calibration Select No Use
		KeyCalibSel_Head	= 66,		// Calibration Select Head
		KeyCalibSel_Stage	= 67,		// Calibration Select Stage
		KeyMeasureCnt		= 68,		// Measurement Count
		KeyIC_HeadPosX		= 70,		// IC-Side  Head Position X
		KeyIC_HeadPosY		= 71,		// IC-Side  Head Position Y
		KeyIC_HeadPosZ		= 72,		// IC-Side  Head Position Z
		KeyIC_AlignDelay	= 73,		// IC-Side  Alignment Delay
		KeyIC_LightLevelA	= 74,		// IC-Side  Vertical Light Level
		KeyIC_LightLevelB	= 75,		// IC-Side  Oblique Light Level
		KeySub_HeadPosX		= 80,		// Sub-Side Head Position X
		KeySub_HeadPosY		= 81,		// Sub-Side Head Position Y
		KeySub_HeadPosZ		= 82,		// Sub-Side Head Position Z
		KeySub_AlignDelay	= 83,		// Sub-Side Alignment Delay
		KeySub_LightLevelA	= 84,		// Sub-Side Vertical Light Level
		KeySub_LightLevelB	= 85,		// Sub-Side Oblique Light Level
		//
		AttCalibSel			= 200,		// Calibration Select
		//
		MeasureCnt			= 300,		// Measurement Count
		IC_HeadPosX			= 310,		// IC-Side  Head Position X
		IC_HeadPosY			= 312,		// IC-Side  Head Position Y
		IC_HeadPosZ			= 314,		// IC-Side  Head Position Z
		IC_AlignDelay		= 316,		// IC-Side  Alignment Delay
		IC_LightLevelA		= 318,		// IC-Side  Vertical Light Level
		IC_LightLevelB		= 320,		// IC-Side  Oblique Light Level
		Sub_HeadPosX		= 330,		// Sub-Side Head Position X
		Sub_HeadPosY		= 332,		// Sub-Side Head Position Y
		Sub_HeadPosZ		= 334,		// Sub-Side Head Position Z
		Sub_AlignDelay		= 336,		// Sub-Side Alignment Delay
		Sub_LightLevelA		= 338,		// Sub-Side Vertical Light Level
		Sub_LightLevelB		= 340,		// Sub-Side Oblique Light Level
		//
		KeyHome				= '0',
		KeyPrev					,
		KeyTeach				,
		KeyData					,
		KeyData1				,
		KeyData2				,
	};
	int	r = KeyPrev;
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	BOOL	DataUpdate=FALSE;
	for(;;){
		BOOL	End=FALSE;
		tpc.GpScreenDisp(SNo);	// 	��ʐ؂�ւ�
		/////////////////////
		// �����l�\��
		tpc.GpPut16(AttCalibSel, 1 << (0x00ff & pMCC->BND.MD.BDICCalib.CalibSel));																// Calibration Select
		DataPut(MeasureCnt,		pMCC->BND.MD.HdTargetCalibD.measureCount);																		// Interval Bg Count
		///////////////
		// IC Camera Side
		//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//		DataPut(IC_HeadPosX,	pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].x,	10000);									// Head Position X
//		DataPut(IC_HeadPosY,	pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].y,	10000);									// Head Position Y
		DataPut(IC_HeadPosX,	pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,	10000);																// Head Position X
		DataPut(IC_HeadPosY,	pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,	10000);																// Head Position Y
		DataPut(IC_HeadPosZ,	pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_ICSide],	10000);									// Head Position Z
		DataPut(IC_AlignDelay,	pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_ICSide],		1000);									// Alignment Delay
		DataPut(IC_LightLevelA,	(pMCC->SD.IO.ICLight.ANo == -1) ? 0 : pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].A);	// Vertical Light Level
		DataPut(IC_LightLevelB,	(pMCC->SD.IO.ICLight.BNo == -1) ? 0 : pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].B);	// Oblique Light Level
		///////////////
		// Sub Camera Side
		//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//		DataPut(Sub_HeadPosX,	pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].x,	10000);									// Head Position X
//		DataPut(Sub_HeadPosY,	pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].y,	10000);									// Head Position Y
		DataPut(Sub_HeadPosX,	pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,	10000);																// Head Position X
		DataPut(Sub_HeadPosY,	pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,	10000);																// Head Position Y
		DataPut(Sub_HeadPosZ,	pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_SubSide],10000);									// Head Position Z
		DataPut(Sub_AlignDelay,	pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_SubSide],		1000);									// Alignment Delay
		DataPut(Sub_LightLevelA,(pMCC->SD.IO.BCLight.ANo == -1) ? 0 : pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].A);	// Vertical Light Level
		DataPut(Sub_LightLevelB,(pMCC->SD.IO.BCLight.BNo == -1) ? 0 : pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].B);	// Oblique Light Level
		//
		for(;;){
			BOOL	Restart=FALSE;
			int key = KeyWait();
			if(key)	tpc.GpBeep();
			switch(key){
				///////////////
				// Calibration Select
				case KeyCalibSel_NoUse	:
				case KeyCalibSel_Head	:
				case KeyCalibSel_Stage	:
					{
						int val = (KeyCalibSel_NoUse == key) ? 0 : ((KeyCalibSel_Head == key) ? 1 : 2);
						if (val != pMCC->BND.MD.BDICCalib.CalibSel) {
							tpc.GpPut16(AttCalibSel, 1 << (pMCC->BND.MD.BDICCalib.CalibSel = val));
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Measurement Count
				case KeyMeasureCnt	:
					{
						const char* msg[] = {
							{ "Measurement Count" },
							{ "Measurement Count" },
						};
						///////////////
						// �f�[�^�ҏW
						int min = 1;
						int max = 10;
						if(DataEdit(msg[Lang],"count",pMCC->BND.MD.HdTargetCalibD.measureCount,min,max,1)){
							DataPut(MeasureCnt,pMCC->BND.MD.HdTargetCalibD.measureCount,1);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// IC Camera Side
				///////////////
				// Head Position X
				case KeyIC_HeadPosX	:
					{
						const char* msg[] = {
							{ "Head Position X" },
							{ "Head Position X" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].x,min,max,10000)){
//							DataPut(IC_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].x,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,min,max,10000)){
							DataPut(IC_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Y
				case KeyIC_HeadPosY	:
					{
						const char* msg[] = {
							{ "Head Position Y" },
							{ "Head Position Y" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].y,min,max,10000)){
//							DataPut(IC_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_ICSide].y,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,min,max,10000)){
							DataPut(IC_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Z
				case KeyIC_HeadPosZ	:
					{
						const char* msg[] = {
							{ "Head Position Z" },
							{ "Head Position Z" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][1] - 0.1;
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_ICSide],min,max,10000)){
							DataPut(IC_HeadPosZ,pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_ICSide],10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Alignment Delay
				case KeyIC_AlignDelay	:
					{
						const char* msg[] = {
							{ "Alignment Delay" },
							{ "Alignment Delay" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = 0.0;
						double max = 4.0;
						if(DataEdit(msg[Lang],"sec",pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_ICSide],min,max,1000)){
							DataPut(IC_AlignDelay,pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_ICSide],1000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Vertical Light Level
				case KeyIC_LightLevelA	:
					{
						if(pMCC->SD.IO.ICLight.ANo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Vertical Light Level" },
								{ "Vertical Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].A,0,LIGHTLEVEL_MAX)){
								DataPut(IC_LightLevelA,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].A);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Oblique Light Level
				case KeyIC_LightLevelB	:
					{
						if(pMCC->SD.IO.ICLight.BNo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Oblique Light Level" },
								{ "Oblique Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].B,0,LIGHTLEVEL_MAX)){
								DataPut(IC_LightLevelB,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_ICSide].B);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Sub Camera Side
				///////////////
				// Head Position X
				case KeySub_HeadPosX	:
					{
						const char* msg[] = {
							{ "Head Position X" },
							{ "Head Position X" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HXI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].x,min,max,10000)){
//							DataPut(Sub_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].x,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,min,max,10000)){
							DataPut(Sub_HeadPosX,pMCC->BND.MD.HdTargetCalibD.head_RecPos.x,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Y
				case KeySub_HeadPosY	:
					{
						const char* msg[] = {
							{ "Head Position Y" },
							{ "Head Position Y" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HYI][1] - 0.1;
						//#TT150925-02 ���IC�L�����u�ɂ����āA�w�b�hXY��BD/IC�œ���ʒu�Ƃ���
//						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].y,min,max,10000)){
//							DataPut(Sub_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos[BNDCtrl::eBDICCalib_SubSide].y,10000);
//							DataUpdate = TRUE;
//						}
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,min,max,10000)){
							DataPut(Sub_HeadPosY,pMCC->BND.MD.HdTargetCalibD.head_RecPos.y,10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Head Position Z
				case KeySub_HeadPosZ	:
					{
						const char* msg[] = {
							{ "Head Position Z" },
							{ "Head Position Z" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][0] + 0.1;
						double max = pMCC->BND.MD.MtrD.Limit[BNDCtrl::HZI][1] - 0.1;
						if(DataEdit(msg[Lang],"mm",pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_SubSide],min,max,10000)){
							DataPut(Sub_HeadPosZ,pMCC->BND.MD.HdTargetCalibD.head_RecHeight[BNDCtrl::eBDICCalib_SubSide],10000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Alignment Delay
				case KeySub_AlignDelay	:
					{
						const char* msg[] = {
							{ "Alignment Delay" },
							{ "Alignment Delay" },
						};
						///////////////
						// �f�[�^�ҏW
						double min = 0.0;
						double max = 4.0;
						if(DataEdit(msg[Lang],"sec",pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_SubSide],min,max,1000)){
							DataPut(Sub_AlignDelay,pMCC->BND.MD.HdTargetCalibD.delayTime[BNDCtrl::eBDICCalib_SubSide],1000);
							DataUpdate = TRUE;
						}
					}
					break;
				///////////////
				// Vertical Light Level
				case KeySub_LightLevelA	:
					{
						if(pMCC->SD.IO.BCLight.ANo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Vertical Light Level" },
								{ "Vertical Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].A,0,LIGHTLEVEL_MAX)){
								DataPut(Sub_LightLevelA,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].A);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// Oblique Light Level
				case KeySub_LightLevelB	:
					{
						if(pMCC->SD.IO.BCLight.BNo == -1){
							Warn(OptionDisp[Lang]);
						} else {
							const char* msg[] = {
								{ "Oblique Light Level" },
								{ "Oblique Light Level" },
							};
							///////////////
							// �f�[�^�ҏW
							if(DataEdit(msg[Lang],"dig",pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].B,0,LIGHTLEVEL_MAX)){
								DataPut(Sub_LightLevelB,pMCC->BND.MD.HdTargetCalibD.lightLevel[BNDCtrl::eBDICCalib_SubSide].B);
								DataUpdate = TRUE;
							}
						}
					}
					break;
				///////////////
				// 
				case KeyPrev:
					End = TRUE;
					r = Prev_END;
					break;
				case KeyHome:
					End = TRUE;
					r = Home_END;
					break;
				case KeyTeach:
					End = TRUE;
					r = Teach1_END;
					break;
				case KeyData1:
					if(pMCC->MD.OptionD.hasACalib_HeadTarget){
						r = Data1_END;
						End = TRUE;
					} else {
						Warn(OptionDisp[Lang]);
					}
					break;
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	if(DataUpdate){	// �f�[�^�Z�[�u
		pMCC->BND.MD.BDICCalib.DataRW(FALSE, pMCC->BND.MD.FName);
		pMCC->BND.MD.HdTargetCalibD.DataRW(pMCC->C8200, FALSE, pMCC->BND.MD.FName);
	}
	return r;
}
/////////////////////////////////////////////////////////////////////////////
int TPCtrl::MCt_BDICCalib1()
{
	enum{
//		SNo					= 2705,	// ���No.
		SNo					= 2505,	// ���No.
		//
		Msg					= 160,	// ү���ޕ\��������
		//
		KeyEnter			= 65,	// �o�^���s
		KeyCancel			= 66,	
		KeyCheck			= 67,	// �m�F
		KeyCursor			= 71,	// ���وړ�
		KeyMInput			= 72,	// ����ݓo�^
		KeyMDisp			= 73,	// ����ݕ\��
		KeyTest				= 74,	// ýĔF��
		//
		AttEnter			= 200,
		AttCancel			= 201,	
		AttCheck			= 202,
		AttCursor			= 206,
		AttMInput			= 207,
		AttMDisp			= 208,
		AttTest				= 209,
		//
		KeyHome				= '0',	
		KeyPrev					,	
		KeyTeach				,	
		KeyData					,	
		KeyTeach1				,	
		KeyTeach2				,		

		MaxStep		= 2,
	};
	int		r = KeyPrev;
	BOOL	DataUpdate=FALSE;
	bool	ModelInput=false;	// ���ݓo�^���׸ށ@0:���o�^�@1:�o�^��

					//			 1234567890123456789012345678901234567890
	const char*	Emsg[]=	{		"[�o�^���s],[�m�F] �������Ă��������B    ",
								"1/2 IC���F������݂�ݒ肵�ĉ�����       ",
								"2/2 ����F������݂�ݒ肵�ĉ�����     ",
						};
					//			 1234567890123456789012345678901234567890
	const char*	EmsgEng[]=	{	"Please press [Set-up / Done],[Confirm]  ",
								"1/2 Set-up IC side pattern.             ",
								"2/2 Set-up Subst side pattern.          ",
							};
					//			 1234567890123456789012345678901234567890	
	const char*	Cmsg[]=	{		"[�o�^���s],[�m�F] �������Ă��������B    ",
								"1/2 IC���F������݈ʒu                   ",
								"2/2 ����F������݈ʒu                 ",
						};
					//			 1234567890123456789012345678901234567890
	const char*	CmsgEng[]=	{	"Please press [Set-up / Done],[Confirm]  ",
								"1/2 IC side pattern position.           ",
								"2/2 Subst side pattern position.        ",
							};
	tpc.GpPut16(AttCancel	,0);
	tpc.GpPut16(AttEnter	,0);
	tpc.GpPut16(AttCheck	,0);
	tpc.GpPut16(AttCursor	,0);
	tpc.GpPut16(AttMDisp	,0);
	tpc.GpPut16(AttTest		,0);
	tpc.GpPut16(AttMInput	,0);
		//@@@@@@@@@@@ ICCamNo �֖߂� @@@@@@@@@@@//
	pMCC->CameraSelect(ICCamNo);										// ��אؑ�
		//@@@@@@@@@@@ ICCamNo �֖߂� @@@@@@@@@@@//
	pMCC->BND.LightSelect(ICCamNo, BNDCtrl::eHdTarget_IC_LightLevel);	//  ch->	�Ɩ��I���@BCCamNo,ICCamNo
	int	Lang = (pMCC->MD.OptionD.Language_mode) ? 1 : 0;
	for(;;){
		BOOL	End=FALSE;
		int		CCnt=0,ECnt=0;
		tpc.GpScreenDisp(SNo);											// ��ʐ؂�ւ�
		tpc.GpPutStrLen(Msg,(Lang) ? EmsgEng[0] : Emsg[0],40);			// ү���ޕ\��
		for(;;){
			BOOL	Restart=FALSE;
			int		cnt=ECnt;
			if (0 == cnt)	cnt = CCnt;
			int Axis_Sw = BGH_XY | BGH_Z | CAM_XY | CAM_Z | STG_XY;
			switch (cnt) {
			case 1 :
// #OZ20150915-04 (S)
		//@@@@@@@@@@@ ICCamNo �֖߂� @@@@@@@@@@@//
				pMCC->CameraSelect(ICCamNo);										// ��אؑ�
				Set_Adjust_BND_STAGE_CAMERA_Sel(eKeyBND_BgHeadStageSel);
				Axis_Sw = BGH_XY | BGH_Z;
				break;
// #OZ20150915-04 (E)
			case 2 :
// #OZ20150915-04
				pMCC->CameraSelect(BCCamNo);										// ��אؑ�
				Set_Adjust_BND_STAGE_CAMERA_Sel(eKeyBND_BgHeadStageSel);
				// #TT150925-01 ���IC�L�����u�ɂ����āA�摜�̓o�^��1��Ƃ���(����o�^���̓w�b�hXY�𓮍삳���Ȃ�)
				//Axis_Sw = BGH_XY | BGH_Z;
				Axis_Sw = BGH_Z;
				break;
			}
			int key = KeyWait_Adjust_BND_STAGE_CAMERA(TRUE,eAdjMode_Normal,0,0,Axis_Sw);	//�@��ެ�ċ@�\�t��������
			if (key)	tpc.GpBeep();

			if (KeyEnter == key		// �o�^���s
			 && 0 == CCnt			// �m�FӰ�ޒ��łȂ�
			) {	
				bool	flag = true;
				MCC_Action_Call	A(pMCC);		// ����J�n���w��	�޽�׸��ŏI�����w��
				// #TT150925-01 ���IC�L�����u�ɂ����āA�摜�̓o�^��1��Ƃ���
//				if (1 == ECnt || 2 == ECnt) {	// �F�����ݓ���
				if (1 == ECnt) {				// �F�����ݓ���
					if (!ModelInput) {
						flag = false;
						const char *Wmsg[][2] = {
							{ "�p�^�[����ݒ肵�Ă��������B", "" },
							{ "Please set the Pattern.", "" }, 
						};
						Warn(Wmsg[Lang][0],Wmsg[Lang][1]);
					}
				}

				if(flag){
					ModelInput = false;
					if(pMCC->BND.HdTargetCalibRecTeach(ECnt)){				// è��ݸ� 
						ECnt ++ ;
						DataUpdate = TRUE;
						if (MaxStep < ECnt) {	// �I��
							tpc.GpPut16(AttEnter	,0);			// �o�^���s�@��I�����
							tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0],40);		// ү���ޕ\��
							ECnt = 0;
							DataUpdate = false;
							if(pMCC->MD.OptionF.DeviceDataSaveLater){
								// ���Ƃŕۑ�����B
								this->deviceDataNotSaved	= true;
							}
							pMCC->BND.MD.HdTargetCalibD.DataRW(pMCC->C8200, FALSE, pMCC->BND.MD.FName);
						}
						else{
							tpc.GpPut16(AttEnter	,ATTR_SEL);		// �o�^���s�@�I�����
							tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[ECnt] : Emsg[ECnt],40);		// ү���ޕ\��
						}
					}
				}
			}
			if(key == KeyCheck && ECnt == 0){	// �m�F
				MCC_Action_Call	A(pMCC);	// ����J�n���w��	�޽�׸��ŏI�����w��
				int ret = true;
				if (0 == ECnt){
				}
// #OZ20150917-03	�������Ă���ꏊ����ӏ��ɏW��B
				if( pMCC->BND.HdTargetCalibRecTeach(CCnt) ){				// è��ݸ�
					CCnt ++ ;
					if (MaxStep < CCnt) {	// �I��
						pMCC->CursorDisplay(0,0,0,0);								// ���ٸر
						tpc.GpPutStrLen(Msg, (Lang) ? EmsgEng[0] : Emsg[0],40);		// ү���ޕ\��
						tpc.GpPut16(AttCheck	,0);								// �m�F�@��I�����
						CCnt = 0;
					}
					else{
						tpc.GpPut16(AttCheck	,ATTR_SEL);								// �m�F�@�I�����
						pMCC->BND.HdTargetCalibRecDisp(CCnt);							// ���ٕ\��
						tpc.GpPutStrLen(Msg, (Lang) ? CmsgEng[CCnt] : Cmsg[CCnt],40);	// ү���ޕ\��
					}
				}
			}
			// #TT150925-01 ���IC�L�����u�ɂ����āA�摜�̓o�^��1��Ƃ���
//			else if (key == KeyMDisp && (CCnt >= 1 || ECnt >= 1)) {	// ����ݕ\��
			else if (key == KeyMDisp && (CCnt == 1 || ECnt == 1)) {	// ����ݕ\��
				tpc.GpPut16(AttMDisp	,ATTR_SEL);			// �I�����
				int	no = __max(CCnt,ECnt);
				
				pMCC->BND.HdTargetCalibRecModelDisp(no);
				for(;;){
					if(KeyWait() == KeyMDisp)	break;
				}
				tpc.GpBeep();
				pMCC->BND.HdTargetCalibRecDisp(no);						// ���ٕ\��
				tpc.GpPut16(AttMDisp	,0);						// ��I�����
			}
			// #TT150925-01 ���IC�L�����u�ɂ����āA�摜�̓o�^��1��Ƃ���
//			else if (key == KeyTest && (CCnt >= 1 || ECnt >= 1)) {	// ýĔF��
			else if (key == KeyTest && (CCnt == 1 || ECnt == 1)) {	// ýĔF��
				tpc.GpPut16(AttTest	,ATTR_SEL);						// �I�����
				int	no = __max(CCnt,ECnt);
				tpc.GpBeep();
// #OZ20150917-04
			//	pMCC->BND.HdTargetCalibRecDisp(no);						// ���ٕ\��
				pMCC->BND.HdTargetCalibRecTest(no);					// ýĔF
				for(;;){
					if(KeyWait() == KeyTest)	break;
				}
				tpc.GpBeep();
				tpc.GpPut16(AttTest	,0);							// ��I�����
				tpc.GpKeyClear();
			}
			// #TT150925-01 ���IC�L�����u�ɂ����āA�摜�̓o�^��1��Ƃ���
//			else if(key == KeyMInput && ECnt >= 1){					// ����ݓo�^
			else if(key == KeyMInput && ECnt == 1){					// ����ݓo�^
				tpc.GpPut16(AttMInput	,ATTR_SEL);					// �I�����

				if (pMCC->BND.HdTargetCalibRecModelInp(ECnt)) {			// ����ݓo�^
					ModelInput = true;
				}
				tpc.GpPut16(AttMInput	,0);						// ��I�����
				DataUpdate = TRUE;
			}
			// #TT150925-01 ���IC�L�����u�ɂ����āA�摜�̓o�^��1��Ƃ���
//			else if(key == KeyCursor && ECnt >= 1){					// ���وړ�
			else if(key == KeyCursor && ECnt == 1){					// ���وړ�
				MCC_Action_Call	A(pMCC);							// ����J�n���w��	�޽�׸��ŏI�����w��
				tpc.GpPut16(AttCursor	,ATTR_SEL);					// �I�����
				pMCC->BND.HdTargetCalibRecInp(ECnt,1);					// ���وړ�
				tpc.GpBeep();
// #OZ20150915-04
				//if(ECnt >= 5){
					pMCC->BND.HdTargetCalibRecInp(ECnt,2);				// ���وړ�
					tpc.GpBeep();
				//}
				tpc.GpPut16(AttCursor	,0);						// ��I�����
				DataUpdate = TRUE;
				ModelInput = false;
			}
			else if(key == KeyCancel){
				tpc.GpPut16(AttEnter	,0);						// �o�^���s�@��I�����
				tpc.GpPut16(AttCheck	,0);						// �o�^���s�@��I�����
				pMCC->BND.HdTargetCalibRecTeach(-1);					// ��ݾ�
				// �C���^�[���b�N��ʏ�p�ɐݒ�
				pMCC->BND.WD.nowHeadTargetCalibDoing = false;
				if(DataUpdate){
// #OZ20150915-04
//					pMCC->BND.MD.HdTargetCalibD.DataRW(pMCC->C8200, FALSE, pMCC->BND.MD.FName);
					pMCC->BND.MD.HdTargetCalibD.DataRW(pMCC->C8200, TRUE, pMCC->BND.MD.FName);
				}
				DataUpdate = FALSE;
				Restart = TRUE;
			}
			else if(CCnt == 0 && ECnt == 0){	// �o�^���s�y�ъm�F���ł͂Ȃ�
				if(key == KeyPrev){
					End = TRUE;
					r = Prev_END;
				}
				else if(key == KeyHome){
					End = TRUE;
					r = Home_END;
				}
				else if(key == KeyData){
					End = TRUE;
					r = Data1_END;	// �ް��ݒ��߰��1��
				}
				else if (KeyTeach1 == key) {
					if(pMCC->MD.OptionD.hasACalib_HeadTarget){
						r = Teach1_END;
						End = TRUE;
					} else {
						Warn(OptionDisp[Lang]);
					}
				}
			}
			if(Restart || End)	break;
		}
		if(End)	break;
	}
	return	r;
}
